package a.b;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

/** Automations ("flows"): a time + a list of blocks, each block can have an "only if" condition. Saved in flows.json. */
final class Flows {
    private Flows() { }

    static final class Step {
        String type;
        String cond = "";   // "" = always
        boolean not;        // run when the condition is FALSE
        int num;            // seconds, for blocks that need it
        String data = "";   // shortcut block: intent URI
        String label = "";  // shortcut block: name shown
        // send block: its own target. sid empty = use the automation's session / chat link / message
        String sid = "", sname = "", url = "", msg = "";
        Step(String t) { type = t; num = defNum(t); }
    }

    static final class Flow {
        String id, name, sid, sname, url = "", msg;
        int h = 19, m = 0;
        boolean daily = true, on = false;
        final ArrayList<Step> steps = new ArrayList<>();
    }

    /** "20:00 daily" / "18:10 once, OFF" for lists. */
    static String when(Flow f) {
        return String.format(java.util.Locale.US, "%02d:%02d", f.h, f.m) + (f.daily ? " daily" : " once") + (f.on ? "" : ", OFF");
    }

    static final ArrayList<Flow> all = new ArrayList<>();
    private static boolean loaded = false;

    static final String[][] TYPES = {
            {"wake", "Wake the screen"},
            {"unlock", "Unlock the phone (pattern)"},
            {"wifi_on", "Wi-Fi on"},
            {"wifi_off", "Wi-Fi off"},
            {"data_on", "Mobile data on"},
            {"data_off", "Mobile data off"},
            {"wait_net", "Wait for internet (seconds)"},
            {"wait", "Wait (seconds)"},
            {"ask", "Ask first with countdown (seconds)"},
            {"send", "Open the session and send the message"},
            {"shortcut", "Run an app shortcut / open an app"},
            {"lock", "Lock the screen"},
            {"stop", "Stop here (end the automation)"},
    };

    static final String[][] CONDS = {
            {"screen_on", "the screen is on"},
            {"locked", "the phone is locked"},
            {"in_use", "the phone is in use (on and unlocked)"},
            {"wifi_on", "Wi-Fi is switched on"},
            {"wifi_up", "Wi-Fi has internet"},
            {"data_on", "mobile data is on"},
            {"net_up", "there is internet"},
            {"s_wifi", "Wi-Fi was on when this started"},
            {"s_data", "mobile data was on when this started"},
            {"s_locked", "the phone was off or locked when this started"},
            {"s_use", "the phone was in use when this started"},
    };

    static boolean hasNum(String t) { return t.equals("wait_net") || t.equals("wait") || t.equals("ask"); }

    static int defNum(String t) { return t.equals("wait_net") ? 10 : t.equals("ask") ? 5 : t.equals("wait") ? 5 : 0; }

    static String typeLabel(String t) {
        for (String[] x : TYPES) if (x[0].equals(t)) return x[1];
        return t;
    }

    static String condLabel(String c) {
        for (String[] x : CONDS) if (x[0].equals(c)) return x[1];
        return c;
    }

    static String condText(Step s) {
        if (s.cond.isEmpty()) return "(always)";
        return (s.not ? "NOT " : "") + condLabel(s.cond);
    }

    static String label(Step s) {
        String t = typeLabel(s.type);
        if (hasNum(s.type)) t = t.replace("(seconds)", "").replace("seconds", "").trim() + " " + s.num + " s";
        if (s.type.equals("send") && !s.sid.isEmpty()) {
            t += " -> " + s.sname + (s.url.isEmpty() ? " (new chat)" : " (chat)");
            if (!s.msg.isEmpty()) t += ": " + (s.msg.length() > 20 ? s.msg.substring(0, 20) + "..." : s.msg);
        }
        if (s.type.equals("shortcut")) t += ": " + (s.label.isEmpty() ? "(none chosen)" : s.label);
        return t + (s.cond.isEmpty() ? "" : "  -  only if " + condText(s));
    }

    static int num(Flow f) {
        try { return Integer.parseInt(f.id); } catch (Exception e) { return 0; }
    }

    private static File file(Context c) { return new File(c.getFilesDir(), "flows.json"); }

    static synchronized void load(Context c) {
        if (loaded) return;
        loaded = true;
        try {
            File f = file(c);
            if (!f.exists()) return;
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int o = 0;
                while (o < b.length) { int k = in.read(b, o, b.length - o); if (k < 0) break; o += k; }
            }
            JSONArray a = new JSONArray(new String(b, "UTF-8"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject j = a.getJSONObject(i);
                Flow f2 = new Flow();
                f2.id = j.getString("id");
                f2.name = j.optString("name", "Automation");
                f2.sid = j.optString("sid", "");
                f2.sname = j.optString("sname", "");
                f2.url = j.optString("url", "");
                f2.msg = j.optString("msg", Auto.DEF_MSG);
                f2.h = j.optInt("h", 19);
                f2.m = j.optInt("m", 0);
                f2.daily = j.optBoolean("daily", true);
                f2.on = j.optBoolean("on", false);
                JSONArray st = j.optJSONArray("steps");
                if (st != null) for (int k = 0; k < st.length(); k++) {
                    JSONObject sj = st.getJSONObject(k);
                    Step s = new Step(sj.optString("t", "wait"));
                    s.cond = sj.optString("c", "");
                    s.not = sj.optBoolean("n", false);
                    s.num = sj.optInt("v", s.num);
                    s.data = sj.optString("d", "");
                    s.label = sj.optString("l", "");
                    s.sid = sj.optString("si", "");
                    s.sname = sj.optString("sn", "");
                    s.url = sj.optString("u", "");
                    s.msg = sj.optString("m", "");
                    f2.steps.add(s);
                }
                all.add(f2);
            }
        } catch (Throwable e) { Dbg.d("flows load failed: " + e); }
    }

    static synchronized void save(Context c) {
        try {
            JSONArray a = new JSONArray();
            for (Flow f : all) {
                JSONObject j = new JSONObject();
                j.put("id", f.id).put("name", f.name).put("sid", f.sid).put("sname", f.sname).put("url", f.url)
                        .put("msg", f.msg).put("h", f.h).put("m", f.m).put("daily", f.daily).put("on", f.on);
                JSONArray st = new JSONArray();
                for (Step s : f.steps) {
                    st.put(new JSONObject().put("t", s.type).put("c", s.cond).put("n", s.not).put("v", s.num).put("d", s.data).put("l", s.label)
                            .put("si", s.sid).put("sn", s.sname).put("u", s.url).put("m", s.msg));
                }
                j.put("steps", st);
                a.put(j);
            }
            File tmp = new File(c.getFilesDir(), "flows.json.tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(a.toString().getBytes("UTF-8")); }
            if (!tmp.renameTo(file(c))) { file(c).delete(); tmp.renameTo(file(c)); }
        } catch (Throwable e) { Dbg.d("flows save failed: " + e); }
    }

    static synchronized Flow byId(String id) {
        if (id == null) return null;
        for (Flow f : all) if (f.id.equals(id)) return f;
        return null;
    }

    /** What one send block sends: its own session / chat / message, or the automation's. */
    static Flow target(Flow f, Step s) {
        Flow t = new Flow();
        boolean own = !s.sid.isEmpty();
        t.id = f.id;
        t.name = f.name;
        t.sid = own ? s.sid : f.sid;
        t.sname = own ? s.sname : f.sname;
        t.url = own ? s.url : f.url;
        t.msg = s.msg.isEmpty() ? f.msg : s.msg;
        return t;
    }

    static synchronized Flow find(String sid, String url) {
        for (Flow f : all) if (f.sid.equals(sid) && f.url.equals(url)) return f;
        return null;
    }

    /** The usual night routine: unlock, get internet, ask if you are using the phone, send, undo what we changed. */
    static void defaultSteps(Flow f) {
        f.steps.clear();
        add(f, "wake", "screen_on", true, 0);
        add(f, "unlock", "locked", false, 0);
        add(f, "wifi_on", "wifi_on", true, 0);
        add(f, "wait_net", "", false, 10);
        add(f, "data_on", "net_up", true, 0);
        add(f, "wait_net", "net_up", true, 10);
        add(f, "stop", "net_up", true, 0);
        add(f, "ask", "s_use", false, 5);
        add(f, "send", "", false, 0);
        add(f, "wifi_off", "s_wifi", true, 0);
        add(f, "data_off", "s_data", true, 0);
        add(f, "lock", "s_locked", false, 0);
    }

    /** Saves this automation's blocks as the starting blocks of every new automation (kept in the backed-up auto prefs). */
    static void saveTemplate(Context c, Flow f) {
        try {
            JSONArray st = new JSONArray();
            for (Step s : f.steps)
                st.put(new JSONObject().put("t", s.type).put("c", s.cond).put("n", s.not).put("v", s.num).put("d", s.data).put("l", s.label)
                        .put("si", s.sid).put("sn", s.sname).put("u", s.url).put("m", s.msg));
            Auto.p(c).edit().putString("tpl", st.toString()).apply();
        } catch (Throwable e) { Dbg.d("template save failed: " + e); }
    }

    /** Blocks from the saved template; the factory routine if none was saved. */
    static void applyDefault(Context c, Flow f) {
        String s = Auto.p(c).getString("tpl", "");
        if (s.isEmpty()) { defaultSteps(f); return; }
        try {
            JSONArray st = new JSONArray(s);
            ArrayList<Step> n = new ArrayList<>();
            for (int k = 0; k < st.length(); k++) {
                JSONObject sj = st.getJSONObject(k);
                Step x = new Step(sj.optString("t", "wait"));
                x.cond = sj.optString("c", "");
                x.not = sj.optBoolean("n", false);
                x.num = sj.optInt("v", x.num);
                x.data = sj.optString("d", "");
                x.label = sj.optString("l", "");
                x.sid = sj.optString("si", "");
                x.sname = sj.optString("sn", "");
                x.url = sj.optString("u", "");
                x.msg = sj.optString("m", "");
                n.add(x);
            }
            f.steps.clear();
            f.steps.addAll(n);
        } catch (Throwable e) { Dbg.d("template load failed: " + e); defaultSteps(f); }
    }

    private static void add(Flow f, String t, String c, boolean not, int num) {
        Step s = new Step(t);
        s.cond = c;
        s.not = not && !c.isEmpty();
        if (num > 0) s.num = num;
        f.steps.add(s);
    }

    static synchronized Flow create(Context c, String sid, String sname, String url) {
        int max = 0;
        for (Flow x : all) max = Math.max(max, num(x));
        Flow f = new Flow();
        f.id = String.valueOf(max + 1);
        f.sid = sid;
        f.sname = sname;
        f.url = url;
        f.name = sname + (url.isEmpty() ? "" : " - continue");
        f.msg = url.isEmpty() ? Auto.msgNew(c) : Auto.msgLast(c);   // your two messages (Automations > Change ALL)
        applyDefault(c, f);
        all.add(f);
        save(c);
        return f;
    }

    /** The chat link a send should use after a bulk change. null = "last chat" wanted but this session has no saved chat yet. */
    private static String wantUrl(int mode, String cur, Store.Tab t) {
        if (mode == 2) return "";                       // new chat
        if (mode == 3) return cur == null ? "" : cur;   // messages only: the chat stays
        if (t != null && !t.chats.isEmpty()) return t.chats.get(0)[0];   // newest chat of the session
        return cur != null && cur.contains("/chat/") ? cur : null;
    }

    /**
     * Sets chat + message of EVERY automation (and of the send blocks that have their own session) in one go.
     * mode 1 = last chat of each session, 2 = new chat, 3 = messages only (each keeps its own chat).
     * A last-chat send gets your "last chat" message, a new-chat send gets your "new chat" message.
     * Time, ON/OFF, repeat and the other blocks are not touched. Returns a short report.
     */
    static synchronized String applyAll(Context c, int mode, Store st) {
        load(c);
        final String ml = Auto.msgLast(c), mn = Auto.msgNew(c);
        int n = 0, noChat = 0;
        for (Flow f : all) {
            String u = wantUrl(mode, f.url, st.byId(f.sid));
            if (u == null) { u = ""; noChat++; }
            f.url = u;
            f.msg = u.isEmpty() ? mn : ml;
            for (Step s : f.steps) {
                if (!s.type.equals("send")) continue;
                if (s.sid.isEmpty()) { s.msg = ""; continue; }   // uses the automation's chat + message
                String u2 = wantUrl(mode, s.url, st.byId(s.sid));
                if (u2 == null) { u2 = ""; noChat++; }
                s.url = u2;
                s.msg = u2.isEmpty() ? mn : ml;
            }
            n++;
        }
        save(c);
        Dbg.d("flow: bulk change mode=" + mode + " automations=" + n + " noSavedChat=" + noChat);
        return n + (n == 1 ? " automation" : " automations") + " changed"
                + (noChat > 0 ? ". " + noChat + " had no saved chat yet and stay on a new chat" : "");
    }

    static synchronized void remove(Context c, Flow f) {
        Auto.cancelAlarm(c, f);
        all.remove(f);
        save(c);
    }
}
