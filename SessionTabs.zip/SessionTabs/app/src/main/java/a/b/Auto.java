package a.b;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

import java.util.Calendar;

/** Alarms for the automations, the unlock pattern, and the notifications (running + Stop, result, stopped + OK). */
final class Auto {
    private Auto() { }

    static final String LIMIT_MSG = "\u0635\u0644 \u0639\u0644\u06CC \u0645\u062D\u0645\u062F \u0648\u0622\u0644 \u0645\u062D\u0645\u062F\nAnd just talk English please";
    static final String DEF_MSG = "Good morning Claude! Please reply with one short, friendly sentence.";
    static final int N_RUN = 801;
    static final String LAST_MSG = "Continue";   // factory message for "last chat"

    // ---- your two messages: one for automations that continue the LAST chat, one for automations that open a NEW chat ----
    // Used when a new automation is created, and by Automations > "Change ALL automations". Saved in the "auto" prefs (backups keep them).
    static String msgLast(Context c) { String s = p(c).getString("msg_last", ""); return s.isEmpty() ? LAST_MSG : s; }
    static String msgNew(Context c) { String s = p(c).getString("msg_new", ""); return s.isEmpty() ? LIMIT_MSG : s; }
    /** Empty text = back to the factory message. */
    static void setMsgLast(Context c, String s) { p(c).edit().putString("msg_last", s == null ? "" : s).apply(); }
    static void setMsgNew(Context c, String s) { p(c).edit().putString("msg_new", s == null ? "" : s).apply(); }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("auto", Context.MODE_PRIVATE); }
    static String pat(Context c) { return p(c).getString("pat", ""); }


    // ---- "automation at limit": per-session option, its automation id, and the mark shown on the session row ----
    // marks: 0 none, 1 automation created, 2 message sent, 3 not sent. Saved in the "auto" prefs (so backups keep them).
    static final int M_NONE = 0, M_CREATED = 1, M_SENT = 2, M_FAILED = 3;
    static boolean limitAuto(Context c, String sid) { return p(c).getBoolean("alim_" + sid, false); }
    static void setLimitAuto(Context c, String sid, boolean on) { p(c).edit().putBoolean("alim_" + sid, on).apply(); }
    static String limitFid(Context c, String sid) { return p(c).getString("afid_" + sid, ""); }
    static int mark(Context c, String sid) { return p(c).getInt("amark_" + sid, M_NONE); }
    static void setMark(Context c, String sid, int m) {
        p(c).edit().putInt("amark_" + sid, m).apply();
        final MainActivity a = MainActivity.inst;
        if (a != null) a.runOnUiThread(a::refreshUi);
    }

    /** Create (or re-arm) the one-time automation of this session for the moment its limit ends. Returns it, or null. */
    static Flows.Flow createForLimit(Context c, Store.Tab t, String chatUrl, long limitEnd) {
        Flows.load(c);
        Flows.Flow f = Flows.byId(limitFid(c, t.id));
        if (f == null) {   // first time: a new chat with YOUR "new chat" message
            f = Flows.create(c, t.id, t.name, "");
            p(c).edit().putString("afid_" + t.id, f.id).apply();
            f.name = t.name + " - limit";
            f.url = "";
            f.msg = msgNew(c);
        }
        // when it is re-armed for the next limit, its chat and message stay as YOU set them (all at once or one by one)
        f.sid = t.id; f.sname = t.name;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(limitEnd);   // exactly when the limit ends
        f.h = cal.get(Calendar.HOUR_OF_DAY);
        f.m = cal.get(Calendar.MINUTE);
        f.daily = false;
        f.on = true;
        Flows.save(c);
        scheduleOne(c, f);
        setMark(c, t.id, M_CREATED);
        Dbg.d("flow: limit automation for " + t.name + " at " + String.format(java.util.Locale.US, "%02d:%02d", f.h, f.m));
        return f;
    }

    /** Switch the session's limit automation off (limit mark cleared / option turned off). */
    static void cancelForLimit(Context c, String sid) {
        Flows.load(c);
        Flows.Flow f = Flows.byId(limitFid(c, sid));
        if (f != null && f.on) { f.on = false; Flows.save(c); scheduleOne(c, f); }
        if (mark(c, sid) == M_CREATED) setMark(c, sid, M_NONE);
    }

    // ---- notifications: mode 0 = result (swipe away), 1 = running (+Stop), 2 = sticky (+OK, cannot be swiped) ----
    static void cancel(Context c, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id);
    }

    static void note(Context c, int id, String title, String text, int mode) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            String ch = mode == 1 ? "ar_run" : "ar_done";
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(ch) == null) {
                nm.createNotificationChannel(new NotificationChannel(ch, mode == 1 ? "Automation running" : "Automation result",
                        mode == 1 ? NotificationManager.IMPORTANCE_LOW : NotificationManager.IMPORTANCE_DEFAULT));
            }
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, ch)
                    .setSmallIcon(mode == 1 ? android.R.drawable.stat_notify_sync : android.R.drawable.stat_sys_upload_done)
                    .setContentTitle(title).setContentText(text)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                    .setContentIntent(showPi(c)).setOnlyAlertOnce(true)
                    .setOngoing(mode != 0).setAutoCancel(mode == 0);
            if (mode == 1) {
                b.addAction(0, "Stop", PendingIntent.getBroadcast(c, 80, new Intent(c, Stop.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            } else if (mode == 2) {
                b.addAction(0, "OK", PendingIntent.getBroadcast(c, id, new Intent(c, Ok.class).putExtra("id", id),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            }
            nm.notify(id, b.build());
        } catch (Throwable e) { Dbg.d("flow: notification failed " + e); }
    }

    // ---- alarms: one per automation ----
    private static PendingIntent firePi(Context c, Flows.Flow f) {
        Intent i = new Intent(c, Fire.class).putExtra("fid", f.id);
        return PendingIntent.getBroadcast(c, 7000 + Flows.num(f), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent showPi(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, 79, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancelAlarm(Context c, Flows.Flow f) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(firePi(c, f));
    }

    static void scheduleOne(Context c, Flows.Flow f) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = firePi(c, f);
        am.cancel(pi);
        if (!f.on) { Dbg.d("flow: alarm cleared for " + f.name); return; }
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, f.h);
        t.set(Calendar.MINUTE, f.m);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 5000) t.add(Calendar.DAY_OF_YEAR, 1);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(t.getTimeInMillis(), showPi(c)), pi);
            Dbg.d("flow: alarm for " + f.name + " at " + t.getTime());
        } catch (Throwable e) { Dbg.d("flow: alarm failed " + e); }
    }

    /** Re-arm everything (alarms are lost after reboot / force-stop). */
    static void schedule(Context c) {
        Flows.load(c);
        try {   // alarm of the old single-automation version
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(PendingIntent.getBroadcast(c, 78, new Intent(c, Fire.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        } catch (Throwable ignored) { }
        for (Flows.Flow f : new java.util.ArrayList<>(Flows.all)) scheduleOne(c, f);
    }

    /** After a scheduled run: daily -> next day, once -> off. */
    static void afterRun(Context c, Flows.Flow f) {
        if (!f.daily) { f.on = false; Flows.save(c); }
        scheduleOne(c, f);
    }

    static String unlockCmd(Context c, String pt) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels, h = dm.heightPixels;
        double[] fx = {0.225, 0.5, 0.772}, fy = {0.561, 0.684, 0.8075};
        StringBuilder sb = new StringBuilder();
        sb.append("input swipe ").append(w / 2).append(' ').append((int) (h * 0.78)).append(' ')
                .append(w / 2).append(' ').append((int) (h * 0.31)).append(" 200; sleep 0.5; ");
        int px = 0, py = 0;
        for (int k = 0; k < pt.length(); k++) {
            int d = pt.charAt(k) - '1';
            int x = (int) (w * fx[d % 3]), y = (int) (h * fy[d / 3]);
            if (k == 0) {
                sb.append("input motionevent DOWN ").append(x).append(' ').append(y).append("; ");
            } else {
                for (int s = 1; s <= 3; s++) {
                    sb.append("input motionevent MOVE ").append(px + (x - px) * s / 3).append(' ')
                            .append(py + (y - py) * s / 3).append("; ");
                }
            }
            px = x; py = y;
        }
        sb.append("input motionevent UP ").append(px).append(' ').append(py).append("; sleep 1; ");
        return sb.toString();
    }

    public static final class Fire extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            Dbg.init(c);
            String fid = i.getStringExtra("fid");
            Dbg.d("flow: alarm fired id=" + fid);
            Engine.start(c.getApplicationContext(), fid, false);   // runs on its own thread: this returns at once
        }
    }

    /** The Stop button of the running notification. */
    public static final class Stop extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) {
            Dbg.init(c);
            Dbg.d("flow: STOP tapped");
            if (Engine.running) Engine.requestStop();
            else cancel(c, N_RUN);
        }
    }

    /** The OK button of the sticky "stopped" notification. */
    public static final class Ok extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { cancel(c, i.getIntExtra("id", 0)); }
    }

    public static final class Boot extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { schedule(c); }
    }
}
