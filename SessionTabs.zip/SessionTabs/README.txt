AR - multi-session browser (package a.b)

KEEP FOREVER: applicationId a.b and app/ar-release.keystore (same key + same package = updates keep all logins).

What it does
- Sessions screen is the home screen. Nothing loads until you tap a session. One WebView alive at a time.
- Closing a page keeps the session. Only "Delete session" (confirmed) erases logins.
- Hold a session: Rename / Set as MAIN / Link to main / Delete.
- Pencil (edit) icon on every session row = rename with one tap.
- Color dot on every session row: tap to cycle empty > red > green > blue (your own marks, e.g. "has the latest source").
- Folders: "+ New folder" at the top of the list, or hold a session > "Move to folder...". Tap a folder to open it
  (Back row or Android back returns). Hold a folder: Rename / Delete (sessions inside go back to the main window).
  Sessions not in a folder stay in the main window. Folders and colors are saved in backups and in Make APK.
- MAIN session holds your Google accounts. Linked sessions copy its Google cookies when opened,
  on Google/YouTube navigation, and every 4 minutes while open (best effort; Google may still ask to verify).
  Google login cookies (SID, SAPISID, __Secure-*, ...) are copied as .google.com / .youtube.com domain cookies so
  AI Studio, Gemini and Google API hosts see the login, not just accounts.google.com.
- Settings: Make APK (with or without logins), fingerprint/screen lock, home page, storage check.
- API button: Settings > "API button on the session list" hides/shows it on ALL sessions. Hold a session > "API button on this
  session's row" hides it on that one only. Hidden or not, hold a session > "API chat..." still opens it.
- Old installs are migrated automatically (profiles p1, p2... keep their logins).

Keep page alive (per session; automatic for Qwen)
- Hold a session > "Keep page alive, never reload": ON. The page is never unloaded when RAM is short (hidden pages of other sessions
  may still be), and the site is told it is always visible/focused (visibilitychange, blur, pagehide are hidden from it), so
  sites that reset or reload when you leave (Qwen: Start chat > menu > chat) stay exactly where you left them.
  The chat window that a site opens (Qwen: Start chat opens a popup window) is kept too: it is hidden, not closed, when you
  open the sessions list or another session, and comes back exactly as it was. Back closes it, as before.
  Microphone, camera, file upload and downloads now also work inside that chat window.
  If Android itself kills the app (vivo battery manager), nothing in memory survives: allow background activity for this app.

Automation at limit (per session)
- Hold a session > "Automation when the limit is set: ON". From then on, whenever that session gets a limit time
  (read from the Claude page, or set by hand with "Set limit time"), a one-time automation is created for the exact minute the
  limit ends and switched ON. Notifications must be allowed. The first time it is a new chat with YOUR "new chat" message
  (see "Change ALL automations at once" below; factory: Salawat + "And just talk English please").
- Marks on the right of the session row: "Auto" with a green check = automation created and waiting;
  thumbs up "Sent" = the message was sent; thumbs down "Not sent" = it failed or was stopped.
  The result mark goes away when you open the session.
- The same automation is re-used and re-armed for the next limit (no pile of automations). Only its time changes: the chat
  and message stay as you set them (all at once or one by one). "Clear limit mark" or
  turning the option OFF switches it off. You can still edit it in Automations (name: "<session> - limit").

Change ALL automations at once (Settings > Automations > first row)
- You keep TWO messages: one for "last chat" automations (factory: Continue) and one for "new chat" automations (factory: Salawat +
  "And just talk English please"). Edit them there (multi-line). New automations start with them too.
- "ALL > LAST chat of each session": every automation continues the newest chat the app saved for its session and sends the
  "last chat" message. A session with no saved chat yet stays on a new chat (the result says how many).
- "ALL > NEW chat": every automation opens a new chat and sends the "new chat" message.
- "Only the messages": each automation keeps its own chat; last-chat ones get the "last" message, new-chat ones the "new" message.
- It also updates the send blocks that have their own session. Time, ON/OFF, repeat and the other blocks are not touched.
- For one that must be different: open that automation and edit its Chat link / Message (message box is multi-line).

Copy Microsoft accounts to another session
- Hold the session that has your Microsoft accounts > "Copy Microsoft accounts to another session..." > pick the target
  (MAIN is marked with a star). The target's Microsoft logins are replaced by the source's; its Google/Claude logins and the
  source are not touched. Open the target (reload it if it was open). Works for any pair, also into the MAIN session.
- Best effort: it copies the cookies of the main Microsoft sign-in sites (live, microsoftonline, office, outlook, microsoft...).

Bookmarks (main session only): page menu > Bookmarks. Defaults: Gmail, Add Google account, My Google account, YouTube, Claude.
  "+ Add this page" / "- Remove a bookmark". Saved in the Make APK clone too.

Back button: each page's back history is saved when the page is unloaded and restored when you open the session again.
If Android kills the page for low RAM the app no longer crashes: it returns to the sessions list.

Microphone/camera: if Android refuses (also after "Don't ask again" was tapped once), a box offers "Open settings" ->
Permissions -> Microphone -> Allow.

Bug report: Settings (or page menu) > Copy bug report. Copies device info + the last 200 log lines
(back presses with history position, page loads, memory events, crashes). No cookies; URLs without query strings.

Downloads: a small script (injected into every page and iframe) tells the app the real file name the website gave
(the <a download="..."> name) and the file type. Names also come from Content-Disposition (incl. UTF-8 names).
Blob downloads made inside sandboxed iframes (blob:null/..., e.g. apps built in Google AI Studio) are read by the iframe
that owns the blob: the app asks the page, which relays the request down to its child frames. If no frame gives the file
within 30 s a "Download failed" toast appears.
If a file still has no usable name it is called download-DATE-TIME with the right extension (from its type or first bytes).

API chat (blue "API" button on every session card, also: hold a session > "API chat...")
- Opens a separate screen for that session that talks to the provider's API with YOUR API KEY, instead of the web page.
  Provider is guessed from the session (claude.ai = Claude, chatgpt.com = ChatGPT/OpenAI, qwen = Qwen/Alibaba Model Studio,
  aistudio/gemini = Google AI Studio); change it in the gear. The session's account email is shown at the top
  (read from the web login; the refresh button re-reads it). The API key itself is not linked to that login by the provider:
  paste it once per session in the gear (stored only in the app: files/api/<session>/ and in backups / Make APK WITH logins).
- Model list (Claude: Fable 5.2, Opus 5.5, Sonnet 5.5, Haiku 5.5, or "Test key + load models" to read the real list) and
  Effort: Low / Medium / High / Extra (= xhigh) / Max, sent as output_config.effort. If a model refuses a level or a
  max_tokens value the app lowers it and sends again by itself.
- Attach files (clip): png/jpg/gif/webp, PDF (Claude, ChatGPT), text/code files. Pasting long text (over 3000 characters,
  changeable) becomes a TXT attachment automatically; the clipboard button always pastes as TXT.
- Voice (microphone): speech to text with the phone's recognizer, keeps listening until you tap again. Voice language in the gear.
- Copy: Copy button on every message and every code block; text is also selectable by long-press. Export chat as TXT in the gear.
- Chats: list button = previous chats of this session (open / rename / delete), + = new chat. Retry / Edit on the last message.
- Streaming answers, Stop button, token usage under each answer.

Readable backup (Settings > "Readable backup for Claude (JSON + text)...")
- Writes 2 files to Downloads: AR-readable-SAFE-<date>.json and a short .txt summary. It is only for READING; it restores nothing
  (use "Restore from backup" with the normal zip for that).
- Contains: every session (also removed ones): name, id, link, folder, color, MAIN/linked, keep-alive, limit time, recent chats,
  folders, bookmarks, settings, automations, automation settings, and per session the list of cookies by site.
- Accounts: every session that has a Claude or ChatGPT login is opened invisibly for a few seconds and asked which account it is
  (email, name, organizations). Best effort: if the site shows a check page or changes its answer, the file says why it could not read it.
  Tokens are never saved. Google: only MAIN / linked layout (the number of accounts inside a MAIN session cannot be read from outside).
- SAFE = cookie names + value lengths only, no phone unlock pattern: this is the one to send to Claude.
  FULL (private) = also the cookie values and the unlock pattern = live logins. Never upload it.

Make APK
- Copies the installed APK, replaces assets/tabs_default.json (+ assets/sessions_default.zip with logins),
  signs on the phone with the key built into assets, verifies, saves to Downloads.
- Fresh install of a clone restores everything once. Updates never touch existing data.
- A clone made WITH logins = your accounts. Never upload it or put it in the repo.

Build: unchanged (gradle assembleRelease, AGP 8.5.2). Gradle task genSigner exports the key from the keystore into assets.
