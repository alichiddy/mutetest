# A Gesture — local file-sharing addition

This source revision renames the installed application ID to `a.gstr` and the launcher label to **A Gesture**. It adds Android Share-sheet targets for one or multiple files.

## Implemented in this revision

- Share / Share multiple intents open the A Gesture transfer screen.
- Editable Wi-Fi Direct network name, password and HTTP port.
- Android 10+ Wi-Fi Direct group creation with the requested credentials.
- Two QR codes: WPA Wi-Fi credentials and `http://192.168.49.1:<port>`.
- Local HTTP page with download links for the files explicitly shared to the app.
- A persistent foreground notification with Show QR and Stop server actions.
- A Download all button on the receiving page (the receiving browser may require permission for multiple downloads).

## Known limitations — not implemented yet

- The current server exposes only files passed through Android's Share sheet. It does not yet expose the sender's entire storage or a SAF-selected folder.
- Wi-Fi-off hotspot fallback is not implemented. This revision asks the user to enable Wi-Fi before creating a Wi-Fi Direct group.
- Wi-Fi Direct uses one operating band/channel per group; Android does not provide a single group that simultaneously broadcasts on both 2.4 GHz and 5 GHz.
- The current transfer URL assumes the device is the Wi-Fi Direct group owner at `192.168.49.1`.
- The source has not been compiled or tested on a physical device in this environment because no Android SDK platform is installed here. Run the GitHub Actions build, then test on the Vivo Y21 before relying on it.

This is a personal sideload-oriented build. Do not expose the HTTP server on untrusted networks; it is intended for a direct local Wi-Fi connection.
