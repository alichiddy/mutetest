PKG=@PKG@
appops set $PKG SYSTEM_ALERT_WINDOW allow
appops set $PKG WRITE_SETTINGS allow
appops set $PKG MANAGE_EXTERNAL_STORAGE allow
appops set $PKG REQUEST_INSTALL_PACKAGES allow
pm grant $PKG android.permission.POST_NOTIFICATIONS 2>/dev/null
cmd notification allow_dnd $PKG 2>/dev/null
dumpsys deviceidle whitelist +$PKG 2>/dev/null
SVC=$(cmd package query-services --brief --components -a android.accessibilityservice.AccessibilityService 2>/dev/null | grep "^$PKG/" | head -n 1)
if [ -n "$SVC" ]; then
  OLD=$(settings get secure enabled_accessibility_services)
  case ":$OLD:" in
    *":$SVC:"*) ;;
    *) if [ "$OLD" = "null" ] || [ -z "$OLD" ]; then settings put secure enabled_accessibility_services "$SVC"; else settings put secure enabled_accessibility_services "$OLD:$SVC"; fi ;;
  esac
  settings put secure accessibility_enabled 1
  echo "Accessibility: on"
else
  echo "Accessibility service not found"
fi
echo "Draw over apps: $(appops get $PKG SYSTEM_ALERT_WINDOW)"
echo "Modify settings: $(appops get $PKG WRITE_SETTINGS)"
echo "All files: $(appops get $PKG MANAGE_EXTERNAL_STORAGE)"
echo "Done"
