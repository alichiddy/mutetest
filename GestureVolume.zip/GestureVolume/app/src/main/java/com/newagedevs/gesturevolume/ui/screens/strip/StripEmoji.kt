package com.newagedevs.gesturevolume.ui.screens.strip

/** The picker's emoji: drawn by the system font, so they take no storage of their own. */
internal val StripEmoji: List<String> = (
    "🔦 💡 🔆 🔅 🌙 ☀️ ⭐ ✨ 🔥 ⚡ 💧 ❄️ 🌡️ 🔋 🪫 🔌 📶 📡 🛜 📍 🧭 🗺️ ✈️ 🚗 🚀 🛡️ 🔒 🔓 🔑 🚫 ⛔ ✅ ❌ ⭕ ❗ ❓ ℹ️ ⚠️ 🔔 🔕 🔊 🔉 🔈 🔇 🎵 🎶 🎤 🎧 📻 📺 🎬 🎮 🕹️ 📷 📸 📹 🖼️ 🔍 🔎 🔬 🧪 🧰 🔧 🔨 ⚙️ 🛠️ 🧲 🧮 🔢 🔤 🔠 📝 ✏️ 🖊️ 📋 📄 📃 📑 📁 📂 🗂️ 🗃️ 🗑️ 📥 📤 📦 📬 ✉️ 📧 💬 🗨️ 📞 ☎️ 📱 💻 🖥️ ⌨️ 🖱️ 💾 💿 ☁️ ⬆️ ⬇️ ⬅️ ➡️ 🔄 🔁 🔀 ▶️ ⏸️ ⏹️ ⏭️ ⏮️ ⏩ ⏪ 🔼 🔽 ➕ ➖ ✖️ ➗ 💲 💰 🏦 💳 🧾 🕐 ⏰ ⏱️ ⏲️ ⌛ ⏳ 📅 📆 🗓️ 🏠 🏢 🏫 🏪 🛒 🛍️ 🍔 🍕 ☕ 🍵 🍎 🍌 🎂 🎁 🎉 🏆 🥇 🎯 🎲 🃏 🧩 ♟️ 🎨 🖌️ 📚 📖 🎓 🔭 🌍 🌎 🌏 🌐 🌳 🌸 🌈 ☔ ⛅ 🌊 🐞 🐛 🐱 🐶 🦊 🐻 🐼 🐸 🦉 🤖 👽 👻 💀 😀 😎 🤔 😴 🙈 🙉 🙊 👁️ 👀 👍 👎 👌 ✌️ 🤝 🙏 💪 ❤️ 💙 💚 💛 🧡 💜 🖤 🤍 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ 🔳 🔲 ♻️ ⏻ 🆘 🆗 🆒 🆕 🅰️ 🅱️ 🔰 ☑️ 🏁 🚩 🏳️ 📌 📎 🔗 ⛓️ 🧷 🪄 🔮 🎭 🧿 🕌 🕋 📿"
).split(" ")
