package com.newagedevs.gesturevolume.strip

import com.newagedevs.gesturevolume.utils.HandlerActions
import org.json.JSONArray
import org.json.JSONObject

/**
 * One cell of the strip.
 *
 * [action] is what runs: any [HandlerActions] identifier (so every Deck action, tile, app launch
 * and the QR scanner already work), or "Flow:468/233" for an Automate flow statement, or empty for
 * a blank cell. [icon] is an emoji (zero bytes: the system font draws it), "app:<package>" for that
 * app's own icon, or empty to show the label instead.
 */
data class StripItem(
    val label: String, val icon: String, val action: String,
    /** Seconds the shortcut stays on screen after it ran; null follows the strip's own setting, 0 is off. */
    val stay: Int? = null,
    /** Toast after running: null follows the strip's setting, 0 off, 1 short, 2 long. */
    val toast: Int? = null,
    /** Seconds a notification about the run stays; null follows the strip's setting, 0 is off. */
    val notify: Int? = null,
) {
    /**
     * The app whose icon the strip draws: the one chosen, or, when no icon was chosen, the app the
     * action belongs to (an app shortcut's target, a launched app, Automate for a flow).
     */
    val appIconPackage: String? get() = when {
        icon.startsWith("app:") -> icon.substring(4).takeIf { it.isNotBlank() }
        icon.isEmpty() -> derivedPackage(action)
        else -> null
    }

    /** Name of a picture kept in this app's own storage (a shortcut's own icon), or null. */
    val iconFile: String? get() = icon.takeIf { it.startsWith("img:") }?.substring(4)

    private companion object {
        val derived = HashMap<String, String>()

        fun derivedPackage(action: String): String? {
            if (action.isEmpty()) return null
            derived[action]?.let { return it.takeIf { p -> p.isNotEmpty() } }
            val pkg = when {
                action.startsWith("Launch app:") -> action.removePrefix("Launch app:")
                action.startsWith("Flow:") -> "com.llamalab.automate"
                action.startsWith("Intent:") -> runCatching {
                    val i = android.content.Intent.parseUri(action.removePrefix("Intent:"), android.content.Intent.URI_INTENT_SCHEME)
                    i.component?.packageName ?: i.`package` ?: ""
                }.getOrDefault("")
                else -> ""
            }
            derived[action] = pkg
            return pkg.takeIf { it.isNotEmpty() }
        }
    }
}

/** The strip's whole configuration, kept as one small JSON string in the preferences. */
data class StripConfig(
    val columns: Int = 8,
    /** Cell size as a percentage of the largest size that still fits the screen. */
    val sizePct: Int = 88,
    val showLabels: Boolean = true,
    /** Centered on the screen instead of on the bar's side. */
    val centered: Boolean = false,
    val bottomDp: Int = 40,
    /** Seconds the shortcut that ran stays visible (0 = hide at once). */
    val stay: Int = 1,
    /** Toast after a run: 0 off, 1 short, 2 long. */
    val toast: Int = 0,
    /** Seconds a notification about the run stays; 0 is off. */
    val notify: Int = 0,
    val items: List<StripItem> = defaultItems(),
) {
    fun toJson(): String {
        val arr = JSONArray()
        for (it in items) {
            val o = JSONObject().put("l", it.label).put("i", it.icon).put("a", it.action)
            it.stay?.let { v -> o.put("y", v) }
            it.toast?.let { v -> o.put("o", v) }
            it.notify?.let { v -> o.put("n", v) }
            arr.put(o)
        }
        return JSONObject()
            .put("c", columns).put("s", sizePct).put("t", showLabels)
            .put("m", centered).put("b", bottomDp).put("y", stay).put("o", toast).put("n", notify).put("items", arr)
            .toString()
    }

    companion object {
        const val FLOW_PREFIX = "Flow:"

        fun flowAction(flow: Int, statement: Int) = "$FLOW_PREFIX$flow/$statement"

        /** The Automate content URI for a "Flow:f/s" action, or null for any other action. */
        fun flowUri(action: String): String? {
            if (!action.startsWith(FLOW_PREFIX)) return null
            val parts = action.removePrefix(FLOW_PREFIX).split("/")
            val f = parts.getOrNull(0)?.toIntOrNull() ?: return null
            val s = parts.getOrNull(1)?.toIntOrNull() ?: return null
            return "content://com.llamalab.automate.provider/flows/$f/statements/$s"
        }

        /** Pulls the two numbers out of a pasted Automate URI (or "468/233"), or null. */
        fun parseFlow(text: String): String? {
            val m = Regex("""flows/(\d+)/statements/(\d+)""").find(text)
                ?: Regex("""^\s*(\d+)\s*[/ ,]\s*(\d+)\s*$""").find(text)
                ?: return null
            return flowAction(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }

        /**
         * The saved configuration, or, when nothing is saved, the one baked into the app as
         * assets/strip_default.json (this is how an APK carries its author's edited strip to
         * another phone), or else the built-in Easy Slider list.
         */
        fun load(context: android.content.Context, json: String?): StripConfig {
            if (!json.isNullOrBlank()) return fromJson(json)
            val baked = runCatching {
                context.assets.open("strip_default.json").bufferedReader().use { it.readText() }
            }.getOrNull()
            return if (baked.isNullOrBlank()) StripConfig() else fromJson(baked)
        }

        fun fromJson(json: String?): StripConfig {
            if (json.isNullOrBlank()) return StripConfig()
            return runCatching {
                val o = JSONObject(json)
                val arr = o.getJSONArray("items")
                val list = ArrayList<StripItem>(arr.length())
                for (n in 0 until arr.length()) {
                    val e = arr.getJSONObject(n)
                    list += StripItem(
                        e.optString("l"), e.optString("i"), e.optString("a"),
                        if (e.has("y")) e.optInt("y") else null,
                        if (e.has("o")) e.optInt("o") else null,
                        if (e.has("n")) e.optInt("n") else null,
                    )
                }
                StripConfig(
                    columns = o.optInt("c", 8).coerceIn(1, 16),
                    sizePct = o.optInt("s", 88).coerceIn(30, 100),
                    showLabels = o.optBoolean("t", true),
                    centered = o.optBoolean("m", false),
                    bottomDp = o.optInt("b", 40).coerceIn(0, 400),
                    stay = o.optInt("y", 1).coerceIn(0, 60),
                    toast = o.optInt("o", 0).coerceIn(0, 2),
                    notify = o.optInt("n", 0).coerceIn(0, 120),
                    items = list,
                )
            }.getOrDefault(StripConfig())
        }

        /** Easy Slider's strip, as editable items. */
        fun defaultItems(): List<StripItem> = ShortcutStore.legacy.map { old ->
            val action = when {
                old.flow > 0 -> flowAction(old.flow, old.statement)
                old.pkg != null -> HandlerActions.launchApp(old.pkg)
                else -> ""
            }
            val icon = old.pkg?.let { "app:$it" } ?: DEFAULT_EMOJI[old.label].orEmpty()
            StripItem(old.label, icon, action)
        }

        // A first guess for some labels; every one can be changed in the editor.
        private val DEFAULT_EMOJI = mapOf(
            "QShr" to "📤", "GRNT" to "✅", "RVOK" to "🚫", "Torch" to "🔦", "Airpl" to "✈️",
            "BT" to "🔵", "Loc" to "📍", "Hotsp" to "📶", "WifiOn" to "📶", "Wifi" to "📡",
            "Brgt" to "🔆", "Awake" to "☕", "ScrSh" to "📸", "PSTE" to "📋", "CopyM" to "📄",
            "Speed" to "⚡", "AppInf" to "ℹ️", "UPLD" to "⬆️", "GUPLD" to "☁️", "MaxVol" to "🔊",
            "TMP" to "🌡️", "DSave" to "🔋", "LOGKL" to "📜", "QR" to "🔳", "Power" to "⏻",
            "V2Ray" to "🚀", "V2Win" to "🚀", "WFV2R" to "🚀", "HSSt" to "🛡️", "DbgOff" to "🐞",
            "HdDev" to "🙈", "ShwDV" to "👁️", "123" to "🔢", "SOD" to "🌙",
        )
    }
}
