package com.newagedevs.gesturevolume.strip

import com.newagedevs.gesturevolume.utils.HandlerActions
import org.json.JSONArray
import org.json.JSONObject

/**
 * One cell of the strip.
 *
 * [action] is what runs: any [HandlerActions] identifier (so every Deck action, tile, app launch
 * and the QR scanner already work), or "Flow:468/233" for an Automate flow statement, or empty for
 * a blank cell. [icon] is an emoji (zero bytes: the system font draws it), "app:<package>" for that
 * app's own icon, or empty to show the label instead.
 */
data class StripItem(val label: String, val icon: String, val action: String) {
    val appIconPackage: String? get() = icon.takeIf { it.startsWith("app:") }?.substring(4)?.takeIf { it.isNotBlank() }
}

/** The strip's whole configuration, kept as one small JSON string in the preferences. */
data class StripConfig(
    val columns: Int = 8,
    /** Cell size as a percentage of the largest size that still fits the screen. */
    val sizePct: Int = 88,
    val showLabels: Boolean = true,
    /** Centered on the screen instead of on the bar's side. */
    val centered: Boolean = false,
    val bottomDp: Int = 40,
    val items: List<StripItem> = defaultItems(),
) {
    fun toJson(): String {
        val arr = JSONArray()
        for (it in items) arr.put(JSONObject().put("l", it.label).put("i", it.icon).put("a", it.action))
        return JSONObject()
            .put("c", columns).put("s", sizePct).put("t", showLabels)
            .put("m", centered).put("b", bottomDp).put("items", arr)
            .toString()
    }

    companion object {
        const val FLOW_PREFIX = "Flow:"

        fun flowAction(flow: Int, statement: Int) = "$FLOW_PREFIX$flow/$statement"

        /** The Automate content URI for a "Flow:f/s" action, or null for any other action. */
        fun flowUri(action: String): String? {
            if (!action.startsWith(FLOW_PREFIX)) return null
            val parts = action.removePrefix(FLOW_PREFIX).split("/")
            val f = parts.getOrNull(0)?.toIntOrNull() ?: return null
            val s = parts.getOrNull(1)?.toIntOrNull() ?: return null
            return "content://com.llamalab.automate.provider/flows/$f/statements/$s"
        }

        /** Pulls the two numbers out of a pasted Automate URI (or "468/233"), or null. */
        fun parseFlow(text: String): String? {
            val m = Regex("""flows/(\d+)/statements/(\d+)""").find(text)
                ?: Regex("""^\s*(\d+)\s*[/ ,]\s*(\d+)\s*$""").find(text)
                ?: return null
            return flowAction(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }

        /**
         * The saved configuration, or, when nothing is saved, the one baked into the app as
         * assets/strip_default.json (this is how an APK carries its author's edited strip to
         * another phone), or else the built-in Easy Slider list.
         */
        fun load(context: android.content.Context, json: String?): StripConfig {
            if (!json.isNullOrBlank()) return fromJson(json)
            val baked = runCatching {
                context.assets.open("strip_default.json").bufferedReader().use { it.readText() }
            }.getOrNull()
            return if (baked.isNullOrBlank()) StripConfig() else fromJson(baked)
        }

        fun fromJson(json: String?): StripConfig {
            if (json.isNullOrBlank()) return StripConfig()
            return runCatching {
                val o = JSONObject(json)
                val arr = o.getJSONArray("items")
                val list = ArrayList<StripItem>(arr.length())
                for (n in 0 until arr.length()) {
                    val e = arr.getJSONObject(n)
                    list += StripItem(e.optString("l"), e.optString("i"), e.optString("a"))
                }
                StripConfig(
                    columns = o.optInt("c", 8).coerceIn(1, 16),
                    sizePct = o.optInt("s", 88).coerceIn(30, 100),
                    showLabels = o.optBoolean("t", true),
                    centered = o.optBoolean("m", false),
                    bottomDp = o.optInt("b", 40).coerceIn(0, 400),
                    items = list,
                )
            }.getOrDefault(StripConfig())
        }

        /** Easy Slider's strip, as editable items. */
        fun defaultItems(): List<StripItem> = ShortcutStore.legacy.map { old ->
            val action = when {
                old.flow > 0 -> flowAction(old.flow, old.statement)
                old.pkg != null -> HandlerActions.launchApp(old.pkg)
                else -> ""
            }
            val icon = old.pkg?.let { "app:$it" } ?: DEFAULT_EMOJI[old.label].orEmpty()
            StripItem(old.label, icon, action)
        }

        // A first guess for some labels; every one can be changed in the editor.
        private val DEFAULT_EMOJI = mapOf(
            "QShr" to "📤", "GRNT" to "✅", "RVOK" to "🚫", "Torch" to "🔦", "Airpl" to "✈️",
            "BT" to "🔵", "Loc" to "📍", "Hotsp" to "📶", "WifiOn" to "🛜", "Wifi" to "📡",
            "Brgt" to "🔆", "Awake" to "☕", "ScrSh" to "📸", "PSTE" to "📋", "CopyM" to "📄",
            "Speed" to "⚡", "AppInf" to "ℹ️", "UPLD" to "⬆️", "GUPLD" to "☁️", "MaxVol" to "🔊",
            "TMP" to "🌡️", "DSave" to "🔋", "LOGKL" to "📜", "QR" to "🔳", "Power" to "⏻",
            "V2Ray" to "🚀", "V2Win" to "🚀", "WFV2R" to "🚀", "HSSt" to "🛡️", "DbgOff" to "🐞",
            "HdDev" to "🙈", "ShwDV" to "👁️", "123" to "🔢", "SOD" to "🌙",
        )
    }
}
