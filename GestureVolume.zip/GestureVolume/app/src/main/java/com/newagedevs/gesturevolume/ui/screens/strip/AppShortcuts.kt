package com.newagedevs.gesturevolume.ui.screens.strip

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import org.xmlpull.v1.XmlPullParser

/** A shortcut an app declares in its manifest (the kind a launcher shows on a long press). */
class FoundShortcut(val packageName: String, val appLabel: String, val label: String, val intentUri: String)

/** An app's "create shortcut" screen, such as Automate's flow picker or Shortcut Maker. */
class ShortcutCreator(val packageName: String, val className: String, val label: String)

private const val NS = "http://schemas.android.com/apk/res/android"

/** The Intent: action prefix a stored app shortcut carries. */
const val INTENT_ACTION_PREFIX = "Intent:"

fun loadCreators(context: Context): List<ShortcutCreator> {
    val pm = context.packageManager
    return runCatching { pm.queryIntentActivities(Intent(Intent.ACTION_CREATE_SHORTCUT), 0) }
        .getOrDefault(emptyList())
        .map { ShortcutCreator(it.activityInfo.packageName, it.activityInfo.name, it.loadLabel(pm).toString()) }
        .sortedBy { it.label.lowercase() }
}

/** Reads every launchable app's static shortcuts file. Dynamic shortcuts are not readable by other apps. */
fun loadStaticShortcuts(context: Context): List<FoundShortcut> {
    val pm = context.packageManager
    val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val out = ArrayList<FoundShortcut>()
    val resolved = runCatching { pm.queryIntentActivities(launcher, PackageManager.GET_META_DATA) }
        .getOrDefault(emptyList())
    for (ri in resolved) {
        val info = ri.activityInfo
        val resId = info.metaData?.getInt("android.app.shortcuts") ?: 0
        if (resId == 0 || info.packageName == context.packageName) continue
        runCatching {
            val res = pm.getResourcesForApplication(info.applicationInfo)
            val appLabel = ri.loadLabel(pm).toString()
            val p = res.getXml(resId)
            try {
                fun attr(name: String): String? {
                    val r = p.getAttributeResourceValue(NS, name, 0)
                    return if (r != 0) runCatching { res.getString(r) }.getOrNull() else p.getAttributeValue(NS, name)
                }
                var label: String? = null
                var enabled = true
                var intent: Intent? = null
                var event = p.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "shortcut" -> {
                                label = attr("shortcutShortLabel") ?: attr("shortcutLongLabel")
                                enabled = p.getAttributeBooleanValue(NS, "enabled", true)
                                intent = null
                            }
                            "intent" -> {
                                val i = Intent()
                                attr("action")?.let { i.action = it }
                                attr("data")?.let { i.data = Uri.parse(it) }
                                val pkg = attr("targetPackage") ?: info.packageName
                                val cls = attr("targetClass")
                                if (cls != null) i.setClassName(pkg, cls) else i.setPackage(pkg)
                                intent = i
                            }
                            "extra" -> {
                                val name = attr("name")
                                val value = attr("value")
                                if (name != null && value != null) intent?.putExtra(name, value)
                            }
                        }
                    } else if (event == XmlPullParser.END_TAG && p.name == "shortcut") {
                        val l = label
                        val i = intent
                        if (enabled && l != null && i != null) {
                            out += FoundShortcut(info.packageName, appLabel, l, i.toUri(Intent.URI_INTENT_SCHEME))
                        }
                    }
                    event = p.next()
                }
            } finally {
                p.close()
            }
        }
    }
    return out.sortedWith(compareBy({ it.appLabel.lowercase() }, { it.label.lowercase() }))
}


/**
 * The icon a shortcut maker hands back with its shortcut, kept as a small picture in the app's own
 * storage so the strip can show it. Returns "img:<name>", or null when the shortcut carried none.
 */
fun saveShortcutIcon(context: Context, data: Intent?): String? {
    if (data == null) return null
    val bmp: android.graphics.Bitmap? = runCatching {
        @Suppress("DEPRECATION")
        data.getParcelableExtra<android.graphics.Bitmap>(Intent.EXTRA_SHORTCUT_ICON)
    }.getOrNull() ?: runCatching {
        @Suppress("DEPRECATION")
        val res = data.getParcelableExtra<Intent.ShortcutIconResource>(Intent.EXTRA_SHORTCUT_ICON_RESOURCE)
        if (res == null) null else {
            val r = context.packageManager.getResourcesForApplication(res.packageName)
            val id = r.getIdentifier(res.resourceName, null, null)
            androidx.core.graphics.drawable.toBitmap(androidx.core.content.res.ResourcesCompat.getDrawable(r, id, null)!!, 96, 96)
        }
    }.getOrNull()
    if (bmp == null) return null
    return runCatching {
        val dir = java.io.File(context.filesDir, "sicons").apply { mkdirs() }
        val name = "s${System.currentTimeMillis()}.png"
        java.io.File(dir, name).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
        "img:$name"
    }.getOrNull()
}
