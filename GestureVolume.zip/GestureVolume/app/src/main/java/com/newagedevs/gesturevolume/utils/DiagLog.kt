package com.newagedevs.gesturevolume.utils

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * A small diary of what went wrong, and a report that can be copied and sent.
 *
 * The report says what phone this is, which permissions and settings are in place, what each
 * audio stream looks like, the app's own recent notes, and the app's own warnings and errors from
 * the system log (an app may read its own lines of the log without any permission).
 */
object DiagLog {
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun note(text: String) {
        if (lines.size >= 200) lines.removeFirst()
        lines.addLast("${clock.format(Date())} $text")
    }

    /**
     * A note that survives the process being killed: kept in a small private file, newest last,
     * so the next report can say what happened before the app last died.
     */
    fun persist(context: Context, text: String) {
        note(text)
        runCatching {
            val f = java.io.File(context.filesDir, "events.log")
            val old = if (f.exists()) f.readLines().takeLast(60) else emptyList()
            f.writeText((old + "${java.text.SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())} $text").joinToString("\n") + "\n")
        }
    }

    /** Written once each time the app process starts, with what the settings say about the service. */
    fun processStarted(context: Context) {
        val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        persist(context, "process started; accessibility in settings=${enabled.contains(context.packageName)}")
    }

    fun e(what: String, error: Throwable) = note("ERROR $what: ${error.javaClass.simpleName}: ${error.message}")

    /** A volume write that raised no error but left the level where it was is the Realme-type failure. */
    fun verify(manager: AudioManager, stream: Int, wanted: Int) {
        val now = runCatching { manager.getStreamVolume(stream) }.getOrNull() ?: return
        if (now != wanted) note("WRITE IGNORED stream=$stream wanted=$wanted now=$now fixed=${runCatching { manager.isVolumeFixed }.getOrNull()} mode=${runCatching { manager.mode }.getOrNull()}")
    }

    fun report(context: Context): String {
        val sb = StringBuilder()
        fun line(s: String) = sb.append(s).append('\n')
        line("== A diagnostic report ==")
        line("Phone: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
        line("Build: ${Build.DISPLAY}")
        runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            line("App: ${context.packageName} ${info.versionName}")
        }
        line("Overlay allowed: ${runCatching { Settings.canDrawOverlays(context) }.getOrNull()}")
        line("Write settings allowed: ${runCatching { Settings.System.canWrite(context) }.getOrNull()}")
        line("Notification policy (DND) access: ${runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }.getOrNull()}")
        val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        line("Accessibility service on: ${enabled.contains(context.packageName)}")
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audio != null) {
            line("Audio mode: ${runCatching { audio.mode }.getOrNull()}  volume fixed: ${runCatching { audio.isVolumeFixed }.getOrNull()}  music active: ${runCatching { audio.isMusicActive }.getOrNull()}")
            val names = listOf(
                AudioManager.STREAM_MUSIC to "music", AudioManager.STREAM_RING to "ring",
                AudioManager.STREAM_NOTIFICATION to "notification", AudioManager.STREAM_ALARM to "alarm",
                AudioManager.STREAM_VOICE_CALL to "call", AudioManager.STREAM_SYSTEM to "system",
            )
            for ((s, n) in names) {
                line("Stream $n: ${runCatching { audio.getStreamVolume(s) }.getOrNull()} of ${if (Build.VERSION.SDK_INT >= 28) runCatching { audio.getStreamMinVolume(s) }.getOrNull() else 0}..${runCatching { audio.getStreamMaxVolume(s) }.getOrNull()}")
            }
            // A harmless live test: set music to its current value and see whether the call is accepted.
            val cur = runCatching { audio.getStreamVolume(AudioManager.STREAM_MUSIC) }.getOrNull()
            if (cur != null) {
                val res = runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, cur, 0) }
                line("Test write of music volume: ${if (res.isSuccess) "accepted" else "REFUSED " + res.exceptionOrNull()}")
            }
        }
        line("")
        line("== Saved events (survive the app being killed) ==")
        runCatching { java.io.File(context.filesDir, "events.log").readText() }.getOrNull()?.let { sb.append(it) }
        line("")
        line("== Why the system ended this app's earlier processes ==")
        sb.append(systemView(context))
        line("")
        line("== The app's own notes ==")
        synchronized(this) { lines.forEach { line(it) } }
        line("")
        line("== The app's log (warnings and errors) ==")
        sb.append(ownLog())
        return sb.toString()
    }

    /** With Shizuku: Android's own record of why this app's processes ended, and of the service. */
    private fun systemView(context: Context): String {
        if (!ShizukuShell.isReady()) return "(Shizuku is not running or not allowed, so the system's own record is not available. Start Shizuku and copy the report again.)\n"
        val pkg = context.packageName
        val sb = StringBuilder()
        val cmds = listOf(
            "dumpsys activity exit-info $pkg 2>&1 | head -60",
            "dumpsys accessibility 2>&1 | grep -i -E '$pkg|crashed|bound|enabled' | head -30",
            "logcat -d -b all -t 4000 2>&1 | grep -i -E 'accessibility.*($pkg|disabl|crash|unbind)|$pkg.*(died|kill|force|disabl)|(kill|force).*$pkg' | tail -40",
        )
        for (c in cmds) {
            sb.append("$ ").append(c.substringBefore(" 2>&1")).append('\n')
            runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }.onFailure { sb.append("failed: ${it.message}\n") }
        }
        return sb.toString()
    }

    private fun ownLog(): String = runCatching {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "300", "-v", "time", "*:W"))
        p.inputStream.bufferedReader().use { it.readText() }.ifBlank { "(empty)" }
    }.getOrElse { "(could not read the log: ${it.message})" }
}
