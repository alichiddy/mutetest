package com.newagedevs.gesturevolume.ui.activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.newagedevs.gesturevolume.BuildConfig
import com.newagedevs.gesturevolume.service.OverlayRuntime
import com.newagedevs.gesturevolume.utils.ReviewPrompter
import com.newagedevs.gesturevolume.ui.theme.GestureVolumeTheme
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.google.android.play.core.review.ReviewManagerFactory

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    companion object {
        /** Lets the happy moment's own feedback — a toast, a closing dialog — land before the sheet. */
        private const val REVIEW_SETTLE_DELAY_MS = 700L

        /** A navigation route to open on arrival, from the Deck's "manage" buttons. */
        const val EXTRA_ROUTE = "route"
    }

    /**
     * The route the Deck asked for, consumed once by the navigation graph.
     *
     * State rather than an argument to the graph, because the Activity is `singleTop` in spirit:
     * the Deck reuses a running instance, and the route then arrives through [onNewIntent] with
     * the composition already up.
     */
    val pendingRoute = mutableStateOf<String?>(null)

    private val viewModel: MainViewModel by viewModels()

    /**
     * True from the moment a Play update is known to be pending until this Activity goes away.
     *
     * Both Play dialogs are system-owned and neither yields to the other, so the only way to stop
     * them overlapping is to not ask for the second one.
     */
    private var updateFlowActive = false

    /**
     * True from launching Play's update screen until it reports back. See [startImmediateUpdate].
     *
     * Not [updateFlowActive], which stays true for the rest of the Activity's life so the review
     * keeps out of the way: guarding on that would also stop onResume putting the screen back
     * over an update the user left half-way through.
     */
    private var updateFlowShowing = false

    private val appUpdateManager by lazy { AppUpdateManagerFactory.create(this) }

    /**
     * Play's update screen, launched through the Activity Result API rather than the deprecated
     * requestCode overload. That one sent the update's IntentSender from inside the listener, and
     * a send that fails — the PendingIntent is FLAG_ONE_SHOT, so a second launch from the same
     * AppUpdateInfo, or one Play has already cancelled — threw SendIntentException out of it: the
     * app's top crash. Through the launcher a failed send comes back as RESULT_CANCELED.
     */
    private val updateFlowLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        // Gone, whichever way it went, so the next check may show it again. An immediate update
        // that installs restarts the app before this is reached.
        updateFlowShowing = false
        if (result.resultCode != RESULT_OK) {
            android.util.Log.w("MainActivity", "In-app update not completed: ${result.resultCode}")
        }
    }

    private val reviewRunnable = Runnable { launchReviewFlow() }
    private val reviewHandler = android.os.Handler(android.os.Looper.getMainLooper())

    // Bumped in onConfigurationChanged to trigger recomposition with new locale strings
    private val configVersion = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        // Before the first composition, not only from the collector below, which runs after it.
        // The home screen reads the manager once as it draws; after a rotation that read found the
        // manager built for the Activity just destroyed, whose loads all stop at its isDestroyed
        // check, and nothing redrew when the new one arrived.
        if (!viewModel.state.value.isProActivated) {
            viewModel.initializeAdsManager(this)
        }

        setContent {
            // Read configVersion so Compose recomposes when locale changes
            val version = configVersion.intValue
            val state by viewModel.state.collectAsState()
            val isDarkTheme = when (state.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }

            GestureVolumeTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainNavigation()
                }
            }
        }

        // Initialize IAP
        viewModel.initializeIAP(this)

        // Observe pro user status and initialize ads if needed
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                if (!state.isProActivated) {
                    viewModel.initializeAdsManager(this@MainActivity)
                }
            }
        }

        // Observe LiveData communicator
        viewModel.observeCommunicator(this)

        // Launch count feeds the review pacing; the old boolean is folded in once.
        viewModel.preference.incrementAppLaunchCount()
        viewModel.preference.migrateReviewState()
        // Clips saved by the retired clipboard history are deleted rather than left behind.
        viewModel.preference.removeRetiredClipboardHistory()

        // Check for App Updates
        checkForAppUpdate()

        pendingRoute.value = intent?.getStringExtra(EXTRA_ROUTE)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_ROUTE)?.let { pendingRoute.value = it }
    }

    override fun onStart() {
        super.onStart()
        // Before the service is started, not after. `onResume` writes this too, but the service is
        // launched from here — one callback earlier — so a service that comes up promptly draws
        // the bar in the gap between the two and the flag it consults is still false. Setting it
        // first closes that gap: whenever the bar is created from here on, the answer is already
        // recorded. See SharedPref.isAppInForeground.
        viewModel.preference.setAppInForeground(true)
        // Restart the service if the system killed it while the user still wants it running.
        // Doing this from the foreground sidesteps the Android 12+ background-start restrictions.
        viewModel.repairServiceIfNeeded(this)
        // Re-bind to running service if it exists (handles recents-clear scenario)
        viewModel.rebindToServiceIfRunning(this)
    }

    override fun onResume() {
        super.onResume()
        // Written here as well as sent, and before the send. The command only reaches a service
        // that is already up; the flag is what a service starting *after* this point reads, and a
        // cold start is exactly when the bar used to appear on top of the app.
        viewModel.preference.setAppInForeground(true)
        sendServiceCommand("hide")

        // Resume App Update if needed
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                startImmediateUpdate(appUpdateInfo)
            }
        }

        // No review check here any more. On resume it sampled whatever mood the user opened the
        // app in, which from their side looked random; it now waits for a happy moment instead.
        // See askForReviewIfHappy.
    }

    override fun onPause() {
        super.onPause()
        viewModel.preference.setAppInForeground(false)
        sendServiceCommand("show")
        // Nothing half-scheduled outlives the foreground: a prompt that fires as the user is
        // leaving lands on whatever they switched to.
        reviewHandler.removeCallbacks(reviewRunnable)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Bump version to force Compose to recompose with updated locale resources
        configVersion.intValue++
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.removeObserver()
    }

    private fun sendServiceCommand(action: String) {
        // Routed through the runtime, which sends it only while the foreground service is up.
        if (viewModel.preference.isRunning()) {
            OverlayRuntime.sendCommand(this, action)
        }
    }

    private fun checkForAppUpdate() {
        appUpdateManager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            ) {
                startImmediateUpdate(appUpdateInfo)
            }
        }
    }

    /**
     * Shows Play's immediate-update screen, at most once at a time.
     *
     * [appUpdateInfo] is always the one just fetched for this attempt, never one kept from an
     * earlier check: its PendingIntent is FLAG_ONE_SHOT, spent by the first launch. onCreate and
     * onResume each fetch their own and either can answer first, so the guard keeps a second
     * answer from launching over a screen that is already up.
     */
    private fun startImmediateUpdate(appUpdateInfo: AppUpdateInfo) {
        // The info arrives asynchronously, and the user may have left in the meantime.
        if (updateFlowShowing || isFinishing || isDestroyed) return
        updateFlowActive = true
        updateFlowShowing = try {
            appUpdateManager.startUpdateFlowForResult(
                appUpdateInfo,
                updateFlowLauncher,
                AppUpdateOptions.newBuilder(AppUpdateType.IMMEDIATE).build()
            )
        } catch (e: Exception) {
            // Whatever the cause, not worth a crash: the next launch checks again.
            android.util.Log.w("MainActivity", "Could not start the in-app update", e)
            false
        }
    }

    /**
     * Called at a happy moment (MainEffect.HappyMoment). Asks for a review if [ReviewPrompter]
     * says this user has earned it, and says whether it did, so the moment is not also spent on a
     * support nudge or an ad.
     */
    fun askForReviewIfHappy(): Boolean {
        if (isFinishing || isDestroyed) return false
        if (!ReviewPrompter.shouldAsk(
                preference = viewModel.preference,
                serviceRunning = viewModel.preference.isRunning(),
                updateFlowActive = updateFlowActive,
                versionCode = BuildConfig.VERSION_CODE
            )
        ) return false

        reviewHandler.removeCallbacks(reviewRunnable)
        reviewHandler.postDelayed(reviewRunnable, REVIEW_SETTLE_DELAY_MS)
        return true
    }

    private fun launchReviewFlow() {
        if (isFinishing || isDestroyed) return
        val versionCode = BuildConfig.VERSION_CODE

        val manager = ReviewManagerFactory.create(this)
        manager.requestReviewFlow().addOnCompleteListener { task ->
            if (!task.isSuccessful) return@addOnCompleteListener
            // Re-checked: requestReviewFlow is asynchronous, and the user may have left in the
            // meantime. launchReviewFlow on a dead Activity is the other way this looks broken.
            if (isFinishing || isDestroyed) return@addOnCompleteListener

            manager.launchReviewFlow(this, task.result).addOnCompleteListener {
                // Recorded whichever way it went. Play does not report whether the sheet was
                // actually shown — success here covers "displayed", "suppressed by quota" and
                // "already rated" alike — so this counts attempts, not impressions. That is
                // precisely why the budget is three and not one.
                viewModel.preference.recordReviewAsk(versionCode)
            }
        }
    }
}