package com.newagedevs.gesturevolume.flow

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The flow list and the step editor. Nothing from here stays in memory once it is closed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class FlowActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var names by remember { mutableStateOf(FlowStore.names(this)) }
                    var open by remember { mutableStateOf<String?>(null) }
                    var newName by remember { mutableStateOf(false) }
                    var info by remember { mutableStateOf("") }
                    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            info = "Importing…"
                            Thread {
                                info = try {
                                    val n = AutomateImporter.import(this@FlowActivity, uri)
                                    names = FlowStore.names(this@FlowActivity)
                                    "Imported $n flows. Texts that are not commands are kept as Notes."
                                } catch (e: Throwable) { "Import failed: ${e.message}" }
                            }.start()
                        }
                    }
                    if (open == null) {
                        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Flows (${names.size})", fontSize = 20.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { newName = true }) { Text("New flow") }
                                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import Automate backup") }
                            }
                            if (info.isNotEmpty()) Text(info, fontSize = 12.sp)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemsIndexed(names) { _, n ->
                                    Text(n, Modifier.fillMaxWidth().clickable { open = n }.padding(vertical = 10.dp))
                                }
                            }
                        }
                        if (newName) {
                            var t by remember { mutableStateOf("") }
                            AlertDialog(
                                onDismissRequest = { newName = false },
                                title = { Text("Flow name") },
                                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                                confirmButton = { TextButton(onClick = {
                                    if (t.isNotBlank()) { FlowStore.save(this, t.trim(), emptyList()); names = FlowStore.names(this); open = t.trim() }
                                    newName = false
                                }) { Text("OK") } },
                            )
                        }
                    } else {
                        Editor(open!!) { names = FlowStore.names(this); open = null }
                    }
                }
            }
        }
    }

    @Composable
    private fun Editor(name: String, close: () -> Unit) {
        val steps = remember { mutableStateListOf<Step>().also { it.addAll(FlowStore.load(this, name)) } }
        var edit by remember { mutableStateOf<Int?>(null) }   // index being edited, steps.size = new
        var draft by remember { mutableStateOf(Step(Step.SHELL)) }
        var output by remember { mutableStateOf("") }
        var running by remember { mutableStateOf(false) }
        fun save() = FlowStore.save(this, name, steps.toList())
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name, fontSize = 20.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { draft = Step(Step.SHELL); edit = steps.size }) { Text("Add step") }
                Button(enabled = !running, onClick = {
                    save(); running = true; output = ""
                    Thread {
                        FlowRunner.run(this@FlowActivity, name, { l -> output += l + "\n" }, { })
                        running = false
                    }.start()
                }) { Text("Run") }
                OutlinedButton(onClick = { FlowRunner.stop() }) { Text("Stop") }
                OutlinedButton(onClick = { save(); close() }) { Text("Save & close") }
                OutlinedButton(onClick = { FlowStore.delete(this@FlowActivity, name); close() }) { Text("Delete") }
            }
            val indent = IntArray(steps.size).also { arr ->
                var d = 0
                steps.forEachIndexed { i, s ->
                    if (s.type == Step.END || s.type == Step.ELSE) d = (d - 1).coerceAtLeast(0)
                    arr[i] = d
                    if (s.type == Step.IF || s.type == Step.REPEAT || s.type == Step.ELSE) d++
                }
            }
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(steps) { i, s ->
                    val pad = indent.getOrElse(i) { 0 }
                    Row(Modifier.fillMaxWidth().clickable { draft = s; edit = i }.padding(start = (pad * 16).dp, top = 6.dp, bottom = 6.dp)) {
                        Text("${i + 1}. ${s.describe()}", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    }
                }
            }
            if (output.isNotEmpty()) Text(output.takeLast(1500), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        val idx = edit
        if (idx != null) {
            var type by remember(idx) { mutableStateOf(draft.type) }
            var a by remember(idx) { mutableStateOf(draft.a) }
            var b by remember(idx) { mutableStateOf(draft.b) }
            var c by remember(idx) { mutableStateOf(draft.c) }
            AlertDialog(
                onDismissRequest = { edit = null },
                title = { Text(if (idx < steps.size) "Edit step" else "New step") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Step.TYPES.forEach { t ->
                                if (t == type) Button(onClick = {}) { Text(t) } else OutlinedButton(onClick = { type = t }) { Text(t) }
                            }
                        }
                        val (la, lb, lc) = labels(type)
                        if (la.isNotEmpty()) OutlinedTextField(a, { a = it }, label = { Text(la) })
                        if (lb.isNotEmpty()) OutlinedTextField(b, { b = it }, label = { Text(lb) })
                        if (lc.isNotEmpty()) OutlinedTextField(c, { c = it }, label = { Text(lc) })
                    }
                },
                confirmButton = { TextButton(onClick = {
                    val s = Step(type, a, b, c)
                    if (idx < steps.size) steps[idx] = s else steps.add(s)
                    // A new if or repeat gets its end straight away.
                    if (idx >= steps.size - 1 && (type == Step.IF || type == Step.REPEAT) && steps.count { it.type == Step.END } < steps.count { it.type == Step.IF || it.type == Step.REPEAT }) steps.add(Step(Step.END))
                    save(); edit = null
                }) { Text("OK") } },
                dismissButton = { Row {
                    if (idx < steps.size) {
                        TextButton(onClick = { steps.removeAt(idx); save(); edit = null }) { Text("Delete") }
                        TextButton(onClick = { if (idx > 0) { steps.add(idx - 1, steps.removeAt(idx)); save() }; edit = null }) { Text("Up") }
                        TextButton(onClick = { if (idx < steps.size - 1) { steps.add(idx + 1, steps.removeAt(idx)); save() }; edit = null }) { Text("Down") }
                    }
                } },
            )
        }
    }

    private fun labels(type: String): Triple<String, String, String> = when (type) {
        Step.SHELL -> Triple("Command", "Put the output in variable (default out)", "")
        Step.WAIT -> Triple("Milliseconds", "", "")
        Step.MESSAGE -> Triple("Text", "", "")
        Step.LAUNCH -> Triple("Package name", "", "")
        Step.INTENT -> Triple("Intent URI", "", "")
        Step.SET -> Triple("Variable", "Value", "")
        Step.IF -> Triple("Left (e.g. {out})", "Operator: = != contains > <", "Right")
        Step.REPEAT -> Triple("Times", "", "")
        Step.HTTP -> Triple("URL", "Method (GET/POST)", "Put the answer in variable")
        Step.RUN -> Triple("Flow name", "", "")
        else -> Triple("", "", "")
    }
}
