package com.newagedevs.gesturevolume.strip

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.floor

/**
 * The shortcut strip: a plain grid of text cells, drawn straight to the canvas.
 *
 * Deliberately light: no icons, no images, no animation, no Compose. Its whole memory is the label
 * list and four paints, and the window holding it is gone the moment the finger lifts.
 *
 * It takes no touches of its own. The bar's window keeps the gesture and forwards the finger's
 * screen position to [setFinger]; this finds the cell under it and lights it.
 */
class StripView(
    context: Context,
    private val items: List<ShortcutStore.Item>,
    val cellPx: Int,
    private val columns: Int = ShortcutStore.COLUMNS,
) : View(context) {

    private val rows = (items.size + columns - 1) / columns
    private val gapPx = (cellPx * 0.08f).coerceAtLeast(2f)

    /** Where this view's top-left corner sits on the screen, for turning finger positions into cells. */
    private var originX = 0f
    private var originY = 0f

    /** The cell under the finger, or -1. */
    var hot = -1
        private set

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1F8A8A.toInt() }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A4A4C.toInt() }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = cellPx * 0.24f
    }
    private val rect = RectF()

    /** Width and height of the whole panel in pixels. */
    val panelWidthPx: Int get() = (columns * cellPx + gapPx * (columns + 1)).toInt()
    val panelHeightPx: Int get() = (rows * cellPx + gapPx * (rows + 1)).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelWidthPx, panelHeightPx)
    }

    /** Tells the view where it is on screen. Called once, when its window is placed. */
    fun setScreenOrigin(x: Float, y: Float) {
        originX = x
        originY = y
    }

    /** The cell at a screen position, or -1 for a gap, the margin or outside the panel. */
    fun cellAt(rawX: Float, rawY: Float): Int {
        val x = rawX - originX - gapPx
        val y = rawY - originY - gapPx
        if (x < 0f || y < 0f) return -1
        val step = cellPx + gapPx
        val col = floor(x / step).toInt()
        val row = floor(y / step).toInt()
        if (col !in 0 until columns || row !in 0 until rows) return -1
        // The gap after a cell belongs to nothing, so a finger crossing it does not flicker the light.
        if (x - col * step > cellPx || y - row * step > cellPx) return hot.takeIf { it >= 0 && it == row * columns + col } ?: -1
        val index = row * columns + col
        return if (index < items.size) index else -1
    }

    /** Moves the light to the cell under the finger. */
    fun setFinger(rawX: Float, rawY: Float) {
        val next = cellAt(rawX, rawY)
        if (next == hot) return
        hot = next
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, panelPaint)
        val radius = cellPx * 0.22f
        for (i in items.indices) {
            val col = i % columns
            val row = i / columns
            val left = gapPx + col * (cellPx + gapPx)
            val top = gapPx + row * (cellPx + gapPx)
            rect.set(left, top, left + cellPx, top + cellPx)
            val item = items[i]
            val runnable = item.flow > 0 || item.pkg != null
            canvas.drawRoundRect(
                rect, radius, radius,
                when {
                    i == hot -> hotPaint
                    runnable -> cellPaint
                    else -> emptyPaint
                }
            )
            drawLabel(canvas, item.label, rect, if (i == hot) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        }
    }

    private fun drawLabel(canvas: Canvas, label: String, box: RectF, color: Int) {
        textPaint.color = color
        val base = cellPx * 0.24f
        textPaint.textSize = base
        val room = box.width() * 0.9f
        val wide = textPaint.measureText(label)
        if (wide > room) textPaint.textSize = base * room / wide
        val y = box.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(label, box.centerX(), y, textPaint)
    }
}
