package com.newagedevs.gesturevolume.strip

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.floor

/**
 * The shortcut strip: a grid of cells drawn straight to the canvas.
 *
 * An icon costs nothing to keep: an emoji is a few bytes of text drawn by the system font, and an
 * app's icon is the drawable the package manager already holds, drawn in place and dropped with
 * this view when the finger lifts. No bitmaps, no animation, no Compose.
 *
 * It takes no touches of its own. The bar's window keeps the gesture and forwards the finger's
 * screen position to [setFinger]; this finds the cell under it and lights it.
 */
class StripView(
    context: Context,
    val items: List<StripItem>,
    val cellPx: Int,
    private val columns: Int,
    private val showLabels: Boolean,
) : View(context) {

    private val rows = ((items.size + columns - 1) / columns).coerceAtLeast(1)
    private val gapPx = (cellPx * 0.08f).coerceAtLeast(2f)

    private var originX = 0f
    private var originY = 0f

    /** The cell under the finger, or -1. */
    var hot = -1
        private set

    private val appIcons = HashMap<String, Drawable?>()

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1F8A8A.toInt() }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3638.toInt() }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()

    val panelWidthPx: Int get() = (columns * cellPx + gapPx * (columns + 1)).toInt()
    val panelHeightPx: Int get() = (rows * cellPx + gapPx * (rows + 1)).toInt()

    init {
        val pm = context.packageManager
        for (item in items) {
            val pkg = item.appIconPackage ?: continue
            if (pkg !in appIcons) appIcons[pkg] = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelWidthPx, panelHeightPx)
    }

    fun setScreenOrigin(x: Float, y: Float) {
        originX = x
        originY = y
    }

    /** The cell at a screen position, or -1 for a gap, the margin or outside the panel. */
    fun cellAt(rawX: Float, rawY: Float): Int {
        val x = rawX - originX - gapPx
        val y = rawY - originY - gapPx
        if (x < 0f || y < 0f) return -1
        val step = cellPx + gapPx
        val col = floor(x / step).toInt()
        val row = floor(y / step).toInt()
        if (col !in 0 until columns || row !in 0 until rows) return -1
        if (x - col * step > cellPx || y - row * step > cellPx) {
            return hot.takeIf { it >= 0 && it == row * columns + col } ?: -1
        }
        val index = row * columns + col
        return if (index < items.size) index else -1
    }

    fun setFinger(rawX: Float, rawY: Float) {
        val next = cellAt(rawX, rawY)
        if (next == hot) return
        hot = next
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, panelPaint)
        val radius = cellPx * 0.22f
        for (i in items.indices) {
            val item = items[i]
            val col = i % columns
            val row = i / columns
            val left = gapPx + col * (cellPx + gapPx)
            val top = gapPx + row * (cellPx + gapPx)
            rect.set(left, top, left + cellPx, top + cellPx)
            val blank = item.action.isEmpty() && item.label.isEmpty() && item.icon.isEmpty()
            if (blank) continue
            canvas.drawRoundRect(
                rect, radius, radius,
                when {
                    i == hot -> hotPaint
                    item.action.isNotEmpty() -> cellPaint
                    else -> emptyPaint
                }
            )
            val ink = if (i == hot) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            drawItem(canvas, item, rect, ink)
        }
    }

    private fun drawItem(canvas: Canvas, item: StripItem, box: RectF, ink: Int) {
        val appIcon = item.appIconPackage?.let { appIcons[it] }
        val hasIcon = appIcon != null || (item.icon.isNotEmpty() && item.appIconPackage == null)
        if (!hasIcon) {
            drawLabel(canvas, item.label, box, box.centerY(), 0.24f, ink)
            return
        }
        val labelled = showLabels && item.label.isNotEmpty()
        val iconBox = if (labelled) box.height() * 0.66f else box.height() * 0.78f
        val cy = if (labelled) box.top + box.height() * 0.38f else box.centerY()
        if (appIcon != null) {
            val half = (iconBox / 2f).toInt()
            appIcon.setBounds(
                (box.centerX() - half).toInt(), (cy - half).toInt(),
                (box.centerX() + half).toInt(), (cy + half).toInt()
            )
            appIcon.draw(canvas)
        } else {
            textPaint.color = 0xFFFFFFFF.toInt()
            textPaint.textSize = iconBox * 0.86f
            val y = cy - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(item.icon, box.centerX(), y, textPaint)
        }
        if (labelled) drawLabel(canvas, item.label, box, box.top + box.height() * 0.86f, 0.17f, ink)
    }

    private fun drawLabel(canvas: Canvas, label: String, box: RectF, centerY: Float, scale: Float, color: Int) {
        if (label.isEmpty()) return
        textPaint.color = color
        val base = cellPx * scale
        textPaint.textSize = base
        val room = box.width() * 0.92f
        val wide = textPaint.measureText(label)
        if (wide > room) textPaint.textSize = base * room / wide
        val y = centerY - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(label, box.centerX(), y, textPaint)
    }
}
