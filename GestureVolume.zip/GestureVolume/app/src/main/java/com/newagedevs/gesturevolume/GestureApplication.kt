package com.newagedevs.gesturevolume

import android.app.Application
import android.provider.Settings
import com.newagedevs.gesturevolume.utils.DiagLog
import com.newagedevs.gesturevolume.utils.ShizukuShell
import dagger.hilt.android.HiltAndroidApp

/** The application class. Ads, billing and the Play Store prompts are gone from this build. */
@HiltAndroidApp
class GestureApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DiagLog.processStarted(this)
        // If the system switched the accessibility service off, switch it back on through Shizuku.
        // One short thread, only when it is off, and only when Shizuku is there.
        val on = runCatching {
            Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)?.contains(packageName) == true
        }.getOrDefault(true)
        val wanted = getSharedPreferences("MyPrefs", MODE_PRIVATE).getBoolean("autoA11y", false)
        if (!on && wanted) Thread {
            repeat(5) {
                if (ShizukuShell.isReady()) {
                    runCatching { ShizukuShell.run(ShizukuShell.enableAccessibilityScript(packageName)) { } }
                    DiagLog.persist(this, "accessibility was off; switched on through Shizuku")
                    return@Thread
                }
                Thread.sleep(1500)
            }
            DiagLog.persist(this, "accessibility was off; Shizuku not ready to switch it on")
        }.start()
    }
}
