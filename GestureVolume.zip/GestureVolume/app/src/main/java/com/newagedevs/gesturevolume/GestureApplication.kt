package com.newagedevs.gesturevolume

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/** The application class. Ads, billing and the Play Store prompts are gone from this build. */
@HiltAndroidApp
class GestureApplication : Application()
