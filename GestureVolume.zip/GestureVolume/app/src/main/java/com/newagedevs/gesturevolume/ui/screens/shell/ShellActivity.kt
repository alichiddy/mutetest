package com.newagedevs.gesturevolume.ui.screens.shell

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.utils.ShizukuShell

/** A plain shell: type a command, watch its output as it appears. Shizuku's privilege when allowed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class ShellActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var command by remember { mutableStateOf("id") }
                    var output by remember { mutableStateOf("") }   // the last run
                    var history by remember { mutableStateOf("") }  // every run this time
                    var lastCommand by remember { mutableStateOf("") }
                    var running by remember { mutableStateOf(false) }
                    var mode by remember { mutableStateOf(modeText()) }
                    val scroll = rememberScrollState()

                    fun launch(title: String, block: () -> Unit) {
                        if (running) return
                        running = true
                        lastCommand = title
                        output = ""
                        Thread {
                            try { block() } catch (e: Throwable) { output += "ERROR: ${e.javaClass.simpleName}: ${e.message}" }
                            history += "$ $title\n$output\n\n"
                            running = false
                        }.start()
                    }

                    Column(
                        Modifier.fillMaxSize().statusBarsPadding().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("Shell  -  $mode", style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = command, onValueChange = { command = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Command") },
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = !running, onClick = {
                                launch(command) {
                                    val code = ShizukuShell.run(command) { line -> output += line + "\n" }
                                    output += "\n[exit $code]"
                                }
                            }) { Text("Run") }
                            OutlinedButton(onClick = {
                                ShizukuShell.requestPermission { mode = modeText() }
                                mode = modeText()
                            }) { Text("Allow Shizuku") }
                            OutlinedButton(enabled = !running, onClick = {
                                launch("grant permissions") {
                                    val code = ShizukuShell.grantAll(this@ShellActivity) { line -> output += line + "\n" }
                                    output += "\n[exit $code]"
                                }
                            }) { Text("Grant permissions") }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { copy(output, "Last output copied") }) { Text("Copy last output") }
                            OutlinedButton(onClick = { copy(history + output.takeIf { running }.orEmpty(), "All output copied") }) { Text("Copy all output") }
                            OutlinedButton(onClick = { saveTxt(lastCommand.ifBlank { command }, output) }) { Text("Save as txt") }
                        }
                        Text(
                            output,
                            modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(scroll),
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                        )
                    }
                }
            }
        }
    }

    private fun modeText(): String = when {
        ShizukuShell.isReady() -> "Shizuku (privileged)"
        ShizukuShell.isRunning() -> "Shizuku running, not allowed yet"
        else -> "normal (Shizuku is not running)"
    }

    private fun copy(text: String, done: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shell", text))
        Toast.makeText(this, done, Toast.LENGTH_SHORT).show()
    }

    /** Downloads/<first 15 characters of the command>.txt */
    private fun saveTxt(command: String, text: String) {
        val base = command.trim().take(15).replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "output" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "$base.txt")
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val ok = runCatching {
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Saved in Downloads as $base.txt" else "Could not save", Toast.LENGTH_SHORT).show()
    }
}
