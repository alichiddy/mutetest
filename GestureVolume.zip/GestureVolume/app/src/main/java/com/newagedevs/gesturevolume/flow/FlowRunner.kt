package com.newagedevs.gesturevolume.flow

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.net.HttpURLConnection
import java.net.URL

/**
 * Runs a flow on its own thread and is gone when it ends. [log] gets one line per thing that
 * happens, [message] is where a Message step shows its text.
 */
object FlowRunner {
    @Volatile private var stopAll = false

    fun stop() { stopAll = true }

    fun run(
        context: Context, name: String, log: (String) -> Unit,
        message: (String) -> Unit = {}, vars: MutableMap<String, String> = HashMap(), depth: Int = 0,
    ) {
        if (depth == 0) stopAll = false
        if (depth > 8) { log("Too many flows inside flows."); return }
        val steps = FlowStore.load(context, name)
        if (steps.isEmpty()) { log("Flow '$name' is empty or missing."); return }
        // For each if/else/repeat, where its else and its end are.
        val end = IntArray(steps.size) { -1 }
        val els = IntArray(steps.size) { -1 }
        val open = ArrayDeque<Int>()
        steps.forEachIndexed { i, s ->
            when (s.type) {
                Step.IF, Step.REPEAT -> open.addLast(i)
                Step.ELSE -> open.lastOrNull()?.let { els[it] = i }
                Step.END -> open.removeLastOrNull()?.let { end[it] = i; end[i] = it }
            }
        }
        val counters = HashMap<Int, Int>()
        fun sub(t: String): String {
            var r = t
            vars.forEach { (k, v) -> r = r.replace("{$k}", v) }
            return r
        }
        var i = 0
        var guard = 0
        while (i < steps.size && !stopAll) {
            if (++guard > 100_000) { log("Stopped: too many steps."); return }
            val s = steps[i]
            try {
                when (s.type) {
                    Step.SHELL -> {
                        val out = StringBuilder()
                        val code = ShizukuShell.run(sub(s.a)) { line -> out.append(line).append('\n'); log(line) }
                        vars["code"] = code.toString()
                        vars[s.b.ifEmpty { "out" }] = out.toString().trim()
                    }
                    Step.WAIT -> Thread.sleep(sub(s.a).toLongOrNull() ?: 0L)
                    Step.MESSAGE -> { message(sub(s.a)); log(sub(s.a)) }
                    Step.LAUNCH -> context.packageManager.getLaunchIntentForPackage(sub(s.a))
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { context.startActivity(it) }
                        ?: log("App not found: ${s.a}")
                    Step.INTENT -> context.startActivity(
                        Intent.parseUri(sub(s.a), Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    Step.SET -> vars[s.a] = sub(s.b)
                    Step.IF -> if (!test(sub(s.a), s.b, sub(s.c))) {
                        // Jump to the else branch, or past the end.
                        i = if (els[i] >= 0) els[i] else end[i]
                    }
                    Step.ELSE -> i = findEndOfElse(steps, i)
                    Step.REPEAT -> {
                        val n = counters.getOrPut(i) { sub(s.a).toIntOrNull() ?: 1 }
                        if (n <= 0) { counters.remove(i); i = end[i] } else counters[i] = n - 1
                    }
                    Step.END -> {
                        val head = end[i]
                        if (head >= 0 && steps[head].type == Step.REPEAT && (counters[head] ?: 0) > 0) i = head - 1
                        else if (head >= 0 && steps[head].type == Step.REPEAT) counters.remove(head)
                    }
                    Step.HTTP -> {
                        val c = URL(sub(s.a)).openConnection() as HttpURLConnection
                        c.requestMethod = s.b.ifEmpty { "GET" }
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        val text = (if (c.responseCode < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                        vars["status"] = c.responseCode.toString()
                        vars[s.c.ifEmpty { "answer" }] = text
                        c.disconnect()
                    }
                    Step.RUN -> run(context, sub(s.a), log, message, vars, depth + 1)
                    Step.STOP -> return
                    Step.NOTE -> {}
                }
            } catch (e: Throwable) {
                log("Step ${i + 1} failed: ${e.javaClass.simpleName}: ${e.message}")
                return
            }
            i++
        }
    }

    /** After the "then" branch reaches an else, run on past the matching end. */
    private fun findEndOfElse(steps: List<Step>, from: Int): Int {
        var depth = 0
        for (j in from + 1 until steps.size) {
            when (steps[j].type) {
                Step.IF, Step.REPEAT -> depth++
                Step.END -> if (depth == 0) return j else depth--
            }
        }
        return steps.size
    }

    private fun test(left: String, op: String, right: String): Boolean {
        val l = left.toDoubleOrNull(); val r = right.toDoubleOrNull()
        return when (op) {
            "=" -> if (l != null && r != null) l == r else left == right
            "!=" -> if (l != null && r != null) l != r else left != right
            "contains" -> left.contains(right)
            ">" -> l != null && r != null && l > r
            "<" -> l != null && r != null && l < r
            else -> false
        }
    }
}
