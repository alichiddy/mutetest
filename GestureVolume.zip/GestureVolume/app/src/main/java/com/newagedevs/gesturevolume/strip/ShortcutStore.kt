package com.newagedevs.gesturevolume.strip

/**
 * The shortcut strip's contents, in the order and eight-column layout of the Easy Slider strip it
 * replaces. Built in, because this is a private build: there is nothing to import or edit.
 *
 * An item is an Automate flow (a statement of a flow, started through Automate's own START_FLOW
 * intent), or an app by package name, or, for the two whose launch intent is not known yet, only a
 * label.
 */
object ShortcutStore {

    const val COLUMNS = 8

    const val AUTOMATE_START_FLOW = "com.llamalab.automate.intent.action.START_FLOW"

    data class Item(
        val label: String,
        val flow: Int = 0,
        val statement: Int = 0,
        val pkg: String? = null,
    ) {
        /** The content URI Automate gave the flow's shortcut, or null for an app or an empty slot. */
        val flowUri: String?
            get() = if (flow > 0) "content://com.llamalab.automate.provider/flows/$flow/statements/$statement" else null
    }

    val all: List<Item> = listOf(
        Item("QShr", flow = 468, statement = 233),
        Item("GRNT", flow = 468, statement = 592),
        Item("RVOK", flow = 468, statement = 600),
        Item("EsySL", flow = 468, statement = 479),
        Item("Bhsti", flow = 491, statement = 63),
        Item("DbgOff", flow = 468, statement = 165),
        Item("AMXSH", flow = 138, statement = 78),
        Item("HdDev", flow = 468, statement = 170),
        Item("ShwDV", flow = 468, statement = 172),
        Item("2GOnly", flow = 468, statement = 495),
        Item("2G/3G", flow = 468, statement = 145),
        Item("4GOnly", flow = 468, statement = 349),
        Item("5GOnly", flow = 468, statement = 339),
        Item("SOD", flow = 335, statement = 53),
        Item("AMRsh", flow = 138, statement = 71),
        Item("KBRG#", flow = 486, statement = 2),
        Item("KBRG$", flow = 486, statement = 18),
        Item("1.0", flow = 468, statement = 384),
        Item("123", flow = 468, statement = 372),
        Item("CHKDT", flow = 468, statement = 390),
        Item("TMP", flow = 609, statement = 1),
        Item("WShr", flow = 468, statement = 369),
        Item("V2Ray", flow = 468, statement = 266),
        Item("WifiOn", flow = 468, statement = 520),
        Item("WFV2R", flow = 468, statement = 489),
        Item("Hotsp", flow = 468, statement = 137),
        Item("4G+HS", flow = 468, statement = 43),
        Item("Loc", flow = 468, statement = 229),
        Item("BT", flow = 468, statement = 64),
        Item("Airpl", flow = 468, statement = 151),
        Item("Torch", flow = 2, statement = 1),
        Item("MaxVol", flow = 292, statement = 1),
        Item("Wifi", flow = 483, statement = 5),
        Item("WiTgl", flow = 468, statement = 5),
        Item("V2Win", flow = 468, statement = 248),
        Item("4GS2", flow = 468, statement = 12),
        Item("V2+DT", flow = 468, statement = 321),
        Item("DSave", flow = 468, statement = 141),
        Item("Awake", flow = 484, statement = 85),
        Item("Brgt", flow = 468, statement = 214),
        Item("TRMNL", flow = 587, statement = 1),
        Item("LOGKL", flow = 468, statement = 488),
        Item("ALOF", flow = 468, statement = 236),
        Item("BgShl", flow = 468, statement = 362),
        Item("BGSh2", flow = 468, statement = 740),
        Item("BGSh3", flow = 468, statement = 781),
        Item("BGRsh", flow = 468, statement = 727),
        Item("PGDWN", flow = 468, statement = 402),
        Item("v2ray", pkg = "com.v2ray.ang"),
        Item("v2rayF", pkg = "com.v2ray.ang.fdroid"),
        Item("FPKG", flow = 468, statement = 609),
        Item("RSLT", flow = 483, statement = 16),
        Item("Calc", pkg = "pnapp.pncalc.full"),
        Item("CopyM"),
        Item("Power", flow = 468, statement = 615),
        Item("ScrSh", flow = 468, statement = 680),
        Item("UPLD", flow = 621, statement = 1),
        Item("GUPLD", flow = 621, statement = 27),
        Item("FHide", flow = 468, statement = 682),
        Item("FIUsr", flow = 468, statement = 633),
        Item("AppInf", flow = 468, statement = 687),
        Item("Speed", flow = 468, statement = 685),
        Item("PSTE", flow = 468, statement = 467),
        Item("Eitaa", pkg = "ir.eitaa.messenger"),
        Item("Resal", pkg = "mob.banking.android.resalat"),
        Item("HSS", pkg = "hotspotshield.android.vpn"),
        Item("HSSt", flow = 468, statement = 835),
        Item("HSS2"),
        Item("LNS", flow = 468, statement = 804),
        Item("صنمی", flow = 292, statement = 14),
        Item("Auto", pkg = "com.llamalab.automate"),
        Item("QR", flow = 468, statement = 838),
        Item("WGT", flow = 468, statement = 842),
    )
}
