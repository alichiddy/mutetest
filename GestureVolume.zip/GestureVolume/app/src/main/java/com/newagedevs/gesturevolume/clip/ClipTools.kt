package com.newagedevs.gesturevolume.clip

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent

/**
 * Copy options: turn Persian/Arabic digits into 0-9 in whatever is copied, and say what was copied
 * (on the bar, as a toast or as a notification). Listening happens only while an option is on.
 */
object ClipTools {
    const val FIX = "clipFixDigits"
    const val BAR = "clipBar"
    const val TOAST = "clipToast"
    const val NOTICE = "clipNotice"
    const val BAR_MS = "clipBarMs"          // how long the bar message stays, ms
    const val NOTICE_MS = "clipNoticeMs"    // how long the notification stays, ms
    const val TOAST_LONG = "clipToastLong"  // Android's long toast instead of the short one
    const val SHOW_TEXT = "clipShowText"
    private const val PREFS = "MyPrefs"

    private var lastSet: String? = null
    private var lastHandled: String? = null
    private var lastHandledAt = 0L

    fun on(c: Context): Boolean {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return p.getBoolean(FIX, false) || p.getBoolean(BAR, false) || p.getBoolean(TOAST, false) || p.getBoolean(NOTICE, false)
    }

    fun convertDigits(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(
            when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')   // Persian
                in '٠'..'٩' -> '0' + (ch - '٠')   // Arabic-Indic
                '٫' -> '.'                                  // Arabic decimal separator
                '٬' -> ','                                  // Arabic thousands separator
                else -> ch
            }
        )
        return sb.toString()
    }

    /** Reads the clipboard now, if Android lets this app; returns false when it refused. */
    fun readAndHandle(c: Context): Boolean {
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = runCatching { cm.primaryClip }.getOrNull()
        if (clip == null) { com.newagedevs.gesturevolume.utils.DiagLog.note("clip read refused"); return false }
        if (clip.itemCount == 0) return false
        if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return true
        val text = runCatching { clip.getItemAt(0).coerceToText(c)?.toString() }.getOrNull() ?: return true
        handle(c, cm, text)
        return true
    }

    private fun handle(c: Context, cm: ClipboardManager, text: String) {
        if (text == lastSet || (text == lastHandled && System.currentTimeMillis() - lastHandledAt < 400)) { com.newagedevs.gesturevolume.utils.DiagLog.note("clip: same text as before, skipped"); return }
        lastHandled = text; lastHandledAt = System.currentTimeMillis()
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var shown = text
        if (p.getBoolean(FIX, false)) {
            val fixed = convertDigits(text)
            if (fixed != text) {
                lastSet = fixed
                runCatching { cm.setPrimaryClip(ClipData.newPlainText("A", fixed)) }
                shown = fixed
            }
        }
        feedback(c, p, shown)
    }

    /** The keyboard (LeanType A) says something was copied: show it as the Copy options say. */
    fun announce(c: Context, text: String) {
        // Copying the same text again shows the message again; only a double event is dropped.
        val now = System.currentTimeMillis()
        if (text == lastHandled && now - lastHandledAt < 400) return
        lastHandled = text; lastHandledAt = now
        feedback(c, c.getSharedPreferences(PREFS, Context.MODE_PRIVATE), text)
    }

    /** Another app (Automate, say) asks to show a line: on the bar unless the Copy options choose other places too. */
    fun showFor(c: Context, message: String?, text: String?, convert: Boolean?) {
        val p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val line = message ?: text?.let { t ->
            val shown = if (convert ?: p.getBoolean(FIX, false)) convertDigits(t) else t
            (if (p.getBoolean(SHOW_TEXT, true)) "Copied: " else "Copied") .let { if (it.endsWith(": ")) it + shown.take(120) else it }
        } ?: return
        val bar = p.getBoolean(BAR, false); val toast = p.getBoolean(TOAST, false); val notice = p.getBoolean(NOTICE, false)
        if (bar || !(toast || notice)) com.newagedevs.gesturevolume.service.OverlayRuntime.activeController?.showIndicatorMessage(line, p.getInt(BAR_MS, 1500).toLong().coerceIn(200L, 60000L))
        if (toast) runCatching {
            android.widget.Toast.makeText(c, line, if (p.getBoolean(TOAST_LONG, false)) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT).show()
        }
        if (notice) runCatching {
            val nm = c.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("copied", "Copied text", android.app.NotificationManager.IMPORTANCE_LOW))
            nm.notify(7314, android.app.Notification.Builder(c, "copied")
                .setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle(line.take(60)).setTimeoutAfter(p.getInt(NOTICE_MS, 4000).toLong().coerceIn(500L, 600000L)).setAutoCancel(true).build())
        }
    }

    private fun feedback(c: Context, p: android.content.SharedPreferences, shown: String) {
        val text = shown
        val bar = p.getBoolean(BAR, false); val toast = p.getBoolean(TOAST, false); val notice = p.getBoolean(NOTICE, false)
        com.newagedevs.gesturevolume.utils.DiagLog.note("clip shown len=${text.length} bar=$bar toast=$toast notice=$notice")
        if (!bar && !toast && !notice) return
        val msg = if (p.getBoolean(SHOW_TEXT, false)) "Copied: " + shown.take(120) else "Copied"
        if (bar) com.newagedevs.gesturevolume.service.OverlayRuntime.activeController?.showIndicatorMessage(msg, p.getInt(BAR_MS, 1500).toLong().coerceIn(200L, 60000L))
        if (toast) runCatching {
            android.widget.Toast.makeText(c, msg, if (p.getBoolean(TOAST_LONG, false)) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT).show()
        }
        if (notice) runCatching {
            val nm = c.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("copied", "Copied text", android.app.NotificationManager.IMPORTANCE_LOW))
            nm.notify(7314, android.app.Notification.Builder(c, "copied")
                .setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle(msg.take(60)).setTimeoutAfter(p.getInt(NOTICE_MS, 4000).toLong().coerceIn(500L, 600000L)).setAutoCancel(true).build())
        }
    }

    /** Android hides the clipboard from background apps; a see-through activity for an instant can read it. */
    fun readViaWindow(c: Context, force: Boolean = false) {
        if (force) lastHandled = null
        com.newagedevs.gesturevolume.utils.DiagLog.note("clip: opening the invisible reader")
        runCatching {
            c.startActivity(Intent(c, ClipReadActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }.onFailure { com.newagedevs.gesturevolume.utils.DiagLog.e("clip reader", it) }
    }
}
