package com.newagedevs.gesturevolume.strip

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * The app's preferences as JSON, in two independent parts: the **scripts** (the strip: its
 * shortcuts, flows and layout, one key) and the **settings** (everything else). A backup, a
 * restore or an APK can carry either part or both, so scripts can differ between phones while the
 * settings stay the same.
 *
 * An APK made with settings holds assets/settings_default.json; one made with scripts holds
 * assets/strip_default.json. A fresh install applies what it carries before anything reads them.
 */
object SettingsBackup {

    const val BAKED_ASSET = "settings_default.json"

    /** The one preference that holds the strip. */
    const val STRIP_KEY = "stripConfigV1"

    fun toJson(prefs: SharedPreferences, settings: Boolean, scripts: Boolean): String {
        val p = JSONObject()
        for ((key, value) in prefs.all) {
            val isStrip = key == STRIP_KEY
            if ((isStrip && !scripts) || (!isStrip && !settings)) continue
            val e = JSONObject()
            when (value) {
                is Boolean -> e.put("t", "b").put("v", value)
                is Int -> e.put("t", "i").put("v", value)
                is Long -> e.put("t", "l").put("v", value)
                is Float -> e.put("t", "f").put("v", value.toDouble())
                is String -> e.put("t", "s").put("v", value)
                is Set<*> -> e.put("t", "S").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            p.put(key, e)
        }
        return JSONObject().put("format", 1).put("prefs", p).toString()
    }

    /**
     * Applies the chosen part of [json]. Settings replace every setting except the strip; scripts
     * replace only the strip. Returns how many preferences were applied (0 if the file held none
     * of the chosen part), or -1 if it is not a backup.
     */
    fun apply(prefs: SharedPreferences, json: String, settings: Boolean, scripts: Boolean): Int {
        val p = runCatching { JSONObject(json).getJSONObject("prefs") }.getOrNull() ?: return -1
        val incomingSettings = p.keys().asSequence().any { it != STRIP_KEY }
        val edit = prefs.edit()
        if (settings && incomingSettings) {
            for (key in prefs.all.keys) if (key != STRIP_KEY) edit.remove(key)
        }
        var n = 0
        val keys = p.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val isStrip = key == STRIP_KEY
            if ((isStrip && !scripts) || (!isStrip && !settings)) continue
            val e = p.getJSONObject(key)
            when (e.getString("t")) {
                "b" -> edit.putBoolean(key, e.getBoolean("v"))
                "i" -> edit.putInt(key, e.getInt("v"))
                "l" -> edit.putLong(key, e.getLong("v"))
                "f" -> edit.putFloat(key, e.getDouble("v").toFloat())
                "s" -> edit.putString(key, e.getString("v"))
                "S" -> {
                    val a = e.getJSONArray("v")
                    edit.putStringSet(key, (0 until a.length()).map { a.getString(it) }.toSet())
                }
                else -> continue
            }
            n++
        }
        edit.commit()
        return n
    }

    /** On a fresh install of an APK made with settings: load what it carries. */
    fun applyBaked(context: Context, prefs: SharedPreferences) {
        val baked = runCatching {
            context.assets.open(BAKED_ASSET).bufferedReader().use { it.readText() }
        }.getOrNull() ?: return
        apply(prefs, baked, settings = true, scripts = false)
    }
}
