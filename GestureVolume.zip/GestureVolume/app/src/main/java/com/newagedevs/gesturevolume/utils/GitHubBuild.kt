package com.newagedevs.gesturevolume.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import com.newagedevs.gesturevolume.data.local.SharedPref
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.time.Instant

/**
 * One gesture that does the whole phone-to-GitHub build: uploads the project zip (and a freshly
 * saved workflow yml) to the `gv` release, starts the "Build GestureVolume" workflow, watches it,
 * downloads the finished APK to Downloads and opens the installer.
 *
 * Everything says what it is doing through [say] (the bar's message line), and every failure says
 * in plain words what to do, not a stack trace. Runs on its own thread, one build at a time.
 */
object GitHubBuild {
    private const val TAG = "gv"
    private const val WORKFLOW = "gesturevolume.yml"
    private const val APK_ASSET = "GestureVolume.apk"
    private const val POLL_MS = 20_000L
    private const val MAX_WAIT_MS = 20 * 60_000L
    private const val YML_FRESH_MS = 5 * 60_000L

    @Volatile private var running = false
    @Volatile private var cancelRequested = false
    private val main = Handler(Looper.getMainLooper())

    private class HttpError(val code: Int, val body: String) : Exception("HTTP $code")
    private class Stop(message: String) : Exception(message)

    fun start(context: Context, pref: SharedPref, say: (String) -> Unit) {
        if (running) {
            // Running the action again while a build is being watched stops the watching.
            cancelRequested = true
            say("Stopping…")
            return
        }
        running = true
        cancelRequested = false
        val app = context.applicationContext
        val out: (String) -> Unit = { text -> notify(app, text, text.endsWith("…") || text.startsWith("Building") || text.startsWith("Build started")); main.post { say(text) } }
        val last: (String) -> Unit = { text -> notify(app, text, false); main.post { say(text) } }
        Thread {
            try {
                run(app, pref.getGhToken(), pref.getGhRepo(), pref.getGhZip(), pref.getGhYml(), out)
            } catch (e: Stop) {
                last(e.message ?: "Stopped.")
            } catch (e: Throwable) {
                last(explain(e))
            } finally {
                running = false
            }
        }.start()
    }

    /** The build's status as a notification, so it can be followed with the app closed. */
    private fun notify(context: Context, text: String, ongoing: Boolean) {
        runCatching {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(
                android.app.NotificationChannel("build", "Build from GitHub", android.app.NotificationManager.IMPORTANCE_LOW)
            )
            val n = android.app.Notification.Builder(context, "build")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("A build")
                .setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .build()
            nm.notify(7311, n)
        }
    }

    private fun explain(e: Throwable): String = when {
        e is UnknownHostException || e is SocketTimeoutException || e is java.net.ConnectException ||
            e is javax.net.ssl.SSLException ->
            "No internet, or GitHub is unreachable. Turn on the VPN and try again."
        e is HttpError -> when (e.code) {
            401 -> "GitHub refused the token (wrong or expired). Set it again in GitHub build settings."
            403 -> "The token is not allowed to do this. It needs Contents, Actions and Workflows read and write."
            404 -> "Repository or the 'gv' release was not found. Check the repo name and that the token can see it."
            422 -> "GitHub refused the upload: a file with that name already exists."
            else -> "GitHub answered with error ${e.code}: ${e.body.take(120)}"
        }
        else -> "Build stopped: ${e.javaClass.simpleName}: ${e.message}"
    }

    private fun run(
        context: Context, token: String, repo: String, zipPath: String, ymlPath: String,
        say: (String) -> Unit,
    ) {
        if (token.isEmpty()) throw Stop("Set your GitHub token first (Actions, GitHub build settings).")
        if (!Environment.isExternalStorageManager()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            throw Stop("Allow \"all files access\" for this app, then try again.")
        }
        // The newest file that starts like the chosen one: a browser renames repeats to "name (1).zip".
        val zip = newest(File(zipPath)) ?: throw Stop("Zip not found: $zipPath")
        val zipName = File(zipPath).name

        say("Checking GitHub…")
        val release = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG"))
        val releaseId = release.getLong("id")

        // Clear a stale zip of the same name and any old APK, so the finished APK is unmistakable.
        deleteAssets(token, repo, release.getJSONArray("assets")) { it == zipName || it == APK_ASSET }

        say("Uploading ${zip.name} (${zip.length() / 1024} KB)…")
        upload(token, repo, releaseId, zipName, "application/zip", zip)

        val yml = newest(File(ymlPath)) ?: File(ymlPath)
        if (yml.isFile && System.currentTimeMillis() - yml.lastModified() < YML_FRESH_MS) {
            runCatching {
                upload(token, repo, releaseId, "gesturevolume-${yml.lastModified()}.yml", "text/plain", yml)
                say("Workflow file uploaded too.")
            }.onFailure { say("The yml was not uploaded: " + explain(it)) }
        }

        val startedAt = Instant.now().minusSeconds(30)
        api(token, "POST", "https://api.github.com/repos/$repo/actions/workflows/$WORKFLOW/dispatches", "{\"ref\":\"main\"}")
        say("Build started.")

        val begin = System.currentTimeMillis()
        var lastReport = 0L
        while (true) {
            if (System.currentTimeMillis() - begin > MAX_WAIT_MS) throw Stop("The build took more than 20 minutes. Check GitHub Actions.")
            var waited = 0L
            while (waited < POLL_MS) {
                if (cancelRequested) throw Stop("Stopped. The build on GitHub keeps running; the APK will appear in the gv release.")
                Thread.sleep(1000)
                waited += 1000
            }
            runCatching { failedRun(token, repo, startedAt) }.getOrNull()?.let {
                throw Stop("The build $it. Open GitHub Actions to see why.")
            }
            val assets = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG")).getJSONArray("assets")
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }.firstOrNull { it.getString("name") == APK_ASSET }
            if (apk != null) {
                say("Build ready. Downloading…")
                val (uri, fileName) = download(context, token, repo, apk.getLong("id"))
                if (ShizukuShell.isReady()) {
                    say("Downloaded. Installing quietly with Shizuku…")
                    var result = ""
                    ShizukuShell.run("pm install -r -d \"/sdcard/Download/$fileName\"" + (if (context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE).getBoolean("autoA11y", false)) "; sleep 2; " + ShizukuShell.enableAccessibilityScript(context.packageName) else "")) { result += "$it " }
                    if (result.contains("Success")) say("Updated.") else say("Install failed: " + result.take(150))
                } else {
                    say("Saved in Downloads as $fileName. Opening the installer…")
                    runCatching {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    }.onFailure { say("Could not open the installer. Install $fileName from Downloads by hand.") }
                }
                return
            }
            val minutes = (System.currentTimeMillis() - begin) / 60_000
            if (minutes > lastReport) { lastReport = minutes; say("Building… $minutes min") }
        }
    }

    /** The most recently modified file in the same folder whose name starts like [wanted] and ends the same. */
    private fun newest(wanted: File): File? {
        val dir = wanted.parentFile ?: return null
        val ext = wanted.extension.lowercase()
        // Letters and digits only, so "GestureVolume (3).zip", "GestureVolume-2.zip" and
        // "gesture_volume.zip" all count, wherever the browser put the number or dash.
        fun key(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val base = key(wanted.nameWithoutExtension)
        return dir.listFiles { f ->
            f.isFile && !f.name.startsWith(".") && f.name.lowercase().contains(".$ext") && key(f.name.substringBeforeLast(".$ext", f.name)).startsWith(base)
        }?.maxByOrNull { it.lastModified() }
    }

    /** The conclusion of the run this build started, when it ended badly; null while fine or unknown. */
    private fun failedRun(token: String, repo: String, since: Instant): String? {
        val runs = JSONObject(
            api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?event=workflow_dispatch&per_page=3")
        ).getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (Instant.parse(r.getString("created_at")).isBefore(since)) continue
            return when (val c = r.optString("conclusion", "")) {
                "failure", "cancelled", "timed_out" -> if (c == "failure") "failed" else c.replace('_', ' ')
                else -> null
            }
        }
        return null
    }

    private fun deleteAssets(token: String, repo: String, assets: JSONArray, match: (String) -> Boolean) {
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (match(a.getString("name"))) {
                api(token, "DELETE", "https://api.github.com/repos/$repo/releases/assets/${a.getLong("id")}")
            }
        }
    }

    private fun open(url: String, method: String, token: String?, accept: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = false
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "A-app")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            if (token != null) setRequestProperty("Authorization", "Bearer $token")
        }

    private fun api(token: String, method: String, url: String, body: String? = null): String {
        val c = open(url, method, token, "application/vnd.github+json")
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun upload(token: String, repo: String, releaseId: Long, name: String, type: String, file: File) {
        val url = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=" + Uri.encode(name)
        val c = open(url, "POST", token, "application/vnd.github+json")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", type)
            c.setFixedLengthStreamingMode(file.length())
            c.outputStream.use { out -> file.inputStream().use { it.copyTo(out) } }
            val code = c.responseCode
            if (code != 201) {
                throw HttpError(code, (c.errorStream ?: c.inputStream)?.bufferedReader()?.use { it.readText() } ?: "")
            }
        } finally {
            c.disconnect()
        }
    }

    /** Downloads the asset into Downloads/A.apk (the token is not sent to the storage host). */
    private fun download(context: Context, token: String, repo: String, assetId: Long): Pair<Uri, String> {
        val first = open("https://api.github.com/repos/$repo/releases/assets/$assetId", "GET", token, "application/octet-stream")
        val location: String
        try {
            val code = first.responseCode
            if (code !in 300..399) throw HttpError(code, "")
            location = first.getHeaderField("Location") ?: throw Stop("GitHub gave no download address.")
        } finally {
            first.disconnect()
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "A.apk")
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Stop("Could not create A.apk in Downloads.")
        val c = open(location, "GET", null, "application/octet-stream")
        try {
            c.readTimeout = 120_000
            if (c.responseCode !in 200..299) throw HttpError(c.responseCode, "")
            resolver.openOutputStream(uri)!!.use { out -> c.inputStream.use { it.copyTo(out) } }
        } finally {
            c.disconnect()
        }
        val name = resolver.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "A.apk"
        return uri to name
    }
}
