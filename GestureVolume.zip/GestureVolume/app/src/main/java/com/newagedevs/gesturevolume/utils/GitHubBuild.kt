package com.newagedevs.gesturevolume.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import com.newagedevs.gesturevolume.data.local.SharedPref
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.time.Instant

/**
 * One gesture that does the whole phone-to-GitHub build: uploads the project zip (and a freshly
 * saved workflow yml) to the `gv` release, starts the "Build GestureVolume" workflow, watches it,
 * downloads the finished APK to Downloads and opens the installer.
 *
 * Everything says what it is doing through [say] (the bar's message line), and every failure says
 * in plain words what to do, not a stack trace. Runs on its own thread, one build at a time.
 */
object GitHubBuild {
    // Which project is being built: A (gv release, gesturevolume.yml) or the LeanType A keyboard
    // (lt release, leantype.yml), chosen from the zip's file name.
    private class Proj(val tag: String, val workflow: String, val apk: String, val prefix: String)
    // Each build thread has its own project, so several projects can be built at the same time.
    private val cur = ThreadLocal.withInitial { Proj("gv", "gesturevolume.yml", "GestureVolume.apk", "gesturevolume") }
    private val TAG get() = cur.get()!!.tag
    private val WORKFLOW get() = cur.get()!!.workflow
    private val APK_ASSET get() = cur.get()!!.apk
    private val YML_PREFIX get() = cur.get()!!.prefix

    /** The release a file goes to when the user did not choose one: by the file's name. */
    private fun autoTag(name: String) = when {
        name.startsWith("LeanType", true) -> "lt"
        name.startsWith("blackbox", true) -> "bb"
        else -> "gv"
    }
    private fun tagOf(name: String, rel: String) = rel.trim().ifEmpty { autoTag(name) }

    private fun select(name: String, rel: String = "") {
        val tag = tagOf(name, rel)
        cur.set(
            when {
                name.startsWith("LeanType", true) -> Proj(tag, "leantype.yml", "LeanType.apk", "leantype")
                name.startsWith("blackbox", true) -> Proj(tag, "blackbox.yml", "BlackBox.apk", "blackbox")
                else -> Proj(tag, "gesturevolume.yml", "GestureVolume.apk", "gesturevolume")
            }
        )
    }

    /** The release the zip goes to; created the first time when it does not exist yet. */
    private fun releaseOf(token: String, repo: String): JSONObject = try {
        JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG"))
    } catch (e: HttpError) {
        if (e.code != 404) throw e
        JSONObject(api(token, "POST", "https://api.github.com/repos/$repo/releases",
            "{\"tag_name\":\"$TAG\",\"name\":\"$TAG\",\"prerelease\":true}"))
    }
    private const val POLL_MS = 20_000L
    private const val MAX_WAIT_MS = 20 * 60_000L
    private const val YML_FRESH_MS = 5 * 60_000L

    @Volatile private var running = false
    @Volatile private var cancelRequested = false
    private val main = Handler(Looper.getMainLooper())

    private class HttpError(val code: Int, val body: String) : Exception("HTTP $code")
    private class Stop(message: String) : Exception(message)

    const val ACTION_STOP = "a.a.BUILD_STOP"
    const val ACTION_RESUME = "a.a.BUILD_RESUME"

    /** Where a status line goes (notification, toast, bar: the user's choice); returns (running line, final line). */
    private fun makeOutput(app: Context, sp: android.content.SharedPreferences, say: (String) -> Unit): Pair<(String) -> Unit, (String) -> Unit> {
        fun show(text: String, ongoing: Boolean) {
            val lines = record(text)
            if (sp.getBoolean("ghShowNotif", true)) notify(app, lines, ongoing)
            if (sp.getBoolean("ghShowToast", false)) main.post { runCatching { android.widget.Toast.makeText(app, text, android.widget.Toast.LENGTH_LONG).show() } }
            if (sp.getBoolean("ghShowBar", false)) main.post { say(text) }
        }
        return Pair({ t: String -> show(t, true) }, { t: String -> show(t, false) })
    }

    /** Downloads the APK of a finished run (its artifact) and installs it, like the end of a build. */
    fun installRun(context: Context, pref: SharedPref, runId: Long, runName: String, say: (String) -> Unit) {
        if (running) { say("A build is being watched. Wait for it, or stop it from its notification."); return }
        running = true; cancelRequested = false; history.clear()
        val app = context.applicationContext
        val sp = pref.sharedPreferences
        val (out, last) = makeOutput(app, sp, say)
        Thread {
            try {
                val token = pref.getGhToken(); val repo = pref.getGhRepo()
                out("Finding the APK of run $runName…")
                val arts = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs/$runId/artifacts")).getJSONArray("artifacts")
                val art = (0 until arts.length()).map { arts.getJSONObject(it) }.firstOrNull { !it.optBoolean("expired") }
                    ?: throw Stop("That run has no downloadable file any more (GitHub keeps them 90 days).")
                val apkName = if (runName.contains("LeanType", true)) "LeanType.apk" else "A.apk"
                out("Downloading ${art.getString("name")} (${art.getLong("size_in_bytes") / 1024} KB)…")
                val (uri, fileName) = download(app, token, "https://api.github.com/repos/$repo/actions/artifacts/${art.getLong("id")}/zip", apkName, unzip = true)
                installApk(app, uri, fileName, out)
                last("Done: $fileName")
            } catch (e: Stop) { last(e.message ?: "Stopped.") } catch (e: Throwable) { last(explain(e)) } finally { running = false }
        }.start()
    }

    /** Hands the downloaded APK to the system installer (tap-to-install; no silent install). */
    private fun installApk(context: Context, uri: Uri, fileName: String, say: (String) -> Unit) {
        val info = runCatching {
            context.packageManager.getPackageArchiveInfo("/sdcard/Download/$fileName", 0)
        }.getOrNull()
        val version = info?.versionName?.let { "$it" } ?: "unknown version"
        val kb = runCatching { java.io.File("/sdcard/Download/$fileName").length() / 1024 }.getOrDefault(0L)
        val at = clock.format(java.util.Date())
        say("Ready at $at: $fileName, version $version (${kb} KB). Tap the notification to install.")
        offerInstall(context, uri, "$fileName  v$version  ready $at")
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    /** Cancels the workflow runs still going or waiting; returns how many. */
    private fun cancelRunning(token: String, repo: String): Int {
        var n = 0
        fetchRuns(token, repo).getOrNull()?.filter { !it.finished }?.forEach {
            runCatching { api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/${it.id}/cancel"); n++ }
        }
        return n
    }

    /** Stop watching (the notification's Stop button). The build on GitHub keeps running. */
    fun requestStop() { if (running) cancelRequested = true }

    /** Receives the notification's Stop and Resume buttons. */
    class ButtonReceiver : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_STOP -> requestStop()
                ACTION_RESUME -> if (!running) start(context, SharedPref(context.applicationContext), resume = true) { }
            }
        }
    }

    private fun button(context: Context, label: String, action: String): android.app.Notification.Action {
        val i = Intent(action).setPackage(context.packageName)
        val pi = android.app.PendingIntent.getBroadcast(context, action.hashCode(), i, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        return android.app.Notification.Action.Builder(null as android.graphics.drawable.Icon?, label, pi).build()
    }

    /** Identity of a file as last seen: a build counts as done for it only when it finished. */
    private fun sig(f: File) = "${f.name}|${f.length()}|${f.lastModified()}"
    private fun done(sp: android.content.SharedPreferences, f: File) = sp.getString("ghDone_" + f.name.lowercase().filter { it.isLetterOrDigit() }, null) == sig(f)
    private fun markDone(sp: android.content.SharedPreferences, f: File) =
        sp.edit().putString("ghDone_" + f.name.lowercase().filter { it.isLetterOrDigit() }, sig(f)).apply()

    fun start(context: Context, pref: SharedPref, resume: Boolean = false, force: Boolean = false, say: (String) -> Unit) {
        DiagLog.note("build action tapped (already running=$running)")
        if (running) {
            // Tapping again stops the build (and cancels it on GitHub); tap once more to start again.
            cancelRequested = true
            say("Stopping the build… Tap again to start it again.")
            return
        }
        running = true
        cancelRequested = false
        val app = context.applicationContext
        history.clear()
        // Where the status goes is the user's choice (GitHub build settings): notification (the
        // default), toast, bar message.
        val sp = pref.sharedPreferences
        val (out, last) = makeOutput(app, sp, say)
        if (sp.getBoolean("ghShowNotif", true) &&
            !runCatching { app.getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled() }.getOrDefault(true)) {
            say("Notifications are off. Please turn them on to see the build status.")
        }
        val zipItems = pref.getGhFiles("zip").filter { it.on && it.path.isNotBlank() }
        val ymlItems = pref.getGhFiles("yml").filter { it.on && it.path.isNotBlank() }
        val zips = zipItems.map { it.path }
        val ymls = ymlItems.map { it.path }
        val zipRel = zipItems.associate { it.path to it.rel }
        val ymlRel = ymlItems.associate { it.path to it.rel }
        Thread {
            try {
                if (resume) {
                    run(app, pref.getGhToken(), pref.getGhRepo(), zips.firstOrNull() ?: "", ymls, out, true, sp, zipRel[zips.firstOrNull() ?: ""] ?: "", ymlRel)
                } else {
                    // Every checked zip that exists is built in turn; a missing one is just skipped.
                    val onlyChanged = !force && sp.getBoolean("ghOnlyChanged", true)
                    val allPresent = zips.filter { newest(File(it)) != null }
                    val present = allPresent.filter { !onlyChanged || !done(sp, newest(File(it))!!) }
                    val unchanged = allPresent - present.toSet()
                    if (unchanged.isNotEmpty()) out("Skipped, nothing new since the last finished build: " + unchanged.joinToString { newest(File(it))!!.name })
                    val missing = zips.filter { newest(File(it)) == null }
                    val ymlsFound = ymls.filter { newest(File(it)) != null && (!onlyChanged || !done(sp, newest(File(it))!!)) }
                    out("Checked files: zips found " + (present.joinToString { newest(File(it))!!.name }.ifEmpty { "none" }) +
                        (if (missing.isNotEmpty()) "; not found: " + missing.joinToString { File(it).name } else "") +
                        "; ymls found " + (ymlsFound.joinToString { newest(File(it))!!.name }.ifEmpty { "none" }) + ".")
                    // A ticked yml whose project has no zip this time is still uploaded, on its own.
                    val projectsBuilt = present.map { tagOf(File(it).name, zipRel[it] ?: "") }.toSet()
                    val loneYmls = ymlsFound.filter { tagOf(File(it).name, ymlRel[it] ?: "") !in projectsBuilt }
                    // Everything goes up at the same time: lone ymls and every project's build.
                    val workers = ArrayList<Thread>()
                    val failures = java.util.Collections.synchronizedList(ArrayList<Throwable>())
                    for (y in loneYmls) workers += Thread {
                        try {
                            select(File(y).name, ymlRel[y] ?: "")
                            val rel = releaseOf(pref.getGhToken(), pref.getGhRepo())
                            val f = newest(File(y))!!
                            upload(pref.getGhToken(), pref.getGhRepo(), rel.getLong("id"), "$YML_PREFIX-${f.lastModified()}.yml", "text/plain", f)
                            markDone(sp, f)
                            out("Uploaded ${f.name} to the $TAG release (it takes effect at the next build of that project).")
                        } catch (e: Throwable) { out("${File(y).name}: " + explain(e)); failures += e }
                    }
                    if (present.isEmpty()) {
                        if (loneYmls.isNotEmpty()) {
                            workers.forEach { it.start() }; workers.forEach { it.join() }
                            throw Stop("Uploaded the checked workflow file(s). No zip was found, so nothing was built.")
                        }
                        if (allPresent.isNotEmpty()) throw Stop("Nothing new to build: every checked file was already built. Change a file, or use \"Build all ticked now\" in GitHub build settings.")
                        throw Stop("None of the checked files was found. Check the paths in GitHub build settings.")
                    }
                    for (z in present) workers += Thread {
                        try {
                            val label = File(z).nameWithoutExtension
                            val say2: (String) -> Unit = if (present.size > 1) { t -> out("[$label] $t") } else out
                            run(app, pref.getGhToken(), pref.getGhRepo(), z, ymls, say2, false, sp, zipRel[z] ?: "", ymlRel)
                        } catch (e: Stop) { out("[${File(z).nameWithoutExtension}] ${e.message}"); failures += e }
                        catch (e: Throwable) { out("[${File(z).nameWithoutExtension}] " + explain(e)); failures += e }
                    }
                    workers.forEach { it.start() }
                    workers.forEach { it.join() }
                    if (failures.isNotEmpty() && failures.all { it is Stop }) throw Stop("Finished with problems; see the lines above.")
                }
            } catch (e: Stop) {
                last(e.message ?: "Stopped.")
            } catch (e: Throwable) {
                last(explain(e))
            } finally {
                running = false
            }
        }.start()
    }

    private val history = ArrayList<String>()
    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    /** Adds a line to the running history and returns the last lines, one per row, for the notification. */
    @Synchronized
    private fun record(text: String): String {
        DiagLog.note("build: $text")
        history.add("${clock.format(java.util.Date())}  $text")
        return history.takeLast(8).joinToString("\n")
    }

    /** The build's status as a notification, so it can be followed with the app closed. */
    private fun notify(context: Context, text: String, ongoing: Boolean) {
        runCatching {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(
                android.app.NotificationChannel("build", "Build from GitHub", android.app.NotificationManager.IMPORTANCE_LOW)
            )
            val n = android.app.Notification.Builder(context, "build")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("A build")
                .setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .addAction(if (ongoing) button(context, "Stop", ACTION_STOP) else button(context, "Resume", ACTION_RESUME))
                .build()
            nm.notify(7311, n)
        }
    }

    /** A notification that opens the installer for the downloaded APK when tapped (a background app cannot open it by itself). */
    private fun offerInstall(context: Context, uri: Uri, detail: String = "Tap to install") {
        runCatching {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pi = android.app.PendingIntent.getActivity(context, 0, view, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            val n = android.app.Notification.Builder(context, "build")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("New A build ready")
                .setContentText(detail)
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(7312, n)
            context.startActivity(view)
        }
    }

    private fun isNetworkError(e: Throwable) =
        e is UnknownHostException || e is SocketTimeoutException || e is java.net.ConnectException ||
            e is javax.net.ssl.SSLException || e is java.net.SocketException

    private fun explain(e: Throwable): String = when {
        isNetworkError(e) ->
            "No internet, or GitHub is unreachable. Turn on the VPN, then run Resume build status. " +
                "If the upload had not finished, run Build from GitHub again instead."
        e is HttpError -> when (e.code) {
            401 -> "GitHub refused the token (wrong or expired). Set it again in GitHub build settings."
            403 -> "The token is not allowed to do this. It needs Contents, Actions and Workflows read and write."
            404 -> "Repository or the 'gv' release was not found. Check the repo name and that the token can see it."
            422 -> "GitHub refused the upload: a file with that name already exists."
            else -> "GitHub answered with error ${e.code}: ${e.body.take(120)}"
        }
        else -> "Build stopped: ${e.javaClass.simpleName}: ${e.message}"
    }

    private fun run(
        context: Context, token: String, repo: String, zipPath: String, ymlPaths: List<String>,
        say: (String) -> Unit, resume: Boolean, sp: android.content.SharedPreferences,
        zipRel: String, ymlRels: Map<String, String>,
    ) {
        if (token.isEmpty()) throw Stop("Set your GitHub token first (Actions, GitHub build settings).")
        if (!Environment.isExternalStorageManager()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            throw Stop("Allow \"all files access\" for this app, then try again.")
        }
        if (resume) select(sp.getString("ghProject", "GestureVolume") ?: "GestureVolume", sp.getString("ghProjectRel", "") ?: "")
        else {
            select(File(zipPath).name, zipRel)
            sp.edit().putString("ghProject", File(zipPath).name).putString("ghProjectRel", zipRel).apply()
        }
        val startedAt: Instant
        if (resume) {
            // Picks up the build started earlier, without uploading anything again.
            val saved = sp.getLong("ghStartedAt", 0L)
            if (saved == 0L || System.currentTimeMillis() - saved > 60 * 60_000L) {
                throw Stop("No recent build to resume. Run Build from GitHub to start a new one.")
            }
            startedAt = Instant.ofEpochMilli(saved)
            say("Resuming the build started at ${clock.format(java.util.Date(saved))}. Nothing is uploaded again.")
        } else {
        // The newest file that starts like the chosen one: a browser renames repeats to "name (1).zip".
        val zip = newest(File(zipPath)) ?: kotlin.run {
            val seen = File(zipPath).parentFile?.listFiles()?.map { it.name }.orEmpty()
            val like = seen.filter { it.contains("gesture", true) }.take(6)
            throw Stop("Zip not found: $zipPath. Folder shows ${seen.size} files; ones named like it: ${like.ifEmpty { listOf("none") }.joinToString(", ")}. Check the zip path in GitHub build settings.")
        }
        val zipName = File(zipPath).name

        checkStop()
        val release = releaseOf(token, repo)
        val releaseId = release.getLong("id")

        // Clear a stale zip of the same name and any old APK, so the finished APK is unmistakable.
        deleteAssets(token, repo, release.getJSONArray("assets")) { it == zipName || it == APK_ASSET || it.endsWith(".apk", true) }

        checkStop()
        say("Uploading ${zip.nameWithoutExtension} (${zip.length() / 1024} KB, saved ${clock.format(java.util.Date(zip.lastModified()))})…")
        upload(token, repo, releaseId, zipName, "application/zip", zip)
        sp.edit().putString("ghPendingZip_$TAG", zip.absolutePath).putString("ghPendingSig_$TAG", sig(zip)).apply()

        // The checked workflow files that belong to this project (leantype*.yml go with the keyboard).
        for (p in ymlPaths) {
            if (tagOf(File(p).name, ymlRels[p] ?: "") != TAG) continue
            val yml = newest(File(p)) ?: continue
            if (sp.getBoolean("ghOnlyChanged", true) && done(sp, yml)) continue
            runCatching {
                upload(token, repo, releaseId, "$YML_PREFIX-${yml.lastModified()}.yml", "text/plain", yml)
                markDone(sp, yml)
                say("Workflow file uploaded too: ${yml.name}.")
            }.onFailure { say("The yml was not uploaded: " + explain(it)) }
        }

        checkStop("Stopped before the build was started. The upload is on GitHub but nothing is building.")
        startedAt = Instant.now().minusSeconds(30)
        api(token, "POST", "https://api.github.com/repos/$repo/actions/workflows/$WORKFLOW/dispatches", "{\"ref\":\"main\"}")
        sp.edit().putLong("ghStartedAt", startedAt.toEpochMilli()).apply()
        say("Build started on GitHub (checking every ${POLL_MS / 1000} s)…")
        }

        val begin = System.currentTimeMillis()
        var lastReport = 0L
        var netFails = 0
        while (true) {
            if (System.currentTimeMillis() - begin > MAX_WAIT_MS) throw Stop("The build took more than 20 minutes. Check GitHub Actions.")
            var waited = 0L
            while (waited < POLL_MS) {
                if (cancelRequested) {
                    val n = runCatching { cancelRunning(token, repo) }.getOrDefault(0)
                    throw Stop(if (n > 0) "Stopped. The build was cancelled on GitHub. Tap the shortcut to build it again." else "Stopped watching. Tap the shortcut to build again.")
                }
                Thread.sleep(1000)
                waited += 1000
            }
            runCatching { failedRun(token, repo, startedAt, WORKFLOW) }.getOrNull()?.let {
                throw Stop("The build $it. Open GitHub Actions to see why.")
            }
            val assets = try {
                JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG")).getJSONArray("assets")
                    .also { netFails = 0 }
            } catch (e: Throwable) {
                if (!isNetworkError(e)) throw e
                // A dropped connection must not end the watching: wait and ask again.
                if (++netFails > 15) throw Stop("Lost the connection for 5 minutes. Turn on the VPN, then run Resume build status (nothing is uploaded again).")
                notify(context, record("Connection lost, trying again ($netFails)…"), true)
                continue
            }
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }.filter { it.getString("name").endsWith(".apk", true) && !Instant.parse(it.getString("created_at")).isBefore(startedAt) }
                .maxByOrNull { it.getString("created_at") }
            if (apk != null) {
                say("Build ready: ${apk.getString("name")} (${apk.getLong("size") / 1024} KB). Downloading…")
                val (uri, fileName) = download(context, token, repo, apk.getLong("id"))
                sp.getString("ghPendingZip_$TAG", null)?.let { p ->
                    val z = File(p)
                    if (z.exists() && sig(z) == sp.getString("ghPendingSig_$TAG", "")) markDone(sp, z)
                }
                installApk(context, uri, fileName, say)
                return
            }
            val minutes = (System.currentTimeMillis() - begin) / 60_000
            val secs = (System.currentTimeMillis() - begin) / 1000
            if (minutes > lastReport) { lastReport = minutes; say("Still building… $minutes min (checked at ${clock.format(java.util.Date())})") }
            else notify(context, record("Checked GitHub, ${secs / 60}:${"%02d".format(secs % 60)} in, not finished"), true)
        }
    }

    /** The most recently modified file in the same folder whose name starts like [wanted] and ends the same. */
    private fun newest(wanted: File): File? {
        val dir = wanted.parentFile ?: return null
        val ext = wanted.extension.lowercase()
        // Letters and digits only, so "GestureVolume (3).zip", "GestureVolume-2.zip" and
        // "gesture_volume.zip" all count, wherever the browser put the number or dash.
        fun key(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val base = key(wanted.nameWithoutExtension)
        return dir.listFiles { f ->
            f.isFile && !f.name.startsWith(".") && f.name.lowercase().contains(".$ext") && key(f.name.substringBeforeLast(".$ext", f.name)).startsWith(base)
        }?.maxByOrNull { it.lastModified() }
    }

    /** The conclusion of the run this build started, when it ended badly; null while fine or unknown. */
    private fun failedRun(token: String, repo: String, since: Instant, workflow: String): String? {
        val runs = JSONObject(
            api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?event=workflow_dispatch&per_page=10")
        ).getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (Instant.parse(r.getString("created_at")).isBefore(since)) continue
            if (!r.optString("path", "").endsWith(workflow)) continue
            return when (val c = r.optString("conclusion", "")) {
                "failure", "cancelled", "timed_out" -> if (c == "failure") "failed" else c.replace('_', ' ')
                else -> null
            }
        }
        return null
    }

    private fun deleteAssets(token: String, repo: String, assets: JSONArray, match: (String) -> Boolean) {
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (match(a.getString("name"))) {
                api(token, "DELETE", "https://api.github.com/repos/$repo/releases/assets/${a.getLong("id")}")
            }
        }
    }

    private fun open(url: String, method: String, token: String?, accept: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = false
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "A-app")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            if (token != null) setRequestProperty("Authorization", "Bearer $token")
        }

    private fun api(token: String, method: String, url: String, body: String? = null): String {
        val c = open(url, method, token, "application/vnd.github+json")
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    /**
     * Deletes every workflow run of the repository: failed, successful and cancelled ones. A run
     * still going is cancelled first and left for the next time. Blocking: use a background
     * thread. Returns a sentence to show.
     */
    fun deleteAllRuns(token: String, repo: String, progress: (String) -> Unit = {}): String {
        if (token.isEmpty()) return "Set your GitHub token first."
        var deleted = 0
        var busy = 0
        return try {
            for (round in 0 until 30) {
                val runs = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=100")).getJSONArray("workflow_runs")
                if (runs.length() == 0) break
                var progressMade = false
                for (i in 0 until runs.length()) {
                    val r = runs.getJSONObject(i)
                    val id = r.getLong("id")
                    if (r.optString("status") != "completed") {
                        runCatching { api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/$id/cancel") }
                        busy++
                        continue
                    }
                    api(token, "DELETE", "https://api.github.com/repos/$repo/actions/runs/$id")
                    deleted++; progressMade = true
                    if (deleted % 10 == 0) progress("Deleted $deleted…")
                }
                if (!progressMade) break
            }
            "Deleted $deleted workflow runs." + if (busy > 0) " $busy still running: cancelled, delete them again in a minute." else ""
        } catch (e: HttpError) {
            if (e.code == 403 || e.code == 404) "GitHub refused (${e.code}). The token needs the Actions: read and write permission for $repo."
            else "GitHub answered with error ${e.code}. Deleted $deleted so far."
        } catch (e: Throwable) {
            "Stopped after $deleted: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    class RunInfo(val id: Long, val number: Int, val name: String, val state: String, val created: String, val finished: Boolean)

    /** The repository's newest 100 workflow runs with their status (blocking; background thread). */
    fun fetchRuns(token: String, repo: String): Result<List<RunInfo>> = runCatching {
        if (token.isEmpty()) error("Set your GitHub token first.")
        val runs = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=100")).getJSONArray("workflow_runs")
        (0 until runs.length()).map {
            val r = runs.getJSONObject(it)
            val status = r.optString("status")
            RunInfo(
                r.getLong("id"), r.optInt("run_number"), r.optString("name"),
                r.optString("conclusion").ifEmpty { status },
                r.optString("created_at").replace('T', ' ').removeSuffix("Z"), status == "completed",
            )
        }
    }

    /** Deletes only the runs given (finished ones; a run still going is never touched). */
    fun deleteRuns(token: String, repo: String, ids: List<Long>): String {
        var deleted = 0; var failed = 0
        for (id in ids) {
            try { api(token, "DELETE", "https://api.github.com/repos/$repo/actions/runs/$id"); deleted++ } catch (e: Throwable) { failed++ }
        }
        return "Deleted $deleted workflow runs." + if (failed > 0) " $failed could not be deleted (still running, or the token lacks Actions write)." else ""
    }

    /** A readable list of the repository's workflow runs (newest first), to check what is there. */
    fun listRuns(token: String, repo: String): String {
        if (token.isEmpty()) return "Set your GitHub token first."
        return try {
            val o = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=50"))
            val total = o.optInt("total_count", 0)
            val runs = o.getJSONArray("workflow_runs")
            if (total == 0 || runs.length() == 0) return "No workflow runs in $repo."
            val sb = StringBuilder("$total workflow runs in $repo")
            if (total > runs.length()) sb.append(" (newest ${runs.length()} shown)")
            sb.append(":\n\n")
            for (i in 0 until runs.length()) {
                val r = runs.getJSONObject(i)
                val state = r.optString("conclusion").ifEmpty { r.optString("status") }
                val mark = when (state) { "success" -> "OK"; "failure" -> "FAILED"; "cancelled" -> "CANCELLED"; else -> state.uppercase() }
                sb.append("#${r.optInt("run_number")}  $mark  ${r.optString("name")}  ${r.optString("created_at").replace('T', ' ').removeSuffix("Z")}\n")
            }
            sb.toString()
        } catch (e: HttpError) {
            if (e.code == 403 || e.code == 404) "GitHub refused (${e.code}). Check the token and the repository name; the token needs Actions: read."
            else "GitHub answered with error ${e.code}."
        } catch (e: Throwable) {
            "Could not read: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun checkStop(text: String = "Stopped before anything was built.") {
        if (cancelRequested) throw Stop(text)
    }

    private fun upload(token: String, repo: String, releaseId: Long, name: String, type: String, file: File) {
        val url = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=" + Uri.encode(name)
        val c = open(url, "POST", token, "application/vnd.github+json")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", type)
            c.setFixedLengthStreamingMode(file.length())
            c.outputStream.use { out ->
                file.inputStream().use { input ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        // Stop pressed: cut the connection, GitHub throws the half file away.
                        if (cancelRequested) { c.disconnect(); throw Stop("Stopped while uploading. Nothing was built.") }
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            val code = c.responseCode
            if (code != 201) {
                throw HttpError(code, (c.errorStream ?: c.inputStream)?.bufferedReader()?.use { it.readText() } ?: "")
            }
        } finally {
            c.disconnect()
        }
    }

    /** Downloads the asset into Downloads/A.apk (the token is not sent to the storage host). */
    private fun download(context: Context, token: String, repo: String, assetId: Long): Pair<Uri, String> =
        download(context, token, "https://api.github.com/repos/$repo/releases/assets/$assetId", "A.apk", unzip = false)

    /** [unzip]: the address gives a zip (a workflow artifact); its APK is what is saved. */
    private fun download(context: Context, token: String, apiUrl: String, saveAs: String, unzip: Boolean): Pair<Uri, String> {
        // The artifact zip endpoint refuses "octet-stream" (error 415); it wants the plain GitHub type.
        val first = open(apiUrl, "GET", token, if (unzip) "application/vnd.github+json" else "application/octet-stream")
        val location: String
        try {
            val code = first.responseCode
            if (code !in 300..399) throw HttpError(code, "")
            location = first.getHeaderField("Location") ?: throw Stop("GitHub gave no download address.")
        } finally {
            first.disconnect()
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, saveAs)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Stop("Could not create $saveAs in Downloads.")
        val c = open(location, "GET", null, "application/octet-stream")
        try {
            c.readTimeout = 120_000
            if (c.responseCode !in 200..299) throw HttpError(c.responseCode, "")
            if (!unzip) {
                resolver.openOutputStream(uri)!!.use { out -> c.inputStream.use { it.copyTo(out) } }
            } else {
                java.util.zip.ZipInputStream(c.inputStream).use { zin ->
                    var found = false
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (!e.isDirectory && e.name.endsWith(".apk", true)) {
                            resolver.openOutputStream(uri)!!.use { out -> zin.copyTo(out) }
                            found = true; break
                        }
                    }
                    if (!found) throw Stop("The downloaded file held no APK.")
                }
            }
        } finally {
            c.disconnect()
        }
        val name = resolver.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: saveAs
        return uri to name
    }
}
