package com.newagedevs.gesturevolume.strip

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.android.apksig.ApkSigner
import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Makes a copy of this very app with the current strip baked in as its default.
 *
 * An APK is a zip: the installed one is copied entry by entry (stored entries kept stored and
 * aligned, as Android requires), `assets/strip_default.json` is replaced, and the copy is signed
 * with the same key the CI builds use, so it installs over this app as an update and keeps every
 * setting, and on a phone without the app it simply starts with this strip.
 *
 * Runs only when asked, from the settings screen. Nothing here is loaded by the overlay.
 */
object ApkCloner {

    private const val ASSET = "assets/strip_default.json"

    /** Returns a short message for the screen: where the file went, or why it failed. */
    fun make(context: Context, stripJson: String): String = try {
        val cache = File(context.cacheDir, "clone").apply { deleteRecursively(); mkdirs() }
        val unsigned = File(cache, "unsigned.apk")
        val signed = File(cache, "signed.apk")
        rewrite(File(context.applicationInfo.sourceDir), unsigned, stripJson)
        sign(context, unsigned, signed)
        val name = "GestureVolume-mine.apk"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("could not create the file in Downloads")
        resolver.openOutputStream(uri)!!.use { out -> signed.inputStream().use { it.copyTo(out) } }
        cache.deleteRecursively()
        "Saved in Downloads as $name"
    } catch (e: Throwable) {
        "Failed: ${e.javaClass.simpleName}: ${e.message}"
    }

    private class Counting(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun rewrite(source: File, target: File, json: String) {
        val counter = Counting(target.outputStream().buffered(1 shl 16))
        ZipFile(source).use { zip ->
            ZipOutputStream(counter).use { out ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    val name = e.name
                    if (e.isDirectory || name == ASSET || isSignatureFile(name)) continue
                    val copy = ZipEntry(name)
                    if (e.method == ZipEntry.STORED) {
                        copy.method = ZipEntry.STORED
                        copy.size = e.size
                        copy.compressedSize = e.size
                        copy.crc = e.crc
                        val align = if (name.endsWith(".so")) 16384 else 4
                        val base = counter.count + 30 + name.toByteArray(Charsets.UTF_8).size
                        var need = ((align - base % align) % align).toInt()
                        if (need in 1..3) need += align
                        if (need > 0) {
                            val extra = ByteArray(need)
                            extra[0] = 0x35; extra[1] = 0xD9.toByte()
                            extra[2] = ((need - 4) and 0xFF).toByte(); extra[3] = (((need - 4) shr 8) and 0xFF).toByte()
                            copy.extra = extra
                        }
                    }
                    out.putNextEntry(copy)
                    zip.getInputStream(e).use { it.copyTo(out) }
                    out.closeEntry()
                }
                out.putNextEntry(ZipEntry(ASSET))
                out.write(json.toByteArray(Charsets.UTF_8))
                out.closeEntry()
            }
        }
    }

    private fun isSignatureFile(name: String): Boolean {
        if (!name.startsWith("META-INF/")) return false
        val n = name.uppercase()
        return n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") ||
            n.endsWith(".DSA") || n.endsWith(".EC")
    }

    private fun sign(context: Context, input: File, output: File) {
        val keyBytes = context.assets.open("signer_key.der").use { it.readBytes() }
        val certBytes = context.assets.open("signer_cert.der").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(certBytes.inputStream()) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("debug", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setV4SigningEnabled(false)
            .build()
            .sign()
    }
}
