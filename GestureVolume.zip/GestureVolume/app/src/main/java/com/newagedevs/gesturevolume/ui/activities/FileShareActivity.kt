package com.newagedevs.gesturevolume.ui.activities

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.newagedevs.gesturevolume.service.FileShareService

/** Share-sheet entry point. Only user-shared URIs are served; private app data is never exposed. */
class FileShareActivity : AppCompatActivity() {
    private lateinit var ssid: EditText
    private lateinit var password: EditText
    private lateinit var port: EditText
    private lateinit var status: TextView
    private lateinit var wifiQr: ImageView
    private lateinit var httpQr: ImageView
    private val shared = linkedSetOf<Uri>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        collectUris(intent)
        buildUi()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); collectUris(intent); }

    private fun collectUris(i: Intent?) {
        if (i == null) return
        (i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))?.let { shared.add(it) }
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)?.let(shared::addAll)
        } else {
            @Suppress("DEPRECATION")
            (i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.let(shared::addAll)
        }
        i.clipData?.let { c -> for (n in 0 until c.itemCount) c.getItemAt(n).uri?.let(shared::add) }
        if (i.data != null) shared.add(i.data!!)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 28) }
        root.addView(TextView(this).apply { text = "A Gesture · Wi-Fi file sharing"; textSize = 22f })
        root.addView(TextView(this).apply { text = "${shared.size} shared item(s). Only these selected items are available to the receiving device."; textSize = 14f })
        ssid = field(root, "Wi-Fi Direct network name", "DIRECT-A-Gesture")
        password = field(root, "Password (8–63 characters)", "88888888")
        port = field(root, "HTTP port", "8228")
        val start = Button(this).apply { text = "Start sharing"; setOnClickListener { startSharing() } }
        root.addView(start)
        status = TextView(this).apply { text = "Not sharing"; textSize = 14f }
        root.addView(status)
        root.addView(TextView(this).apply { text = "Wi-Fi network QR"; textSize = 16f })
        wifiQr = ImageView(this); root.addView(wifiQr, ViewGroup.LayoutParams(280, 280))
        root.addView(TextView(this).apply { text = "HTTP address QR"; textSize = 16f })
        httpQr = ImageView(this); root.addView(httpQr, ViewGroup.LayoutParams(280, 280))
        val stop = Button(this).apply { text = "Stop sharing"; setOnClickListener { stopService(Intent(this@FileShareActivity, FileShareService::class.java)); status.text = "Stopped" } }
        root.addView(stop)
        setContentView(ScrollView(this).apply { addView(root) })
        wifiQr.setImageBitmap(qr("WIFI:T:WPA;S:${ssid.text};P:${password.text};H:;;"))
        httpQr.setImageBitmap(qr("http://192.168.49.1:${port.text}"))
    }

    private fun field(root: LinearLayout, label: String, value: String): EditText {
        root.addView(TextView(this).apply { text = label })
        return EditText(this).also { it.setText(value); root.addView(it) }
    }

    private fun startSharing() {
        val name = ssid.text.toString().trim()
        val pass = password.text.toString()
        val p = port.text.toString().toIntOrNull()
        if (name.isBlank() || pass.length !in 8..63 || p == null || p !in 1024..65535) {
            status.text = "Check SSID, password (8–63 characters), and port (1024–65535)."; return
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), 41); status.text = "Allow Nearby devices, then tap Start sharing again."; return
        }
        if (Build.VERSION.SDK_INT <= 32 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 41); status.text = "Allow Location while using the app, then tap Start sharing again."; return
        }
        val svc = Intent(this, FileShareService::class.java).apply {
            action = FileShareService.ACTION_START
            putExtra(FileShareService.EXTRA_SSID, name); putExtra(FileShareService.EXTRA_PASSWORD, pass); putExtra(FileShareService.EXTRA_PORT, p)
            putParcelableArrayListExtra(FileShareService.EXTRA_URIS, ArrayList(shared))
            clipData = if (shared.isEmpty()) null else android.content.ClipData.newUri(contentResolver, "Shared files", shared.first()).also { cd ->
                shared.drop(1).forEach { cd.addItem(android.content.ClipData.Item(it)) }
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ContextCompat.startForegroundService(this, svc)
        val url = "http://192.168.49.1:$p"
        wifiQr.setImageBitmap(qr("WIFI:T:WPA;S:$name;P:$pass;H:;;"))
        httpQr.setImageBitmap(qr(url))
        status.text = "Starting Wi-Fi Direct. If Android creates the group, open $url on the connected device."
    }

    private fun qr(value: String): Bitmap {
        val matrix: BitMatrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 640, 640)
        return Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888).also { b ->
            for (x in 0 until 640) for (y in 0 until 640) b.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
}
