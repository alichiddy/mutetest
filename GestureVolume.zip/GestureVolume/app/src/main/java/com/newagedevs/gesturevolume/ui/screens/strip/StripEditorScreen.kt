package com.newagedevs.gesturevolume.ui.screens.strip

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import com.newagedevs.gesturevolume.strip.StripConfig
import com.newagedevs.gesturevolume.strip.StripItem
import com.newagedevs.gesturevolume.ui.components.ActionIconImage
import com.newagedevs.gesturevolume.ui.components.actionDisplayName
import com.newagedevs.gesturevolume.ui.screens.deck.InstalledApp
import com.newagedevs.gesturevolume.ui.screens.deck.loadLaunchableApps
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Edits the shortcut strip: the grid itself (tap a cell to select it, then move, copy, blank,
 * delete or edit it), the columns, the cell size, the labels, the position.
 *
 * Every change is saved at once, as one small JSON string, so the settings backup that already
 * copies the preferences file carries the strip too.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StripEditorScreen(viewModel: MainViewModel, onNavigateBack: () -> Unit) {
    val pref = viewModel.preference
    var cfg by remember { mutableStateOf(StripConfig.fromJson(pref.getStripConfigJson())) }
    var enabled by remember { mutableStateOf(pref.getStripEnabled()) }
    var selected by remember { mutableIntStateOf(-1) }
    var swapMode by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }

    fun commit(next: StripConfig) {
        cfg = next
        pref.setStripConfigJson(next.toJson())
    }

    fun commitItems(list: List<StripItem>) = commit(cfg.copy(items = list))

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Shortcut strip") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        bottomBar = {
            val i = selected
            if (i in cfg.items.indices) {
                Surface(tonalElevation = 6.dp) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        TextButton(onClick = { editing = i }) { Text("Edit") }
                        TextButton(onClick = {
                            if (i > 0) {
                                val l = cfg.items.toMutableList()
                                l.add(i - 1, l.removeAt(i)); commitItems(l); selected = i - 1
                            }
                        }) { Text("◀") }
                        TextButton(onClick = {
                            if (i < cfg.items.size - 1) {
                                val l = cfg.items.toMutableList()
                                l.add(i + 1, l.removeAt(i)); commitItems(l); selected = i + 1
                            }
                        }) { Text("▶") }
                        TextButton(onClick = { swapMode = !swapMode }) {
                            Text(if (swapMode) "Swap: tap a cell" else "Swap…")
                        }
                        TextButton(onClick = {
                            val l = cfg.items.toMutableList(); l.add(i + 1, cfg.items[i]); commitItems(l); selected = i + 1
                        }) { Text("Copy") }
                        TextButton(onClick = {
                            val l = cfg.items.toMutableList(); l.add(i, StripItem("", "", "")); commitItems(l)
                        }) { Text("Blank") }
                        TextButton(onClick = {
                            val l = cfg.items.toMutableList(); l.removeAt(i); commitItems(l); selected = -1; swapMode = false
                        }) { Text("Delete") }
                        TextButton(onClick = { selected = -1; swapMode = false }) { Text("✕") }
                    }
                }
            }
        },
    ) { padding ->
        val cols = cfg.columns.coerceIn(1, 16)
        val cells = (0..cfg.items.size).toList().chunked(cols)
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        ) {
            item {
                ToggleRow("Strip enabled", enabled) { enabled = it; pref.setStripEnabled(it) }
                StepperRow("Columns", "${cfg.columns}", { commit(cfg.copy(columns = (cfg.columns - 1).coerceAtLeast(1))) },
                    { commit(cfg.copy(columns = (cfg.columns + 1).coerceAtMost(16))) })
                StepperRow("Cell size", "${cfg.sizePct}%", { commit(cfg.copy(sizePct = (cfg.sizePct - 4).coerceAtLeast(30))) },
                    { commit(cfg.copy(sizePct = (cfg.sizePct + 4).coerceAtMost(100))) })
                StepperRow("Distance from bottom", "${cfg.bottomDp} dp", { commit(cfg.copy(bottomDp = (cfg.bottomDp - 10).coerceAtLeast(0))) },
                    { commit(cfg.copy(bottomDp = (cfg.bottomDp + 10).coerceAtMost(400))) })
                ToggleRow("Show names under icons", cfg.showLabels) { commit(cfg.copy(showLabels = it)) }
                ToggleRow("Centered (off = beside the bar)", cfg.centered) { commit(cfg.copy(centered = it)) }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { commit(StripConfig()); selected = -1 }) { Text("Reset to Easy Slider list") }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(
                    "Tap a cell to select it. Same order as the strip on screen.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            items(cells) { row ->
                Row(Modifier.fillMaxWidth()) {
                    for (idx in row) {
                        Box(Modifier.weight(1f)) {
                            if (idx == cfg.items.size) {
                                AddCell {
                                    commitItems(cfg.items + StripItem("", "", ""))
                                    selected = idx; editing = idx
                                }
                            } else {
                                ItemCell(cfg.items[idx], idx == selected) {
                                    val s = selected
                                    if (swapMode && s in cfg.items.indices && s != idx) {
                                        val l = cfg.items.toMutableList()
                                        val t = l[s]; l[s] = l[idx]; l[idx] = t
                                        commitItems(l); selected = idx; swapMode = false
                                    } else {
                                        selected = idx
                                    }
                                }
                            }
                        }
                    }
                    repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    val e = editing
    if (e in cfg.items.indices) {
        ItemEditor(
            item = cfg.items[e],
            onSave = { updated ->
                val l = cfg.items.toMutableList(); l[e] = updated; commitItems(l); editing = -1
            },
            onCancel = { editing = -1 },
        )
    }
}

@Composable
private fun ToggleRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun StepperRow(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        OutlinedButton(onClick = onMinus) { Text("−") }
        Text(value, Modifier.width(72.dp), textAlign = TextAlign.Center)
        OutlinedButton(onClick = onPlus) { Text("+") }
    }
}

@Composable
private fun AddCell(onClick: () -> Unit) {
    Box(
        Modifier.padding(2.dp).aspectRatio(1f).clip(RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", fontSize = 18.sp) }
}

@Composable
private fun ItemCell(item: StripItem, selected: Boolean, onClick: () -> Unit) {
    val colours = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier.padding(2.dp).aspectRatio(1f).clip(shape)
            .background(if (item.action.isNotEmpty()) colours.primaryContainer else colours.surfaceVariant)
            .then(if (selected) Modifier.border(BorderStroke(2.dp, colours.primary), shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        IconOrLabel(item, Modifier.fillMaxSize().padding(3.dp), 22)
    }
}

/** An item as the strip shows it: its icon (emoji or the app's own), else its name. */
@Composable
private fun IconOrLabel(item: StripItem, modifier: Modifier, emojiSp: Int) {
    val context = LocalContext.current
    val pkg = item.appIconPackage
    val bitmap = remember(pkg) {
        pkg?.let { p ->
            runCatching { context.packageManager.getApplicationIcon(p).toBitmap(64, 64).asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            bitmap != null -> Image(bitmap = bitmap, contentDescription = item.label, modifier = Modifier.fillMaxSize())
            item.icon.isNotEmpty() && pkg == null -> Text(item.icon, fontSize = emojiSp.sp)
            else -> Text(item.label, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
    }
}

private enum class Page { MAIN, EMOJI, ICON_APP, ACTION_APP, ACTION, FLOW, SHORTCUTS }

@Composable
private fun ItemEditor(item: StripItem, onSave: (StripItem) -> Unit, onCancel: () -> Unit) {
    var label by remember { mutableStateOf(item.label) }
    var icon by remember { mutableStateOf(item.icon) }
    var action by remember { mutableStateOf(item.action) }
    var page by remember { mutableStateOf(Page.MAIN) }
    val context = LocalContext.current
    var creatorPkg by remember { mutableStateOf("") }
    val creatorLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        @Suppress("DEPRECATION")
        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
            action = INTENT_ACTION_PREFIX + picked.toUri(android.content.Intent.URI_INTENT_SCHEME)
            val name = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME)
            if (label.isBlank() && !name.isNullOrBlank()) label = name
            if (icon.isEmpty()) {
                val pkg = picked.component?.packageName ?: picked.`package` ?: creatorPkg
                if (pkg.isNotEmpty()) icon = "app:$pkg"
            }
            page = Page.MAIN
        }
    }

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
            when (page) {
                Page.MAIN -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    OutlinedTextField(
                        value = label, onValueChange = { label = it }, singleLine = true,
                        label = { Text("Name") }, modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Icon", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconOrLabel(StripItem(label, icon, action), Modifier.size(56.dp), 36)
                        Spacer(Modifier.width(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(onClick = { page = Page.EMOJI }) { Text("Emoji") }
                            OutlinedButton(onClick = { page = Page.ICON_APP }) { Text("App icon") }
                            OutlinedButton(onClick = { icon = "" }) { Text("None") }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Action", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text(
                        when {
                            action.isEmpty() -> "Nothing"
                            action.startsWith(StripConfig.FLOW_PREFIX) -> "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
                            action.startsWith(INTENT_ACTION_PREFIX) -> "App shortcut"
                            else -> actionDisplayName(action)
                        },
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(onClick = { page = Page.ACTION_APP }) { Text("Open an app") }
                        OutlinedButton(onClick = { page = Page.SHORTCUTS }) { Text("App shortcuts") }
                        OutlinedButton(onClick = { page = Page.FLOW }) { Text("Automate flow (numbers)") }
                        OutlinedButton(onClick = { page = Page.ACTION }) { Text("Deck / tile action") }
                        OutlinedButton(onClick = { action = "" }) { Text("Nothing") }
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSave(StripItem(label.trim(), icon, action)) }) { Text("Save") }
                        TextButton(onClick = onCancel) { Text("Cancel") }
                    }
                }

                Page.EMOJI -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    var typed by remember { mutableStateOf("") }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = typed, onValueChange = { typed = it }, singleLine = true,
                            label = { Text("Type or paste any emoji") }, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { if (typed.isNotBlank()) { icon = typed.trim(); page = Page.MAIN } }) { Text("Use") }
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyVerticalGrid(columns = GridCells.Adaptive(48.dp), modifier = Modifier.weight(1f)) {
                        items(StripEmoji) { e ->
                            Box(
                                Modifier.aspectRatio(1f).clickable { icon = e; page = Page.MAIN },
                                contentAlignment = Alignment.Center,
                            ) { Text(e, fontSize = 28.sp) }
                        }
                    }
                    TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                }

                Page.ICON_APP -> AppList(onPick = { app -> icon = "app:${app.packageName}"; page = Page.MAIN }, onBack = { page = Page.MAIN })

                Page.ACTION_APP -> AppList(
                    onPick = { app ->
                        action = HandlerActions.launchApp(app.packageName)
                        if (label.isBlank()) label = app.label
                        if (icon.isEmpty()) icon = "app:${app.packageName}"
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.ACTION -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    val entries = remember {
                        HandlerActionCatalog.ALL.filter {
                            it.action != HandlerActions.NONE && it.action != HandlerActions.REPOSITION &&
                                it.action != HandlerActions.LAUNCH_APP
                        }
                    }
                    LazyColumn(Modifier.weight(1f)) {
                        items(entries) { entry ->
                            val name = stringResource(entry.labelRes)
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    action = entry.action
                                    if (label.isBlank()) label = name
                                    if (icon.isEmpty()) icon = EMOJI_FOR_ACTION[entry.action].orEmpty()
                                    page = Page.MAIN
                                }.padding(vertical = 10.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                ActionIconImage(entry.icon, null, Modifier.size(28.dp))
                                Spacer(Modifier.width(14.dp))
                                Text(name)
                            }
                        }
                    }
                    TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                }

                Page.SHORTCUTS -> {
                    var creators by remember { mutableStateOf<List<ShortcutCreator>?>(null) }
                    var found by remember { mutableStateOf<List<FoundShortcut>?>(null) }
                    LaunchedEffect(Unit) {
                        creators = withContext(Dispatchers.IO) { loadCreators(context) }
                        found = withContext(Dispatchers.IO) { loadStaticShortcuts(context) }
                    }
                    Column(Modifier.fillMaxSize().padding(12.dp)) {
                        LazyColumn(Modifier.weight(1f)) {
                            item {
                                Text("Pick from an app (Automate flows, Shortcut Maker, Settings…)", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            }
                            val c = creators
                            if (c == null) item { CircularProgressIndicator() }
                            else items(c) { cr ->
                                Text(
                                    cr.label,
                                    Modifier.fillMaxWidth().clickable {
                                        creatorPkg = cr.packageName
                                        runCatching {
                                            creatorLauncher.launch(
                                                android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT)
                                                    .setClassName(cr.packageName, cr.className)
                                            )
                                        }
                                    }.padding(vertical = 12.dp, horizontal = 6.dp)
                                )
                            }
                            item {
                                Spacer(Modifier.height(12.dp))
                                Text("Shortcuts apps declare", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            }
                            val f = found
                            if (f == null) item { CircularProgressIndicator() }
                            else items(f) { sc ->
                                Column(
                                    Modifier.fillMaxWidth().clickable {
                                        action = INTENT_ACTION_PREFIX + sc.intentUri
                                        if (label.isBlank()) label = sc.label
                                        if (icon.isEmpty()) icon = "app:${sc.packageName}"
                                        page = Page.MAIN
                                    }.padding(vertical = 8.dp, horizontal = 6.dp)
                                ) {
                                    Text(sc.label)
                                    Text(sc.appLabel, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                        TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                    }
                }

                Page.FLOW -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    var text by remember { mutableStateOf(action.removePrefix(StripConfig.FLOW_PREFIX).takeIf { action.startsWith(StripConfig.FLOW_PREFIX) }.orEmpty()) }
                    Text("Paste the shortcut's Automate address (content://com.llamalab.automate.provider/flows/…/statements/…) or type flow/statement, for example 468/233.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            StripConfig.parseFlow(text)?.let { action = it; page = Page.MAIN }
                        }) { Text("Use") }
                        TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppList(onPick: (InstalledApp) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<InstalledApp>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadLaunchableApps(context) } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth(),
        )
        val loaded = apps
        if (loaded == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val q = query.trim()
            val shown = if (q.isEmpty()) loaded else loaded.filter { it.label.contains(q, ignoreCase = true) }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.packageName }) { app ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(app) }.padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        app.icon?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(40.dp)) }
                            ?: Spacer(Modifier.size(40.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}

/** A first emoji for the actions that have an obvious one; the rest keep their name until chosen. */
private val EMOJI_FOR_ACTION: Map<String, String> = mapOf(
    HandlerActions.SCAN_QR to "🔳",
    HandlerActions.TOGGLE_FLASHLIGHT to "🔦",
    HandlerActions.OPEN_CAMERA to "📷",
    HandlerActions.OPEN_CALCULATOR to "🧮",
    HandlerActions.OPEN_NOTES to "📝",
    HandlerActions.OPEN_TIMER to "⏱️",
    HandlerActions.OPEN_SEARCH to "🔍",
    HandlerActions.COIN_TOSS to "🪙",
    HandlerActions.DICE_ROLL to "🎲",
    HandlerActions.MUTE to "🔇",
    HandlerActions.MUTE_OR_UNMUTE to "🔇",
    HandlerActions.MEDIA_PLAY_PAUSE to "⏯️",
    HandlerActions.MEDIA_NEXT to "⏭️",
    HandlerActions.MEDIA_PREVIOUS to "⏮️",
    HandlerActions.SCREENSHOT to "📸",
    HandlerActions.LOCK to "🔒",
    HandlerActions.HOME to "🏠",
    HandlerActions.BACK to "⬅️",
    HandlerActions.WIFI_PANEL to "🛜",
    HandlerActions.BLUETOOTH_SETTINGS to "🔵",
    HandlerActions.VOICE_ASSISTANT to "🎤",
    HandlerActions.OPEN_DECK to "🗂️",
    HandlerActions.OPEN_MENU to "☰",
)
