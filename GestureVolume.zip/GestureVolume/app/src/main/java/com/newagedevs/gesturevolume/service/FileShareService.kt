package com.newagedevs.gesturevolume.service

import android.app.*
import android.content.*
import android.net.Uri
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.pm.ServiceInfo
import java.net.ServerSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.OutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** User-started, local-only HTTP file server. It exposes only URIs explicitly shared to A Gesture. */
class FileShareService : Service() {
    companion object {
        const val ACTION_START = "a.gstr.files.START"
        const val ACTION_STOP = "a.gstr.files.STOP"
        const val EXTRA_SSID = "ssid"; const val EXTRA_PASSWORD = "password"; const val EXTRA_PORT = "port"; const val EXTRA_URIS = "uris"
        private const val CHANNEL = "a_gesture_file_share"
        private const val NOTIFICATION = 8228
    }
    private val alive = AtomicBoolean(false)
    private var server: ServerSocket? = null
    private var worker: Thread? = null
    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var groupCreated = false
    private var items: List<Uri> = emptyList()
    private var port = 8228
    private var netName = "DIRECT-A-Gesture"

    override fun onBind(intent: Intent?) = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_START && !alive.get()) {
            netName = intent.getStringExtra(EXTRA_SSID) ?: netName
            val pass = intent.getStringExtra(EXTRA_PASSWORD) ?: "88888888"
            port = intent.getIntExtra(EXTRA_PORT, 8228)
            items = intent.getParcelableArrayListExtra(EXTRA_URIS) ?: emptyList()
            startForegroundNotification()
            startP2p(netName, pass)
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "A Gesture sharing", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 2, Intent(this, FileShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openIntent = Intent(this, com.newagedevs.gesturevolume.ui.activities.FileShareActivity::class.java)
        val open = PendingIntent.getActivity(this, 3, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("A Gesture · File sharing active").setContentText("http://192.168.49.1:$port · ${items.size} item(s)")
            .setOngoing(true).setContentIntent(open).addAction(0, "Show QR", open).addAction(0, "Stop server", stop).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NOTIFICATION, n)
    }

    private fun startP2p(name: String, password: String) {
        val wm = getSystemService(WIFI_P2P_SERVICE) as WifiP2pManager
        manager = wm; channel = wm.initialize(this, mainLooper, null)
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as android.net.wifi.WifiManager
        if (!wifi.isWifiEnabled) {
            updateNotification("Wi-Fi is off. Enable Wi-Fi to create the Wi-Fi Direct group; hotspot fallback is not available in this build.")
            return
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val config = WifiP2pConfig.Builder().setNetworkName(name).setPassphrase(password).build()
            wm.createGroup(channel, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { groupCreated = true; startHttp() }
                override fun onFailure(reason: Int) { updateNotification("Wi-Fi Direct failed ($reason). Turn Wi-Fi on and try again.") }
            })
        } else updateNotification("Custom Wi-Fi Direct credentials require Android 10 or newer.")
    }

    private fun updateNotification(message: String) {
        val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("A Gesture · File sharing").setContentText(message).setOngoing(true).build()
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION, n)
    }

    private fun startHttp() {
        if (!alive.compareAndSet(false, true)) return
        worker = Thread {
            try {
                server = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(InetAddress.getByName("192.168.49.1"), port)) }
                while (alive.get()) {
                    val client = server?.accept() ?: break
                    Thread { handle(client) }.start()
                }
            } catch (_: Exception) { if (alive.get()) updateNotification("HTTP server could not start on port $port") }
        }.apply { name = "AGestureHttp"; isDaemon = true; start() }
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 10000
                val input = BufferedInputStream(s.getInputStream())
                val line = readLine(input) ?: return
                val parts = line.split(" ")
                val path = parts.getOrNull(1) ?: "/"
                while (true) { val h = readLine(input) ?: break; if (h.isEmpty()) break }
                val out = BufferedOutputStream(s.getOutputStream())
                if (path == "/" || path.startsWith("/?")) {
                    val html = page().toByteArray(Charsets.UTF_8)
                    headers(out, "200 OK", "text/html; charset=utf-8", html.size.toLong()); out.write(html); out.flush()
                } else if (path.startsWith("/download/")) {
                    val i = path.removePrefix("/download/").substringBefore('?').toIntOrNull()
                    val uri = i?.let { items.getOrNull(it) }
                    if (uri == null) { val b = "Not found".toByteArray(); headers(out,"404 Not Found","text/plain",b.size.toLong()); out.write(b) }
                    else {
                        val name = queryName(uri)
                        val stream = contentResolver.openInputStream(uri)
                        if (stream == null) { val b="Unavailable".toByteArray(); headers(out,"404 Not Found","text/plain",b.size.toLong()); out.write(b) }
                        else {
                            out.write("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Disposition: attachment; filename=\"${safe(name)}\"\r\nConnection: close\r\n\r\n".toByteArray())
                            stream.use { it.copyTo(out) }
                        }
                    }
                    out.flush()
                } else { val b="Not found".toByteArray(); headers(out,"404 Not Found","text/plain",b.size.toLong()); out.write(b); out.flush() }
            } catch (_: Exception) { }
        }
    }

    private fun page(): String {
        val rows = items.mapIndexed { i, uri ->
            val name = safe(queryName(uri))
            "<li><span>$name</span> <a class='filelink' href='/download/$i'>Download</a></li>"
        }.joinToString("\n")
        return """<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>A Gesture</title><style>body{font:16px system-ui;max-width:760px;margin:36px auto;padding:0 18px;background:#f5f7fb;color:#172033}main{background:white;padding:24px;border-radius:18px;box-shadow:0 4px 24px #0001}li{padding:14px 0;border-bottom:1px solid #ddd;display:flex;justify-content:space-between;gap:16px}a,button{background:#1769aa;color:white;padding:9px 14px;border:0;border-radius:9px;text-decoration:none;font:inherit}</style><script>function allFiles(){document.querySelectorAll('.filelink').forEach((a,i)=>setTimeout(()=>a.click(),i*900));}</script></head><body><main><h1>A Gesture</h1><p>Files shared from the other device</p><button onclick="allFiles()">Download all</button><ul>$rows</ul><small>Local connection only. This page lists only items the sender explicitly shared. Your browser may ask permission for multiple downloads.</small></main></body></html>"""
    }
    private fun queryName(uri: Uri): String = try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } ?: uri.lastPathSegment ?: "file" } catch (_: Exception) { uri.lastPathSegment ?: "file" }
    private fun safe(s: String) = s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;")
    private fun headers(out: OutputStream, status: String, type: String, size: Long) { out.write("HTTP/1.1 $status\r\nContent-Type: $type\r\nContent-Length: $size\r\nConnection: close\r\n\r\n".toByteArray()) }
    private fun readLine(input: BufferedInputStream): String? { val b=StringBuilder(); while (true) { val c=input.read(); if(c<0) return if(b.isEmpty()) null else b.toString(); if(c==10) break; if(c!=13 && b.length<8192) b.append(c.toChar()) }; return b.toString() }

    override fun onDestroy() {
        alive.set(false); try { server?.close() } catch (_: Exception) { }
        if (groupCreated) try { manager?.removeGroup(channel, object : WifiP2pManager.ActionListener { override fun onSuccess() {}; override fun onFailure(reason: Int) {} }) } catch (_: Exception) { }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
