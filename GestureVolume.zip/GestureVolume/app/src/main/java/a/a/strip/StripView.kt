package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.animation.ValueAnimator
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.floor
import kotlin.math.hypot

/**
 * The shortcut strip: a grid of cells drawn straight to the canvas.
 *
 * An icon costs nothing to keep: an emoji is a few bytes of text drawn by the system font, and an
 * app's icon is the drawable the package manager already holds, drawn in place and dropped with
 * this view when the finger lifts. No bitmaps, no animation, no Compose.
 *
 * It takes no touches of its own. The bar's window keeps the gesture and forwards the finger's
 * screen position to [setFinger]; this finds the cell under it and lights it.
 */
class StripView(
    context: Context,
    val items: List<StripItem>,
    val cellPx: Int,
    private val columns: Int,
    private val showLabels: Boolean,
    /** Columns run right to left, so cell 1 is nearest the right edge (for a bar on the left). */
    private val mirror: Boolean = false,
    /** A folder's window: reads its own look settings (see [LookPrefs]); any it does not have follow the cells window. */
    private val folderLook: Boolean = false,
    /** Where the look settings are read from: the main slider's (default) or a segment's own cells window. */
    prefs: android.content.SharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE),
    /** Option "+ in empty cells": a blank cell draws a "+" (and can be lit), so the thumb can land on it. */
    val plusEmpty: Boolean = false,
    /** Option "+ after the last cell": one more slot after the last cell, drawn as a "+". */
    val plusEnd: Boolean = false,
) : View(context) {

    /**
     * How the cells look (settings in the cells window): 0 = tiles as always, 1 = icons only (no tile, no panel,
     * icons bigger), 2 = icons only on a very faint dark panel. [halo] = a soft dark glow around every icon and
     * name so they read on any background colour.
     */
    private val look: Int
    private val backdropAlpha: Int
    /** Colour of the panel behind icons-only cells (0 = black). */
    private val backdropRgb: Int
    private val halo: Boolean
    /** The cells' own settings: tile colour (0 = the standard teal), icon size and the gap between cells, in percent. */
    private val tileColor: Int
    private val iconScale: Float
    private val gapPct: Int
    /** The names under the icons: size in percent (100 = as before) and an outline (colour 0 = none, width in percent of the text size). */
    private val labelMul: Float
    private val outlineColor: Int
    private val outlinePct: Int
    init {
        val sp = prefs
        fun k(name: String) = LookPrefs.readKey(sp, folderLook, name)
        look = sp.getInt(k("stripLook"), 0).coerceIn(0, 2)
        backdropAlpha = (sp.getInt(k("stripBackdropPct"), 18).coerceIn(0, 100) * 255 / 100)
        backdropRgb = sp.getInt(k("stripBackdropColor"), 0).let { if (it == 0) 0 else it and 0xFFFFFF }
        halo = sp.getBoolean(k("stripHalo"), false)
        tileColor = sp.getInt(k("stripTileColor"), 0)
        iconScale = sp.getInt(k("stripIconPct"), 100).coerceIn(50, 170) / 100f
        gapPct = sp.getInt(k("stripGapPct"), 8).coerceIn(0, 40)
        labelMul = sp.getInt(k("stripLabelPct"), 100).coerceIn(50, 200) / 100f
        outlineColor = sp.getInt(k("stripOutlineColor"), 0)
        outlinePct = sp.getInt(k("stripOutlinePct"), 14).coerceIn(4, 40)
    }
    /** Pinned cells: a small dot in the corner, or (instead) the cell's text in another colour. Same in folders. */
    private val pinDot: Boolean
    private val pinDotPx: Float
    private val pinDotColor: Int
    private val pinText: Boolean
    private val pinTextColor: Int
    private val pinCorner: Int
    private val pinDx: Float
    private val pinDy: Float
    init {
        val sp = prefs
        pinDot = sp.getBoolean("stripPinDot", true)
        pinDotPx = sp.getInt("stripPinDotPx", 5).coerceIn(1, 12) * context.resources.displayMetrics.density
        pinDotColor = sp.getInt("stripPinDotColor", 0xFFFF5252.toInt())
        pinText = sp.getBoolean("stripPinText", false)
        pinTextColor = sp.getInt("stripPinTextColor", 0xFFFFD600.toInt())
        pinCorner = sp.getInt("stripPinDotCorner", 0).coerceIn(0, 3)
        // Distance from the corner in dp; -1 = never chosen (the dot sits where it always did).
        val dens = context.resources.displayMetrics.density
        val hasD = sp.contains("stripPinDotX") || sp.contains("stripPinDotY")
        pinDx = if (hasD) sp.getInt("stripPinDotX", 3).coerceIn(0, 24) * dens else -1f
        pinDy = if (hasD) sp.getInt("stripPinDotY", 3).coerceIn(0, 24) * dens else -1f
    }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /**
     * The mark on a folder cell: on or off, shape, size (percent of the cell), colour (0 = the cell's text colour), corner and
     * distance from it. Same in folders. Never chosen = the small bottom-right triangle as always.
     */
    private val foldArrow: Boolean
    private val foldShape: Int
    private val foldPct: Int
    private val foldColor: Int
    private val foldCorner: Int
    private val foldDx: Float
    private val foldDy: Float
    /** What a folder cell shows: 0 = its own icon, 1 = the first four apps inside (unless it has an icon of its own), 2 = the four apps always. */
    private val foldPreview: Int
    private val foldPlate: Boolean
    /** Size of the four small apps inside a folder cell, as a fraction of the usual size (1 = as always). */
    private val foldMini: Float
    init {
        val sp = prefs
        val dens = context.resources.displayMetrics.density
        foldArrow = sp.getBoolean("stripFoldArrow", true)
        foldShape = sp.getInt("stripFoldArrowShape", 0).coerceIn(0, 5)
        foldPct = sp.getInt("stripFoldArrowPct", 20).coerceIn(8, 45)
        foldColor = sp.getInt("stripFoldArrowColor", 0)
        foldCorner = sp.getInt("stripFoldArrowCorner", 3).coerceIn(0, 3)
        val hasD = sp.contains("stripFoldArrowX") || sp.contains("stripFoldArrowY")
        foldDx = if (hasD) sp.getInt("stripFoldArrowX", 2).coerceIn(0, 40) * dens else -1f
        foldDy = if (hasD) sp.getInt("stripFoldArrowY", 2).coerceIn(0, 40) * dens else -1f
        foldPreview = sp.getInt("stripFoldPreview", 0).coerceIn(0, 2)
        foldPlate = sp.getBoolean("stripFoldPlate", true)
        foldMini = sp.getInt("stripFoldMiniPct", 100).coerceIn(40, 140) / 100f
    }
    private val arrowPath = android.graphics.Path()
    private val platePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    /** The small pictures of the first apps inside each folder, kept by position: folder index * 4 + n. */
    private val miniIcons = HashMap<Int, Bitmap?>()
    private val miniGlyphs = HashMap<Int, String>()
    private val miniNames = HashMap<Int, String>()
    private val plain get() = look != 0
    private val iconPx: Int get() = (cellPx * (if (plain) 0.95f else 0.8f) * maxOf(1f, iconScale)).toInt().coerceIn(32, 384)

    /** The cells plus, with the option on, the "+" slot after the last one. */
    private val slots = items.size + (if (plusEnd) 1 else 0)
    private val rows = ((slots + columns - 1) / columns).coerceAtLeast(1)
    private val gapPx = if (gapPct == 0) 0f else (cellPx * gapPct / 100f).coerceAtLeast(2f)

    private var originX = 0f
    private var originY = 0f

    /** The editor draws blank cells too, so one can be selected. */
    var editorMode = false

    /** The cell under the finger, or -1. */
    var hot = -1
        private set

    /**
     * Option "Swifty Switch style" (cells window settings): round touch zones around each cell and a
     * short fly-out when the window opens, as Swiftly Switch does it. Off = the usual behaviour.
     */
    private val swifty = prefs.getBoolean("stripSwifty", false)
    private val dpScale = context.resources.displayMetrics.density
    /** 1 = fully open. While the window opens it runs 0 to 1 (cells fly out from the middle and fade in). */
    private var openProgress = 1f
    private var openAnim: ValueAnimator? = null

    /** Swiftly Switch's opening: each cell starts halfway towards the middle, see-through, and settles in (decelerating). */
    fun startOpen(ms: Long) {
        if (!swifty) return
        openAnim?.cancel()
        openProgress = 0f
        openAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = DecelerateInterpolator(3f)
            addUpdateListener { openProgress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        openAnim?.cancel(); openAnim = null
        removeCallbacks(fadeStep); fadeRunning = false
        super.onDetachedFromWindow()
    }

    // Swiftly Switch's lighting: the cell's colour fades to the lit colour and back over ~100 ms instead of
    // jumping. Only with the option on; nothing runs once the fade has finished.
    private val amt = FloatArray(items.size + 1)
    private var fadeRunning = false
    private var fadeLastNs = 0L
    private val fadeStep = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val d = ((now - fadeLastNs) / 1_000_000f).coerceIn(0f, 50f) / 100f
            fadeLastNs = now
            var busy = false
            for (i in amt.indices) {
                val target = if (i == hot) 1f else 0f
                val a = amt[i]
                if (a != target) {
                    amt[i] = if (a < target) minOf(target, a + d) else maxOf(target, a - d)
                    busy = true
                }
            }
            invalidate()
            if (busy) postOnAnimation(this) else fadeRunning = false
        }
    }

    private fun startFade() {
        if (!swifty || fadeRunning) return
        fadeRunning = true
        fadeLastNs = System.nanoTime()
        postOnAnimation(fadeStep)
    }

    private fun litAmount(i: Int): Float =
        if (i in marked) 1f else if (!swifty) (if (i == hot) 1f else 0f) else amt.getOrElse(i) { 0f }

    private val fadePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val appIcons = HashMap<String, Bitmap?>()
    private val imgIcons = HashMap<String, Bitmap?>()
    /** After a release: the one cell that stays on screen, so the shortcut that ran can be seen. */
    private var only = -1
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val backdropPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (tileColor != 0) tileColor else 0xFF1F8A8A.toInt() }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3638.toInt() }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val rect2 = RectF()

    val panelWidthPx: Int get() = (columns * cellPx + gapPx * (columns + 1)).toInt()
    val panelHeightPx: Int get() = (rows * cellPx + gapPx * (rows + 1)).toInt()

    init {
        val pm = context.packageManager
        // Option "Keep the icons ready" (cells window settings): seconds the drawn icons are kept; 0 = off.
        val keepSec = prefs.getInt("stripIconKeepSec", 300).coerceIn(0, 3600)
        for (item in items) {
            val f = item.iconFile ?: continue
            if (f !in imgIcons) imgIcons[f] = runCatching {
                val file = java.io.File(context.filesDir, "sicons/$f")
                val px = iconPx
                IconCache.get("f:$f:$px:${file.lastModified()}", keepSec) {
                    val raw = android.graphics.BitmapFactory.decodeFile(file.path)
                    raw?.let { Bitmap.createScaledBitmap(it, px, px, true) }
                }
            }.getOrNull()
        }
        for (item in items) {
            val pkg = item.appIconPackage ?: continue
            if (pkg !in appIcons) appIcons[pkg] = runCatching {
                // Drawn once into a plain bitmap: an adaptive icon drawn straight onto the (hardware)
                // canvas, one shared drawable re-bounded for every cell, left black patches while moving.
                val px = iconPx
                IconCache.get("p:$pkg:$px", keepSec) {
                    val d = pm.getApplicationIcon(pkg)
                    Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888).also { bmp ->
                        val c = Canvas(bmp)
                        d.setBounds(0, 0, px, px)
                        d.draw(c)
                    }
                }
            }.getOrNull()
        }
        // The first four apps inside every folder that shows them: drawn once, small, kept like the other icons.
        for ((fi, item) in items.withIndex()) {
            if (!showsPreview(item)) continue
            val kids = item.children ?: continue
            val mini = (iconPx * 0.5f * maxOf(1f, foldMini)).toInt().coerceIn(16, 256)
            for (n in 0 until minOf(4, kids.size)) {
                val kid = kids[n]
                val key = fi * 4 + n
                // Same choice as the cell itself: no icon -> the typed name fills the little square;
                // app / picture -> that icon; emoji -> the emoji; anything that cannot be drawn -> the name.
                val kpkg = if (kid.icon == FitText.NONE) null else kid.appIconPackage
                val kfile = if (kid.icon == FitText.NONE) null else kid.iconFile
                if (kpkg != null) {
                    miniIcons[key] = runCatching {
                        IconCache.get("p:$kpkg:$mini", keepSec) {
                            val d = pm.getApplicationIcon(kpkg)
                            Bitmap.createBitmap(mini, mini, Bitmap.Config.ARGB_8888).also { bmp ->
                                val c = Canvas(bmp)
                                d.setBounds(0, 0, mini, mini)
                                d.draw(c)
                            }
                        }
                    }.getOrNull()
                } else if (kfile != null) {
                    miniIcons[key] = runCatching {
                        val file = java.io.File(context.filesDir, "sicons/$kfile")
                        IconCache.get("f:$kfile:$mini:${file.lastModified()}", keepSec) {
                            val raw = android.graphics.BitmapFactory.decodeFile(file.path)
                            raw?.let { Bitmap.createScaledBitmap(it, mini, mini, true) }
                        }
                    }.getOrNull()
                } else if (kid.icon.isNotEmpty() && kid.icon != FitText.NONE) {
                    val g = if (textPaint.hasGlyph(kid.icon)) kid.icon
                    else (SUBSTITUTE[kid.icon]?.takeIf { textPaint.hasGlyph(it) } ?: "")
                    if (g.isNotEmpty()) miniGlyphs[key] = g
                }
                if (miniIcons[key] == null && miniGlyphs[key] == null) miniNames[key] = kid.label
            }
        }
    }

    /** Whether this folder cell is drawn as the four apps inside it. */
    private fun showsPreview(item: StripItem): Boolean =
        item.isFolder && item.icon != FitText.NONE &&
            (foldPreview == 2 || (foldPreview == 1 && item.icon.isEmpty() && item.iconFile == null))

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelWidthPx, panelHeightPx)
    }

    /** Where this panel sits on the screen, for telling which side of it the finger left by. */
    fun screenBounds(): android.graphics.RectF = android.graphics.RectF(originX, originY, originX + panelWidthPx, originY + panelHeightPx)

    fun setScreenOrigin(x: Float, y: Float) {
        originX = x
        originY = y
    }

    /** The cell at a screen position, or -1 for a gap, the margin or outside the panel. */
    fun cellAt(rawX: Float, rawY: Float): Int {
        if (swifty) return swiftyCellAt(rawX, rawY)
        val x = rawX - originX - gapPx
        val y = rawY - originY - gapPx
        if (x < 0f || y < 0f) return -1
        val step = cellPx + gapPx
        val col = floor(x / step).toInt()
        val row = floor(y / step).toInt()
        if (col !in 0 until columns || row !in 0 until rows) return -1
        val dataCol = if (mirror) columns - 1 - col else col
        if (x - col * step > cellPx || y - row * step > cellPx) {
            return hot.takeIf { it >= 0 && it == row * columns + dataCol } ?: -1
        }
        val index = row * columns + dataCol
        return if (index < items.size) index else -1
    }

    /**
     * Swiftly Switch's way of finding the cell: a round zone around each cell's middle (radius 35 dp, or
     * half the cell when that is bigger), the first cell in column order whose zone holds the finger.
     * Between the zones nothing is lit.
     */
    private fun swiftyCellAt(rawX: Float, rawY: Float): Int {
        val step = cellPx + gapPx
        val r = maxOf(35f * dpScale, cellPx / 2f)
        for (col in 0 until columns) {
            val cx = originX + gapPx + col * step + cellPx / 2f
            for (row in 0 until rows) {
                val dataCol = if (mirror) columns - 1 - col else col
                val index = row * columns + dataCol
                if (index >= items.size) continue
                val cy = originY + gapPx + row * step + cellPx / 2f
                if (hypot(rawX - cx, rawY - cy) <= r) return index
            }
        }
        return -1
    }

    /** Whether a screen position is inside this panel (gaps and margin included). */
    fun contains(rawX: Float, rawY: Float): Boolean =
        rawX >= originX && rawY >= originY && rawX < originX + panelWidthPx && rawY < originY + panelHeightPx

    fun clearHot() {
        if (hot != -1 || endHot) { hot = -1; endHot = false; invalidate() }
    }

    /** The thumb is on the "+" slot after the last cell (the slot is not a cell, so [hot] stays -1 there). */
    var endHot = false
        private set

    /** Whether a screen position is on the "+" slot after the last cell. Always false with the option off. */
    fun endSlotAt(rawX: Float, rawY: Float): Boolean {
        if (!plusEnd) return false
        val step = cellPx + gapPx
        val col: Int
        val row: Int
        val dataCol = items.size % columns
        row = items.size / columns
        col = if (mirror) columns - 1 - dataCol else dataCol
        val left = originX + gapPx + col * step
        val top = originY + gapPx + row * step
        if (swifty) {
            val r = maxOf(35f * dpScale, cellPx / 2f)
            return hypot(rawX - (left + cellPx / 2f), rawY - (top + cellPx / 2f)) <= r
        }
        return rawX >= left && rawX <= left + cellPx && rawY >= top && rawY <= top + cellPx
    }

    /** Where cell [index] is on the screen (the same frame as [screenBounds]). */
    fun cellScreenRect(index: Int): RectF {
        val col = if (mirror) columns - 1 - index % columns else index % columns
        val row = index / columns
        val left = originX + gapPx + col * (cellPx + gapPx)
        val top = originY + gapPx + row * (cellPx + gapPx)
        return RectF(left, top, left + cellPx, top + cellPx)
    }

    /** Draws one cell, lit, scaled to [sizePx], for the thumb popup. The same icon and name as in the panel. */
    fun drawTile(canvas: Canvas, index: Int, sizePx: Float) {
        val item = items.getOrNull(index) ?: return
        val s = sizePx / cellPx
        val box = RectF(0f, 0f, cellPx.toFloat(), cellPx.toFloat())
        canvas.save()
        canvas.scale(s, s)
        canvas.drawRoundRect(box, cellPx * 0.22f, cellPx * 0.22f, hotPaint)
        drawItem(canvas, item, index, box, 0xFF000000.toInt(), false, false)
        canvas.restore()
    }

    /** Which sides of the panel glow (bit 1 top, 2 left, 4 bottom, 8 right): the side whose outside action is about to run. */
    private var glow = 0
    fun setGlow(mask: Int) { if (mask != glow) { glow = mask; invalidate() } }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }

    /** The editor's multi-selection (and the cells being dragged). */
    private var marked: Set<Int> = emptySet()
    fun setMarked(set: Set<Int>) { if (set != marked) { marked = set; invalidate() } }

    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val markPath = android.graphics.Path()

    /** Lights one cell without a finger, for the editor's selection. */
    fun highlight(index: Int) {
        if (hot == index) return
        hot = index
        startFade()
        invalidate()
    }

    fun keepOnly(index: Int) {
        only = index
        hot = index
        if (index in amt.indices) amt[index] = 1f
        invalidate()
    }

    fun setFinger(rawX: Float, rawY: Float) {
        val next = cellAt(rawX, rawY)
        val end = next < 0 && endSlotAt(rawX, rawY)
        if (next == hot && end == endHot) return
        hot = next
        endHot = end
        startFade()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        if (only < 0) when (look) {
            0 -> canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, panelPaint)
            2 -> canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, backdropPaint.apply { color = (backdropAlpha shl 24) or backdropRgb })
        }
        val radius = cellPx * 0.22f
        for (i in 0 until slots) {
            val isEnd = i >= items.size
            val item = if (isEnd) endBlank else items[i]
            val col = if (mirror) columns - 1 - i % columns else i % columns
            val row = i / columns
            val left = gapPx + col * (cellPx + gapPx)
            val top = gapPx + row * (cellPx + gapPx)
            val opening = openProgress < 1f
            var saved = -1
            if (opening) {
                val k = (1f - openProgress) * 0.5f
                canvas.save()
                canvas.translate((width / 2f - (left + cellPx / 2f)) * k, (height / 2f - (top + cellPx / 2f)) * k)
                val m = cellPx * 0.3f
                saved = canvas.saveLayerAlpha(left - m, top - m, left + cellPx + m, top + cellPx + m, (openProgress * 255).toInt().coerceIn(0, 255))
            }
            try {
            rect.set(left, top, left + cellPx, top + cellPx)
            val blank = item.action.isEmpty() && item.label.isEmpty() && item.icon.isEmpty()
            if (blank && only < 0 && (editorMode || isEnd || plusEmpty)) {
                // In the editor a blank cell is shown, so it can be seen and selected. With "+ in empty cells" a blank
                // cell is shown with a "+" in the window too; the slot after the last cell is always a "+".
                val litBlank = if (isEnd) endHot else (i == hot || i in marked)
                if (!plain || editorMode || litBlank) canvas.drawRoundRect(rect, radius, radius, if (litBlank) hotPaint else emptyPaint)
                if (isEnd || plusEmpty) drawPlus(canvas, rect, if (litBlank) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                continue
            }
            if (blank || (only >= 0 && i != only)) continue
            val a = litAmount(i)
            val lit = a >= 0.5f
            // Icons-only looks: no tile behind a cell, except the lit one so the finger's cell still shows.
            val baseTile = if (item.action.isNotEmpty()) cellPaint.color else emptyPaint.color
            val baseInk = if (item.pinned && pinText) pinTextColor else 0xFFFFFFFF.toInt()
            if (!swifty || a <= 0f || a >= 1f) {
                if (!plain || lit) canvas.drawRoundRect(
                    rect, radius, radius,
                    when {
                        lit -> hotPaint
                        item.action.isNotEmpty() -> cellPaint
                        else -> emptyPaint
                    }
                )
            } else if (plain) {
                fadePaint.color = hotPaint.color
                fadePaint.alpha = (a * 255).toInt()
                canvas.drawRoundRect(rect, radius, radius, fadePaint)
            } else {
                fadePaint.color = androidx.core.graphics.ColorUtils.blendARGB(baseTile, hotPaint.color, a)
                canvas.drawRoundRect(rect, radius, radius, fadePaint)
            }
            val ink = if (swifty && a > 0f && a < 1f) androidx.core.graphics.ColorUtils.blendARGB(baseInk, 0xFF000000.toInt(), a)
                else if (lit) 0xFF000000.toInt() else baseInk
            drawItem(canvas, item, i, rect, ink, halo && !lit, !lit)
            if (item.pinned && pinDot) {
                val r = pinDotPx / 2f
                val inset = maxOf(r, cellPx * 0.06f)
                val dx = if (pinDx < 0f) inset + r * 0.2f else pinDx + r
                val dy = if (pinDy < 0f) inset + r * 0.2f else pinDy + r
                val cx = if (pinCorner == 1 || pinCorner == 3) rect.right - dx else rect.left + dx
                val cy = if (pinCorner >= 2) rect.bottom - dy else rect.top + dy
                pinPaint.color = pinDotColor
                canvas.drawCircle(cx, cy, r, pinPaint)
            }
            if (item.isFolder && foldArrow) drawFolderArrow(canvas, rect, ink)
            } finally {
                if (opening) { canvas.restoreToCount(saved); canvas.restore() }
            }
        }
        if (glow != 0) drawGlow(canvas)
    }

    /** The blank item the "+" slot after the last cell stands for (never part of [items]). */
    private val endBlank = StripItem("", "", "")
    private val plusPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** A "+" in the middle of [box]. */
    private fun drawPlus(canvas: Canvas, box: RectF, color: Int) {
        plusPaint.color = color
        plusPaint.strokeWidth = (cellPx * 0.07f).coerceAtLeast(2f)
        val cx = box.centerX()
        val cy = box.centerY()
        val h = cellPx * 0.2f
        canvas.drawLine(cx - h, cy, cx + h, cy, plusPaint)
        canvas.drawLine(cx, cy - h, cx, cy + h, plusPaint)
    }

    private fun drawGlow(canvas: Canvas) {
        val t = (cellPx * 0.1f).coerceAtLeast(4f)
        val w = width.toFloat(); val h = height.toFloat()
        if (glow and 1 != 0) canvas.drawRect(0f, 0f, w, t, glowPaint)
        if (glow and 2 != 0) canvas.drawRect(0f, 0f, t, h, glowPaint)
        if (glow and 4 != 0) canvas.drawRect(0f, h - t, w, h, glowPaint)
        if (glow and 8 != 0) canvas.drawRect(w - t, 0f, w, h, glowPaint)
    }

    private val fitPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val haloBlur = HashMap<Bitmap, Pair<Bitmap, IntArray>>()

    /** The soft dark glow of an icon picture: its own outline, blurred. Made once per picture. */
    private fun haloOf(bmp: Bitmap): Pair<Bitmap, IntArray> = haloBlur.getOrPut(bmp) {
        val off = IntArray(2)
        val p = Paint().apply { maskFilter = android.graphics.BlurMaskFilter((bmp.width * 0.07f).coerceAtLeast(2f), android.graphics.BlurMaskFilter.Blur.NORMAL) }
        bmp.extractAlpha(p, off) to off
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }

    private fun drawItem(canvas: Canvas, item: StripItem, index: Int, box: RectF, ink: Int, glow: Boolean, outline: Boolean) {
        if (item.icon == FitText.NONE) {
            // No icon: what was typed fills the cell, up to three lines, no name underneath.
            if (glow) fitPaint.setShadowLayer(cellPx * 0.07f, 0f, 0f, 0xE6000000.toInt()) else fitPaint.clearShadowLayer()
            FitText.draw(canvas, fitPaint, item.label, box, ink, if (outline) outlineColor else 0, outlinePct)
            return
        }
        val appIcon = item.appIconPackage?.let { appIcons[it] } ?: item.iconFile?.let { imgIcons[it] }
        // An emoji this phone's font cannot draw (a newer one) would show as an empty box: try a
        // close older one, else fall back to the name.
        val glyph = if (item.icon.isEmpty() || item.appIconPackage != null || item.iconFile != null) item.icon
        else if (textPaint.hasGlyph(item.icon)) item.icon else (SUBSTITUTE[item.icon]?.takeIf { textPaint.hasGlyph(it) } ?: "")
        val preview = showsPreview(item)
        val hasIcon = appIcon != null || (glyph.isNotEmpty() && item.appIconPackage == null && item.iconFile == null)
        if (!hasIcon && !preview) {
            if (glow) textPaint.setShadowLayer(cellPx * 0.06f, 0f, 0f, 0xE6000000.toInt()) else textPaint.clearShadowLayer()
            drawLabel(canvas, item.label, box, box.centerY(), 0.24f, ink, outline)
            textPaint.clearShadowLayer()
            return
        }
        val labelled = showLabels && item.label.isNotEmpty()
        val iconBox = (if (plain) { if (labelled) box.height() * 0.72f else box.height() * 0.9f } else if (labelled) box.height() * 0.66f else box.height() * 0.78f) * iconScale
        // A bigger name pushes the icon up a little and the name down a little, so they do not touch.
        val bigger = (labelMul - 1f).coerceAtLeast(0f)
        val cy = if (labelled) box.top + box.height() * (0.38f - bigger * 0.06f) else box.centerY()
        if (preview) {
            drawFolderPreview(canvas, item, index, box.centerX(), cy, iconBox, ink)
        } else if (appIcon != null) {
            val half = (iconBox / 2f).toInt()
            rect2.set(box.centerX() - half, cy - half, box.centerX() + half, cy + half)
            if (glow) {
                val (h, off) = haloOf(appIcon)
                val k = rect2.width() / appIcon.width
                val l = rect2.left + off[0] * k; val t = rect2.top + off[1] * k
                canvas.drawBitmap(h, null, RectF(l, t, l + h.width * k, t + h.height * k), haloPaint)
            }
            canvas.drawBitmap(appIcon, null, rect2, bitmapPaint)
        } else {
            textPaint.color = 0xFFFFFFFF.toInt()
            textPaint.textSize = iconBox * 0.86f
            val y = cy - (textPaint.descent() + textPaint.ascent()) / 2f
            if (glow) textPaint.setShadowLayer(cellPx * 0.06f, 0f, 0f, 0xE6000000.toInt())
            canvas.drawText(glyph, box.centerX(), y, textPaint)
            textPaint.clearShadowLayer()
        }
        if (labelled) {
            if (glow) textPaint.setShadowLayer(cellPx * 0.05f, 0f, 0f, 0xE6000000.toInt())
            drawLabel(canvas, item.label, box, box.top + box.height() * (0.86f + bigger * 0.04f).coerceAtMost(0.9f), 0.17f, ink, outline)
            textPaint.clearShadowLayer()
        }
    }

    /** The four apps inside a folder as a 2 x 2 picture of the real icons, on a soft plate. */
    private fun drawFolderPreview(canvas: Canvas, item: StripItem, index: Int, cx: Float, cy: Float, size: Float, ink: Int) {
        val padBase = size * 0.09f
        val gapBase = size * 0.06f
        // The four icons: usual size times the user's choice, kept in the middle of the picture.
        val cell = (size - padBase * 2f - gapBase) / 2f * foldMini
        val gap = gapBase * foldMini
        val group = cell * 2f + gap
        // The plate keeps its usual size when the icons are made smaller, and grows with them when they are made bigger.
        val plateSize = maxOf(size, group + padBase * 2f)
        if (foldPlate) {
            val pl = cx - plateSize / 2f; val pt = cy - plateSize / 2f
            platePaint.color = if (ink == 0xFF000000.toInt()) 0x30000000 else 0x40FFFFFF
            canvas.drawRoundRect(pl, pt, pl + plateSize, pt + plateSize, plateSize * 0.24f, plateSize * 0.24f, platePaint)
        }
        val left = cx - group / 2f; val top = cy - group / 2f
        val kids = item.children ?: return
        for (n in 0 until minOf(4, kids.size)) {
            val l = left + (n % 2) * (cell + gap)
            val t = top + (n / 2) * (cell + gap)
            val bmp = miniIcons[index * 4 + n]
            if (bmp != null) {
                rect2.set(l, t, l + cell, t + cell)
                canvas.drawBitmap(bmp, null, rect2, bitmapPaint)
            } else {
                val g = miniGlyphs[index * 4 + n]
                if (g != null) {
                    textPaint.color = ink
                    textPaint.textSize = cell * 0.8f
                    val y = t + cell / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
                    canvas.drawText(g, l + cell / 2f, y, textPaint)
                } else {
                    val name = miniNames[index * 4 + n] ?: continue
                    if (name.isNotEmpty()) {
                        fitPaint.clearShadowLayer()
                        FitText.draw(canvas, fitPaint, name, RectF(l, t, l + cell, t + cell), ink, outlineColor, outlinePct)
                    }
                }
            }
        }
    }

    /** The folder mark, in the shape, size, colour and place the user chose (Look of the cells). */
    private fun drawFolderArrow(canvas: Canvas, rect: RectF, ink: Int) {
        val m = cellPx * foldPct / 100f
        val r = m / 2f
        val dflt = cellPx * 0.06f
        val dx = if (foldDx < 0f) dflt else foldDx
        val dy = if (foldDy < 0f) dflt else foldDy
        val right = foldCorner == 1 || foldCorner == 3
        val bottom = foldCorner >= 2
        val x0 = if (right) rect.right - dx - m else rect.left + dx
        val y0 = if (bottom) rect.bottom - dy - m else rect.top + dy
        markPaint.color = if (foldColor != 0) foldColor else ink
        markPaint.style = Paint.Style.FILL
        when (foldShape) {
            0 -> {
                // Triangle with its right angle in the chosen corner.
                val ax = if (right) x0 + m else x0
                val ay = if (bottom) y0 + m else y0
                val bx = if (right) x0 else x0 + m
                val cy2 = if (bottom) y0 else y0 + m
                arrowPath.reset()
                arrowPath.moveTo(ax, ay)
                arrowPath.lineTo(bx, ay)
                arrowPath.lineTo(ax, cy2)
                arrowPath.close()
                canvas.drawPath(arrowPath, markPaint)
            }
            1 -> canvas.drawCircle(x0 + r, y0 + r, r * 0.8f, markPaint)
            2 -> canvas.drawRoundRect(x0 + m * 0.1f, y0 + m * 0.1f, x0 + m * 0.9f, y0 + m * 0.9f, m * 0.12f, m * 0.12f, markPaint)
            3 -> {
                // A right-pointing arrow head (opens a folder to the side).
                arrowPath.reset()
                arrowPath.moveTo(x0 + m * 0.25f, y0 + m * 0.1f)
                arrowPath.lineTo(x0 + m * 0.85f, y0 + r)
                arrowPath.lineTo(x0 + m * 0.25f, y0 + m * 0.9f)
                arrowPath.close()
                canvas.drawPath(arrowPath, markPaint)
            }
            4 -> {
                // A down-pointing arrow head.
                arrowPath.reset()
                arrowPath.moveTo(x0 + m * 0.1f, y0 + m * 0.25f)
                arrowPath.lineTo(x0 + m * 0.9f, y0 + m * 0.25f)
                arrowPath.lineTo(x0 + r, y0 + m * 0.85f)
                arrowPath.close()
                canvas.drawPath(arrowPath, markPaint)
            }
            else -> {
                arrowPath.reset()
                arrowPath.moveTo(x0 + r, y0 + m * 0.05f)
                arrowPath.lineTo(x0 + m * 0.95f, y0 + r)
                arrowPath.lineTo(x0 + r, y0 + m * 0.95f)
                arrowPath.lineTo(x0 + m * 0.05f, y0 + r)
                arrowPath.close()
                canvas.drawPath(arrowPath, markPaint)
            }
        }
    }

    private fun drawLabel(canvas: Canvas, label: String, box: RectF, centerY: Float, scale: Float, color: Int, outline: Boolean) {
        if (label.isEmpty()) return
        textPaint.color = color
        val base = cellPx * scale * labelMul
        textPaint.textSize = base
        // A long name is shrunk to fit; a bigger name may reach a little into the gaps.
        val room = box.width() * (0.92f + (labelMul - 1f).coerceAtLeast(0f) * 0.3f)
        val wide = textPaint.measureText(label)
        if (wide > room) textPaint.textSize = base * room / wide
        val y = centerY - (textPaint.descent() + textPaint.ascent()) / 2f
        if (outline && outlineColor != 0) {
            // The outline first (a thick stroke in the user's colour), the letters on top.
            textPaint.style = Paint.Style.STROKE
            textPaint.strokeJoin = Paint.Join.ROUND
            textPaint.strokeWidth = textPaint.textSize * outlinePct / 100f
            textPaint.color = outlineColor
            canvas.drawText(label, box.centerX(), y, textPaint)
            textPaint.style = Paint.Style.FILL
            textPaint.color = color
        }
        canvas.drawText(label, box.centerX(), y, textPaint)
    }

    private companion object {
        /** Newer emoji and the older look-alike that every phone can draw. */
        val SUBSTITUTE = mapOf(
            "\uD83D\uDEDC" to "\uD83D\uDCF6", "\uD83E\uDEAB" to "\uD83D\uDD0B", "\uD83E\uDEAA" to "\uD83D\uDEAA",
            "\uD83E\uDEE0" to "\uD83D\uDE42", "\uD83E\uDEE1" to "\uD83D\uDE42", "\uD83E\uDEE5" to "\uD83D\uDE36",
            "\uD83E\uDEE8" to "\uD83D\uDE2E", "\uD83E\uDEF6" to "\u2764\uFE0F", "\uD83E\uDEF0" to "\uD83D\uDC4D",
        )
    }
}
