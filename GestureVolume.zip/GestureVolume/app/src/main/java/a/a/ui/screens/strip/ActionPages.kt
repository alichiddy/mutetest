package a.a.ui.screens.strip

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import a.a.flow.FlowStore
import a.a.flow.NativePicker
import a.a.ui.screens.deck.AppKinds
import a.a.utils.ActionIcon
import a.a.utils.DeviceActionIcons
import a.a.ui.components.ActionIconImage
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import a.a.strip.ActionSaver
import a.a.strip.StripItem
import a.a.strip.ShortcutTools
import a.a.strip.StripConfig
import a.a.strip.SettingsBackup

/** This picker's own choice of app kinds (User, User hidden/disabled, System, System hidden/disabled). */
private const val OPEN_APP_KINDS_KEY = "openAppKinds"

/**
 * True when [pkg] is hidden, disabled, frozen or removed, judged the same way the All Apps window judges it:
 * such an app has no launcher entry to start, so it is opened through Hail. Blocking but quick; called on a tap.
 */
private fun appIsOff(context: android.content.Context, pkg: String): Boolean {
    val pm = context.packageManager
    val flags = android.content.pm.PackageManager.MATCH_DISABLED_COMPONENTS or android.content.pm.PackageManager.MATCH_UNINSTALLED_PACKAGES
    val ai = runCatching { pm.getApplicationInfo(pkg, flags) }.getOrNull() ?: return false
    @Suppress("DEPRECATION")
    val visible: Set<String>? = runCatching { pm.getInstalledApplications(0).map { it.packageName }.toHashSet() }.getOrNull()
    return AppKinds.isOff(pm, ai, visible)
}

/** A's own windows, offered as one group at the top of the built-in shortcuts. */
val WINDOW_ACTIONS: List<String> = listOf(
    HandlerActions.OPEN_CELLS, HandlerActions.GITHUB_SETTINGS, HandlerActions.OPEN_SEGMENTS, HandlerActions.SHELL_RUNNER, HandlerActions.LAUNCHER_MODE, HandlerActions.ALL_APPS, HandlerActions.WIFI_SHARE,
    HandlerActions.SCRIPTS_WINDOW, HandlerActions.WIDGETS_WINDOW, HandlerActions.FLOAT_NOTES, HandlerActions.FLOAT_GALLERY,
)

/**
 * The built-in shortcuts list used everywhere an action is chosen (cell editor, segment gestures,
 * the picker other apps see): a search box, "A Windows Shortcuts" first, then the rest, each with its icon.
 *
 * The device actions (Wi-Fi, flashlight, lock, airplane, network...) are part of the same list, so
 * one search finds anything. Picking one asks for its mode (On / Off / Toggle) and then calls
 * [onPickAction] with the action text, its name and its icon; leave [onPickAction] out to list only the others.
 */
@Composable
fun BuiltInPage(
    modifier: Modifier = Modifier,
    onPick: (HandlerActionCatalog.Entry, String) -> Unit,
    onBack: () -> Unit,
    onPickAction: ((action: String, name: String, icon: ActionIcon) -> Unit)? = null,
    /**
     * When set, "Open an app" is the first row of the list; picking an app calls this with the app, the
     * milliseconds to stay before going back (-1 = stay open) and the action to store: "Launch app:" for an
     * app that is on, Hail's own intent for a hidden, disabled or frozen one (same as the All Apps window).
     */
    onPickApp: ((a.a.ui.screens.deck.InstalledApp, Int, String) -> Unit)? = null,
) {
    val context = LocalContext.current
    // A tap on a shortcut first offers Test / Add to launcher / Use (Use = what the tap did before).
    class Gate(val label: String, val icon: String, val action: String, val go: () -> Unit)
    var gate by remember { mutableStateOf<Gate?>(null) }
    gate?.let { g -> ShortcutGateDialog(g.label, g.icon, g.action, onUse = { gate = null; g.go() }, onDismiss = { gate = null }) }
    // Option "ask when picking" (off by default): off = the tap picks at once, as before.
    fun openGate(g: Gate) { if (ShortcutTools.askOnPick(context)) gate = g else g.go() }
    var query by remember { mutableStateOf("") }
    var windows by remember { mutableStateOf(false) }
    var pickingApp by remember { mutableStateOf(false) }
    var pendingApp by remember { mutableStateOf<a.a.ui.screens.deck.InstalledApp?>(null) }
    var backText by remember { mutableStateOf("1500") }
    var goBack by remember { mutableStateOf(false) }
    if (pickingApp && onPickApp != null) {
        // The same four filters and the same list as the All Apps window (this picker keeps its own choice of kinds).
        AppList(
            onPick = { app ->
                pickingApp = false
                val plain = app.copy(label = plainAppLabel(app.label))
                if (appIsOff(context, app.packageName)) {
                    // Hidden, disabled, frozen or removed: only Hail can wake and open it, so there is nothing to ask.
                    val act = ActionSaver.hailAction(app.packageName)
                    openGate(Gate(plain.label, "", act) { onPickApp(plain, -1, act) })
                } else pendingApp = plain
            },
            onBack = { pickingApp = false },
            everything = true,
            kindFilter = true,
            kindKey = OPEN_APP_KINDS_KEY,
        )
        return
    }
    // The question after picking an app that is on. It is drawn over the shortcuts list (the list it came from
    // is not showing any more), so it has to live outside the branch above or it never appears.
    pendingApp?.let { app ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingApp = null },
            title = { Text(app.label) },
            text = {
                Column {
                    Row(Modifier.fillMaxWidth().clickable { goBack = false }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(selected = !goBack, onClick = { goBack = false })
                        Text("Stay open")
                    }
                    Row(Modifier.fillMaxWidth().clickable { goBack = true }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(selected = goBack, onClick = { goBack = true })
                        Text("Go back after a time")
                    }
                    if (goBack) OutlinedTextField(
                        value = backText, onValueChange = { backText = it.filter(Char::isDigit).take(6) }, singleLine = true,
                        label = { Text("Milliseconds in the app (1000 = 1 s)") }, modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingApp = null
                    val backMs = if (goBack) (backText.toIntOrNull() ?: 1500) else -1
                    val act = HandlerActions.launchApp(app.packageName, backMs)
                    openGate(Gate(app.label, "", act) { onPickApp?.invoke(app, backMs, act) })
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { pendingApp = null }) { Text("Cancel") } },
        )
    }
    val all = remember {
        HandlerActionCatalog.ALL.filter {
            it.action != HandlerActions.NONE && it.action != HandlerActions.REPOSITION && it.action != HandlerActions.LAUNCH_APP && it.action !in HandlerActionCatalog.HIDDEN
        }.map { it to context.getString(it.labelRes) }
    }
    val devices = remember(onPickAction != null) {
        if (onPickAction == null) emptyList() else NativePicker.groups().map { it to ActionIcon.Vector(DeviceActionIcons.forTitle(it.title)) }
    }
    val q = query.trim().lowercase()
    val shownBuilt = when {
        q.isNotEmpty() -> all.filter { it.second.lowercase().contains(q) }
        windows -> WINDOW_ACTIONS.mapNotNull { a -> all.firstOrNull { it.first.action == a } }
        else -> all.filter { it.first.action !in WINDOW_ACTIONS }
    }
    val shownDevices = when {
        q.isNotEmpty() -> devices.filter { it.first.title.lowercase().contains(q) }
        windows -> emptyList()
        else -> devices
    }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search (lock, Wi-Fi, flashlight, screenshot…)") }, modifier = Modifier.fillMaxWidth(),
        )
        if (q.isEmpty()) TextButton(onClick = { windows = !windows }) {
            Text(if (windows) "⬅ All built-in shortcuts" else "A Windows Shortcuts  ›")
        }
        LazyColumn(Modifier.weight(1f)) {
            if (onPickApp != null && !windows && (q.isEmpty() || "open an app".contains(q) || "app".startsWith(q))) item {
                Row(
                    Modifier.fillMaxWidth().clickable { pickingApp = true }.padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    HandlerActionCatalog.entryFor(HandlerActions.LAUNCH_APP)?.let { ActionIconImage(it.icon, null, Modifier.size(28.dp)) }
                        ?: Spacer(Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text("Open an app")
                }
            }
            items(shownBuilt) { (entry, name) ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        openGate(Gate(name, BuiltInIcons.save(context, entry.icon, entry.action).orEmpty(), entry.action) { onPick(entry, name) })
                    }.padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ActionIconImage(entry.icon, null, Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(name)
                }
            }
            items(shownDevices) { (group, icon) ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        NativePicker.choose(context, group) { action, name ->
                            openGate(Gate(name, BuiltInIcons.save(context, icon, action).orEmpty(), action) { onPickAction?.invoke(action, name, icon) })
                        }
                    }.padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ActionIconImage(icon, null, Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(group.title)
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}

/** My Scripts: the cells that have an action, and the scripts, with a search box. */
@Composable
fun MyScriptsPage(modifier: Modifier = Modifier, onPick: (label: String, action: String, cell: StripItem?) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    class Row2(val label: String, val action: String, val cell: StripItem?)
    var gate by remember { mutableStateOf<Row2?>(null) }
    gate?.let { g ->
        ShortcutGateDialog(g.label.removePrefix("Script: "), g.cell?.icon.orEmpty(), g.action, onUse = { gate = null; onPick(g.label, g.action, g.cell) }, onDismiss = { gate = null })
    }
    // Read off the main thread, and the scripts in one pass: with many scripts the old way (one full read
    // of every script for each script listed) froze the window long enough for Android to call it not responding.
    val loaded by androidx.compose.runtime.produceState<List<Row2>?>(null) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            val prefs = context.getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE)
            val cfg = StripConfig.load(context, prefs.getString(SettingsBackup.STRIP_KEY, null))
            val list = ArrayList<Row2>()
            for (cell in cfg.items) if (cell.action.isNotEmpty()) list += Row2(cell.label.replace('\n', ' ').ifBlank { cell.action.take(24) }, cell.action, cell)
            for ((name, link) in FlowStore.links(context)) list += Row2("Script: $name", "MyFlow:$link", null)
            list
        }
    }
    val all = loaded ?: emptyList()
    // Any typed word finds a script or cell (in any order); the ones holding the most words come first.
    val shown = SearchMatch.filter(all, query) { r ->
        r.label + " " + r.action.removePrefix("MyFlow:") + " " + (if (r.action.startsWith("N:")) runCatching { NativePicker.label(r.action) }.getOrDefault("") else "")
    }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search") }, modifier = Modifier.fillMaxWidth(),
        )
        if (loaded == null) Text("Loading…", modifier = Modifier.padding(12.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { r ->
                Text(
                    r.label, color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth().clickable { if (ShortcutTools.askOnPick(context)) gate = r else onPick(r.label, r.action, r.cell) }.padding(vertical = 12.dp, horizontal = 6.dp),
                )
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
