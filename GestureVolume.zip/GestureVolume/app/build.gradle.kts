import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.hilt)
    alias(libs.plugins.ksp)
    id("com.google.android.libraries.mapsplatform.secrets-gradle-plugin")
}

/**
 * Signing credentials, read from `local.properties` first and the environment second.
 *
 * `local.properties` is gitignored and already holds this project's other secrets, so the keystore
 * password never reaches version control. The environment fallback is what lets CI sign without a
 * local.properties file at all.
 */
val localProperties = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun signingSecret(name: String): String? =
    localProperties.getProperty(name)?.takeIf { it.isNotBlank() }
        ?: System.getenv(name)?.takeIf { it.isNotBlank() }

val releaseStoreFile = signingSecret("RELEASE_STORE_FILE")
val releaseStorePassword = signingSecret("RELEASE_STORE_PASSWORD")
val releaseKeyAlias = signingSecret("RELEASE_KEY_ALIAS")
val releaseKeyPassword = signingSecret("RELEASE_KEY_PASSWORD")

// All four, or none. A half-configured signing config fails deep inside the packaging task with a
// message that does not mention the missing property, so it is checked up front instead.
val hasReleaseSigning = releaseStoreFile != null &&
        releaseStorePassword != null &&
        releaseKeyAlias != null &&
        releaseKeyPassword != null &&
        file(releaseStoreFile).exists()

android {
    namespace = "com.newagedevs.gesturevolume"
    compileSdk = 37

    // Only English and Arabic: the libraries' own translations are left out too.
    androidResources {
        localeFilters += listOf("en", "ar")
    }

    defaultConfig {
        applicationId = "a.gstr"
        minSdk = 26
        targetSdk = 37
        versionCode = 42
        versionName = "1.5.4"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // `-PnoAds` builds a copy with every ad switched off — the SDK is never started — for
        // recording store and policy videos. Pro stays locked; only the ads go.
        buildConfigField("boolean", "ADS_DISABLED", project.hasProperty("noAds").toString())
    }

    signingConfigs {
        // One fixed debug key, kept in the project, so every build is signed the same and installs
        // over the last one. CI otherwise makes a new random debug key per run, and Android refuses
        // to update an app signed with a different key.
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
                // Both schemes: v2 is what Play requires, v1 keeps the artifact installable by
                // anything still verifying the old way.
                enableV1Signing = true
                enableV2Signing = true
            }
        }
    }

    buildTypes {
        debug {
            // `./gradlew assembleDebug -Psideload` builds a copy that installs *beside* the Play
            // release on a test device, under its own package name, so trying a build never means
            // replacing the release — and losing its settings — on the phone in your pocket.
            if (project.hasProperty("sideload")) {
                applicationIdSuffix = ""
                versionNameSuffix = "-sideload"
            }
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Left unsigned when the credentials are absent rather than failing the build, so a
            // clone without the keystore can still run assembleRelease to check that R8 passes.
            signingConfig = if (hasReleaseSigning) signingConfigs.getByName("release") else null
            // Personal build: same package and the same fixed key as the debug one, so it installs
            // over it and keeps every setting, but it is optimised (R8) and not debuggable.
            if (project.hasProperty("sideload")) {
                applicationIdSuffix = ""
                versionNameSuffix = "-sideload"
                signingConfig = signingConfigs.getByName("debug")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_11)
    }
}

dependencies {
    // Signs the copy of this app that the strip editor makes ("Make APK with my shortcuts").
    implementation("com.android.tools.build:apksig:8.5.2")
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)

    // Hilt
    implementation(libs.hilt.android)
    implementation(libs.androidx.lifecycle.process)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.cardview)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    // Splashscreen
    implementation(libs.androidx.core.splashscreen)

    // Icons
    implementation(libs.androidx.compose.material.icons.extended)

    // Lottie
    implementation(libs.lottie.compose)

    // Coil
    implementation(libs.coil.compose)
    implementation(libs.coil.network.okhttp)
    implementation(libs.coil)

    // Sheets
    implementation(libs.color)

    implementation("com.google.zxing:core:3.5.3")

    // QR / barcode scanning. The scanner itself is downloaded on demand by Play services, so
    // this adds a couple of hundred kilobytes to the APK rather than a whole vision pipeline.
    implementation(libs.play.services.code.scanner)

    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}