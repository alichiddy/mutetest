package com.newagedevs.gesturevolume.ui.screens.handler_action

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.newagedevs.gesturevolume.R
import com.newagedevs.gesturevolume.data.local.AppGestureStore.Slot
import com.newagedevs.gesturevolume.ui.components.HowItWorksAction
import com.newagedevs.gesturevolume.ui.components.Tutorial
import com.newagedevs.gesturevolume.ui.components.TutorialAction
import com.newagedevs.gesturevolume.ui.components.rememberGestureDemoState
import com.newagedevs.gesturevolume.ui.components.AccessibilityDisclosureDialog
import com.newagedevs.gesturevolume.ui.components.ActionIconImage
import com.newagedevs.gesturevolume.ui.components.DndAccessDialog
import com.newagedevs.gesturevolume.ui.components.PermissionNote
import com.newagedevs.gesturevolume.ui.components.PreviewSettingsLayout
import com.newagedevs.gesturevolume.ui.components.isLandscape
import com.newagedevs.gesturevolume.ui.components.actionDisplayName
import com.newagedevs.gesturevolume.ui.motion.Button
import com.newagedevs.gesturevolume.ui.motion.IconButton
import com.newagedevs.gesturevolume.ui.motion.OutlinedButton
import com.newagedevs.gesturevolume.ui.motion.TextButton
import com.newagedevs.gesturevolume.ui.screens.app_gestures.appGesturesSummary
import com.newagedevs.gesturevolume.ui.screens.handler_appearance.SliderControl
import com.newagedevs.gesturevolume.ui.screens.quick_slider.sliderTargetLabel
import com.newagedevs.gesturevolume.ui.view.TapTiming
import com.newagedevs.gesturevolume.ui.viewmodels.MainEvent
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import com.newagedevs.gesturevolume.utils.ActionIcon
import com.newagedevs.gesturevolume.utils.AudioStreamCatalog
import com.newagedevs.gesturevolume.utils.BarBehaviour
import com.newagedevs.gesturevolume.utils.DeviceToggles
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions
import com.newagedevs.gesturevolume.utils.PermissionNeeds
import com.newagedevs.gesturevolume.utils.VolumeStreamMode

/** Starts a system settings screen, pausing the app-open ad for the round trip. */
private fun openSystemScreen(context: android.content.Context, viewModel: MainViewModel, intent: Intent) {
    viewModel.preference.setAppOpenAdPaused(true)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        viewModel.preference.setAppOpenAdPaused(false)
    }
}

/**
 * What the bar does: its eight gestures, and the settings that shape them.
 *
 * Laid out as a list of gestures rather than a list of settings. Each gesture is one line — a
 * picture of it, its name, and what it does — and the whole line opens a screen to choose from
 * ([ActionPickerScreen]). It used to be a heading, a sentence, and a box to tap for each of them,
 * which was three things to read to learn one, and a dialog of tiles to choose in.
 *
 * At the top, the bar itself to try them on ([GestureTryPad]), which answers the question the
 * list cannot: "which of these did I just do?"
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HandlerActionsScreen(
    viewModel: MainViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onPickAction: (Slot) -> Unit = {},
    onOpenQuickSlider: () -> Unit = {},
    onOpenLongPressMenu: () -> Unit = {},
    onOpenAppGestures: () -> Unit = {},
    onOpenPermissions: (PermissionNeeds.Permission?) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val state by viewModel.state.collectAsState()
    val preference = viewModel.preference
    val onLeft = remember { preference.getHandlerPosition() == "Left" }

    // Summaries of the screens these rows lead to, re-read on return: those screens write straight
    // through to preferences, which this one cannot hear.
    var sliderTarget by remember { mutableStateOf(preference.slider.getTarget()) }
    var contextMenuItems by remember { mutableStateOf(preference.getContextMenuOrder()) }

    // Read once into local state: plain SharedPref values with no observable wrapper, so the
    // controls' own state drives the UI and the preference is written behind it.
    var volumeStreamMode by remember { mutableStateOf(preference.getVolumeStreamMode()) }
    var swipeStepPercent by remember { mutableIntStateOf(preference.getSwipeStepPercent()) }
    var doubleTapMs by remember { mutableIntStateOf(preference.getDoubleTapMs()) }
    var longPressMs by remember { mutableIntStateOf(preference.getLongPressMs()) }

    // Bumped on every return, so the notes under the actions re-read what has been granted since:
    // every one of those permissions is given on a system screen this one cannot hear back from.
    var permissionTick by remember { mutableIntStateOf(0) }
    val actionNote: @Composable ColumnScope.(String) -> Unit = { action ->
        @Suppress("UNUSED_VARIABLE") val tick = permissionTick
        PermissionNeeds.missingFor(context, preference, action)?.let {
            PermissionNote(
                missing = it,
                onOpenPermissions = onOpenPermissions,
                modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp),
            )
        }
    }

    // Coming back from a system screen this screen sent the user to — the WRITE_SETTINGS grant,
    // the Do Not Disturb access, the accessibility list — has to lift the app-open ad pause those
    // set. Without this the pause was set and never cleared, silencing app-open ads for the rest
    // of the install.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                preference.setAppOpenAdPaused(false)
                sliderTarget = preference.slider.getTarget()
                contextMenuItems = preference.getContextMenuOrder()
                permissionTick++
                viewModel.onEvent(MainEvent.UpdatePermissionsStatus(context))
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    // Re-applies the action the user picked, once they come back from the system settings screen.
    val writeSettingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        preference.setAppOpenAdPaused(false)
        viewModel.onEvent(MainEvent.WriteSettingsResult(context))
    }

    // Asked only when a brightness action is actually chosen — never at startup. The picker is
    // a screen of its own, and comes back here with the question pending.
    if (state.pendingWriteSettingsRequest) {
        AlertDialog(
            onDismissRequest = { viewModel.onEvent(MainEvent.CancelPendingBrightnessAction) },
            title = {
                Text(
                    text = stringResource(R.string.brightness_permission_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.brightness_permission_message),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            "package:${context.packageName}".toUri()
                        )
                        preference.setAppOpenAdPaused(true)
                        try {
                            writeSettingsLauncher.launch(intent)
                        } catch (_: Exception) {
                            preference.setAppOpenAdPaused(false)
                            viewModel.onEvent(MainEvent.CancelPendingBrightnessAction)
                        }
                    },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.open_settings))
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.onEvent(MainEvent.CancelPendingBrightnessAction) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.cancel))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(24.dp)
        )
    }

    // The action is already saved; this only asks the user to switch the service on. Shown for a
    // system action chosen while the service is off.
    if (state.showAccessibilityPrompt) {
        AccessibilityDisclosureDialog(
            onAccept = { viewModel.openAccessibilitySettings() },
            onDismiss = { viewModel.onEvent(MainEvent.DismissAccessibilityPrompt) }
        )
    }

    if (state.showDndPrompt) {
        DndAccessDialog(
            onAccept = {
                viewModel.onEvent(MainEvent.DismissDndPrompt)
                openSystemScreen(context, viewModel, DeviceToggles(context).dndAccessIntent())
            },
            onDismiss = { viewModel.onEvent(MainEvent.DismissDndPrompt) }
        )
    }

    // The finger acting the gestures out on the pad, from the ? as on the preview screens. Only on
    // request: the pad is for the user's own tries, and this screen is the one they come back to
    // whenever they change what a gesture does.
    val gestureDemo = rememberGestureDemoState(ACTIONS_DEMO_STEPS, autoPlays = 0)

    Scaffold(
        // The top bar is clear, on the plain page as the preview under it is.
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.handler_actions)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, tooltip = stringResource(R.string.back)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    TutorialAction(Tutorial.ACTIONS)
                    HowItWorksAction(gestureDemo)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { padding ->
        val tryPad: @Composable (Modifier, Boolean) -> Unit = { padModifier, fillHeight ->
            GestureTryPad(
                preference = preference,
                actions = Slot.entries.associateWith { actionFor(state, it) },
                doubleTapMs = doubleTapMs,
                longPressMs = longPressMs,
                onLeft = onLeft,
                onChange = onPickAction,
                modifier = padModifier,
                demo = gestureDemo,
                fillHeight = fillHeight,
            )
        }
        val groups: @Composable ColumnScope.() -> Unit = {
            // ---- taps -----------------------------------------------------------------------
            GroupLabel(stringResource(R.string.actions_taps))
            Segments {
                TAP_SLOTS.forEachIndexed { index, slot ->
                    SlotRow(state = state, slot = slot, onLeft = onLeft, shape = segmentShape(index, TAP_SLOTS.size),
                        onClick = { onPickAction(slot) }, note = actionNote)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            var passTaps by remember { mutableStateOf(preference.isPassTaps()) }
            SettingSwitchItem(
                title = "Pass taps through",
                description = "Taps on the bar reach the keyboard or app underneath, so letters under the bar get typed. Tap, double tap and triple tap actions are paused.",
                checked = passTaps,
                onCheckedChange = { passTaps = it; preference.setPassTaps(it) },
            )

            Spacer(modifier = Modifier.height(8.dp))
            // Louder than the maximum: the sliders go on past 100% into a loudness boost, up to +32 dB.
            val boostCtx = androidx.compose.ui.platform.LocalContext.current
            var boostOn by remember { mutableStateOf(preference.sharedPreferences.getBoolean("volumeBoostAllowed", false)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Volume boost: sliders go past the maximum")
                    Text(
                        "Swiping up at the maximum, or sliding the Quick slider on, raises the loudness up to +32 dB (media). Loud: it can distort and hurt ears and speakers.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                androidx.compose.material3.Switch(checked = boostOn, onCheckedChange = {
                    boostOn = it
                    preference.sharedPreferences.edit().putBoolean("volumeBoostAllowed", it).apply()
                    if (!it) {
                        com.newagedevs.gesturevolume.utils.VolumeBoost.release()
                        Thread {
                            val v = com.newagedevs.gesturevolume.utils.VolumeBoost.verifyOff() ?: "gain set to 0 dB (Shizuku is needed to double-check)"
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                android.widget.Toast.makeText(boostCtx, "Boost off - $v", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }.start()
                    }
                })
            }
            Spacer(modifier = Modifier.height(8.dp))

            Spacer(modifier = Modifier.height(24.dp))

            // ---- swipes ---------------------------------------------------------------------
            // The amount sits between the two swipes it tunes and the two it does not: only the
            // volume and brightness bindings move by an amount, and only up and down hold them.
            GroupLabel(stringResource(R.string.actions_swipes))
            Segments {
                SlotRow(state, Slot.SWIPE_UP, onLeft, segmentShape(0, 5), { onPickAction(Slot.SWIPE_UP) }, actionNote)
                SlotRow(state, Slot.SWIPE_DOWN, onLeft, segmentShape(1, 5), { onPickAction(Slot.SWIPE_DOWN) }, actionNote)
                SwipeAmount(
                    percent = swipeStepPercent,
                    shape = segmentShape(2, 5),
                    onChange = {
                        swipeStepPercent = it
                        preference.setSwipeStepPercent(it)
                    },
                )
                SlotRow(state, Slot.SWIPE_IN, onLeft, segmentShape(3, 5), { onPickAction(Slot.SWIPE_IN) }, actionNote)
                SlotRow(state, Slot.SWIPE_OUT, onLeft, segmentShape(4, 5), { onPickAction(Slot.SWIPE_OUT) }, actionNote)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ---- the screens these gestures lead on to ------------------------------------------
            GroupLabel(stringResource(R.string.actions_more))
            Segments {
                // The Quick panel is opened by one of the gestures above; what it adjusts, how big
                // it is and how hard it buzzes are its own screen's.
                LinkRow(
                    icon = ActionIcon.QuickPanel,
                    title = stringResource(R.string.quick_slider_title),
                    summary = stringResource(sliderTargetLabel(sliderTarget)),
                    shape = segmentShape(0, 3),
                    onClick = onOpenQuickSlider,
                ) { actionNote(HandlerActions.OPEN_QUICK_SLIDER) }
                LinkRow(
                    icon = ActionIcon.Vector(Icons.Filled.Menu),
                    title = stringResource(R.string.context_menu_section),
                    // Counted through the catalog, so the summary matches the menu the user will
                    // actually see — pinned entries included.
                    summary = stringResource(
                        R.string.context_menu_count,
                        HandlerActionCatalog.contextMenuEntries(contextMenuItems).size
                    ),
                    shape = segmentShape(1, 3),
                    onClick = onOpenLongPressMenu,
                )
                @Suppress("UNUSED_VARIABLE") val tick = permissionTick
                LinkRow(
                    icon = ActionIcon.Vector(Icons.Filled.Apps),
                    title = stringResource(R.string.app_gestures_title),
                    summary = appGesturesSummary(preference.appGestures),
                    shape = segmentShape(2, 3),
                    onClick = onOpenAppGestures,
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ---- behaviour ------------------------------------------------------------------
            GroupLabel(stringResource(R.string.behaviour_section))
            Segments {
                VolumeStream(
                    mode = volumeStreamMode,
                    shape = segmentShape(0, 2),
                    onChange = {
                        volumeStreamMode = it
                        preference.setVolumeStreamMode(it)
                    },
                )
                // Read by the bar when it is next put up, which is the moment this screen is left;
                // and by the pad at the top straight away, which is where to feel the difference.
                TapTimingCard(
                    doubleTapMs = doubleTapMs,
                    longPressMs = longPressMs,
                    shape = segmentShape(1, 2),
                    onDoubleTapChange = { doubleTapMs = it },
                    onLongPressChange = { longPressMs = it },
                    onDoubleTapChangeFinished = { preference.setDoubleTapMs(doubleTapMs) },
                    onLongPressChangeFinished = { preference.setLongPressMs(longPressMs) },
                )
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
        // The pad where the preview screens put their preview, and pinned as theirs is: above the
        // gestures upright, only the gestures scrolling under it; beside them on its side, two
        // fifths of the width and as tall as the screen allows — so trying a gesture and changing
        // it are both in view, whichever way the phone is held.
        PreviewSettingsLayout(contentPadding = padding, preview = tryPad, content = groups)
    }
}

/** Rows grouped into one card, a hairline of the page between them. See [segmentShape]. */
@Composable
private fun Segments(content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp), content = content)
}

/** [slot] and what it does everywhere, with the permission that action still waits for. */
@Composable
private fun SlotRow(
    state: com.newagedevs.gesturevolume.ui.viewmodels.MainState,
    slot: Slot,
    onLeft: Boolean,
    shape: Shape,
    onClick: () -> Unit,
    note: @Composable ColumnScope.(String) -> Unit,
) {
    val action = actionFor(state, slot)
    val nothing = HandlerActions.isDisabled(action)
    GestureRow(
        slot = slot,
        onLeft = onLeft,
        actionIcon = actionIconFor(state, slot),
        actionText = if (nothing) stringResource(R.string.actions_not_set) else actionDisplayName(action),
        dimmed = nothing,
        shape = shape,
        onClick = onClick,
    ) { note(action) }
}

/** A row that leads to another screen: its icon, its name, and what is set there now. */
@Composable
private fun LinkRow(
    icon: ActionIcon,
    title: String,
    summary: String,
    shape: Shape,
    onClick: () -> Unit,
    footer: @Composable ColumnScope.() -> Unit = {},
) {
    val colours = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(colours.surfaceVariant.copy(alpha = 0.65f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(colours.secondaryContainer.copy(alpha = 0.8f)),
                contentAlignment = Alignment.Center,
            ) {
                ActionIconImage(
                    icon = icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = colours.onSecondaryContainer,
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colours.onSurface,
                )
                Text(
                    text = summary,
                    fontSize = 14.sp,
                    color = colours.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = colours.outline,
                modifier = Modifier.size(22.dp),
            )
        }
        footer()
    }
}

/** A card of the settings list: a title, the line under it, and the control. */
@Composable
private fun SettingCard(
    title: String,
    description: String,
    shape: Shape,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
            .padding(16.dp)
    ) {
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp),
        )
        content()
    }
}

/**
 * How far one swipe up or down moves the volume, as chips rather than behind a dialog: four short
 * answers, all of them visible, and what the chosen one means said under them.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SwipeAmount(percent: Int, shape: Shape, onChange: (Int) -> Unit) {
    SettingCard(
        title = stringResource(R.string.swipe_amount_title),
        description = stringResource(R.string.swipe_amount_desc),
        shape = shape,
    ) {
        androidx.compose.material3.Slider(
            value = percent.toFloat(),
            onValueChange = { onChange(it.toInt().coerceIn(0, 10)) },
            valueRange = 0f..10f,
            steps = 9,
        )
        Text(
            text = if (percent == 0) "Level 0 - by length" else "Level $percent of 10",
            style = MaterialTheme.typography.labelLarge,
        )
        Text(
            text = if (percent == BarBehaviour.SWIPE_STEP_BY_LENGTH) {
                stringResource(R.string.swipe_amount_by_length_desc)
            } else {
                "Every few millimetres of swipe moves the volume, up or down. Level 6 is a firm swipe; level 10 goes from 0 to 100 in about 3 pixels."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 10.dp),
        )
    }
}

/**
 * Which volume the bar changes, as the three choices themselves with what each one means. They are
 * genuinely three intentions — see `VolumeStreamMode` — and each carries its consequence under it,
 * which a dialog hid until it was opened.
 */
@Composable
private fun VolumeStream(mode: String, shape: Shape, onChange: (String) -> Unit) {
    val chosen = VolumeStreamMode.sanitize(mode)
    SettingCard(
        title = stringResource(R.string.volume_stream_title),
        description = stringResource(R.string.volume_stream_desc),
        shape = shape,
    ) {
        Column(modifier = Modifier.selectableGroup()) {
            VolumeStreamMode.ALL.forEach { option ->
                val selected = option == chosen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f) else Color.Transparent
                        )
                        .selectable(selected = selected, role = Role.RadioButton, onClick = { onChange(option) })
                        .padding(horizontal = 4.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    // The whole row is the target; a second one inside it would let a screen reader
                    // announce the same choice twice.
                    RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(horizontal = 8.dp))
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            text = stringResource(AudioStreamCatalog.labelForMode(option)),
                            fontSize = 15.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = stringResource(AudioStreamCatalog.descriptionForMode(option)),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

/**
 * The tap timings: the automatic figures until moved, then the user's own, each with the way back
 * to automatic once it has been moved — which there was not, so a slider nudged once stayed the
 * user's for good.
 */
@Composable
private fun TapTimingCard(
    doubleTapMs: Int,
    longPressMs: Int,
    shape: Shape,
    onDoubleTapChange: (Int) -> Unit,
    onLongPressChange: (Int) -> Unit,
    /** Where each is written: once its change is complete, not every frame. See SliderControl. */
    onDoubleTapChangeFinished: () -> Unit,
    onLongPressChangeFinished: () -> Unit,
) {
    SettingCard(
        title = stringResource(R.string.tap_timing_title),
        description = stringResource(R.string.tap_timing_desc),
        shape = shape,
    ) {
        TimingSlider(
            label = stringResource(R.string.tap_timing_double),
            ms = doubleTapMs,
            automatic = TapTiming.automaticDoubleTapMs.toInt(),
            range = TapTiming.MIN_DOUBLE_TAP_MS..TapTiming.MAX_DOUBLE_TAP_MS,
            step = 25f,
            onChange = onDoubleTapChange,
            onChangeFinished = onDoubleTapChangeFinished,
        )
        Spacer(modifier = Modifier.height(8.dp))
        TimingSlider(
            label = stringResource(R.string.tap_timing_long),
            ms = longPressMs,
            automatic = TapTiming.automaticLongPressMs.toInt(),
            range = TapTiming.MIN_LONG_PRESS_MS..TapTiming.MAX_LONG_PRESS_MS,
            step = 50f,
            onChange = onLongPressChange,
            onChangeFinished = onLongPressChangeFinished,
        )
        Text(
            text = stringResource(R.string.tap_timing_try),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

/** One timing: 0 is automatic, shown as the figure it stands for. */
@Composable
private fun TimingSlider(
    label: String,
    ms: Int,
    automatic: Int,
    range: IntRange,
    step: Float,
    onChange: (Int) -> Unit,
    onChangeFinished: () -> Unit,
) {
    val custom = ms > 0
    val shown = if (custom) ms else automatic
    SliderControl(
        label = label,
        value = shown.toFloat(),
        valueRange = range.first.toFloat()..range.last.toFloat(),
        valueDisplay = if (custom) {
            stringResource(R.string.tap_timing_value, shown)
        } else {
            stringResource(R.string.tap_timing_auto, shown)
        },
        borderColor = MaterialTheme.colorScheme.primary,
        step = step,
        onValueChange = { onChange(it.toInt()) },
        onValueChangeFinished = onChangeFinished,
    )
    if (custom) {
        TextButton(onClick = { onChange(0); onChangeFinished() }) {
            Text(stringResource(R.string.tap_timing_use_auto))
        }
    }
}

/** "By how far you swipe", or "10% per swipe". */
@Composable
private fun swipeAmountLabel(percent: Int): String =
    if (percent == BarBehaviour.SWIPE_STEP_BY_LENGTH) {
        stringResource(R.string.swipe_amount_by_length)
    } else {
        stringResource(R.string.swipe_amount_percent, percent)
    }


/**
 * A list of file paths for the GitHub build: a tick (build/upload this one when it exists), the path
 * as text, a browse button and a remove button, with Add on the left. Any version of the name counts
 * ("name (3).zip", "name-2.zip"): the newest one in that folder is used.
 */
@androidx.compose.runtime.Composable
private fun GhFileList(
    title: String, kind: String,
    files: androidx.compose.runtime.snapshots.SnapshotStateList<com.newagedevs.gesturevolume.data.local.SharedPref.GhFile>,
) {
    val context = LocalContext.current
    var browsing by remember { mutableStateOf(-1) }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        val idx = browsing; browsing = -1
        if (uri != null && idx in files.indices) {
            val path = pathOf(context, uri)
            if (path == null) android.widget.Toast.makeText(context, "Pick it from Internal storage in the Files app, or type the path.", android.widget.Toast.LENGTH_LONG).show()
            else files[idx] = com.newagedevs.gesturevolume.data.local.SharedPref.GhFile(path, files[idx].on, files[idx].rel)
        }
    }
    Text(title, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    files.forEachIndexed { i, f ->
        androidx.compose.material3.Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(checked = f.on, onCheckedChange = { files[i] = com.newagedevs.gesturevolume.data.local.SharedPref.GhFile(f.path, it, f.rel) })
                    // One line, as tall as the text; a long path scrolls sideways and always shows its end.
                    var tfv by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue(f.path, androidx.compose.ui.text.TextRange(f.path.length))) }
                    androidx.compose.runtime.LaunchedEffect(f.path) {
                        if (tfv.text != f.path) tfv = androidx.compose.ui.text.input.TextFieldValue(f.path, androidx.compose.ui.text.TextRange(f.path.length))
                    }
                    androidx.compose.foundation.text.BasicTextField(
                        value = tfv,
                        onValueChange = { n ->
                            // A pasted path puts the cursor at its end, so the end is what you see.
                            val pasted = n.text.length - tfv.text.length > 1
                            tfv = if (pasted) n.copy(selection = androidx.compose.ui.text.TextRange(n.text.length)) else n
                            files[i] = com.newagedevs.gesturevolume.data.local.SharedPref.GhFile(n.text, f.on, f.rel)
                        },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(androidx.compose.material3.MaterialTheme.colorScheme.primary),
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp, vertical = 10.dp),
                    )
                    TextButton(onClick = {
                        browsing = i
                        launcher.launch(arrayOf("*/*"))
                    }) { Text("Browse") }
                    TextButton(onClick = { files.removeAt(i) }) { Text("×") }
                }
                // What the path really points at, so a pasted path can be checked at a glance.
                val file = java.io.File(f.path.trim())
                val shown = remember(f.path) {
                    if (file.isFile) "${file.name}   ${file.length() / 1024} KB, saved " + java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(file.lastModified()))
                    else "${file.name}   (not found at this exact path; the newest file named like it in that folder is used)"
                }
                Text(shown, fontSize = 11.sp, modifier = Modifier.padding(start = 12.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 12.dp)) {
                    Text("Release:", fontSize = 12.sp)
                    androidx.compose.foundation.text.BasicTextField(
                        value = f.rel, onValueChange = { files[i] = com.newagedevs.gesturevolume.data.local.SharedPref.GhFile(f.path, f.on, it) },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.primary),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(androidx.compose.material3.MaterialTheme.colorScheme.primary),
                        decorationBox = { inner ->
                            Box(Modifier.padding(horizontal = 8.dp, vertical = 8.dp)) {
                                if (f.rel.isEmpty()) Text(autoRelease(f.path) + " (automatic)", fontSize = 13.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.outline)
                                inner()
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
    Row {
        TextButton(onClick = { files.add(com.newagedevs.gesturevolume.data.local.SharedPref.GhFile("/storage/emulated/0/Download/", true, "")) }) { Text("+ Add") }
    }
}

private fun autoRelease(path: String): String {
    val n = java.io.File(path).name
    return when {
        n.startsWith("LeanType", true) -> "lt"
        n.startsWith("blackbox", true) -> "bb"
        else -> "gv"
    }
}

/** A real path for a file chosen in the system picker (phone storage, Downloads, or the media store). */
private fun pathOf(context: android.content.Context, uri: android.net.Uri): String? {
    if (uri.authority == "com.android.externalstorage.documents") {
        val id = android.provider.DocumentsContract.getDocumentId(uri)
        val (vol, rel) = id.split(":", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
        return if (vol == "primary") "/storage/emulated/0/$rel" else "/storage/$vol/$rel"
    }
    val id = runCatching { android.provider.DocumentsContract.getDocumentId(uri) }.getOrNull()
    if (id != null && id.startsWith("raw:")) return id.removePrefix("raw:")
    // The picker may give a media or downloads id: ask for the real path, or find the name in Download.
    runCatching {
        context.contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0)?.takeIf { p -> p.startsWith("/") }?.let { p -> return p }
        }
    }
    val name = runCatching {
        context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: return null
    val guess = java.io.File("/storage/emulated/0/Download/$name")
    return if (guess.exists()) guess.path else null
}

/** The GitHub build settings window; opened from the main screen's top bar. */
@Composable
internal fun GitHubSettingsDialog(preference: com.newagedevs.gesturevolume.data.local.SharedPref, onDismiss: () -> Unit) {
    val boostCtx = androidx.compose.ui.platform.LocalContext.current
                var token by remember { mutableStateOf(preference.getGhToken()) }
                var repo by remember { mutableStateOf(preference.getGhRepo()) }
                val zips = remember { androidx.compose.runtime.mutableStateListOf<com.newagedevs.gesturevolume.data.local.SharedPref.GhFile>().apply { addAll(preference.getGhFiles("zip")) } }
                val ymls = remember { androidx.compose.runtime.mutableStateListOf<com.newagedevs.gesturevolume.data.local.SharedPref.GhFile>().apply { addAll(preference.getGhFiles("yml")) } }
                AlertDialog(
                    onDismissRequest = { onDismiss() },
                    modifier = Modifier.fillMaxWidth(0.97f),
                    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                    title = { Text("GitHub build") },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.OutlinedTextField(
                                value = token, onValueChange = { token = it }, singleLine = true,
                                label = { Text("Token") },
                                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            )
                            androidx.compose.material3.OutlinedTextField(value = repo, onValueChange = { repo = it }, singleLine = true, label = { Text("Repository") })
                            GhFileList("Zip files", "zip", zips)
                            GhFileList("Workflow yml files", "yml", ymls)
                            var shownRuns by remember { mutableStateOf<List<com.newagedevs.gesturevolume.utils.GitHubBuild.RunInfo>?>(null) }
                            var shownMsg by remember { mutableStateOf("") }
                            fun refreshRuns(t: String, r: String) {
                                shownMsg = "Reading…"
                                Thread {
                                    val res = com.newagedevs.gesturevolume.utils.GitHubBuild.fetchRuns(t, r)
                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                        res.onSuccess { shownRuns = it; shownMsg = if (it.isEmpty()) "No workflow runs in $r." else "${it.size} newest runs in $r" }
                                            .onFailure { shownRuns = emptyList(); shownMsg = it.message ?: "Could not read the runs." }
                                    }
                                }.start()
                            }
                            androidx.compose.material3.OutlinedButton(onClick = { shownRuns = emptyList(); refreshRuns(token, repo) }) { Text("Show workflow runs") }
                            shownRuns?.let { runs ->
                                val chosen = remember(runs) { androidx.compose.runtime.mutableStateListOf<Long>() }
                                androidx.compose.material3.AlertDialog(
                                    onDismissRequest = { shownRuns = null },
                                    modifier = Modifier.fillMaxWidth(0.97f),
                                    properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                                    title = { Text("Workflow runs") },
                                    text = {
                                        Column(Modifier.verticalScroll(rememberScrollState())) {
                                            Text(shownMsg, fontSize = 12.sp)
                                            Text("Tick runs to delete them, or tap Install on a successful one. Runs still building cannot be ticked and are never touched.", fontSize = 12.sp)
                                            for (r in runs) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    androidx.compose.material3.Checkbox(
                                                        checked = r.id in chosen, enabled = r.finished,
                                                        onCheckedChange = { on -> if (on) chosen.add(r.id) else chosen.remove(r.id) },
                                                    )
                                                    val mark = when (r.state) { "success" -> "OK"; "failure" -> "FAILED"; "cancelled" -> "CANCELLED"; "in_progress" -> "BUILDING"; "queued" -> "WAITING"; else -> r.state.uppercase() }
                                                    Text("#${r.number}  $mark\n${r.name}  ${r.created}", Modifier.weight(1f).padding(vertical = 4.dp), fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                                                    if (r.state == "success") TextButton(onClick = {
                                                        com.newagedevs.gesturevolume.utils.GitHubBuild.installRun(boostCtx, preference, r.id, r.name) {
                                                            android.widget.Toast.makeText(boostCtx, it, android.widget.Toast.LENGTH_LONG).show()
                                                        }
                                                        shownRuns = null
                                                    }) { Text("Install") }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Row {
                                            TextButton(onClick = { refreshRuns(token, repo) }) { Text("Refresh") }
                                            TextButton(onClick = { chosen.clear(); chosen.addAll(runs.filter { it.finished }.map { it.id }) }) { Text("All finished") }
                                            TextButton(enabled = chosen.isNotEmpty(), onClick = {
                                                val ids = chosen.toList()
                                                val t = token; val r = repo
                                                shownMsg = "Deleting…"
                                                Thread {
                                                    val msg = com.newagedevs.gesturevolume.utils.GitHubBuild.deleteRuns(t, r, ids)
                                                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                                                        android.widget.Toast.makeText(boostCtx, msg, android.widget.Toast.LENGTH_LONG).show()
                                                        refreshRuns(t, r)
                                                    }
                                                }.start()
                                            }) { Text("Delete ${chosen.size}") }
                                        }
                                    },
                                    dismissButton = { TextButton(onClick = { shownRuns = null }) { Text("Close") } },
                                )
                            }
                            run {
                                var only by remember { mutableStateOf(preference.sharedPreferences.getBoolean("ghOnlyChanged", true)) }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Only upload files that changed since their last finished build", Modifier.weight(1f))
                                    androidx.compose.material3.Switch(checked = only, onCheckedChange = {
                                        only = it; preference.sharedPreferences.edit().putBoolean("ghOnlyChanged", it).apply()
                                    })
                                }
                                androidx.compose.material3.OutlinedButton(onClick = {
                                    preference.setGhSettings(token, repo, zips.firstOrNull { it.on }?.path ?: "", ymls.firstOrNull { it.on }?.path ?: "")
                                    preference.setGhFiles("zip", zips.toList()); preference.setGhFiles("yml", ymls.toList())
                                    onDismiss()
                                    com.newagedevs.gesturevolume.utils.GitHubBuild.start(boostCtx, preference, force = true) {
                                        android.widget.Toast.makeText(boostCtx, it, android.widget.Toast.LENGTH_LONG).show()
                                    }
                                }) { Text("Build all ticked now") }
                            }
                            Text("Show the build status as", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            for ((key, label, def) in listOf(
                                Triple("ghShowNotif", "Notification", true),
                                Triple("ghShowToast", "Toast", false),
                                Triple("ghShowBar", "Bar message", false),
                            )) {
                                var on by remember { mutableStateOf(preference.sharedPreferences.getBoolean(key, def)) }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(label, Modifier.weight(1f))
                                    androidx.compose.material3.Switch(checked = on, onCheckedChange = {
                                        on = it; preference.sharedPreferences.edit().putBoolean(key, it).apply()
                                    })
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            preference.setGhSettings(token, repo, zips.firstOrNull { it.on }?.path ?: "", ymls.firstOrNull { it.on }?.path ?: "")
                            preference.setGhFiles("zip", zips.toList()); preference.setGhFiles("yml", ymls.toList())
                            onDismiss()
                        }) { Text("Save") }
                    },
                    dismissButton = { TextButton(onClick = { onDismiss() }) { Text("Cancel") } },
                )
}
