package top.niunaijun.blackbox.fake.delegate;

import android.net.Uri;
import android.os.Build;
import android.os.IInterface;
import android.util.ArrayMap;

import java.lang.reflect.Proxy;
import java.util.HashSet;
import java.util.Set;

import black.android.app.BRActivityThread;
import black.android.app.BRActivityThreadProviderClientRecordP;
import black.android.app.BRIActivityManagerContentProviderHolder;
import black.android.content.BRContentProviderHolderOreo;
import black.android.providers.BRSettingsContentProviderHolder;
import black.android.providers.BRSettingsGlobal;
import black.android.providers.BRSettingsNameValueCache;
import black.android.providers.BRSettingsNameValueCacheOreo;
import black.android.providers.BRSettingsSecure;
import black.android.providers.BRSettingsSystem;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.service.context.providers.ContentProviderStub;
import top.niunaijun.blackbox.fake.service.context.providers.SystemProviderStub;
import top.niunaijun.blackbox.utils.Slog;
import top.niunaijun.blackbox.utils.compat.BuildCompat;


public class ContentProviderDelegate {
    public static final String TAG = "ContentProviderDelegate";
    private static Set<String> sInjected = new HashSet<>();

    public static void update(Object holder, String auth) {
        IInterface iInterface;
        if (BuildCompat.isOreo()) {
            iInterface = BRContentProviderHolderOreo.get(holder).provider();
        } else {
            iInterface = BRIActivityManagerContentProviderHolder.get(holder).provider();
        }

        if (iInterface instanceof Proxy)
            return;
        IInterface bContentProvider;
        boolean systemProvider = isSystemProviderAuthority(auth);
        Slog.d(TAG, "Wrapping provider authority=" + auth + ", system=" + systemProvider
                + ", virtualPackage=" + BlackBoxCore.getAppPackageName());
        if (systemProvider) {
            bContentProvider = new SystemProviderStub().wrapper(iInterface, BlackBoxCore.getHostPkg());
        } else {
            bContentProvider = new ContentProviderStub().wrapper(
                    iInterface, BlackBoxCore.getAppPackageName());
        }
        if (BuildCompat.isOreo()) {
            BRContentProviderHolderOreo.get(holder)._set_provider(bContentProvider);
        } else {
            BRIActivityManagerContentProviderHolder.get(holder)._set_provider(bContentProvider);
        }
    }

    public static void init() {
        clearSettingProvider();

        BlackBoxCore.getContext().getContentResolver().call(Uri.parse("content://settings"), "", null, null);
        Object activityThread = BlackBoxCore.mainThread();
        ArrayMap<Object, Object> map = (ArrayMap<Object, Object>) BRActivityThread.get(activityThread).mProviderMap();

        for (Object value : map.values()) {
            String[] mNames = BRActivityThreadProviderClientRecordP.get(value).mNames();
            if (mNames == null || mNames.length <= 0) {
                continue;
            }
            String providerName = mNames[0];
            if (!sInjected.contains(providerName)) {
                sInjected.add(providerName);
                final IInterface iInterface = BRActivityThreadProviderClientRecordP.get(value).mProvider();
                boolean systemProvider = isSystemProviderAuthority(providerName);
                Slog.d(TAG, "Wrapping cached provider authority=" + providerName
                        + ", system=" + systemProvider + ", virtualPackage="
                        + BlackBoxCore.getAppPackageName());
                IInterface wrapped = systemProvider
                        ? new SystemProviderStub().wrapper(iInterface, BlackBoxCore.getHostPkg())
                        : new ContentProviderStub().wrapper(iInterface, BlackBoxCore.getAppPackageName());
                BRActivityThreadProviderClientRecordP.get(value)._set_mProvider(wrapped);
                BRActivityThreadProviderClientRecordP.get(value)._set_mNames(new String[]{providerName});
            }
        }
    }

    public static boolean isSystemProviderAuthority(String authority) {
        if (authority == null) return false;
        for (String item : authority.split(";")) {
            String value = item.trim();
            if (value.equals("settings") || value.equals("media")
                    || value.equals("downloads") || value.equals("contacts")
                    || value.equals("call_log") || value.equals("telephony")
                    || value.equals("calendar") || value.equals("browser")
                    || value.equals("user_dictionary") || value.equals("applications")
                    || value.startsWith("com.android.providers.")
                    || value.equals("com.android.contacts")
                    || value.startsWith("com.android.contacts.")
                    || value.equals("com.android.calendar")
                    || value.startsWith("com.android.calendar.")
                    || value.equals("com.android.settings")
                    || value.startsWith("com.android.settings.")
                    || value.startsWith("com.huawei.android.launcher.settings")
                    || value.startsWith("com.hihonor.android.launcher.settings")
                    || value.startsWith("android.")) {
                return true;
            }
        }
        return false;
    }

    public static void clearSettingProvider() {
        Object cache;
        cache = BRSettingsSystem.get().sNameValueCache();
        if (cache != null) {
            clearContentProvider(cache);
        }
        cache = BRSettingsSecure.get().sNameValueCache();
        if (cache != null) {
            clearContentProvider(cache);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && BRSettingsGlobal.getRealClass() != null) {
            cache = BRSettingsGlobal.get().sNameValueCache();
            if (cache != null) {
                clearContentProvider(cache);
            }
        }
    }

    private static void clearContentProvider(Object cache) {
        if (BuildCompat.isOreo()) {
            Object holder = BRSettingsNameValueCacheOreo.get(cache).mProviderHolder();
            if (holder != null) {
                BRSettingsContentProviderHolder.get(holder)._set_mContentProvider(null);
            }
        } else {
            BRSettingsNameValueCache.get(cache)._set_mContentProvider(null);
        }
    }
}
