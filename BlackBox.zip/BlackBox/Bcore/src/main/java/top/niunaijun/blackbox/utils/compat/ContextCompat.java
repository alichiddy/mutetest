package top.niunaijun.blackbox.utils.compat;

import android.content.Context;
import android.content.ContextWrapper;

import black.android.app.BRContextImpl;
import black.android.app.BRContextImplKitkat;
import black.android.content.AttributionSourceStateContext;
import black.android.content.BRAttributionSource;
import black.android.content.BRAttributionSourceState;
import black.android.content.BRContentResolver;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.user.BUserHandle;
import top.niunaijun.blackbox.utils.Slog;


public class ContextCompat {
    public static final String TAG = "ContextCompat";

    public static void fixAttributionSourceState(Object obj, int uid) {
        String appPackageName = BlackBoxCore.getAppPackageName();
        String packageName = uid == BlackBoxCore.getHostUid()
                && (appPackageName == null || appPackageName.equals(BlackBoxCore.getHostPkg()))
                ? BlackBoxCore.getHostPkg() : getVirtualPackageName();
        fixAttributionSourceState(obj, uid, packageName);
    }

    /**
     * AttributionSource.enforceCallingUid() compares this UID with Binder.getCallingUid().
     * AttributionSource describes the current virtual app process; incoming Binder
     * callers are resolved separately by PID in NativeCore. Real system-provider calls
     * explicitly retain the real host identity.
     */
    public static void fixAttributionSourceState(Object obj, int uid, String packageName) {
        if (obj == null) return;
        try {
            if (BRAttributionSource.get(obj)._check_mAttributionSourceState() == null) {
                return;
            }
            Object state = BRAttributionSource.get(obj).mAttributionSourceState();
            if (state == null) return;
            AttributionSourceStateContext stateContext = BRAttributionSourceState.get(state);
            stateContext._set_packageName(packageName);
            stateContext._set_uid(uid);
        } catch (Throwable e) {
            Slog.w(TAG, "Failed to align AttributionSource identity: " + e.getMessage());
        }
    }

    public static String getVirtualPackageName() {
        // With no virtual AppConfig this is the real host process, not appId 10000.
        if (BActivityThread.getAppConfig() == null) {
            return BlackBoxCore.getHostPkg();
        }
        String appPackageName = BlackBoxCore.getAppPackageName();
        if (appPackageName == null || appPackageName.equals(BlackBoxCore.getHostPkg())
                || "com.google.android.webview".equals(appPackageName)) {
            return BlackBoxCore.getHostPkg();
        }
        return appPackageName;
    }

    private static int getVirtualAttributionUid() {
        // The host UI process has no AppConfig. BActivityThread's default appId
        // (10000) is only a placeholder and must never be written into a real
        // host Context's AttributionSource. Doing so makes SettingsProvider reject
        // the host's Binder call (for example while MainActivity is being paused).
        if (BActivityThread.getAppConfig() == null) {
            return BlackBoxCore.getHostUid();
        }
        String packageName = BlackBoxCore.getAppPackageName();
        // NativeCore deliberately exposes the host identity to WebView itself.
        if ("com.google.android.webview".equals(packageName)) {
            return BlackBoxCore.getHostUid();
        }
        int uid = BUserHandle.getUid(
                BActivityThread.getUserId(), BActivityThread.getBAppId());
        return BUserHandle.isApp(uid) ? uid : BlackBoxCore.getHostUid();
    }

    public static void fix(Context context) {
        try {

            if (context == null) {
                Slog.w(TAG, "Context is null, skipping ContextCompat.fix");
                return;
            }

            int deep = 0;
            while (context instanceof ContextWrapper) {
                context = ((ContextWrapper) context).getBaseContext();
                deep++;
                if (deep >= 10) {
                    return;
                }
            }


            if (context == null) {
                Slog.w(TAG, "Base context is null after unwrapping, skipping ContextCompat.fix");
                return;
            }

            BRContextImpl.get(context)._set_mPackageManager(null);
            try {
                context.getPackageManager();
            } catch (Throwable e) {
                e.printStackTrace();
            }

            BRContextImpl.get(context)._set_mBasePackageName(BlackBoxCore.getHostPkg());
            BRContextImplKitkat.get(context)._set_mOpPackageName(BlackBoxCore.getHostPkg());

            try {
                BRContentResolver.get(context.getContentResolver())._set_mPackageName(BlackBoxCore.getHostPkg());
            } catch (Exception e) {
                Slog.w(TAG, "Failed to fix content resolver: " + e.getMessage());
            }

            if (BuildCompat.isS()) {
                try {
                    boolean hostProcess = BActivityThread.getAppConfig() == null;
                    int attributionUid = getVirtualAttributionUid();
                    String attributionPackage = hostProcess
                            || "com.google.android.webview".equals(BlackBoxCore.getAppPackageName())
                            ? BlackBoxCore.getHostPkg() : getVirtualPackageName();
                    fixAttributionSourceState(
                            BRContextImpl.get(context).getAttributionSource(),
                            attributionUid,
                            attributionPackage);
                    Slog.d(TAG, "Context attribution aligned: "
                            + (hostProcess ? "host" : "virtual")
                            + " uid=" + attributionUid
                            + " package=" + attributionPackage);
                } catch (Exception e) {
                    Slog.w(TAG, "Failed to fix attribution source state: " + e.getMessage());
                }
            }
        } catch (Exception e) {
            Slog.e(TAG, "Error in ContextCompat.fix: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
