package top.niunaijun.blackbox.fake.service.context.providers;

import android.os.IInterface;

import java.lang.reflect.Method;

import black.android.content.BRAttributionSource;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.fake.hook.ClassInvocationStub;
import top.niunaijun.blackbox.utils.compat.ContextCompat;

public class SystemProviderStub extends ClassInvocationStub implements BContentProvider {
    private IInterface mBase;

    @Override
    public IInterface wrapper(IInterface contentProviderProxy, String appPkg) {
        mBase = contentProviderProxy;
        injectHook();
        return (IInterface) getProxyInvocation();
    }

    @Override
    protected Object getWho() {
        return mBase;
    }

    @Override
    protected void inject(Object baseInvocation, Object proxyInvocation) {
    }

    @Override
    protected void onBindMethod() {
    }

    @Override
    public boolean isBadEnv() {
        return false;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if ("asBinder".equals(method.getName())) {
            return method.invoke(mBase, args);
        }
        if (args != null && args.length > 0) {
            if (args[0] instanceof String) {
                // IContentProvider's first String argument is callingPackage.
                args[0] = BlackBoxCore.getHostPkg();
            }
            Class<?> attributionSourceClass = BRAttributionSource.getRealClass();
            for (Object arg : args) {
                if (arg != null && attributionSourceClass != null
                        && attributionSourceClass.isInstance(arg)) {
                    ContextCompat.fixAttributionSourceState(
                            arg, BlackBoxCore.getHostUid(), BlackBoxCore.getHostPkg());
                }
            }
        }
        return method.invoke(mBase, args);
    }
}
