package top.niunaijun.blackbox.core.system.pm.installer;


import java.io.File;
import java.io.IOException;

import top.niunaijun.blackbox.core.env.BEnvironment;
import top.niunaijun.blackbox.core.system.pm.BPackageSettings;
import top.niunaijun.blackbox.entity.pm.InstallOption;
import top.niunaijun.blackbox.utils.FileUtils;
import top.niunaijun.blackbox.utils.NativeUtils;


public class CopyExecutor implements Executor {

    @Override
    public int exec(BPackageSettings ps, InstallOption option, int userId) {
        try {
            if (!option.isFlag(InstallOption.FLAG_SYSTEM)) {
                File nativeDir = BEnvironment.getAppLibDir(ps.pkg.packageName);
                NativeUtils.copyNativeLib(new File(ps.pkg.baseCodePath), nativeDir);
                String[] splitPaths = ps.pkg.applicationInfo != null
                        ? ps.pkg.applicationInfo.splitSourceDirs : null;
                if (splitPaths != null) {
                    for (String splitPath : splitPaths) {
                        if (splitPath != null) {
                            NativeUtils.copyNativeLib(new File(splitPath), nativeDir);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
        if (option.isFlag(InstallOption.FLAG_STORAGE)) {
            
            File origFile = new File(ps.pkg.baseCodePath);
            File newFile = BEnvironment.getBaseApkDir(ps.pkg.packageName);
            try {
                if (option.isFlag(InstallOption.FLAG_URI_FILE)) {
                    boolean b = FileUtils.renameTo(origFile, newFile);
                    if (!b) {
                        FileUtils.copyFile(origFile, newFile);
                    }
                } else {
                    FileUtils.copyFile(origFile, newFile);
                }
                newFile.setReadOnly();
                
                ps.pkg.baseCodePath = newFile.getAbsolutePath();

                String[] splitPaths = ps.pkg.applicationInfo != null
                        ? ps.pkg.applicationInfo.splitSourceDirs : null;
                if (splitPaths != null && splitPaths.length > 0) {
                    String[] copiedSplitPaths = new String[splitPaths.length];
                    for (int i = 0; i < splitPaths.length; i++) {
                        File splitSource = new File(splitPaths[i]);
                        File splitTarget = new File(newFile.getParentFile(), splitSource.getName());
                        FileUtils.copyFile(splitSource, splitTarget);
                        splitTarget.setReadOnly();
                        copiedSplitPaths[i] = splitTarget.getAbsolutePath();
                    }
                    ps.pkg.applicationInfo.splitSourceDirs = copiedSplitPaths;
                    ps.pkg.applicationInfo.splitPublicSourceDirs = copiedSplitPaths.clone();
                }
            } catch (IOException e) {
                e.printStackTrace();
                return -1;
            }
        } else if (option.isFlag(InstallOption.FLAG_SYSTEM)) {
            
        }
        return 0;
    }
}
