package top.niunaijun.blackbox.core;


import android.os.Process;
import android.os.Binder;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.Keep;

import java.io.File;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import dalvik.system.DexFile;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.utils.compat.DexFileCompat;
import top.niunaijun.blackbox.core.system.user.BUserHandle;
import top.niunaijun.blackbox.fake.frameworks.BActivityManager;

import top.niunaijun.blackbox.core.system.JarManager;
import top.niunaijun.blackbox.utils.Slog;


public class NativeCore {
    public static final String TAG = "NativeCore";

    private static final long CALLER_UID_CACHE_MS = 1000L;
    private static final long HOST_CALLER_CACHE_MS = 150L;
    private static final ConcurrentHashMap<Integer, CachedCallerUid> sCallerUidCache =
            new ConcurrentHashMap<>();
    private static final ThreadLocal<Boolean> sResolvingCallerUid = new ThreadLocal<>();

    private static final class CachedCallerUid {
        final int uid;
        final long resolvedAt;

        CachedCallerUid(int uid, long resolvedAt) {
            this.uid = uid;
            this.resolvedAt = resolvedAt;
        }
    }

    private static int resolveIncomingVirtualCallerUid(int callingPid, int originalUid) {
        long now = SystemClock.elapsedRealtime();
        CachedCallerUid cached = sCallerUidCache.get(callingPid);
        if (cached != null) {
            long cacheWindow = cached.uid == originalUid
                    ? HOST_CALLER_CACHE_MS : CALLER_UID_CACHE_MS;
            if (now - cached.resolvedAt <= cacheWindow) {
                return cached.uid;
            }
        }

        // Avoid recursive service discovery if the Activity Manager Binder is not
        // cached yet and resolving it itself causes another Binder UID query.
        if (Boolean.TRUE.equals(sResolvingCallerUid.get())) {
            return originalUid;
        }
        sResolvingCallerUid.set(Boolean.TRUE);
        try {
            int virtualUid = BActivityManager.get().getVirtualUidForPid(callingPid);
            if (BUserHandle.isApp(virtualUid)) {
                sCallerUidCache.put(callingPid, new CachedCallerUid(virtualUid, now));
                Log.d(TAG, "Mapped incoming Binder PID " + callingPid
                        + " to virtual UID " + virtualUid);
                return virtualUid;
            }
            // Briefly cache non-virtual callers as well; this avoids a server IPC
            // for every Binder callback from the long-lived host process. The short
            // window limits the risk of a PID being reused by a new virtual process.
            sCallerUidCache.put(callingPid, new CachedCallerUid(originalUid, now));
            return originalUid;
        } catch (Throwable error) {
            Log.w(TAG, "Unable to map Binder caller PID " + callingPid
                    + " to a virtual UID; preserving original UID " + originalUid, error);
            return originalUid;
        } finally {
            sResolvingCallerUid.remove();
        }
    }


    static {

        System.loadLibrary("blackbox");
    }

    public static native void init(int apiLevel);

    public static native void enableIO();

    public static native void addIORule(String targetPath, String relocatePath);

    public static native void hideXposed();

    public static native boolean disableHiddenApi();

    public static native boolean disableResourceLoading();


    @Keep
    public static int getCallingUid(int origCallingUid) {
        try {
            if (origCallingUid > 0 && origCallingUid < Process.FIRST_APPLICATION_UID) {
                return origCallingUid;
            }
            if (origCallingUid > Process.LAST_APPLICATION_UID) {
                return origCallingUid;
            }
            if (origCallingUid != BlackBoxCore.getHostUid()
                    || !BlackBoxCore.get().isBlackProcess()) {
                return origCallingUid;
            }

            String appPackageName = BlackBoxCore.getAppPackageName();
            if ("com.google.android.webview".equals(appPackageName)) {
                return Process.myUid();
            }

            int callingPid = Binder.getCallingPid();
            if (callingPid != Process.myPid()) {
                // The kernel UID is shared by all virtual apps. Resolve the actual
                // remote virtual process by PID; if it is a host/system process,
                // retain the original host UID instead of impersonating this app.
                return resolveIncomingVirtualCallerUid(callingPid, origCallingUid);
            }

            // Outside a Binder transaction Android reports the process's own UID,
            // not the UID of the process that originally launched it.
            int ownVirtualUid = BUserHandle.getUid(
                    BActivityThread.getUserId(), BActivityThread.getBAppId());
            return BUserHandle.isApp(ownVirtualUid) ? ownVirtualUid : origCallingUid;
        } catch (Throwable e) {
            Log.e(TAG, "Error in getCallingUid: " + e.getMessage(), e);
            return origCallingUid;
        }
    }

    @Keep
    public static String redirectPath(String path) {
        return IOCore.get().redirectPath(path);
    }

    @Keep
    public static File redirectPath(File path) {
        return IOCore.get().redirectPath(path);
    }

    @Keep
    public static long[] loadEmptyDex() {
        try {
            File emptyJar = JarManager.getInstance().getEmptyJar();
            if (emptyJar == null) {
                Log.w(TAG, "Empty JAR not available, attempting sync initialization");
                JarManager.getInstance().initializeSync();
                emptyJar = JarManager.getInstance().getEmptyJar();
            }

            if (emptyJar == null || !emptyJar.exists()) {
                Log.e(TAG, "Empty JAR file not found or invalid");
                return new long[]{};
            }

            DexFile dexFile = new DexFile(emptyJar);
            List<Long> cookies = DexFileCompat.getCookies(dexFile);
            long[] longs = new long[cookies.size()];
            for (int i = 0; i < cookies.size(); i++) {
                longs[i] = cookies.get(i);
            }
            Log.d(TAG, "Successfully loaded empty DEX with " + cookies.size() + " cookies");
            return longs;
        } catch (Exception e) {
            Log.e(TAG, "Failed to load empty DEX", e);
        }
        return new long[]{};
    }


    private static long[] createFallbackEmptyDex() {
        try {
            Slog.d(TAG, "Creating fallback empty DEX");



            byte[] emptyDexBytes = createMinimalDexBytes();


            File tempDexFile = File.createTempFile("fallback_empty", ".dex");
            tempDexFile.deleteOnExit();

            java.io.FileOutputStream fos = new java.io.FileOutputStream(tempDexFile);
            fos.write(emptyDexBytes);
            fos.close();


            DexFile dexFile = new DexFile(tempDexFile);
            List<Long> cookies = DexFileCompat.getCookies(dexFile);

            if (cookies != null && !cookies.isEmpty()) {
                long[] longs = new long[cookies.size()];
                for (int i = 0; i < cookies.size(); i++) {
                    longs[i] = cookies.get(i);
                }

                Slog.d(TAG, "Successfully created fallback empty DEX with " + cookies.size() + " cookies");
                return longs;
            }

        } catch (Exception e) {
            Slog.e(TAG, "Error creating fallback empty DEX: " + e.getMessage());
        }


        Slog.w(TAG, "Returning empty DEX array as last resort");
        return new long[]{};
    }


    private static byte[] createMinimalDexBytes() {





        byte[] dexHeader = {
            'd', 'e', 'x', '\n',
            0x30, 0x33, 0x35, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x70, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00
        };

        return dexHeader;
    }
}
