package top.niunaijun.blackbox.core.system;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.core.env.AppSystemEnv;
import top.niunaijun.blackbox.core.env.BEnvironment;
import top.niunaijun.blackbox.core.system.accounts.BAccountManagerService;
import top.niunaijun.blackbox.core.system.am.BActivityManagerService;
import top.niunaijun.blackbox.core.system.am.BJobManagerService;
import top.niunaijun.blackbox.core.system.location.BLocationManagerService;
import top.niunaijun.blackbox.core.system.notification.BNotificationManagerService;
import top.niunaijun.blackbox.core.system.os.BStorageManagerService;
import top.niunaijun.blackbox.core.system.pm.BPackageInstallerService;
import top.niunaijun.blackbox.core.system.pm.BPackageManagerService;

import top.niunaijun.blackbox.core.system.user.BUserHandle;
import top.niunaijun.blackbox.core.system.user.BUserManagerService;
import top.niunaijun.blackbox.entity.pm.InstallOption;
import top.niunaijun.blackbox.utils.Slog;

import top.niunaijun.blackbox.core.system.JarManager;


public class BlackBoxSystem {
    private static BlackBoxSystem sBlackBoxSystem;
    private final List<ISystemService> mServices = new ArrayList<>();
    private final List<ISystemService> mReadyServices = new ArrayList<>();
    private final static AtomicBoolean isStartup = new AtomicBoolean(false);

    public static BlackBoxSystem getSystem() {
        if (sBlackBoxSystem == null) {
            synchronized (BlackBoxSystem.class) {
                if (sBlackBoxSystem == null) {
                    sBlackBoxSystem = new BlackBoxSystem();
                }
            }
        }
        return sBlackBoxSystem;
    }

    public synchronized void startup() {
        if (isStartup.get()) {
            return;
        }

        final long startupStartedAt = System.currentTimeMillis();
        Slog.d("BlackBoxSystem", "System startup beginning");
        BEnvironment.load();

        if (mServices.isEmpty()) {
            // User state is loaded before package scanning so package services
            // never observe an uninitialized virtual-user registry.
            ISystemService[] services = {
                    BUserManagerService.get(),
                    BPackageManagerService.get(),
                    BActivityManagerService.get(),
                    BJobManagerService.get(),
                    BStorageManagerService.get(),
                    BPackageInstallerService.get(),
                    BProcessManagerService.get(),
                    BAccountManagerService.get(),
                    BLocationManagerService.get(),
                    BNotificationManagerService.get()
            };
            // addAll happens only after every singleton was obtained. If a
            // constructor fails, a later startup retry rebuilds the full list.
            mServices.addAll(Arrays.asList(services));
        }

        for (ISystemService service : mServices) {
            if (mReadyServices.contains(service)) {
                continue;
            }
            final long serviceStartedAt = System.currentTimeMillis();
            final String serviceName = service.getClass().getSimpleName();
            try {
                Slog.d("BlackBoxSystem", "Starting system service: " + serviceName);
                service.systemReady();
                mReadyServices.add(service);
                Slog.d("BlackBoxSystem", "System service ready: " + serviceName
                        + " in " + (System.currentTimeMillis() - serviceStartedAt) + "ms");
            } catch (Throwable error) {
                Slog.e("BlackBoxSystem", "System service failed: " + serviceName, error);
                if (error instanceof RuntimeException) {
                    throw (RuntimeException) error;
                }
                if (error instanceof Error) {
                    throw (Error) error;
                }
                throw new IllegalStateException("System service failed: " + serviceName, error);
            }
        }

        List<String> preInstallPackages = AppSystemEnv.getPreInstallPackages();
        for (String preInstallPackage : preInstallPackages) {
            try {
                if (!BPackageManagerService.get().isInstalled(preInstallPackage, BUserHandle.USER_ALL)) {
                    PackageInfo packageInfo = BlackBoxCore.getPackageManager().getPackageInfo(preInstallPackage, 0);
                    BPackageManagerService.get().installPackageAsUser(packageInfo.applicationInfo.sourceDir, InstallOption.installBySystem(), BUserHandle.USER_ALL);
                }
            } catch (PackageManager.NameNotFoundException ignored) {
            }
        }

        JarManager.getInstance().initializeAsync();
        isStartup.set(true);
        Slog.d("BlackBoxSystem", "System startup completed in "
                + (System.currentTimeMillis() - startupStartedAt) + "ms");
    }

    public boolean isStarted() {
        return isStartup.get();
    }
}
