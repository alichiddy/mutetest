package top.niunaijun.blackbox.utils;

import android.os.Bundle;

import java.lang.reflect.Constructor;
import java.util.Set;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.system.user.BUserHandle;
import top.niunaijun.blackbox.utils.compat.ContextCompat;

/** Utilities for keeping AttributionSource aligned with BlackBox's Binder UID identity. */
public class AttributionSourceUtils {
    private static final String TAG = "AttributionSourceUtils";

    private static int virtualUid() {
        // Hooks can also be reached from BlackBox's real host process. In that
        // process there is no AppConfig; getBAppId() would return its placeholder
        // value 10000, which is not the host UID and fails AttributionSource checks.
        if (BActivityThread.getAppConfig() == null) {
            return BlackBoxCore.getHostUid();
        }
        String packageName = BlackBoxCore.getAppPackageName();
        if ("com.google.android.webview".equals(packageName)) {
            return BlackBoxCore.getHostUid();
        }
        int uid = BUserHandle.getUid(
                BActivityThread.getUserId(), BActivityThread.getBAppId());
        return BUserHandle.isApp(uid) ? uid : BlackBoxCore.getHostUid();
    }

    public static String getVirtualPackageName() {
        return ContextCompat.getVirtualPackageName();
    }

    public static void fixAttributionSourceInArgs(Object[] args) {
        if (args == null) return;
        for (Object arg : args) {
            if (arg == null) continue;
            if (arg.getClass().getName().equals("android.content.AttributionSource")) {
                fixAttributionSourceUid(arg);
            } else if (arg instanceof Bundle) {
                fixAttributionSourceInBundle((Bundle) arg);
            }
        }
    }

    public static void fixAttributionSourceUid(Object attributionSource) {
        if (attributionSource == null) return;
        ContextCompat.fixAttributionSourceState(
                attributionSource, virtualUid(), getVirtualPackageName());
    }

    /**
     * IContentProvider calls cross a real Binder boundary from the host process.
     * Android 12 validates AttributionSource.uid against the actual Binder caller,
     * which is the host application's UID, not BlackBox's virtual UID.
     */
    public static void fixProviderBoundaryAttributionInArgs(Object[] args) {
        if (args == null) return;
        for (Object arg : args) {
            if (arg == null) continue;
            if (arg.getClass().getName().equals("android.content.AttributionSource")) {
                fixProviderBoundaryAttribution(arg);
            } else if (arg instanceof Bundle) {
                fixProviderBoundaryAttributionInBundle((Bundle) arg);
            }
        }
    }

    private static void fixProviderBoundaryAttribution(Object attributionSource) {
        ContextCompat.fixAttributionSourceState(
                attributionSource, BlackBoxCore.getHostUid(), BlackBoxCore.getHostPkg());
    }

    private static void fixProviderBoundaryAttributionInBundle(Bundle bundle) {
        if (bundle == null) return;
        try {
            for (String key : bundle.keySet()) {
                Object value = bundle.get(key);
                if (value == null) continue;
                if (value.getClass().getName().equals("android.content.AttributionSource")) {
                    fixProviderBoundaryAttribution(value);
                } else if (value instanceof Bundle) {
                    fixProviderBoundaryAttributionInBundle((Bundle) value);
                }
            }
        } catch (Throwable e) {
            Slog.w(TAG, "Unable to align provider attribution: " + e.getMessage());
        }
    }

    public static void fixAttributionSourceInBundle(Bundle bundle) {
        if (bundle == null) return;
        try {
            Set<String> keys = bundle.keySet();
            for (String key : keys) {
                Object value = bundle.get(key);
                if (value == null) continue;
                if (value.getClass().getName().equals("android.content.AttributionSource")) {
                    fixAttributionSourceUid(value);
                } else if (value instanceof Bundle) {
                    fixAttributionSourceInBundle((Bundle) value);
                }
            }
        } catch (Throwable e) {
            Slog.w(TAG, "Unable to inspect attribution extras: " + e.getMessage());
        }
    }

    public static Object createSafeAttributionSource() {
        int uid = virtualUid();
        String packageName = getVirtualPackageName();
        try {
            Class<?> clazz = Class.forName("android.content.AttributionSource");
            try {
                Constructor<?> constructor = clazz.getDeclaredConstructor(int.class, String.class, String.class);
                constructor.setAccessible(true);
                return constructor.newInstance(uid, packageName, null);
            } catch (NoSuchMethodException ignored) {
            }
            try {
                Constructor<?> constructor = clazz.getDeclaredConstructor(int.class, String.class);
                constructor.setAccessible(true);
                return constructor.newInstance(uid, packageName);
            } catch (NoSuchMethodException ignored) {
            }
            Constructor<?> constructor = clazz.getDeclaredConstructor();
            constructor.setAccessible(true);
            Object source = constructor.newInstance();
            ContextCompat.fixAttributionSourceState(source, uid, packageName);
            return source;
        } catch (Throwable e) {
            Slog.w(TAG, "Could not create AttributionSource: " + e.getMessage());
            return null;
        }
    }

    public static boolean validateAttributionSource(Object attributionSource) {
        if (attributionSource == null) return false;
        fixAttributionSourceUid(attributionSource);
        return true;
    }
}
