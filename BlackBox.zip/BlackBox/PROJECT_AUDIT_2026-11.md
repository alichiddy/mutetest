# BlackBox project audit — 2026-11-10

## Scope and current architecture

This is a source-level audit of the supplied `BlackBox.zip` project. The project contains the BlackBox virtual-app engine, Android/Kotlin launcher, Java service and package-manager layers, AIDL interfaces, and native Binder/filesystem hooks.

The current engine already models installed packages and app data per virtual user. `BEnvironment` stores private data under `data/user/<userId>/<packageName>`, so installing the same package into separate virtual users gives it separate private data. The current process manager also has a fixed pool of 50 host-process slots; these are capacity slots, not 50 processes started at app launch.

Installed-app cloning already attempts to preserve split APK clusters: `BlackBoxCore.installPackageAsUser(String, userId)` verifies that the base APK and every `splitSourceDir` exist in the same package directory, then passes the complete directory to the package parser. `CopyExecutor` copies split APKs and native libraries for storage installs. This still needs device tests against real multi-split packages and ABI/density configurations.

## Changes in this audit

### 1. Virtual UID and Binder caller identity

`ProcessRecord.buid` is an appId, not a full Android UID. Process startup now combines appId and userId using `BUserHandle.getUid(...)` when it records the virtual process that initiated another process. Package-name lookup splits a full virtual UID into appId and userId; pending-intent records retain the full virtual caller UID.

A deeper review of the Build 16 sign-in trace found a separate, more important flaw: the native `Binder.getCallingUid()` hook reused the process's saved `callingBUid` for every Binder call. That value describes the process that initiated the current virtual process; it is not a reliable answer for every incoming Binder transaction. The correct identity depends on direction: outside a transaction, report the current virtual app's own UID; during an incoming transaction, resolve the remote caller PID against the authoritative server process table and return that caller's virtual UID. If the caller is a real host/system process, preserve the original Android UID. Positive PID mappings are cached for one second; non-virtual host mappings are cached for only 150 ms to avoid repeated server IPCs without retaining stale PID identities for long.

`AttributionSource` now describes the current virtual app (its own package and full user-scoped UID), rather than the process that originally launched it. Real system-provider calls continue to use the host identity. The Activity Manager AIDL exposes the narrow PID-to-virtual-UID lookup needed by the native hook. Several attribution-related `ClassInvocationStub` registrations whose `getWho()` returned `null` remain removed because they never installed their advertised hooks.

### 2. Smaller default Google bundle

The normal GMS enable action now installs only the core set when those packages are present on the host device:

- Google Services Framework (`com.google.android.gsf`)
- Google Play services (`com.google.android.gms`)
- GSF login (`com.google.android.gsf.login`)
- Google Play Store (`com.android.vending`)

The previous backup, sync-adapter, setup-wizard, feedback, games, and wearable packages are not part of the default install. An explicit `installFullGApps()` method retains the old full-bundle path for a future advanced setting. If an install fails, rollback removes only packages installed during that attempt; it no longer removes components that were already present for that virtual user.

This reduces the installed Google package footprint, but it does not guarantee that a given target app needs or will use fewer GMS background processes. Apps that do not need Google APIs should be cloned without enabling GMS at all.

### 3. Do not suppress fatal exceptions

The previous global uncaught-exception handler classified Google, WebView, attribution and context exceptions as recoverable and returned without delegating to Android. An uncaught exception is fatal to the affected thread/process; swallowing it can leave a process alive with a dead main thread. The handler now records the category and delegates to the original Android handler, preserving normal crash reporting and process cleanup.

### 4. Remove forced garbage collection from scrolling and app-list loading

The app-list code was explicitly calling `System.gc()` while loading app tiles and while scrolling, and one helper slept for 100 ms after the collection request. ART already manages garbage collection; forcing it during UI work can create pauses without guaranteeing useful memory recovery. Those forced-GC calls were removed. Icon loading still backs off when the Java heap is above its configured threshold, and RecyclerView's retained view cache/prefetch sizes were reduced.

### 5. Device-property spoofing is opt-in

The native library previously installed a global Pixel 6 / Android 12 property spoof hook automatically when `libblackbox.so` loaded. On unrelated hardware this creates contradictory device identity signals (for example, a Google fingerprint with MediaTek hardware). The hook is now disabled by default and can be explicitly enabled at compile time with `BLACKBOX_ENABLE_DEVICE_SPOOF=1` if a documented compatibility test demonstrates a need.

### 6. Server readiness and startup recovery

The main process previously probed the server with a request for a deliberately nonexistent service named `test`, then treated any non-null response Bundle as proof that the virtual system was ready. The provider correctly returned an empty Bundle for that unknown service, producing the misleading `Service test not found` log and allowing a partially initialized server to be reported as ready. The probe now requests the real Package Manager Binder and requires it to be alive. The delayed provider check uses the same criterion.

`BlackBoxSystem.startup()` previously set its one-shot startup flag before loading services. If any `systemReady()` step failed, the flag stayed set and later calls could not retry the failed initialization. Startup now marks itself complete only after all services and preinstalled-package handling finish; successful service stages are remembered so a later retry resumes at the failed stage. The virtual-user registry is loaded before package scanning, and each service failure is logged with its service name. `SystemCallProvider.call()` retries startup if a VM Binder request arrives while startup is incomplete. A package-root enumeration failure now aborts package-manager readiness instead of silently treating an inaccessible directory as an empty installation list.

### 7. Remove a no-op WorkManager hook and correct proxy slot mapping

`WorkManagerProxy` used reflection to find WorkManager, but its `inject()` implementation was empty, so it never installed a proxy. Its registration has been removed; this also removes the irrelevant reflection warning from startup. The manifest entry for `ProxyPendingActivity$P49` was incorrectly assigned to process `:p48`; it now uses `:p49`, matching the other P49 proxy components. The framework service-acquisition negative-cache window was reduced from 2,000 ms to 300 ms so the app-list loader's short retry sequence can actually reach a fresh provider request instead of spending all attempts inside the old cooldown window.

## Validation performed here

- The supplied ZIP passed `unzip -t` with no archive errors.
- GitHub Actions run #16 (9 November 2026) completed successfully, built the release APK, and signed it with the existing BlackBox certificate. The user reported that this build still did not proceed through Google Play sign-in. Run #16 predates the Binder caller-identity correction documented below and does not validate this revision.
- Earlier baseline source archive SHA-256: `4b6716db3fdebc0942c48814f5f69863f54c65fa110e6e7878aa19493392103a`. The follow-up source archive received for this revision had SHA-256 `7102474d1705df202398bb0f7cb0a629db90d0de268a854c524f3eae79516606` before the changes documented here.
- Source paths and call sites for virtual UID propagation, package lookup, split APK installation, Google package installation, native property spoofing, and server startup/readiness were inspected.
- The local environment has Java 21 but no Android SDK/NDK and no cached Gradle 8.14.5 distribution. Running the Gradle wrapper failed before project configuration because `services.gradle.org` could not be resolved. Therefore no APK build or Android runtime test is claimed.

## Remaining work before calling this project complete

1. Build debug and release variants in the existing Android SDK/NDK GitHub Actions environment; resolve every compile, AIDL, native, packaging, and R8 error.
2. Build the updated AIDL/Java/native project, then verify Binder caller/source UID pairs on Android 12, including host-to-virtual, virtual-to-virtual, and system-provider transactions.
3. Exercise split APK cloning with base + ABI + density + language splits, app updates, and reinstall/rollback paths.
4. Verify two or more virtual users can run the same app with isolated data and independent process lifecycles.
5. Measure idle and active PSS/RSS for the host, each clone, and optional GMS processes on the Vivo Y21. Remove unnecessary startup hooks only after measuring their impact.
6. Test login, WebView/Custom Tabs, notifications, file sharing, permissions, and network behaviour for Claude and ChatGPT on the target device.

The source-level Binder identity, authenticator diagnostics, and startup/readiness changes are not yet APK-build or device verified. This audit is an intermediate source revision, not a claim that the final APK is built or that Google sign-in is fixed on-device.
