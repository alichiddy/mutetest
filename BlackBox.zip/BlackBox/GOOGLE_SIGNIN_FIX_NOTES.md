# BlackBox 4.0.0 – Google sign-in investigation notes

This document records the historical account/provider fixes and the subsequent corrections driven by the Vivo Y21 Android 12 sign-in trace. The later PID-aware Binder identity section supersedes earlier assumptions about `callingBUid`.

## Prior fixes carried into this source

1. **AttributionSource UID alignment (superseded by the PID-aware correction below).** The earlier revision attempted to align `AttributionSourceState.uid` with the saved `callingBUid`. Build 16 still produced `Calling uid: 10005 doesn't match source uid: 10404`, showing that a single saved process-launch identity is not sufficient for all Binder transactions. The current revision no longer treats `callingBUid` as the current process identity or as every incoming caller's identity.
2. **Provider routing and argument integrity.** Cached system providers are now wrapped with `SystemProviderStub`, not the virtual-provider wrapper. The provider proxies rewrite only the first calling-package argument; they no longer replace every String argument (which could corrupt provider method names, query selections, sort orders, and other data).
3. **No silent permission/UID masking.** The virtual ContentProvider wrapper no longer turns arbitrary `SecurityException`, permission failures, or provider errors into fabricated `true`, `1`, or empty-Bundle values. Exceptions are propagated after the attribution identity is corrected, making genuine failures visible.
4. **Earlier Binder UID consistency attempt (superseded).** Removed the stack-trace heuristic that changed `Binder.getCallingUid()` to SYSTEM_UID for Settings/FeatureFlag calls. The later PID-aware correction below replaces the remaining static `callingBUid` substitution with per-transaction caller resolution.
5. **Activity placeholder ordering.** Proxy and pending-intent activities now submit the replacement target activity before finishing the placeholder, avoiding premature task teardown and unnecessary extra Recents tasks in fallback launch paths.
6. **Explicit account user.** `addAccountAsUser()` now honours the userId argument supplied by Android rather than silently substituting the current virtual user.

## Device evidence addressed

The 2026-11-10 trace reported repeated `SecurityException: Calling uid: 10005 doesn't match source uid: 10404`. Android's `AttributionSource.enforceCallingUid()` throws this when the UID of the incoming Binder caller differs from the UID claimed by the attribution source. The previous patch focused on provider type but missed that `NativeCore.getCallingUid()` reused a static process-launch UID even while handling incoming Binder transactions. That could make a host AB/server callback appear to come from the virtual GMS identity (10005), while the callback's source correctly identified the host process (10404). The new correction resolves incoming callers by PID in the server's process table and preserves the original host UID when the caller is not a virtual process.

The trace also showed GMS reaching `PreAddAccountActivity`, `UnpackingRedirectActivity`, and `AccountIntroActivity`; no `AndroidRuntime` fatal exception was included in the supplied excerpt. The resource-ID warning and optional MANAGE_USERS warning are retained for observation rather than hidden with fake return values.

**Build status:** source only. This environment has no Android SDK/NDK or Gradle distribution, so a device APK build must be run by the existing GitHub Actions workflow. A successful build still requires on-device sign-in verification.


## Follow-up audit — 2026-11-10

A deeper audit found that `ProcessRecord.buid` is an appId, while `callingBUid` is consumed by the native `Binder.getCallingUid()` hook and by `AttributionSource` construction. Passing an appId as a full UID is only accidentally correct for virtual user 0. The process manager now composes the full user-scoped UID, and the Binder hook validates the appId portion so secondary virtual users are supported. Package-name lookup now resolves the user component from the full UID, and pending-intent records retain the full virtual caller UID.

Several earlier attribution proxy registrations were inert because their `getWho()` methods returned null; the generic class-hook injector therefore exited without installing them. Those no-op registrations have been removed rather than being treated as active fixes.

The full Google package bundle is no longer the default: the normal GMS enable action installs only GSF, GMS, GSF login, and Play Store when available. A separate `installFullGApps()` path remains for explicit full-bundle use. Failed installation now rolls back only packages newly installed by that attempt.

Uncaught exceptions are no longer swallowed as if Google/WebView/attribution crashes were recoverable. They are logged and delegated to Android's original uncaught-exception handler. The hard-coded Pixel 6 system-property spoof is disabled by default because it conflicts with real device hardware identity; it is compile-time opt-in only.

**Validation:** source-level changes only. This environment has no Android SDK/NDK or cached Gradle distribution, so no APK build or device sign-in test is claimed. See `PROJECT_AUDIT_2026-11.md`.

The launcher app's app-list screen also no longer forces garbage collection while loading or scrolling. It skips icon loading under heap pressure and keeps a smaller RecyclerView view cache/prefetch window to reduce avoidable UI memory retention.


## Follow-up startup/readiness audit — 2026-11-10

The startup logs contained two misleading signals: the main process queried a nonexistent service named `test` and treated any non-null response Bundle as proof that the virtual server was ready; and `WorkManagerProxy` attempted to reflect WorkManager even though its `inject()` method was empty. The readiness check now requests the real Package Manager Binder and requires it to be alive, and the inert WorkManager registration has been removed.

`BlackBoxSystem.startup()` now commits its started flag only after successful initialization and remembers completed service stages so a later request can retry from the stage that failed. The provider retries startup before serving a VM Binder request if startup is incomplete. Package scanning fails explicitly if the virtual app directory cannot be enumerated instead of reporting a false empty scan. The `ProxyPendingActivity$P49` manifest entry now maps to `:p49`, and the service wrapper's negative retry cache is 300 ms to fit the app-list loader's retry cadence.

These are source-level corrections. The Android APK has not yet been rebuilt or verified on the Vivo device.


## Follow-up Binder identity correction — 2026-11-10

The Build 16 trace and source review showed that `callingBUid` cannot serve as a universal `Binder.getCallingUid()` replacement. It records the virtual process that initiated a new process (or the target package UID when launched by the host); it does not identify the remote caller for every later Binder transaction.

The revised hook now follows Android's call direction:

- Outside a Binder transaction, it returns the current virtual process's own full UID (`userId` + `appId`).
- During an incoming Binder transaction, it resolves `Binder.getCallingPid()` through a new Activity Manager AIDL method backed by `BProcessManagerService.findProcessByPid()`. Virtual callers receive their own full virtual UID; host callers retain the original host UID.
- Positive PID mappings are cached for one second; non-virtual host mappings are cached for 150 ms. This reduces repeated cross-process lookups while limiting stale-PID exposure. A thread-local recursion guard preserves the original UID if service discovery itself triggers another UID query.
- `AttributionSourceUtils` and `ContextCompat` now stamp the current virtual app's own UID and package, not its launcher/parent identity. WebView's host-identity exception is preserved.

The account-manager path now logs missing authenticator types, returned sign-in intent details, and rejected/unresolvable intents without logging account names or tokens. Provider wrapper selection logs the authority and whether the real-system or virtual-provider wrapper was chosen. These diagnostics are intended to make any remaining failure actionable rather than silently fabricating success.

**Validation status:** source-level delimiter and contract checks passed, and all app XML parsed. No Android SDK/NDK or Gradle distribution is available in this environment, so the new AIDL interface and APK have not been compiled here. This revision must pass the existing GitHub Actions build before any device test.
