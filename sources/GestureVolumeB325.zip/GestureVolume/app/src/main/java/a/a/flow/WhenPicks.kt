package a.a.flow

import a.a.strip.StripItem
import a.a.strip.StripScope
import a.a.strip.WhenRules
import a.a.ui.motion.TextButton
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Every cell of the main cells window (folders' cells included) that has an action, by name. [onPicked] gets the
 * key the "A chosen cell runs" event uses (WhenRules.cellKey) and the name to show.
 */
@Composable
internal fun WhenCellPicker(onPicked: (key: String, name: String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val cells = remember {
        val out = ArrayList<StripItem>()
        fun walk(list: List<StripItem>) { for (it in list) { if (it.children != null) walk(it.children) else if (it.action.isNotEmpty()) out.add(it) } }
        walk(StripScope.load(context, StripScope.MAIN).items)
        out
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                Text("Choose a cell", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                if (cells.isEmpty()) Text("The cells window has no cell with an action yet.")
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(cells) { _, it ->
                        Text(
                            it.label.ifEmpty { it.action.take(50) }, fontSize = 15.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                onPicked(WhenRules.cellKey(it.label, it.action), it.label.ifEmpty { it.action.take(30) })
                            }.padding(vertical = 12.dp),
                        )
                    }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    }
}
