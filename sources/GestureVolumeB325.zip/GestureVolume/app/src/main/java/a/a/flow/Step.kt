package a.a.flow

import org.json.JSONArray
import org.json.JSONObject

/**
 * One block of a flow. Old flows are flat lists (if / repeat opened by a step and closed by "end");
 * the canvas editor stores blocks with an [id], a [n] (bottom output: the next block), an [r]
 * (right output: the other branch, or a second thing running at the same time) and a position
 * [x], [y]. Flat flows are turned into this form when they are opened.
 * Nothing here is loaded until a flow is edited or run, so it costs no memory idle.
 */
data class Step(
    val type: String, val a: String = "", val b: String = "", val c: String = "", val d: String = "",
    val id: Int = 0, val n: Int = 0, val r: Int = 0, val x: Float = 0f, val y: Float = 0f,
    val e: String = "", val f: String = "",
) {
    fun toJson(): JSONObject {
        val o = JSONObject().put("t", type).put("a", a).put("b", b).put("c", c)
        if (d.isNotEmpty()) o.put("d", d)
        if (e.isNotEmpty()) o.put("e", e)
        if (f.isNotEmpty()) o.put("f", f)
        if (id > 0) o.put("i", id).put("n", n).put("r", r).put("x", x.toDouble()).put("y", y.toDouble())
        return o
    }

    /** A line for the editor list. */
    fun describe(): String = when (type) {
        SHELL -> "Shell: $a" + if (b.isNotEmpty()) "   -> $b" else ""
        WAIT -> if (c == "expr") "Wait ($a) ms" else "Wait $a ms"
        MESSAGE -> "Message: $a"
        LAUNCH -> "Open app: $a" + (if (c.isNotEmpty()) " / $c" else "") + if (b.isNotEmpty()) "  (back after $b ms)" else ""
        INTENT -> if (b == "raw") "Raw shortcut: ${a.take(40)}" else "Intent: $a"
        SET -> if (c == "expr") "Set $a to ($b)" else "Set $a = $b"
        IF -> if (b == "expr") "If ($a)" else "If $a $b $c"
        ELSE -> "Else"
        REPEAT -> if (b == "each") "For each ${c.ifEmpty { "item" }} in ($a)" else "Repeat $a times"
        END -> "End"
        HTTP -> "Web $b $a" + if (c.isNotEmpty()) "   -> $c" else ""
        RUN -> "Run flow: " + FlowStore.display(a) + if (b == "async") "  (at the same time)" else ""
        STOP -> "Stop"
        BEGIN -> "Start"
        NOTE -> "Note: $a"
        ACTION -> "Do: " + (NativeActions.find(a)?.label ?: a) + (if (b.isNotEmpty()) "  (" + ActionArgs.label(a, b) + ")" else "") + (if (c == "optional") "  [skipped without Shizuku]" else "")
        SHIZUKU -> "Shizuku command: $a" + if (b.isNotEmpty()) "   -> $b" else ""
        BROADCAST -> "Send broadcast: $a  $b"
        OCRWAIT -> "OCR wait: $a ($b) up to $c ms -> ${d.ifEmpty { "ocr" }}" + (if (e.isNotEmpty()) "  [$e digits]" else "") + (if (f.isNotEmpty()) "  [skips $f]" else "")
        COUNTDOWN -> "Countdown $a ms" + (if (b.isNotEmpty()) ": $b" else "") + (if (c.isNotEmpty()) "  (${c})" else "")
        FIELDWAIT -> "Wait for a field with the cursor, up to $a ms"
        WHEN -> "When: " + WhenEvents.eventLabel(a, d) + "  (" + WhenEvents.modeLabel(b) + ")"
        ONLYIF -> "Only if " + WhenEvents.onlyLabel(a, b)
        RATELIMIT -> "Limit \"$a\": at least $b ms between runs"
        else -> "$type $a $b $c".trim()
    }

    companion object {
        const val SHELL = "shell"      // a = command, b = variable that gets the output
        const val WAIT = "wait"        // a = milliseconds
        const val MESSAGE = "message"  // a = text
        const val LAUNCH = "launch"    // a = package, c = activity class ("" = the app's normal start), b = milliseconds to wait before going back to the app that was in front ("" = stay open)
        const val INTENT = "intent"    // a = Intent.toUri string
        const val SET = "set"          // a = variable, b = value
        const val IF = "if"            // a = left, b = operator (= != contains > <), c = right
        const val ELSE = "else"
        const val REPEAT = "repeat"    // a = count
        const val END = "end"
        const val HTTP = "http"        // a = url, b = method, c = variable that gets the answer
        const val RUN = "run"          // a = another flow's name
        const val STOP = "stop"
        const val BEGIN = "begin"      // where a canvas flow starts (never in a flat flow)
        const val NOTE = "note"        // a = text kept from an import, never run
        const val ACTION = "act"       // a = a built-in action id (see NativeActions), b = its argument
        const val SHIZUKU = "psh"      // a = command run with Shizuku's privilege, b = variable for the output, c = "optional" to skip quietly without Shizuku
        const val OCRWAIT = "ocrwait"      // a = source (box:<name>, widget, widgetnow), b = digits | text | both | word:<word>, c = milliseconds to wait, d = variable for what was read (also sets ocr_found), e = exactly this many digits ("" = any), f = readings to ignore, separated by commas (it keeps waiting)
        const val COUNTDOWN = "countdown"  // a = milliseconds, b = text shown, c = show as: bar | notice | both | none ("" = bar), d = opacity 10..100 ("" = 80), e = name (same name = one shared countdown; "" = the text), f = when it already counts: join (continue it) | stop (stop this run) | restart ("" = join)
        const val FIELDWAIT = "fieldwait"  // a = milliseconds to wait (sets field_found)
        const val RATELIMIT = "ratelimit"  // a = name of the limit, b = milliseconds between runs, c = countdown | wait | stop, d = text shown, e = show the countdown as: bar | notice | both | none ("" = bar), f = opacity 10..100 ("" = 80)
        const val BROADCAST = "bcast"  // a = package or package/.Receiver, b = action, c = extras as key=value;key=value
        const val WHEN = "when"        // a = event (WhenRules.EVENTS), b = start | wait | both ("" = start), c = cell key and d = its name (event "a chosen cell runs"), e = wait at most this many ms ("" = until it happens; sets when_found), f = options separated by commas: again, noopen, lift (see WhenEvents)
        const val ONLYIF = "onlyif"    // a = what must hold (WhenRules.ONLY), b = package for "a chosen app is in front"; bottom output = yes, right output = no

        val TYPES = listOf(SHELL, WAIT, MESSAGE, LAUNCH, INTENT, SET, IF, ELSE, REPEAT, END, HTTP, RUN, STOP, NOTE, ACTION, SHIZUKU, BROADCAST, OCRWAIT, COUNTDOWN, FIELDWAIT, RATELIMIT, WHEN, ONLYIF)

        fun fromJson(o: JSONObject) = Step(
            o.optString("t"), o.optString("a"), o.optString("b"), o.optString("c"), o.optString("d"),
            o.optInt("i", 0), o.optInt("n", 0), o.optInt("r", 0), o.optDouble("x", 0.0).toFloat(), o.optDouble("y", 0.0).toFloat(),
            e = o.optString("e"), f = o.optString("f"),
        )
    }
}

