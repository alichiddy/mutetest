@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package a.a.flow

import a.a.utils.AppStarter
import android.content.ComponentName
import android.content.Intent
import a.a.ui.components.MsBox
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import a.a.ui.components.Chevron
import a.a.ui.components.rowColor
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.cardShape
import a.a.ui.screens.strip.SettingRow
import a.a.ui.motion.IconButton
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import a.a.ui.motion.Button
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.abs
import a.a.strip.ScreenOcr
import a.a.strip.WhenRules
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.AppShortcutsPage

/** Where a new block goes, and the dot it was dragged from (fromId 0 = none). */
private class AddCtx(val wx: Float, val wy: Float, val fromId: Int = 0, val slot: Int = 0)

private class CatalogEntry(val label: String, val device: Boolean = false, val make: () -> Step)

/** One line of the long-press menu. */
private class MenuEntry(val title: String, val summary: String, val icon: ImageVector, val go: () -> Unit)

private fun catalog(): List<CatalogEntry> {
    val base = listOf(
        CatalogEntry("Show message") { Step(Step.MESSAGE) },
        CatalogEntry("Delay (wait)") { Step(Step.WAIT, "1000") },
        CatalogEntry("Decision (if yes / no)") { Step(Step.IF, "", "=", "") },
        CatalogEntry("When (an event of the main bar)") { Step(Step.WHEN, WhenRules.SLIDE_IN, WhenEvents.MODE_START) },
        CatalogEntry("Only if (app in front, rotation, keyboard...)") { Step(Step.ONLYIF, WhenRules.ONLY_PORTRAIT) },
        CatalogEntry("Loop (repeat)") { Step(Step.REPEAT, "3") },
        CatalogEntry("Set variable") { Step(Step.SET) },
        CatalogEntry("Open app") { Step(Step.LAUNCH) },
        CatalogEntry("Run raw shortcut (paste it)") { Step(Step.INTENT, "", "raw") },
        CatalogEntry("Read with OCR and wait") { Step(Step.OCRWAIT, "", "digits", "40000", "ocr") },
        CatalogEntry("Countdown") { Step(Step.COUNTDOWN, "120000", "Wait", "bar", "80", f = "join") },
        CatalogEntry("Wait for a field with the cursor") { Step(Step.FIELDWAIT, "30000") },
        CatalogEntry("Limit how often (2-minute rule)") { Step(Step.RATELIMIT, "limit", "120000", "countdown", "Too soon, wait") },
        CatalogEntry("Run another script") { Step(Step.RUN) },
        CatalogEntry("Shell command") { Step(Step.SHELL) },
        CatalogEntry("Shizuku command") { Step(Step.SHIZUKU) },
        CatalogEntry("HTTP request") { Step(Step.HTTP, "", "GET") },
        CatalogEntry("Send intent") { Step(Step.INTENT) },
        CatalogEntry("Send broadcast") { Step(Step.BROADCAST) },
        CatalogEntry("Note") { Step(Step.NOTE) },
        CatalogEntry("Stop") { Step(Step.STOP) },
    )
    val actions = NativeActions.all.filter { !it.id.startsWith("A:") }
        .map { d -> CatalogEntry("Device: " + d.label, device = true) { Step(Step.ACTION, d.id) } }
    return base + actions
}

private val STATES = listOf(
    "Wi-Fi" to "wifi", "Bluetooth" to "bluetooth", "Airplane mode" to "airplane", "Location" to "location",
    "Mobile data" to "mobiledata", "Screen" to "screenon", "Charging" to "charging", "NFC" to "nfc",
    "Hotspot" to "hotspot", "Torch" to "torch", "Data saver" to "datasaver", "Phone locked" to "locked",
    "Music playing" to "musicplaying", "Widget button" to "widgetbutton",
)

private val OPS = listOf(
    "is equal to" to "=", "is not equal to" to "!=", "contains" to "contains", "does not contain" to "!contains",
    "is greater than" to ">", "is less than" to "<", "is at least" to ">=", "is at most" to "<=",
)

/** The canvas editor: replaces the old card list. Nothing stays in memory once it is closed. */
@Composable
fun CanvasEditor(activity: ComponentActivity, name: String, close: () -> Unit) {
    val model = remember { GraphModel(FlowStore.loadGraph(activity, name)) }
    var version by remember { mutableStateOf(0) }
    val viewRef = remember { arrayOfNulls<FlowCanvasView>(1) }
    var running by remember { mutableStateOf(false) }
    var output by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf(0) }
    var menuId by remember { mutableStateOf(0) }
    var addAt by remember { mutableStateOf<AddCtx?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun save() { FlowStore.save(activity, name, model.blocks); version++ }

    fun runFrom(startAt: Int) {
        if (running) return
        save()
        running = true
        output = ""
        viewRef[0]?.clearRun()
        Thread {
            try {
                FlowRunner.run(
                    activity, name, { l -> output += l + "\n" }, { },
                    trace = { id, st, msg -> viewRef[0]?.setState(id, st, msg) },
                    startAt = startAt,
                )
            } finally {
                running = false
            }
        }.start()
    }

    fun addBlock(ctx: AddCtx, step: Step) {
        model.checkpoint()
        var x = ctx.wx
        var y = ctx.wy
        var guard = 0
        while (guard++ < 40 && model.blocks.any { abs(it.x - x) < 20f && abs(it.y - y) < 20f }) { x += 28f; y += 28f }
        val id = model.add(step, x, y)
        if (ctx.fromId != 0) model.connect(ctx.fromId, ctx.slot, id)
        save()
        viewRef[0]?.invalidate()
        if (step.type != Step.STOP) editId = id
    }

    BackHandler { save(); close() }

    val v = version   // read so the buttons below follow undo / redo
    AWindowPage(
        name, onBack = { save(); close() },
        actions = {
            IconButton(onClick = {
                val vw = viewRef[0]
                val cx = (vw?.centerWorldX() ?: 0f) - BlockStyle.W / 2f
                val cy = (vw?.centerWorldY() ?: 0f) - BlockStyle.H / 2f
                addAt = AddCtx(cx, cy)
            }) { Icon(Icons.Filled.Add, contentDescription = "Add a block") }
            IconButton(enabled = !running, onClick = { runFrom(0) }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Run") }
        },
    ) { pad ->
    Column(Modifier.fillMaxSize().padding(pad)) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = { FlowRunner.stopByName(name) }) { Text("Stop") }
            OutlinedButton(enabled = v >= 0 && model.canUndo, onClick = { if (model.undo()) { save(); viewRef[0]?.invalidate() } }) { Text("Undo") }
            OutlinedButton(enabled = v >= 0 && model.canRedo, onClick = { if (model.redo()) { save(); viewRef[0]?.invalidate() } }) { Text("Redo") }
            OutlinedButton(onClick = { viewRef[0]?.fit() }) { Text("Fit") }
            var alwaysOn by remember(name) { mutableStateOf(FlowPrefs.isAlwaysOn(activity, name)) }
            ChoiceChip("Always On", alwaysOn, onClick = { alwaysOn = !alwaysOn; FlowPrefs.setAlwaysOn(activity, name, alwaysOn) })
            OutlinedButton(onClick = { confirmDelete = true }) { Text("Delete script") }
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                FlowCanvasView(ctx, model).also { cv ->
                    cv.listener = object : FlowCanvasView.Listener {
                        override fun onTap(id: Int) { if (model.get(id)?.type != Step.BEGIN) editId = id }
                        override fun onLongPress(id: Int) { menuId = id }
                        override fun onBackgroundLongPress(wx: Float, wy: Float) { addAt = AddCtx(wx - BlockStyle.W / 2f, wy - BlockStyle.H / 2f) }
                        override fun onDropEmpty(fromId: Int, slot: Int, wx: Float, wy: Float) {
                            addAt = AddCtx(wx - BlockStyle.W / 2f, wy, fromId, slot)
                        }
                        override fun onChanged() { save() }
                    }
                    viewRef[0] = cv
                }
            },
        )
        val missing = remember(version) { PrivateValues.missing(activity, model.blocks) }
        if (missing.isNotEmpty()) Text(
            "These {blanks} still need a value: " + missing.joinToString(", "),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 8.dp),
        )
        if (output.isNotEmpty()) Text(
            output.takeLast(600), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
    }

    // ---- add a block (search) ----
    val add = addAt
    if (add != null) {
        var q by remember(add) { mutableStateOf("") }
        val all = remember { catalog() }
        val shown = all.filter { q.isBlank() || it.label.contains(q.trim(), true) }
        val blocksShown = shown.filter { !it.device }
        val deviceShown = shown.filter { it.device }
        val copied = GraphModel.clip
        AlertDialog(
            onDismissRequest = { addAt = null },
            title = { Text("Add a block") },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search blocks") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn(
                        Modifier.heightIn(max = 380.dp).padding(top = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp),
                    ) {
                        if (copied != null && q.isBlank()) item {
                            SettingRow(
                                title = "Paste the copied block", shape = cardShape(0, 1), compact = true,
                                icon = Icons.Filled.ContentCopy, summary = BlockStyle.title(copied),
                                onClick = { addBlock(add, copied); addAt = null },
                            )
                        }
                        if (blocksShown.isNotEmpty()) item { GroupHeading("Blocks", Modifier.padding(top = 10.dp)) }
                        items(blocksShown.size) { i ->
                            val e = blocksShown[i]
                            SettingRow(
                                title = e.label, shape = cardShape(i, blocksShown.size), compact = true,
                                onClick = { addAt = null; addBlock(add, e.make()) },
                            )
                        }
                        if (deviceShown.isNotEmpty()) item { GroupHeading("Device actions", Modifier.padding(top = 10.dp)) }
                        items(deviceShown.size) { i ->
                            val e = deviceShown[i]
                            SettingRow(
                                title = e.label.removePrefix("Device: "), shape = cardShape(i, deviceShown.size), compact = true,
                                onClick = { addAt = null; addBlock(add, e.make()) },
                            )
                        }
                        if (shown.isEmpty()) item {
                            Text("No block matches.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addAt = null }) { Text("Cancel") } },
        )
    }

    // ---- long-press menu ----
    val mid = menuId
    val ms = if (mid != 0) model.get(mid) else null
    if (ms != null) {
        val isBegin = ms.type == Step.BEGIN
        val entries = ArrayList<MenuEntry>()
        if (!isBegin) entries.add(MenuEntry("Edit", "Change what this block does", Icons.Filled.Edit) { menuId = 0; editId = mid })
        entries.add(
            MenuEntry(
                if (isBegin) "Run from the start" else "Start here",
                if (isBegin) "Run the whole script" else "Run the script from this block",
                Icons.Filled.PlayArrow,
            ) { menuId = 0; runFrom(if (isBegin) 0 else mid) },
        )
        if (!isBegin) {
            entries.add(MenuEntry("Copy", "Then paste it from Add a block", Icons.Filled.ContentCopy) { menuId = 0; GraphModel.clip = ms })
            entries.add(MenuEntry("Duplicate", "Make a second block like this one", Icons.Filled.Add) {
                menuId = 0; model.checkpoint(); model.duplicate(mid); save(); viewRef[0]?.invalidate()
            })
        }
        if (ms.n != 0) entries.add(MenuEntry("Disconnect below", "Cut the line that leaves the bottom", Icons.Filled.Close) {
            menuId = 0; model.checkpoint(); model.disconnect(mid, 0); save(); viewRef[0]?.invalidate()
        })
        if (ms.r != 0) entries.add(MenuEntry("Disconnect side", "Cut the line that leaves the side", Icons.Filled.Close) {
            menuId = 0; model.checkpoint(); model.disconnect(mid, 1); save(); viewRef[0]?.invalidate()
        })
        if (!isBegin) entries.add(MenuEntry("Delete", "Remove this block", Icons.Filled.Delete) {
            menuId = 0; model.checkpoint(); model.delete(mid); save(); viewRef[0]?.invalidate()
        })
        AlertDialog(
            onDismissRequest = { menuId = 0 },
            title = { Text(BlockStyle.title(ms)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    entries.forEachIndexed { i, e ->
                        SettingRow(
                            title = e.title, shape = cardShape(i, entries.size), compact = true,
                            icon = e.icon, summary = e.summary, onClick = e.go,
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { menuId = 0 }) { Text("Close") } },
        )
    }

    // ---- block options ----
    val eid = editId
    val es = if (eid != 0) model.get(eid) else null
    if (es != null) {
        BlockForm(activity, es, model.blocks, onSave = { s ->
            model.checkpoint(); model.update(s.copy(id = eid)); save(); viewRef[0]?.invalidate(); editId = 0
        }, onCancel = { editId = 0 })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this script?") },
            text = { Text(name) },
            confirmButton = { TextButton(onClick = { FlowStore.delete(activity, name); confirmDelete = false; close() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}

/** Tap-to-choose chips (the same chips as everywhere else in A). */
@Composable
private fun Pick(options: List<Pair<String, String>>, value: String, onPick: (String) -> Unit) {
    ChoiceRow(options, value, onPick)
}

/** One card of the block form: a short title, then what it holds. */
@Composable
internal fun FormCard(title: String?, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(rowColor()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        if (title != null) Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        content()
    }
}

/** A line of explanation under a card. */
@Composable
internal fun FormHint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp))
}

/** A row that opens a chooser: its picture, what it is, what is chosen, and a chevron. */
@Composable
private fun ChooserRow(title: String, summary: String, icon: ImageVector, onClick: () -> Unit) {
    SettingRow(title, RoundedCornerShape(16.dp), compact = true, icon = icon, summary = summary, onClick = onClick, trailing = { Chevron() })
}

/** The options of one block, in plain words: things to tap, no formulas to type. */
@Composable
private fun BlockForm(activity: ComponentActivity, s: Step, blocks: List<Step>, onSave: (Step) -> Unit, onCancel: () -> Unit) {
    var a by remember(s.id) { mutableStateOf(s.a) }
    var b by remember(s.id) { mutableStateOf(s.b) }
    var c by remember(s.id) { mutableStateOf(s.c) }
    var d by remember(s.id) { mutableStateOf(s.d) }
    var e by remember(s.id) { mutableStateOf(s.e) }
    var f by remember(s.id) { mutableStateOf(s.f) }
    // Decision: compare two values, or ask about the phone's state. Anything else (from an import) stays as a formula.
    val stateNow = s.b == "expr" && (s.a.startsWith("is(\"") || s.a.startsWith("!is(\""))
    var kind by remember(s.id) { mutableStateOf(if (s.type != Step.IF) "" else if (stateNow) "state" else if (s.b == "expr") "formula" else "cmp") }
    var stateKey by remember(s.id) { mutableStateOf(if (stateNow) s.a.substringAfter("is(\"").substringBefore("\")") else "wifi") }
    var stateOn by remember(s.id) { mutableStateOf(!s.a.startsWith("!")) }
    var op by remember(s.id) { mutableStateOf(if (s.b == "expr" || s.b.isEmpty()) "=" else s.b) }
    var choosing by remember(s.id) { mutableStateOf(false) }
    var pickApp by remember(s.id) { mutableStateOf(false) }
    var pickOnlyApp by remember(s.id) { mutableStateOf(false) }
    var pickCell by remember(s.id) { mutableStateOf(false) }
    var pickShortcut by remember(s.id) { mutableStateOf(false) }
    // The Package and Class boxes of a Send intent block, read once from the saved intent text.
    val parsedIntent = remember(s.id) { if (s.type == Step.INTENT && s.b != "raw") runCatching { AppStarter.parse(s.a) }.getOrNull() else null }
    var ipkg by remember(s.id) { mutableStateOf(parsedIntent?.component?.packageName ?: parsedIntent?.`package` ?: "") }
    var icls by remember(s.id) { mutableStateOf(parsedIntent?.component?.className ?: "") }
    var typeIt by remember(s.id) { mutableStateOf(false) }
    var pickAction by remember(s.id) { mutableStateOf(false) }
    val vars = remember(blocks) { variablesIn(blocks) }
    val scCreator = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        @Suppress("DEPRECATION")
        val picked = result.data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
            a = AppStarter.save(picked); pickShortcut = false
        }
    }

    if (choosing) {
        val names = remember { FlowStore.names(activity) }
        AlertDialog(
            onDismissRequest = { choosing = false },
            title = { Text("Choose a script") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(names) { n -> Text(n, Modifier.fillMaxWidth().clickable { a = FlowStore.link(activity, n); choosing = false }.padding(vertical = 10.dp), fontSize = 14.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { choosing = false }) { Text("Close") } },
        )
    }
    if (pickApp) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { pickApp = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(Modifier.fillMaxSize()) {
                AppList(
                    onPick = { app -> a = app.packageName; pickApp = false },
                    onBack = { pickApp = false }, everything = true,
                )
            }
        }
    }
    if (pickOnlyApp) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { pickOnlyApp = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(Modifier.fillMaxSize()) {
                AppList(
                    onPick = { app -> b = app.packageName; pickOnlyApp = false },
                    onBack = { pickOnlyApp = false }, everything = true,
                )
            }
        }
    }
    if (pickCell) {
        WhenCellPicker(onPicked = { key, label -> c = key; d = label; pickCell = false }, onDismiss = { pickCell = false })
    }
    if (pickShortcut) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { pickShortcut = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        ) {
            androidx.compose.material3.Surface(Modifier.fillMaxSize()) {
                AppShortcutsPage(
                    onCreator = { cr ->
                        runCatching {
                            scCreator.launch(android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT).setClassName(cr.packageName, cr.className))
                        }
                    },
                    onShortcut = { sc -> a = sc.intentUri; pickShortcut = false },
                    onBack = { pickShortcut = false },
                )
            }
        }
    }

    if (pickAction) {
        DeviceActionPicker(
            onDismiss = { pickAction = false },
            onPicked = { act, _ ->
                val body = act.removePrefix(NativePicker.PREFIX)
                a = body.substringBefore('|'); b = body.substringAfter('|', "")
            },
        )
    }

    fun appLabel(pkg: String): String = runCatching {
        activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(BlockStyle.title(s)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (s.type) {
                    Step.SHELL -> {
                        FormCard(null) { Field("Command", a) { a = it } }
                        FormCard("Save the output in") { VarPick(b, vars, emptyMeans = "out") { b = it } }
                    }
                    Step.SHIZUKU -> {
                        FormCard(null) { Field("Command (runs with Shizuku)", a) { a = it } }
                        FormCard("Save the output in") { VarPick(b, vars, emptyMeans = "out") { b = it } }
                        FormCard("Without Shizuku") { Pick(listOf("Fail without Shizuku" to "", "Skip quietly without Shizuku" to "optional"), c) { c = it } }
                    }
                    Step.WAIT -> {
                        if (c == "expr") FormCard(null) { Field("Milliseconds (formula from an import)", a) { a = it } }
                        else {
                            FormCard("Wait for") {
                                ChoiceRow(
                                    listOf("10 ms" to "10", "100 ms" to "100", "0.5 s" to "500", "1 s" to "1000", "2 s" to "2000", "3 s" to "3000", "5 s" to "5000", "10 s" to "10000", "1 min" to "60000"),
                                    a,
                                ) { a = it }
                            }
                            FormCard(null) { MsBox("Wait", a.toIntOrNull() ?: 0, 86400000, 60000) { a = it.toString() } }
                        }
                    }
                    Step.MESSAGE -> {
                        FormCard(null) { Field("Text", a) { a = it } }
                        if (vars.isNotEmpty()) FormCard("Put a variable in the text") {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                vars.take(8).forEach { v -> OutlinedButton(onClick = { a += "{$v}" }) { Text(v, fontSize = 12.sp) } }
                            }
                        }
                        FormCard("Show it as") { Pick(listOf("Bar" to "", "Toast" to "toast", "Window" to "window"), c) { c = it } }
                    }
                    Step.LAUNCH -> {
                        AppAndClassCard(activity, a, c) { p, k, fresh -> a = p; c = if (fresh) "" else k }
                        FormCard("After opening it") {
                            Pick(listOf("Stay open" to "", "Go back after a time" to "back"), if (b.isEmpty()) "" else "back") { b = if (it == "back") "1500" else "" }
                            if (b.isNotEmpty()) {
                                MsBox("Go back after", b.toIntOrNull() ?: 1500, 3600000, 30000) { b = it.toString() }
                                FormHint("It opens without an animation, waits, then you are taken back to where you were. With Shizuku it is quicker. A tiny time (5 ms) opens it behind your back.")
                            }
                        }
                    }
                    Step.INTENT -> if (b == "raw") {
                        FormCard("Raw shortcut") {
                            FormHint("Paste a raw shortcut (the text a cell keeps for its action). It runs when the block runs.")
                            Field("Raw shortcut", a) { a = it }
                            OutlinedButton(onClick = {
                                val cm = activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cm.primaryClip?.getItemAt(0)?.coerceToText(activity)?.toString()?.let { a = it }
                            }) { Text("Paste from the clipboard") }
                        }
                    } else {
                        AppAndClassCard(activity, ipkg, icls) { p, k, fresh ->
                            ipkg = p; icls = k
                            if (p.isNotBlank()) {
                                val base = if (fresh) null else runCatching { AppStarter.parse(a) }.getOrNull()
                                val i = base ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                                if (k.isBlank()) {
                                    val home = activity.packageManager.getLaunchIntentForPackage(p.trim())?.component
                                    i.setComponent(home)
                                    if (home == null) i.setPackage(p.trim())
                                } else i.setComponent(ComponentName(p.trim(), fullClass(p.trim(), k.trim())))
                                a = AppStarter.save(i)
                            }
                        }
                        ChooserRow("App shortcut", if (a.isEmpty()) "Choose an app shortcut…" else "Shortcut chosen - change…", Icons.Filled.Star) { pickShortcut = true }
                        ChooserRow("Advanced", "Edit the intent text", Icons.Filled.Edit) { typeIt = !typeIt }
                        if (typeIt || (a.isNotEmpty() && !a.startsWith("intent:") && !a.startsWith("#Intent"))) FormCard(null) { Field("Intent", a) { a = it } }
                    }
                    Step.SET -> {
                        FormCard("Variable") { VarPick(a, vars) { a = it } }
                        if (c == "expr") FormCard(null) { Field("Value (formula from an import)", b) { b = it } }
                        else FormCard("Value") { ValuePick(b, blocks) { b = it } }
                    }
                    Step.IF -> {
                        FormCard("What to check") {
                            Pick(listOf("Compare two values" to "cmp", "Phone state" to "state") + (if (kind == "formula") listOf("Imported formula" to "formula") else emptyList()), kind) { kind = it }
                        }
                        when (kind) {
                            "cmp" -> {
                                FormCard("Value") { ValuePick(a, blocks) { a = it } }
                                FormCard("Is") { Pick(OPS, op) { op = it } }
                                FormCard("Compared with") { ValuePick(c, blocks) { c = it } }
                            }
                            "state" -> {
                                FormCard("Phone state") {
                                    Pick(STATES, stateKey) { stateKey = it }
                                    Pick(
                                        if (stateKey == "widgetbutton") listOf("was found" to "on", "was not found" to "off") else listOf("is on" to "on", "is off" to "off"),
                                        if (stateOn) "on" else "off",
                                    ) { stateOn = it == "on" }
                                    if (stateKey == "widgetbutton") FormHint("Waits up to a minute for the last widget press to finish, then answers.")
                                }
                            }
                            else -> FormCard(null) { Field("Condition (from an import)", a) { a = it } }
                        }
                        FormHint("Bottom dot = yes, side dot = no.")
                    }
                    Step.WHEN -> {
                        val mode = b.ifEmpty { WhenEvents.MODE_START }
                        FormCard("When this happens") {
                            ChoiceRow(WhenRules.EVENTS.map { it.second to it.first }, a) { a = it }
                        }
                        if (a == WhenRules.CELL_RUNS) {
                            ChooserRow("Cell", if (d.isEmpty()) "Choose the cell\u2026" else d, Icons.Filled.Apps) { pickCell = true }
                        }
                        FormCard("What this block does") {
                            Pick(WhenEvents.MODES, mode) { b = it }
                            FormHint(
                                when (mode) {
                                    WhenEvents.MODE_WAIT -> "Wait: when the script reaches this block it stops here until this happens, then goes on."
                                    WhenEvents.MODE_BOTH -> "Both: the script runs by itself from this block when this happens, and a script that reaches this block waits here for it."
                                    else -> "Start: the script runs by itself from this block every time this happens. Pressing Run does not wait for it."
                                },
                            )
                        }
                        if (mode != WhenEvents.MODE_START) FormCard("How long to wait") {
                            Pick(listOf("Until it happens" to "", "Up to a time" to "time"), if (e.isEmpty()) "" else "time") { e = if (it == "time") "60000" else "" }
                            if (e.isNotEmpty()) {
                                MsBox("Give up after", e.toIntOrNull() ?: 60000, 86400000, 60000) { e = it.coerceAtLeast(1).toString() }
                                FormHint("If it does not happen in time the script goes on and when_found is no.")
                            }
                        }
                        if (mode != WhenEvents.MODE_WAIT) {
                            FormCard("If the script is still running from the last time") {
                                Pick(listOf("Skip this time" to "", "Run it again too" to "again"), if (WhenEvents.hasFlag(f, WhenEvents.FLAG_AGAIN)) "again" else "") {
                                    f = WhenEvents.setFlag(f, WhenEvents.FLAG_AGAIN, it == "again")
                                }
                            }
                            if (a == WhenRules.SLIDE_IN) {
                                FormCard("The cells window") {
                                    Pick(listOf("Opens as usual" to "", "Does not open" to "noopen"), if (WhenEvents.hasFlag(f, WhenEvents.FLAG_NOOPEN)) "noopen" else "") {
                                        f = WhenEvents.setFlag(f, WhenEvents.FLAG_NOOPEN, it == "noopen")
                                    }
                                }
                                FormCard("When I lift my thumb") {
                                    Pick(listOf("Stay open" to "", "Close what it opened" to "lift"), if (WhenEvents.hasFlag(f, WhenEvents.FLAG_LIFT)) "lift" else "") {
                                        f = WhenEvents.setFlag(f, WhenEvents.FLAG_LIFT, it == "lift")
                                    }
                                    FormHint("Closing works for floating windows the script opens (a widget, notes, gallery). A screen of another app cannot be closed this way.")
                                }
                            }
                        }
                        FormHint("Same events as the When list on the Actions screen. Add an Only if block under this one to check the app in front, rotation, keyboard or headphones.")
                    }
                    Step.ONLYIF -> {
                        FormCard("Go on only if") {
                            ChoiceRow(WhenRules.ONLY.filter { it.first != WhenRules.ONLY_NONE }.map { it.second to it.first }, a) { a = it }
                        }
                        if (a == WhenRules.ONLY_APP) {
                            ChooserRow("App", if (b.isEmpty()) "Choose the app\u2026" else appLabel(b), Icons.Filled.Apps) { pickOnlyApp = true }
                            FormHint("Needs Usage access (or the accessibility service reporting the app) to know which app is in front.")
                        }
                        FormHint("Bottom dot = yes, side dot = no. It answers the same way as the Only if of a row in the When list.")
                    }
                    Step.REPEAT -> {
                        if (b == "each") {
                            FormCard(null) { Field("List (from an import)", a) { a = it } }
                            FormCard("Variable for each item") { VarPick(c, vars, emptyMeans = "item") { c = it } }
                        } else {
                            FormCard("How many times") {
                                NumberPick(a, listOf("2" to "2", "3" to "3", "5" to "5", "10" to "10", "20" to "20", "50" to "50"), step = 1, min = 1) { a = it }
                            }
                        }
                        FormHint("Side dot = what to repeat, bottom dot = when finished.")
                    }
                    Step.HTTP -> {
                        FormCard(null) { Field("Web address", a) { a = it } }
                        FormCard("Method") { Pick(listOf("GET" to "GET", "POST" to "POST"), b.ifEmpty { "GET" }) { b = it } }
                        FormCard("Save the answer in") { VarPick(c, vars, emptyMeans = "answer") { c = it } }
                    }
                    Step.RUN -> {
                        ChooserRow("Script", if (a.isEmpty()) "Choose a script…" else FlowStore.display(a), Icons.Filled.PlayArrow) { choosing = true }
                        FormCard("How to run it") { Pick(listOf("Wait for it" to "", "At the same time" to "async", "Hand over (no return)" to "goto"), b) { b = it } }
                    }
                    Step.NOTE -> FormCard(null) { Field("Note", a) { a = it } }
                    Step.ACTION -> {
                        ChooserRow(
                            "Action", NativeActions.find(a)?.label ?: "Choose an action…", Icons.Filled.Tune,
                        ) { pickAction = true }
                        NativeActions.find(a)?.help?.takeIf { it.isNotEmpty() }?.let { FormHint(it) }
                        if (ActionArgs.specFor(a, activity) != null) FormCard("Options") { ActionArgPick(a, b) { b = it } }
                        else if (NativeActions.find(a)?.let { it.label.contains("argument", true) || it.help.contains("Argument", true) } == true)
                            FormCard(null) { Field("Argument", b) { b = it } }
                        FormCard("Without Shizuku") { Pick(listOf("Fail without Shizuku" to "", "Skip quietly without Shizuku" to "optional"), c) { c = it } }
                    }
                    Step.BROADCAST -> FormCard(null) {
                        Field("Package or package/.Receiver", a) { a = it }
                        Field("Action", b) { b = it }
                        Field("Extras: key=value;key=value", c) { c = it }
                    }
                    Step.OCRWAIT -> {
                        val boxes = ScreenOcr.boxNames(activity).map { n -> "Box: $n" to "box:$n" }
                        FormCard("What to read") {
                            Pick(boxes + listOf("Selected widget (digits)" to "widget", "Widget on screen now (digits)" to "widgetnow"), a) { a = it }
                            if (boxes.isEmpty()) FormHint("No boxes yet: make one in the OCR screen (section 4).")
                        }
                        FormCard("Wait until it sees") {
                            Pick(
                                listOf("Digits" to "digits", "Any written text" to "text", "Digits or text" to "both", "A word" to "word"),
                                b.substringBefore(':'),
                            ) { b = if (it == "word") "word:" + b.substringAfter(':', "") else it }
                            if (b.startsWith("word")) Field("The word", b.substringAfter(':', "")) { b = "word:" + it }
                        }
                        FormCard(null) { MsBox("Look for up to", c.toIntOrNull() ?: 40000, 3600000, 120000) { c = it.toString() } }
                        FormCard("Save what it read in") { VarPick(d, vars, emptyMeans = "ocr") { d = it } }
                        FormCard("Only accept this many digits") {
                            Pick(listOf("Any" to "", "4" to "4", "5" to "5", "6" to "6", "7" to "7", "8" to "8"), e.trim()) { e = it }
                            Field("Ignore these readings (separate with commas)", f) { f = it }
                            FormHint("A reading with another number of digits, or one on the ignore list (for example an error word the OCR reads as 00040), is skipped and it keeps looking until the time is up.")
                        }
                        FormHint("Also sets ocr_found to yes or no. Digits are taken from written text first, then from the picture of the box. Text and words need written text the screen shows (needs Shizuku). Nothing found in time is not an error: ask ocr_found in a Decision.")
                    }
                    Step.COUNTDOWN -> {
                        FormCard(null) {
                            MsBox("Count down", a.toLongOrNull()?.toInt() ?: 120000, 86400000, 300000) { a = it.toString() }
                            Field("Text shown with it", b) { b = it }
                        }
                        FormCard("Show it as") {
                            Pick(listOf("Bar on screen" to "bar", "Notification" to "notice", "Both" to "both", "Nothing" to "none"), c.ifEmpty { "bar" }) { c = it }
                        }
                        if (c.ifEmpty { "bar" } == "bar" || c == "both") FormCard("Bar opacity") {
                            Pick(listOf("100%" to "100", "80%" to "80", "60%" to "60", "40%" to "40", "20%" to "20"), d.ifEmpty { "80" }) { d = it }
                            FormHint("The bar can be dragged anywhere. Tap the dash on it to shrink it to the time only.")
                        }
                        FormCard(null) { Field("Name (countdowns with the same name are one countdown)", e) { e = it } }
                        FormCard("If it is already counting (the script was run again)") {
                            Pick(listOf("Continue it" to "join", "Stop this run" to "stop", "Start it again" to "restart"), f.ifEmpty { "join" }) { f = it }
                        }
                    }
                    Step.FIELDWAIT -> {
                        FormCard(null) { MsBox("Wait up to", a.toIntOrNull() ?: 30000, 3600000, 120000) { a = it.toString() } }
                        FormHint("Waits until a text field with the cursor is on the screen, then sets field_found to yes (or no when time ran out). Needs Shizuku.")
                    }
                    Step.RATELIMIT -> {
                        FormCard(null) {
                            Field("Name of this limit (scripts with the same name share it)", a) { a = it }
                            MsBox("At least this long between runs", b.toLongOrNull()?.toInt() ?: 120000, 86400000, 300000) { b = it.toString() }
                        }
                        FormCard("If it runs too soon") {
                            Pick(listOf("Show a countdown, then stop" to "countdown", "Wait with a countdown, then go on" to "wait", "Stop quietly" to "stop"), c.ifEmpty { "countdown" }) { c = it }
                        }
                        FormCard(null) { Field("Text shown with the countdown", d) { d = it } }
                        FormCard("Show the countdown as") {
                            Pick(listOf("Bar on screen" to "bar", "Notification" to "notice", "Both" to "both", "Nothing" to "none"), e.ifEmpty { "bar" }) { e = it }
                        }
                        if (e.ifEmpty { "bar" } == "bar" || e == "both") FormCard("Bar opacity") {
                            Pick(listOf("100%" to "100", "80%" to "80", "60%" to "60", "40%" to "40", "20%" to "20"), f.ifEmpty { "80" }) { f = it }
                        }
                        FormHint("Put it before the step that must not be repeated (for example asking the bank for a code).")
                    }
                    Step.STOP -> FormHint("Stops the whole flow here.")
                    else -> FormHint(s.describe())
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val out = if (s.type == Step.IF) when (kind) {
                    "cmp" -> s.copy(a = a, b = op, c = c)
                    "state" -> s.copy(a = (if (stateOn) "" else "!") + "is(\"" + stateKey + "\")", b = "expr", c = "")
                    else -> s.copy(a = a, b = "expr", c = "")
                } else if (s.type == Step.WHEN) {
                    val cell = a == WhenRules.CELL_RUNS
                    val m = b.ifEmpty { WhenEvents.MODE_START }
                    s.copy(a = a, b = m, c = if (cell) c else "", d = if (cell) d else "", e = if (m == WhenEvents.MODE_START) "" else e, f = f)
                } else if (s.type == Step.ONLYIF) {
                    s.copy(a = a, b = if (a == WhenRules.ONLY_APP) b else "")
                } else s.copy(a = a, b = b, c = c, d = d, e = e, f = f)
                onSave(out)
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}
