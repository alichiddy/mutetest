package a.a.ui.screens.ziptool

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File

/**
 * The Terminal: Claude gives Ali a block of text, he pastes it here, and the full source zip is patched and saved
 * in Downloads, read back and checked. The text is checked first (checksums, every path, every edit found exactly
 * once) and the Check box says what will happen. The source zip is never changed; a new zip is always written.
 *
 * The source is either the zip picked each time, or the last result kept in the app (the switch is remembered),
 * so after one pick every paste patches the zip the previous paste made.
 */
class TerminalState(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("zip_terminal", Context.MODE_PRIVATE)
    private val keptFile = File(ctx.filesDir, KEPT)
    private val pickFile = File(ctx.cacheDir, PICK_TMP)

    var keepLast by mutableStateOf(prefs.getBoolean(KEY_KEEP, true))
    var keptSrc by mutableStateOf<ZipSource?>(null)
    var pickedSrc by mutableStateOf<ZipSource?>(null)
    var scriptInfo by mutableStateOf("")
    var check by mutableStateOf("")
    var canRun by mutableStateOf(false)
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var log by mutableStateOf("")

    /** What the last successful run changed: the Changed Files Info text is made from it. */
    var lastRun by mutableStateOf<ChangedInfo.Run?>(null)
    var infoText by mutableStateOf("")
    var infoLog by mutableStateOf("")
    private var pendingChanges: List<TerminalChange> = emptyList()

    private var parsed: TerminalScript.Parsed? = null
    private var plan: ZipPlan? = null
    private var nameAuto = true

    @Volatile
    private var gen = 0

    /** The zip the next paste will patch. */
    val src: ZipSource? get() = if (keepLast) keptSrc else pickedSrc

    fun cleanup() {
        pickFile.delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    /** Takes the kept zip from the last run back into the window. */
    fun restore() {
        if (keptSrc != null || !keptFile.exists()) return
        Thread {
            try {
                val names = ZipIo.listFiles(keptFile)
                if (keptSrc == null && names.isNotEmpty()) {
                    val name = prefs.getString(KEY_NAME, null) ?: "last result"
                    keptSrc = ZipSource(keptFile, name, names, ZipIo.rootOf(names), false)
                    recheck()
                }
            } catch (e: Throwable) {
                keptFile.delete()
            }
        }.start()
    }

    fun chooseKeep(on: Boolean) {
        if (busy) return
        keepLast = on
        prefs.edit().putBoolean(KEY_KEEP, on).apply()
        refreshName()
        recheck()
    }

    fun renamed(s: String) {
        outName = s
        nameAuto = false
    }

    private fun refreshName() {
        if (!nameAuto) return
        val fromScript = parsed?.name
        val s = src
        outName = when {
            !fromScript.isNullOrBlank() -> fromScript
            s != null -> ZipIo.stem(s.name).removeSuffix("_patched") + "_patched.zip"
            else -> ""
        }
    }

    // ---------------------------------------------------------------- source

    fun pickSource(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the zip..."
        val kept = keepLast
        Thread {
            try {
                val s = ZipSources.fromZip(ctx, u, if (kept) keptFile else pickFile)
                if (kept) {
                    prefs.edit().putString(KEY_NAME, s.name).apply()
                    keptSrc = s
                } else {
                    pickedSrc = s
                }
                refreshName()
                recheck()
            } catch (e: Throwable) {
                log = "TERMINAL ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    // ---------------------------------------------------------------- the pasted text

    fun pasteClipboard() {
        if (busy) return
        val text = try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(ctx).toString() else ""
        } catch (e: Throwable) {
            ""
        }
        if (text.isBlank()) {
            log = "TERMINAL: nothing to paste. Copy the terminal text first, then tap Paste again, or long-press the box and paste."
            return
        }
        setScript(text)
    }

    /** Reads the pasted text and checks it against the source. The text itself is not kept, only what it says. */
    fun setScript(text: String) {
        if (busy) return
        log = ""
        val p = TerminalScript.parse(text)
        parsed = p
        scriptInfo = "${p.ops.size} change(s), ${ZipIo.size(text.length.toLong())}"
        refreshName()
        recheck()
    }

    fun clearScript() {
        gen++
        parsed = null
        plan = null
        scriptInfo = ""
        check = ""
        canRun = false
    }

    /** Works out what the text would do to the source, on a worker thread. A newer check cancels an older one. */
    private fun recheck() {
        val p = parsed
        val s = src
        gen++
        val mine = gen
        plan = null
        canRun = false
        if (p == null) {
            check = ""
            return
        }
        if (s == null) {
            check = (p.problems.map { "PROBLEM: $it" } + "Choose the source zip first.").joinToString("\n")
            return
        }
        check = "Checking..."
        Thread {
            var made: List<TerminalChange> = emptyList()
            val result = try {
                val act = TerminalAction(p)
                val r = act.plan(s)
                made = act.changes
                r
            } catch (e: Throwable) {
                ZipPlan(emptyMap(), emptySet(), emptyList(), "", listOf("Could not check: ${e.message ?: e.javaClass.simpleName}"), emptyList())
            }
            if (mine == gen) {
                plan = result
                pendingChanges = made
                check = result.checkText()
                canRun = result.canBuild
            }
        }.start()
    }

    // ---------------------------------------------------------------- running

    fun execute() {
        if (busy) return
        val s = src ?: return
        val p = plan ?: return
        if (!p.canBuild) return
        busy = true
        log = ""
        status = "Working..."
        val saveName = ZipIo.cleanName(outName, "patched")
        val kept = keepLast
        val ran = pendingChanges
        val ranNotes = parsed?.notes ?: emptyList()
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                val built = ZipBuilder.build(
                    ctx, s, p, saveName, tmp,
                    afterSave = { f, name -> if (kept) keep(f, name) },
                    status = { status = it },
                )
                log = built.text
                if (built.saved) {
                    val run = ChangedInfo.Run(saveName, ChangedInfo.now(), ranNotes, ran)
                    lastRun = run
                    infoText = ChangedInfo.section(run)
                    infoLog = ""
                    clearScript()
                    if (!kept) {
                        s.discard()
                        pickedSrc = null
                    }
                    nameAuto = true
                    refreshName()
                }
            } catch (e: Throwable) {
                log = "TERMINAL ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    fun copy(text: String) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Terminal", text))
            android.widget.Toast.makeText(ctx, "Copied", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            infoLog = "Could not copy: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    /** Writes the last run as a new Changed Files Info txt in Downloads (a number is added when the name is taken). */
    fun saveInfo() {
        val run = lastRun
        if (run == null) {
            infoLog = "Run the terminal first: there are no changes to write yet."
            return
        }
        Thread {
            try {
                val text = ChangedInfo.fresh(run)
                val name = ChangedInfo.saveNew(ctx, text)
                infoText = text
                infoLog = "Saved: Downloads/$name"
            } catch (e: Throwable) {
                infoLog = "Could not save: ${e.message ?: e.javaClass.simpleName}"
            }
        }.start()
    }

    /** Adds the last run to the most recently changed Changed Files Info txt in Downloads and shows the result. */
    fun mergeInfo() {
        val run = lastRun
        if (run == null) {
            infoLog = "Run the terminal first: there are no changes to merge yet."
            return
        }
        Thread {
            try {
                val f = ChangedInfo.latest(ctx)
                if (f == null) {
                    infoLog = "No Changed Files Info txt in Downloads yet. Tap Save Changed Files Info first."
                    return@Thread
                }
                val old = ChangedInfo.read(ctx, f)
                if (ChangedInfo.has(old, run)) {
                    infoText = old
                    infoLog = "Already merged into Downloads/${f.name}."
                    return@Thread
                }
                val merged = ChangedInfo.merge(old, run)
                infoLog = if (ChangedInfo.overwrite(ctx, f, merged)) {
                    "Merged into Downloads/${f.name} (the most recently changed Changed Files Info txt)."
                } else {
                    "Android would not let A change Downloads/${f.name}, so the merged text was saved as Downloads/${ChangedInfo.saveNew(ctx, merged)}."
                }
                infoText = merged
            } catch (e: Throwable) {
                infoLog = "Could not merge: ${e.message ?: e.javaClass.simpleName}"
            }
        }.start()
    }

    /** The new zip becomes the source for the next paste: copied beside the old one, then put in its place. */
    private fun keep(f: File, name: String) {
        val part = File(keptFile.parentFile, keptFile.name + ".part")
        try {
            f.inputStream().use { i -> part.outputStream().use { o -> i.copyTo(o) } }
            val names = ZipIo.listFiles(part)
            if (!part.renameTo(keptFile)) {
                keptFile.delete()
                if (!part.renameTo(keptFile)) throw IllegalStateException("Could not keep the file in the app.")
            }
            prefs.edit().putString(KEY_NAME, name).apply()
            keptSrc = ZipSource(keptFile, name, names, ZipIo.rootOf(names), false)
        } finally {
            part.delete()
        }
    }

    private companion object {
        const val KEPT = "zt_terminal_source.zip"
        const val PICK_TMP = "zt_terminal_pick.zip"
        const val OUT_TMP = "zt_terminal_out.zip"
        const val KEY_KEEP = "keepLast"
        const val KEY_NAME = "keptName"
    }
}

@Composable
fun TerminalTab(s: TerminalState) {
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.pickSource(u)
    }
    LaunchedEffect(Unit) { s.restore() }
    val src = s.src
    HeroCard(
        title = "Terminal",
        text = "Paste the text Claude gives you. Your full source zip is patched and the new full zip is saved in Downloads, checked.",
        leading = { IconTile(Icons.Filled.Settings, lit = true) },
    )
    Column {
        GroupHeading("Source")
        RowGroup {
            KitRow(
                title = "Source zip",
                shape = cardShape(0, 2),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = src?.name ?: "Tap to choose",
                description = if (src != null) "${src.entries.size} files inside" else null,
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "Keep the new zip as the next source",
                shape = cardShape(1, 2),
                description = if (s.keepLast) "After each run the new full zip is the source for the next paste" else "You choose the source zip every time",
                onClick = { if (!s.busy) s.chooseKeep(!s.keepLast) },
                trailing = { Switch(checked = s.keepLast, onCheckedChange = { if (!s.busy) s.chooseKeep(it) }) },
            )
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GroupHeading("Terminal")
        OutlinedTextField(
            value = "",
            onValueChange = { if (it.length > 20 && !s.busy) s.setScript(it) },
            label = {
                Text(if (s.scriptInfo.isEmpty()) "Paste the terminal text here" else "Pasted: ${s.scriptInfo}. Paste again to replace it")
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { s.pasteClipboard() }, enabled = !s.busy) { Text("Paste from clipboard") }
            TextButton(onClick = { s.clearScript() }, enabled = !s.busy && s.scriptInfo.isNotEmpty()) { Text("Clear") }
        }
    }
    if (s.check.isNotEmpty()) {
        Column {
            GroupHeading("Check")
            TextBox(s.check)
        }
    }
    SaveAsField(s.outName) { s.renamed(it) }
    Button(
        onClick = { s.execute() },
        enabled = s.canRun && !s.busy && s.outName.isNotBlank(),
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) (s.status.ifEmpty { "Working..." }) else "Run the terminal") }
    ResultBox(s.log)
    if (s.log.isNotEmpty()) {
        TextButton(onClick = { s.copy(s.log) }) { Text("Copy result") }
    }
    if (s.lastRun != null) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GroupHeading("Changed files info")
            Button(onClick = { s.saveInfo() }, modifier = Modifier.fillMaxWidth()) { Text("Save Changed Files Info") }
            Button(onClick = { s.mergeInfo() }, modifier = Modifier.fillMaxWidth()) { Text("Merge/Append TXT") }
            if (s.infoLog.isNotEmpty()) Text(s.infoLog)
            if (s.infoText.isNotEmpty()) {
                TextBox(s.infoText)
                TextButton(onClick = { s.copy(s.infoText) }) { Text("Copy") }
            }
        }
    }
}
