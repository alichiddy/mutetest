package a.a.ui.screens.ziptool

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One file a terminal text changes. [kind] is ADDED, REPLACED, EDITED or REMOVED; [notes] say where an edit is. */
class TerminalChange(val kind: String, val path: String, val detail: String, val notes: List<String> = emptyList())

/**
 * The "Changed Files Info" text: which files each run of the Terminal added, replaced, edited or removed, so another
 * AI that still has an older source knows what to merge. One section per run (newest last), then a FILES TOUCHED
 * list built from the sections. [saveNew] writes Downloads/Changed Files Info.txt, or "Changed Files Info 01.txt",
 * "02" and so on when the name is taken; [merge] adds a run to the most recently changed one.
 */
object ChangedInfo {
    const val BASE = "Changed Files Info"
    private const val HEAD = "CHANGED FILES INFO (newest build last)"
    private const val TOUCHED = "FILES TOUCHED"
    private val KIND = Regex("^(ADDED|REPLACED|EDITED|REMOVED)\\s+(\\S+)")
    private val LABEL = Regex("^== (.+?) \\(")

    class Run(val build: String, val time: String, val notes: List<String>, val changes: List<TerminalChange>)

    class Found(val name: String, val uri: Uri?, val file: File?, val modified: Long)

    fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    /** One run's part of the text. */
    fun section(run: Run): String {
        val sb = StringBuilder()
        sb.append("== ").append(run.build).append(" (").append(run.time).append(") ==\n")
        for (n in run.notes) sb.append("NOTE: ").append(n).append('\n')
        for (k in listOf("ADDED", "REPLACED", "EDITED", "REMOVED")) {
            for (c in run.changes) {
                if (c.kind != k) continue
                sb.append(k.padEnd(8)).append(' ').append(c.path)
                if (c.detail.isNotEmpty()) sb.append("  (").append(c.detail).append(')')
                sb.append('\n')
                for (n in c.notes) sb.append("    - ").append(n).append('\n')
            }
        }
        return sb.toString()
    }

    /** The FILES TOUCHED list for every section in [body]. */
    private fun touched(body: String): String {
        val map = LinkedHashMap<String, ArrayList<String>>()
        var label = "?"
        for (line in body.lines()) {
            val l = LABEL.find(line)
            if (l != null) {
                label = l.groupValues[1]
                continue
            }
            val k = KIND.find(line) ?: continue
            map.getOrPut(k.groupValues[2]) { ArrayList() }.add(label + " " + k.groupValues[1].lowercase(Locale.US))
        }
        val sb = StringBuilder(TOUCHED).append('\n')
        for ((p, v) in map) sb.append(p).append(" : ").append(v.joinToString(", ")).append('\n')
        return sb.toString()
    }

    fun has(existing: String, run: Run): Boolean = existing.contains("== " + run.build + " (" + run.time + ") ==")

    /** [existing] with [run] added as the newest section and the FILES TOUCHED list rebuilt. Text after that list is kept. */
    fun merge(existing: String, run: Run): String {
        val lines = existing.replace("\r\n", "\n").lines()
        val t = lines.indexOfFirst { it.trim() == TOUCHED }
        val headEnd = if (t >= 0) t else lines.size
        var tailStart = lines.size
        if (t >= 0) {
            var j = t + 1
            while (j < lines.size && lines[j].isNotBlank()) j++
            tailStart = j
        }
        val head = lines.subList(0, headEnd).joinToString("\n").trimEnd()
        val tail = lines.subList(tailStart, lines.size).joinToString("\n").trim()
        val body = (if (head.isBlank()) HEAD else head) + "\n\n" + section(run).trimEnd() + "\n"
        val sb = StringBuilder(body).append('\n').append(touched(body))
        if (tail.isNotEmpty()) sb.append('\n').append(tail).append('\n')
        return sb.toString()
    }

    fun fresh(run: Run): String = merge("", run)

    // ---------------------------------------------------------------- Downloads

    /** Every "Changed Files Info*.txt" in Downloads that this app can see. */
    @Suppress("DEPRECATION")
    fun find(ctx: Context): List<Found> {
        val out = ArrayList<Found>()
        if (Build.VERSION.SDK_INT >= 29) {
            val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_MODIFIED)
            val sel = MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?"
            val args = arrayOf("$BASE%.txt", Environment.DIRECTORY_DOWNLOADS + "%")
            ctx.contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj, sel, args, null)?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
                    out.add(Found(name, uri, null, c.getLong(2) * 1000L))
                }
            }
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.listFiles()?.forEach { f ->
                if (f.isFile && f.name.startsWith(BASE) && f.name.endsWith(".txt")) out.add(Found(f.name, null, f, f.lastModified()))
            }
        }
        return out
    }

    /** The most recently changed one, or null. */
    fun latest(ctx: Context): Found? = find(ctx).maxByOrNull { it.modified }

    /** "Changed Files Info.txt", then "Changed Files Info 01.txt", "02", ... the first name not in [taken]. */
    fun nextName(taken: Set<String>): String {
        if ("$BASE.txt" !in taken) return "$BASE.txt"
        var n = 1
        while (true) {
            val s = String.format(Locale.US, "%s %02d.txt", BASE, n)
            if (s !in taken) return s
            n++
        }
    }

    /** Writes [text] as a new file in Downloads under the next free name and returns that name. */
    fun saveNew(ctx: Context, text: String): String {
        val name = nextName(find(ctx).map { it.name }.toSet())
        return create(ctx, name, text)
    }

    @Suppress("DEPRECATION")
    private fun create(ctx: Context, name: String, text: String): String {
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (Build.VERSION.SDK_INT >= 29) {
            val cr = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads.")
            val os = cr.openOutputStream(uri) ?: throw IllegalStateException("Could not write the file in Downloads.")
            os.use { it.write(bytes) }
            var shown = name
            runCatching {
                cr.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { shown = it }
                }
            }
            return shown
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        File(dir, name).writeBytes(bytes)
        return name
    }

    fun read(ctx: Context, f: Found): String {
        val uri = f.uri
        val bytes = if (uri != null) ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } else f.file?.readBytes()
        return bytes?.toString(Charsets.UTF_8) ?: throw IllegalStateException("Could not read ${f.name}.")
    }

    /** Writes [text] over [f]. False when Android does not let this app change that file. */
    fun overwrite(ctx: Context, f: Found, text: String): Boolean {
        val bytes = text.toByteArray(Charsets.UTF_8)
        return try {
            val uri = f.uri
            if (uri != null) {
                val os = ctx.contentResolver.openOutputStream(uri, "wt")
                if (os == null) {
                    false
                } else {
                    os.use { it.write(bytes) }
                    true
                }
            } else {
                f.file?.writeBytes(bytes)
                f.file != null
            }
        } catch (e: Throwable) {
            false
        }
    }
}
