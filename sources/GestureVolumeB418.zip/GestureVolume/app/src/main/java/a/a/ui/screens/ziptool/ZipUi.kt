package a.a.ui.screens.ziptool

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.GroupHeading
import a.a.ui.components.rowColor

/** Monospace text on a card: results, checks and lists of files. */
@Composable
fun TextBox(text: String) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(rowColor()).padding(14.dp),
    ) {
        androidx.compose.foundation.text.selection.SelectionContainer {
            Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
    }
}

/** The "Save as" heading with the name box under it. */
@Composable
fun SaveAsField(value: String, onChange: (String) -> Unit) {
    Column {
        GroupHeading("Save as")
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            label = { Text("File name (saved in Downloads)") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** The "Result" heading with the result text under it, when there is any. */
@Composable
fun ResultBox(log: String) {
    if (log.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        GroupHeading("Result")
        TextBox(log)
    }
}
