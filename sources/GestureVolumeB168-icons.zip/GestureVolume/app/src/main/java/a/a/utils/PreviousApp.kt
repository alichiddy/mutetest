package a.a.utils

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

/**
 * "Previous app": goes back to the app used before the one in front, the way Recents does it, and
 * lands exactly where that app was left (inside its submenu, not on its main screen).
 *
 * How the app is brought back: Android keeps each app's screens in a *task*. Starting the app
 * again from scratch (what the first version did: `am start -n <activity>`) opens its main screen
 * on top of that task. Instead the task is resumed, in this order:
 *  1. The task's own start intent is replayed exactly as a launcher icon would (MAIN + LAUNCHER +
 *     the task's flags). Android sees it is the root of an existing task and just brings that task
 *     to the front as it was.
 *  2. If it did not come to the front, the task is moved to the front by its id
 *     (ActivityManager.moveTaskToFront, the REORDER_TASKS permission).
 *  3. Last, `am task lock` / `lock stop`, which brings a task to the front by its id from the shell.
 *
 * Which app: only what the real Recents list would show. Tasks Android hides from Recents, file or
 * content pickers (GET_CONTENT, OPEN_DOCUMENT ...), system dialogs, the launcher and A itself are
 * skipped, so an app that only flashed up as a picker (a file manager, say) is never "previous".
 *
 * Two sources, no background work of its own:
 *  1. Android's recents list, read on demand through Shizuku (`dumpsys activity recents`).
 *  2. A tiny list of the last few apps fed by the accessibility service's window changes, only
 *     while the "track apps" switch is on. An app counts only after it stayed in front for a moment,
 *     so windows that flash past (pickers, trampolines) are dropped.
 */
object PreviousApp {
    const val PREF_EXCLUDE = "prevAppExclude"
    const val PREF_TRACK = "prevAppTrack"
    /** Show the "nothing found" message as Android's own toast instead of on the bar. */
    const val PREF_TOAST = "prevAppToast"

    /** One task of the recents list. Only [pkg], [component] and [visible] are always filled. */
    data class Task(
        val pkg: String, val component: String?, val visible: Boolean,
        val id: Int = -1, val user: Int = 0, val type: String = "",
        val action: String = "", val categories: List<String> = emptyList(), val flags: Long = 0L, val data: String = "",
        val hiddenFromRecents: Boolean = false,
    )

    private const val DWELL_MS = 700L
    private const val FLAG_NEW_TASK = 0x10000000L
    private const val FLAG_EXCLUDE_FROM_RECENTS = 0x00800000L
    // Flags that would make a replay start something new instead of resuming the task.
    private const val FLAGS_THAT_RESTART = 0x04000000L or 0x00008000L or 0x00080000L // CLEAR_TOP, CLEAR_TASK, NEW_DOCUMENT
    /** Windows that are never an app the user was using: Android's own dialogs and pickers. */
    private val NEVER_PREVIOUS = setOf(
        "android", "com.android.systemui", "com.android.documentsui", "com.google.android.documentsui",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.android.permissioncontroller", "com.google.android.permissioncontroller", "com.android.intentresolver",
    )
    /** A task started to pick a file or a value is a trampoline, not an app the user went to. */
    private val PICKER_ACTIONS = setOf(
        "android.intent.action.GET_CONTENT", "android.intent.action.OPEN_DOCUMENT", "android.intent.action.OPEN_DOCUMENT_TREE",
        "android.intent.action.CREATE_DOCUMENT", "android.intent.action.PICK", "android.intent.action.PICK_ACTIVITY",
        "android.intent.action.CHOOSER", "android.intent.action.RINGTONE_PICKER", "android.intent.action.SET_WALLPAPER",
    )

    private val history = ArrayList<String>()
    private var frontSince = 0L

    /**
     * Called for each app that comes to the front. Keeps the last 8. An app that was in front for
     * less than a moment before the next one took over (a picker, a trampoline) is dropped again.
     */
    @Synchronized
    fun noteForeground(pkg: String) {
        if (history.isNotEmpty() && history[0] == pkg) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (history.isNotEmpty() && now - frontSince < DWELL_MS) history.removeAt(0)
        history.remove(pkg)
        history.add(0, pkg)
        frontSince = now
        while (history.size > 8) history.removeAt(history.size - 1)
    }

    @Synchronized
    private fun historyCopy(): List<String> = ArrayList(history)

    fun tracking(sp: SharedPreferences): Boolean = sp.getBoolean(PREF_TRACK, false)

    fun excluded(sp: SharedPreferences): Set<String> =
        sp.getString(PREF_EXCLUDE, "").orEmpty()
            .split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Parses the output of `dumpsys activity recents`, newest first. */
    fun parse(text: String): List<Task> {
        val out = ArrayList<Task>()
        val starts = Regex("Recent #(\\d+):").findAll(text).toList()
        for ((i, m) in starts.withIndex()) {
            val end = if (i + 1 < starts.size) starts[i + 1].range.first else text.length
            val block = text.substring(m.range.first, end)
            val pkg = Regex("\\bA=(?:\\d+:)?([A-Za-z0-9_.]+)").find(block)?.groupValues?.get(1)
                ?: Regex("\\bI=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: Regex("cmp=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: continue
            val cmp = Regex("cmp=([A-Za-z0-9_.\$]+/[A-Za-z0-9_.\$]+)").find(block)?.groupValues?.get(1)
            val id = Regex("(?:Task|TaskRecord)\\{[0-9a-f]+ #(\\d+)").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val user = Regex("\\bU=(\\d+)").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val type = Regex("\\btype=(\\w+)").find(block)?.groupValues?.get(1).orEmpty()
            // The task's start intent: intent={act=... cat=[...] dat=... flg=0x... cmp=...}
            val intent = Regex("\\bintent=\\{([^}]*)\\}").find(block)?.groupValues?.get(1).orEmpty()
            val act = Regex("\\bact=(\\S+)").find(intent)?.groupValues?.get(1).orEmpty()
            val cats = Regex("\\bcat=\\[([^\\]]*)\\]").find(intent)?.groupValues?.get(1)
                ?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            val flags = Regex("\\bflg=0x([0-9a-fA-F]+)").find(intent)?.groupValues?.get(1)?.toLongOrNull(16) ?: 0L
            val dat = Regex("\\bdat=(\\S+)").find(intent)?.groupValues?.get(1).orEmpty()
            val hidden = (flags and FLAG_EXCLUDE_FROM_RECENTS) != 0L || block.contains("isAvailable=false") ||
                Regex("\\bsz=0\\b").containsMatchIn(block)
            out.add(Task(pkg, cmp, block.contains("visible=true"), id, user, type, act, cats, flags, dat, hidden))
        }
        return out
    }

    private fun homePackages(context: Context): Set<String> = runCatching {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        context.packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
    }.getOrDefault(emptySet())

    /** Reads the recents list through Shizuku. Null when Shizuku is not ready or printed nothing usable. Blocking. */
    fun readRecents(): List<Task>? {
        if (!ShizukuShell.isReady()) return null
        val sb = StringBuilder()
        runCatching { ShizukuShell.run("dumpsys activity recents") { sb.append(it).append('\n') } }
        return parse(sb.toString()).takeIf { it.isNotEmpty() }
    }

    /** An app that is installed, enabled and not suspended: hidden, frozen or removed apps (Hail ...) are not. */
    fun isUsableApp(context: Context, pkg: String): Boolean = runCatching {
        val ai = context.packageManager.getApplicationInfo(pkg, 0)
        ai.enabled && (ai.flags and android.content.pm.ApplicationInfo.FLAG_SUSPENDED) == 0
    }.getOrDefault(false)

    /** Whether a task is something the user would call an app they were using. */
    private fun counts(context: Context, t: Task, home: Set<String>): Boolean =
        t.pkg != context.packageName && t.pkg !in home && t.pkg !in NEVER_PREVIOUS &&
            !t.hiddenFromRecents && (t.type.isEmpty() || t.type == "standard") &&
            t.action !in PICKER_ACTIONS && isUsableApp(context, t.pkg)

    /** The task to go to from [tasks], or null. */
    fun pick(context: Context, tasks: List<Task>, skip: Set<String>): Task? {
        val home = homePackages(context)
        // The app in front: the first task that is visible (or the first one, when the list says nothing about visibility).
        val anyVisibleInfo = tasks.any { it.visible }
        val first = tasks.firstOrNull { it.pkg != context.packageName && it.pkg !in NEVER_PREVIOUS }
        val current = if (first != null && (first.visible || !anyVisibleInfo) && first.pkg !in home) first else null
        return tasks.firstOrNull { t ->
            counts(context, t, home) && t.pkg !in skip &&
                (current == null || (t.pkg != current.pkg && t.id != current.id))
        }
    }

    // ---- bringing a task back -------------------------------------------------------------------

    /** Whether [task] is now the one in front. Blocking. */
    private fun isFront(task: Task): Boolean {
        val now = readRecents() ?: return false
        val top = now.firstOrNull { it.visible } ?: return false
        return top.id == task.id || (task.id < 0 && top.pkg == task.pkg)
    }

    /** Resumes [task] where it was left. Returns how it was done, or null if nothing worked. Blocking. */
    private fun resume(context: Context, task: Task): String? {
        // 1. Replay the task's start intent like a launcher icon does: Android resumes the task instead of starting a new screen.
        if (task.component != null) {
            val flags = (task.flags and FLAGS_THAT_RESTART.inv()) or FLAG_NEW_TASK or 0x00200000L // + RESET_TASK_IF_NEEDED
            val cmd = StringBuilder("am start --user ${task.user}")
            cmd.append(" -a ").append(task.action.ifEmpty { "android.intent.action.MAIN" })
            val cats = task.categories.ifEmpty { listOf("android.intent.category.LAUNCHER") }
            cats.forEach { cmd.append(" -c ").append(it) }
            if (task.data.isNotEmpty() && task.data != "null") cmd.append(" -d '").append(task.data.replace("'", "")).append("'")
            cmd.append(" -n ").append(task.component).append(" -f 0x").append(java.lang.Long.toHexString(flags))
            runCatching { ShizukuShell.run(cmd.toString()) { } }
            try { Thread.sleep(350) } catch (_: InterruptedException) { }
            if (isFront(task)) return "resumed"
        }
        if (task.id < 0) return null
        // 2. Move the task to the front by its id.
        runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            am.moveTaskToFront(task.id, 0)
        }
        try { Thread.sleep(350) } catch (_: InterruptedException) { }
        if (isFront(task)) return "moved to front"
        // 3. Shell: bring it to the front by id, then let go of the lock.
        runCatching { ShizukuShell.run("am task lock ${task.id}") { } }
        try { Thread.sleep(250) } catch (_: InterruptedException) { }
        runCatching { ShizukuShell.run("am task lock stop") { } }
        try { Thread.sleep(250) } catch (_: InterruptedException) { }
        return if (isFront(task)) "locked to front" else null
    }

    /** Every app seen lately, newest first: Shizuku's recents (only what Recents shows), else the tracked ones. Blocking. */
    fun detected(): List<String> {
        val out = LinkedHashSet<String>()
        val tasks = readRecents()
        if (tasks != null) tasks.filter { !it.hiddenFromRecents && it.action !in PICKER_ACTIONS }.forEach { out.add(it.pkg) }
        else historyCopy().forEach { out.add(it) }
        return out.toList()
    }

    /** What the Test button shows: the list found and the app it would go to. Blocking. */
    fun test(context: Context, sp: SharedPreferences): String {
        val skip = excluded(sp)
        val sb = StringBuilder()
        val tasks = readRecents()
        if (tasks != null) {
            sb.append("Shizuku recents (newest first):\n")
            val home = homePackages(context)
            tasks.forEachIndexed { n, t ->
                val why = when {
                    t.pkg in skip -> " (skipped by you)"
                    t.pkg == context.packageName -> " (A itself)"
                    t.pkg in home -> " (launcher)"
                    t.hiddenFromRecents -> " (hidden from Recents)"
                    t.action in PICKER_ACTIONS -> " (a picker, not an app)"
                    t.pkg in NEVER_PREVIOUS -> " (system window)"
                    !counts(context, t, home) -> " (not usable)"
                    else -> ""
                }
                sb.append("${n + 1}. ${t.pkg}${if (t.visible) " (visible)" else ""} task ${t.id}$why\n")
            }
            sb.append("\nWould go to: ${pick(context, tasks, skip)?.pkg ?: "nothing found"}\n")
        } else {
            sb.append("Shizuku recents: not available (Shizuku not running/allowed, or nothing readable).\n")
        }
        val h = historyCopy()
        sb.append("\nTracked apps (accessibility, newest first, tracking is ${if (tracking(sp)) "ON" else "OFF"}):\n")
        if (h.isEmpty()) sb.append("(empty)\n") else h.forEachIndexed { n, p -> sb.append("${n + 1}. $p${if (p in skip) " (skipped)" else ""}\n") }
        return sb.toString().trim()
    }

    /**
     * Goes to the previous app. Blocking work runs on its own thread; [report] is called from it
     * with a short message when nothing could be done.
     */
    fun go(context: Context, sp: SharedPreferences, report: (String) -> Unit) {
        Thread {
            val skip = excluded(sp)
            val tasks = readRecents()
            val target = tasks?.let { pick(context, it, skip) }
            if (target != null) {
                if (resume(context, target) != null) return@Thread
                // Nothing brought the task back: say so instead of opening something else.
                val msg = "Previous app: could not bring back ${target.pkg}"
                if (sp.getBoolean(PREF_TOAST, false)) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } else report(msg)
                return@Thread
            }
            // Fallback: the tracked list. Index 0 is the app in front.
            val h = historyCopy()
            val own = context.packageName
            val cur = h.firstOrNull { it != own }
            val pkg = h.firstOrNull { it != own && it != cur && it !in skip && it !in NEVER_PREVIOUS && isUsableApp(context, it) }
            val intent = pkg?.let { context.packageManager.getLaunchIntentForPackage(it) }
            if (intent != null) {
                // Like a launcher icon: the app's task comes back as it was left.
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                runCatching { context.startActivity(intent) }
            } else {
                val msg = "Previous app: nothing found (use Shizuku, or turn on app tracking)"
                if (sp.getBoolean(PREF_TOAST, false)) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } else report(msg)
            }
        }.start()
    }
}
