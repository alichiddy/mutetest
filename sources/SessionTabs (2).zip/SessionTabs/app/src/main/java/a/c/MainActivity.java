package a.c;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Minimal browser: every tab is bound to its own WebView Profile
 * (separate cookies, localStorage, cache, logins). Only the active tab
 * has a live WebView, so RAM stays low.
 *
 * Built for web chat apps (Claude, ChatGPT): microphone + camera, file/photo
 * upload, downloads (incl. blob: files), third-party cookies for login,
 * Chrome-like user agent, autoplay audio for voice mode, external link schemes.
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://duckduckgo.com";
    private static final int REQ_FILE = 2;
    private static final int REQ_PERM = 1;

    private static class Tab {
        String profile;
        String url;
        Tab(String p, String u) { profile = p; url = u; }
    }

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private int counter = 0;
    private boolean profilesOk;

    private WebView web;
    private CookieManager cookies;
    private EditText urlBar;
    private Button tabBtn;
    private FrameLayout holder;
    private SharedPreferences prefs;
    private PermissionRequest pendingPerm;
    private ValueCallback<Uri[]> filePathCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("s", MODE_PRIVATE);
        profilesOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        tabBtn = new Button(this);
        tabBtn.setMinWidth(0);
        tabBtn.setMinimumWidth(0);
        tabBtn.setOnClickListener(v -> showTabMenu());
        bar.addView(tabBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        holder = new FrameLayout(this);
        root.addView(holder, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (!profilesOk) {
            Toast.makeText(this,
                    "Update 'Android System WebView' / Chrome: per-tab sessions unsupported.",
                    Toast.LENGTH_LONG).show();
        }

        load();
        String incoming = getIntent() != null && getIntent().getData() != null
                ? getIntent().getData().toString() : null;
        if (tabs.isEmpty()) newTab(incoming != null ? incoming : HOME);
        else {
            open(Math.min(prefs.getInt("cur", 0), tabs.size() - 1));
            if (incoming != null) go(incoming);
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        Uri d = i.getData();
        if (d != null) newTab(d.toString());
    }

    // ---------- tabs ----------

    private void newTab(String url) {
        tabs.add(new Tab("p" + (++counter), url));
        open(tabs.size() - 1);
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void open(int i) {
        pendingPerm = null;
        if (filePathCb != null) { filePathCb.onReceiveValue(null); filePathCb = null; }
        if (web != null) {
            holder.removeView(web);
            web.destroy();   // free RAM; session data stays in the profile
            web = null;
        }
        current = i;
        Tab t = tabs.get(i);

        web = new WebView(this);
        if (profilesOk) {
            // must be called before any other call on this WebView
            ProfileStore.getInstance().getOrCreateProfile(t.profile);
            WebViewCompat.setProfile(web, t.profile);
            cookies = ProfileStore.getInstance().getOrCreateProfile(t.profile).getCookieManager();
        } else {
            cookies = CookieManager.getInstance();
        }
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);   // needed by many login flows

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(false);    // voice-mode audio replies
        s.setAllowFileAccess(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        // look like Chrome, not a WebView (helps Google/Apple sign-in pages)
        s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));

        web.addJavascriptInterface(new Bridge(), "ARB");

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { sync(u); }
            @Override public void onPageFinished(WebView v, String u) { sync(u); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                        || u.startsWith("blob:") || u.startsWith("data:") || u.startsWith("javascript:"))
                    return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); }   // mailto:, tel:, apps
                catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            // microphone + camera (voice messages, voice mode, camera input)
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    ArrayList<String> grant = new ArrayList<>();
                    ArrayList<String> need = new ArrayList<>();
                    for (String res : r.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                            grant.add(res);
                            if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                        } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                            grant.add(res);
                            if (!has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                        }
                    }
                    if (grant.isEmpty()) { r.deny(); return; }
                    if (need.isEmpty()) { r.grant(grant.toArray(new String[0])); return; }
                    pendingPerm = r;
                    requestPermissions(need.toArray(new String[0]), REQ_PERM);
                });
            }

            // file / photo upload
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                                       FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((du, dua, dcd, dmime, dlen) -> download(du, dua, dcd, dmime));

        holder.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        web.loadUrl(t.url);
        urlBar.setText(t.url);
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    private void sync(String u) {
        if (u == null || current < 0) return;
        tabs.get(current).url = u;
        if (!urlBar.hasFocus()) urlBar.setText(u);
    }

    private void closeCurrent() {
        Tab t = tabs.remove(current);
        holder.removeView(web);
        web.destroy();
        web = null;
        if (profilesOk) {
            try { ProfileStore.getInstance().deleteProfile(t.profile); }  // wipes that session
            catch (Exception ignored) { }
        }
        if (tabs.isEmpty()) newTab(HOME);
        else open(Math.max(0, current - 1));
    }

    private void showTabMenu() {
        int n = tabs.size();
        String[] items = new String[n + 3];
        items[0] = "+  New tab (fresh session)";
        items[1] = "x  Close this tab (deletes its logins)";
        items[2] = "↻  Reload";
        for (int i = 0; i < n; i++) {
            String host = Uri.parse(tabs.get(i).url).getHost();
            items[i + 3] = (i == current ? "● " : "○ ") + (i + 1) + ". "
                    + (host != null ? host : tabs.get(i).url);
        }
        new AlertDialog.Builder(this).setItems(items, (d, w) -> {
            if (w == 0) newTab(HOME);
            else if (w == 1) closeCurrent();
            else if (w == 2) { if (web != null) web.reload(); }
            else if (w - 3 != current) open(w - 3);
        }).show();
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty() || web == null) return;
        String u;
        if (in.startsWith("http://") || in.startsWith("https://")) u = in;
        else if (in.contains(" ") || !in.contains(".")) u = "https://duckduckgo.com/?q=" + Uri.encode(in);
        else u = "https://" + in;
        web.loadUrl(u);
    }

    // ---------- permissions / file chooser results ----------

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (pendingPerm == null) return;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : pendingPerm.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
        }
        if (ok.isEmpty()) pendingPerm.deny();
        else pendingPerm.grant(ok.toArray(new String[0]));
        pendingPerm = null;
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == REQ_FILE && filePathCb != null) {
            filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, data));
            filePathCb = null;
        }
    }

    // ---------- downloads ----------

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
    }

    /** Receives blob: files read by JavaScript and saves them to Downloads. */
    private class Bridge {
        @JavascriptInterface
        public void save(String b64, String mime, String name) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > 100 * 1024 * 1024) return;
                saveBytes(bytes, mime, name);
            } catch (Exception ignored) { }
        }
    }

    private void download(String url, String agent, String cd, String mime) {
        String name = URLUtil.guessFileName(url, cd, mime);
        try {
            if (url.startsWith("blob:")) {
                if (web == null || url.contains("'") || url.contains("\\")) return;
                web.evaluateJavascript("(function(){var x=new XMLHttpRequest();x.open('GET','" + url
                        + "',true);x.responseType='blob';x.onload=function(){var r=new FileReader();"
                        + "r.onloadend=function(){ARB.save(String(r.result).split(',')[1]||'','"
                        + esc(mime) + "','" + esc(name) + "')};r.readAsDataURL(x.response)};x.send()})()", null);
                toast("Downloading " + name);
            } else if (url.startsWith("data:")) {
                int c = url.indexOf(',');
                if (c < 0) return;
                String head = url.substring(5, c);
                String payload = url.substring(c + 1);
                byte[] bytes = head.endsWith(";base64")
                        ? Base64.decode(payload, Base64.DEFAULT)
                        : Uri.decode(payload).getBytes(StandardCharsets.UTF_8);
                saveBytes(bytes, mime, name);
            } else {
                DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
                if (mime != null && !mime.isEmpty()) rq.setMimeType(mime);
                rq.addRequestHeader("User-Agent", agent);
                String ck = cookies != null ? cookies.getCookie(url) : null;
                if (ck != null) rq.addRequestHeader("Cookie", ck);
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(rq);
                toast("Downloading " + name);
            }
        } catch (Exception e) {
            toast("Download failed");
        }
    }

    private void saveBytes(byte[] bytes, String mime, String name) {
        name = name == null ? "download" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (name.isEmpty()) name = "download";
        if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bytes); }
            } else {
                File f = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name);
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
            }
            toast("Saved to Downloads: " + name);
        } catch (Exception e) {
            toast("Save failed");
        }
    }

    // ---------- persistence ----------

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (Tab t : tabs) sb.append(t.profile).append('|').append(t.url).append('\n');
        prefs.edit().putString("tabs", sb.toString())
                .putInt("cur", Math.max(current, 0)).putInt("n", counter).apply();
    }

    private void load() {
        counter = prefs.getInt("n", 0);
        String s = prefs.getString("tabs", "");
        for (String line : s.split("\n")) {
            int k = line.indexOf('|');
            if (k > 0) tabs.add(new Tab(line.substring(0, k), line.substring(k + 1)));
        }
    }

    @Override protected void onPause() {
        super.onPause();
        save();
        if (web != null) web.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
