package a.a.strip

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.res.Configuration
import android.media.AudioDeviceInfo
import android.media.AudioManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * The "When..." list of the main bar: each row is an event, an optional "only if", and an action.
 * A row is looked at only when its event happens (nothing runs or waits while idle): the saved list is
 * read from the preferences at that moment, and the last text read is kept so a repeated event does not
 * parse it again.
 */
object WhenRules {
    const val SLIDE_IN = "slidein"
    const val VOL_UP = "volup"
    const val VOL_DOWN = "voldown"
    const val AT_ZERO = "zero"
    const val AT_FULL = "full"
    const val CELL_RUNS = "cell"
    const val CLOSES = "closes"

    /** Event id and its words, in the order the picker shows them. */
    val EVENTS = listOf(
        SLIDE_IN to "I slide in (the cells window opens)",
        VOL_UP to "Volume goes up (while sliding)",
        VOL_DOWN to "Volume goes down (while sliding)",
        AT_ZERO to "Volume reaches 0%",
        AT_FULL to "Volume reaches 100%",
        CELL_RUNS to "A chosen cell runs",
        CLOSES to "The cells window closes",
    )

    const val ONLY_NONE = ""
    const val ONLY_APP = "app"
    const val ONLY_PORTRAIT = "portrait"
    const val ONLY_LANDSCAPE = "landscape"
    const val ONLY_KEYBOARD = "keyboard"
    const val ONLY_HEADPHONES = "headphones"

    val ONLY = listOf(
        ONLY_NONE to "Always",
        ONLY_APP to "A chosen app is in front",
        ONLY_PORTRAIT to "Phone is upright (portrait)",
        ONLY_LANDSCAPE to "Phone is on its side (landscape)",
        ONLY_KEYBOARD to "The keyboard is open",
        ONLY_HEADPHONES to "Headphones are connected",
    )

    /**
     * One row. [onlyArg] = the package for "a chosen app is in front". [cellKey] = the cell for "a chosen cell
     * runs" (its name and its action). [alsoOpen] (slide in only) = the cells window still opens. [closeOnLift]
     * (slide in only) = floating windows the action opened (a widget, notes, gallery) close when the thumb lifts.
     */
    data class Rule(
        val event: String, val only: String = "", val onlyArg: String = "",
        val cellKey: String = "", val cellName: String = "",
        val action: String = "", val actionName: String = "",
        val alsoOpen: Boolean = true, val closeOnLift: Boolean = false,
    )

    private const val PREFS = "MyPrefs"
    private const val KEY = "whenRules"

    private var cachedJson: String? = null
    private var cached: List<Rule> = emptyList()

    fun cellKey(label: String, action: String) = label + "\u0001" + action

    fun load(context: Context): List<Rule> {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        if (json.isNullOrBlank()) return emptyList()
        if (json == cachedJson) return cached
        val out = ArrayList<Rule>()
        runCatching {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Rule(
                        o.optString("e"), o.optString("o"), o.optString("oa"), o.optString("ck"), o.optString("cn"),
                        o.optString("a"), o.optString("an"), o.optBoolean("open", true), o.optBoolean("lift", false),
                    ),
                )
            }
        }
        cachedJson = json; cached = out
        return out
    }

    fun save(context: Context, rules: List<Rule>) {
        val arr = JSONArray()
        for (r in rules) {
            arr.put(
                JSONObject().put("e", r.event).put("o", r.only).put("oa", r.onlyArg).put("ck", r.cellKey).put("cn", r.cellName)
                    .put("a", r.action).put("an", r.actionName).put("open", r.alsoOpen).put("lift", r.closeOnLift),
            )
        }
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (rules.isEmpty()) p.remove(KEY) else p.putString(KEY, arr.toString())
        p.apply()
    }

    /** The rows of [event] whose "only if" holds right now. [front] and [keyboardOpen] are asked only when a row needs them. */
    fun matching(
        context: Context, event: String, front: () -> String?, keyboardOpen: () -> Boolean, cellKey: String = "",
    ): List<Rule> {
        val all = load(context)
        if (all.isEmpty()) return emptyList()
        return all.filter { r ->
            r.event == event && r.action.isNotBlank() &&
                (event != CELL_RUNS || r.cellKey == cellKey) &&
                holds(context, r, front, keyboardOpen)
        }
    }

    private fun holds(context: Context, r: Rule, front: () -> String?, keyboardOpen: () -> Boolean): Boolean = when (r.only) {
        ONLY_APP -> r.onlyArg.isNotBlank() && front() == r.onlyArg
        ONLY_PORTRAIT -> context.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        ONLY_LANDSCAPE -> context.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        ONLY_KEYBOARD -> keyboardOpen()
        ONLY_HEADPHONES -> headphones(context)
        else -> true
    }

    private fun headphones(context: Context): Boolean = runCatching {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            when (it.type) {
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET,
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> true
                else -> false
            }
        }
    }.getOrDefault(false)

    /** The app in front by usage access (quick, no shell). Null when the permission is missing or nothing was seen. */
    @Suppress("DEPRECATION")
    fun usageFront(context: Context): String? = runCatching {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        if (ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.packageName) != AppOpsManager.MODE_ALLOWED) return@runCatching null
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 60_000L, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != context.packageName) last = e.packageName
        }
        last
    }.getOrNull()

    /** What floating windows are open now, so [closeSince] can close only the ones a row's action opened. */
    class Snapshot(val widgets: Set<Int>, val tools: Set<String>)

    fun snapshot(): Snapshot = Snapshot(WidgetFloat.openIds(), FloatTools.openKinds())

    /** Closes every floating widget / notes / gallery window that was not open in [before]. */
    fun closeSince(before: Snapshot) {
        for (id in WidgetFloat.openIds()) if (id !in before.widgets) WidgetFloat.close(id)
        for (k in FloatTools.openKinds()) if (k !in before.tools) FloatTools.close(k)
    }
}
