package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.json.JSONArray

/**
 * Reads a one-time code out of a floating widget. Two ways, in this order: the widget's own text
 * (Persian and Arabic digits become 0-9), and, for digits that are drawn rather than written, a
 * small shape matcher that learns the digits from the widget itself. Nothing is kept in memory
 * between reads; the learned shapes live in one small preferences file.
 */
object OtpOcr {
    private const val PREFS = "otp_ocr"
    private const val G = 10
    private const val KEEP = 8

    class Glyph(val grid: FloatArray, val aspect: Float, val relH: Float, val relY: Float)

    private class Comp(var l: Int, var t: Int, var r: Int, var b: Int, var area: Int) {
        val w: Int get() = r - l + 1
        val h: Int get() = b - t + 1
        val cy: Float get() = (t + b) / 2f
    }

    fun toEnglish(s: CharSequence): String {
        val sb = StringBuilder()
        for (ch in s) {
            sb.append(
                when (ch) {
                    in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0')
                    in '\u0660'..'\u0669' -> '0' + (ch - '\u0660')
                    else -> ch
                },
            )
        }
        return sb.toString()
    }

    /** Every run of 4 to 12 digits written in the widget's text or descriptions. */
    fun digitRuns(root: View): List<String> {
        val out = ArrayList<String>()
        val clean = Regex("[\\s,.\\-]")
        val run = Regex("\\d{4,12}")
        fun scan(t: CharSequence?) {
            if (t.isNullOrEmpty()) return
            val e = toEnglish(t).replace(clean, "")
            for (m in run.findAll(e)) out.add(m.value)
        }
        fun walk(x: View) {
            if (x is TextView) scan(x.text)
            scan(x.contentDescription)
            if (x is ViewGroup) for (n in 0 until x.childCount) walk(x.getChildAt(n))
        }
        walk(root)
        return out
    }

    // ---- finding the shapes ----

    fun segment(src: Bitmap): List<Glyph> {
        var bmp = src
        val side = maxOf(src.width, src.height)
        if (side > 900) {
            val k = 900f / side
            bmp = Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
        }
        val w = bmp.width
        val h = bmp.height
        val total = w * h
        val px = IntArray(total)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val lum = IntArray(total) { val c = px[it]; (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 }

        // Otsu: the threshold that best splits dark from light; the smaller side is the writing.
        val hist = IntArray(256)
        for (v in lum) hist[v]++
        var sum = 0L
        for (n in 0..255) sum += n.toLong() * hist[n]
        var sB = 0L
        var wB = 0
        var best = -1.0
        var thr = 127
        for (t in 0..255) {
            wB += hist[t]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sB += t.toLong() * hist[t]
            val mB = sB.toDouble() / wB
            val mF = (sum - sB).toDouble() / wF
            val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; thr = t }
        }
        var dark = 0
        for (v in lum) if (v <= thr) dark++
        val textIsDark = dark < total - dark
        val fg = BooleanArray(total) { if (textIsDark) lum[it] <= thr else lum[it] > thr }

        // Connected pieces of writing.
        val seen = BooleanArray(total)
        val stack = IntArray(total)
        val comps = ArrayList<Comp>()
        for (s0 in 0 until total) {
            if (!fg[s0] || seen[s0]) continue
            var sp = 0
            stack[sp++] = s0
            seen[s0] = true
            val c = Comp(s0 % w, s0 / w, s0 % w, s0 / w, 0)
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                c.area++
                if (x < c.l) c.l = x
                if (x > c.r) c.r = x
                if (y < c.t) c.t = y
                if (y > c.b) c.b = y
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (fg[q] && !seen[q]) { seen[q] = true; stack[sp++] = q }
                }
            }
            if (c.area >= 6) comps.add(c)
        }
        if (comps.isEmpty()) return emptyList()

        // The line of text: the row with the most pieces.
        var group: List<Comp> = emptyList()
        var bestScore = -1f
        for (a in comps) {
            if (a.h < 8) continue
            val g = comps.filter { Math.abs(it.cy - a.cy) <= 0.5f * a.h }
            val score = g.size * 1000f + a.h
            if (score > bestScore) { bestScore = score; group = g }
        }
        if (group.isEmpty()) return emptyList()

        // Pieces that sit over one another (a dot over a stroke) are one digit.
        val merged = ArrayList<Comp>()
        for (c in group.sortedBy { it.l }) {
            val last = merged.lastOrNull()
            if (last != null && minOf(last.r, c.r) - maxOf(last.l, c.l) + 1 > 0.4f * minOf(last.w, c.w)) {
                last.l = minOf(last.l, c.l)
                last.r = maxOf(last.r, c.r)
                last.t = minOf(last.t, c.t)
                last.b = maxOf(last.b, c.b)
                last.area += c.area
            } else {
                merged.add(Comp(c.l, c.t, c.r, c.b, c.area))
            }
        }
        val maxH = merged.maxOf { it.h }
        val line = merged.filter { it.h >= 0.12f * maxH }
        if (line.isEmpty()) return emptyList()
        val bandT = line.minOf { it.t }
        val bandB = line.maxOf { it.b }
        val bandH = (bandB - bandT + 1).toFloat()

        fun grid(c: Comp): FloatArray {
            val g = FloatArray(G * G)
            val cw = c.w.toFloat()
            val ch = c.h.toFloat()
            for (gy in 0 until G) for (gx in 0 until G) {
                val x0 = c.l + (gx * cw / G).toInt()
                val x1 = minOf(c.r + 1, maxOf(x0 + 1, c.l + ((gx + 1) * cw / G).toInt()))
                val y0 = c.t + (gy * ch / G).toInt()
                val y1 = minOf(c.b + 1, maxOf(y0 + 1, c.t + ((gy + 1) * ch / G).toInt()))
                var n = 0
                var tot = 0
                for (y in y0 until y1) for (x in x0 until x1) { tot++; if (fg[y * w + x]) n++ }
                g[gy * G + gx] = if (tot == 0) 0f else n.toFloat() / tot
            }
            return g
        }
        return line.map { Glyph(grid(it), it.w.toFloat() / it.h, it.h.toFloat() / maxH, (it.cy - bandT) / bandH) }
    }

    // ---- matching ----

    private fun dist(a: Glyph, b: Glyph): Float {
        var s = 0f
        for (i in a.grid.indices) { val d = a.grid[i] - b.grid[i]; s += d * d }
        val da = a.aspect - b.aspect
        val dh = a.relH - b.relH
        val dy = a.relY - b.relY
        return s + 6f * da * da + 12f * dh * dh + 12f * dy * dy
    }

    private fun encode(g: Glyph): JSONArray {
        val a = JSONArray()
        a.put(g.aspect.toDouble()).put(g.relH.toDouble()).put(g.relY.toDouble())
        for (v in g.grid) a.put(Math.round(v * 1000) / 1000.0)
        return a
    }

    private fun decode(a: JSONArray): Glyph? {
        if (a.length() != 3 + G * G) return null
        return Glyph(FloatArray(G * G) { a.getDouble(3 + it).toFloat() }, a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat())
    }

    private fun learned(ctx: Context): List<Pair<Int, Glyph>> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out = ArrayList<Pair<Int, Glyph>>()
        for (d in 0..9) {
            val arr = runCatching { JSONArray(sp.getString("d$d", "[]")) }.getOrNull() ?: continue
            for (n in 0 until arr.length()) decode(arr.getJSONArray(n))?.let { out.add(d to it) }
        }
        return out
    }

    @Volatile private var seedCache: List<Pair<Int, Glyph>>? = null

    /** Drops the starting shapes from memory; they are drawn again the next time a read needs them. */
    fun release() { seedCache = null }

    /** Starting shapes drawn with the phone's own font, in English and in Persian digits, next to a tall stroke so sizes compare the way they do in a code. */
    private fun seeds(): List<Pair<Int, Glyph>> {
        seedCache?.let { return it }
        val out = ArrayList<Pair<Int, Glyph>>()
        for (d in 0..9) for (bold in listOf(false, true)) for (persian in listOf(false, true)) {
            val zero = if (persian) '\u06F0' else '0'
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.textSize = 90f
            p.color = Color.BLACK
            p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val b = Bitmap.createBitmap(260, 160, Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            val cv = Canvas(b)
            cv.drawText((zero + d).toString(), 30f, 110f, p)
            cv.drawText((zero + 1).toString(), 150f, 110f, p)
            val g = segment(b)
            b.recycle()
            if (g.size == 2) out.add(d to g[0])
        }
        seedCache = out
        return out
    }

    private fun classify(ctx: Context, glyphs: List<Glyph>): String {
        val mine = learned(ctx)
        val base = seeds()
        val sb = StringBuilder()
        val log = StringBuilder("OCR read: ${glyphs.size} shapes, taught ${mine.size}, seeds ${base.size}")
        for ((gi, g) in glyphs.withIndex()) {
            var bestD = -1
            var bestV = Float.MAX_VALUE
            var bestMine = false
            var secondD = -1
            var secondV = Float.MAX_VALUE
            fun offer(d: Int, v: Float, isMine: Boolean) {
                if (v < bestV) {
                    if (bestD != d) { secondD = bestD; secondV = bestV }
                    bestV = v; bestD = d; bestMine = isMine
                } else if (d != bestD && v < secondV) { secondD = d; secondV = v }
            }
            for ((d, t) in mine) offer(d, dist(g, t), true)
            for ((d, t) in base) offer(d, dist(g, t) * 1.4f, false)
            sb.append(if (bestD < 0) '?' else ('0' + bestD))
            log.append(
                "\n #$gi asp=%.2f h=%.2f y=%.2f -> %d (%s %.2f), next %d %.2f"
                    .format(g.aspect, g.relH, g.relY, bestD, if (bestMine) "taught" else "seed", bestV, secondD, secondV)
            )
        }
        runCatching { a.a.utils.DiagLog.note(log.toString()) }
        return sb.toString()
    }

    /** The digits drawn in the picture, left to right; empty when it finds none. */
    fun read(ctx: Context, bmp: Bitmap): String = classify(ctx, segment(bmp))

    fun shapeCount(bmp: Bitmap): Int = segment(bmp).size

    /** Learns from a picture and the digits the person says it shows; the reply says what happened. */
    fun learn(ctx: Context, bmp: Bitmap, typed: String): String {
        val digits = toEnglish(typed).filter { it.isDigit() }
        if (digits.isEmpty()) return "Type the digits you see"
        val glyphs = segment(bmp)
        if (glyphs.size != digits.length) return "I found ${glyphs.size} shapes but you typed ${digits.length} digits. Nothing was saved."
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val ed = sp.edit()
        for (d in 0..9) {
            if (!digits.contains('0' + d)) continue
            val arr = runCatching { JSONArray(sp.getString("d$d", "[]")) }.getOrNull() ?: JSONArray()
            for (i in digits.indices) if (digits[i] == '0' + d) arr.put(encode(glyphs[i]))
            val keep = JSONArray()
            for (n in maxOf(0, arr.length() - KEEP) until arr.length()) keep.put(arr.get(n))
            ed.putString("d$d", keep.toString())
        }
        ed.apply()
        return "Learned. Digits known: ${learnedCount(ctx)} of 10"
    }

    fun learnedCount(ctx: Context): Int {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var n = 0
        for (d in 0..9) if ((runCatching { JSONArray(sp.getString("d$d", "[]")).length() }.getOrDefault(0)) > 0) n++
        return n
    }

    /** The digits A has been taught (0 to 9). English digits need no teaching. */
    fun learnedDigits(ctx: Context): Set<Int> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out = HashSet<Int>()
        for (d in 0..9) if ((runCatching { JSONArray(sp.getString("d$d", "[]")).length() }.getOrDefault(0)) > 0) out.add(d)
        return out
    }

    fun forget(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
