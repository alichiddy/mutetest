package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import a.a.service.OverlayRuntime
import a.a.utils.PreviousApp
import a.a.utils.ShizukuShell
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Floating widgets: a widget drawn in its own small window over whatever app is in front. No
 * activity is involved, so showing one never switches app or lands on a home screen.
 *
 * - [show] floats one widget (a second call closes it again).
 * - [press] presses one tile of a widget, hidden or shown for a few seconds so you can see the
 *   result (the Hotspot Shield switch, a chat).
 * - [grab] opens the widget in "tap the tile you want" mode and reports which tile it was.
 */
object WidgetFloat {
    private val windows = HashMap<Int, FloatWindow>()

    /** What the last press of a widget tile did: 0 none yet, 1 still looking for the tile, 2 pressed it, 3 tile not found. */
    @Volatile var pressState = 0

    /** Waits (up to [maxMs]) until the last press is settled. True when the tile was found and pressed. Blocking. */
    fun waitPress(maxMs: Int): Boolean {
        val end = System.currentTimeMillis() + maxMs
        while (pressState == 1 && System.currentTimeMillis() < end) pause(150)
        return pressState == 2
    }

    /** Opens an app without an animation, waits [ms], then returns to where the person was. Blocking; false when the app could not be started. */
    fun openThenBack(app: Context, pkg: String, ms: Int, cls: String = ""): Boolean {
        val started = warmUp(app, pkg, cls)
        pause(ms.coerceAtLeast(0))
        if (started) PreviousApp.go(app, app.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)) { }
        pause(600)
        return started
    }

    fun toast(ctx: Context, text: String) {
        Toast.makeText(ctx.applicationContext, text, Toast.LENGTH_LONG).show()
    }

    /** True when A may draw over other apps; otherwise opens the permission screen. */
    internal fun allowed(app: Context): Boolean {
        if (Settings.canDrawOverlays(app)) return true
        toast(app, "Allow \"Display over other apps\" for A, then try again")
        runCatching {
            app.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
        return false
    }

    fun isOpen(id: Int) = windows.containsKey(id)

    fun closeAll() {
        windows.values.toList().forEach { it.close() }
        FloatTools.closeAll()
    }

    fun close(id: Int) {
        windows[id]?.close()
    }

    /** Floats the widget; when it is already floating, closes it instead. */
    fun show(ctx: Context, id: Int, toggle: Boolean = true): Boolean {
        val app = ctx.applicationContext
        if (!allowed(app)) return false
        val existing = windows[id]
        if (existing != null) {
            if (existing.isMinimized()) existing.restore() else if (toggle) existing.close()
            return true
        }
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = false)) {
            toast(app, "That widget could not be shown")
            return false
        }
        windows[id] = w
        return true
    }

    /** Closes the window if it is open and shows it again, so new settings are used. */
    fun reopen(ctx: Context, id: Int): Boolean {
        close(id)
        return show(ctx, id, toggle = false)
    }

    /** Presses one tile. [showMs] = 0 keeps the widget hidden; above 0 shows it that many milliseconds; below 0 keeps it. */
    fun press(ctx: Context, id: Int, name: String, pos: Int, showMs: Int, findMs: Int = 8000, tid: String = ""): Boolean {
        val app = ctx.applicationContext
        pressState = 1
        if (!allowed(app)) { pressState = 3; return false }
        val existing = windows[id]
        if (existing != null) {
            existing.press(name, pos, showMs, closeAfter = false, findMs = findMs, tid = tid)
            return true
        }
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = showMs == 0)) {
            toast(app, "That widget could not be shown")
            pressState = 3
            return false
        }
        windows[id] = w
        w.press(name, pos, showMs, closeAfter = true, findMs = findMs, tid = tid)
        return true
    }

    /** Opens the widget in grab mode; [onDone] gets the tile's name, place and description. */
    fun grab(ctx: Context, id: Int, onDone: (String, Int, String) -> Unit): Boolean {
        val app = ctx.applicationContext
        if (!allowed(app)) return false
        close(id)
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = false, forceHandle = true)) {
            toast(app, "That widget could not be shown")
            return false
        }
        windows[id] = w
        w.startGrab(onDone)
        return true
    }

    /**
     * Runs what a cell asked for (see [WidgetFloatActivity]): first the optional warm-up app and the
     * "before" shortcuts, then the widget itself, then the "after" shortcuts. All of it runs on a
     * thread of its own, and A's own screen is never opened.
     */
    fun handle(ctx: Context, mode: String, i: Intent): Boolean {
        val app = ctx.applicationContext
        val pre = WSteps.parse(i.getStringExtra("pre"))
        val post = WSteps.parse(i.getStringExtra("post"))
        val warm = i.getStringExtra("warm").orEmpty()
        val ocr = mode == "press" && i.getBooleanExtra("ocr", false)
        val again = (mode == "press" || mode == "qs") && i.getBooleanExtra("again", false)
        val post2 = WSteps.parse(i.getStringExtra("post2"))
        if (pre.isEmpty() && post.isEmpty() && warm.isEmpty() && !ocr && !again) return handleNow(app, mode, i)
        // Reading the code needs the widget on screen until it has been read.
        if (ocr) i.putExtra("show", -1).putExtra("showMs", -1)
        val warmMs = i.getIntExtra("warmMs", 3000).coerceAtLeast(0)
        val postMs = i.getIntExtra("postMs", 2000).coerceAtLeast(0)
        val main = Handler(Looper.getMainLooper())
        Thread {
            if (warm.isNotEmpty()) openThenBack(app, warm, warmMs)
            for (s in pre) { runStep(app, main, s); pause(s.waitMs) }
            if (mode == "press" || mode == "qs") pressState = 1
            main.post { runCatching { handleNow(app, mode, i) } }
            if (ocr) { runCatching { readAndType(app, main, i) }; OtpOcr.release() }
            if (post.isNotEmpty()) {
                pause(postMs)
                for (s in post) { runStep(app, main, s); pause(s.waitMs) }
            }
            // "Run the widget again": press the same tile once more, then run the shortcuts meant for after that.
            if (again) {
                pause(i.getIntExtra("againMs", 3000).coerceAtLeast(0))
                pressState = 1
                main.post { runCatching { handleNow(app, mode, i) } }
                if (post2.isNotEmpty()) {
                    pause(i.getIntExtra("post2Ms", 2000).coerceAtLeast(0))
                    for (s in post2) { runStep(app, main, s); pause(s.waitMs) }
                }
            }
        }.start()
        return true
    }

    private fun savedWidgetId(app: Context, i: Intent): Int {
        val pkg = i.getStringExtra("pkg").orEmpty()
        val wid = i.getIntExtra("wid", -1)
        val saved = WidgetKit.savedIds(app)
        val byPkg = saved.filter { pkg.isEmpty() || WidgetKit.providerPackage(app, it) == pkg }
        return if (wid in saved) wid else (byPkg.firstOrNull() ?: -1)
    }

    private class Look(val texts: List<String>, val pics: List<Bitmap>, val whole: Bitmap?)

    /** The widget's written digits and a picture of it, taken on the main thread. */
    private fun look(main: Handler, id: Int): Look? {
        val latch = CountDownLatch(1)
        var out: Look? = null
        main.post {
            val w = windows[id]
            if (w != null) out = runCatching {
                val pieces = w.pieces()
                Look(w.textDigits(), pieces, if (pieces.isEmpty()) w.snapshot() else null)
            }.getOrNull()
            latch.countDown()
        }
        latch.await(3, TimeUnit.SECONDS)
        return out
    }

    /** Every code-like run of digits the widget shows right now. */
    private fun candidates(app: Context, main: Handler, id: Int): Set<String> {
        val l = look(main, id) ?: return emptySet()
        val out = LinkedHashSet<String>(l.texts)
        // Each picture inside the widget is read alone (the card number is longer than a code and is skipped).
        for (p in l.pics) {
            val r = runCatching { OtpOcr.read(app, p) }.getOrDefault("")
            if (r.length in 4..12 && !r.contains('?')) out.add(r)
            p.recycle()
        }
        val pic = l.whole
        if (pic != null) {
            val r = runCatching { OtpOcr.read(app, pic) }.getOrDefault("")
            if (r.length >= 4 && !r.contains('?')) out.add(r)
            pic.recycle()
        }
        return out
    }

    /**
     * Waits for a code to appear that was not there when the widget came up, reads it twice to be sure,
     * copies it and types it into the field that has the cursor (needs Shizuku for the typing).
     */
    private fun readAndType(app: Context, main: Handler, i: Intent) {
        val id = savedWidgetId(app, i)
        if (id == -1) return
        val limit = System.currentTimeMillis() + (if (i.hasExtra("ocrMs")) i.getIntExtra("ocrMs", 40000) else i.getIntExtra("ocrSec", 40) * 1000).coerceAtLeast(5000).toLong()
        pause(1500)
        val before = candidates(app, main, id)
        var last = ""
        while (System.currentTimeMillis() < limit) {
            pause(600)
            val fresh = candidates(app, main, id).firstOrNull { it !in before } ?: continue
            if (fresh != last) { last = fresh; continue }
            main.post {
                runCatching {
                    val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("code", fresh))
                }
            }
            if (i.getBooleanExtra("ocrType", true) && ShizukuShell.isReady()) {
                pause(300)
                runCatching { ShizukuShell.run("input text " + fresh) { } }
            }
            main.post { toast(app, "Code read and copied") }
            if (i.getBooleanExtra("ocrClose", true)) main.post { close(id) }
            return
        }
        main.post { toast(app, "No code was found in the widget") }
    }

    fun firstOpenId(): Int = windows.keys.firstOrNull() ?: -1

    /**
     * Reads the code a widget shows right now, until the same one is seen twice. A widget that is not floating
     * is shown for a moment and closed again. Blocking; throws a short message when nothing is found.
     */
    fun readNow(app: Context, id: Int, timeoutMs: Int = 15000, accept: (String) -> Boolean = { true }): String {
        val main = Handler(Looper.getMainLooper())
        val wasOpen = isOpen(id)
        if (!wasOpen) {
            main.post { runCatching { show(app, id, toggle = false) } }
            pause(1500)
        }
        var last = ""
        val limit = System.currentTimeMillis() + timeoutMs
        try {
            while (System.currentTimeMillis() < limit) {
                val all = candidates(app, main, id)
                val c = all.firstOrNull { it.length in 4..12 && accept(it) } ?: all.firstOrNull { accept(it) }
                if (c != null) { if (c == last) return c; last = c } else last = ""
                pause(500)
            }
        } finally {
            OtpOcr.release()
            if (!wasOpen) main.post { close(id) }
        }
        throw IllegalStateException("No code was found in the widget")
    }

    /** The widget window for a saved widget, if it is on screen (used to teach the reader). */
    fun picture(id: Int): Bitmap? = windows[id]?.snapshot()

    private fun pause(ms: Int) {
        if (ms > 0) try { Thread.sleep(ms.toLong()) } catch (_: InterruptedException) { }
    }

    private fun runStep(app: Context, main: Handler, s: WStep) {
        val c = OverlayRuntime.activeController
        if (c == null) main.post { toast(app, "Turn A on first") } else c.runStripItem(StripItem(s.label, "", s.action))
    }

    /** Starts the app without any animation (through Shizuku when it runs); true when it was started. */
    private fun warmUp(app: Context, pkg: String, cls: String = ""): Boolean {
        val launch = (if (cls.isNotEmpty()) a.a.flow.exactIntent(pkg, cls) else app.packageManager.getLaunchIntentForPackage(pkg)) ?: return false
        val comp = launch.component?.flattenToShortString()
        if (comp != null && ShizukuShell.isReady()) {
            val code = runCatching { ShizukuShell.run("am start --activity-no-animation -n " + comp) { } }.getOrDefault(-1)
            if (code == 0) return true
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        return runCatching { app.startActivity(launch) }.isSuccess
    }

    private fun handleNow(app: Context, mode: String, i: Intent): Boolean {
        if (mode == "notes" || mode == "gallery") return FloatTools.toggle(app, mode)
        if (mode == "qs") {
            val showMs = if (i.hasExtra("showMs")) i.getIntExtra("showMs", 0) else 0
            return QsTiles.press(app, i.getStringExtra("tap").orEmpty(), i.getIntExtra("pos", 0), showMs,
                i.getIntExtra("findMs", 8000), i.getStringExtra("tid").orEmpty(), i.getBooleanExtra("cover", true))
        }
        val pkg = i.getStringExtra("pkg").orEmpty()
        val wid = i.getIntExtra("wid", -1)
        val saved = WidgetKit.savedIds(app)
        if (saved.isEmpty()) {
            toast(app, "No widget saved in A yet")
            if (mode == "press") pressState = 3
            return false
        }
        val byPkg = saved.filter { pkg.isEmpty() || WidgetKit.providerPackage(app, it) == pkg }
        val id = if (wid in saved) wid else (byPkg.firstOrNull() ?: -1)
        if (mode == "press") {
            if (id == -1) {
                toast(app, "The widget for this cell is not saved in A any more")
                pressState = 3
                return false
            }
            val showMs = if (i.hasExtra("showMs")) i.getIntExtra("showMs", 0)
            else i.getIntExtra("show", 0).let { if (it > 0) it * 1000 else it }   // cells saved before milliseconds
            return press(app, id, i.getStringExtra("tap").orEmpty(), i.getIntExtra("pos", -1), showMs,
                i.getIntExtra("findMs", 8000), i.getStringExtra("tid").orEmpty())
        }
        if (wid == -1 && pkg.isEmpty()) return saved.map { show(app, it) }.all { it }
        if (id == -1) {
            toast(app, "The widget for this cell is not saved in A any more")
            return false
        }
        return show(app, id)
    }
}

/** The window's root: reports taps inside it and taps outside it. */
class FloatRoot(context: Context) : FrameLayout(context) {
    var onOutside: (() -> Unit)? = null
    var onTouched: ((MotionEvent) -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside?.invoke()
            return true
        }
        onTouched?.invoke(ev)
        return super.dispatchTouchEvent(ev)
    }
}

/** One floating widget window. */
class FloatWindow(private val app: Context, private val wid: Int, private val onClosed: (Int) -> Unit) {
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val d = app.resources.displayMetrics.density
    private val sw: Int get() = app.resources.displayMetrics.widthPixels
    private val sh: Int get() = app.resources.displayMetrics.heightPixels
    private var cfg = WidgetKit.loadCfg(app, wid)
    private var root: FloatRoot? = null
    private var lp: WindowManager.LayoutParams? = null
    private var frame: GrabFrame? = null
    private var hv: AppWidgetHostView? = null
    private var bar: LinearLayout? = null
    private var title: TextView? = null
    private var handlePx = 0
    private var closed = false
    private var grabbing = false
    private val closeRun = Runnable { close() }
    private var bubble: FloatBubble? = null
    private var mini = false
    private var bubbleLabel = ""

    // ---- showing ----

    fun show(silent: Boolean, forceHandle: Boolean = false): Boolean {
        val info = AppWidgetManager.getInstance(app).getAppWidgetInfo(wid) ?: return false
        val view = runCatching { WidgetKit.host(app).createView(app, wid, info) }.getOrNull() ?: return false
        hv = view
        cfg = WidgetKit.loadCfg(app, wid)
        val showHandle = (cfg.handle || forceHandle) && !silent
        handlePx = if (showHandle) (28 * d).toInt() else 0

        val maxW = maxOf(96, (sw / d).toInt() - 8)
        val maxH = maxOf(64, (sh / d).toInt() - 40)
        val wDp = (if (cfg.wDp > 0) cfg.wDp else maxOf(96, (info.minWidth / d).toInt())).coerceIn(96, maxW)
        val hDp = (if (cfg.hDp > 0) cfg.hDp else maxOf(64, (info.minHeight / d).toInt() + (handlePx / d).toInt())).coerceIn(64, maxH)
        val wPx = (wDp * d).toInt()
        val hPx = (hDp * d).toInt()
        val fg = if (cfg.bg == 2) 0xFF202124.toInt() else 0xFFFFFFFF.toInt()

        val card = LinearLayout(app)
        card.orientation = LinearLayout.VERTICAL
        val gf = GrabFrame(app, view)
        frame = gf

        if (showHandle) {
            val b = LinearLayout(app)
            b.orientation = LinearLayout.HORIZONTAL
            b.gravity = Gravity.CENTER_VERTICAL
            b.setBackgroundColor(0x33000000)
            val t = TextView(app)
            t.text = "≡  " + cfg.name.ifBlank { runCatching { info.loadLabel(app.packageManager) }.getOrDefault("") }
            t.setTextColor(fg)
            t.textSize = 12f
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER_VERTICAL
            t.setPadding((8 * d).toInt(), 0, 0, 0)
            t.setOnTouchListener(dragListener)
            b.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            bubbleLabel = cfg.name.ifBlank { runCatching { info.loadLabel(app.packageManager).toString() }.getOrDefault("") }
            val mn = TextView(app)
            mn.text = "–"
            mn.textSize = 18f
            mn.gravity = Gravity.CENTER
            mn.setTextColor(fg)
            mn.setPadding((12 * d).toInt(), 0, (12 * d).toInt(), 0)
            mn.setOnClickListener { minimize() }
            b.addView(mn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val x = TextView(app)
            x.text = "✕"
            x.textSize = 16f
            x.gravity = Gravity.CENTER
            x.setTextColor(fg)
            x.setPadding((14 * d).toInt(), 0, (14 * d).toInt(), 0)
            x.setOnClickListener { close() }
            b.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            card.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, handlePx))
            bar = b
            title = t
        }
        card.addView(gf, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val r = FloatRoot(app)
        r.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (showHandle && !cfg.lock) {
            val grip = TextView(app)
            grip.text = "◢"
            grip.setTextColor(fg)
            grip.textSize = 16f
            grip.gravity = Gravity.END or Gravity.BOTTOM
            grip.setPadding(0, 0, (4 * d).toInt(), 0)
            grip.setOnTouchListener(resizeListener)
            val glp = FrameLayout.LayoutParams((34 * d).toInt(), (34 * d).toInt())
            glp.gravity = Gravity.END or Gravity.BOTTOM
            r.addView(grip, glp)
        }
        val bgDrawable = GradientDrawable()
        bgDrawable.setColor(
            when (cfg.bg) {
                0 -> 0
                2 -> 0xF2FFFFFF.toInt()
                else -> 0xE6202124.toInt()
            },
        )
        bgDrawable.cornerRadius = cfg.radius * d
        r.background = bgDrawable
        r.clipToOutline = true
        r.outlineProvider = ViewOutlineProvider.BACKGROUND
        r.alpha = if (silent) 0f else cfg.opacity / 100f
        r.onOutside = { if (cfg.outside && !grabbing && !silent) close() }
        r.onTouched = { ev -> onTouched(ev) }
        root = r

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (silent) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else if (cfg.outside) flags = flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        val p = WindowManager.LayoutParams(wPx, hPx, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        val (px, py) = place(wPx, hPx)
        p.x = px
        p.y = py
        lp = p

        WidgetKit.hostStart(app)
        val added = runCatching { wm.addView(r, p) }.isSuccess
        if (!added) {
            WidgetKit.hostStop()
            root = null
            return false
        }
        view.updateAppWidgetSize(null, wDp, hDp - (handlePx / d).toInt(), wDp, hDp - (handlePx / d).toInt())
        if (cfg.autoClose > 0 && !silent) schedule(cfg.autoClose)
        return true
    }

    private fun place(wPx: Int, hPx: Int): Pair<Int, Int> {
        if (cfg.remember && cfg.x != Int.MIN_VALUE && cfg.y != Int.MIN_VALUE) {
            return clampX(cfg.x, wPx) to clampY(cfg.y, hPx)
        }
        val cx = (sw - wPx) / 2
        val cy = (sh - hPx) / 2
        val edge = (8 * d).toInt()
        return when (cfg.startAt) {
            1 -> cx to (sh * 0.08f).toInt()
            2 -> cx to (sh - hPx - (sh * 0.12f).toInt())
            3 -> edge to cy
            4 -> (sw - wPx - edge) to cy
            else -> cx to cy
        }
    }

    private fun clampX(x: Int, wPx: Int) = x.coerceIn(0, maxOf(0, sw - wPx))
    private fun clampY(y: Int, hPx: Int) = y.coerceIn(0, maxOf(0, sh - hPx))

    private fun update() {
        val r = root ?: return
        val p = lp ?: return
        runCatching { wm.updateViewLayout(r, p) }
    }

    // ---- moving and resizing ----

    private var dsx = 0f
    private var dsy = 0f
    private var dox = 0
    private var doy = 0

    private val dragListener = View.OnTouchListener { _, e ->
        val p = lp
        if (p == null || cfg.lock) {
            false
        } else {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dsx = e.rawX
                    dsy = e.rawY
                    dox = p.x
                    doy = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = clampX(dox + (e.rawX - dsx).toInt(), p.width)
                    p.y = clampY(doy + (e.rawY - dsy).toInt(), p.height)
                    update()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (cfg.snap) snap(p)
                    update()
                    savePos(p)
                    true
                }
                else -> false
            }
        }
    }

    private fun snap(p: WindowManager.LayoutParams) {
        val th = (16 * d).toInt()
        if (p.x < th) p.x = 0
        if (sw - (p.x + p.width) < th) p.x = maxOf(0, sw - p.width)
        if (p.y < th) p.y = 0
        if (sh - (p.y + p.height) < th) p.y = maxOf(0, sh - p.height)
    }

    private fun savePos(p: WindowManager.LayoutParams) {
        if (!cfg.remember) return
        cfg = cfg.copy(x = p.x, y = p.y)
        WidgetKit.saveCfg(app, wid, cfg)
    }

    private var rsx = 0f
    private var rsy = 0f
    private var rw = 0
    private var rh = 0

    private val resizeListener = View.OnTouchListener { _, e ->
        val p = lp
        if (p == null || cfg.lock) {
            false
        } else {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    rsx = e.rawX
                    rsy = e.rawY
                    rw = p.width
                    rh = p.height
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (rw + (e.rawX - rsx).toInt()).coerceIn((96 * d).toInt(), maxOf((96 * d).toInt(), sw - p.x))
                    p.height = (rh + (e.rawY - rsy).toInt()).coerceIn((64 * d).toInt(), maxOf((64 * d).toInt(), sh - p.y))
                    update()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wDp = (p.width / d).toInt()
                    val hDp = (p.height / d).toInt()
                    cfg = cfg.copy(wDp = wDp, hDp = hDp)
                    WidgetKit.saveCfg(app, wid, cfg)
                    hv?.updateAppWidgetSize(null, wDp, hDp - (handlePx / d).toInt(), wDp, hDp - (handlePx / d).toInt())
                    true
                }
                else -> false
            }
        }
    }

    // ---- closing ----

    private fun schedule(ms: Int) {
        handler.removeCallbacks(closeRun)
        handler.postDelayed(closeRun, ms.toLong())
    }

    private fun onTouched(ev: MotionEvent) {
        if (grabbing) return
        if (ev.actionMasked == MotionEvent.ACTION_UP && cfg.afterTap > 0 && ev.y > handlePx) {
            schedule(cfg.afterTap)
        } else if (cfg.autoClose > 0 && ev.actionMasked == MotionEvent.ACTION_DOWN) {
            schedule(cfg.autoClose)
        }
    }

    /** Every run of 4 or more digits written in the widget's text (Persian or English digits). */
    fun textDigits(): List<String> {
        val v = hv ?: return emptyList()
        return OtpOcr.digitRuns(v)
    }

    /** One picture per image inside the widget, for widgets that draw their numbers as pictures. */
    fun pieces(): List<Bitmap> {
        val v = hv ?: return emptyList()
        return WidgetKit.imagePieces(v, if (cfg.bg == 2) 0xFF202124.toInt() else 0xFFFFFFFF.toInt())
    }

    /** A picture of the widget as it looks now, for reading digits that are drawn rather than written. */
    fun snapshot(): Bitmap? {
        val v = hv ?: return null
        if (v.width < 8 || v.height < 8) return null
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        b.eraseColor(if (cfg.bg == 2) 0xFF202124.toInt() else 0xFFFFFFFF.toInt())
        v.draw(Canvas(b))
        return b
    }

    // ---- minimizing: the window hides and a bubble stands in for it; the widget keeps running ----

    fun isMinimized() = mini

    fun minimize() {
        val r = root ?: return
        val p = lp ?: return
        if (mini || closed) return
        val b = FloatBubble(app, "w$wid", bubbleLabel) { restore() }
        if (!b.show()) return
        bubble = b
        mini = true
        handler.removeCallbacks(closeRun)   // it must not close while it is tucked away
        r.visibility = View.GONE
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        update()
    }

    fun restore() {
        val r = root ?: return
        val p = lp ?: return
        if (!mini) return
        mini = false
        bubble?.hide()
        bubble = null
        r.visibility = View.VISIBLE
        p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        update()
        if (cfg.autoClose > 0) schedule(cfg.autoClose)
    }

    fun close() {
        if (closed) return
        closed = true
        handler.removeCallbacksAndMessages(null)
        bubble?.hide()
        bubble = null
        root?.let { r -> runCatching { wm.removeView(r) } }
        root = null
        WidgetKit.hostStop()
        onClosed(wid)
    }

    // ---- pressing a tile ----

    fun press(name: String, pos: Int, showMs: Int, closeAfter: Boolean, findMs: Int = 8000, tid: String = "") {
        if (mini) restore()   // a tile cannot be pressed in a hidden window
        val h = hv ?: run { WidgetFloat.pressState = 3; return }
        val limit = findMs.coerceAtLeast(300)
        val start = android.os.SystemClock.uptimeMillis()
        // Page down through the widget's list only after a third of the time (at most 3 s) has passed.
        val scrollAfter = minOf(3000L, limit / 3L)
        var nextScroll = start + scrollAfter
        var idle = 0
        fun notFound() {
            WidgetFloat.pressState = 3
            WidgetFloat.toast(app, "That tile was not found in the widget")
            if (closeAfter) close()
        }
        val r = object : Runnable {
            override fun run() {
                if (closed) return
                val tile = WidgetKit.pick(h, name, pos)
                if (tile != null) {
                    // The tile moved (found by its name, at another place): remember the new place.
                    if (tid.isNotEmpty() && name.isNotBlank()) runCatching {
                        val now = WidgetKit.placeOf(tile, h)
                        val sameName = WidgetKit.tiles(h).count { WidgetKit.nameOf(it, h).equals(name, ignoreCase = true) }
                        if (sameName == 1 && now >= 0 && now != pos) WidgetTiles.savePlace(app, tid, now)
                    }
                    WidgetKit.click(tile)
                    WidgetFloat.pressState = 2
                    if (closeAfter) {
                        // above 0: close after that many milliseconds; 0: close at once; below 0: stay until closed by hand
                        if (showMs > 0) schedule(showMs) else if (showMs == 0) handler.postDelayed({ close() }, 500)
                    }
                    return
                }
                val now = android.os.SystemClock.uptimeMillis()
                if (now - start >= limit) { notFound(); return }
                if (now >= nextScroll) {
                    if (WidgetKit.scrollPage(h)) idle = 0 else idle++
                    nextScroll = now + 1000L
                    if (idle >= 3) { notFound(); return }
                }
                handler.postDelayed(this, 250)
            }
        }
        handler.postDelayed(r, 300)
    }

    // ---- grabbing a tile ----

    fun startGrab(onDone: (String, Int, String) -> Unit) {
        val gf = frame ?: return
        val h = hv ?: return
        grabbing = true
        gf.grabbing = true
        title?.text = "🎯  Tap the tile you want"
        gf.onGrab = { tile ->
            if (tile == null) {
                WidgetFloat.toast(app, "Tap right on the tile (a chat, a button)")
            } else {
                val name = WidgetKit.nameOf(tile, h)
                val place = WidgetKit.placeOf(tile, h)
                val details = WidgetKit.describe(tile, h)
                gf.grabbing = false
                grabbing = false
                close()
                onDone(name, place, details)
            }
        }
        // 🎯 switches grabbing off so the widget can be scrolled, and on again.
        val b = bar ?: return
        val t = TextView(app)
        t.text = "🎯"
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
        t.setOnClickListener {
            gf.grabbing = !gf.grabbing
            grabbing = gf.grabbing
            title?.text = if (gf.grabbing) "🎯  Tap the tile you want" else "↕  Scroll, then tap 🎯"
        }
        b.addView(t, 1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }
}
