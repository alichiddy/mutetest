package a.a.sides

import a.a.utils.AppStarter
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import a.a.flow.FlowStore
import a.a.flow.NativePicker
import a.a.strip.StripConfig
import a.a.ui.screens.strip.FoundShortcut
import a.a.ui.screens.strip.INTENT_ACTION_PREFIX
import a.a.ui.screens.strip.loadCreators
import a.a.ui.screens.strip.loadStaticShortcuts
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import a.a.share.FilePaths
import a.a.data.local.SharedPref

/** Picks any A action as plain dialogs (nothing stays in memory): built-in, device, cells, scripts, apps. */
object SidePicker {
    private class Choice(val label: String, val action: String)

    fun label(activity: android.content.Context, action: String): String {
        if (StripConfig.isTouch(action)) return label(activity, StripConfig.bare(action)) + " (on touch)"
        if (action.isEmpty()) return "not set"
        if (action == Seg.MAIN) return "Same as main slider (live)"
        if (action == Seg.STRIP) return "Cells window"
        HandlerActionCatalog.entryFor(action)?.let { return activity.getString(it.labelRes) }
        if (NativePicker.isNative(action)) return NativePicker.label(action)
        if (action.startsWith("MyFlow:")) return "Script: " + (FlowStore.resolve(activity, action.removePrefix("MyFlow:")) ?: action.removePrefix("MyFlow:"))
        if (action.startsWith(INTENT_ACTION_PREFIX)) {
            val pkg = runCatching { AppStarter.parse(action).let { it.component?.packageName ?: it.`package` } }.getOrNull()
            val app = pkg?.let { runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(it, 0)).toString() }.getOrNull() }
            return "App shortcut" + (app?.let { " ($it)" } ?: "")
        }
        if (action.startsWith(StripConfig.FLOW_PREFIX)) return "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
        if (action.startsWith("Shell:")) return "Shell: " + action.removePrefix("Shell:").take(24)
        if (action.startsWith("File:")) return "Open file: " + FilePaths.nameOf(action)
        HandlerActions.launchedPackage(action)?.let { pkg ->
            return "Open " + runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        }
        return action.take(30)
    }

    /** Opens the action picker (shown by the side bars screen); [onPicked] gets the chosen action. */
    fun pick(activity: Activity, slot: String, onPicked: (String) -> Unit) {
        (activity as? SidesActivity)?.showPicker(slot, onPicked)
    }

    /** What the main slider does for [slot] now, for "Copy Main Slider's current". */
    fun mainNow(activity: Activity, slot: String): String {
        val p = SharedPref(activity)
        return when (slot) {
            "tap" -> p.getHandlerSingleTapAction(); "double" -> p.getHandlerDoubleTapAction()
            "long" -> p.getHandlerLongTapAction(); "up" -> p.getHandlerSwipeUpAction()
            "down" -> p.getHandlerSwipeDownAction()
            "in" -> if (p.getStripEnabled()) Seg.STRIP else p.getHandlerSwipeInAction()
            else -> p.getHandlerSwipeOutAction()
        }
    }

    const val REQ_CREATOR = 7001
    private var pendingCreator: ((String) -> Unit)? = null

    /** Called from the activity's onActivityResult: the shortcut another app's "create shortcut" screen made. */
    @Suppress("DEPRECATION")
    fun onResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ_CREATOR) return
        val cb = pendingCreator; pendingCreator = null
        val picked = data?.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (resultCode == Activity.RESULT_OK && picked != null && cb != null) cb(INTENT_ACTION_PREFIX + AppStarter.save(picked))
    }

    /** Starts another app's "make a shortcut" screen; its result comes back through [onResult]. */
    fun launchCreator(activity: Activity, pkg: String, cls: String, onPicked: (String) -> Unit) {
        pendingCreator = onPicked
        runCatching {
            activity.startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setClassName(pkg, cls), REQ_CREATOR)
        }
    }
}
