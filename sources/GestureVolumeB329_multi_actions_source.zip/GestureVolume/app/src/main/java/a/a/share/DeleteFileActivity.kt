package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import a.a.utils.ShizukuShell
import java.io.File

/**
 * "A Delete" in the share / open-with sheet of any app: shows the name(s), asks once, then deletes the
 * file that was shared or opened. It tries, in this order: the file itself by its path (when A may
 * touch it), the app that owns it (its document provider), and last Shizuku (rm on the real path).
 * Nothing stays open afterwards.
 */
class DeleteFileActivity : Activity() {
    private class Target(val uri: Uri, val name: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val targets = collect(intent)
        if (targets.isEmpty()) { finishWith("Nothing to delete."); return }
        val shown = targets.take(8).joinToString("\n") { it.name } +
            if (targets.size > 8) "\n... and ${targets.size - 8} more" else ""
        AlertDialog.Builder(this)
            .setTitle(if (targets.size > 1) "Delete ${targets.size} files?" else "Delete this file?")
            .setMessage(shown)
            .setCancelable(true)
            .setPositiveButton("Delete") { _, _ -> deleteAll(targets) }
            .setNegativeButton("Cancel") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    @Suppress("DEPRECATION")
    private fun collect(i: Intent): List<Target> {
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
        }
        return uris.map { Target(it, FilePaths.displayName(this, it) ?: "file") }
    }

    private fun deleteAll(targets: List<Target>) {
        val app = applicationContext
        Thread {
            val gone = ArrayList<String>()
            val kept = ArrayList<String>()
            for (t in targets) {
                val ok = try { deleteOne(t.uri) } catch (e: Throwable) { false }
                if (ok) gone += t.name else kept += t.name
            }
            var report = if (gone.isNotEmpty()) "Deleted: " + gone.joinToString(", ") else ""
            if (kept.isNotEmpty()) {
                if (report.isNotEmpty()) report += "\n"
                report += "Could not delete: " + kept.joinToString(", ") + " (the app that owns it did not allow it)"
            }
            runOnUiThread { finishWith(report.ifEmpty { "Nothing to delete." }, app) }
        }.start()
    }

    private fun finishWith(report: String, app: android.content.Context = applicationContext) {
        Toast.makeText(app, report, Toast.LENGTH_LONG).show()
        finish()
    }

    private fun deleteOne(uri: Uri): Boolean {
        val path = FilePaths.pathOf(uri) ?: dataPath(uri)
        // 1. The file itself, when A may touch it.
        if (path != null) {
            val f = File(path)
            if (f.isFile && f.delete()) return true
        }
        // 2. The app that owns it.
        if (uri.scheme == "content") {
            val viaDoc = runCatching {
                DocumentsContract.isDocumentUri(this, uri) && DocumentsContract.deleteDocument(contentResolver, uri)
            }.getOrDefault(false)
            if (viaDoc) return true
            val viaProvider = runCatching { contentResolver.delete(uri, null, null) > 0 }.getOrDefault(false)
            if (viaProvider) return true
        }
        // 3. Shizuku, only on a real file path in shared storage (rm without -r never removes a folder).
        if (path != null && ShizukuShell.isReady() &&
            (path.startsWith("/storage/") || path.startsWith("/sdcard/") || path.startsWith("/data/media/"))
        ) {
            val code = runCatching { ShizukuShell.run("rm -f '" + path.replace("'", "'\\''") + "'") { } }.getOrDefault(-1)
            return code == 0
        }
        return false
    }

    /** The real path some providers (the media store) still give under "_data". */
    private fun dataPath(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()?.takeIf { it.startsWith("/") }
}
