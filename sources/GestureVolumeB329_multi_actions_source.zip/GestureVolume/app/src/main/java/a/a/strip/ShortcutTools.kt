package a.a.strip

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.io.File

/**
 * What any chosen shortcut can do besides being saved: run now (Test), go onto a launcher's home
 * screen.
 *
 * Nothing here runs until one of those buttons is pressed.
 */
object ShortcutTools {
    private fun prefs(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

    // ---- the question window when a shortcut is picked (off unless the person turns it on) ----

    private const val ASK_KEY = "pickAsk"
    fun askOnPick(c: Context): Boolean = prefs(c).getBoolean(ASK_KEY, false)
    fun setAskOnPick(c: Context, on: Boolean) { prefs(c).edit().putBoolean(ASK_KEY, on).apply() }

    // ---- Test -------------------------------------------------------------------------------

    @Volatile private var testToken: String? = null
    @Volatile private var testUntil = 0L

    /** True for a run started by [test] a moment ago: it may run an action that is not saved anywhere yet. */
    fun isTrusted(token: String?): Boolean = token != null && token == testToken && System.currentTimeMillis() < testUntil

    fun runIntent(c: Context, label: String, icon: String, action: String): Intent =
        Intent(c, ShortcutRunActivity::class.java).setAction(Intent.ACTION_MAIN)
            .putExtra("n", label).putExtra("a", action).putExtra("i", icon)

    /** Runs the shortcut now, the way a cell would, without saving it. */
    fun test(c: Context, label: String, icon: String, action: String) {
        if (action.isBlank()) { toast(c, "Nothing to run yet"); return }
        val token = java.util.UUID.randomUUID().toString()
        testToken = token
        testUntil = System.currentTimeMillis() + 15_000L
        c.startActivity(runIntent(c, label, icon, action).putExtra("t", token).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---- icon -------------------------------------------------------------------------------

    private fun bitmapOf(d: android.graphics.drawable.Drawable, size: Int): Bitmap =
        Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { d.setBounds(0, 0, size, size); d.draw(Canvas(it)) }

    private fun tile(size: Int): Pair<Bitmap, Canvas> {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val r = size * 0.21f
        cv.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF37474F.toInt() })
        return out to cv
    }

    /** The cell's own picture, app icon or emoji as a picture; A's own icon when it has none. */
    fun iconBitmap(c: Context, label: String, icon: String, action: String, size: Int = 96): Bitmap {
        val item = StripItem(label, icon, action)
        item.iconFile?.let { f ->
            runCatching { BitmapFactory.decodeFile(File(c.filesDir, "sicons/$f").path) }.getOrNull()?.let { src ->
                val (out, cv) = tile(size)
                val inner = (size * 2 / 3f).toInt()
                val off = (size - inner) / 2f
                cv.drawBitmap(Bitmap.createScaledBitmap(src, inner, inner, true), off, off, null)
                return out
            }
        }
        item.appIconPackage?.let { pkg ->
            runCatching { bitmapOf(c.packageManager.getApplicationIcon(pkg), size) }.getOrNull()?.let { return it }
        }
        if (item.iconFile == null && item.appIconPackage == null && icon.isNotBlank() && icon != "none" && icon.length <= 12) {
            val (out, cv) = tile(size)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size * 0.58f; textAlign = Paint.Align.CENTER }
            cv.drawText(icon, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
            return out
        }
        return bitmapOf(c.packageManager.getApplicationIcon(c.packageName), size)
    }

    // ---- launchers --------------------------------------------------------------------------

    fun defaultLauncher(c: Context): String? =
        c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName

    /** Every installed launcher except A itself and the default one: package and name. */
    fun otherLaunchers(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val def = defaultLauncher(c)
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != c.packageName && it.first != def }
            .distinctBy { it.first }
    }

    /** Asks the default launcher for a home-screen icon; the launcher shows its own "Add" question. False when it does not accept. */
    fun pinToDefault(c: Context, label: String, icon: String, action: String): Boolean = runCatching {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(c)) return false
        val name = label.ifBlank { "A" }
        val info = ShortcutInfoCompat.Builder(c, "a_" + Integer.toHexString((label + "|" + action).hashCode()))
            .setShortLabel(name.take(24)).setLongLabel(name)
            .setIntent(runIntent(c, label, icon, action))
            .setIcon(IconCompat.createWithBitmap(iconBitmap(c, label, icon, action)))
            .build()
        ShortcutManagerCompat.requestPinShortcut(c, info, null)
    }.getOrDefault(false)

    /** The old "install shortcut" request, sent to one launcher. Only launchers that still listen to it add the icon. */
    fun sendLegacy(c: Context, pkg: String, label: String, icon: String, action: String) {
        val i = Intent("com.android.launcher.action.INSTALL_SHORTCUT").setPackage(pkg)
            .putExtra(Intent.EXTRA_SHORTCUT_INTENT, runIntent(c, label, icon, action))
            .putExtra(Intent.EXTRA_SHORTCUT_NAME, label.ifBlank { "A" })
            .putExtra(Intent.EXTRA_SHORTCUT_ICON, iconBitmap(c, label, icon, action))
        c.sendBroadcast(i)
    }
}
