package a.a.ui.screens.strip

import android.content.SharedPreferences
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage

/**
 * "Gap, popup and effects" in the card design (full-screen window with the back arrow, like the Look window):
 * the gap to the screen's side, the thumb popup and what shows while the thumb is over a side that has an action.
 * Only the drawing is new; every setting keeps its stored name and value.
 */
@Composable
fun GapPopupDialog(sp: SharedPreferences, onDismiss: () -> Unit) {
    var gapDp by remember { mutableIntStateOf(sp.getInt("stripGapDp", 4)) }
    var tipOn by remember { mutableStateOf(sp.getBoolean("stripTipOn", false)) }
    var edgeFx by remember { mutableIntStateOf(sp.getInt("stripEdgeFx", 1)) }
    var edgeTick by remember { mutableStateOf(sp.getBoolean("stripEdgeTick", false)) }

    fun setGap(v: Int) { gapDp = v.coerceIn(0, 5000); sp.edit().putInt("stripGapDp", gapDp).apply() }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().imePadding(), color = MaterialTheme.colorScheme.background) {
            AWindowPage("Gap, popup and effects", onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup("Gap") {
                        row { sh ->
                            StepRow(
                                "Gap to the screen's side", "$gapDp dp", sh,
                                onMinus = { setGap(gapDp - 1) }, onPlus = { setGap(gapDp + 1) },
                                icon = Icons.Filled.Tune,
                                summary = "Between the screen's side and the cells window",
                                info = "Each side bar segment can have its own gap (in its settings).",
                            )
                        }
                    }
                    CardGroup("Popup under the thumb") {
                        row { sh ->
                            SwitchRow(
                                "Popup", tipOn, sh, icon = Icons.Filled.Visibility,
                                summary = "The cell under the thumb, a bit bigger, just above it",
                            ) { tipOn = it; sp.edit().putBoolean("stripTipOn", it).apply() }
                        }
                        if (tipOn) {
                            row { sh ->
                                SliderRow("tipPct", "Popup size", "% of a cell", sp.getInt("stripTipPct", 140), 100, 300, sh) {
                                    sp.edit().putInt("stripTipPct", it).apply()
                                }
                            }
                            row { sh ->
                                SliderRow("tipGap", "Gap between the cell and the popup", " dp", sp.getInt("stripTipGapDp", 4), 0, 120, sh) {
                                    sp.edit().putInt("stripTipGapDp", it).apply()
                                }
                            }
                        }
                    }
                    CardGroup("Outside the cells window", hint = "When the thumb is over a side that has an action.") {
                        row { sh ->
                            PickCardRow(
                                "edgeFx", "What shows", listOf("Nothing shown", "Its name above the thumb", "Name + that side of the window glows", "Name + the whole window glows"),
                                edgeFx, sh, icon = Icons.Filled.TouchApp,
                            ) { edgeFx = it; sp.edit().putInt("stripEdgeFx", it).apply() }
                        }
                        row { sh ->
                            SwitchRow(
                                "A tick", edgeTick, sh, icon = Icons.Filled.Notifications,
                                summary = "A tick when the thumb enters such a side",
                            ) { edgeTick = it; sp.edit().putBoolean("stripEdgeTick", it).apply() }
                        }
                    }
                }
            }
        }
    }
}
