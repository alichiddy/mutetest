package a.a.ui.screens.shell

import android.hardware.usb.UsbDevice
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.adb.AdbConnection
import a.a.adb.AdbOtg

/** Pick a device plugged into the OTG cable and connect to it; or disconnect from the current one. */
@Composable
fun OtgDialog(
    connectedName: String?,
    onConnected: (AdbConnection) -> Unit,
    onDisconnect: () -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var devices by remember { mutableStateOf(AdbOtg.devices(ctx)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun connect(d: UsbDevice) {
        if (busy) return
        busy = true
        status = "Allow USB access in the Android window..."
        AdbOtg.requestPermission(ctx, d) { granted ->
            if (!granted) {
                status = "USB access was not allowed."
                busy = false
            } else {
                status = "Connecting..."
                Thread {
                    var conn: AdbConnection? = null
                    try {
                        val t = AdbOtg.open(ctx, d)
                        val c = AdbConnection(ctx, t)
                        conn = c
                        c.connect { status = "On the other device: tick Always allow, then tap Allow." }
                        onConnected(c)
                        status = "Connected."
                    } catch (e: Throwable) {
                        conn?.close()
                        status = "Could not connect: " + (e.message ?: e.javaClass.simpleName)
                    }
                    busy = false
                }.start()
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("OTG device") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Plug the other device into this phone with an OTG cable. On that device turn on USB debugging (Developer options).",
                    fontSize = 12.sp
                )
                if (connectedName != null) {
                    Text("Connected to: $connectedName")
                    Button(onClick = { onDisconnect(); onDismiss() }) { Text("Disconnect (run on this phone again)") }
                }
                if (status.isNotEmpty()) Text(status)
                if (devices.isEmpty()) Text("No USB device found. Plug it in, then press Refresh.")
                for (d in devices) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(AdbOtg.label(d), Modifier.weight(1f), fontSize = 13.sp)
                        Button(enabled = !busy && AdbOtg.isAdb(d), onClick = { connect(d) }) { Text("Connect") }
                    }
                }
                OutlinedButton(onClick = { devices = AdbOtg.devices(ctx) }) { Text("Refresh") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

/** Where on the other device the pushed files go; the file picker opens after Choose. */
@Composable
fun PushDialog(dir: String, onDismiss: () -> Unit, onChoose: (String) -> Unit) {
    var d by remember { mutableStateOf(dir) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Push files to the other device") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Folder on the other device (made if missing):", fontSize = 12.sp)
                OutlinedTextField(value = d, onValueChange = { d = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(enabled = d.isNotBlank(), onClick = { onChoose(d.trim()) }) { Text("Choose files and push") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
