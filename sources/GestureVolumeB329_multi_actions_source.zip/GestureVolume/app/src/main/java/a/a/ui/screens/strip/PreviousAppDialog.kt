package a.a.ui.screens.strip

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.service.OverlayRuntime
import a.a.ui.components.AWindowPage
import a.a.ui.motion.TextButton
import a.a.utils.PreviousApp

/**
 * "Previous app" in the card design (full-screen window with the back arrow, like the Look window): the way it
 * switches, how it follows the apps, the apps it skips, and the Test. [sp] is the main settings file ("MyPrefs").
 * Only the drawing is new; every setting keeps its stored name and value.
 */
@Composable
fun PreviousAppDialog(sp: SharedPreferences, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var exclude by remember { mutableStateOf(sp.getString(PreviousApp.PREF_EXCLUDE, "").orEmpty()) }
    var toast by remember { mutableStateOf(sp.getBoolean(PreviousApp.PREF_TOAST, false)) }
    var allowA by remember { mutableStateOf(sp.getBoolean(PreviousApp.PREF_ALLOW_A, false)) }
    var pinFix by remember { mutableStateOf(sp.getBoolean(PreviousApp.PREF_PIN_FIX, false)) }
    var track by remember { mutableStateOf(PreviousApp.tracking(sp)) }
    var result by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<List<String>?>(null) }
    val sel = remember { mutableStateListOf<String>() }
    var pick by remember { mutableStateOf(false) }

    val pm = context.packageManager
    fun nameOf(pkg: String): String = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
    fun skipList(): List<String> = exclude.split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    fun saveSkip(l: List<String>) {
        exclude = l.joinToString("\n")
        sp.edit().putString(PreviousApp.PREF_EXCLUDE, exclude).apply()
    }
    fun copyText(t: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("apps", t))
        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().imePadding(), color = MaterialTheme.colorScheme.background) {
            AWindowPage("Previous app", onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup("Switching") {
                        row { sh ->
                            SwitchRow(
                                "Allow A as the previous app", allowA, sh, icon = Icons.Filled.Apps,
                                summary = "Switch back to A when it was the app before",
                                info = "Works with Shizuku and with accessibility tracking.",
                            ) { allowA = it; sp.edit().putBoolean(PreviousApp.PREF_ALLOW_A, it).apply() }
                        }
                        row { sh ->
                            SwitchRow(
                                "Stop the phone locking after it switches", pinFix, sh, icon = Icons.Filled.Lock,
                                summary = "Needs Shizuku",
                                info = "Turns off \"lock after unpinning\" for a moment, then puts it back.",
                            ) { pinFix = it; sp.edit().putBoolean(PreviousApp.PREF_PIN_FIX, it).apply() }
                        }
                        row { sh ->
                            SwitchRow(
                                "Messages as Android's own toast", toast, sh, icon = Icons.Filled.Notifications,
                                summary = "Not shown on the bar",
                            ) { toast = it; sp.edit().putBoolean(PreviousApp.PREF_TOAST, it).apply() }
                        }
                    }
                    CardGroup("How it follows the apps") {
                        row { sh ->
                            SwitchRow(
                                "Track apps without Shizuku", track, sh, icon = Icons.Filled.Memory,
                                summary = "Uses accessibility window changes",
                                info = "A little work on each app change. With Shizuku running, the real recents list is read only when the action runs; nothing is kept in memory.",
                            ) {
                                track = it
                                sp.edit().putBoolean(PreviousApp.PREF_TRACK, it).apply()
                                OverlayRuntime.accessibilityService?.applyEventSubscription()
                            }
                        }
                    }
                    CardGroup("Apps to skip", hint = "For example apps that only forward a link to another app.") {
                        val skips = skipList()
                        if (skips.isEmpty()) {
                            row { sh -> SettingRow("None", sh, compact = true, summary = "Nothing is skipped") }
                        }
                        skips.forEach { pkg ->
                            row { sh ->
                                SettingRow(
                                    nameOf(pkg), sh, compact = true, summary = pkg,
                                    trailing = { TextButton(onClick = { saveSkip(skipList() - pkg) }) { Text("Remove") } },
                                )
                            }
                        }
                        row { sh ->
                            SettingRow(
                                "Add from all apps", sh, icon = Icons.Filled.Add,
                                summary = "Pick one app from the list", onClick = { pick = true },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                "Find recent apps", sh, icon = Icons.Filled.Search,
                                summary = "The apps seen lately, newest first",
                                onClick = {
                                    found = emptyList(); sel.clear()
                                    Thread { found = PreviousApp.detected() }.start()
                                },
                            )
                        }
                    }
                    found?.let { list ->
                        CardGroup(
                            "Recent apps",
                            hint = if (list.isEmpty()) null else "Newest first. Tap an app to select it.",
                        ) {
                            if (list.isEmpty()) {
                                row { sh ->
                                    SettingRow(
                                        "Nothing found yet", sh, compact = true,
                                        summary = "Shizuku must run, or turn on tracking above.",
                                    )
                                }
                            }
                            list.forEach { pkg ->
                                row { sh ->
                                    SettingRow(
                                        nameOf(pkg) + if (pkg in skipList()) "  (skipped)" else "", sh, compact = true, summary = pkg,
                                        onClick = { if (pkg in sel) sel.remove(pkg) else sel.add(pkg) },
                                        trailing = { Checkbox(checked = pkg in sel, onCheckedChange = null) },
                                    )
                                }
                            }
                            if (list.isNotEmpty()) {
                                row { sh ->
                                    SettingRow(
                                        "Selected: ${sel.size}", sh, compact = true,
                                        footer = {
                                            Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                TextButton(onClick = { sel.clear(); sel.addAll(list) }) { Text("All") }
                                                TextButton(
                                                    onClick = { saveSkip((skipList() + sel).distinct()); sel.clear() },
                                                    enabled = sel.isNotEmpty(),
                                                ) { Text("Skip selected") }
                                                TextButton(
                                                    onClick = { copyText(sel.joinToString("\n")) },
                                                    enabled = sel.isNotEmpty(),
                                                ) { Text("Copy selected") }
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                    CardGroup("Test") {
                        row { sh ->
                            SettingRow(
                                "Test: what does it find?", sh, icon = Icons.Filled.PlayArrow,
                                summary = "Shows the apps it reads and the one it would go to",
                                onClick = {
                                    result = "Reading..."
                                    Thread { result = PreviousApp.test(context, sp) }.start()
                                },
                                footer = {
                                    if (result.isNotEmpty()) {
                                        SelectionContainer {
                                            Text(
                                                result, style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp),
                                            )
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }

    if (pick) {
        Dialog(onDismissRequest = { pick = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                AppList(
                    onPick = { app ->
                        saveSkip(skipList() + app.packageName)
                        pick = false
                    },
                    onBack = { pick = false },
                    everything = true,
                )
            }
        }
    }
}
