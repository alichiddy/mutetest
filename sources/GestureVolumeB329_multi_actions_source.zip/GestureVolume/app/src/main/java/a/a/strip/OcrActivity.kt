package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import a.a.flow.NativeActions
import a.a.utils.ShizukuShell

/**
 * One place for the OCR that reads digits. English digits work from the start; Persian and Arabic
 * digits are taught once here, from a live widget you can press, or from any part of the screen,
 * and then work everywhere (widget cells, the OCR shortcut, scripts).
 */
class OcrActivity : ComponentActivity() {
    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val main = Handler(Looper.getMainLooper())
    private var tick by mutableStateOf(0)
    private var pic by mutableStateOf<Bitmap?>(null)
    private var typed by mutableStateOf("")
    private var liveId by mutableStateOf(-1)
    private var liveView: AppWidgetHostView? = null
    private var pieces by mutableStateOf<List<Bitmap>>(emptyList())
    private var pieceAt by mutableStateOf(0)
    private var boxTick by mutableStateOf(0)
    private var renaming by mutableStateOf<String?>(null)
    private var renameText by mutableStateOf("")

    /** True when the Scripts screen sent the person here to draw a box: A goes straight back to it afterwards. */
    private var fromScripts = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
        val redo = intent.getStringExtra("boxredo")
        val isNew = intent.getBooleanExtra("boxnew", false)
        if (savedInstanceState == null && (redo != null || isNew)) {
            fromScripts = true
            main.post { boxPick(redo) }
        }
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    // A tap on the live widget may end on the home screen: bring this screen back (see ReturnGuard).
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val hit = ReturnGuard.hit(liveView, ev)
        val r = super.dispatchTouchEvent(ev)
        if (hit) ReturnGuard.after(this, OcrActivity::class.java)
        return r
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun bringBack() {
        if (fromScripts) {
            fromScripts = false
            runCatching {
                startActivity(Intent(this, a.a.flow.FlowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
            finish()
            return
        }
        runCatching {
            startActivity(Intent(this, OcrActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    /** A goes to the back; the person drags a box over any screen; then A either keeps the picture to teach from, or reads it. */
    private fun screenPick(learn: Boolean) {
        if (!ShizukuShell.isReady()) {
            toast("This needs Shizuku. Start Shizuku and allow A, then try again.")
            return
        }
        val app = applicationContext
        moveTaskToBack(true)
        Thread {
            try {
                Thread.sleep(500)
                if (learn) {
                    val b = ScreenOcr.snap(app)
                    main.post {
                        if (b == null) toast("Nothing was picked") else {
                            typed = ""
                            pieces = emptyList()
                            pic = b
                            toast("Picked. Open A to teach the digits.")
                            bringBack()
                        }
                    }
                } else {
                    val msg = try { NativeActions.run(app, "ocr_area", "copy", HashMap()) } catch (e: Throwable) { e.message ?: "Could not read it" }
                    main.post { toast(msg); bringBack() }
                }
            } finally {
                OtpOcr.release()
            }
        }.start()
    }

    /** A steps aside; the person drags a box over any screen; it is saved by name (a new one, or [redo] drawn again). */
    private fun boxPick(redo: String?) {
        val app = applicationContext
        if (!WidgetFloat.allowed(app)) {
            toast("Allow Display over other apps for A, then try again.")
            return
        }
        moveTaskToBack(true)
        Thread {
            Thread.sleep(500)
            val r = ScreenOcr.pick(app)
            main.post {
                if (r == null) toast("Nothing was picked") else {
                    val name = redo ?: ScreenOcr.nextName(app)
                    ScreenOcr.saveBox(app, name, r)
                    toast("Saved as $name. You can rename it in A.")
                    boxTick++
                }
                bringBack()
            }
        }.start()
    }

    /** A picture of the live widget as it looks now. */
    private fun liveSnapshot(): Bitmap? {
        val v = liveView ?: return null
        if (v.width < 8 || v.height < 8) return null
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.WHITE)
        v.draw(Canvas(b))
        return b
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Screen() {
        val known = remember(tick) { OtpOcr.learnedDigits(this@OcrActivity) }
        val saved = remember { WidgetKit.savedIds(this@OcrActivity) }
        Column(
            Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("OCR: reading digits", fontSize = 18.sp)
            Text(
                "English digits are read from the start. Persian and Arabic digits are taught once here, and then work everywhere: " +
                    "widget cells, the OCR shortcut and scripts.",
                fontSize = 12.sp,
            )
            Text(
                "Taught digits: " + if (known.isEmpty()) "none yet" else known.sorted().joinToString(" "),
                fontSize = 13.sp,
            )

            Text("1. Teach from a live widget", fontSize = 14.sp)
            Text("Pick a widget, press its button until the code shows inside it, then tap \"Read it and teach\".", fontSize = 11.sp)
            if (saved.isEmpty()) {
                Text("No widget yet. Add one in the Widgets window first.", fontSize = 12.sp)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (id in saved) {
                        val name = mgr.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget $id"
                        OutlinedButton(onClick = { liveView = null; liveId = if (liveId == id) -1 else id }) {
                            Text(if (liveId == id) "Hide: $name" else name)
                        }
                    }
                }
            }
            val info = if (liveId != -1) mgr.getAppWidgetInfo(liveId) else null
            if (info != null) {
                key(liveId) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth.value.toInt()
                        val h = 220
                        AndroidView(
                            factory = { ctx -> host.createView(ctx, liveId, info).also { liveView = it } },
                            update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                            modifier = Modifier.fillMaxWidth().height(h.dp),
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        // Each picture inside the widget alone, the likely code first; the whole widget when it has none.
                        val v = liveView
                        val list = if (v == null) emptyList() else WidgetKit.imagePieces(v, Color.WHITE)
                            .sortedBy { p -> val n = OtpOcr.shapeCount(p); if (n in 3..12) 0 else 1 }
                        if (list.isNotEmpty()) { typed = ""; pieces = list; pieceAt = 0; pic = list[0] } else {
                            val b = liveSnapshot()
                            if (b == null) toast("The widget has not loaded yet") else { typed = ""; pieces = emptyList(); pic = b }
                        }
                    }) { Text("Read it and teach") }
                    OutlinedButton(onClick = {
                        ScreenOcr.saveWidget(this@OcrActivity, liveId)
                        toast("The OCR shortcut will read this widget")
                    }) { Text("Use for the OCR shortcut") }
                }
            }

            Text("2. Teach from the screen", fontSize = 14.sp)
            Text("A steps aside. Open the app that shows the digits, drag a box over them, then open A again.", fontSize = 11.sp)
            OutlinedButton(onClick = { screenPick(true) }) { Text("Pick digits on the screen") }

            Text("3. Try it", fontSize = 14.sp)
            Text("The same as the OCR shortcut: drag a box over digits and A copies them.", fontSize = 11.sp)
            OutlinedButton(onClick = { screenPick(false) }) { Text("Read part of the screen now") }

            Text("4. Boxes for the OCR shortcut", fontSize = 14.sp)
            Text(
                "A box is a part of the screen, saved by name. A steps aside, you open the app, drag the box, and A comes back. " +
                    "In the OCR shortcut you then pick the box by its name.",
                fontSize = 11.sp,
            )
            OutlinedButton(onClick = { boxPick(null) }) { Text("New box") }
            val boxes = remember(boxTick) { ScreenOcr.boxNames(this@OcrActivity) }
            if (boxes.isEmpty()) Text("No boxes yet.", fontSize = 12.sp)
            for (name in boxes) {
                Text(name, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { renameText = name; renaming = name }) { Text("Rename") }
                    TextButton(onClick = { boxPick(name) }) { Text("Drag again") }
                    TextButton(onClick = { ScreenOcr.deleteBox(this@OcrActivity, name); boxTick++ }) { Text("Delete") }
                }
            }

            TextButton(onClick = { OtpOcr.forget(this@OcrActivity); tick++ }) { Text("Forget everything taught") }
        }
        renaming?.let { old ->
            AlertDialog(
                onDismissRequest = { renaming = null },
                title = { Text("Name of the box") },
                text = {
                    OutlinedTextField(
                        value = renameText, onValueChange = { renameText = it }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        toast(if (ScreenOcr.renameBox(this@OcrActivity, old, renameText)) "Renamed" else "That name is empty or already used")
                        renaming = null
                        boxTick++
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
            )
        }
        pic?.let { Teach(it) }
    }

    @Composable
    private fun Teach(b: Bitmap) {
        val reading = remember(b) { OtpOcr.read(this@OcrActivity, b) }
        val shapes = remember(b) { OtpOcr.shapeCount(b) }
        AlertDialog(
            onDismissRequest = { OtpOcr.release(); pic = null },
            title = { Text("Teach the digits") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp))
                    if (pieces.size > 1) {
                        TextButton(onClick = { pieceAt = (pieceAt + 1) % pieces.size; typed = ""; pic = pieces[pieceAt] }) {
                            Text("Another picture of the widget (${pieceAt + 1} of ${pieces.size})")
                        }
                    }
                    Text("Shapes found: $shapes. A reads it as: " + reading.ifEmpty { "nothing" }, fontSize = 12.sp)
                    OutlinedTextField(
                        value = typed, onValueChange = { typed = it }, singleLine = true,
                        label = { Text("Type the digits you see") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    toast(OtpOcr.learn(this@OcrActivity, b, typed))
                    tick++
                    if (pieces.size > 1) {
                        // Straight on to the next picture of the widget: more pictures, a better reading.
                        pieceAt = (pieceAt + 1) % pieces.size; typed = ""; pic = pieces[pieceAt]
                    } else {
                        OtpOcr.release()
                        pic = null
                    }
                }) { Text(if (pieces.size > 1) "Teach, then next picture" else "Teach") }
            },
            dismissButton = { TextButton(onClick = { OtpOcr.release(); pic = null }) { Text(if (pieces.size > 1) "Done" else "Cancel") } },
        )
    }
}
