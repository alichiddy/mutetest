package a.a.strip

import a.a.utils.AppStarter
import a.a.utils.HandlerActions
import org.json.JSONArray
import org.json.JSONObject

/**
 * One cell of the strip.
 *
 * [action] is what runs: any [HandlerActions] identifier (so every Deck action, tile, app launch
 * and the QR scanner already work), or "Flow:468/233" for an Automate flow statement, or empty for
 * a blank cell. [icon] is an emoji (zero bytes: the system font draws it), "app:<package>" for that
 * app's own icon, or empty to show the label instead.
 */
data class StripItem(
    val label: String, val icon: String, val action: String,
    /** Seconds the shortcut stays on screen after it ran; null follows the strip's own setting, 0 is off. */
    val stay: Int? = null,
    /** Toast after running: null follows the strip's setting, 0 off, 1 short, 2 long. */
    val toast: Int? = null,
    /** Seconds a notification about the run stays; null follows the strip's setting, 0 is off. */
    val notify: Int? = null,
    /** A folder: the cells that open under the thumb when it rests on this cell (null = a normal cell). */
    val children: List<StripItem>? = null,
    /** Columns of the folder's own window. */
    val cols: Int = 3,
    /** Runs the moment the thumb is on this cell, without waiting for a release. */
    val touch: Boolean = false,
    /** Pinned: the cell keeps its own slot ([pinSlot], counted from 0) when cells are added or removed. */
    val pinned: Boolean = false,
    val pinSlot: Int = 0,
    /** The pinned cell sat in the bottom row: it can follow the bottom row down when a row is added, in column [pinCol]. */
    val pinBottom: Boolean = false,
    val pinCol: Int = 0,
) {
    val isFolder: Boolean get() = children != null

    /**
     * The app whose icon the strip draws: the one chosen, or, when no icon was chosen, the app the
     * action belongs to (an app shortcut's target, a launched app, Automate for a flow).
     */
    val appIconPackage: String? get() = when {
        icon.startsWith("app:") -> icon.substring(4).takeIf { it.isNotBlank() }
        icon.isEmpty() -> derivedPackage(action)
        else -> null
    }

    /** Name of a picture kept in this app's own storage (a shortcut's own icon), or null. */
    val iconFile: String? get() = icon.takeIf { it.startsWith("img:") }?.substring(4)

    private companion object {
        val derived = HashMap<String, String>()

        fun derivedPackage(action: String): String? {
            if (action.isEmpty()) return null
            derived[action]?.let { return it.takeIf { p -> p.isNotEmpty() } }
            val pkg = when {
                action.startsWith("Launch app:") -> action.removePrefix("Launch app:")
                action.startsWith("Flow:") -> "com.llamalab.automate"
                action.startsWith("Intent:") -> runCatching {
                    val i = AppStarter.parse(action)
                    i.component?.packageName ?: i.`package` ?: ""
                }.getOrDefault("")
                else -> ""
            }
            derived[action] = pkg
            return pkg.takeIf { it.isNotEmpty() }
        }
    }
}

/** The strip's whole configuration, kept as one small JSON string in the preferences. */
data class StripConfig(
    val columns: Int = 8,
    /** Cell size as a percentage of the largest size that still fits the screen. */
    val sizePct: Int = 88,
    val showLabels: Boolean = true,
    /** Centered on the screen instead of on the bar's side. */
    val centered: Boolean = false,
    val bottomDp: Int = 40,
    /** Seconds the shortcut that ran stays visible (0 = hide at once). */
    val stay: Int = 1,
    /** Toast after a run: 0 off, 1 short, 2 long. */
    val toast: Int = 0,
    /** Seconds a notification about the run stays; 0 is off. */
    val notify: Int = 0,
    val items: List<StripItem> = defaultItems(),
) {
    fun toJson(): String {
        val arr = JSONArray()
        for (it in items) arr.put(itemJson(it))
        return JSONObject()
            .put("c", columns).put("s", sizePct).put("t", showLabels)
            .put("m", centered).put("b", bottomDp).put("y", stay).put("o", toast).put("n", notify).put("items", arr)
            .toString()
    }

    companion object {
        const val FLOW_PREFIX = "Flow:"

        /** An outside-of-window action that runs the moment the thumb is over its side is saved with this in front. */
        const val TOUCH_PREFIX = "@touch:"
        fun isTouch(action: String) = action.startsWith(TOUCH_PREFIX)
        fun bare(action: String) = action.removePrefix(TOUCH_PREFIX)
        fun withTouch(action: String, on: Boolean) = if (action.isEmpty()) action else if (on) TOUCH_PREFIX + bare(action) else bare(action)

        private fun itemJson(it: StripItem): JSONObject {
            val o = JSONObject().put("l", it.label).put("i", it.icon).put("a", it.action)
            it.stay?.let { v -> o.put("y", v) }
            it.toast?.let { v -> o.put("o", v) }
            it.notify?.let { v -> o.put("n", v) }
            if (it.touch) o.put("tc", true)
            if (it.pinned) o.put("pn", it.pinSlot)
            if (it.pinned && it.pinBottom) o.put("pb", it.pinCol)
            it.children?.let { kids ->
                val a = JSONArray(); for (k in kids) a.put(itemJson(k))
                o.put("k", a).put("fc", it.cols)
            }
            return o
        }

        private fun itemFrom(e: JSONObject): StripItem = StripItem(
            e.optString("l"), e.optString("i"), e.optString("a"),
            if (e.has("y")) e.optInt("y") else null,
            if (e.has("o")) e.optInt("o") else null,
            if (e.has("n")) e.optInt("n") else null,
            if (e.has("k")) e.getJSONArray("k").let { a -> (0 until a.length()).map { n -> itemFrom(a.getJSONObject(n)) } } else null,
            e.optInt("fc", 3).coerceIn(1, 8),
            e.optBoolean("tc", false),
            e.has("pn"), e.optInt("pn", 0).coerceAtLeast(0),
            e.has("pb"), e.optInt("pb", 0).coerceAtLeast(0),
        )

        /** Pinned cells in the bottom row that follow it down when a row is added: all of them, only folders, or none. */
        const val PIN_ALL = 0
        const val PIN_FOLDERS = 1
        const val PIN_NONE = 2

        private fun isBlank(c: StripItem) = c.action.isEmpty() && c.label.isEmpty() && c.icon.isEmpty() && c.children == null

        /**
         * Puts every pinned cell of [list] in its own place in a grid of [columns] columns. A pinned cell that
         * sat in the bottom row and may follow it ([follow]) stays in the last row, same column; the grid grows a
         * row when the cells need one, and the gaps in front of such a pin become blank cells. Any other pinned
         * cell keeps the slot it was pinned at. The other cells fill the free slots in their order. The pins'
         * stored place is updated to where they ended up. Folders inside are settled with their own columns.
         * Cells that need no change are returned as they are.
         */
        fun settlePins(
            list: List<StripItem>, columns: Int, follow: Int = PIN_ALL,
            keepPath: List<Int>? = null, keep: Int = 0,
        ): List<StripItem> {
            val c = columns.coerceAtLeast(1)
            val keepHere = if (keepPath != null && keepPath.isEmpty()) keep else 0
            val kids = list.mapIndexed { idx, it0 ->
                val ch = it0.children
                if (ch == null) it0 else {
                    val sub = if (keepPath != null && keepPath.isNotEmpty() && keepPath[0] == idx) keepPath.drop(1) else null
                    val s = settlePins(ch, it0.cols, follow, sub, keep)
                    if (s.size == ch.size && s.indices.all { k -> s[k] === ch[k] }) it0 else it0.copy(children = s)
                }
            }
            if (kids.none { it.pinned }) return kids
            val pins = kids.withIndex().filter { it.value.pinned }
            // Pins that follow the bottom row: the last row, their own column (the next free one when taken).
            val following = pins.filter { p ->
                p.value.pinBottom && (follow == PIN_ALL || (follow == PIN_FOLDERS && p.value.isFolder))
            }.sortedWith(compareBy({ it.value.pinCol }, { it.index })).take(c)
            var rest = kids.filter { !it.pinned }
            // Blank cells at the very end are only padding for such a pin: they are made again below when needed,
            // so deleting what sat in front of it lets the extra row go.
            // (The last [keepHere] cells are a blank cell just added on purpose: it stays.)
            if (following.isNotEmpty()) {
                val tail = if (keepHere > 0) rest.takeLast(keepHere) else emptyList()
                var e = rest.size - tail.size
                while (e > 0 && isBlank(rest[e - 1])) e--
                rest = rest.subList(0, e) + tail
            }
            val n = rest.size + pins.size
            val rows = (n + c - 1) / c
            val len0 = rows * c
            val slots = arrayOfNulls<StripItem>(len0)
            val base = (rows - 1) * c
            val placed = ArrayList<Pair<Int, StripItem>>()
            for (p in following) {
                var d = base + p.value.pinCol.coerceAtMost(c - 1)
                while (d < len0 && slots[d] != null) d++
                if (d >= len0) { d = base + p.value.pinCol.coerceAtMost(c - 1); while (d >= base && slots[d] != null) d-- }
                if (d in base until len0) { slots[d] = p.value; placed += d to p.value }
            }
            // The other pins keep their slot (the next free one down, else up, when it is taken).
            val placedRefs = placed.map { it.second }
            val others = pins.filter { p -> placedRefs.none { it === p.value } }
                .sortedWith(compareBy({ it.value.pinSlot }, { it.index }))
            for (p in others) {
                val slot = p.value.pinSlot.coerceIn(0, n - 1)
                var d = slot
                while (d < len0 && slots[d] != null) d++
                if (d >= len0) { d = slot; while (d >= 0 && slots[d] != null) d-- }
                if (d in 0 until len0) { slots[d] = p.value; placed += d to p.value }
            }
            val it2 = rest.iterator()
            for (k in 0 until len0) if (slots[k] == null && it2.hasNext()) slots[k] = it2.next()
            var last = -1
            for (k in 0 until len0) if (slots[k] != null) last = k
            val len = last + 1
            val bottomRow = (len - 1) / c
            val out = ArrayList<StripItem>(len)
            val pinAt = HashMap<Int, StripItem>()
            for ((d, p) in placed) pinAt[d] = p
            for (k in 0 until len) {
                val cell = slots[k]
                if (cell == null) { out += StripItem("", "", ""); continue }
                if (pinAt[k] === cell) {
                    val nb = k / c == bottomRow
                    out += if (cell.pinSlot == k && cell.pinBottom == nb && cell.pinCol == k % c) cell
                    else cell.copy(pinSlot = k, pinBottom = nb, pinCol = k % c)
                } else out += cell
            }
            return out
        }

        /** The first blank cell (not pinned) a new cell or folder can take, or -1. */
        fun firstBlank(list: List<StripItem>): Int = list.indexOfFirst { !it.pinned && isBlank(it) }

        /**
         * A new cell takes the first blank cell. With none it goes at the end, and settlePins gives it a row of
         * its own above the pinned bottom row. Returns the list and how many trailing cells settlePins must keep
         * (1 for a blank new cell, which would otherwise be trimmed as padding).
         */
        fun withNewCell(list: List<StripItem>, fresh: StripItem): Pair<List<StripItem>, Int> {
            val at = firstBlank(list)
            if (at >= 0) return list.toMutableList().also { it[at] = fresh } to 0
            return (list + fresh) to (if (isBlank(fresh)) 1 else 0)
        }

        /** A pinned cell that was moved on purpose now wants the slot it is in (and the bottom row, if it is there). */
        fun anchorPin(l: MutableList<StripItem>, at: Int, columns: Int) {
            val it = l.getOrNull(at) ?: return
            if (!it.pinned) return
            val c = columns.coerceAtLeast(1)
            l[at] = it.copy(pinSlot = at, pinCol = at % c, pinBottom = at / c == (l.size - 1) / c)
        }

        /**
         * Deletes the cells [ids]. A deleted cell with a pinned cell after it leaves a blank cell in its place, so
         * nothing shifts and the pin really stays; with no pin after it the cell is just removed. A blank cell is
         * always just removed.
         */
        fun deleteCells(list: List<StripItem>, ids: Set<Int>): List<StripItem> {
            val lastPin = list.indices.lastOrNull { it !in ids && list[it].pinned } ?: -1
            val out = ArrayList<StripItem>(list.size)
            for (i in list.indices) {
                if (i !in ids) out += list[i]
                else if (i < lastPin && !isBlank(list[i])) out += StripItem("", "", "")
            }
            return out
        }

        fun flowAction(flow: Int, statement: Int) = "$FLOW_PREFIX$flow/$statement"

        /** The Automate content URI for a "Flow:f/s" action, or null for any other action. */
        fun flowUri(action: String): String? {
            if (!action.startsWith(FLOW_PREFIX)) return null
            val parts = action.removePrefix(FLOW_PREFIX).split("/")
            val f = parts.getOrNull(0)?.toIntOrNull() ?: return null
            val s = parts.getOrNull(1)?.toIntOrNull() ?: return null
            return "content://com.llamalab.automate.provider/flows/$f/statements/$s"
        }

        /** Pulls the two numbers out of a pasted Automate URI (or "468/233"), or null. */
        fun parseFlow(text: String): String? {
            val m = Regex("""flows/(\d+)/statements/(\d+)""").find(text)
                ?: Regex("""^\s*(\d+)\s*[/ ,]\s*(\d+)\s*$""").find(text)
                ?: return null
            return flowAction(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }

        /**
         * The saved configuration, or, when nothing is saved, the one baked into the app as
         * assets/strip_default.json (this is how an APK carries its author's edited strip to
         * another phone), or else the built-in Easy Slider list.
         */
        fun load(context: android.content.Context, json: String?): StripConfig {
            if (!json.isNullOrBlank()) return fromJson(json)
            val baked = runCatching {
                context.assets.open("strip_default.json").bufferedReader().use { it.readText() }
            }.getOrNull()
            return if (baked.isNullOrBlank()) StripConfig() else fromJson(baked)
        }

        fun fromJson(json: String?): StripConfig {
            if (json.isNullOrBlank()) return StripConfig()
            return runCatching {
                val o = JSONObject(json)
                val arr = o.getJSONArray("items")
                val list = ArrayList<StripItem>(arr.length())
                for (n in 0 until arr.length()) {
                    list += itemFrom(arr.getJSONObject(n))
                }
                StripConfig(
                    columns = o.optInt("c", 8).coerceIn(1, 16),
                    sizePct = o.optInt("s", 88).coerceIn(30, 100),
                    showLabels = o.optBoolean("t", true),
                    centered = o.optBoolean("m", false),
                    bottomDp = o.optInt("b", 40).coerceIn(0, 400),
                    stay = o.optInt("y", 1).coerceIn(0, 60),
                    toast = o.optInt("o", 0).coerceIn(0, 2),
                    notify = o.optInt("n", 0).coerceIn(0, 120),
                    items = list,
                )
            }.getOrDefault(StripConfig())
        }

        /** Easy Slider's strip, as editable items. */
        fun defaultItems(): List<StripItem> = ShortcutStore.legacy.map { old ->
            val action = when {
                old.flow > 0 -> flowAction(old.flow, old.statement)
                old.pkg != null -> HandlerActions.launchApp(old.pkg)
                else -> ""
            }
            val icon = old.pkg?.let { "app:$it" } ?: DEFAULT_EMOJI[old.label].orEmpty()
            StripItem(old.label, icon, action)
        }

        // A first guess for some labels; every one can be changed in the editor.
        private val DEFAULT_EMOJI = mapOf(
            "QShr" to "📤", "GRNT" to "✅", "RVOK" to "🚫", "Torch" to "🔦", "Airpl" to "✈️",
            "BT" to "🔵", "Loc" to "📍", "Hotsp" to "📶", "WifiOn" to "📶", "Wifi" to "📡",
            "Brgt" to "🔆", "Awake" to "☕", "ScrSh" to "📸", "PSTE" to "📋", "CopyM" to "📄",
            "Speed" to "⚡", "AppInf" to "ℹ️", "UPLD" to "⬆️", "GUPLD" to "☁️", "MaxVol" to "🔊",
            "TMP" to "🌡️", "DSave" to "🔋", "LOGKL" to "📜", "QR" to "🔳", "Power" to "⏻",
            "V2Ray" to "🚀", "V2Win" to "🚀", "WFV2R" to "🚀", "HSSt" to "🛡️", "DbgOff" to "🐞",
            "HdDev" to "🙈", "ShwDV" to "👁️", "123" to "🔢", "SOD" to "🌙",
        )
    }
}
