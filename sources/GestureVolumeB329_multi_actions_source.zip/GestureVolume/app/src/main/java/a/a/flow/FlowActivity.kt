package a.a.flow

import a.a.utils.AppStarter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.strip.ActionSaver
import a.a.auto.AutomationsScreen
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.screens.deck.AppKinds
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.AppShortcutsPage
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.ChipsCardRow
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.ui.screens.strip.plainAppLabel

/** The scripts list and the block editor. Nothing from here stays in memory once it is closed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
class FlowActivity : ComponentActivity() {
    /** Goes up each time this screen comes back, so OCR boxes drawn in the OCR flow show up in the list. */
    private var resumeTick by mutableStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                    var names by remember { mutableStateOf(FlowStore.names(this)) }
                    var open by remember { mutableStateOf<String?>(intent.getStringExtra("flow")?.takeIf { it in names }) }
                    var newName by remember { mutableStateOf(false) }
                    var info by remember { mutableStateOf("") }
                    // Selecting scripts: delete, duplicate, share many at once; rename one.
                    var selected by remember { mutableStateOf(setOf<String>()) }
                    var confirmDel by remember { mutableStateOf(false) }
                    var renameOf by remember { mutableStateOf<String?>(null) }
                    // OCR boxes (made on the screen, kept by name) are listed here beside the scripts.
                    var ocrOnly by remember { mutableStateOf(false) }
                    var ocrDlg by remember { mutableStateOf<String?>(null) }
                    var ocrRename by remember { mutableStateOf<String?>(null) }
                    var boxTick by remember { mutableStateOf(0) }
                    val sharedPicker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            val got = FlowShare.import(this@FlowActivity, uri)
                            names = FlowStore.names(this@FlowActivity)
                            info = if (got == null) "That file does not hold shared scripts." else "Imported ${got.size} script(s): " + got.joinToString(", ")
                        }
                    }
                    var runningNow by remember { mutableStateOf(FlowRunner.running()) }
                    var values by remember { mutableStateOf(false) }
                    var autos by remember { mutableStateOf(false) }
                    // "Add a shortcut": 0 closed, 1 menu, 2 open an app with Hail, 3 app shortcuts / Shortcut Maker.
                    var addSc by remember { mutableStateOf(0) }
                    val scCreator = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
                    ) { result ->
                        val data = result.data
                        @Suppress("DEPRECATION")
                        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
                        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
                            val nm = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME) ?: "Shortcut"
                            ActionSaver.saveToScripts(this@FlowActivity, nm, "Intent:" + AppStarter.save(picked))
                            names = FlowStore.names(this@FlowActivity); info = "Saved script: $nm"; addSc = 0
                        }
                    }
                    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            info = "Importing…"
                            Thread {
                                info = try {
                                    val n = AutomateImporter.import(this@FlowActivity, uri)
                                    names = FlowStore.names(this@FlowActivity)
                                    "Imported $n scripts. Texts that are not commands are kept as Notes."
                                } catch (e: Throwable) { "Import failed: ${e.message}" }
                            }.start()
                        }
                    }
                    if (autos) {
                        AutomationsScreen { autos = false }
                    } else if (values) {
                        ValuesScreen { values = false }
                    } else if (open == null) {
                        AWindowPage("Scripts", onBack = { finish() }) { pad ->
                            var query by remember { mutableStateOf("") }
                            var showParts by remember { mutableStateOf(false) }
                            var optionsOpen by remember { mutableStateOf(false) }
                            var selectMode by remember { mutableStateOf(false) }
                            var barMode by remember { mutableStateOf(FlowPrefs.mode(this@FlowActivity)) }
                            val uiPrefs = remember { this@FlowActivity.getSharedPreferences("FlowUi", android.content.Context.MODE_PRIVATE) }
                            var searchTop by remember { mutableStateOf(uiPrefs.getBoolean("searchTop", true)) }
                            // Which scripts run right now: asked once a second, only while this window is open.
                            androidx.compose.runtime.LaunchedEffect(Unit) {
                                while (true) { runningNow = FlowRunner.running(); kotlinx.coroutines.delay(1000) }
                            }
                            val shown = if (ocrOnly) emptyList() else
                                names.filter { (showParts || !AutomateFlows.isPart(it)) && (query.isBlank() || it.contains(query, true)) }
                                    .sortedByDescending { n -> runningNow.any { it.name == n } }
                            val boxes = remember(boxTick, resumeTick, query) {
                                a.a.strip.ScreenOcr.boxNames(this@FlowActivity).filter { query.isBlank() || it.contains(query, true) || "ocr".contains(query, true) }
                            }
                            val selecting = selectMode || selected.isNotEmpty()
                            val searchBox: @Composable () -> Unit = {
                                OutlinedTextField(
                                    query, { query = it }, singleLine = true, label = { Text("Search scripts") },
                                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                                )
                            }
                            Column(Modifier.fillMaxSize().padding(pad)) {
                                if (searchTop) Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 6.dp)) { searchBox() }
                                LazyColumn(
                                    Modifier.fillMaxWidth().weight(1f),
                                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                                    verticalArrangement = Arrangement.spacedBy(3.dp),
                                ) {
                                    item {
                                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            ChoiceChip("Options", optionsOpen, { optionsOpen = !optionsOpen })
                                            ChoiceChip("Select", selectMode, { selectMode = !selectMode; if (!selectMode) selected = emptySet() })
                                        }
                                    }
                                    if (info.isNotEmpty()) item {
                                        Box(
                                            Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer).padding(12.dp),
                                        ) { Text(info, fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                                    }
                                    if (runningNow.isNotEmpty()) item {
                                        CardGroup("Running now") {
                                            row { sh ->
                                                SettingRow(
                                                    "Stop all running scripts (${runningNow.size})", sh, icon = Icons.Filled.Close, lit = true,
                                                    summary = "Ends every script that is running",
                                                    onClick = { FlowRunner.stopAllRuns(); runningNow = FlowRunner.running(); info = "Stopping all running scripts…" },
                                                )
                                            }
                                        }
                                    }
                                    if (optionsOpen) item {
                                        Column {
                                            CardGroup("Add") {
                                                row { sh ->
                                                    SettingRow(
                                                        "New script", sh, icon = Icons.Filled.Add,
                                                        summary = "Start an empty script and fill it with blocks",
                                                        onClick = { newName = true },
                                                    )
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "Add a shortcut as a script", sh, icon = Icons.Filled.Apps,
                                                        summary = "An app, one of its shortcuts or a Shortcut Maker button",
                                                        onClick = { addSc = 1 },
                                                    )
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "Add example scripts", sh, icon = Icons.Filled.Star,
                                                        summary = "Ready-made scripts named Example: … to open and learn from",
                                                        onClick = {
                                                            val n = SeedFlows.installExamples(this@FlowActivity)
                                                            names = FlowStore.names(this@FlowActivity)
                                                            info = if (n > 0) "Added $n example script(s): Example: …  Open one to edit its blocks." else "The example scripts are already here."
                                                        },
                                                    )
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "Add my Automate flows", sh, icon = Icons.Filled.Download,
                                                        summary = "Converted copies named Automate: …",
                                                        onClick = {
                                                            info = "Adding…"
                                                            Thread {
                                                                info = try {
                                                                    val n = AutomateFlows.install(this@FlowActivity)
                                                                    names = FlowStore.names(this@FlowActivity)
                                                                    "Added $n converted Automate flows (named Automate: …). Numbers and codes are left as {blanks} in the steps."
                                                                } catch (e: Throwable) { "Could not add: ${e.message}" }
                                                            }.start()
                                                        },
                                                    )
                                                }
                                            }
                                            CardGroup("Bring in") {
                                                row { sh ->
                                                    SettingRow(
                                                        "Import an Automate backup", sh, icon = Icons.Filled.Download,
                                                        summary = "Choose a backup file made by Automate",
                                                        onClick = { picker.launch(arrayOf("*/*")) },
                                                    )
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "Import shared scripts", sh, icon = Icons.Filled.Download,
                                                        summary = "Choose a file that someone shared from A",
                                                        onClick = { sharedPicker.launch(arrayOf("*/*")) },
                                                    )
                                                }
                                            }
                                            CardGroup("When and how they run") {
                                                row { sh ->
                                                    ChipsCardRow(
                                                        "Message bar after a cell", (0..2).map { FlowPrefs.modeName(it) to (it == barMode) }, sh,
                                                        onToggle = {
                                                            barMode = it
                                                            FlowPrefs.setMode(this@FlowActivity, it)
                                                            info = "Message bar after a cell: " + FlowPrefs.modeName(it)
                                                        },
                                                        icon = Icons.Filled.Info,
                                                        summary = "What the bar shows when a cell has run a script",
                                                    )
                                                }
                                                row { sh ->
                                                    LinkRow("Automations", "When something happens, run one of your scripts", sh, Icons.Filled.Notifications) { autos = true }
                                                }
                                                row { sh ->
                                                    LinkRow("My values", "Keys, codes and names that scripts use as {name}", sh, Icons.Filled.Lock) { values = true }
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "Allow usage access", sh, icon = Icons.Filled.Check,
                                                        summary = "Opens Android's setting that lets A see which app is open",
                                                        onClick = {
                                                            runCatching { startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                                                        },
                                                    )
                                                }
                                            }
                                            CardGroup("This window") {
                                                row { sh ->
                                                    SwitchRow(
                                                        "Search bar at the top", searchTop, sh, icon = Icons.Filled.Search,
                                                        summary = "Off puts it under these options",
                                                    ) { searchTop = it; uiPrefs.edit().putBoolean("searchTop", it).apply() }
                                                }
                                                row { sh ->
                                                    SwitchRow(
                                                        "Show script parts", showParts, sh, icon = Icons.Filled.Visibility,
                                                        summary = "Scripts named “… - part …” are hidden until this is on",
                                                    ) { showParts = it }
                                                }
                                                row { sh ->
                                                    SwitchRow(
                                                        "Show OCR boxes only", ocrOnly, sh, icon = Icons.Filled.Visibility,
                                                        summary = "Hides the scripts and lists only the OCR boxes",
                                                    ) { ocrOnly = it }
                                                }
                                                row { sh ->
                                                    SettingRow(
                                                        "New OCR box", sh, icon = Icons.Filled.Add,
                                                        summary = "Draw a part of the screen for OCR to read",
                                                        onClick = {
                                                            startActivity(android.content.Intent(this@FlowActivity, a.a.strip.OcrActivity::class.java).putExtra("boxnew", true))
                                                        },
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    if (!searchTop) item { Box(Modifier.padding(top = 10.dp)) { searchBox() } }
                                    // What can be done with the ticked scripts.
                                    if (selecting) item {
                                        val none = selected.isEmpty()
                                        CardGroup("${selected.size} selected") {
                                            row { sh -> SettingRow("Select all", sh, compact = true, icon = Icons.Filled.Checklist, onClick = { selected = shown.toSet() }) }
                                            row { sh -> SettingRow("Select none", sh, compact = true, icon = Icons.Filled.Close, onClick = { selected = emptySet() }) }
                                            row { sh ->
                                                SettingRow(
                                                    "Duplicate", sh, Modifier.alpha(if (none) 0.45f else 1f), icon = Icons.Filled.ContentCopy, compact = true,
                                                    onClick = {
                                                        if (selected.isNotEmpty()) {
                                                            var n = 0
                                                            selected.forEach { if (FlowStore.duplicate(this@FlowActivity, it) != null) n++ }
                                                            names = FlowStore.names(this@FlowActivity); selected = emptySet(); info = "Duplicated $n script(s)."
                                                        }
                                                    },
                                                )
                                            }
                                            row { sh ->
                                                SettingRow(
                                                    "Share", sh, Modifier.alpha(if (none) 0.45f else 1f), icon = Icons.Filled.Share, compact = true,
                                                    onClick = { if (selected.isNotEmpty()) FlowShare.share(this@FlowActivity, selected.toList()) },
                                                )
                                            }
                                            if (selected.size == 1) row { sh ->
                                                SettingRow("Rename", sh, compact = true, icon = Icons.Filled.Edit, onClick = { renameOf = selected.first() })
                                            }
                                            row { sh ->
                                                SettingRow(
                                                    "Delete", sh, Modifier.alpha(if (none) 0.45f else 1f), icon = Icons.Filled.Delete, compact = true,
                                                    onClick = { if (selected.isNotEmpty()) confirmDel = true },
                                                )
                                            }
                                        }
                                    }
                                    if (boxes.isNotEmpty()) item {
                                        GroupHeading(
                                            "OCR boxes (${boxes.size})",
                                            modifier = Modifier.padding(top = 14.dp),
                                            hint = "Parts of the screen that OCR reads by name",
                                        )
                                    }
                                    itemsIndexed(boxes) { i, bn ->
                                        SettingRow(
                                            bn, cardShape(i, boxes.size), icon = Icons.Filled.Visibility,
                                            summary = "OCR box", onClick = { ocrDlg = bn },
                                        )
                                    }
                                    item {
                                        GroupHeading(
                                            "Your scripts (${shown.size})",
                                            modifier = Modifier.padding(top = 14.dp),
                                            hint = if (selecting) "Tap scripts to tick them" else "Tap one to open it. Hold one, or use Select, to choose several.",
                                        )
                                    }
                                    if (shown.isEmpty() && !ocrOnly) item {
                                        Text(
                                            if (names.isEmpty()) "No scripts yet. Open Options to make one." else "No script matches the search.",
                                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(horizontal = 6.dp),
                                        )
                                    }
                                    itemsIndexed(shown) { i, n ->
                                        val on = n in selected
                                        val runs = runningNow.filter { it.name == n }
                                        val sh = cardShape(i, shown.size)
                                        SettingRow(
                                            n, sh,
                                            Modifier.clip(sh).combinedClickable(
                                                onClick = { if (selecting) selected = if (on) selected - n else selected + n else open = n },
                                                onLongClick = { selected = if (on) selected - n else selected + n },
                                            ),
                                            icon = Icons.Filled.PlayArrow, lit = runs.isNotEmpty(),
                                            summary = if (runs.isNotEmpty()) (if (runs.any { it.alwaysOn }) "Always On, running" else "Running now") else null,
                                            trailing = {
                                                if (selecting) androidx.compose.material3.Checkbox(checked = on, onCheckedChange = { selected = if (on) selected - n else selected + n })
                                                else if (runs.isNotEmpty()) OutlinedButton(onClick = { FlowRunner.stopByName(n); runningNow = FlowRunner.running() }) { Text("Stop") }
                                            },
                                        )
                                    }
                                }
                            }
                        }
                        if (confirmDel) AlertDialog(
                            onDismissRequest = { confirmDel = false },
                            title = { Text("Delete ${selected.size} script(s)?") },
                            text = { Text(selected.sorted().joinToString(", ") + "\n\nCells that run them will do nothing until you pick another script.") },
                            confirmButton = { TextButton(onClick = {
                                FlowStore.deleteMany(this@FlowActivity, selected)
                                names = FlowStore.names(this@FlowActivity); info = "Deleted ${selected.size} script(s)."; selected = emptySet(); confirmDel = false
                            }) { Text("Delete") } },
                            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Cancel") } },
                        )
                        renameOf?.let { old ->
                            var t by remember(old) { mutableStateOf(old) }
                            AlertDialog(
                                onDismissRequest = { renameOf = null },
                                title = { Text("Rename script") },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(16.dp))
                                        Text("Cells and scripts that run it keep working.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                confirmButton = { TextButton(onClick = {
                                    val ok = FlowStore.rename(this@FlowActivity, old, t)
                                    names = FlowStore.names(this@FlowActivity)
                                    info = if (ok) "Renamed to ${t.trim()}." else "Not renamed: the name is empty or already used."
                                    if (ok) selected = emptySet()
                                    renameOf = null
                                }) { Text("OK") } },
                                dismissButton = { TextButton(onClick = { renameOf = null }) { Text("Cancel") } },
                            )
                        }
                        ocrDlg?.let { bn ->
                            AlertDialog(
                                onDismissRequest = { ocrDlg = null },
                                title = { Text("OCR box: $bn") },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            "A part of the screen that the OCR shortcut and the “Read with OCR and wait” block read by this name.",
                                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                        SettingRow(
                                            "Draw it again on the screen", DIALOG_CARD, compact = true, icon = Icons.Filled.Edit,
                                            onClick = {
                                                startActivity(
                                                    android.content.Intent(this@FlowActivity, a.a.strip.OcrActivity::class.java)
                                                        .putExtra("boxredo", bn)
                                                )
                                                ocrDlg = null
                                            },
                                        )
                                        SettingRow("Rename", DIALOG_CARD, compact = true, icon = Icons.Filled.Edit, onClick = { ocrRename = bn; ocrDlg = null })
                                        SettingRow(
                                            "Delete", DIALOG_CARD, compact = true, icon = Icons.Filled.Delete,
                                            onClick = {
                                                a.a.strip.ScreenOcr.deleteBox(this@FlowActivity, bn)
                                                boxTick++; info = "Deleted OCR box $bn."; ocrDlg = null
                                            },
                                        )
                                    }
                                },
                                confirmButton = { TextButton(onClick = { ocrDlg = null }) { Text("Close") } },
                            )
                        }
                        ocrRename?.let { old ->
                            var t by remember(old) { mutableStateOf(old) }
                            AlertDialog(
                                onDismissRequest = { ocrRename = null },
                                title = { Text("Rename OCR box") },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(16.dp))
                                        Text("Shortcuts and scripts that still say the old name keep finding this box.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                confirmButton = { TextButton(onClick = {
                                    val ok = a.a.strip.ScreenOcr.renameBox(this@FlowActivity, old, t)
                                    boxTick++
                                    info = if (ok) "Renamed to ${t.trim()}." else "Not renamed: the name is empty or already used."
                                    ocrRename = null
                                }) { Text("OK") } },
                                dismissButton = { TextButton(onClick = { ocrRename = null }) { Text("Cancel") } },
                            )
                        }
                        if (addSc != 0) androidx.compose.ui.window.Dialog(
                            onDismissRequest = { addSc = if (addSc == 1) 0 else 1 },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                        ) {
                            Surface(Modifier.fillMaxSize().statusBarsPadding(), color = MaterialTheme.colorScheme.background) {
                                fun saveSc(name: String, action: String) {
                                    ActionSaver.saveToScripts(this@FlowActivity, name, action)
                                    names = FlowStore.names(this@FlowActivity); info = "Saved script: $name"; addSc = 0
                                }
                                when (addSc) {
                                    2 -> AppList(
                                        onPick = { app -> saveSc(plainAppLabel(app.label), ActionSaver.hailAction(app.packageName)) },
                                        onBack = { addSc = 1 },
                                        everything = true,
                                        kindFilter = true,
                                        kindKey = AppKinds.HAIL_PREF_KEY,
                                    )
                                    3 -> AppShortcutsPage(
                                        onCreator = { cr ->
                                            runCatching {
                                                scCreator.launch(
                                                    android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT).setClassName(cr.packageName, cr.className)
                                                )
                                            }
                                        },
                                        onShortcut = { sc -> saveSc(sc.label, "Intent:" + sc.intentUri) },
                                        onBack = { addSc = 1 },
                                    )
                                    else -> Column(Modifier.padding(16.dp)) {
                                        Text("Add a shortcut as a script", fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface)
                                        CardGroup("Where is the shortcut?") {
                                            row { sh ->
                                                LinkRow(
                                                    "Open an app with Hail", "Any app, even a hidden one", sh, Icons.Filled.Apps,
                                                ) { addSc = 2 }
                                            }
                                            row { sh ->
                                                LinkRow(
                                                    "App shortcuts and Shortcut Maker", "A shortcut an app offers, or one you make", sh, Icons.Filled.Star,
                                                ) { addSc = 3 }
                                            }
                                        }
                                        TextButton(onClick = { addSc = 0 }, modifier = Modifier.padding(top = 8.dp)) { Text("Cancel") }
                                    }
                                }
                            }
                        }
                        if (newName) {
                            var t by remember { mutableStateOf("") }
                            AlertDialog(
                                onDismissRequest = { newName = false },
                                title = { Text("New script") },
                                text = { OutlinedTextField(t, { t = it }, singleLine = true, label = { Text("Name") }, shape = RoundedCornerShape(16.dp)) },
                                confirmButton = { TextButton(onClick = {
                                    if (t.isNotBlank()) { val nm = FlowStore.freeName(this, t); FlowStore.save(this, nm, emptyList()); names = FlowStore.names(this); open = nm }
                                    newName = false
                                }) { Text("OK") } },
                                dismissButton = { TextButton(onClick = { newName = false }) { Text("Cancel") } },
                            )
                        }
                    } else {
                        CanvasEditor(this, open!!) { names = FlowStore.names(this); open = null }
                    }
            }
        }
    }

    @Composable
    private fun ValuesScreen(close: () -> Unit) {
        BackHandler(onBack = close)
        AWindowPage("My values", onBack = close) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item {
                    GroupHeading(
                        "Keys, codes and names",
                        hint = "Scripts use them as {name}. They stay only on this phone: they are not in the settings backup and not in copies of the app.",
                    )
                }
                itemsIndexed(PrivateValues.allSlots(this@FlowActivity)) { _, slot ->
                    var v by remember { mutableStateOf(PrivateValues.get(this@FlowActivity, slot.name)) }
                    Box(Modifier.fillMaxWidth().clip(DIALOG_CARD).background(rowColor()).padding(10.dp)) {
                        OutlinedTextField(
                            v, { v = it; PrivateValues.set(this@FlowActivity, slot.name, it) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            label = { Text(slot.label + "   {" + slot.name + "}") },
                            supportingText = { if (slot.hint.isNotEmpty()) Text(slot.hint) },
                        )
                    }
                }
            }
        }
    }
}

/** The shape of a small card inside a dialog or beside other things. */
private val DIALOG_CARD = RoundedCornerShape(16.dp)
