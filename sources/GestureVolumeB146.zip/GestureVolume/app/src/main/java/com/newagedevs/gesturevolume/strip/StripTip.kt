package com.newagedevs.gesturevolume.strip

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/**
 * The little window that floats near the thumb while the cells window is open: either the cell
 * under the thumb, enlarged (same icon, same name), or the name of the action a release outside the
 * window would run. It takes no touches, exists only while the thumb is down, and is one tiny view.
 */
class StripTip(context: Context) : View(context) {
    private var src: StripView? = null
    private var index = -1
    private var tile = 0f
    private var text: String? = null
    private val dp = context.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xF2102A2E.toInt() }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * dp }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 15f * dp; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val box = RectF()

    /** Size the window must have for what it shows now. */
    var wantW = 0
        private set
    var wantH = 0
        private set

    fun showCell(view: StripView, i: Int, sizePx: Int) {
        src = view; index = i; tile = sizePx.toFloat(); text = null
        wantW = sizePx; wantH = sizePx
        invalidate()
    }

    fun showText(t: String) {
        src = null; index = -1; text = t
        wantW = (ink.measureText(t) + 28f * dp).toInt().coerceAtLeast((60 * dp).toInt())
        wantH = (38f * dp).toInt()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(wantW.coerceAtLeast(1), wantH.coerceAtLeast(1))
    }

    override fun onDraw(canvas: Canvas) {
        val t = text
        if (t != null) {
            box.set(edge.strokeWidth, edge.strokeWidth, width - edge.strokeWidth, height - edge.strokeWidth)
            canvas.drawRoundRect(box, height / 2f, height / 2f, bg)
            canvas.drawRoundRect(box, height / 2f, height / 2f, edge)
            canvas.drawText(t, width / 2f, height / 2f - (ink.descent() + ink.ascent()) / 2f, ink)
        } else {
            src?.drawTile(canvas, index, tile)
        }
    }
}
