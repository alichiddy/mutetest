package com.newagedevs.gesturevolume.ui.screens.strip

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.newagedevs.gesturevolume.flow.FlowStore
import com.newagedevs.gesturevolume.ui.components.ActionIconImage
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions

/** A's own windows, offered as one group at the top of the built-in shortcuts. */
val WINDOW_ACTIONS: List<String> = listOf(
    HandlerActions.OPEN_CELLS, HandlerActions.GITHUB_SETTINGS, HandlerActions.OPEN_SEGMENTS, HandlerActions.SHELL_RUNNER,
)

/**
 * The built-in shortcuts list used everywhere an action is chosen (cell editor, segment gestures,
 * the picker other apps see): a search box, "A Windows Shortcuts" first, then the rest, each with its icon.
 */
@Composable
fun BuiltInPage(modifier: Modifier = Modifier, onPick: (HandlerActionCatalog.Entry, String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var windows by remember { mutableStateOf(false) }
    val all = remember {
        HandlerActionCatalog.ALL.filter {
            it.action != HandlerActions.NONE && it.action != HandlerActions.REPOSITION && it.action != HandlerActions.LAUNCH_APP
        }.map { it to context.getString(it.labelRes) }
    }
    val q = query.trim().lowercase()
    val shown = when {
        q.isNotEmpty() -> all.filter { it.second.lowercase().contains(q) }
        windows -> WINDOW_ACTIONS.mapNotNull { a -> all.firstOrNull { it.first.action == a } }
        else -> all.filter { it.first.action !in WINDOW_ACTIONS }
    }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search") }, modifier = Modifier.fillMaxWidth(),
        )
        if (q.isEmpty()) TextButton(onClick = { windows = !windows }) {
            Text(if (windows) "⬅ All built-in shortcuts" else "A Windows Shortcuts  ›")
        }
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { (entry, name) ->
                Row(
                    Modifier.fillMaxWidth().clickable { onPick(entry, name) }.padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ActionIconImage(entry.icon, null, Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(name)
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}

/** My Scripts: the cells that have an action, and the scripts, with a search box. */
@Composable
fun MyScriptsPage(modifier: Modifier = Modifier, onPick: (label: String, action: String, cell: com.newagedevs.gesturevolume.strip.StripItem?) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    class Row2(val label: String, val action: String, val cell: com.newagedevs.gesturevolume.strip.StripItem?)
    val all = remember {
        val prefs = context.getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE)
        val cfg = com.newagedevs.gesturevolume.strip.StripConfig.load(context, prefs.getString(com.newagedevs.gesturevolume.strip.SettingsBackup.STRIP_KEY, null))
        val list = ArrayList<Row2>()
        for (cell in cfg.items) if (cell.action.isNotEmpty()) list += Row2(cell.label.replace('\n', ' ').ifBlank { cell.action.take(24) }, cell.action, cell)
        for (name in FlowStore.names(context)) list += Row2("Script: $name", "MyFlow:$name", null)
        list
    }
    val q = query.trim().lowercase()
    val shown = all.filter { q.isEmpty() || it.label.lowercase().contains(q) }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search") }, modifier = Modifier.fillMaxWidth(),
        )
        LazyColumn(Modifier.weight(1f)) {
            items(shown) { r ->
                Text(
                    r.label, color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth().clickable { onPick(r.label, r.action, r.cell) }.padding(vertical = 12.dp, horizontal = 6.dp),
                )
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
