package com.newagedevs.gesturevolume.ui.screens.strip

/**
 * The picker's emoji (tools, devices, symbols, animals, food, transport, flags, faces and hands) with the words they are found
 * by. Drawn by the system font, so they take no storage of their own. Only the ones this phone's
 * font can draw are shown.
 */
private const val RAW = """
⏻|power on off button
⭘|power off circle ring
⏼|power sleep
⏽|power on
⭕|circle ring off red
🔌|plug electric power cable charge
🔋|battery full charge power
🪫|battery low empty
⚡|lightning bolt electric power fast
🔦|flashlight torch light
💡|bulb idea light lamp
🔆|bright brightness high sun
🔅|dim brightness low
☀️|sun day light
🌙|moon night dark sleep
⭐|star favorite
✨|sparkle clean new
🔥|fire hot burn
💧|drop water wet
❄️|snow cold freeze ice
🌡️|thermometer temperature
📶|signal bars network cellular wifi
📡|antenna satellite signal dish
🛜|wifi wireless network
📍|pin location place map
🧭|compass direction qibla
🗺️|map world route
✈️|airplane flight mode plane airport
🚗|car drive
🚀|rocket launch boost fast
🛡️|shield security protect vpn
🔒|lock locked secure
🔓|unlock unlocked open
🔐|lock key secure
🔑|key password
🗝️|old key
🚫|prohibited forbidden block no
⛔|no entry stop block
🛑|stop sign octagon
✅|check done ok yes
❌|cross no cancel close x
✔️|check mark ok
✖️|multiply close x
❗|exclamation alert important
❓|question help
ℹ️|info information
⚠️|warning caution
🔔|bell notification ring
🔕|bell off silent mute notification
🔊|speaker loud volume high sound
🔉|speaker medium volume
🔈|speaker low volume
🔇|mute silent speaker off
📢|loudspeaker announce boost
📣|megaphone cheer boost
🎵|music note song
🎶|music notes song
🎤|microphone mic voice record
🎧|headphones earphones audio
📻|radio
📺|tv television
🎬|clapper movie film
🎮|game controller play
🕹️|joystick game
📷|camera photo
📸|camera flash photo screenshot
📹|video camera record
🎥|movie camera film
🖼️|picture frame image
🔍|search magnifier find zoom
🔎|search magnifier right find
🔬|microscope science
🔭|telescope
🧪|test tube lab
🧰|toolbox tools
🔧|wrench tool fix settings
🔨|hammer tool build
🪛|screwdriver tool
🪚|saw tool
⚙️|gear settings cog options
🛠️|tools hammer wrench settings build
⛏️|pick tool
🧲|magnet
🧮|abacus calculator math
🔢|numbers digits
🔤|abc letters text
🔠|capital letters text
🔡|small letters text
📝|memo note write edit
✏️|pencil edit write
🖊️|pen write
🖋️|fountain pen write
📋|clipboard paste copy list
📄|page document file
📃|page curl document
📑|pages bookmark tabs
📁|folder files
📂|open folder files
🗂️|dividers folders index
🗃️|card file box archive
🗑️|trash bin delete rubbish
📥|inbox download receive
📤|outbox upload send
📦|package box parcel
📬|mailbox mail
✉️|envelope mail message
📧|email mail
💬|speech chat message sms
🗨️|speech bubble chat
📞|phone call receiver
☎️|telephone call
📱|mobile phone smartphone
💻|laptop computer
🖥️|desktop computer screen monitor
⌨️|keyboard type
🖱️|mouse computer click
🖨️|printer print
💾|floppy save disk
💿|cd disc
📀|dvd disc
☁️|cloud online drive
⬆️|up arrow
⬇️|down arrow
⬅️|left arrow back
➡️|right arrow next
↩️|return back undo
↪️|forward redo
🔄|refresh reload sync arrows
🔃|refresh clockwise sync
🔁|repeat loop
🔂|repeat once
🔀|shuffle random mix
▶️|play start
⏸️|pause
⏹️|stop
⏯️|play pause
⏺️|record
⏭️|next track skip
⏮️|previous track
⏩|fast forward
⏪|rewind
⏏️|eject
🔼|up
🔽|down
➕|plus add
➖|minus remove
➗|divide
💲|dollar money price
💰|money bag
💵|cash dollar
🏦|bank
💳|credit card pay
🧾|receipt bill
🪙|coin toss
🕐|clock time one
⏰|alarm clock wake
⏱️|stopwatch timer
⏲️|timer clock
⌛|hourglass wait time
⏳|hourglass flowing wait
📅|calendar date
📆|calendar tear date
🗓️|calendar spiral date
🏠|home house
🏢|office building
🏪|shop store
🛒|cart shopping
🛍️|shopping bags
🎁|gift present
🎯|target aim dart
🎲|dice game random
🃏|joker card game
🧩|puzzle piece
♟️|chess pawn
🎨|palette art colors theme
🖌️|paintbrush paint
📚|books library read
📖|book open read quran
🎓|graduation study
🌍|earth globe world europe
🌎|earth americas world
🌏|earth asia world
🌐|globe internet web network
🌈|rainbow
☔|rain umbrella weather
⛅|cloud sun weather
🌊|wave sea water
🔴|red circle record
🟠|orange circle
🟡|yellow circle
🟢|green circle on
🔵|blue circle
🟣|purple circle
⚫|black circle
⚪|white circle
🔘|radio button toggle switch
🟥|red square
🟧|orange square
🟨|yellow square
🟩|green square
🟦|blue square
🟪|purple square
⬛|black square
⬜|white square
🔳|qr code square scan
🔲|black square button
♻️|recycle
🆘|sos help emergency
🆗|ok
🆒|cool
🆕|new
🔛|on arrow
🔙|back arrow
🔝|top arrow
🔚|end arrow
🔜|soon arrow
🔰|beginner
☑️|checked box
🏁|finish flag race
🚩|flag red
🏳️|white flag
📌|pushpin pin
📎|paperclip attach
🖇️|linked paperclips attach
🔗|link chain url
⛓️|chains link
🧷|safety pin
🪄|magic wand
🔮|crystal ball
🎭|masks theater
🧿|nazar amulet
🕌|mosque prayer islam
🕋|kaaba mecca qibla
📿|prayer beads tasbih
🕯️|candle light
🪔|lamp diya
🔏|lock pen sign
🧯|extinguisher fire
🪜|ladder
🧱|brick wall firewall
⛽|fuel pump gas
🚦|traffic light
🚥|traffic light horizontal
🔱|trident
⚓|anchor
🪝|hook
🧵|thread
🧶|yarn
📐|ruler triangle measure
📏|ruler straight measure
✂️|scissors cut
📊|chart bar stats
📈|chart up growth
📉|chart down
🧬|dna
⚖️|scale balance law
🔖|bookmark save
🏷️|label tag
💎|gem diamond
🎙️|studio microphone podcast
🎚️|slider level volume
🎛️|control knobs mixer
📲|phone arrow receive call
📳|vibration mode
📴|mobile phone off
🪟|window
🚪|door
🪑|chair
🛏️|bed sleep
🛋️|couch
🚿|shower
🧹|broom clean sweep
🧼|soap clean
🧽|sponge clean
🪥|toothbrush
🖲️|trackball
🕰️|mantelpiece clock
📟|pager
📠|fax
🛰️|satellite gps
🛸|saucer ufo
🪐|planet
☄️|comet
🌠|shooting star
🌀|cyclone swirl
💤|zzz sleep
💢|anger
💥|collision boom
💫|dizzy
🐶|dog puppy pet animal
🐱|cat kitten pet animal
🐭|mouse animal
🐰|rabbit bunny animal
🦊|fox animal
🐻|bear animal
🐼|panda animal
🐨|koala animal
🐯|tiger animal
🦁|lion animal king
🐮|cow animal
🐷|pig animal
🐸|frog animal
🐵|monkey animal
🐔|chicken animal
🐧|penguin animal bird
🐦|bird animal
🦅|eagle bird animal
🦉|owl bird night wise
🦋|butterfly insect
🐝|bee honey insect
🐞|ladybug beetle bug insect
🐛|bug caterpillar insect
🐜|ant insect
🕷️|spider web
🐢|turtle slow animal
🐍|snake animal
🦎|lizard animal
🐙|octopus sea animal
🦑|squid sea animal
🐠|fish tropical sea animal
🐟|fish sea animal
🐬|dolphin sea animal
🐳|whale sea animal
🦈|shark sea animal
🐊|crocodile animal
🐘|elephant animal
🦒|giraffe animal
🐪|camel animal
🐎|horse animal
🐑|sheep animal
🐐|goat animal
🦌|deer animal
🐕|dog animal
🐈|cat animal
🐾|paw prints animal
🌳|tree nature green
🌲|evergreen tree pine nature
🌴|palm tree beach nature
🌵|cactus desert plant
🌱|seedling plant grow green
🌿|herb leaf plant green
🍀|clover luck green
🍁|maple leaf autumn
🍂|fallen leaf autumn
🌸|blossom flower spring
🌹|rose flower red love
🌺|hibiscus flower
🌻|sunflower flower
🌷|tulip flower
💐|bouquet flowers
🍄|mushroom
⛰️|mountain nature
🏔️|snow mountain
🌋|volcano
🏖️|beach umbrella
🏝️|island desert
🌅|sunrise morning
🌄|sunrise mountain morning
🌇|sunset evening city
🌃|night stars city
🌌|milky way galaxy night
🌤️|sun small cloud weather
⛈️|storm thunder rain weather
🌧️|rain cloud weather
🌨️|snow cloud weather
🌩️|lightning cloud weather
🌪️|tornado wind weather
🌫️|fog weather
💨|wind dash fast blow
☃️|snowman winter
🍎|apple red fruit
🍏|green apple fruit
🍐|pear fruit
🍊|orange tangerine fruit
🍋|lemon fruit sour
🍌|banana fruit
🍉|watermelon fruit summer
🍇|grapes fruit
🍓|strawberry fruit
🫐|blueberries fruit
🍒|cherries fruit
🍑|peach fruit
🥭|mango fruit
🍍|pineapple fruit
🥥|coconut fruit
🥝|kiwi fruit
🍅|tomato vegetable
🥑|avocado fruit
🥕|carrot vegetable
🌽|corn maize
🥔|potato vegetable
🍆|eggplant vegetable
🥦|broccoli vegetable
🧄|garlic
🧅|onion
🍞|bread food
🥐|croissant bread food
🥖|baguette bread food
🧀|cheese food
🥚|egg food
🍳|cooking fried egg pan food
🥞|pancakes food breakfast
🧇|waffle food breakfast
🥓|bacon food
🍗|chicken leg meat food
🍖|meat bone food
🍔|burger hamburger food
🍟|fries food
🍕|pizza food
🌭|hot dog food
🌮|taco food
🌯|burrito wrap food
🥙|stuffed flatbread kebab food
🍜|noodles ramen soup food
🍝|spaghetti pasta food
🍣|sushi food
🍤|shrimp food
🍚|rice food
🍛|curry rice food
🍲|stew pot food
🥗|salad green food
🍿|popcorn snack
🍩|donut doughnut sweet
🍪|cookie sweet
🎂|birthday cake sweet
🍰|cake slice sweet
🧁|cupcake sweet
🍫|chocolate sweet
🍬|candy sweet
🍭|lollipop sweet
🍯|honey sweet
🥛|milk glass drink
☕|coffee tea hot drink cup
🍵|tea green cup drink
🧃|juice box drink
🥤|cup straw drink soda
🍺|beer drink
🍷|wine drink
🥂|cheers glasses drink celebrate
🧊|ice cube cold
🍽️|plate fork knife dinner meal
🥄|spoon
🍴|fork knife eat
🔪|knife kitchen
🚕|taxi cab car
🚙|suv car
🚌|bus
🚎|trolleybus
🏎️|race car fast
🚓|police car
🚑|ambulance emergency
🚒|fire truck engine
🚚|truck delivery
🚛|lorry truck
🚜|tractor farm
🏍️|motorcycle bike
🛵|scooter
🚲|bicycle bike
🛴|kick scooter
🚂|train steam locomotive
🚆|train
🚇|metro subway
🚊|tram
🚁|helicopter
🛩️|small airplane
🛫|takeoff departure airplane
🛬|landing arrival airplane
⛵|sailboat boat
🚤|speedboat boat
🛥️|motor boat
🚢|ship cruise
🛳️|passenger ship
🏗️|construction crane building
🏭|factory industry
🏥|hospital medical
🏫|school
🏛️|classical building bank
🏰|castle
🗼|tower tokyo
🗽|statue liberty
🕍|synagogue
⛪|church
🛕|hindu temple
🗿|moai statue
⚽|soccer football ball sport
🏀|basketball ball sport
🏈|american football sport
⚾|baseball sport
🎾|tennis sport
🏐|volleyball sport
🏉|rugby sport
🎱|billiards pool eight ball
🏓|ping pong table tennis
🏸|badminton sport
🥊|boxing glove sport
🥋|martial arts judo karate
⛳|golf flag
🎣|fishing rod
🎿|ski
🏂|snowboard
🏋️|weight lifting gym sport
🚴|cycling bike sport
🏊|swimming sport
🧘|yoga meditation
🏆|trophy cup winner
🥇|gold medal first
🥈|silver medal second
🥉|bronze medal third
🎖️|military medal
🎪|circus tent
🎸|guitar music
🎹|piano keyboard music
🥁|drum music
🎺|trumpet music
🎻|violin music
🎷|saxophone music
🎼|score music notes
🎳|bowling
🎰|slot machine casino
🎡|ferris wheel fair
🎢|roller coaster
🎈|balloon party
🎉|party popper celebrate
🎊|confetti ball celebrate
🎀|ribbon bow
🎄|christmas tree
🎃|pumpkin halloween
🎆|fireworks
🎇|sparkler fireworks
🧸|teddy bear toy
🪀|yo-yo toy
🪁|kite
👓|glasses eyeglasses
🕶️|sunglasses
🥽|goggles
👔|necktie shirt
👕|t-shirt clothes
👖|jeans pants clothes
🧣|scarf
🧤|gloves
🧥|coat jacket
👗|dress
👟|sneaker shoe
👞|shoe
👠|high heel shoe
🎒|backpack school bag
👜|handbag bag
👛|purse wallet
💼|briefcase work bag
☂️|umbrella rain
🌂|closed umbrella
👑|crown king
💍|ring diamond
💄|lipstick makeup
🧴|lotion bottle
🧻|toilet paper roll
🚽|toilet
🚰|tap water drink
🛁|bathtub bath
🪒|razor shave
🧺|basket laundry
🛌|bed sleep
🪞|mirror
💊|pill medicine capsule
💉|syringe injection vaccine
🩺|stethoscope doctor health
🩹|bandage adhesive
🩸|blood drop
🦷|tooth dentist
🦴|bone
🧠|brain mind think
🫀|heart organ anatomical
👁️|eye see watch
👀|eyes look watch
👂|ear hear listen
👃|nose smell
👄|mouth lips
🗣️|speaking head talk voice
👤|person silhouette user profile
👥|people silhouettes users group
👨‍💻|developer programmer man computer
🧑‍🔧|mechanic technician
🧑‍🍳|cook chef
🤖|robot bot
👻|ghost
💀|skull
☠️|skull crossbones danger
👽|alien
🎅|santa
❤️|red heart love
🧡|orange heart love
💛|yellow heart love
💚|green heart love
💙|blue heart love
💜|purple heart love
🖤|black heart love
🤍|white heart love
🤎|brown heart love
💔|broken heart
💕|two hearts love
💖|sparkling heart love
💗|growing heart love
💓|beating heart love
💞|revolving hearts love
💘|heart arrow love
💝|heart ribbon gift love
😀|grinning face smile happy
😃|smiley face happy
😄|smile happy
😁|grin happy
😆|laugh happy
😂|joy tears laugh
🤣|rofl laugh
😊|blush smile happy
😇|angel halo
🙂|slight smile
😉|wink
😍|heart eyes love
🥰|smiling hearts love
😘|kiss blow love
😋|yum tasty
😎|cool sunglasses
🤓|nerd glasses
🤔|thinking hmm
🤨|raised eyebrow
😐|neutral
😑|expressionless
😶|no mouth silent
🙄|eye roll
😏|smirk
😴|sleeping zzz
😪|sleepy
😷|mask sick
🤒|sick thermometer
🤕|hurt bandage
🤢|nauseated sick
🥵|hot face
🥶|cold face freezing
😵|dizzy face
🤯|mind blown explode
😳|flushed
🥺|pleading puppy eyes
😢|cry sad tear
😭|sob cry loud
😱|scream fear shock
😨|fearful
😰|anxious sweat
😡|angry red
🤬|swearing cursing
😈|devil imp
🙈|see no evil monkey
🙉|hear no evil monkey
🙊|speak no evil monkey
👍|thumbs up like good yes
👎|thumbs down dislike bad no
👌|ok hand
✌️|victory peace hand
🤞|crossed fingers luck
🤟|love you hand
🤘|rock horns hand
👈|point left hand
👉|point right hand
👆|point up hand
👇|point down hand
☝️|index up hand
✋|raised hand stop
🖐️|hand fingers splayed
👋|wave hello bye hand
🤝|handshake deal
🙏|pray thanks please folded hands dua
👏|clap applause hands
🙌|raised hands celebrate
💪|muscle strong flex arm
✍️|writing hand
🤲|palms up together dua
🫶|heart hands love
👊|fist bump punch
✊|raised fist
🇮🇷|iran flag
🇺🇸|usa united states flag
🇬🇧|uk britain united kingdom flag
🇸🇦|saudi arabia flag
🇮🇶|iraq flag
🇦🇪|uae emirates flag
🇹🇷|turkey flag
🇩🇪|germany flag
🇫🇷|france flag
🇨🇦|canada flag
🇨🇳|china flag
🇯🇵|japan flag
🇷🇺|russia flag
🇮🇳|india flag
🇵🇰|pakistan flag
🏴|black flag
🕎|menorah
☪️|star and crescent islam
🔯|star of david
☮️|peace symbol
☯️|yin yang
☢️|radioactive
☣️|biohazard
♾️|infinity
💯|hundred perfect score
🔞|18 adults only
🆓|free
🆙|up
🆚|versus vs
🅰️|a blood type
🅱️|b blood type
🅾️|o blood type
🆎|ab blood type
🔟|ten 10
#️⃣|hash number sign
*️⃣|asterisk star key
0️⃣|zero 0 number
1️⃣|one 1 number
2️⃣|two 2 number
3️⃣|three 3 number
4️⃣|four 4 number
5️⃣|five 5 number
6️⃣|six 6 number
7️⃣|seven 7 number
8️⃣|eight 8 number
9️⃣|nine 9 number
🔺|red triangle up
🔻|red triangle down
🔶|large orange diamond
🔷|large blue diamond
🔸|small orange diamond
🔹|small blue diamond
◀️|reverse play left
🔣|symbols
📜|scroll paper
📰|newspaper news
🗞️|rolled newspaper news
📓|notebook
📔|notebook decorative cover
📒|ledger
📕|closed book red
📗|green book
📘|blue book
📙|orange book
✒️|nib pen
🖍️|crayon
📇|card index
🗒️|spiral notepad
🗄️|file cabinet
🏧|atm
🛂|passport control
🛃|customs
🛄|baggage claim
🧳|luggage travel suitcase
⌚|watch time
📼|videocassette tape
🎞️|film frames movie
📽️|film projector movie
🧧|red envelope gift money
🪪|id card identity
🧨|firecracker
⚔️|crossed swords
🗡️|dagger
🏹|bow arrow archery
🔫|water pistol toy
🪃|boomerang
🪓|axe
⚗️|alembic chemistry
🧫|petri dish
🦠|microbe virus germ
🪤|mouse trap
🪣|bucket
"""

internal class EmojiEntry(val emoji: String, val words: String)

internal val StripEmojiEntries: List<EmojiEntry> = RAW.trim().lines().mapNotNull {
    val i = it.indexOf('|')
    if (i <= 0) null else EmojiEntry(it.substring(0, i), it.substring(i + 1).lowercase())
}

/** Kept for places that only need the characters. */
internal val StripEmoji: List<String> = StripEmojiEntries.map { it.emoji }

/** The ones this phone's font can really draw (checked once). */
internal fun drawableEmoji(): List<EmojiEntry> {
    val p = android.graphics.Paint()
    return StripEmojiEntries.filter { p.hasGlyph(it.emoji) }
}

/** A plain recycling grid of emoji: much lighter than hundreds of Compose cells. */
internal class EmojiAdapter(private val items: List<String>) : android.widget.BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
        val tv = (convertView as? android.widget.TextView) ?: android.widget.TextView(parent.context).apply {
            textSize = 28f
            gravity = android.view.Gravity.CENTER
            layoutParams = android.widget.AbsListView.LayoutParams(-1, (52 * resources.displayMetrics.density).toInt())
            includeFontPadding = false
        }
        tv.text = items[position]
        return tv
    }
}
