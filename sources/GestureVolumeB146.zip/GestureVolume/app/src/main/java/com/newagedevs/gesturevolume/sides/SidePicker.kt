package com.newagedevs.gesturevolume.sides

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import com.newagedevs.gesturevolume.flow.FlowStore
import com.newagedevs.gesturevolume.flow.NativePicker
import com.newagedevs.gesturevolume.strip.StripConfig
import com.newagedevs.gesturevolume.ui.screens.strip.FoundShortcut
import com.newagedevs.gesturevolume.ui.screens.strip.INTENT_ACTION_PREFIX
import com.newagedevs.gesturevolume.ui.screens.strip.loadCreators
import com.newagedevs.gesturevolume.ui.screens.strip.loadStaticShortcuts
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions

/** Picks any A action as plain dialogs (nothing stays in memory): built-in, device, cells, scripts, apps. */
object SidePicker {
    private class Choice(val label: String, val action: String)

    fun label(activity: android.content.Context, action: String): String {
        if (action.isEmpty()) return "not set"
        if (action == Seg.MAIN) return "Same as main slider (live)"
        if (action == Seg.STRIP) return "Cells window"
        HandlerActionCatalog.entryFor(action)?.let { return activity.getString(it.labelRes) }
        if (NativePicker.isNative(action)) return NativePicker.label(action)
        if (action.startsWith("MyFlow:")) return "Script: " + action.removePrefix("MyFlow:")
        if (action.startsWith(INTENT_ACTION_PREFIX)) {
            val pkg = runCatching { Intent.parseUri(action.removePrefix(INTENT_ACTION_PREFIX), Intent.URI_INTENT_SCHEME).let { it.component?.packageName ?: it.`package` } }.getOrNull()
            val app = pkg?.let { runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(it, 0)).toString() }.getOrNull() }
            return "App shortcut" + (app?.let { " ($it)" } ?: "")
        }
        if (action.startsWith(StripConfig.FLOW_PREFIX)) return "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
        if (action.startsWith("Shell:")) return "Shell: " + action.removePrefix("Shell:").take(24)
        HandlerActions.launchedPackage(action)?.let { pkg ->
            return "Open " + runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        }
        return action.take(30)
    }

    /** Opens the action picker (shown by the side bars screen); [onPicked] gets the chosen action. */
    fun pick(activity: Activity, slot: String, onPicked: (String) -> Unit) {
        (activity as? SidesActivity)?.showPicker(slot, onPicked)
    }

    /** What the main slider does for [slot] now, for "Copy Main Slider's current". */
    fun mainNow(activity: Activity, slot: String): String {
        val p = com.newagedevs.gesturevolume.data.local.SharedPref(activity)
        return when (slot) {
            "tap" -> p.getHandlerSingleTapAction(); "double" -> p.getHandlerDoubleTapAction()
            "long" -> p.getHandlerLongTapAction(); "up" -> p.getHandlerSwipeUpAction()
            "down" -> p.getHandlerSwipeDownAction()
            "in" -> if (p.getStripEnabled()) Seg.STRIP else p.getHandlerSwipeInAction()
            else -> p.getHandlerSwipeOutAction()
        }
    }

    const val REQ_CREATOR = 7001
    private var pendingCreator: ((String) -> Unit)? = null

    /** Called from the activity's onActivityResult: the shortcut another app's "create shortcut" screen made. */
    @Suppress("DEPRECATION")
    fun onResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ_CREATOR) return
        val cb = pendingCreator; pendingCreator = null
        val picked = data?.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (resultCode == Activity.RESULT_OK && picked != null && cb != null) cb(INTENT_ACTION_PREFIX + picked.toUri(Intent.URI_INTENT_SCHEME))
    }

    /** Starts another app's "make a shortcut" screen; its result comes back through [onResult]. */
    fun launchCreator(activity: Activity, pkg: String, cls: String, onPicked: (String) -> Unit) {
        pendingCreator = onPicked
        runCatching {
            activity.startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setClassName(pkg, cls), REQ_CREATOR)
        }
    }
}
