package com.newagedevs.gesturevolume.ui.screens.shell

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.utils.ShizukuShell

/** One button that has Shizuku give this app every permission it can use. */
@Composable
fun ShizukuGrantRow(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var status by remember { mutableStateOf("") }
    Column(modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)) {
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                ShizukuShell.requestPermission { ok ->
                    if (!ok) {
                        status = if (!ShizukuShell.isRunning()) "Shizuku is not running. Start it first, then try again."
                        else "Shizuku permission was refused."
                        return@requestPermission
                    }
                    status = "Granting…"
                    Thread {
                        val code = runCatching { ShizukuShell.grantAll(context) { } }.getOrDefault(-1)
                        status = if (code == 0) "Permissions granted. Close the app and open it again."
                        else "Granting ended with code $code. Open the Shell screen in Troubleshoot to see why."
                    }.start()
                }
            },
        ) { Text("Grant permissions with Shizuku") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = { context.startActivity(android.content.Intent(context, com.newagedevs.gesturevolume.flow.FlowActivity::class.java)) },
        ) { Text("Scripts") }
        if (status.isNotEmpty()) Text(status, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
