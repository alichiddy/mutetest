package com.newagedevs.gesturevolume.utils

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * A small diary of what went wrong, and a report that can be copied and sent.
 *
 * The report says what phone this is, which permissions and settings are in place, what each
 * audio stream looks like, the app's own recent notes, and the app's own warnings and errors from
 * the system log (an app may read its own lines of the log without any permission).
 */
object DiagLog {
    private val lines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun note(text: String) {
        if (lines.size >= 200) lines.removeFirst()
        lines.addLast("${clock.format(Date())} $text")
    }

    /**
     * A note that survives the process being killed: kept in a small private file, newest last,
     * so the next report can say what happened before the app last died.
     */
    fun persist(context: Context, text: String) {
        note(text)
        runCatching {
            val f = java.io.File(context.filesDir, "events.log")
            val old = if (f.exists()) f.readLines().takeLast(60) else emptyList()
            f.writeText((old + "${java.text.SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())} $text").joinToString("\n") + "\n")
        }
    }

    /**
     * A watched system setting changed (the accessibility list, the Do Not Disturb access list): note
     * what was removed and added and, through Shizuku, which processes had just started, so the app
     * that rewrote it can be found. Runs on its own short thread.
     */
    fun noteSettingChange(context: Context, label: String, old: String, now: String, sep: Char) {
        val before = old.split(sep).filter { it.isNotEmpty() }.toSet()
        val after = now.split(sep).filter { it.isNotEmpty() }.toSet()
        if (before == after) return
        persist(context, "$label changed: removed=${before - after} added=${after - before}")
        Thread {
            val sb = StringBuilder()
            sb.append("---- $label changed at ${SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
            sb.append("removed: ${before - after}\nadded: ${after - before}\n")
            if (ShizukuShell.isReady()) {
                for (c in listOf(
                    "logcat -d -b events -t 600 | grep -E 'am_proc_start|am_proc_died' | tail -14",
                    "dumpsys activity activities | grep -E 'mResumedActivity' | head -2",
                )) {
                    sb.append("$ ").append(c.take(80)).append('\n')
                    runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }
                }
            } else sb.append("(Shizuku not ready: only the change itself is recorded)\n")
            runCatching {
                val f = java.io.File(context.filesDir, "unbind.txt")
                val old2 = if (f.exists()) f.readText().takeLast(30000) else ""
                f.writeText(old2 + sb.toString())
            }
        }.start()
    }

    /**
     * When the system disconnects the service: what the settings now say, which app was in front,
     * and, through Shizuku, the system log around that moment (who touched what). Kept in a file
     * the report includes. Runs once per disconnection, on its own short thread.
     */
    fun captureUnbind(context: Context) {
        val settingNow = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull()
        persist(context, "  at disconnect, settings list = $settingNow")
        Thread {
            val sb = StringBuilder()
            sb.append("---- disconnect at ${SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
            sb.append("settings list: $settingNow\n")
            if (ShizukuShell.isReady()) {
                val cmds = listOf(
                    "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -3",
                    "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -3",
                    "L=\$(logcat -d -b all -t 6000 | grep -E 'START u0|startActivity|Accessibility(Settings|SubSettings)' | grep -i -E 'settings' | tail -6); echo \"\$L\"; for u in \$(echo \"\$L\" | grep -o -E '(from uid|callingUid=|uid=)[ ]?[0-9]+' | grep -o -E '[0-9]+' | sort -u); do pm list packages --uid \$u; done",
                    "logcat -d -b all -t 1500 | grep -v -E 'AccessibilityDelegate|resource failed|ImeFocus|inline cache' | grep -i -E 'accessib|a11y|a\\.a|settings|pem|imanager|ActivityTaskManager|ActivityManager|PackageManager|Binder' | tail -80",
                )
                for (c in cmds) {
                    sb.append("$ ").append(c.take(90)).append('\n')
                    runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }
                }
            } else sb.append("(Shizuku not ready: no system log captured)\n")
            runCatching {
                val f = java.io.File(context.filesDir, "unbind.txt")
                val old = if (f.exists()) f.readText().takeLast(30000) else ""
                f.writeText(old + sb.toString())
            }
        }.start()
    }

    /** Written once each time the app process starts, with what the settings say about the service. */
    fun processStarted(context: Context) {
        val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        persist(context, "process started; accessibility in settings=${enabled.contains(context.packageName)}")
    }

    /** After a report is copied the next one starts from scratch: notes, saved events and disconnect captures. */
    fun clear(context: Context) {
        synchronized(this) { lines.clear() }
        runCatching { java.io.File(context.filesDir, "events.log").delete() }
        runCatching { java.io.File(context.filesDir, "unbind.txt").delete() }
        runCatching { Runtime.getRuntime().exec(arrayOf("logcat", "-c")) }
    }

    fun e(what: String, error: Throwable) = note("ERROR $what: ${error.javaClass.simpleName}: ${error.message}")

    /** A volume write that raised no error but left the level where it was is the Realme-type failure. */
    fun verify(manager: AudioManager, stream: Int, wanted: Int) {
        val now = runCatching { manager.getStreamVolume(stream) }.getOrNull() ?: return
        if (now == wanted) return
        note("WRITE IGNORED stream=$stream wanted=$wanted now=$now fixed=${runCatching { manager.isVolumeFixed }.getOrNull()} mode=${runCatching { manager.mode }.getOrNull()}")
        // Another route: the relative adjust, one step at a time. Some ROMs (Realme) drop the
        // absolute write but honour this.
        runCatching {
            var guard = 0
            var cur = now
            while (cur != wanted && guard++ < 40) {
                manager.adjustStreamVolume(stream, if (wanted > cur) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
                val next = manager.getStreamVolume(stream)
                if (next == cur) break
                cur = next
            }
            if (cur == wanted) { note("WRITE FIXED by adjustStreamVolume stream=$stream now=$cur"); return }
        }
        // Last route: the system's own command through Shizuku, off the main thread.
        if (ShizukuShell.isReady()) Thread {
            runCatching {
                ShizukuShell.run("cmd media_session volume --stream $stream --set $wanted") { }
                val after = manager.getStreamVolume(stream)
                note(if (after == wanted) "WRITE FIXED by cmd media_session stream=$stream now=$after" else "WRITE still ignored after cmd media_session stream=$stream now=$after")
            }
        }.start()
        else note("WRITE not fixed: no Shizuku for the last route")
    }

    fun report(context: Context): String {
        val sb = StringBuilder()
        fun line(s: String) = sb.append(s).append('\n')
        line("== A diagnostic report ==")
        line("Phone: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
        line("Build: ${Build.DISPLAY}")
        runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            line("App: ${context.packageName} ${info.versionName}")
        }
        line("Volume boost: ${VolumeBoost.status()}")
        line("Overlay allowed: ${runCatching { Settings.canDrawOverlays(context) }.getOrNull()}")
        line("Write settings allowed: ${runCatching { Settings.System.canWrite(context) }.getOrNull()}")
        line("Notification policy (DND) access: ${runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }.getOrNull()}")
        val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        line("Accessibility service on: ${enabled.contains(context.packageName)}")
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audio != null) {
            line("Audio mode: ${runCatching { audio.mode }.getOrNull()}  volume fixed: ${runCatching { audio.isVolumeFixed }.getOrNull()}  music active: ${runCatching { audio.isMusicActive }.getOrNull()}")
            val names = listOf(
                AudioManager.STREAM_MUSIC to "music", AudioManager.STREAM_RING to "ring",
                AudioManager.STREAM_NOTIFICATION to "notification", AudioManager.STREAM_ALARM to "alarm",
                AudioManager.STREAM_VOICE_CALL to "call", AudioManager.STREAM_SYSTEM to "system",
            )
            for ((s, n) in names) {
                line("Stream $n: ${runCatching { audio.getStreamVolume(s) }.getOrNull()} of ${if (Build.VERSION.SDK_INT >= 28) runCatching { audio.getStreamMinVolume(s) }.getOrNull() else 0}..${runCatching { audio.getStreamMaxVolume(s) }.getOrNull()}")
            }
            // A harmless live test: set music to its current value and see whether the call is accepted.
            val cur = runCatching { audio.getStreamVolume(AudioManager.STREAM_MUSIC) }.getOrNull()
            if (cur != null) {
                val res = runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, cur, 0) }
                line("Test write of music volume: ${if (res.isSuccess) "accepted" else "REFUSED " + res.exceptionOrNull()}")
            }
        }
        line("")
        line("== Saved events (survive the app being killed) ==")
        runCatching { java.io.File(context.filesDir, "events.log").readText() }.getOrNull()?.let { sb.append(it) }
        line("")
        line("== Why the system ended this app's earlier processes ==")
        sb.append(systemView(context))
        line("")
        line("== System view at each disconnection ==")
        runCatching { java.io.File(context.filesDir, "unbind.txt").readText().takeLast(9000) }.getOrNull()?.let { sb.append(it) }
        line("")
        line("== The app's own notes ==")
        synchronized(this) { lines.forEach { line(it) } }
        line("")
        line("== The app's log (warnings and errors) ==")
        sb.append(ownLog())
        return sb.toString()
    }

    /** With Shizuku: Android's own record of why this app's processes ended, and of the service. */
    private fun systemView(context: Context): String {
        if (!ShizukuShell.isReady()) return "(Shizuku is not running or not allowed, so the system's own record is not available. Start Shizuku and copy the report again.)\n"
        val pkg = context.packageName
        val sb = StringBuilder()
        val cmds = listOf(
            "dumpsys activity exit-info $pkg 2>&1 | head -60",
            "logcat -d -b crash -t 120",
            "dumpsys accessibility 2>&1 | grep -i -E '$pkg|crashed|bound|enabled' | head -30",
            "logcat -d -b all -t 4000 2>&1 | grep -i -E 'accessibility.*($pkg|disabl|crash|unbind)|$pkg.*(died|kill|force|disabl)|(kill|force).*$pkg' | tail -40",
        )
        for (c in cmds) {
            sb.append("$ ").append(c.substringBefore(" 2>&1")).append('\n')
            runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }.onFailure { sb.append("failed: ${it.message}\n") }
        }
        return sb.toString()
    }

    private fun ownLog(): String = runCatching {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "300", "-v", "time", "*:W"))
        p.inputStream.bufferedReader().use { it.readText() }.ifBlank { "(empty)" }
    }.getOrElse { "(could not read the log: ${it.message})" }
}
