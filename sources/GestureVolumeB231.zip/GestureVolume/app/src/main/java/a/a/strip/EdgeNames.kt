package a.a.strip

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import android.text.TextPaint
import android.view.View

/**
 * One full-screen, touch-free view that exists only while the cells window is open and the option
 * "Show the names of all outside actions" is on. It writes the name of every outside field where
 * that field is (so the thumb knows which field runs what before it gets there), lights the one
 * under the thumb, and, when the cancel gap is on, outlines the gap around the cells window.
 */
class EdgeNames(context: Context) : View(context) {
    class Pill(val key: String, val text: String, val cx: Float, val cy: Float, val maxW: Float)

    private var pills: List<Pill> = emptyList()
    private var gapRect: RectF? = null
    private var active = ""
    private val dp = context.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val bgOn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * dp }
    private val gapLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * dp
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(8f * dp, 6f * dp), 0f)
    }
    private val ink = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 13f * dp; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val inkOn = TextPaint(ink).apply { color = 0xFF102A2E.toInt() }
    private val box = RectF()

    fun set(list: List<Pill>, gap: RectF?) {
        pills = list; gapRect = gap
        invalidate()
    }

    /** Key ("Side#zone") of the field under the thumb, "" for none. */
    fun setActive(key: String) {
        if (key == active) return
        active = key
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        gapRect?.let { canvas.drawRoundRect(it, 10f * dp, 10f * dp, gapLine) }
        val h = 30f * dp
        val pad = 10f * dp
        for (p in pills) {
            val on = p.key == active
            val paint = if (on) inkOn else ink
            val room = (p.maxW - 2f * pad).coerceAtLeast(24f * dp)
            val t = TextUtils.ellipsize(p.text, paint, room, TextUtils.TruncateAt.END).toString()
            val w = paint.measureText(t) + 2f * pad
            var l = p.cx - w / 2f
            var tp = p.cy - h / 2f
            l = l.coerceIn(2f * dp, (width - w - 2f * dp).coerceAtLeast(2f * dp))
            tp = tp.coerceIn(2f * dp, (height - h - 2f * dp).coerceAtLeast(2f * dp))
            box.set(l, tp, l + w, tp + h)
            canvas.drawRoundRect(box, h / 2f, h / 2f, if (on) bgOn else bg)
            if (!on) canvas.drawRoundRect(box, h / 2f, h / 2f, edge)
            canvas.drawText(t, box.centerX(), box.centerY() - (paint.descent() + paint.ascent()) / 2f, paint)
        }
    }
}
