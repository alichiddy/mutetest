## Build B363
All requests built at once. Bracket integrity verified. Zero idle RAM maintained. All new features are optional and default to off or preserve existing behavior.

1. Cell tile colour/opacity (Built-in): `LookPrefs.kt`, `LookDialog.kt`, `StripView.kt`. Added global/per-item tile color, opacity, corner roundness, border. Live preview updated.
2. Show system volume bar (Built-in): `OverlayController.kt`. Added toggle in Appearance. Applies `AudioManager.FLAG_SHOW_UI` when on.
3. Floating gallery multi-select (Built-in): `FloatTools.kt`. Added long-press selection, select all/none, count. Actions: Share (MULTIPLE), Delete (API 30+ createDeleteRequest), Copy path, Details, Open.
4. Floating notes multi-select (Built-in): `FloatTools.kt`. Added multi-select, Share, Copy, Delete, Export .txt.
5. Widgets bar opacity (Built-in): `WidgetFloat.kt`. Added `barOpacity` and `barColor` to WidgetKit cfg, applied to handle/title bar.
6. Widget picker preview (Built-in): `WidgetHostActivity.kt`. Cards show App Icon, App Name, Widget Name, Size, `loadPreviewImage` (lazy-loaded, released on close).
7. Scripts background checks running (Built-in/Engine): `FlowRunner.kt`, `FlowActivity.kt`, `WhenEvents.kt`, `WhenPicks.kt`. Background checks register as running with `waitingFor` description, sorted to top, included in "Stop all (n)" count, unregistered cleanly on stop.
