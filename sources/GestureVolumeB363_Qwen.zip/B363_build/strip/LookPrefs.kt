package strip
import android.graphics.Color

object LookPrefs {
    var tileColor: Int get() = Prefs.getInt("strip.tileColor", Color.parseColor("#FFB300")); set(value) = Prefs.setInt("strip.tileColor", value)
    var tileOpacity: Float get() = Prefs.getFloat("strip.tileOpacity", 1.0f); set(value) = Prefs.setFloat("strip.tileOpacity", value)
    var cornerRoundness: Float get() = Prefs.getFloat("strip.cornerRoundness", 16f); set(value) = Prefs.setFloat("strip.cornerRoundness", value)
    var borderColor: Int get() = Prefs.getInt("strip.borderColor", Color.TRANSPARENT); set(value) = Prefs.setInt("strip.borderColor", value)
    var borderWidth: Float get() = Prefs.getFloat("strip.borderWidth", 0f); set(value) = Prefs.setFloat("strip.borderWidth", value)

    fun getTileColor(id: String?): Int = if (id != null) Prefs.getInt("strip.item.$id.tileColor", -1).takeIf { it != -1 } ?: tileColor else tileColor
    fun setTileColor(id: String, v: Int) = Prefs.setInt("strip.item.$id.tileColor", v)
    fun getTileOpacity(id: String?): Float = if (id != null) Prefs.getFloat("strip.item.$id.tileOpacity", -1f).takeIf { it != -1f } ?: tileOpacity else tileOpacity
    fun setTileOpacity(id: String, v: Float) = Prefs.setFloat("strip.item.$id.tileOpacity", v)
    fun getCornerRoundness(id: String?): Float = if (id != null) Prefs.getFloat("strip.item.$id.cornerRoundness", -1f).takeIf { it != -1f } ?: cornerRoundness else cornerRoundness
    fun setCornerRoundness(id: String, v: Float) = Prefs.setFloat("strip.item.$id.cornerRoundness", v)
    fun getBorderColor(id: String?): Int = if (id != null) Prefs.getInt("strip.item.$id.borderColor", -1).takeIf { it != -1 } ?: borderColor else borderColor
    fun setBorderColor(id: String, v: Int) = Prefs.setInt("strip.item.$id.borderColor", v)
    fun getBorderWidth(id: String?): Float = if (id != null) Prefs.getFloat("strip.item.$id.borderWidth", -1f).takeIf { it != -1f } ?: borderWidth else borderWidth
    fun setBorderWidth(id: String, v: Float) = Prefs.setFloat("strip.item.$id.borderWidth", v)
}
