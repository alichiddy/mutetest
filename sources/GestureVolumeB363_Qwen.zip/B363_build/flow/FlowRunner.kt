package flow

object FlowRunner {
    data class RunInfo(val scriptId: String, val alwaysOn: Boolean, val waitingFor: String? = null)
    private val running = mutableMapOf<String, RunInfo>()

    fun register(scriptId: String, alwaysOn: Boolean = false, waitingFor: String? = null) {
        running[scriptId] = RunInfo(scriptId, alwaysOn, waitingFor)
    }
    fun unregister(scriptId: String) { running.remove(scriptId) }
    fun getRunning(): List<RunInfo> = running.values.toList()
    
    fun stop(scriptId: String) {
        unregister(scriptId)
        // [KEEP EXISTING STOP LOGIC HERE]
    }
}
