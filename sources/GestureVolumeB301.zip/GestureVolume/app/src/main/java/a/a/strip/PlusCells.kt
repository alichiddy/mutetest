package a.a.strip

import android.content.SharedPreferences

/**
 * The cells window's "+" options, read from one window's settings (the main slider's or a segment's own):
 *  - "+ in empty cells": blank cells show a "+"; a tap (in the editing window) or a release (in the live window) on one opens its editing window.
 *  - "Hold a cell to edit it": the thumb resting on a cell opens its editing window. Independent of the "+ in empty cells" option.
 *    It works on any cell, only empty cells or only defined cells ([HOLD_ANY], [HOLD_EMPTY], [HOLD_DEFINED]), after the system's hold
 *    time or a time of the user's own.
 *  - "+ after the last cell": one more slot after the last cell; it adds a blank cell and opens its editing window.
 * Scope values: 0 = main window and folders, 1 = main window only, 2 = folders only.
 * "Where" values for the last-cell "+": 0 = both, 1 = only from a gesture, 2 = only in the cells editing window.
 */
object PlusCells {
    const val SCOPE_BOTH = 0
    const val SCOPE_MAIN = 1
    const val SCOPE_FOLDERS = 2

    const val HOLD_ANY = 0
    const val HOLD_EMPTY = 1
    const val HOLD_DEFINED = 2

    /** The hold time the user's own setting starts at, in milliseconds. */
    const val HOLD_MS_DEFAULT = 500
    const val HOLD_MS_MAX = 10000

    const val WHERE_BOTH = 0
    const val WHERE_GESTURE = 1
    const val WHERE_EDITOR = 2

    private fun inScope(scope: Int, folder: Boolean) =
        scope == SCOPE_BOTH || (scope == SCOPE_MAIN && !folder) || (scope == SCOPE_FOLDERS && folder)

    /** Whether blank cells show a "+" in the main window ([folder] false) or in a folder's window. */
    fun empty(sp: SharedPreferences, folder: Boolean): Boolean =
        sp.getBoolean("stripPlusEmpty", false) && inScope(sp.getInt("stripPlusEmptyScope", SCOPE_BOTH), folder)

    /** Whether the slot after the last cell shows a "+", in the live window ([gesture] true) or in the editing window. */
    fun end(sp: SharedPreferences, folder: Boolean, gesture: Boolean): Boolean {
        if (!sp.getBoolean("stripPlusEnd", false)) return false
        if (!inScope(sp.getInt("stripPlusEndScope", SCOPE_BOTH), folder)) return false
        val where = sp.getInt("stripPlusEndWhere", WHERE_BOTH)
        return if (gesture) where != WHERE_EDITOR else where != WHERE_GESTURE
    }

    /** Whether resting on a cell opens its editing window (the hold option). */
    fun hold(sp: SharedPreferences): Boolean = sp.getBoolean("stripHoldEdit", false)

    /** Which cells the hold works on: [HOLD_ANY], [HOLD_EMPTY] or [HOLD_DEFINED]. */
    fun holdWhich(sp: SharedPreferences): Int = sp.getInt("stripHoldWhich", HOLD_ANY)

    /** The hold time in milliseconds: the system's ([systemMs]) unless the user set their own. */
    fun holdMs(sp: SharedPreferences, systemMs: Int): Int =
        if (sp.getBoolean("stripHoldOwn", false)) sp.getInt("stripHoldMs", HOLD_MS_DEFAULT).coerceIn(50, HOLD_MS_MAX) else systemMs
}
