package a.a.utils

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/**
 * "Previous app": goes back to the app used before the one in front, the way Recents does it, and
 * lands exactly where that app was left (inside its submenu, not on its main screen).
 *
 * How the app is brought back (Shizuku): exactly what Recents does when you tap a card, in this order,
 * each one checked before the next is tried:
 *  1. ActivityTaskManager.startActivityFromRecents(taskId), the very call Recents makes.
 *  2. ActivityManager.moveTaskToFront(taskId, MOVE_TASK_WITH_HOME).
 *  3. `am task lock` / `lock stop`, which brings a task to the front by its id from the shell. Unpinning locks the
 *     phone when "ask for the PIN before unpinning" is on; the option PREF_PIN_FIX turns that off during this step and restores it.
 * A launcher icon or the task's start intent is never used: they land on the app's main screen.
 * Without Shizuku it works like MyGesture's "Previous app": the app before the one in front is taken from the list of
 * apps seen by the accessibility service (else Usage access), and is opened with its launcher intent
 * (MAIN + LAUNCHER, its first launcher activity, NEW_TASK + RESET_TASK_IF_NEEDED) sent as a PendingIntent. Android
 * then brings that app's existing task to the front as it was left, the same as tapping its icon.
 *
 * Which app: only what the real Recents list would show. Tasks Android hides from Recents, file or
 * content pickers (GET_CONTENT, OPEN_DOCUMENT ...), system dialogs, the launcher and A itself are
 * skipped, so an app that only flashed up as a picker (a file manager, say) is never "previous".
 *
 * Three sources, no background work of its own:
 *  1. Android's recents list, read on demand through Shizuku (`dumpsys activity recents`).
 *  2. A tiny list of the last few apps fed by the accessibility service's window changes, only
 *     while the "track apps" switch is on. An app counts only after it stayed in front for a moment,
 *     so windows that flash past (pickers, trampolines) are dropped.
 *  3. Android's usage events ("Usage access"), read on demand, with the same dwell rule. Used when
 *     Shizuku's list is not available and tracking has nothing. The launcher is never "previous".
 */
object PreviousApp {
    const val PREF_EXCLUDE = "prevAppExclude"
    const val PREF_TRACK = "prevAppTrack"
    /** Show the "nothing found" message as Android's own toast instead of on the bar. */
    const val PREF_TOAST = "prevAppToast"
    /** Option: turn off "lock after unpinning" while the pin way runs (Huawei power saving mode), then restore it. Off by default. */
    const val PREF_PIN_FIX = "prevAppPinFix"
    /** Option: A itself may be the previous app (default off: A is skipped). */
    const val PREF_ALLOW_A = "prevAppAllowA"

    /** Whether A itself counts as an app to switch back to. Read on demand, nothing kept. */
    fun allowA(context: Context): Boolean =
        context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE).getBoolean(PREF_ALLOW_A, false)

    /** One task of the recents list. Only [pkg], [component] and [visible] are always filled. */
    data class Task(
        val pkg: String, val component: String?, val visible: Boolean,
        val id: Int = -1, val user: Int = 0, val type: String = "",
        val action: String = "", val categories: List<String> = emptyList(), val flags: Long = 0L, val data: String = "",
        val hiddenFromRecents: Boolean = false,
    )

    private const val DWELL_MS = 700L
    private const val FLAG_NEW_TASK = 0x10000000L
    private const val FLAG_EXCLUDE_FROM_RECENTS = 0x00800000L
    // Flags that would make a replay start something new instead of resuming the task.
    private const val FLAGS_THAT_RESTART = 0x04000000L or 0x00008000L or 0x00080000L // CLEAR_TOP, CLEAR_TASK, NEW_DOCUMENT
    /** Windows that are never an app the user was using: Android's own dialogs and pickers. */
    private val NEVER_PREVIOUS = setOf(
        "android", "com.android.systemui", "com.android.documentsui", "com.google.android.documentsui",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.android.permissioncontroller", "com.google.android.permissioncontroller", "com.android.intentresolver",
    )
    /** A task started to pick a file or a value is a trampoline, not an app the user went to. */
    private val PICKER_ACTIONS = setOf(
        "android.intent.action.GET_CONTENT", "android.intent.action.OPEN_DOCUMENT", "android.intent.action.OPEN_DOCUMENT_TREE",
        "android.intent.action.CREATE_DOCUMENT", "android.intent.action.PICK", "android.intent.action.PICK_ACTIVITY",
        "android.intent.action.CHOOSER", "android.intent.action.RINGTONE_PICKER", "android.intent.action.SET_WALLPAPER",
    )

    /** How the last task was brought back (for the Test button). */
    @Volatile
    var lastHow: String = ""

    private val history = ArrayList<String>()
    private var frontSince = 0L

    /**
     * Called for each app that comes to the front. Keeps the last 8. An app that was in front for
     * less than a moment before the next one took over (a picker, a trampoline) is dropped again.
     */
    @Synchronized
    fun noteForeground(pkg: String) {
        if (history.isNotEmpty() && history[0] == pkg) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (history.isNotEmpty() && now - frontSince < DWELL_MS) history.removeAt(0)
        history.remove(pkg)
        history.add(0, pkg)
        frontSince = now
        while (history.size > 8) history.removeAt(history.size - 1)
    }

    @Synchronized
    private fun historyCopy(): List<String> = ArrayList(history)

    fun tracking(sp: SharedPreferences): Boolean = sp.getBoolean(PREF_TRACK, false)

    fun excluded(sp: SharedPreferences): Set<String> =
        sp.getString(PREF_EXCLUDE, "").orEmpty()
            .split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Parses the output of `dumpsys activity recents`, newest first. */
    fun parse(text: String): List<Task> {
        val out = ArrayList<Task>()
        val starts = Regex("Recent #(\\d+):").findAll(text).toList()
        for ((i, m) in starts.withIndex()) {
            val end = if (i + 1 < starts.size) starts[i + 1].range.first else text.length
            val block = text.substring(m.range.first, end)
            val pkg = Regex("\\bA=(?:\\d+:)?([A-Za-z0-9_.]+)").find(block)?.groupValues?.get(1)
                ?: Regex("\\bI=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: Regex("cmp=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: continue
            val cmp = Regex("cmp=([A-Za-z0-9_.\$]+/[A-Za-z0-9_.\$]+)").find(block)?.groupValues?.get(1)
            val id = Regex("(?:Task|TaskRecord)\\{[0-9a-f]+ #(\\d+)").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val user = Regex("\\bU=(\\d+)").find(block)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val type = Regex("\\btype=(\\w+)").find(block)?.groupValues?.get(1).orEmpty()
            // The task's start intent: intent={act=... cat=[...] dat=... flg=0x... cmp=...}
            val intent = Regex("\\bintent=\\{([^}]*)\\}").find(block)?.groupValues?.get(1).orEmpty()
            val act = Regex("\\bact=(\\S+)").find(intent)?.groupValues?.get(1).orEmpty()
            val cats = Regex("\\bcat=\\[([^\\]]*)\\]").find(intent)?.groupValues?.get(1)
                ?.split(',')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            val flags = Regex("\\bflg=0x([0-9a-fA-F]+)").find(intent)?.groupValues?.get(1)?.toLongOrNull(16) ?: 0L
            val dat = Regex("\\bdat=(\\S+)").find(intent)?.groupValues?.get(1).orEmpty()
            // "sz=0" is NOT hidden: it is a task whose app was killed in the background. Recents still shows it
            // and startActivityFromRecents brings it back where it was left, so it counts as a previous app.
            val hidden = (flags and FLAG_EXCLUDE_FROM_RECENTS) != 0L || block.contains("isAvailable=false")
            out.add(Task(pkg, cmp, block.contains("visible=true"), id, user, type, act, cats, flags, dat, hidden))
        }
        return out
    }

    private fun homePackages(context: Context): Set<String> = runCatching {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        context.packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet() - (if (allowA(context)) setOf(context.packageName) else emptySet())
    }.getOrDefault(emptySet())

    /** Reads the recents list through Shizuku. Null when Shizuku is not ready or printed nothing usable. Blocking. */
    fun readRecents(): List<Task>? {
        if (!ShizukuShell.isReady()) return null
        val sb = StringBuilder()
        runCatching { ShizukuShell.run("dumpsys activity recents") { sb.append(it).append('\n') } }
        return parse(sb.toString()).takeIf { it.isNotEmpty() }
    }

    /** An app that is installed, enabled and not suspended: hidden, frozen or removed apps (Hail ...) are not. */
    fun isUsableApp(context: Context, pkg: String): Boolean = runCatching {
        val ai = context.packageManager.getApplicationInfo(pkg, 0)
        ai.enabled && (ai.flags and android.content.pm.ApplicationInfo.FLAG_SUSPENDED) == 0
    }.getOrDefault(false)

    /** Whether a task is something the user would call an app they were using. */
    private fun counts(context: Context, t: Task, home: Set<String>): Boolean =
        (t.pkg != context.packageName || allowA(context)) && t.pkg !in home && t.pkg !in NEVER_PREVIOUS &&
            !t.hiddenFromRecents && (t.type.isEmpty() || t.type == "standard") &&
            // An app in another user (an App Clone) is not known to this user's package list: its task still counts.
            t.action !in PICKER_ACTIONS && (t.user != 0 || isUsableApp(context, t.pkg))

    /** The task to go to from [tasks], or null. */
    fun pick(context: Context, tasks: List<Task>, skip: Set<String>): Task? {
        val home = homePackages(context)
        // The app in front: the first task that is visible (or the first one, when the list says nothing about visibility).
        val anyVisibleInfo = tasks.any { it.visible }
        val allowOwn = allowA(context)
        val first = tasks.firstOrNull { (allowOwn || it.pkg != context.packageName) && it.pkg !in NEVER_PREVIOUS }
        val current = if (first != null && (first.visible || !anyVisibleInfo) && first.pkg !in home) first else null
        return tasks.firstOrNull { t ->
            counts(context, t, home) && t.pkg !in skip &&
                (current == null || (t.pkg != current.pkg && t.id != current.id))
        }
    }

    // ---- bringing a task back -------------------------------------------------------------------

    /** Whether [task] is now the one in front. Blocking. */
    private fun isFront(task: Task): Boolean {
        val now = readRecents() ?: return false
        val top = now.firstOrNull { it.visible } ?: return false
        return top.id == task.id || (task.id < 0 && top.pkg == task.pkg)
    }

    /**
     * Waits for [task] to reach the front, checking about every 150 ms up to [maxMs]. A task whose app was killed
     * has to cold-start first (WhatsApp takes 1-2 s), so one check after 300 ms wrongly says "did not work".
     */
    private fun waitFront(task: Task, maxMs: Long): Boolean {
        val end = android.os.SystemClock.elapsedRealtime() + maxMs
        while (true) {
            pause(150)
            if (isFront(task)) return true
            if (android.os.SystemClock.elapsedRealtime() >= end) return false
        }
    }

    private fun pause(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { }
    }

    private fun how(text: String): String {
        lastHow = text
        return text
    }

    /**
     * What Recents does when a card is tapped: ActivityTaskManager.startActivityFromRecents(taskId).
     * Goes through Shizuku's binder (the shell's privilege), with Android's hidden-API limit lifted
     * for this call. Returns whether Android accepted it. Blocking.
     */
    private fun startFromRecents(taskId: Int): Boolean {
        if (!ShizukuShell.isReady()) return false
        return runCatching {
            if (Build.VERSION.SDK_INT >= 28) HiddenApiBypass.addHiddenApiExemptions("L")
            val binder: IBinder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("activity_task"))
            val atm = Class.forName("android.app.IActivityTaskManager\$Stub")
                .getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            val m = Class.forName("android.app.IActivityTaskManager")
                .getMethod("startActivityFromRecents", Int::class.javaPrimitiveType, Bundle::class.java)
            val code = m.invoke(atm, taskId, null as Bundle?) as Int
            code >= 0
        }.getOrDefault(false)
    }

    // ---- "lock the phone after unpinning" setting ---------------------------------------------------

    private const val EXIT_LOCK_KEY = "lock_to_app_exit_locked"

    /** The setting's value: 0 = off, 1 = on, -1 = never set (Android then treats it as on). */
    private fun readExitLock(context: Context): Int = runCatching {
        android.provider.Settings.Secure.getInt(context.contentResolver, EXIT_LOCK_KEY, -1)
    }.getOrDefault(-1)

    /** Writes the setting, with A's own permission first, then Shizuku. True when it now reads [value]. */
    private fun setExitLock(context: Context, value: Int): Boolean {
        runCatching { android.provider.Settings.Secure.putInt(context.contentResolver, EXIT_LOCK_KEY, value) }
        if (readExitLock(context) == value) return true
        runCatching { ShizukuShell.run("settings put secure $EXIT_LOCK_KEY $value") { } }
        return readExitLock(context) == value
    }

    /** Puts the setting back as it was: a value that was never set is removed again. */
    private fun restoreExitLock(context: Context, saved: Int) {
        if (saved == -1) {
            runCatching { ShizukuShell.run("settings delete secure $EXIT_LOCK_KEY") { } }
            if (readExitLock(context) != -1) setExitLock(context, 1)
        } else setExitLock(context, saved)
    }

    /** Resumes [task] where it was left. Returns how it was done, or null if nothing worked. Blocking. */
    private fun resume(context: Context, sp: SharedPreferences, task: Task): String? {
        if (task.id >= 0) {
            // 1. The call Recents itself makes for a tapped card.
            val accepted = startFromRecents(task.id)
            runCatching { DiagLog.note("Previous app: startActivityFromRecents(${task.id}) ${task.pkg} accepted=$accepted") }
            if (accepted) {
                // Android accepted it: a killed app is restarting. Give it time before trying anything else.
                if (waitFront(task, 3000L)) return how("Recents call (startActivityFromRecents)")
                runCatching { DiagLog.note("Previous app: accepted but ${task.pkg} not in front after 3 s") }
            }
            // 2. What Recents does for a live task: move it to the front with Home underneath.
            runCatching {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.moveTaskToFront(task.id, android.app.ActivityManager.MOVE_TASK_WITH_HOME)
            }
            if (waitFront(task, 800L)) return how("moveTaskToFront (with Home)")
            runCatching { DiagLog.note("Previous app: moveTaskToFront(${task.id}) did not bring ${task.pkg} to front") }
        }
        if (task.id >= 0) {
            // 3. Shell: bring it to the front by id, then let go of the pin. Letting go of a pin locks the phone when
            // "ask for the PIN before unpinning" is on. With the option "Stop the lock after unpinning" that setting is
            // switched off for the moment and put back after; if it cannot be switched off, this way is skipped.
            val fix = sp.getBoolean(PREF_PIN_FIX, false)
            val saved = if (fix) readExitLock(context) else 0
            val safe = !fix || saved == 0 || setExitLock(context, 0)
            if (safe) {
                try {
                    runCatching { ShizukuShell.run("am task lock ${task.id}") { } }
                    pause(250)
                    runCatching { ShizukuShell.run("am task lock stop") { } }
                    pause(if (fix) 400 else 250)
                } finally {
                    if (fix && saved != 0) restoreExitLock(context, saved)
                }
                if (waitFront(task, 1500L)) return how("am task lock")
                runCatching { DiagLog.note("Previous app: am task lock ${task.id} did not bring ${task.pkg} to front") }
            } else {
                how("pin way skipped: could not turn off lock after unpinning")
            }
        }
        // 4. Last resort, like MyGesture: the app's launcher intent. Only reached when the three exact ways failed,
        // which is the case of an app that was killed (no live task to resume), so the main screen is all there is.
        if (launchLikeMyGesture(context, task.pkg)) {
            runCatching { DiagLog.note("Previous app: fell back to launcher intent for ${task.pkg}") }
            return lastHow
        }
        lastHow = "nothing worked"
        return null
    }

    /**
     * The apps in the order they were last in front, newest first, from Android's usage events
     * (needs "Usage access"; no Shizuku). Same rule as the tracked list: an app that was in front for
     * under a moment before the next one took over (a picker, a trampoline) is dropped. Blocking.
     */
    @Suppress("DEPRECATION")
    fun usageHistory(context: Context): List<String> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyList()
        val now = System.currentTimeMillis()
        val events = runCatching { usm.queryEvents(now - 6L * 3600L * 1000L, now) }.getOrNull() ?: return emptyList()
        val e = UsageEvents.Event()
        val list = ArrayList<String>()
        var since = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType != UsageEvents.Event.MOVE_TO_FOREGROUND) continue
            val pkg = e.packageName ?: continue
            if (list.isNotEmpty() && list[0] == pkg) continue
            if (list.isNotEmpty() && e.timeStamp - since < DWELL_MS) list.removeAt(0)
            list.remove(pkg)
            list.add(0, pkg)
            since = e.timeStamp
        }
        return list
    }

    /** The app to go to from a history (newest first): not the one in front, not the launcher, not skipped, usable. */
    fun pickFromHistory(context: Context, h: List<String>, skip: Set<String>): String? {
        val own = if (allowA(context)) "" else context.packageName
        val home = homePackages(context)
        val cur = h.firstOrNull { it != own }
        return h.firstOrNull { it != own && it != cur && it !in home && it !in skip && it !in NEVER_PREVIOUS && isUsableApp(context, it) }
    }

    /** Every app seen lately, newest first: Shizuku's recents (only what Recents shows), else the tracked ones. Blocking. */
    fun detected(): List<String> {
        val out = LinkedHashSet<String>()
        val tasks = readRecents()
        if (tasks != null) tasks.filter { !it.hiddenFromRecents && it.action !in PICKER_ACTIONS }.forEach { out.add(it.pkg) }
        else historyCopy().forEach { out.add(it) }
        return out.toList()
    }

    /** What the Test button shows: the list found and the app it would go to. Blocking. */
    fun test(context: Context, sp: SharedPreferences): String {
        val skip = excluded(sp)
        val sb = StringBuilder()
        val tasks = readRecents()
        if (tasks != null) {
            sb.append("Shizuku recents (newest first):\n")
            val home = homePackages(context)
            tasks.forEachIndexed { n, t ->
                val why = when {
                    t.pkg in skip -> " (skipped by you)"
                    t.pkg == context.packageName -> " (A itself)"
                    t.pkg in home -> " (launcher)"
                    t.hiddenFromRecents -> " (hidden from Recents)"
                    t.action in PICKER_ACTIONS -> " (a picker, not an app)"
                    t.pkg in NEVER_PREVIOUS -> " (system window)"
                    !counts(context, t, home) -> " (not usable)"
                    else -> ""
                }
                sb.append("${n + 1}. ${t.pkg}${if (t.visible) " (visible)" else ""} task ${t.id}$why\n")
            }
            sb.append("\nWould go to: ${pick(context, tasks, skip)?.pkg ?: "nothing found"}\n")
        } else {
            sb.append("Shizuku recents: not available (Shizuku not running/allowed, or nothing readable).\n")
        }
        val h = historyCopy()
        sb.append("\nTracked apps (accessibility, newest first, tracking is ${if (tracking(sp)) "ON" else "OFF"}):\n")
        if (h.isEmpty()) sb.append("(empty)\n") else h.forEachIndexed { n, p -> sb.append("${n + 1}. $p${if (p in skip) " (skipped)" else ""}\n") }
        val u = usageHistory(context)
        sb.append("\nUsage events (newest first, needs Usage access):\n")
        if (u.isEmpty()) sb.append("(empty)\n") else u.take(10).forEachIndexed { n, p -> sb.append("${n + 1}. $p${if (p in skip) " (skipped)" else ""}\n") }
        sb.append("Would go to (usage events): ${pickFromHistory(context, u, skip) ?: "nothing found"}\n")
        sb.append("\nLast way a task was brought back: ${lastHow.ifEmpty { "(none yet)" }}")
        return sb.toString().trim()
    }

    /**
     * Without Shizuku: the system's quick-switch, Recents pressed twice in a row through the accessibility
     * service. Android returns to the app that was in front before, as it was left. False when the service is off.
     */
    private fun quickSwitch(): Boolean {
        val service = a.a.service.OverlayRuntime.accessibilityService ?: return false
        if (!service.performSystemAction(HandlerActions.RECENTS)) return false
        pause(170)
        service.performSystemAction(HandlerActions.RECENTS)
        how("accessibility quick-switch (Recents twice)")
        return true
    }

    /**
     * MyGesture's way to open an app: its MAIN/LAUNCHER intent for the first launcher activity, flags
     * NEW_TASK | RESET_TASK_IF_NEEDED (0x10200000), started through a PendingIntent. An app that is already running
     * comes back with its task as it was. Falls back to a plain startActivity. True when something was started.
     */
    private fun launchLikeMyGesture(context: Context, pkg: String): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
        val name = runCatching {
            context.packageManager.queryIntentActivities(i, android.content.pm.PackageManager.GET_META_DATA).firstOrNull()?.activityInfo?.name
        }.getOrNull()
        if (name != null) i.setComponent(android.content.ComponentName(pkg, name))
        else context.packageManager.getLaunchIntentForPackage(pkg)?.component?.let { i.setComponent(it) } ?: return false
        i.setFlags(0x10200000)
        val ok = runCatching {
            android.app.PendingIntent.getActivity(
                context.applicationContext, 0, i,
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT,
            ).send()
        }.isSuccess || runCatching { context.startActivity(i) }.isSuccess
        if (ok) how("launcher intent like MyGesture ($pkg)")
        return ok
    }

    /**
     * Goes to the previous app. Blocking work runs on its own thread; [report] is called from it
     * with a short message when nothing could be done.
     */
    fun go(context: Context, sp: SharedPreferences, report: (String) -> Unit) {
        Thread {
            val skip = excluded(sp)
            val tasks = readRecents()
            val target = tasks?.let { pick(context, it, skip) }
            // One line in A's report with what the list held and what was chosen, so a wrong answer can be traced.
            runCatching {
                val home = homePackages(context)
                val line = tasks?.take(10)?.joinToString("; ") { t ->
                    t.pkg + "#" + t.id + " u" + t.user + (if (t.visible) " vis" else "") +
                        (if (t.hiddenFromRecents) " hidden" else "") + (if (t.pkg in home) " home" else "") +
                        (if (t.pkg in skip) " skipped" else "") + (if (t.type.isNotEmpty() && t.type != "standard") " " + t.type else "") +
                        (if (!counts(context, t, home)) " NO" else "")
                } ?: "no recents (Shizuku not ready or nothing readable)"
                DiagLog.note("Previous app [allowA=" + allowA(context) + " skip=" + skip.joinToString(",") + "]: " + line + " -> " + (target?.pkg ?: "nothing"))
            }
            if (target != null) {
                if (resume(context, sp, target) != null) return@Thread
                // Nothing brought the task back: say so instead of opening something else.
                val msg = "Previous app: could not bring back ${target.pkg}"
                if (sp.getBoolean(PREF_TOAST, false)) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } else report(msg)
                return@Thread
            }
            // No Shizuku recents: never a launcher icon (that lands on the app's main screen). Only when the
            // usage history shows a valid previous app, use the system's own quick-switch (Recents pressed twice).
            if (tasks == null) {
                val tracked = historyCopy()
                val h = if (tracked.size >= 2) tracked else usageHistory(context).ifEmpty { tracked }
                val pkg = pickFromHistory(context, h, skip)
                runCatching { DiagLog.note("Previous app (no Shizuku) [allowA=" + allowA(context) + " skip=" + skip.joinToString(",") + "]: history " + h.take(6).joinToString(",") + " -> " + (pkg ?: "nothing")) }
                if (pkg != null && launchLikeMyGesture(context, pkg)) return@Thread
            }
            val msg = "Previous app: nothing found (use Shizuku, or allow Usage access)"
            if (sp.getBoolean(PREF_TOAST, false)) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                }
            } else report(msg)
        }.start()
    }
}
