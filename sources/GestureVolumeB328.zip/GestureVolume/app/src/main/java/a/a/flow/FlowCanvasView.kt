package a.a.flow

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** How a block looks: its name, its colour and the line under the name. */
object BlockStyle {
    const val W = 150f
    const val H = 58f
    const val BW = 110f
    const val BH = 34f

    fun width(s: Step) = if (s.type == Step.BEGIN) BW else W
    fun height(s: Step) = if (s.type == Step.BEGIN) BH else H

    fun title(s: Step): String = when (s.type) {
        Step.BEGIN -> "Start of the script"
        Step.IF -> "Decision"
        Step.WHEN -> "When"
        Step.ONLYIF -> "Only if"
        Step.REPEAT -> "Loop"
        Step.WAIT -> "Delay"
        Step.MESSAGE -> "Show message"
        Step.LAUNCH -> "Open app"
        Step.INTENT -> if (s.b == "raw") "Run raw shortcut" else "Send intent"
        Step.SET -> "Set variable"
        Step.HTTP -> "HTTP request"
        Step.RUN -> "Run script"
        Step.STOP -> "Stop"
        Step.NOTE -> "Note"
        Step.SHELL -> "Shell command"
        Step.SHIZUKU -> "Shizuku command"
        Step.BROADCAST -> "Send broadcast"
        Step.OCRWAIT -> "Read with OCR and wait"
        Step.COUNTDOWN -> "Countdown"
        Step.FIELDWAIT -> "Wait for a field"
        Step.RATELIMIT -> "Limit how often"
        Step.ACTION -> NativeActions.find(s.a)?.label ?: "Device action"
        else -> s.type
    }

    fun body(s: Step): String = when (s.type) {
        Step.SHELL, Step.SHIZUKU -> s.a
        Step.WAIT -> if (s.c == "expr") "(${s.a}) ms" else s.a + " ms"
        Step.MESSAGE -> s.a
        Step.LAUNCH -> if (s.c.isEmpty()) s.a else s.a + " / " + s.c.removePrefix(s.a)
        Step.INTENT, Step.RUN, Step.NOTE -> s.a
        Step.SET -> if (s.a.isEmpty()) "" else "${s.a} = ${s.b}"
        Step.IF -> if (s.b == "expr") s.a else "${s.a} ${s.b} ${s.c}".trim()
        Step.REPEAT -> if (s.b == "each") "each ${s.c.ifEmpty { "item" }} in ${s.a}" else s.a + " times"
        Step.HTTP -> s.a
        Step.BROADCAST -> s.a
        Step.ACTION -> s.b
        Step.OCRWAIT -> s.a.removePrefix("box:") + " (" + s.b.substringBefore(':') + ")"
        Step.COUNTDOWN -> s.a + " ms"
        Step.FIELDWAIT -> s.a + " ms"
        Step.WHEN -> WhenEvents.eventLabel(s.a, s.d) + " - " + WhenEvents.modeLabel(s.b) + WhenEvents.fromLabel(s.f)
        Step.ONLYIF -> WhenEvents.onlyLabel(s.a, s.b)
        Step.RATELIMIT -> s.a + ": " + s.b + " ms"
        else -> ""
    }.replace('\n', ' ')

    fun color(s: Step): Int = when (s.type) {
        Step.BEGIN -> 0xFF2E7D32.toInt()
        Step.IF, Step.ONLYIF -> 0xFFEF6C00.toInt()
        Step.WHEN -> 0xFFD81B60.toInt()
        Step.REPEAT -> 0xFF1E88E5.toInt()
        Step.WAIT -> 0xFF8E24AA.toInt()
        Step.MESSAGE -> 0xFF00897B.toInt()
        Step.STOP -> 0xFFC62828.toInt()
        Step.NOTE -> 0xFF757575.toInt()
        Step.SET -> 0xFF6D4C41.toInt()
        Step.RUN -> 0xFF5E35B1.toInt()
        Step.HTTP -> 0xFF0277BD.toInt()
        Step.SHELL, Step.SHIZUKU, Step.BROADCAST, Step.INTENT, Step.LAUNCH -> 0xFF455A64.toInt()
        else -> 0xFF3949AB.toInt()
    }

    /** Names for the two outputs of a block, or null for plain ones. */
    fun bottomLabel(s: Step): String? = when (s.type) { Step.IF, Step.ONLYIF -> "Yes"; Step.REPEAT -> "Done"; else -> null }
    fun rightLabel(s: Step): String? = when (s.type) { Step.IF, Step.ONLYIF -> "No"; Step.REPEAT -> "Each time"; else -> null }
}

/**
 * The free canvas: drag blocks anywhere, pan with one finger on the background, pinch to zoom,
 * drag from a block's bottom or right dot to another block to connect. Nothing is kept once the
 * editor closes. World units are about one dp.
 */
class FlowCanvasView(context: Context, val model: GraphModel) : View(context) {
    interface Listener {
        fun onTap(id: Int)
        fun onLongPress(id: Int)
        fun onBackgroundLongPress(wx: Float, wy: Float)
        /** A connection was dragged and let go on empty space. */
        fun onDropEmpty(fromId: Int, slot: Int, wx: Float, wy: Float)
        /** Something moved or was connected: save it. */
        fun onChanged()
    }

    var listener: Listener? = null

    private val dp = resources.displayMetrics.density
    private var scale = 1f
    private var panX = 0f
    private var panY = 0f
    private var fitted = false

    /** Run state per block: Interpreter.RUNNING / OK / FAILED. */
    private val states = HashMap<Int, Int>()
    private val errors = HashMap<Int, String>()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private val uiHandler = Handler(Looper.getMainLooper())
    private var mode = 0   // 0 none, 1 pending block, 2 drag block, 3 drag link, 4 pan, 5 pinch, 6 long-pressed
    private var hitId = 0
    private var linkSlot = 0
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var fingerX = 0f
    private var fingerY = 0f
    private val slop = 8f * dp
    private val longPress = Runnable {
        if (mode == 1) { mode = 6; listener?.onLongPress(hitId) }
        else if (mode == 4) { mode = 6; listener?.onBackgroundLongPress(sx2w(downX), sy2w(downY)) }
    }

    private val scaler = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val ns = (scale * d.scaleFactor).coerceIn(0.3f, 2.5f)
            val k = ns / scale
            panX = d.focusX - (d.focusX - panX) * k
            panY = d.focusY - (d.focusY - panY) * k
            scale = ns
            invalidate()
            return true
        }
    })

    // ---- coordinates -------------------------------------------------------------------------
    private fun w2sx(x: Float) = x * dp * scale + panX
    private fun w2sy(y: Float) = y * dp * scale + panY
    private fun sx2w(x: Float) = (x - panX) / (dp * scale)
    private fun sy2w(y: Float) = (y - panY) / (dp * scale)

    /** The middle of what is on screen, in world units. */
    fun centerWorldX() = sx2w(width / 2f)
    fun centerWorldY() = sy2w(height / 2f)

    // ---- run highlight -------------------------------------------------------------------------
    fun clearRun() { states.clear(); errors.clear(); postInvalidate() }

    fun setState(id: Int, state: Int, msg: String) {
        states[id] = state
        if (state == Interpreter.FAILED) errors[id] = msg else errors.remove(id)
        postInvalidate()
    }

    /** Fits all blocks on screen (and is what the editor shows first). */
    fun fit() {
        val bl = model.blocks
        if (bl.isEmpty() || width == 0) return
        val minX = bl.minOf { it.x }
        val minY = bl.minOf { it.y }
        val maxX = bl.maxOf { it.x + BlockStyle.width(it) }
        val maxY = bl.maxOf { it.y + BlockStyle.height(it) }
        val ww = (maxX - minX + 48f) * dp
        val hh = (maxY - minY + 48f) * dp
        scale = min(1f, min(width / ww, height / hh)).coerceIn(0.3f, 1f)
        panX = 24f * dp * scale + (width - (maxX - minX) * dp * scale) / 2f - minX * dp * scale
        panY = 24f * dp * scale - minY * dp * scale
        fitted = true
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!fitted && w > 0 && h > 0) fit()
    }

    // ---- hit tests -----------------------------------------------------------------------------
    private fun bottomX(s: Step) = s.x + BlockStyle.width(s) / 2f
    private fun bottomY(s: Step) = s.y + BlockStyle.height(s)
    private fun rightX(s: Step) = s.x + BlockStyle.width(s)
    private fun rightY(s: Step) = s.y + BlockStyle.height(s) / 2f

    private fun hasBottom(s: Step) = !FlowGraph.endsFlow(s)
    private fun hasRight(s: Step) = !FlowGraph.endsFlow(s) && s.type != Step.BEGIN && s.type != Step.NOTE

    /** Returns id * 2 + slot of the output dot at the screen point, or -1. */
    private fun handleAt(sx: Float, sy: Float): Int {
        val r = 22f * dp
        var best = -1
        var bestD = Float.MAX_VALUE
        for (s in model.blocks) {
            if (hasBottom(s)) {
                val d = hypot(sx - w2sx(bottomX(s)), sy - w2sy(bottomY(s)))
                if (d < r && d < bestD) { bestD = d; best = s.id * 2 }
            }
            if (hasRight(s)) {
                val d = hypot(sx - w2sx(rightX(s)), sy - w2sy(rightY(s)))
                if (d < r && d < bestD) { bestD = d; best = s.id * 2 + 1 }
            }
        }
        return best
    }

    private fun blockAt(sx: Float, sy: Float): Int {
        val wx = sx2w(sx)
        val wy = sy2w(sy)
        val bl = model.blocks
        for (i in bl.indices.reversed()) {
            val s = bl[i]
            if (wx >= s.x && wx <= s.x + BlockStyle.width(s) && wy >= s.y && wy <= s.y + BlockStyle.height(s)) return s.id
        }
        return 0
    }

    // ---- touch ---------------------------------------------------------------------------------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (scaler.isInProgress || e.pointerCount > 1) {
            uiHandler.removeCallbacks(longPress)
            if (mode != 5) {
                if (mode == 2) listener?.onChanged()
                mode = 5
            }
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) mode = 0
            return true
        }
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = x; downY = y; lastX = x; lastY = y; fingerX = x; fingerY = y
                parent?.requestDisallowInterceptTouchEvent(true)
                val h = handleAt(x, y)
                if (h >= 0) {
                    mode = 3; hitId = h / 2; linkSlot = h % 2
                } else {
                    val b = blockAt(x, y)
                    if (b != 0) { mode = 1; hitId = b } else { mode = 4; hitId = 0 }
                    uiHandler.postDelayed(longPress, 500)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val moved = hypot(x - downX, y - downY) > slop
                if (moved && (mode == 1 || mode == 4)) uiHandler.removeCallbacks(longPress)
                if (mode == 1 && moved) { model.checkpoint(); mode = 2 }
                when (mode) {
                    2 -> {
                        val s = model.get(hitId)
                        if (s != null) model.move(hitId, s.x + (x - lastX) / (dp * scale), s.y + (y - lastY) / (dp * scale))
                    }
                    4 -> if (moved) { panX += x - lastX; panY += y - lastY }
                    3 -> { fingerX = x; fingerY = y }
                }
                lastX = x; lastY = y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                uiHandler.removeCallbacks(longPress)
                when (mode) {
                    1 -> listener?.onTap(hitId)
                    2 -> listener?.onChanged()
                    3 -> {
                        val target = blockAt(x, y)
                        if (target != 0 && target != hitId) {
                            model.checkpoint()
                            if (model.connect(hitId, linkSlot, target)) listener?.onChanged() else model.undo()
                        } else if (target == 0 && hypot(x - downX, y - downY) > slop) {
                            listener?.onDropEmpty(hitId, linkSlot, sx2w(x), sy2w(y))
                        }
                    }
                }
                mode = 0
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(longPress)
                if (mode == 2) listener?.onChanged()
                mode = 0
                invalidate()
            }
        }
        return true
    }

    // ---- drawing -------------------------------------------------------------------------------
    override fun onDraw(c: Canvas) {
        c.drawColor(0xFFECEFF1.toInt())
        drawGrid(c)
        val by = HashMap<Int, Step>()
        model.blocks.forEach { by[it.id] = it }
        incomingCache = model.blocks.flatMap { listOf(it.n, it.r) }.filter { it != 0 }.toSet()
        // connections first, so blocks sit on top
        for (s in model.blocks) {
            if (s.n != 0) by[s.n]?.let { drawLink(c, s, 0, it) }
            if (s.r != 0) by[s.r]?.let { drawLink(c, s, 1, it) }
        }
        if (mode == 3) {
            val s = by[hitId]
            if (s != null) {
                val sx = if (linkSlot == 0) w2sx(bottomX(s)) else w2sx(rightX(s))
                val sy = if (linkSlot == 0) w2sy(bottomY(s)) else w2sy(rightY(s))
                stroke.color = 0xFF1565C0.toInt(); stroke.strokeWidth = 2.5f * dp
                c.drawLine(sx, sy, fingerX, fingerY, stroke)
                dot.color = 0xFF1565C0.toInt()
                c.drawCircle(fingerX, fingerY, 6f * dp, dot)
            }
        }
        for (s in model.blocks) drawBlock(c, s)
    }

    private fun drawGrid(c: Canvas) {
        if (scale < 0.5f) return
        val step = 40f
        val x0 = (sx2w(0f) / step).toInt() - 1
        val x1 = (sx2w(width.toFloat()) / step).toInt() + 1
        val y0 = (sy2w(0f) / step).toInt() - 1
        val y1 = (sy2w(height.toFloat()) / step).toInt() + 1
        dot.color = 0xFFCFD8DC.toInt()
        val r = 1.5f * dp * scale
        for (gx in x0..x1) for (gy in y0..y1) c.drawCircle(w2sx(gx * step), w2sy(gy * step), r, dot)
    }

    private fun drawLink(c: Canvas, from: Step, slot: Int, to: Step) {
        val sx = w2sx(if (slot == 0) bottomX(from) else rightX(from))
        val sy = w2sy(if (slot == 0) bottomY(from) else rightY(from))
        val tx = w2sx(to.x + BlockStyle.width(to) / 2f)
        val ty = w2sy(to.y)
        val d = max(40f * dp * scale, abs(ty - sy) / 2f)
        path.reset()
        path.moveTo(sx, sy)
        if (slot == 0) path.cubicTo(sx, sy + d, tx, ty - d, tx, ty)
        else path.cubicTo(sx + d, sy, tx, ty - d, tx, ty)
        val col = when {
            (from.type == Step.IF || from.type == Step.ONLYIF) && slot == 0 -> 0xFF2E7D32.toInt()
            (from.type == Step.IF || from.type == Step.ONLYIF) && slot == 1 -> 0xFFC62828.toInt()
            else -> 0xFF607D8B.toInt()
        }
        stroke.color = col
        stroke.strokeWidth = max(1.5f, 2.5f * dp * scale)
        c.drawPath(path, stroke)
        // arrow head on the input
        val a = 7f * dp * scale
        path.reset()
        path.moveTo(tx, ty)
        path.lineTo(tx - a, ty - a * 1.6f)
        path.lineTo(tx + a, ty - a * 1.6f)
        path.close()
        fill.color = col
        fill.style = Paint.Style.FILL
        c.drawPath(path, fill)
    }

    private fun drawBlock(c: Canvas, s: Step) {
        val l = w2sx(s.x)
        val t = w2sy(s.y)
        val w = BlockStyle.width(s) * dp * scale
        val h = BlockStyle.height(s) * dp * scale
        val rad = 8f * dp * scale
        val state = states[s.id]
        rect.set(l, t, l + w, t + h)
        // soft shadow
        fill.style = Paint.Style.FILL
        fill.color = 0x22000000
        c.drawRoundRect(rect.left + 2f * dp, rect.top + 3f * dp, rect.right + 2f * dp, rect.bottom + 3f * dp, rad, rad, fill)
        fill.color = BlockStyle.color(s)
        c.drawRoundRect(rect, rad, rad, fill)
        // border shows the run state
        val border = when (state) {
            Interpreter.RUNNING -> 0xFFFFD600.toInt()
            Interpreter.OK -> 0xFF69F0AE.toInt()
            Interpreter.FAILED -> 0xFFFF1744.toInt()
            else -> 0x33000000
        }
        stroke.color = border
        stroke.strokeWidth = if (state == null) 1f * dp else 4f * dp * scale.coerceAtLeast(0.6f)
        c.drawRoundRect(rect, rad, rad, stroke)

        // text, clipped to the block
        val pad = 8f * dp * scale
        val tw = (w - pad * 2).coerceAtLeast(1f)
        c.save()
        c.clipRect(rect)
        text.typeface = Typeface.DEFAULT_BOLD
        text.color = Color.WHITE
        text.textSize = 13f * dp * scale
        val title = TextUtils.ellipsize(BlockStyle.title(s), text, tw, TextUtils.TruncateAt.END).toString()
        val body = BlockStyle.body(s)
        if (body.isEmpty()) {
            c.drawText(title, l + pad, t + h / 2f + text.textSize * 0.35f, text)
        } else {
            c.drawText(title, l + pad, t + h * 0.40f, text)
            text.typeface = Typeface.DEFAULT
            text.color = 0xDDFFFFFF.toInt()
            text.textSize = 11f * dp * scale
            val b = TextUtils.ellipsize(body, text, tw, TextUtils.TruncateAt.END).toString()
            c.drawText(b, l + pad, t + h * 0.78f, text)
        }
        c.restore()

        // connection dots
        val r = 6f * dp * scale
        if (s.type != Step.BEGIN) {
            drawDot(c, l + w / 2f, t, r, s.id in incomingCache)
        }
        if (hasBottom(s)) {
            drawDot(c, l + w / 2f, t + h, r, s.n != 0)
            BlockStyle.bottomLabel(s)?.let { label(c, it, l + w / 2f + r + 3f * dp * scale, t + h + 11f * dp * scale) }
        }
        if (hasRight(s)) {
            drawDot(c, l + w, t + h / 2f, r, s.r != 0)
            BlockStyle.rightLabel(s)?.let { label(c, it, l + w + r + 3f * dp * scale, t + h / 2f - 4f * dp * scale) }
        }

        // why it failed, under the block
        val err = errors[s.id]
        if (state == Interpreter.FAILED && err != null) {
            val ew = (190f * dp * scale).toInt().coerceAtLeast(40)
            text.typeface = Typeface.DEFAULT
            text.color = Color.WHITE
            text.textSize = 11f * dp * scale
            val lay = StaticLayout.Builder.obtain(err, 0, err.length, text, ew)
                .setMaxLines(4).setEllipsize(TextUtils.TruncateAt.END).build()
            val bx = l
            val by = t + h + 14f * dp * scale
            fill.color = 0xFFD50000.toInt()
            c.drawRoundRect(bx, by, bx + ew + 12f * dp * scale, by + lay.height + 12f * dp * scale, 6f * dp * scale, 6f * dp * scale, fill)
            c.save()
            c.translate(bx + 6f * dp * scale, by + 6f * dp * scale)
            lay.draw(c)
            c.restore()
        }
    }

    private var incomingCache: Set<Int> = emptySet()

    private fun drawDot(c: Canvas, cx: Float, cy: Float, r: Float, filled: Boolean) {
        dot.color = if (filled) 0xFF263238.toInt() else Color.WHITE
        c.drawCircle(cx, cy, r, dot)
        stroke.color = 0xFF263238.toInt()
        stroke.strokeWidth = 1.5f * dp
        c.drawCircle(cx, cy, r, stroke)
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float) {
        text.typeface = Typeface.DEFAULT_BOLD
        text.color = 0xFF37474F.toInt()
        text.textSize = 10f * dp * scale
        c.drawText(s, x, y, text)
    }

    override fun onDetachedFromWindow() {
        uiHandler.removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }
}
