package a.a.utils

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.Process
import a.a.service.OverlayRuntime

/**
 * Starts an activity so that it really opens. Android silently drops an activity started from the
 * background (no error, nothing happens) unless the app counts as visible at that moment, and it
 * refuses an activity that its app has not exported. An app's own shortcuts (the kind a launcher
 * shows on a long press) very often point at such an activity, because launchers reach them through
 * a privileged path that other apps do not have. The shell (Shizuku) is exempt from both rules, so
 * when Shizuku is ready every start of another app's activity goes through `am start`; otherwise
 * through the accessibility service, then A itself. Nothing runs or stays in memory until an
 * activity is launched.
 */
object AppStarter {
    private val main = Handler(Looper.getMainLooper())

    /** Why the last plain start failed, in words for the screen (null after a success). */
    @Volatile var lastFailure: String? = null
        private set

    /** True for the intent a launcher icon sends: MAIN + LAUNCHER, which is what getLaunchIntentForPackage builds. */
    fun isAppLaunch(i: Intent): Boolean =
        i.action == Intent.ACTION_MAIN && i.categories?.contains(Intent.CATEGORY_LAUNCHER) == true

    /**
     * Whether the shell may start this intent for us. The shell sees the intent only as text, so it
     * must survive being written as an `intent:` URI: only plain extras, no clip, no permission
     * grants (the shell does not hold A's URI permissions), and nothing aimed at A's own screens.
     */
    fun shellCanStart(context: Context, i: Intent): Boolean {
        if (i.clipData != null) return false
        val grants = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        if (i.flags and grants != 0) return false
        val scheme = i.data?.scheme
        if (scheme == "content" || scheme == "file") return false
        val target = i.component?.packageName ?: i.`package`
        if (target == context.packageName) return false
        val extras = i.extras ?: return true
        @Suppress("DEPRECATION")
        return extras.keySet().all { k ->
            when (extras.get(k)) {
                is String, is Boolean, is Byte, is Char, is Double, is Float, is Int, is Long, is Short -> true
                else -> false
            }
        }
    }

    /** Returns true when a start was attempted; failures of the shell route fall back to a normal start. */
    fun start(context: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        lastFailure = null
        if ((isAppLaunch(intent) || shellCanStart(context, intent)) && ShizukuShell.isReady()) {
            val uri = runCatching { intent.toUri(Intent.URI_INTENT_SCHEME) }.getOrNull()
            if (uri != null) {
                val cmd = "am start '" + uri.replace("'", "'\\''") + "'"
                Thread {
                    var out = ""
                    val code = runCatching { ShizukuShell.run(cmd) { out += it + "\n" } }.getOrDefault(-1)
                    DiagLog.note("am start exit=$code out=${out.trim().take(200)}")
                    if (code != 0 || out.contains("Error", ignoreCase = true)) main.post { plain(context, intent) }
                }.start()
                return true
            }
        }
        return plain(context, intent)
    }

    /**
     * Why Android will refuse this intent for any app that is not its owner, or null when it may
     * work. Decided from the target's own manifest, so it needs no Shizuku and is the same on every
     * phone. A target that cannot be looked up is not judged: it is simply tried.
     */
    fun closedReason(context: Context, i: Intent): String? {
        val cn = i.component ?: return null
        val ai = runCatching { context.packageManager.getActivityInfo(cn, 0) }.getOrNull() ?: return null
        if (ai.applicationInfo.uid == Process.myUid()) return null
        if (!ai.exported) return "not exported"
        val perm = ai.permission
        if (perm != null && context.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) return "needs the permission $perm"
        return null
    }

    /** Opens the app the intent belongs to by its launcher icon, which every app allows. */
    private fun openOwnerApp(context: Context, intent: Intent): Boolean {
        val pkg = intent.component?.packageName ?: intent.`package` ?: return false
        val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            (OverlayRuntime.accessibilityService ?: context).startActivity(launch); true
        } catch (_: Exception) { false }
    }

    private fun plain(context: Context, intent: Intent): Boolean {
        // From a screen of A that is showing, Android always allows the start; otherwise from the
        // accessibility service (A's windows count as visible), then A itself.
        val svc: Context = if (context is Activity) context else OverlayRuntime.accessibilityService ?: context
        // An activity its app keeps closed to other apps cannot be started by A at all, however it
        // is started; only the shell (Shizuku) may. Say so, and open the app itself instead of nothing.
        closedReason(context, intent)?.let { why ->
            DiagLog.note("shortcut target closed ($why): ${intent.component?.flattenToShortString()}")
            val opened = openOwnerApp(context, intent)
            lastFailure = "That app keeps this shortcut closed to other apps ($why). " +
                (if (opened) "Its app was opened instead. " else "") + "Shizuku opens it directly."
            return false
        }
        return try {
            svc.startActivity(intent)
            true
        } catch (first: Exception) {
            try {
                context.startActivity(intent); true
            } catch (e: Exception) {
                DiagLog.note("start failed: ${e.javaClass.simpleName}: ${e.message?.take(160)}")
                lastFailure = when (e) {
                    is SecurityException -> "That app does not let other apps open this shortcut. Shizuku opens it directly."
                    is android.content.ActivityNotFoundException -> "The app or screen of this shortcut is not installed (or was renamed by an update). Pick the shortcut again."
                    else -> null
                }
                false
            }
        }
    }
}
