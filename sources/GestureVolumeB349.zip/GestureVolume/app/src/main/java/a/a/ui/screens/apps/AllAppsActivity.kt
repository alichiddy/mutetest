package a.a.ui.screens.apps

import a.a.utils.AppStarter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.CardWindow
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SliderRow
import a.a.ui.screens.strip.SwitchRow
import androidx.compose.material3.Switch
import a.a.ui.motion.TextButton
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import a.a.strip.ActionSaver
import a.a.ui.components.ChoiceChip
import a.a.ui.screens.deck.AppKinds
import a.a.utils.PreviousApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * One app in the list. [cls] is the launcher activity of an app that is on; it is empty for an app that is
 * hidden, disabled, frozen or removed (those are opened through Hail). [ri] is null for those too.
 */
class AppEntry(
    val label: String, val pkg: String, val cls: String, val kind: Int,
    val ai: ApplicationInfo, val ri: ResolveInfo?,
)

/**
 * A window with every app, with the same four filters as "App icon" and "Open with Hail" (User, User
 * hidden/disabled, System, System hidden/disabled), a search box and a grid you can size yourself.
 * The filters and the grid are kept in this window's own settings (not shared with the other two pickers).
 * Tap an app to open it. Nothing runs until the window is open (zero idle cost); icons are drawn only
 * for the cells on screen.
 */
open class AllAppsActivity : ComponentActivity() {
    /** True in [AllAppsPickActivity]: a tap hands the app back to the window that asked, nothing is opened. */
    protected open val picking: Boolean = false

    /** Goes up each time the window comes back (after App info or an uninstall) so the list is read again. */
    private val resumeTick = mutableIntStateOf(0)
    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                AllAppsScreen(
                    reload = resumeTick.intValue,
                    onOpen = { e -> open(e) },
                    onInfo = { e -> appInfo(e) },
                    onUninstall = { e -> uninstall(e) },
                    pick = picking,
                    onBack = { finish() },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (started) resumeTick.intValue = resumeTick.intValue + 1
        started = true
    }

    /** The system's App info page of the app: works for hidden and disabled apps too. */
    private fun appInfo(e: AppEntry) {
        val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", e.pkg, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { startActivity(i) }.isFailure) Toast.makeText(this, "Could not open App info", Toast.LENGTH_SHORT).show()
    }

    /**
     * Uninstall, hidden or disabled apps included. With Shizuku running it is done straight away
     * (pm uninstall for this user); otherwise the system's own uninstall question is shown.
     */
    private fun uninstall(e: AppEntry) {
        if (a.a.utils.ShizukuShell.isReady()) {
            Thread {
                var last = ""
                val code = runCatching {
                    a.a.utils.ShizukuShell.run("pm uninstall --user 0 " + e.pkg) { line -> if (line.isNotBlank()) last = line }
                }.getOrElse { last = it.message ?: "failed"; -1 }
                runOnUiThread {
                    val ok = code == 0 && last.contains("Success", ignoreCase = true)
                    Toast.makeText(this, if (ok) e.label + " removed" else "Could not remove " + e.label + (if (last.isNotEmpty()) ": " + last else ""), Toast.LENGTH_LONG).show()
                    resumeTick.intValue = resumeTick.intValue + 1
                }
            }.start()
            return
        }
        val i = Intent(Intent.ACTION_DELETE, android.net.Uri.fromParts("package", e.pkg, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { startActivity(i) }.isFailure) Toast.makeText(this, "Could not start the uninstall for " + e.label, Toast.LENGTH_SHORT).show()
    }

    private fun open(e: AppEntry) {
        if (picking) {
            setResult(RESULT_OK, Intent().putExtra("pkg", e.pkg).putExtra("label", e.label))
            finish()
            return
        }
        val ok = if (e.cls.isNotEmpty()) {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(e.pkg, e.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            runCatching { startActivity(i) }.isSuccess
        } else {
            // Hidden, disabled, frozen or removed: Hail wakes it and opens it.
            val a = ActionSaver.hailAction(e.pkg).removePrefix("Intent:")
            runCatching { startActivity(AppStarter.parse(a)) }.isSuccess
        }
        if (ok) finish()
        else Toast.makeText(
            this,
            if (e.cls.isEmpty()) "Could not open " + e.label + " (Hail is needed for hidden or disabled apps)" else "Could not open " + e.label,
            Toast.LENGTH_SHORT,
        ).show()
    }
}

/**
 * The same window, opened by a script block to choose an app: a tap returns the package (result "pkg")
 * and closes the window. Its own entry in the manifest (no document mode), so the answer always reaches
 * the block that asked. Nothing runs until it is opened.
 */
class AllAppsPickActivity : AllAppsActivity() {
    override val picking: Boolean = true
}

private const val PREFS = "MyPrefs"
private const val KEY_KINDS = "allAppsKinds"
private const val KEY_COLS = "allAppsCols"
private const val KEY_ICON = "allAppsIconDp"
private const val KEY_TEXT = "allAppsTextSp"
private const val KEY_LINES = "allAppsLines"
private const val KEY_LINEGAP = "allAppsLineGap"
private const val KEY_TAPMENU = "allAppsTapMenu"

/**
 * Every app of the chosen [kinds], sorted by name. An app that is on needs a launcher entry (one per entry,
 * as a launcher shows them); an app that is off in any way is listed once. No icons here. Blocking.
 */
private fun loadApps(context: Context, kinds: Int): List<AppEntry> {
    if (kinds and AppKinds.ALL == 0) return emptyList()
    val pm = context.packageManager
    val flags = PackageManager.MATCH_DISABLED_COMPONENTS or PackageManager.MATCH_UNINSTALLED_PACKAGES
    @Suppress("DEPRECATION")
    val visible: Set<String>? = runCatching { pm.getInstalledApplications(0).map { it.packageName }.toHashSet() }.getOrNull()
    val out = ArrayList<AppEntry>()
    val seen = HashSet<String>()
    val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolved = runCatching { pm.queryIntentActivities(main, 0) }.getOrDefault(emptyList())
    for (ri in resolved) {
        val ai = ri.activityInfo ?: continue
        val pkg = ai.packageName
        if (pkg == context.packageName) continue
        seen.add(pkg)
        val app = ai.applicationInfo
        val kind = AppKinds.kindOf(pm, app, visible)
        if (kind and kinds == 0) continue
        val off = kind == AppKinds.USER_HIDDEN || kind == AppKinds.SYSTEM_HIDDEN
        val label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg) + (if (off) " (hidden)" else "")
        out.add(AppEntry(label, pkg, if (off) "" else ai.name, kind, app, if (off) null else ri))
    }
    @Suppress("DEPRECATION")
    val all = runCatching { pm.getInstalledApplications(flags) }.getOrDefault(emptyList())
    for (app in all) {
        val pkg = app.packageName
        if (pkg == context.packageName || pkg in seen) continue
        if (!AppKinds.isOff(pm, app, visible)) continue   // on, but no launcher entry: nothing to open
        val kind = AppKinds.kindOf(pm, app, visible)
        if (kind and kinds == 0) continue
        val note = if (!app.enabled) " (disabled)"
        else if ((app.flags and ApplicationInfo.FLAG_INSTALLED) == 0) " (removed)" else " (hidden)"
        val label = runCatching { app.loadLabel(pm).toString() }.getOrDefault(pkg) + note
        out.add(AppEntry(label, pkg, "", kind, app, null))
    }
    return out.sortedBy { it.label.lowercase() }
}

@Composable
private fun AppIcon(e: AppEntry, sizeDp: Int) {
    val ctx = LocalContext.current
    val px = (sizeDp * ctx.resources.displayMetrics.density).toInt().coerceAtLeast(1)
    val bmp by produceState<ImageBitmap?>(null, e.pkg, e.cls, px) {
        value = withContext(Dispatchers.Default) {
            runCatching {
                val pm = ctx.packageManager
                val d = e.ri?.loadIcon(pm) ?: e.ai.loadIcon(pm)
                d.toBitmap(px, px).asImageBitmap()
            }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(bitmap = b, contentDescription = null, modifier = Modifier.size(sizeDp.dp))
    else Spacer(Modifier.size(sizeDp.dp))
}

@Composable
private fun GridSlider(label: String, shown: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label + ": " + shown, fontSize = 13.sp)
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.roundToInt().coerceIn(min, max)) },
            valueRange = min.toFloat()..max.toFloat(), steps = (max - min - 1).coerceAtLeast(0),
        )
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
private fun AllAppsScreen(reload: Int, onOpen: (AppEntry) -> Unit, onInfo: (AppEntry) -> Unit, onUninstall: (AppEntry) -> Unit, pick: Boolean = false, onBack: () -> Unit = {}) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var query by remember { mutableStateOf("") }
    // Same four kinds as App icon and Open with Hail, but this window keeps its own choice.
    var kinds by remember { mutableIntStateOf(AppKinds.load(ctx, KEY_KINDS)) }
    var showGrid by remember { mutableStateOf(false) }
    var cols by remember { mutableIntStateOf(prefs.getInt(KEY_COLS, 0).coerceIn(0, 12)) }
    var iconDp by remember { mutableIntStateOf(prefs.getInt(KEY_ICON, 48).coerceIn(24, 96)) }
    var textSp by remember { mutableIntStateOf(prefs.getInt(KEY_TEXT, 11).coerceIn(8, 18)) }
    var lines by remember { mutableIntStateOf(prefs.getInt(KEY_LINES, 2).coerceIn(0, 3)) }
    // Space between the lines of a name that takes two or three lines, in percent of the text size (100 = normal).
    var lineGap by remember { mutableIntStateOf(prefs.getInt(KEY_LINEGAP, 100).coerceIn(60, 200)) }
    var tapMenu by remember { mutableStateOf(prefs.getBoolean(KEY_TAPMENU, true)) }
    var menuFor by remember { mutableStateOf<AppEntry?>(null) }

    LaunchedEffect(kinds, reload) {
        apps = null
        apps = withContext(Dispatchers.Default) { loadApps(ctx, kinds) }
    }
    val list = apps
    val words = query.trim().lowercase().split(' ').filter { it.isNotEmpty() }
    val shown = if (list == null) emptyList() else if (words.isEmpty()) list else list.filter { e ->
        val hay = (e.label + " " + e.pkg).lowercase()
        words.all { hay.contains(it) }
    }
    AWindowPage(
        title = "Apps" + (if (list != null) " (" + shown.size + ")" else ""),
        onBack = onBack,
        actions = {
            a.a.ui.motion.IconButton(onClick = { showGrid = true }, tooltip = "Grid: columns, icon and name size") {
                androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Filled.Tune, contentDescription = null)
            }
        },
    ) { pad ->
    Column(
        Modifier.fillMaxSize().padding(pad).navigationBarsPadding().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    if (query.isEmpty()) Text("Search", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    inner()
                },
            )
        }
        // The four kinds on one line.
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf(
                AppKinds.USER to "User",
                AppKinds.USER_HIDDEN to "User off",
                AppKinds.SYSTEM to "System",
                AppKinds.SYSTEM_HIDDEN to "System off",
            ).forEach { (bit, name) ->
                val on = kinds and bit != 0
                Box(
                    Modifier.weight(1f).height(30.dp).clip(RoundedCornerShape(15.dp))
                        .background(if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(15.dp))
                        .clickable {
                            // From the plain default (user apps only) a first tap on another kind switches to that kind alone;
                            // after that the buttons add and remove kinds, and all four show every app (same as App icon).
                            kinds = if (kinds == AppKinds.DEFAULT && bit != AppKinds.USER) bit else kinds xor bit
                            AppKinds.save(ctx, kinds, KEY_KINDS)
                        },
                    contentAlignment = Alignment.Center,
                ) { Text(name, fontSize = 12.sp, maxLines = 1) }
            }
        }
        if (showGrid) CardWindow(title = "Grid", onBack = { showGrid = false }) {
            CardGroup(title = "Size and shape") {
                row { sh ->
                    SliderRow("apps_cols", "Columns", "", cols, 0, 12, sh, summary = "0 = automatic") { cols = it; prefs.edit().putInt(KEY_COLS, it).apply() }
                }
                row { sh -> SliderRow("apps_icon", "Icon size", " dp", iconDp, 24, 96, sh) { iconDp = it; prefs.edit().putInt(KEY_ICON, it).apply() } }
                row { sh -> SliderRow("apps_text", "Name size", " sp", textSp, 8, 18, sh) { textSp = it; prefs.edit().putInt(KEY_TEXT, it).apply() } }
                row { sh ->
                    SliderRow("apps_lines", "Name lines", "", lines, 0, 3, sh, summary = "0 = no names") { lines = it; prefs.edit().putInt(KEY_LINES, it).apply() }
                }
                if (lines > 1) row { sh ->
                    SliderRow("apps_gap", "Space between the name lines", "%", lineGap, 60, 200, sh) { lineGap = it; prefs.edit().putInt(KEY_LINEGAP, it).apply() }
                }
            }
            CardGroup(title = "Tapping an app") {
                row { sh ->
                    SwitchRow(
                        "Tap an app to choose: Open, App info, Uninstall", tapMenu, sh,
                        summary = "Off = a tap opens, a long press chooses",
                    ) { tapMenu = it; prefs.edit().putBoolean(KEY_TAPMENU, it).apply() }
                }
                row { sh ->
                    LinkRow("Reset grid", "Columns, icon and name sizes back to normal", sh) {
                        cols = 0; iconDp = 48; textSp = 11; lines = 2; lineGap = 100
                        prefs.edit().putInt(KEY_COLS, 0).putInt(KEY_ICON, 48).putInt(KEY_TEXT, 11).putInt(KEY_LINES, 2).putInt(KEY_LINEGAP, 100).apply()
                        showGrid = false
                    }
                }
            }
        }
        if (kinds and AppKinds.ALL == 0) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Nothing is selected. Choose User, User hidden/disabled, System or System hidden/disabled above to see apps.", textAlign = TextAlign.Center)
            }
        } else if (list == null) {
            Text("Loading...")
        } else if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("No apps of the selected kinds match.", textAlign = TextAlign.Center)
            }
        } else {
            val columns = if (cols > 0) GridCells.Fixed(cols) else GridCells.Adaptive((iconDp + 32).dp)
            LazyVerticalGrid(columns = columns, modifier = Modifier.fillMaxSize()) {
                items(shown, key = { it.pkg + "/" + it.cls }) { e ->
                    Column(
                        Modifier.fillMaxWidth().combinedClickable(
                            onClick = { if (tapMenu && !pick) menuFor = e else onOpen(e) },
                            onLongClick = { if (!pick) menuFor = e },
                        ).padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        AppIcon(e, iconDp)
                        if (lines > 0) {
                            Text(
                                e.label, fontSize = textSp.sp, maxLines = lines, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis,
                                lineHeight = (textSp * 1.2f * lineGap / 100f).sp,
                            )
                        }
                    }
                }
            }
        }
    }
    }
    menuFor?.let { e ->
        CardWindow(title = e.label, onBack = { menuFor = null }) {
            CardGroup(title = "App") {
                row { sh -> SettingRow(title = e.pkg, shape = sh) }
            }
            CardGroup(title = "What to do") {
                row { sh -> LinkRow("Open", "Starts the app", sh) { menuFor = null; onOpen(e) } }
                row { sh -> LinkRow("App info", "Android's page for this app", sh) { menuFor = null; onInfo(e) } }
                row { sh -> LinkRow("Uninstall", "Removes the app from this user", sh) { menuFor = null; onUninstall(e) } }
            }
        }
    }
}
