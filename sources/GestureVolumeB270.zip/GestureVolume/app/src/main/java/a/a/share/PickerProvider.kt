package a.a.share

import android.content.ContentUris
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.provider.MediaStore
import android.util.Size
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

/**
 * "A" in the system file picker's side menu (the three lines). Opening it lists the newest photos
 * and the newest files in Download in one flat list. Multi-select comes from the picker itself.
 */
class PickerProvider : DocumentsProvider() {

    private val rootCols = arrayOf(
        Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_ICON, Root.COLUMN_TITLE,
        Root.COLUMN_SUMMARY, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_MIME_TYPES
    )
    private val docCols = arrayOf(
        Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_SIZE,
        Document.COLUMN_MIME_TYPE, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS
    )

    override fun onCreate(): Boolean = true

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: rootCols)
        val ctx = context ?: return c
        c.newRow().apply {
            add(Root.COLUMN_ROOT_ID, "a")
            add(Root.COLUMN_FLAGS, Root.FLAG_LOCAL_ONLY or Root.FLAG_SUPPORTS_RECENTS)
            add(Root.COLUMN_ICON, ctx.applicationInfo.icon)
            add(Root.COLUMN_TITLE, "A")
            add(Root.COLUMN_SUMMARY, "Photos and recent downloads")
            add(Root.COLUMN_DOCUMENT_ID, ROOT)
            add(Root.COLUMN_MIME_TYPES, "*/*")
        }
        return c
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: docCols)
        if (documentId == ROOT) {
            c.newRow().apply {
                add(Document.COLUMN_DOCUMENT_ID, ROOT)
                add(Document.COLUMN_DISPLAY_NAME, "A")
                add(Document.COLUMN_SIZE, 0L)
                add(Document.COLUMN_MIME_TYPE, Document.MIME_TYPE_DIR)
                add(Document.COLUMN_LAST_MODIFIED, null)
                add(Document.COLUMN_FLAGS, 0)
            }
            return c
        }
        val id = idOf(documentId)
        query("${MediaStore.Files.FileColumns._ID}=?", arrayOf(id.toString()), 1, c)
        return c
    }

    override fun queryChildDocuments(
        parentDocumentId: String, projection: Array<out String>?, sortOrder: String?
    ): Cursor {
        val c = MatrixCursor(projection ?: docCols)
        if (parentDocumentId == ROOT) query(LIST_WHERE, null, LIMIT, c)
        return c
    }

    override fun queryRecentDocuments(rootId: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: docCols)
        query(LIST_WHERE, null, 64, c)
        return c
    }

    override fun openDocument(
        documentId: String, mode: String, signal: CancellationSignal?
    ): ParcelFileDescriptor {
        val ctx = context ?: throw FileNotFoundException()
        val uri = fileUri(idOf(documentId))
        return ctx.contentResolver.openFileDescriptor(uri, "r", signal)
            ?: throw FileNotFoundException(documentId)
    }

    override fun openDocumentThumbnail(
        documentId: String, sizeHint: android.graphics.Point, signal: CancellationSignal?
    ): AssetFileDescriptor {
        val ctx = context ?: throw FileNotFoundException()
        if (Build.VERSION.SDK_INT < 29) throw FileNotFoundException("no thumbnail")
        val bmp = try {
            ctx.contentResolver.loadThumbnail(
                fileUri(idOf(documentId)), Size(sizeHint.x, sizeHint.y), signal
            )
        } catch (e: Exception) {
            throw FileNotFoundException("no thumbnail")
        }
        val f = File.createTempFile("thumb", ".jpg", ctx.cacheDir)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        f.delete()
        return AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    private fun idOf(documentId: String): Long =
        documentId.removePrefix("f:").toLongOrNull() ?: throw FileNotFoundException(documentId)

    private fun fileUri(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"), id)

    private fun query(where: String, args: Array<String>?, limit: Int, out: MatrixCursor) {
        val ctx = context ?: return
        val cols = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        try {
            ctx.contentResolver.query(
                MediaStore.Files.getContentUri("external"), cols, where, args,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { q ->
                var n = 0
                while (q.moveToNext() && n < limit) {
                    val name = q.getString(1) ?: continue
                    var mime = q.getString(3)
                    if (mime.isNullOrEmpty()) {
                        val ext = name.substringAfterLast('.', "").lowercase()
                        mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                            ?: "application/octet-stream"
                    }
                    val flags = if (mime.startsWith("image/") && Build.VERSION.SDK_INT >= 29)
                        Document.FLAG_SUPPORTS_THUMBNAIL else 0
                    out.newRow().apply {
                        add(Document.COLUMN_DOCUMENT_ID, "f:" + q.getLong(0))
                        add(Document.COLUMN_DISPLAY_NAME, name)
                        add(Document.COLUMN_SIZE, q.getLong(2))
                        add(Document.COLUMN_MIME_TYPE, mime)
                        add(Document.COLUMN_LAST_MODIFIED, q.getLong(4) * 1000L)
                        add(Document.COLUMN_FLAGS, flags)
                    }
                    n++
                }
            }
        } catch (e: Exception) {
            // no permission or provider problem: show an empty list
        }
    }

    companion object {
        private const val ROOT = "root"
        private const val LIMIT = 300
        // images, or any real file whose folder is Download (or below it)
        private val LIST_WHERE =
            "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=${MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE}" +
                " OR ${MediaStore.Files.FileColumns.RELATIVE_PATH} LIKE 'Download/%')" +
                " AND ${MediaStore.Files.FileColumns.SIZE}>0"
    }
}
