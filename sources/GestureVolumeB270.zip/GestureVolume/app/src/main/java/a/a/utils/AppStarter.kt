package a.a.utils

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import a.a.service.OverlayRuntime

/**
 * Starts an activity so that it really opens. Android silently drops an activity started from the
 * background (no error, nothing happens) unless the app counts as visible at that moment, which is
 * why a launch from A's windows sometimes did nothing. The shell (Shizuku) is exempt from that rule,
 * so an app launch goes through `am start` when Shizuku is ready; otherwise through the accessibility
 * service, then A itself. Nothing runs or stays in memory until an app is launched.
 */
object AppStarter {
    private val main = Handler(Looper.getMainLooper())

    /** True for the intent a launcher icon sends: MAIN + LAUNCHER, which is what getLaunchIntentForPackage builds. */
    fun isAppLaunch(i: Intent): Boolean =
        i.action == Intent.ACTION_MAIN && i.categories?.contains(Intent.CATEGORY_LAUNCHER) == true

    /** Returns true when a start was attempted; failures of the shell route fall back to a normal start. */
    fun start(context: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (isAppLaunch(intent) && ShizukuShell.isReady()) {
            val uri = runCatching { intent.toUri(Intent.URI_INTENT_SCHEME) }.getOrNull()
            if (uri != null) {
                val cmd = "am start '" + uri.replace("'", "'\\''") + "'"
                Thread {
                    var out = ""
                    val code = runCatching { ShizukuShell.run(cmd) { out += it + "\n" } }.getOrDefault(-1)
                    if (code != 0 || out.contains("Error", ignoreCase = true)) main.post { plain(context, intent) }
                }.start()
                return true
            }
        }
        return plain(context, intent)
    }

    private fun plain(context: Context, intent: Intent): Boolean {
        val svc: Context = OverlayRuntime.accessibilityService ?: context
        return try {
            svc.startActivity(intent)
            true
        } catch (_: Exception) {
            try { context.startActivity(intent); true } catch (_: Exception) { false }
        }
    }
}
