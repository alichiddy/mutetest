# HANDOFF - state: B270 (zip GestureVolumeB270.zip), not compiled. Next build: B271

## B270: "Swifty Switch style" option (built, NOT compiled, untested)
Ali asked for the exact logic of how Swifty Switch's Cells window opens and moves between shortcuts, as an OPTION (off by default). Switch: Cell Settings > "Swifty Switch style ..." (pref `stripSwifty`, per Cells window via StripScope; optional hidden pref `stripSwiftyMs`, default 250).

What was read in Swifty (base_src.zip = obfuscated smali of org.de_studio.recentappswitcher.trial):
- Touch -> la2 (OnTouchListener) -> NewServiceView.onTouch -> presenter kf1: F(x,y,id) = open, G(x,y) = every ACTION_MOVE, Q(x,y) = centre of the panel, clamped on screen with xe1.K/L.
- Grid hit test = xe1.H(...): for each cell centre (spacing = size*density + padding) the cell is hit when the finger is inside a CIRCLE of radius 35 dp (35*density) around the centre; first cell found in column-major order wins; gaps between circles = nothing lit (-1); finger farther than 90 dp from every centre (when the flag is on) = -2 (leave/cancel). Mirror: index = (cols-1-col) + row*cols. No hysteresis, no throttling.
- Opening (NewServiceView.b1): the panel is placed under the finger first; every cell starts translated by (panelCentre - cellPos)/2, alpha 0, then animates to 0 / alpha 1 with DecelerateInterpolator(3.0), duration = pref `animation_time` (default 250 ms). One branch also sets a start delay equal to that time: NOT understood, NOT copied.
- Not extracted: highlight drawing on index change, haptic on open (pref disable_haptic), hold-time before close.

What was built in A:
- strip/StripView.kt: `swifty` flag; `swiftyCellAt` (round zones, radius = max(35 dp, cell/2), first in column order, no sticky) used by cellAt (so highlight and release-run agree); `startOpen(ms)` + per-cell fly-out/fade in onDraw (only while opening; saveLayerAlpha per cell); animator cancelled on detach.
- service/OverlayController.kt: with the option on and not "Centered", showStrip builds the window but adds it only when the thumb's place is known (placeStripOnThumb -> attachStrip), at its final place in ONE addView (before: added invisible, then moved with updateViewLayout, up to 150 ms late); fallback adds it after 150 ms. Centered: added at once. `stripPendingParams`, `attachStrip`; hideStrip clears pending.
- ui/screens/strip/StripEditorScreen.kt: the switch.
- Option off = old code paths untouched.

Open questions for Ali's test: does the radius (35 dp / half cell) feel like Swifty's; is a different animation time wanted (then expose stripSwiftyMs as stepper); the unexplained start delay.
Next build: B271.

## (older handoff below, from B265; B266-B269 changes are not listed here)


## Working with Ali
Persian/English, voice dictation ("ID" = idea). NOT a developer: boxes/forms/lists, no code or formulas. Lean replies, accuracy over speed, talk first before big changes, never remind him what to test. App is just "A" (package a.a), repo alichiddy/mutetest; he builds on GitHub Actions and pastes errors (Claude cannot compile). Deliver the zip only (no YML), name the build number (next: B264), bracket-check changed .kt files against the originals. Zero idle RAM: any feature costs nothing when not used. Never wait for a double tap. Terms: "Cells window", "Segments". Source layout: app/src/main/java/a/a/{strip,service,utils,flow,share,ui}.

## Latest builds
- B265: A declares a HOME activity (launcher mode), so it counted as "the launcher" and was skipped even with the switch on; homePackages now drops A when the option is on.
- B264: Previous app report lines now show allowA and the skip list (debug for "A not chosen").
- B263: "Allow A as the previous app" option (Previous app dialog; PreviousApp.PREF_ALLOW_A, default off). On: A is no longer skipped by Previous app - Shizuku recents (counts/pick), the tracked history (OverlayController.onForegroundApp notes A's own screens only when the option is on) and the usage-events path (pickFromHistory). Off = as before. Changed: utils/PreviousApp.kt, service/OverlayController.kt, ui/screens/strip/StripEditorScreen.kt.
- B262: long info texts in the cells editor / outside actions folded behind "▾ Info".
- B260: Previous app without Shizuku = MyGesture's way (tracked list of 8 packages from accessibility window changes, launched with MAIN/LAUNCHER intent, flags 0x10200000, via PendingIntent). Needs "Track apps without Shizuku" ON or Usage access. Shizuku way: startActivityFromRecents, moveTaskToFront, `am task lock` (option "stop lock after unpinning").
- B251: Wi-Fi share (3 QR codes, notification row, "Wi-Fi share window" shortcut, upload page).
- B247: tapping a .json opens "Import into A". B244: A in the system file picker.
- B242/B243: volume panel hands an inward swipe to the Cells window (switch panelOpensCells); test bar bottom-left (switch testBarOn).

## Open
1. Test bar visibility (needs Copy report, note "test bar x= y= w= h=").
2. Left vertical segment's volume panel shows a gap to the screen side in portrait (not fixed).
3. Landscape as two windows idea: discuss first.
4. Accessibility service sometimes dropped: his Automate flows overwrite enabled_accessibility_services (not proven); Copy report logs list changes.
5. Older untested items: bank (Resalat) widget sends A away after tap; Persian digit OCR; see his backlog.

## Reminders from the code
- Kept on purpose with old names: GitHubBuild.kt/SharedPref (workflow gesturevolume.yml, release tag gv), assets/automate_flows.json.
- Never put real keys in source (PrivateValues slots).
- Scripts-blocks principle: say whether a new feature is a user-buildable script block or a built-in.
