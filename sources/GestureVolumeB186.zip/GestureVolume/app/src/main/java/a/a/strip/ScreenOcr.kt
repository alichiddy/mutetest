package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import a.a.utils.ShizukuShell
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Reads digits from any part of the screen (a widget, a USSD window, any app). The person drags a
 * box over what to read; A then takes screenshots through Shizuku, cuts out that box and reads it
 * with [OtpOcr] until the same digits show up twice in a row. Nothing stays in memory afterwards.
 */
object ScreenOcr {
    class Region(val rect: Rect, val screenW: Int, val screenH: Int)

    private fun toast(app: Context, text: String) {
        Handler(Looper.getMainLooper()).post { WidgetFloat.toast(app, text) }
    }

    /** A screenshot through Shizuku. Blocking; null when it fails. */
    fun capture(): Bitmap? {
        if (!ShizukuShell.isReady()) return null
        val sb = StringBuilder()
        ShizukuShell.run("screencap -p | base64") { sb.append(it) }
        if (sb.isEmpty()) return null
        val bytes = runCatching { Base64.decode(sb.toString(), Base64.DEFAULT) }.getOrNull() ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /** The chosen box cut out of a screenshot; the screenshot is recycled. */
    fun crop(full: Bitmap, r: Region): Bitmap? {
        val kx = full.width.toFloat() / r.screenW.coerceAtLeast(1)
        val ky = full.height.toFloat() / r.screenH.coerceAtLeast(1)
        val l = (r.rect.left * kx).toInt().coerceIn(0, full.width - 1)
        val t = (r.rect.top * ky).toInt().coerceIn(0, full.height - 1)
        val w = ((r.rect.right * kx).toInt() - l).coerceIn(1, full.width - l)
        val h = ((r.rect.bottom * ky).toInt() - t).coerceIn(1, full.height - t)
        val out = runCatching { Bitmap.createBitmap(full, l, t, w, h) }.getOrNull()
        if (out !== full) full.recycle()
        return out
    }

    /** Lets the person drag a box over the screen. Blocking; null when cancelled or when it cannot be shown. */
    fun pick(app: Context): Region? {
        val main = Handler(Looper.getMainLooper())
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val latch = CountDownLatch(1)
        var result: Region? = null
        var view: PickView? = null
        main.post {
            val v = PickView(app) { r -> result = r; latch.countDown() }
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            if (runCatching { wm.addView(v, p) }.isSuccess) view = v else latch.countDown()
        }
        latch.await(90, TimeUnit.SECONDS)
        main.post { view?.let { runCatching { wm.removeView(it) } } }
        pause(350)
        return result
    }

    /** Picks a box, then takes one picture of it (used to teach the digits from any screen). */
    fun snap(app: Context): Bitmap? {
        if (!WidgetFloat.allowed(app) || !ShizukuShell.isReady()) return null
        val region = pick(app) ?: return null
        val full = capture() ?: return null
        return crop(full, region)
    }

    /**
     * Picks a box and reads the digits in it, up to about 15 seconds, until the same digits are seen
     * twice in a row. Blocking. Throws a short message when nothing could be read.
     */
    fun read(app: Context): String {
        if (!WidgetFloat.allowed(app)) throw IllegalStateException("Allow Display over other apps for A, then try again")
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        toast(app, "Drag a box over what to read")
        val region = pick(app) ?: throw IllegalStateException("Cancelled")
        val limit = System.currentTimeMillis() + 15000
        var last = ""
        try {
            while (System.currentTimeMillis() < limit) {
                val full = capture() ?: throw IllegalStateException("The screenshot failed")
                val pic = crop(full, region)
                val r = if (pic == null) "" else runCatching { OtpOcr.read(app, pic) }.getOrDefault("")
                pic?.recycle()
                if (r.isNotEmpty() && !r.contains('?')) {
                    if (r == last) return r
                    last = r
                } else last = ""
                pause(300)
            }
        } finally {
            OtpOcr.release()
        }
        throw IllegalStateException("No digits were found in that box")
    }

    private fun pause(ms: Int) {
        try { Thread.sleep(ms.toLong()) } catch (_: InterruptedException) { }
    }

    /** The full-screen layer where the box is dragged. Tap "Cancel" (top right) to give up. */
    private class PickView(ctx: Context, private val onDone: (Region?) -> Unit) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private val dim = Paint().apply { color = 0x88000000.toInt() }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 16f * d }
        private var x0 = 0f
        private var y0 = 0f
        private var x1 = 0f
        private var y1 = 0f
        private var has = false
        private var cancelDown = false
        private var finished = false

        private fun box() = Rect(minOf(x0, x1).toInt(), minOf(y0, y1).toInt(), maxOf(x0, x1).toInt(), maxOf(y0, y1).toInt())
        private fun inCancel(x: Float, y: Float) = x > width - 130f * d && y < 110f * d

        override fun onDraw(c: Canvas) {
            if (has) {
                val b = box()
                c.save()
                c.clipOutRect(b)
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
                c.restore()
                c.drawRect(b, edge)
            } else {
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
            }
            c.drawText("Drag a box over what to read", 16f * d, 70f * d, text)
            c.drawText("Cancel", width - 100f * d, 70f * d, text)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (finished) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    cancelDown = inCancel(e.x, e.y)
                    if (!cancelDown) { x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y; has = true }
                }
                MotionEvent.ACTION_MOVE -> if (!cancelDown) { x1 = e.x; y1 = e.y; invalidate() }
                MotionEvent.ACTION_UP -> {
                    if (cancelDown) {
                        if (inCancel(e.x, e.y)) { finished = true; onDone(null) }
                    } else {
                        x1 = e.x; y1 = e.y
                        val b = box()
                        if (b.width() >= 20 && b.height() >= 12) {
                            val at = IntArray(2)
                            getLocationOnScreen(at)
                            b.offset(at[0], at[1])
                            finished = true
                            onDone(Region(b, width, height))
                        } else { has = false; invalidate() }
                    }
                }
                MotionEvent.ACTION_CANCEL -> { has = false; invalidate() }
            }
            return true
        }
    }
}
