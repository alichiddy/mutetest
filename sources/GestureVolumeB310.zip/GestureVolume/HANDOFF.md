# HANDOFF - B310 (from B308; B309 failed to compile, fixed), not compiled. Next build: B311

## Working with Ali
- Not a developer; Persian/English; voice dictation ("ID" = idea). Calls Claude "Habibi". App = "A" (package a.a, repo alichiddy/mutetest), built on GitHub Actions; he pastes build errors.
- Lean replies, accuracy over speed, talk first before big changes. He hits his usage limit if he talks too much: do ONE step, then ask him to say "continue".
- Everything in the app = boxes, forms, lists (no code/formulas). Zero idle RAM. Never wait for a double tap.
- Deliver the zip only (no YML), name the build number, bracket-check changed .kt files against the originals. Claude cannot compile.
- Terms: "Cells window", "Segments", "Scripts" (not "flows"), "buttons" for widget buttons, "tile" only for Quick Settings tiles, no "strip" in texts.

## Goal (his words)
Make every window feel like the original main app: same design, buttons and better wording as the Cells window (B305). One window group per zip.

## Done
- B305: Cells window rebuilt in card design.
- B307: Widgets host + both Launcher windows.
- B310 = B309 + fix (ChoiceChip: pass onClick = named, trailing lambda goes to `modifier`). B309/B310 (step 1 of the script block editor): top bar of flow/FlowCanvasEditor.kt now AWindowPage (back arrow = save & close, script name, Add + Run icons); Stop/Undo/Redo/Fit/Always On/Delete script in a row under it. AWindowPage got an optional `actions` param.
- B308: Scripts list (flow/FlowActivity.kt), My values (now reachable from Options), Automations (auto/AutomationsScreen.kt).

## Plan (in order)
1. Script block editor, REMAINING: (a) Add-a-block dialog + long-press menu, (b) block edit form BlockForm (cards instead of loose buttons) + flow/FlowPickers.kt (ChoiceRow/NumberPick/VarPick/ValuePick), (c) NativePicker. Top bar done in B309.
2. Cell Settings submenus (opened from the Cells window / when editing or defining a cell): Look of the cells (LookDialog.kt), Gap/popup/effects, Previous app, Click circle, Folders and touch dialogs (all in ui/screens/strip/StripEditorScreen.kt and ActionPages.kt), the Widgets/Launcher dialogs again if any left.
3. Shell runner (ui/screens/shell: ShellActivity.kt, OtgDialogs.kt, ShellHistoryDialog.kt).
4. The buttons at the top of A's main window (Copy report, Backup, ...: ui/screens/main/MainScreen.kt, ReportDialog.kt, BackupDialog.kt, LanguageDialog.kt, ThemeDialog.kt, SearchDialog.kt) and the window inside each.
5. Then Sides, All apps, GitHub settings, OCR, HTML viewer.

## How to restyle (reuse, do not invent)
- ui/components/AWindow.kt: AWindow {} (A's theme + light/dark choice) wraps an activity; AWindowPage(title, onBack) {pad->} = top bar like the Cells window. Separate activities were drawn in plain Material colours until wrapped.
- ui/screens/strip/StripRows.kt: CardGroup{row{sh->}}, SettingRow, SwitchRow, StepRow, ChipsCardRow, ChipsRow, LinkRow, ToggleRow/StepperRow (dialogs), InfoArrow. Long text goes behind the "Info" arrow. GroupHeading, cardShape, rowColor in ui/components/RowKit.kt; ChoiceChip.
- Buttons: use a.a.ui.motion Button/OutlinedButton/TextButton/IconButton (press bounce), not material3.
- Icons.Filled.X needs its own import each (only icons already imported elsewhere are known to exist: Add, Apps, Check, Checklist, Close, ContentCopy, Delete, Download, Edit, Home, Info, Lock, Notifications, PlayArrow, Search, Share, Star, Terminal, Tune, Visibility, Widgets).
- Change UI only; keep logic. Lambdas of CardGroup/row have a receiver: write this@Activity, not this.
- If screens/labels change, re-run: python3 tool/make_search_index.py

## Kept on purpose
- Old names GitHubBuild.kt/SharedPref (workflow gesturevolume.yml, release tag gv), assets/automate_flows.json.
- Never put real keys in source (PrivateValues slots).
- When adding a feature, say if it is a user-buildable script block or a built-in.
