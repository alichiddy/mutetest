package a.a.strip

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * The app's preferences as JSON, in two independent parts: the **scripts** (the strip: its
 * shortcuts, flows and layout, one key) and the **settings** (everything else). A backup, a
 * restore or an APK can carry either part or both, so scripts can differ between phones while the
 * settings stay the same.
 *
 * An APK made with settings holds assets/settings_default.json; one made with scripts holds
 * assets/strip_default.json. A fresh install applies what it carries before anything reads them.
 */
object SettingsBackup {

    const val BAKED_ASSET = "settings_default.json"

    /** The one preference that holds the strip. */
    const val STRIP_KEY = "stripConfigV1"

    /**
     * Pictures for cells. A backup file may carry them under "icons": {"name.png": "<base64>"}; a
     * cell then uses one as icon "img:name.png". They are kept in files/sicons, where the strip and
     * the editor already look. Nothing is built into the app: the pictures come with the file, from
     * whatever tool or app made it, and are written when the scripts part is restored.
     */
    private const val ICON_DIR = "sicons"
    private const val MAX_ICON_BYTES = 1_000_000
    private val ICON_NAME = Regex("[A-Za-z0-9._-]{1,80}\\.(png|webp|jpg|jpeg)")
    private val ICON_REF = Regex("img:([A-Za-z0-9._-]{1,80}\\.(?:png|webp|jpg|jpeg))")

    private var appContext: Context? = null

    /** Called once from the Application, so backups and restores can reach the icon folder. */
    fun init(context: Context) { appContext = context.applicationContext }

    fun toJson(prefs: SharedPreferences, settings: Boolean, scripts: Boolean): String {
        val p = JSONObject()
        for ((key, value) in prefs.all) {
            if (key == "ghToken") continue
            val isStrip = key == STRIP_KEY
            if ((isStrip && !scripts) || (!isStrip && !settings)) continue
            val e = JSONObject()
            when (value) {
                is Boolean -> e.put("t", "b").put("v", value)
                is Int -> e.put("t", "i").put("v", value)
                is Long -> e.put("t", "l").put("v", value)
                is Float -> e.put("t", "f").put("v", value.toDouble())
                is String -> e.put("t", "s").put("v", value)
                is Set<*> -> e.put("t", "S").put("v", JSONArray(value.map { it.toString() }))
                else -> continue
            }
            p.put(key, e)
        }
        val root = JSONObject().put("format", 1).put("prefs", p)
        if (scripts) {
            val icons = iconsOf(prefs)
            if (icons.length() > 0) root.put("icons", icons)
            val boxes = ocrOf("ocr_boxes")
            if (boxes.length() > 0) root.put("ocrBoxes", boxes)
            val al = ocrOf("ocr_box_aliases")
            if (al.length() > 0) root.put("ocrBoxAliases", al)
        }
        return root.toString()
    }

    /** The saved OCR boxes (name -> "l,t,r,b" as screen fractions) or their old names, from the prefs file [file]. */
    private fun ocrOf(file: String): JSONObject {
        val o = JSONObject()
        val c = appContext ?: return o
        for ((k, v) in c.getSharedPreferences(file, Context.MODE_PRIVATE).all) if (v is String) o.put(k, v)
        return o
    }

    /** Puts the OCR boxes of a backup back: boxes with the same name are replaced, the others stay. */
    private fun restoreOcr(json: String) {
        val c = appContext ?: return
        val root = runCatching { JSONObject(json) }.getOrNull() ?: return
        for ((key, file) in listOf("ocrBoxes" to "ocr_boxes", "ocrBoxAliases" to "ocr_box_aliases")) {
            val o = root.optJSONObject(key) ?: continue
            val e = c.getSharedPreferences(file, Context.MODE_PRIVATE).edit()
            for (k in o.keys()) e.putString(k, o.optString(k))
            e.apply()
        }
    }

    /** The pictures the strip refers to as "img:<name>", as name -> base64. */
    private fun iconsOf(prefs: SharedPreferences): JSONObject {
        val out = JSONObject()
        val strip = prefs.getString(STRIP_KEY, null) ?: return out
        val ctx = appContext ?: return out
        val dir = java.io.File(ctx.filesDir, ICON_DIR)
        for (m in ICON_REF.findAll(strip)) {
            val name = m.groupValues[1]
            if (out.has(name)) continue
            runCatching {
                val bytes = java.io.File(dir, name).readBytes()
                out.put(name, android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
            }
        }
        return out
    }

    /** Writes the pictures a backup carries. Only plain picture names and real, reasonably small pictures are accepted. */
    private fun restoreIcons(json: String): Int {
        var written = 0
        runCatching {
            val icons = JSONObject(json).optJSONObject("icons") ?: return 0
            val ctx = appContext ?: return 0
            val dir = java.io.File(ctx.filesDir, ICON_DIR).apply { mkdirs() }
            val names = icons.keys()
            while (names.hasNext()) {
                val name = names.next()
                if (!ICON_NAME.matches(name)) continue
                runCatching {
                    val bytes = android.util.Base64.decode(icons.getString(name), android.util.Base64.DEFAULT)
                    if (bytes.isEmpty() || bytes.size > MAX_ICON_BYTES) return@runCatching
                    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching
                    java.io.File(dir, name).writeBytes(bytes)
                    written += 1
                }
            }
        }
        return written
    }

    /**
     * Applies the chosen part of [json]. Settings replace every setting except the strip; scripts
     * replace only the strip. Returns how many preferences were applied (0 if the file held none
     * of the chosen part), or -1 if it is not a backup.
     */
    fun apply(prefs: SharedPreferences, json: String, settings: Boolean, scripts: Boolean): Int {
        val p = runCatching { JSONObject(json).getJSONObject("prefs") }.getOrNull() ?: return -1
        val incomingSettings = p.keys().asSequence().any { it != STRIP_KEY }
        val edit = prefs.edit()
        if (settings && incomingSettings) {
            for (key in prefs.all.keys) if (key != STRIP_KEY) edit.remove(key)
        }
        var n = 0
        val keys = p.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val isStrip = key == STRIP_KEY
            if ((isStrip && !scripts) || (!isStrip && !settings)) continue
            val e = p.getJSONObject(key)
            when (e.getString("t")) {
                "b" -> edit.putBoolean(key, e.getBoolean("v"))
                "i" -> edit.putInt(key, e.getInt("v"))
                "l" -> edit.putLong(key, e.getLong("v"))
                "f" -> edit.putFloat(key, e.getDouble("v").toFloat())
                "s" -> edit.putString(key, e.getString("v"))
                "S" -> {
                    val a = e.getJSONArray("v")
                    edit.putStringSet(key, (0 until a.length()).map { a.getString(it) }.toSet())
                }
                else -> continue
            }
            n++
        }
        if (scripts) { restoreIcons(json); restoreOcr(json) }
        edit.commit()
        return n
    }

    private const val UNDO_FILE = "undo_restore.json"

    /** Keeps a copy of everything as it is now, so the last restore can be undone. Call before [apply]. */
    fun saveUndo(context: Context, prefs: SharedPreferences) {
        runCatching { java.io.File(context.filesDir, UNDO_FILE).writeText(toJson(prefs, true, true)) }
    }

    fun hasUndo(context: Context): Boolean = java.io.File(context.filesDir, UNDO_FILE).exists()

    /** Puts back what [saveUndo] kept. Returns how many preferences came back, or -1 if there is nothing. */
    fun undoLast(context: Context, prefs: SharedPreferences): Int {
        val f = java.io.File(context.filesDir, UNDO_FILE)
        if (!f.exists()) return -1
        val text = runCatching { f.readText() }.getOrNull() ?: return -1
        return apply(prefs, text, true, true)
    }

    /** On a fresh install of an APK made with settings: load what it carries. */
    fun applyBaked(context: Context, prefs: SharedPreferences) {
        val baked = runCatching {
            context.assets.open(BAKED_ASSET).bufferedReader().use { it.readText() }
        }.getOrNull() ?: return
        apply(prefs, baked, settings = true, scripts = true)
    }
}
