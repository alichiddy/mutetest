# BlackBox 4.0.0 – Google sign-in follow-up fixes

This source includes the prior authenticator-cache, addAccountAsUser, split-APK, signature-metadata, and native recursive-logging fixes, plus a second audit based on the Vivo Y21 Android 12 sign-in trace.

## New fixes in this revision

1. **AttributionSource UID alignment.** Virtual app processes expose `callingBUid` from the Binder UID hook. Their `AttributionSourceState.uid` and package name now use that same virtual caller identity. Calls to real Android system providers explicitly use the real AB host UID/package instead.
2. **Provider routing and argument integrity.** Cached system providers are now wrapped with `SystemProviderStub`, not the virtual-provider wrapper. The provider proxies rewrite only the first calling-package argument; they no longer replace every String argument (which could corrupt provider method names, query selections, sort orders, and other data).
3. **No silent permission/UID masking.** The virtual ContentProvider wrapper no longer turns arbitrary `SecurityException`, permission failures, or provider errors into fabricated `true`, `1`, or empty-Bundle values. Exceptions are propagated after the attribution identity is corrected, making genuine failures visible.
4. **Binder UID consistency.** Removed the stack-trace heuristic that changed `Binder.getCallingUid()` to SYSTEM_UID for Settings/FeatureFlag calls. The hook now uses the virtual caller UID consistently, retaining the explicit WebView host-identity exception.
5. **Activity placeholder ordering.** Proxy and pending-intent activities now submit the replacement target activity before finishing the placeholder, avoiding premature task teardown and unnecessary extra Recents tasks in fallback launch paths.
6. **Explicit account user.** `addAccountAsUser()` now honours the userId argument supplied by Android rather than silently substituting the current virtual user.

## Device evidence addressed

The 2026-11-10 trace reported repeated `SecurityException: Calling uid: 10005 doesn't match source uid: 10404`. Android's `AttributionSource.enforceCallingUid()` throws exactly this error when its source UID differs from the Binder caller UID. The virtual GMS process uses UID 10005 while the prior context/provider wrappers were stamping the host UID 10404. This revision aligns those identities by provider type.

The trace also showed GMS reaching `PreAddAccountActivity`, `UnpackingRedirectActivity`, and `AccountIntroActivity`; no `AndroidRuntime` fatal exception was included in the supplied excerpt. The resource-ID warning and optional MANAGE_USERS warning are retained for observation rather than hidden with fake return values.

**Build status:** source only. This environment has no Android SDK/NDK or Gradle distribution, so a device APK build must be run by the existing GitHub Actions workflow. A successful build still requires on-device sign-in verification.
