package com.newagedevs.gesturevolume.sides

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import com.newagedevs.gesturevolume.flow.FlowStore
import com.newagedevs.gesturevolume.flow.NativePicker
import com.newagedevs.gesturevolume.strip.StripConfig
import com.newagedevs.gesturevolume.ui.screens.strip.FoundShortcut
import com.newagedevs.gesturevolume.ui.screens.strip.INTENT_ACTION_PREFIX
import com.newagedevs.gesturevolume.ui.screens.strip.loadCreators
import com.newagedevs.gesturevolume.ui.screens.strip.loadStaticShortcuts
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions

/** Picks any A action as plain dialogs (nothing stays in memory): built-in, device, cells, scripts, apps. */
object SidePicker {
    private class Choice(val label: String, val action: String)

    fun label(activity: Activity, action: String): String {
        if (action.isEmpty()) return "not set"
        if (action == Seg.MAIN) return "Same as main slider (live)"
        if (action == Seg.STRIP) return "Shortcut strip (cells)"
        HandlerActionCatalog.entryFor(action)?.let { return activity.getString(it.labelRes) }
        if (NativePicker.isNative(action)) return NativePicker.label(action)
        if (action.startsWith("MyFlow:")) return "Script: " + action.removePrefix("MyFlow:")
        if (action.startsWith(INTENT_ACTION_PREFIX)) {
            val pkg = runCatching { Intent.parseUri(action.removePrefix(INTENT_ACTION_PREFIX), Intent.URI_INTENT_SCHEME).let { it.component?.packageName ?: it.`package` } }.getOrNull()
            val app = pkg?.let { runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(it, 0)).toString() }.getOrNull() }
            return "App shortcut" + (app?.let { " ($it)" } ?: "")
        }
        if (action.startsWith(StripConfig.FLOW_PREFIX)) return "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
        if (action.startsWith("Shell:")) return "Shell: " + action.removePrefix("Shell:").take(24)
        HandlerActions.launchedPackage(action)?.let { pkg ->
            return "Open " + runCatching { activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
        }
        return action.take(30)
    }

    /** slot (tap, double, long, up, down, in, out) lets the main slider's own action be offered or copied. */
    fun pick(activity: Activity, slot: String, onPicked: (String) -> Unit) {
        val main = com.newagedevs.gesturevolume.data.local.SharedPref(activity).let {
            when (slot) {
                "tap" -> it.getHandlerSingleTapAction(); "double" -> it.getHandlerDoubleTapAction()
                "long" -> it.getHandlerLongTapAction(); "up" -> it.getHandlerSwipeUpAction()
                "down" -> it.getHandlerSwipeDownAction(); "in" -> it.getHandlerSwipeInAction()
                else -> it.getHandlerSwipeOutAction()
            }
        }
        val items = ArrayList<String>(); val run = ArrayList<() -> Unit>()
        fun add(t: String, r: () -> Unit) { items += t; run += r }
        add("Same as main slider (follows its changes)") { onPicked(Seg.MAIN) }
        val mainNow = if (slot == "in" && com.newagedevs.gesturevolume.data.local.SharedPref(activity).getStripEnabled()) Seg.STRIP else main
        add("Copy main slider's now: " + label(activity, mainNow) + " (stays fixed)") { onPicked(mainNow) }
        if (slot == "in") add("Shortcut strip (cells), mirrored for this side") { onPicked(Seg.STRIP) }
        add("Built-in actions (Back, Home, Recents, flashlight…)") { builtIn(activity, onPicked) }
        add("Device actions (Wi-Fi, airplane, network…)") { NativePicker.pick(activity) { a, _ -> onPicked(a) } }
        add("Open an app") { apps(activity, onPicked) }
        add("Other apps' shortcuts (Automate flows, Shortcut Maker…)") { otherApps(activity, onPicked) }
        add("My cells and scripts") { mine(activity, onPicked) }
        add("Nothing") { onPicked("") }
        AlertDialog.Builder(activity).setTitle("Choose an action")
            .setItems(items.toTypedArray()) { _, which -> run[which]() }.show()
    }

    const val REQ_CREATOR = 7001
    private var pendingCreator: ((String) -> Unit)? = null

    /** Called from the activity's onActivityResult: the shortcut another app's "create shortcut" screen made. */
    @Suppress("DEPRECATION")
    fun onResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ_CREATOR) return
        val cb = pendingCreator; pendingCreator = null
        val picked = data?.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (resultCode == Activity.RESULT_OK && picked != null && cb != null) cb(INTENT_ACTION_PREFIX + picked.toUri(Intent.URI_INTENT_SCHEME))
    }

    /** Other apps' shortcuts: their "make a shortcut" screens (Automate's flow list, Shortcut Maker…) and the shortcuts they declare. */
    private fun otherApps(activity: Activity, onPicked: (String) -> Unit) {
        val creators = runCatching { loadCreators(activity) }.getOrDefault(emptyList())
        val found: List<FoundShortcut> = runCatching { loadStaticShortcuts(activity) }.getOrDefault(emptyList())
        val list = ArrayList<Choice>()
        for (c in creators) list += Choice("Make one with: ${c.label}", "@creator:${c.packageName}/${c.className}")
        for (f in found) list += Choice("${f.label}  (${f.appLabel})", INTENT_ACTION_PREFIX + f.intentUri)
        searchable(activity, "Other apps' shortcuts", list) { a ->
            if (a.startsWith("@creator:")) {
                val (pkg, cls) = a.removePrefix("@creator:").split('/', limit = 2)
                pendingCreator = onPicked
                runCatching {
                    activity.startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setClassName(pkg, cls), REQ_CREATOR)
                }
            } else onPicked(a)
        }
    }

    private fun builtIn(activity: Activity, onPicked: (String) -> Unit) {
        val list = HandlerActionCatalog.ALL
            .filter { it.action != HandlerActions.NONE && it.action != HandlerActions.REPOSITION }
            .map { Choice(activity.getString(it.labelRes), it.action) }
        searchable(activity, "Built-in actions", list, onPicked)
    }

    private fun apps(activity: Activity, onPicked: (String) -> Unit) {
        val pm = activity.packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launch, 0)
            .map { Choice(it.loadLabel(pm).toString(), HandlerActions.launchApp(it.activityInfo.packageName)) }
            .sortedBy { it.label.lowercase() }
        searchable(activity, "Open an app", list, onPicked)
    }

    private fun mine(activity: Activity, onPicked: (String) -> Unit) {
        val prefs = activity.getSharedPreferences("MyPrefs", Activity.MODE_PRIVATE)
        val cfg = StripConfig.load(activity, prefs.getString(com.newagedevs.gesturevolume.strip.SettingsBackup.STRIP_KEY, null))
        val list = ArrayList<Choice>()
        for (cell in cfg.items) if (cell.action.isNotEmpty()) list += Choice(cell.label.replace('\n', ' ').ifBlank { cell.action.take(24) }, cell.action)
        for (name in FlowStore.names(activity)) list += Choice("Script: $name", "MyFlow:$name")
        searchable(activity, "My cells and scripts", list, onPicked)
    }

    private fun searchable(activity: Activity, title: String, choices: List<Choice>, onPicked: (String) -> Unit) {
        val box = EditText(activity).apply { hint = "Search"; setSingleLine(true) }
        val list = ListView(activity)
        var shown = choices
        fun fill() {
            val q = box.text.toString().trim().lowercase()
            shown = choices.filter { q.isEmpty() || it.label.lowercase().contains(q) }
            list.adapter = ArrayAdapter(activity, android.R.layout.simple_list_item_1, shown.map { it.label })
        }
        fill()
        box.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { fill() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val col = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(box)
            addView(list, LinearLayout.LayoutParams(-1, (activity.resources.displayMetrics.heightPixels * 0.55).toInt()))
        }
        val d = AlertDialog.Builder(activity).setTitle(title).setView(col).setNegativeButton("Cancel", null).show()
        list.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onPicked(shown[pos].action) }
    }
}
