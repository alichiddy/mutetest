package com.newagedevs.gesturevolume.sides

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs

private const val HandlerActionsNone = "None"

/**
 * The thin touch strips on the screen edges, one window per segment. Nothing is held while the
 * strips are off; each window is a plain View with no bitmaps, so the cost is a few KB.
 *
 * Inward and outward are relative to the screen's middle, so the left side mirrors the right.
 */
class SideSegments(
    private val context: Context,
    private val wm: WindowManager,
    private val host: Host,
) {
    interface Host {
        fun newParams(widthPx: Int, heightPx: Int): WindowManager.LayoutParams
        fun runAction(action: String)
        /** mode = Seg.MODE_VOLUME or MODE_BRIGHTNESS, fraction 0..1; returns a short text to show. */
        fun setLevel(mode: String, fraction: Float): String?
        fun message(text: String)
        /** What the main slider does for a gesture: slot is tap, double, long, up, down, in or out. */
        fun mainAction(slot: String): String
        fun mainIsLeft(): Boolean
        /** A real copy of the main slider for one side, in a window [windowDp] wide with the bar drawn [drawnDp] wide. */
        fun buildClone(leftSide: Boolean, drawnDp: Float, windowDp: Float, heightDp: Float): View
        /** Usable width and height, in the coordinates window positions use. */
        fun area(): Pair<Int, Int>
        /** The main bar's top and height in those coordinates while it is on screen, else null. */
        fun mainBounds(): Pair<Int, Int>?
        fun stripArmed(): Boolean
        fun stripBegin(leftSide: Boolean, mirror: Boolean)
        fun stripMove(rawX: Float, rawY: Float)
        fun stripEnd(rawX: Float, rawY: Float)
        fun stripCancel()
    }

    /** The main slider's look, read when the segments are built and again whenever it changes. */
    private class Look(
        val color: Int, val alpha: Int, val strokeColor: Int, val strokeAlpha: Int, val strokeDp: Float,
        val tl: Float, val tr: Float, val br: Float, val bl: Float,
    )

    private val views = ArrayList<View>()

    fun removeAll() {
        views.forEach { runCatching { wm.removeViewImmediate(it) } }
        views.clear()
    }

    /** Rebuilds every window from [config]. Call with allowed = false to just take them down. */
    fun refresh(config: SideConfig, allowed: Boolean) {
        removeAll()
        if (!allowed || !config.any()) return
        val density = context.resources.displayMetrics.density
        val area = host.area()          // usable width and height: the same coordinates the main bar uses
        val aw = area.first; val ah = area.second
        val pref = com.newagedevs.gesturevolume.data.local.SharedPref(context)
        val mainLeft = host.mainIsLeft()
        val mainBox = host.mainBounds() // top and height of the main bar, or null when it is not up
        for (leftSide in listOf(true, false)) {
            val side = if (leftSide) config.left else config.right
            if (!side.on) continue
            side.segs.forEachIndexed { i, seg ->
                if (!seg.on) return@forEachIndexed
                val height = (if (seg.heightMain) (mainBox?.second ?: (pref.getHandlerHeightDp() * density).toInt()) else ah * seg.heightPct / 100)
                    .coerceIn(ah / 20, ah)
                val topBase = if (seg.posMain) (mainBox?.first ?: (pref.getHandlerPosYFraction(ah >= aw) * ah - height / 2f).toInt()) + ah * seg.shiftPct / 100
                    else ah * seg.topPct / 100
                val top = topBase.coerceIn(0, (ah - height).coerceAtLeast(0))
                val drawnDp = if (seg.copyWidth) pref.getHandlerWidthDp() else seg.widthDp.toFloat()
                val drawnPx = (drawnDp * density).toInt().coerceAtLeast(8)
                // The touchable window: the main slider's rule, or its own; the drawing stays at its width on the outer edge.
                val touchDpEff = if (seg.touchMain) pref.touchWindowDp(drawnDp) else maxOf(drawnDp, seg.touchDp.toFloat())
                val widthPx = maxOf((touchDpEff * density).toInt(), drawnPx)
                val mainTrig = pref.getHandlerEdgeTriggerDp()
                val trigPx = (if (seg.inMain) mainTrig else seg.inDp.toFloat()) * density   // 0 = automatic
                val look = if (seg.copyLook) Look(
                    pref.getHandlerColor(), pref.getHandlerBackgroundAlpha(), pref.getHandlerStrokeColor(),
                    pref.getHandlerStrokeAlpha(), pref.getHandlerStrokeWidth(),
                    pref.getHandlerCornerRadiusTL(), pref.getHandlerCornerRadiusTR(),
                    pref.getHandlerCornerRadiusBR(), pref.getHandlerCornerRadiusBL(),
                ) else null
                com.newagedevs.gesturevolume.utils.DiagLog.note("side seg ${if (leftSide) "L" else "R"}$i top=$top h=$height w=$widthPx area=${aw}x$ah mainBox=$mainBox mainLeft=$mainLeft look=${look?.let { "c=${it.color} a=${it.alpha} s=${it.strokeDp}" }} inward=${seg.inward} stripArmed=${host.stripArmed()}")
                val vertDeg = (if (seg.vertMain) pref.getHandlerVerticalDeg() else seg.vertDeg).coerceIn(5, 45)
                val vertTan = Math.tan(Math.toRadians(vertDeg.toDouble())).toFloat()
                val view: View = if (seg.clone) host.buildClone(leftSide, drawnPx / density, widthPx / density, height / density)
                    else SegView(context, seg, leftSide, look, leftSide != mainLeft, drawnPx, trigPx, vertTan)
                val p = host.newParams(widthPx, height.coerceAtLeast(1)).apply {
                    gravity = Gravity.TOP or Gravity.LEFT
                    x = if (leftSide) 0 else aw - widthPx
                    this.y = top
                }
                runCatching { wm.addView(view, p); views += view }
            }
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        val m = context.resources.displayMetrics
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else m.widthPixels to m.heightPixels
    }

    @SuppressLint("ViewConstructor")
    private inner class SegView(
        context: Context, val seg: Seg, val leftSide: Boolean, val look: Look?, val mirrored: Boolean,
        val drawnPx: Int, val trigPx: Float, val vertTan: Float,
    ) : View(context) {
        private var stripping = false
        private var vertical = false
        private val path = android.graphics.Path()
        private val rectF = android.graphics.RectF()

        /** A gesture's action, with "same as main slider" looked up now so it is always current. */
        private fun act(value: String, slot: String): String =
            if (value == Seg.MAIN) host.mainAction(slot) else value

        private fun inwardIsStrip() = seg.inward == Seg.STRIP || (seg.inward == Seg.MAIN && host.stripArmed())

        private val handler = Handler(Looper.getMainLooper())
        private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
        private val swipe = 28 * context.resources.displayMetrics.density
        private var downX = 0f
        private var downY = 0f
        private var moved = false
        private var longFired = false
        private var swipeFired = false
        private var sliding = false
        private var level = -1f
        private var lastTapAt = 0L
        private var pendingTap: Runnable? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var touching = false
        private val longRun = Runnable {
            val a = act(seg.long, "long")
            if (!moved && a.isNotEmpty() && a != HandlerActionsNone) { longFired = true; haptic(); host.runAction(a) }
        }

        private fun haptic() { performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }

        override fun onDraw(canvas: Canvas) {
            // The window may be wider than the drawing: draw on its outer edge only.
            val dw = drawnPx.coerceIn(1, width.coerceAtLeast(1))
            canvas.save()
            if (!leftSide) canvas.translate((width - dw).toFloat(), 0f)
            drawInner(canvas, dw.toFloat(), height.toFloat())
            canvas.restore()
        }

        private fun drawInner(canvas: Canvas, w: Float, h: Float) {
            // A faint edge line shows where the segment is; while touched it lights up, and a
            // slider segment fills to its level.
            val d = resources.displayMetrics.density
            if (look != null) {
                // The main slider's own colour, outline and corners (swapped when this is the other side).
                val l = if (mirrored) look.tr else look.tl; val r = if (mirrored) look.tl else look.tr
                val bl = if (mirrored) look.br else look.bl; val br = if (mirrored) look.bl else look.br
                rectF.set(0f, 0f, w, h)
                path.reset()
                path.addRoundRect(rectF, floatArrayOf(l * d, l * d, r * d, r * d, br * d, br * d, bl * d, bl * d), android.graphics.Path.Direction.CW)
                paint.style = Paint.Style.FILL
                paint.color = look.color; paint.alpha = look.alpha.coerceIn(0, 255)
                canvas.drawPath(path, paint)
                if (look.strokeDp > 0f) {
                    paint.style = Paint.Style.STROKE; paint.strokeWidth = look.strokeDp * d
                    paint.color = look.strokeColor; paint.alpha = look.strokeAlpha.coerceIn(0, 255)
                    canvas.drawPath(path, paint)
                    paint.style = Paint.Style.FILL
                }
                if (touching) {
                    paint.color = Color.argb(70, 255, 255, 255)
                    if (sliding && level >= 0f) canvas.drawRect(0f, h * (1f - level), w, h, paint) else canvas.drawPath(path, paint)
                }
                return
            }
            val line = 2 * d
            paint.color = Color.argb(if (touching) 120 else 55, 128, 128, 128)
            if (leftSide) canvas.drawRect(0f, 0f, line, h, paint) else canvas.drawRect(w - line, 0f, w, h, paint)
            if (touching) {
                paint.color = Color.argb(60, 128, 128, 128)
                if (sliding && level >= 0f) canvas.drawRect(0f, h * (1f - level), w, h, paint)
                else canvas.drawRect(0f, 0f, w, h, paint)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; moved = false; vertical = false; longFired = false; swipeFired = false; sliding = false; touching = true
                    handler.postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true; handler.removeCallbacks(longRun)
                        if (seg.mode != Seg.MODE_ACTIONS && abs(dx) <= abs(dy) * vertTan) sliding = true
                    }
                    // A mostly-vertical move is a swipe up or down for good: the strip may only open for a
                    // clearly sideways move toward the middle, never from a vertical swipe that drifts.
                    if (!stripping && abs(dx) <= abs(dy) * vertTan && abs(dy) > slop) vertical = true
                    if (moved && !sliding && !stripping && !vertical && abs(dx) > (if (trigPx > 0f) trigPx else 2 * slop) && abs(dx) > abs(dy) * vertTan &&
                        (if (leftSide) dx > 0 else dx < 0) && inwardIsStrip()
                    ) {
                        stripping = true; host.stripBegin(leftSide, mirrored)
                    }
                    if (stripping) host.stripMove(e.rawX, e.rawY)
                    // A swipe runs its action the moment the finger has travelled far enough, like the main
                    // bar, not when it is lifted.
                    if (!sliding && !stripping && !longFired && !swipeFired && (abs(dx) >= swipe || abs(dy) >= swipe)) {
                        val a = swipeAction(dx, dy)
                        if (a.isNotEmpty() && a != Seg.STRIP && a != HandlerActionsNone) {
                            swipeFired = true; handler.removeCallbacks(longRun); haptic(); host.runAction(a)
                        }
                    }
                    if (sliding) {
                        val f = (1f - e.y / height.coerceAtLeast(1)).coerceIn(0f, 1f)
                        if (abs(f - level) >= 0.01f) {
                            level = f
                            host.setLevel(seg.mode, f)?.let { host.message(it) }
                            invalidate()
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    touching = false; invalidate()
                    if (stripping) { stripping = false; host.stripEnd(e.rawX, e.rawY) }
                    else if (!sliding && !longFired && !swipeFired) finish(e.rawX - downX, e.rawY - downY)
                    sliding = false; level = -1f
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun); touching = false; sliding = false; level = -1f; invalidate()
                    if (stripping) { stripping = false; host.stripCancel() }
                }
            }
            return true
        }

        private fun swipeAction(dx: Float, dy: Float): String =
            if (abs(dx) >= abs(dy)) {
                val toMiddle = if (leftSide) dx > 0 else dx < 0
                if (toMiddle) act(seg.inward, "in") else act(seg.outward, "out")
            } else if (dy < 0) act(seg.up, "up") else act(seg.down, "down")

        private fun finish(dx: Float, dy: Float) {
            if (abs(dx) < swipe && abs(dy) < swipe) { tapped(); return }
            val action = swipeAction(dx, dy)
            if (action.isNotEmpty() && action != Seg.STRIP && action != HandlerActionsNone) host.runAction(action)
        }

        private fun run(action: String) { if (action.isNotEmpty() && action != HandlerActionsNone && action != Seg.STRIP) host.runAction(action) }

        private fun tapped() {
            val tap = act(seg.tap, "tap"); val dbl = act(seg.double, "double")
            if (dbl.isEmpty() || dbl == HandlerActionsNone) { run(tap); return }
            val now = System.currentTimeMillis()
            if (now - lastTapAt < 300) {
                pendingTap?.let { handler.removeCallbacks(it) }; pendingTap = null; lastTapAt = 0
                run(dbl)
            } else {
                lastTapAt = now
                val r = Runnable { pendingTap = null; run(tap) }
                pendingTap = r; handler.postDelayed(r, 300)
            }
        }
    }
}
