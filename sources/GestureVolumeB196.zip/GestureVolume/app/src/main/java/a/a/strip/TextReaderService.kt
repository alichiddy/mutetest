package a.a.strip

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import a.a.utils.ShizukuShell

/**
 * "A text reader": a second, separate accessibility service whose only job is to read the text that is
 * on the screen under a point or inside a box (a sentence, a button's label, written digits). A's main
 * accessibility service stays as it is, unable to read any window. This one is switched on by A through
 * Shizuku only while a copy is needed ([TextReaderControl]) and switched off again right after.
 * It does nothing on its own: no events are used, nothing is stored.
 */
class TextReaderService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** The top window first, then the ones below it. */
    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val ws = runCatching { windows }.getOrNull().orEmpty().sortedByDescending { it.layer }
        for (w in ws) w.root?.let { out.add(it) }
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private fun label(n: AccessibilityNodeInfo): String {
        if (n.isPassword) return ""
        val t = n.text?.toString().orEmpty().trim()
        if (t.isNotEmpty()) return t
        return n.contentDescription?.toString().orEmpty().trim()
    }

    /** The text of the smallest item that holds the point (x, y) on the screen, from the top-most window that has one. */
    fun textAt(x: Int, y: Int): String {
        for (root in roots()) {
            var best = ""
            var bestArea = Long.MAX_VALUE
            val r = Rect()
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || depth > 60) return
                n.getBoundsInScreen(r)
                if (!r.contains(x, y)) return
                if (n.isVisibleToUser) {
                    val t = label(n)
                    val area = r.width().toLong() * r.height().toLong()
                    if (t.isNotEmpty() && area > 0 && area < bestArea) { bestArea = area; best = t }
                }
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
            if (best.isNotEmpty()) return best
        }
        return ""
    }

    /** All the texts whose centre lies inside [box], top to bottom, one per line. */
    fun textIn(box: Rect): String {
        for (root in roots()) {
            val found = ArrayList<Pair<Rect, String>>()
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || depth > 60) return
                val b = Rect()
                n.getBoundsInScreen(b)
                if (!Rect.intersects(b, box)) return
                if (n.isVisibleToUser) {
                    val t = label(n)
                    if (t.isNotEmpty() && box.contains(b.centerX(), b.centerY())) found.add(b to t)
                }
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
            if (found.isNotEmpty()) {
                // A parent and its child often carry the same words: keep each text once.
                val seen = HashSet<String>()
                return found.sortedWith(compareBy({ it.first.top / 24 }, { it.first.left }))
                    .filter { seen.add(it.second) }.joinToString("\n") { it.second }
            }
        }
        return ""
    }

    companion object {
        @Volatile var instance: TextReaderService? = null
    }
}

/** Switches the text reader on and off through Shizuku, so it is on only for the moments it is needed. */
object TextReaderControl {
    private const val PREFS = "text_reader"
    private val main = Handler(Looper.getMainLooper())
    private var offRun: Runnable? = null

    fun isOn() = TextReaderService.instance != null

    private fun names(ctx: Context): Pair<String, String> {
        val cn = ComponentName(ctx.applicationContext, TextReaderService::class.java)
        return cn.flattenToString() to cn.flattenToShortString()
    }

    private fun flag(ctx: Context, on: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("byA", on).apply()
    }

    private fun flagged(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("byA", false)

    private fun enableNow(ctx: Context) {
        val (c1, c2) = names(ctx)
        val script = "C1='$c1'; C2='$c2'; OLD=\$(settings get secure enabled_accessibility_services); " +
            "case \":\$OLD:\" in *\":\$C1:\"*|*\":\$C2:\"*) ;; *) " +
            "if [ -z \"\$OLD\" ] || [ \"\$OLD\" = null ]; then settings put secure enabled_accessibility_services \"\$C1\"; " +
            "else settings put secure enabled_accessibility_services \"\$OLD:\$C1\"; fi;; esac; " +
            "settings put secure accessibility_enabled 1"
        runCatching { ShizukuShell.run(script) { } }
    }

    private fun disableNow(ctx: Context) {
        val (c1, c2) = names(ctx)
        val script = "C1='$c1'; C2='$c2'; OLD=\$(settings get secure enabled_accessibility_services); " +
            "NEW=\$(echo \"\$OLD\" | tr ':' '\\n' | grep -v -x -F -e \"\$C1\" -e \"\$C2\" | grep -v '^null\$' | grep -v '^\$' | paste -sd: -); " +
            "if [ -z \"\$NEW\" ]; then settings delete secure enabled_accessibility_services; " +
            "else settings put secure enabled_accessibility_services \"\$NEW\"; fi"
        runCatching { ShizukuShell.run(script) { } }
    }

    /** Starts switching it on (does not wait). Does nothing when it is already on or Shizuku is not ready. */
    fun ensureOn(ctx: Context) {
        val app = ctx.applicationContext
        main.post { offRun?.let { main.removeCallbacks(it) }; offRun = null }
        if (isOn() || !ShizukuShell.isReady()) return
        Thread {
            flag(app, true)
            enableNow(app)
        }.start()
    }

    /** Blocking: switches it on and waits until it is ready (up to [waitMs]). True when it is on. */
    fun ensureOnBlocking(ctx: Context, waitMs: Long = 3000): Boolean {
        val app = ctx.applicationContext
        main.post { offRun?.let { main.removeCallbacks(it) }; offRun = null }
        if (isOn()) return true
        if (!ShizukuShell.isReady()) return false
        flag(app, true)
        enableNow(app)
        val end = System.currentTimeMillis() + waitMs
        while (!isOn() && System.currentTimeMillis() < end) {
            try { Thread.sleep(80) } catch (_: InterruptedException) { }
        }
        return isOn()
    }

    /** Switches it off after [ms], but only when A switched it on (a copy that the person turned on by hand stays on). */
    fun offLater(ctx: Context, ms: Long) {
        val app = ctx.applicationContext
        if (!flagged(app)) return
        main.post {
            offRun?.let { main.removeCallbacks(it) }
            val r = Runnable { offRun = null; offNow(app) }
            offRun = r
            main.postDelayed(r, ms)
        }
    }

    /** Switches it off now (the manual button, and the safety when A starts). */
    fun offNow(ctx: Context) {
        val app = ctx.applicationContext
        if (!ShizukuShell.isReady()) return
        Thread {
            disableNow(app)
            flag(app, false)
        }.start()
    }

    /** When A starts: if it was left on by A (a crash, say), switch it off. */
    fun safetyOff(ctx: Context) {
        val app = ctx.applicationContext
        if (!flagged(app)) return
        Thread {
            try { Thread.sleep(5000) } catch (_: InterruptedException) { }
            if (ShizukuShell.isReady()) {
                disableNow(app)
                flag(app, false)
            }
        }.start()
    }
}
