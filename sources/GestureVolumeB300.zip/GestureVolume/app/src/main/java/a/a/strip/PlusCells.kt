package a.a.strip

import android.content.SharedPreferences

/**
 * The cells window's "+" options, read from one window's settings (the main slider's or a segment's own):
 *  - "+ in empty cells": blank cells show a "+"; a tap (in the editing window) or a release (in the live window) on one opens its editing window.
 *  - "Hold a cell to edit it": the thumb resting on a cell for the system's hold time opens its editing window (only while the "+ in empty cells" option is off).
 *  - "+ after the last cell": one more slot after the last cell; it adds a blank cell and opens its editing window.
 * Scope values: 0 = main window and folders, 1 = main window only, 2 = folders only.
 * "Where" values for the last-cell "+": 0 = both, 1 = only from a gesture, 2 = only in the cells editing window.
 */
object PlusCells {
    const val SCOPE_BOTH = 0
    const val SCOPE_MAIN = 1
    const val SCOPE_FOLDERS = 2

    const val WHERE_BOTH = 0
    const val WHERE_GESTURE = 1
    const val WHERE_EDITOR = 2

    private fun inScope(scope: Int, folder: Boolean) =
        scope == SCOPE_BOTH || (scope == SCOPE_MAIN && !folder) || (scope == SCOPE_FOLDERS && folder)

    /** Whether blank cells show a "+" in the main window ([folder] false) or in a folder's window. */
    fun empty(sp: SharedPreferences, folder: Boolean): Boolean =
        sp.getBoolean("stripPlusEmpty", false) && inScope(sp.getInt("stripPlusEmptyScope", SCOPE_BOTH), folder)

    /** Whether the slot after the last cell shows a "+", in the live window ([gesture] true) or in the editing window. */
    fun end(sp: SharedPreferences, folder: Boolean, gesture: Boolean): Boolean {
        if (!sp.getBoolean("stripPlusEnd", false)) return false
        if (!inScope(sp.getInt("stripPlusEndScope", SCOPE_BOTH), folder)) return false
        val where = sp.getInt("stripPlusEndWhere", WHERE_BOTH)
        return if (gesture) where != WHERE_EDITOR else where != WHERE_GESTURE
    }

    /** Whether resting on a cell opens its editing window (the hold option; it is the alternative to "+ in empty cells"). */
    fun hold(sp: SharedPreferences): Boolean =
        sp.getBoolean("stripHoldEdit", false) && !sp.getBoolean("stripPlusEmpty", false)
}
