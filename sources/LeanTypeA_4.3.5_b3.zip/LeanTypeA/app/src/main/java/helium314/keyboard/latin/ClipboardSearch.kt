// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import java.text.Normalizer

/**
 * LeanType A addition: advanced search for the clipboard.
 *
 * - Not case sensitive, accents are ignored.
 * - Plain words: a clip is found when it contains ANY of the words; punctuation and spaces inside
 *   are ignored ("wifi" finds "Wi-Fi", "e mail" finds "email"). Clips that match more words come first.
 * - "words in quotes": exact phrase (still not case sensitive). A clip must contain every quoted phrase.
 * - -word : clips containing this word are left out.
 * - A word that is not found exactly can still match when its letters appear in order inside one
 *   word of the clip (a typo-friendly fallback, only for words of 4+ letters).
 */
object ClipboardSearch {
    class Query(val phrases: List<String>, val words: List<String>, val excluded: List<String>) {
        val isEmpty get() = phrases.isEmpty() && words.isEmpty() && excluded.isEmpty()
    }

    private val ACCENTS = Regex("\\p{Mn}+")

    /** Lowercase + accent-free, letters and digits only (anything else is dropped). */
    fun squash(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in Normalizer.normalize(s, Normalizer.Form.NFD).replace(ACCENTS, "")) {
            if (ch.isLetterOrDigit()) sb.append(ch.lowercaseChar())
        }
        return sb.toString()
    }

    /** Lowercase + accent-free, whitespace collapsed, punctuation kept (used for quoted phrases). */
    private fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(ACCENTS, "").lowercase().replace(Regex("\\s+"), " ")

    fun parse(raw: String): Query {
        val phrases = mutableListOf<String>()
        val words = mutableListOf<String>()
        val excluded = mutableListOf<String>()
        var i = 0
        val n = raw.length
        while (i < n) {
            val c = raw[i]
            when {
                c == '"' || c == '“' || c == '”' -> {
                    var j = i + 1
                    while (j < n && raw[j] != '"' && raw[j] != '”' && raw[j] != '“') j++
                    val phrase = fold(raw.substring(i + 1, j)).trim()
                    if (phrase.isNotEmpty()) phrases.add(phrase)
                    i = j + 1 // a missing closing quote simply takes the rest of the text
                }
                c.isWhitespace() -> i++
                else -> {
                    var j = i
                    while (j < n && !raw[j].isWhitespace() && raw[j] != '"') j++
                    val token = raw.substring(i, j)
                    i = j
                    if (token.length > 1 && token[0] == '-') {
                        val w = squash(token.substring(1))
                        if (w.isNotEmpty()) excluded.add(w)
                    } else {
                        val w = squash(token)
                        if (w.isNotEmpty()) words.add(w)
                    }
                }
            }
        }
        return Query(phrases, words, excluded)
    }

    private fun isSubsequence(needle: String, hay: String): Boolean {
        var k = 0
        for (ch in hay) {
            if (k < needle.length && ch == needle[k]) k++
        }
        return k == needle.length
    }

    /** Score > 0 when the text matches the query, 0 when it does not. */
    fun score(query: Query, text: String): Int {
        if (query.isEmpty) return 1
        val folded = fold(text)
        for (p in query.phrases) if (!folded.contains(p)) return 0
        val squashed = squash(text)
        for (e in query.excluded) if (squashed.contains(e)) return 0
        var score = query.phrases.size * 10
        if (query.words.isNotEmpty()) {
            var hits = 0
            var tokens: List<String>? = null
            for (w in query.words) {
                if (squashed.contains(w)) {
                    hits++
                } else if (w.length >= 4) {
                    if (tokens == null) tokens = folded.split(' ').map { squash(it) }.filter { it.isNotEmpty() }
                    if (tokens.any { it.length >= w.length - 1 && isSubsequence(w, it) }) hits++
                }
            }
            if (hits == 0 && query.phrases.isEmpty()) return 0
            // quoted phrases are required, plain words only add to the ranking when phrases exist
            score += hits * 5
            if (hits == query.words.size) score += 3
        } else if (query.phrases.isEmpty()) {
            // only exclusions: everything that is not excluded matches
            score = 1
        }
        return score
    }

    /** Clips that match, best match first (same-score clips keep their original order). */
    fun filter(clips: List<ClipboardHistoryEntry>, rawQuery: String): List<ClipboardHistoryEntry> {
        val q = parse(rawQuery)
        if (q.isEmpty) return clips
        return clips.filter { it.imageUri == null }
            .map { it to score(q, it.text) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second } // stable
            .map { it.first }
    }

    /**
     * The part of a long text that is shown on a search result card: a window around the first match,
     * so the match is visible even when it is far inside the text. Returns the text and the ranges to highlight.
     */
    fun snippet(query: Query, text: String, maxChars: Int = 220): Pair<String, List<IntRange>> {
        val ranges = findMatches(query, text)
        if (text.length <= maxChars) return text to ranges
        val first = ranges.firstOrNull()?.first ?: 0
        var start = (first - maxChars / 3).coerceAtLeast(0)
        val end = (start + maxChars).coerceAtMost(text.length)
        if (end - start < maxChars) start = (end - maxChars).coerceAtLeast(0)
        val prefix = if (start > 0) "…" else ""
        val suffix = if (end < text.length) "…" else ""
        val cut = prefix + text.substring(start, end) + suffix
        val shifted = ranges.filter { it.last >= start && it.first < end }.map {
            val a = (it.first - start).coerceAtLeast(0) + prefix.length
            val b = (it.last - start).coerceAtMost(end - start - 1) + prefix.length
            a..b
        }
        return cut to shifted
    }

    /** Character ranges of the original text to highlight: exact phrases, and words ignoring punctuation. */
    fun findMatches(query: Query, text: String): List<IntRange> {
        val result = mutableListOf<IntRange>()
        val lower = text.lowercase()
        for (p in query.phrases) {
            var from = 0
            while (true) {
                val idx = lower.indexOf(p, from)
                if (idx < 0) break
                result.add(idx until idx + p.length)
                from = idx + p.length.coerceAtLeast(1)
            }
        }
        if (query.words.isNotEmpty()) {
            // map squashed positions back to original positions
            val map = ArrayList<Int>(text.length)
            val sb = StringBuilder(text.length)
            for ((idx, ch) in text.withIndex()) {
                val folded = Normalizer.normalize(ch.toString(), Normalizer.Form.NFD).replace(ACCENTS, "")
                for (f in folded) {
                    if (f.isLetterOrDigit()) {
                        sb.append(f.lowercaseChar())
                        map.add(idx)
                    }
                }
            }
            val squashed = sb.toString()
            for (w in query.words) {
                var from = 0
                while (true) {
                    val idx = squashed.indexOf(w, from)
                    if (idx < 0) break
                    result.add(map[idx]..map[idx + w.length - 1])
                    from = idx + w.length.coerceAtLeast(1)
                }
            }
        }
        return result.sortedBy { it.first }
    }
}
