package a.a.strip

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import a.a.utils.ShizukuShell

/**
 * "Copy what is under the thumb", used by the click circle. At the moment of release the screen is
 * captured (a screenshot, plus the list of on-screen texts) BEFORE the tap is sent, so a button that
 * changes its text when pressed (a new one-time code, say) is still read as it was under the thumb.
 *
 * Reading order: the text of the thing under the spot (a sentence, a button's label, written digits),
 * and when there is none, the digits drawn at that spot, read with the same global [OtpOcr] that was
 * taught in the OCR screen (English digits work by default; Persian and Arabic are the taught ones).
 * Nothing is kept in memory afterwards.
 */
object ScreenCopy {
    class Snap(val shot: Bitmap?, val dump: String, val x: Float, val y: Float)

    /** Blocking. Takes the screenshot and the text list together; waits at most about 0.6 s for the list. */
    fun snapshot(ctx: Context, x: Float, y: Float): Snap {
        val buf = StringBuffer()
        val t = Thread { runCatching { ShizukuShell.run("uiautomator dump /dev/stdout") { buf.append(it).append('\n') } } }
        t.start()
        // The circle's own window needs a moment to be gone before the screen is captured.
        try { Thread.sleep(120) } catch (_: InterruptedException) { }
        val shot = runCatching { ScreenOcr.capture() }.getOrNull()
        runCatching { t.join(600) }
        return Snap(shot, buf.toString(), x, y)
    }

    /** What was under the spot: its text, else the digits drawn there, else "". */
    fun result(ctx: Context, s: Snap): String {
        val fromText = runCatching { textAt(s.dump, s.x.toInt(), s.y.toInt()) }.getOrDefault("")
        if (fromText.isNotEmpty()) {
            s.shot?.recycle()
            return fromText
        }
        val shot = s.shot ?: return ""
        return try {
            val d = ctx.resources.displayMetrics.density
            val w = (300 * d).toInt()
            val h = (56 * d).toInt()
            val l = (s.x - w / 2f).toInt().coerceIn(0, maxOf(0, shot.width - w))
            val t = (s.y - h / 2f).toInt().coerceIn(0, maxOf(0, shot.height - h))
            val pic = ScreenOcr.crop(shot, ScreenOcr.Region(Rect(l, t, l + w, t + h), shot.width, shot.height))
            val r = if (pic == null) "" else runCatching { OtpOcr.read(ctx, pic) }.getOrDefault("")
            pic?.recycle()
            if (r.length in 4..10 && !r.contains('?')) r else ""
        } finally {
            OtpOcr.release()
        }
    }

    fun copy(ctx: Context, text: String) {
        runCatching {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("A", text))
            WidgetFloat.toast(ctx, "Copied: " + if (text.length > 40) text.take(40) + "…" else text)
        }
    }

    private val node = Regex("<node ([^>]*)>")
    private val textAttr = Regex("""\btext="([^"]*)"""")
    private val descAttr = Regex("""content-desc="([^"]*)"""")
    private val boundsAttr = Regex("""bounds="\[(\d+),(\d+)]\[(\d+),(\d+)]"""")
    private val onlyDigits = Regex("[\\d\\s,.\\-]+")

    /** The smallest on-screen item that holds the spot and has text; its whole text (a sentence stays whole). */
    private fun textAt(dump: String, x: Int, y: Int): String {
        var best = ""
        var bestArea = Long.MAX_VALUE
        for (m in node.findAll(dump)) {
            val a = m.groupValues[1]
            val b = boundsAttr.find(a) ?: continue
            val l = b.groupValues[1].toInt(); val t = b.groupValues[2].toInt()
            val r = b.groupValues[3].toInt(); val bt = b.groupValues[4].toInt()
            if (x < l || x > r || y < t || y > bt) continue
            var txt = unescape(textAttr.find(a)?.groupValues?.get(1).orEmpty()).trim()
            if (txt.isEmpty()) txt = unescape(descAttr.find(a)?.groupValues?.get(1).orEmpty()).trim()
            if (txt.isEmpty()) continue
            val area = (r - l).toLong() * (bt - t).toLong()
            if (area < bestArea) { bestArea = area; best = txt }
        }
        if (best.isEmpty()) return ""
        // Digits written in Persian or Arabic become English digits; anything else is copied as it is.
        val e = OtpOcr.toEnglish(best)
        return if (e.matches(onlyDigits)) e.replace(Regex("[\\s,.\\-]"), "") else best
    }

    private fun unescape(s: String): String {
        if (!s.contains('&')) return s
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
            .replace(Regex("&#(\\d+);")) { it.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: "" }
            .replace("&amp;", "&")
    }
}
