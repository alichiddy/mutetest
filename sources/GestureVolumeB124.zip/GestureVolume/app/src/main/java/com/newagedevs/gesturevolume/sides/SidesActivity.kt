package com.newagedevs.gesturevolume.sides

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.service.OverlayRuntime

/**
 * Side bars: a thin strip on the left and/or right edge, each with up to three segments. A segment
 * can have actions on tap, double tap, long press and four swipes, or act as a volume or brightness
 * slider. Changes apply at once.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class SidesActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var cfg by remember { mutableStateOf(SideConfig.load(this@SidesActivity)) }
                    fun update(new: SideConfig) {
                        val keyboardChanged = new.hideForKeyboard != cfg.hideForKeyboard
                        cfg = new
                        SideConfig.save(this@SidesActivity, new)
                        OverlayRuntime.activeController?.let { if (keyboardChanged) it.refreshAutoHide() else it.refreshSides() }
                    }
                    Column(
                        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text("Side bars", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "A thin strip on each edge. Split it into up to 3 segments; each segment has its own actions, or works as a volume or brightness slider. Swipe in/out means toward/away from the screen's middle, so both sides mirror.",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Hide the side bars while the keyboard is open", Modifier.weight(1f))
                            Switch(checked = cfg.hideForKeyboard, onCheckedChange = { update(cfg.copy(hideForKeyboard = it)) })
                        }
                        Text(
                            "For phones using Back-swipe gestures: with the keyboard open the edge strips would fight the Back swipe. You can bind \"Back\" to Swipe in on a segment instead.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Keep the main slider's bar away while a side segment changes volume or brightness", Modifier.weight(1f))
                            Switch(checked = cfg.hideMainBar, onCheckedChange = { update(cfg.copy(hideMainBar = it)) })
                        }
                        HorizontalDivider()
                        SideEditor("Left side", cfg.left) { update(cfg.copy(left = it)) }
                        HorizontalDivider()
                        SideEditor("Right side", cfg.right) { update(cfg.copy(right = it)) }
                    }
                }
            }
        }
    }

    @Composable
    private fun SideEditor(title: String, side: Side, onChange: (Side) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Switch(checked = side.on, onCheckedChange = { onChange(side.copy(on = it)) })
        }
        if (!side.on) return
        var sel by remember { mutableStateOf(0) }
        val selected = sel.coerceIn(0, side.segs.lastIndex)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Segment")
            for (n in 1..3) FilterChip(
                selected = selected == n - 1,
                onClick = {
                    // Pressing a number turns on that many segments (settings of the others are kept,
                    // just switched off) and brings that segment's settings to the top.
                    val segs = side.segs.toMutableList()
                    while (segs.size < n) segs += Seg(topPct = (20 + 25 * segs.size).coerceAtMost(75), heightPct = 20)
                    for (k in segs.indices) segs[k] = segs[k].copy(on = k < n)
                    sel = n - 1
                    onChange(side.copy(segs = segs))
                },
                label = { Text("$n") },
            )
        }
        // The chosen segment first, the others below it.
        val order = listOf(selected) + side.segs.indices.filter { it != selected }
        order.forEach { i ->
            SegEditor(i + 1, side.segs[i]) { new -> onChange(side.copy(segs = side.segs.toMutableList().also { it[i] = new })) }
        }
    }

    @Composable
    private fun SegEditor(number: Int, seg: Seg, onChange: (Seg) -> Unit) {
        Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Segment $number", Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text(if (seg.on) "On" else "Off", fontSize = 12.sp)
                    Switch(checked = seg.on, onCheckedChange = { onChange(seg.copy(on = it)) })
                }
                if (!seg.on) return@Column
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Exact clone of the main slider (same look, gestures, swipe amount, panel)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.clone, onCheckedChange = { onChange(seg.copy(clone = it)) })
                }
                if (!seg.clone) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(seg.mode == Seg.MODE_ACTIONS, { onChange(seg.copy(mode = Seg.MODE_ACTIONS)) }, { Text("Actions") })
                    FilterChip(seg.mode == Seg.MODE_VOLUME, { onChange(seg.copy(mode = Seg.MODE_VOLUME)) }, { Text("Volume slider") })
                    FilterChip(seg.mode == Seg.MODE_BRIGHTNESS, { onChange(seg.copy(mode = Seg.MODE_BRIGHTNESS)) }, { Text("Brightness") })
                }
                // Place and size: each segment has its own, or follows the main slider live.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Position: follow the main slider's top (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.posMain, onCheckedChange = { onChange(seg.copy(posMain = it)) })
                }
                if (seg.posMain) {
                    Text("Moved ${seg.shiftPct}% of the screen (negative = up, positive = down)", fontSize = 12.sp)
                    Slider(value = seg.shiftPct.toFloat(), onValueChange = { onChange(seg.copy(shiftPct = it.toInt())) }, valueRange = -60f..60f)
                } else {
                    Text("Starts ${seg.topPct}% from the top", fontSize = 12.sp)
                    Slider(value = seg.topPct.toFloat(), onValueChange = { onChange(seg.copy(topPct = it.toInt())) }, valueRange = 0f..95f)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Height: same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.heightMain, onCheckedChange = { onChange(seg.copy(heightMain = it)) })
                }
                if (!seg.heightMain) {
                    Text("Height ${seg.heightPct}% of the screen", fontSize = 12.sp)
                    Slider(value = seg.heightPct.toFloat(), onValueChange = { onChange(seg.copy(heightPct = it.toInt())) }, valueRange = 5f..100f)
                }
                if (!seg.clone) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Width: same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.copyWidth, onCheckedChange = { onChange(seg.copy(copyWidth = it)) })
                }
                if (!seg.clone && !seg.copyWidth) {
                    Text("Width ${seg.widthDp} dp", fontSize = 12.sp)
                    Slider(value = seg.widthDp.toFloat(), onValueChange = { onChange(seg.copy(widthDp = it.toInt())) }, valueRange = 8f..40f)
                }
                if (!seg.clone) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Slide-in distance: same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.inMain, onCheckedChange = { onChange(seg.copy(inMain = it)) })
                }
                if (!seg.clone && !seg.inMain) {
                    Text(if (seg.inDp == 0) "Slide-in distance: automatic" else "Slide-in distance ${seg.inDp} dp", fontSize = 12.sp)
                    Slider(value = seg.inDp.toFloat(), onValueChange = { onChange(seg.copy(inDp = it.toInt())) }, valueRange = 0f..40f)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Touch area: same rule as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.touchMain, onCheckedChange = { onChange(seg.copy(touchMain = it)) })
                }
                if (!seg.touchMain) {
                    Text(if (seg.touchDp == 0) "Touch area: exactly as drawn" else "Touch area at least ${seg.touchDp} dp", fontSize = 12.sp)
                    Slider(value = seg.touchDp.toFloat(), onValueChange = { onChange(seg.copy(touchDp = it.toInt())) }, valueRange = 0f..60f)
                }
                if (seg.clone) {
                    Text("A clone follows the main slider live for everything else: look, actions, swipe amount, slide-in distance, the panel and the strip. The panel grows out of the clone itself. The width is the main slider's too. Only place, height and touch area are its own.", fontSize = 12.sp)
                    return@Column
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Straight up/down needed: same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.vertMain, onCheckedChange = { onChange(seg.copy(vertMain = it)) })
                }
                if (!seg.vertMain) {
                    Text("Level slides only within ${seg.vertDeg}° of straight up/down; a more angled slide counts as a slide in", fontSize = 12.sp)
                    Slider(value = seg.vertDeg.toFloat(), onValueChange = { onChange(seg.copy(vertDeg = it.toInt().coerceIn(5, 45))) }, valueRange = 5f..45f)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Appearance: colour, outline, corners as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.copyLook, onCheckedChange = { onChange(seg.copy(copyLook = it)) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        onChange(seg.copy(tap = Seg.MAIN, double = Seg.MAIN, long = Seg.MAIN, up = Seg.MAIN, down = Seg.MAIN, inward = Seg.MAIN, outward = Seg.MAIN))
                    }) { Text("All gestures: follow main", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        val p = com.newagedevs.gesturevolume.data.local.SharedPref(this@SidesActivity)
                        onChange(seg.copy(
                            tap = p.getHandlerSingleTapAction(), double = p.getHandlerDoubleTapAction(), long = p.getHandlerLongTapAction(),
                            up = p.getHandlerSwipeUpAction(), down = p.getHandlerSwipeDownAction(),
                            inward = if (p.getStripEnabled()) Seg.STRIP else p.getHandlerSwipeInAction(), outward = p.getHandlerSwipeOutAction(),
                        ))
                    }) { Text("Copy all now", fontSize = 12.sp) }
                }
                Text("Or choose per gesture below: each one can follow the main slider (live), copy it once, or be its own.", fontSize = 12.sp)
                if (seg.mode != Seg.MODE_ACTIONS) Text("Drag up and down on the strip to set it. Tap and the swipes in/out below still work.", fontSize = 12.sp)
                ActionRow("tap", "Tap", seg.tap) { onChange(seg.copy(tap = it)) }
                ActionRow("double", "Double tap", seg.double) { onChange(seg.copy(double = it)) }
                ActionRow("long", "Long press", seg.long) { onChange(seg.copy(long = it)) }
                if (seg.mode == Seg.MODE_ACTIONS) {
                    ActionRow("up", "Swipe up", seg.up) { onChange(seg.copy(up = it)) }
                    ActionRow("down", "Swipe down", seg.down) { onChange(seg.copy(down = it)) }
                }
                ActionRow("in", "Swipe in", seg.inward) { onChange(seg.copy(inward = it)) }
                ActionRow("out", "Swipe out", seg.outward) { onChange(seg.copy(outward = it)) }
            }
        }
    }

    @Composable
    private fun ActionRow(slot: String, name: String, action: String, onPicked: (String) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, Modifier.weight(0.38f), fontSize = 13.sp)
            OutlinedButton(onClick = { SidePicker.pick(this@SidesActivity, slot, onPicked) }, modifier = Modifier.weight(0.62f)) {
                Text(SidePicker.label(this@SidesActivity, action), maxLines = 1, fontSize = 13.sp)
            }
            if (action.isNotEmpty()) TextButton(onClick = { onPicked("") }) { Text("×") }
        }
    }
}
