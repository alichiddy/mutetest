package com.newagedevs.gesturevolume.share

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.io.File

/**
 * Three entries in the share / open-with sheet of any app, all writing into the Download folder
 * with no storage permission and nothing left open:
 *  - "A Download": saves the file; a name that already exists is renamed by the system, "name (1)".
 *  - "A Replace": saves the file under its own name and removes the older file of that name first.
 *  - "A Rename": asks for the name to save it under (the old copy of that name is replaced).
 *
 * When A runs in a second profile (a dual-app space) and Shizuku is ready, the file is also
 * copied to the main profile's Download folder.
 */
open class SaveToDownloadsActivity : Activity() {
    protected open val mode: Int = DOWNLOAD

    private class Item(val uri: Uri?, val bytes: ByteArray?, var name: String, val mime: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val items = collect(intent)
        if (items.isEmpty()) { finishWith("Nothing to save."); return }
        if (mode == RENAME) askNames(items, 0) else saveAll(items)
    }

    @Suppress("DEPRECATION")
    private fun collect(i: Intent): List<Item> {
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
            // ChatGPT Library shares files as ACTION_VIEW with the URI in Intent.data.
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
        }
        if (uris.isEmpty()) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return emptyList()
            return listOf(Item(null, text.toByteArray(), "shared_text.txt", "text/plain"))
        }
        return uris.map { Item(it, null, nameOf(it), contentResolver.getType(it) ?: "application/octet-stream") }
    }

    /** One small window per file: the name to save it under, with "(1)" and "-1" endings already taken off. */
    private fun askNames(items: List<Item>, index: Int) {
        if (index >= items.size) { saveAll(items); return }
        val item = items[index]
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(cleanName(item.name))
            setSelection(0, text.length.let { n -> val dot = text.lastIndexOf('.'); if (dot > 0) dot else n })
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle(if (items.size > 1) "Save as (${index + 1} of ${items.size})" else "Save as")
            .setMessage(item.name)
            .setView(input)
            .setCancelable(true)
            .setPositiveButton("Save") { _, _ ->
                val typed = input.text.toString().trim().replace('/', '_')
                if (typed.isNotEmpty()) item.name = typed
                askNames(items, index + 1)
            }
            .setNegativeButton("Cancel") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun saveAll(items: List<Item>) {
        val app = applicationContext
        Thread {
            val report = try { handle(items) } catch (e: Throwable) { "Could not save: " + (e.message ?: e.javaClass.simpleName) }
            runOnUiThread { finishWith(report, app) }
        }.start()
    }

    private fun finishWith(report: String, app: android.content.Context = applicationContext) {
        Toast.makeText(app, report, Toast.LENGTH_LONG).show()
        finish()
    }

    private fun handle(items: List<Item>): String {
        val saved = ArrayList<String>()
        val notes = ArrayList<String>()
        for (item in items) {
            val src = item.bytes?.inputStream() ?: item.uri?.let { contentResolver.openInputStream(it) } ?: continue
            val replace = mode != DOWNLOAD
            val got = write(src, item.name, item.mime, replace)
            saved += got
            if (replace && got != item.name) notes += "${item.name} could not be replaced (it belongs to another app), so this one was saved as $got"
        }
        if (saved.isEmpty()) return "Nothing was saved."
        var report = "Saved to Downloads: " + saved.joinToString(", ")
        if (notes.isNotEmpty()) report += "\n" + notes.joinToString("\n")
        val user = Process.myUserHandle().hashCode()
        if (user != 0 && ShizukuShell.isReady()) {
            val copied = saved.count { name ->
                ShizukuShell.run("cp -f '/data/media/$user/Download/$name' /data/media/0/Download/") { } == 0
            }
            if (copied > 0) report += "\nAlso copied $copied to the main profile's Download folder."
        }
        return report
    }

    private fun nameOf(uri: Uri): String {
        var name: String? = null
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0)
            }
        }
        return (name ?: uri.lastPathSegment ?: "shared_file").substringAfterLast('/')
    }

    /** "GestureVolume (1).zip" and "GestureVolume-2.zip" become "GestureVolume.zip". */
    private fun cleanName(n: String): String {
        val dot = n.lastIndexOf('.')
        val base = if (dot > 0) n.substring(0, dot) else n
        val ext = if (dot > 0) n.substring(dot) else ""
        return base.replace(Regex("\\s*\\(\\d+\\)$|-\\d+$"), "") + ext
    }

    /** Removes older files of this name from Download. True when none is left that we could see. */
    private fun removeExisting(name: String): Boolean {
        var gone = true
        if (Build.VERSION.SDK_INT >= 29) {
            val found = ArrayList<Uri>()
            runCatching {
                contentResolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                    arrayOf(name, Environment.DIRECTORY_DOWNLOADS + "/%"), null,
                )?.use { while (it.moveToNext()) found += ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, it.getLong(0)) }
            }
            for (u in found) {
                try { if (contentResolver.delete(u, null, null) == 0) gone = false } catch (_: SecurityException) { gone = false }
            }
        }
        // A file the system will not let us delete by its entry (another app's) can still go with
        // "all files access", which A can be given.
        @Suppress("DEPRECATION")
        val f = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name)
        if (f.exists()) {
            if (f.delete()) {
                MediaScannerConnection.scanFile(this, arrayOf(f.path), null, null)
                Thread.sleep(300)
                gone = true
            } else gone = false
        }
        return gone
    }

    /** Writes the stream into Download and returns the name it ended up with. */
    private fun write(input: java.io.InputStream, name: String, mime: String, replace: Boolean): String {
        input.use { src ->
            if (replace) removeExisting(name)
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val out = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("the phone refused to create the file")
                (contentResolver.openOutputStream(out) ?: throw IllegalStateException("cannot open the new file")).use { dst ->
                    src.copyTo(dst)
                }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(out, done, null, null)
                var finalName = name
                contentResolver.query(out, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) finalName = it.getString(0) ?: name
                }
                return finalName
            }
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val target = File(dir, name)
            target.outputStream().use { src.copyTo(it) }
            return target.name
        }
    }

    companion object {
        const val DOWNLOAD = 0
        const val REPLACE = 1
        const val RENAME = 2
    }
}

/** "A Replace": the older file of the same name is removed first. */
class SaveReplaceActivity : SaveToDownloadsActivity() { override val mode: Int get() = REPLACE }

/** "A Rename": a small window asks for the name. */
class SaveRenameActivity : SaveToDownloadsActivity() { override val mode: Int get() = RENAME }
