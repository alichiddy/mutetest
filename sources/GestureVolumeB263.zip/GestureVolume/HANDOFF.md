# HANDOFF (short) - state: B263, not compiled

## Working with Ali
Persian/English, voice dictation ("ID" = idea). NOT a developer: boxes/forms/lists, no code or formulas. Lean replies, accuracy over speed, talk first before big changes, never remind him what to test. App is just "A" (package a.a), repo alichiddy/mutetest; he builds on GitHub Actions and pastes errors (Claude cannot compile). Deliver the zip only (no YML), name the build number (next: B264), bracket-check changed .kt files against the originals. Zero idle RAM: any feature costs nothing when not used. Never wait for a double tap. Terms: "Cells window", "Segments". Source layout: app/src/main/java/a/a/{strip,service,utils,flow,share,ui}.

## Latest builds
- B263: "Allow A as the previous app" option (Previous app dialog; PreviousApp.PREF_ALLOW_A, default off). On: A is no longer skipped by Previous app - Shizuku recents (counts/pick), the tracked history (OverlayController.onForegroundApp notes A's own screens only when the option is on) and the usage-events path (pickFromHistory). Off = as before. Changed: utils/PreviousApp.kt, service/OverlayController.kt, ui/screens/strip/StripEditorScreen.kt.
- B262: long info texts in the cells editor / outside actions folded behind "▾ Info".
- B260: Previous app without Shizuku = MyGesture's way (tracked list of 8 packages from accessibility window changes, launched with MAIN/LAUNCHER intent, flags 0x10200000, via PendingIntent). Needs "Track apps without Shizuku" ON or Usage access. Shizuku way: startActivityFromRecents, moveTaskToFront, `am task lock` (option "stop lock after unpinning").
- B251: Wi-Fi share (3 QR codes, notification row, "Wi-Fi share window" shortcut, upload page).
- B247: tapping a .json opens "Import into A". B244: A in the system file picker.
- B242/B243: volume panel hands an inward swipe to the Cells window (switch panelOpensCells); test bar bottom-left (switch testBarOn).

## Open
1. Test bar visibility (needs Copy report, note "test bar x= y= w= h=").
2. Left vertical segment's volume panel shows a gap to the screen side in portrait (not fixed).
3. Landscape as two windows idea: discuss first.
4. Accessibility service sometimes dropped: his Automate flows overwrite enabled_accessibility_services (not proven); Copy report logs list changes.
5. Older untested items: bank (Resalat) widget sends A away after tap; Persian digit OCR; see his backlog.

## Reminders from the code
- Kept on purpose with old names: GitHubBuild.kt/SharedPref (workflow gesturevolume.yml, release tag gv), assets/automate_flows.json.
- Never put real keys in source (PrivateValues slots).
- Scripts-blocks principle: say whether a new feature is a user-buildable script block or a built-in.
