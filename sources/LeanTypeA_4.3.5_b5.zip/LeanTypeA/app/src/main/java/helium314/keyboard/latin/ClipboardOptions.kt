// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * LeanType A addition: the options of the clipboard (opened with the gear icon in the clipboard icon bar)
 * and the clip shortcuts (a short word that offers a clip in the suggestion strip).
 */
object ClipboardOptions {
    const val KEY_MIDDLE_ELLIPSIS = "clip_opt_middle_ellipsis"
    const val KEY_COLS_PORTRAIT = "clip_opt_cols_portrait"
    const val KEY_COLS_LANDSCAPE = "clip_opt_cols_landscape"
    const val KEY_LINES = "clip_opt_lines"
    const val KEY_SHORTCUTS_ON = "clip_opt_shortcuts"
    private const val KEY_SHORTCUTS = "clip_shortcuts_v1"
    private const val KEY_EDIT_ACTIONS = "clip_edit_actions_v1"

    const val DEFAULT_LINES = 4

    fun middleEllipsis(p: SharedPreferences) = p.getBoolean(KEY_MIDDLE_ELLIPSIS, false)
    fun lines(p: SharedPreferences) = p.getInt(KEY_LINES, DEFAULT_LINES).coerceIn(1, 20)
    fun shortcutsOn(p: SharedPreferences) = p.getBoolean(KEY_SHORTCUTS_ON, true)

    /** 0 = the normal number of columns of the app. */
    fun columns(p: SharedPreferences, landscape: Boolean): Int =
        p.getInt(if (landscape) KEY_COLS_LANDSCAPE else KEY_COLS_PORTRAIT, 0).coerceIn(0, 8)

    // ---------------------------------------------------------------------------------------------
    // buttons shown under the clip editor (null = all)

    fun editActions(p: SharedPreferences): Set<String>? =
        p.getString(KEY_EDIT_ACTIONS, null)?.split(',')?.filter { it.isNotEmpty() }?.toSet()

    fun setEditActions(p: SharedPreferences, names: Collection<String>) {
        p.edit().putString(KEY_EDIT_ACTIONS, names.joinToString(",")).apply()
    }

    // ---------------------------------------------------------------------------------------------
    // clip shortcuts

    data class Shortcut(val key: String, val clipId: Long, val text: String)

    @Volatile private var cachedRaw: String? = null
    @Volatile private var cachedList: List<Shortcut> = emptyList()

    fun loadShortcuts(p: SharedPreferences): List<Shortcut> {
        val raw = p.getString(KEY_SHORTCUTS, null) ?: return emptyList()
        if (raw == cachedRaw) return cachedList
        val list = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                val o = arr.optJSONObject(it) ?: return@mapNotNull null
                val key = o.optString("k")
                if (key.isEmpty()) null else Shortcut(key, o.optLong("id", -1L), o.optString("t"))
            }
        } catch (_: Exception) {
            emptyList()
        }
        cachedList = list
        cachedRaw = raw
        return list
    }

    private fun saveShortcuts(p: SharedPreferences, list: List<Shortcut>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("k", it.key).put("id", it.clipId).put("t", it.text)) }
        p.edit().putString(KEY_SHORTCUTS, arr.toString()).apply()
    }

    fun shortcutOfClip(p: SharedPreferences, clipId: Long): String? =
        loadShortcuts(p).firstOrNull { it.clipId == clipId }?.key

    /** One shortcut per clip, one clip per shortcut word. An empty [word] removes the shortcut of the clip. */
    fun setShortcut(p: SharedPreferences, clipId: Long, text: String, word: String) {
        val key = word.filter { !it.isWhitespace() }
        val list = loadShortcuts(p).filter { it.clipId != clipId && !it.key.equals(key, ignoreCase = true) }.toMutableList()
        if (key.isNotEmpty()) list.add(Shortcut(key, clipId, text))
        saveShortcuts(p, list)
    }

    /** Keeps the saved text of the shortcut in step with an edited clip. */
    fun updateShortcutText(p: SharedPreferences, clipId: Long, text: String) {
        val list = loadShortcuts(p)
        if (list.none { it.clipId == clipId }) return
        saveShortcuts(p, list.map { if (it.clipId == clipId) it.copy(text = text) else it })
    }

    fun findShortcut(p: SharedPreferences, typed: String): Shortcut? {
        if (typed.isEmpty() || !shortcutsOn(p)) return null
        return loadShortcuts(p).firstOrNull { it.key.equals(typed, ignoreCase = true) && it.text.isNotEmpty() }
    }
}
