// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * LeanType A addition: user-made sections of the clipboard (e.g. "Addresses"). Every section has an
 * icon (any emoji or a few characters) that is shown in the icon bar of the clipboard view.
 * Clips moved into a section are not part of the normal history, and are never auto-deleted.
 */
object ClipboardSections {
    private const val PREF = "clipboard_sections_v1"

    /** Icons offered when editing a section. */
    val ICON_CHOICES = listOf(
        "📁", "🏠", "📍", "🏢", "👤", "👨‍👩‍👧", "📞", "✉️", "🔑", "🔒", "💳", "🏦",
        "🌐", "📶", "🔗", "📝", "⭐", "❤️", "🛒", "🍔", "✈️", "🚗", "💼", "🎓",
        "💊", "🎵", "📷", "🎮", "⚽", "💡", "📌", "🧾"
    )

    data class Section(val id: String, val name: String, val icon: String)

    fun load(prefs: SharedPreferences): List<Section> {
        val raw = prefs.getString(PREF, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                val o = arr.optJSONObject(it) ?: return@mapNotNull null
                val id = o.optString("id")
                if (id.isEmpty()) null else Section(id, o.optString("name"), o.optString("icon", "📁"))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun save(prefs: SharedPreferences, list: List<Section>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("icon", it.icon))
        }
        prefs.edit().putString(PREF, arr.toString()).apply()
    }

    fun add(prefs: SharedPreferences, name: String, icon: String = "📁"): Section {
        val list = load(prefs).toMutableList()
        val section = Section(System.currentTimeMillis().toString(36) + list.size, name.trim(), icon)
        list.add(section)
        save(prefs, list)
        return section
    }

    fun update(prefs: SharedPreferences, id: String, name: String? = null, icon: String? = null) {
        val list = load(prefs).map {
            if (it.id == id) it.copy(name = name?.trim() ?: it.name, icon = icon ?: it.icon) else it
        }
        save(prefs, list)
    }

    fun remove(prefs: SharedPreferences, id: String) {
        save(prefs, load(prefs).filter { it.id != id })
    }

    /** Moves a section one place to the left (-1) or right (+1). */
    fun move(prefs: SharedPreferences, id: String, delta: Int) {
        val list = load(prefs).toMutableList()
        val index = list.indexOfFirst { it.id == id }
        val target = index + delta
        if (index < 0 || target < 0 || target >= list.size) return
        val item = list.removeAt(index)
        list.add(target, item)
        save(prefs, list)
    }
}
