// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.keyboard.clipboard

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import androidx.core.graphics.ColorUtils
import helium314.keyboard.latin.ClipboardHistoryEntry
import helium314.keyboard.latin.ClipboardHistoryManager
import helium314.keyboard.latin.ClipboardOptions
import helium314.keyboard.latin.ClipboardSearch
import helium314.keyboard.latin.R
import helium314.keyboard.latin.common.ColorType
import helium314.keyboard.latin.settings.Settings
import helium314.keyboard.latin.utils.BitmapUtils
import helium314.keyboard.latin.utils.isDarkColor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class ClipboardDisplayItem {
    data class Header(val count: Int, val isFolded: Boolean) : ClipboardDisplayItem()
    data class Clip(val entry: ClipboardHistoryEntry) : ClipboardDisplayItem()
}

class ClipboardAdapter(
       val clipboardLayoutParams: ClipboardLayoutParams,
       val keyEventListener: OnKeyEventListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var clipboardHistoryManager: ClipboardHistoryManager? = null

    var pinnedIconResId = 0
    var itemBackgroundId = 0
    var itemTypeFace: Typeface? = null
    var itemTextColor = 0
    /** LeanType A: user-chosen card colour (null = automatic). */
    var cardColor: Int? = null
    var itemTextSize = 0f

    private var filteredList: List<ClipboardHistoryEntry>? = null
    private var searchQuery: String = ""
    private var parsedQuery: ClipboardSearch.Query? = null

    private val displayList = mutableListOf<ClipboardDisplayItem>()
    private var isPinnedFolded = true

    /** LeanType A: the section that is shown (null = the normal history). */
    var activeSection: String? = null
        set(value) {
            if (field != value) {
                field = value
                refresh()
            }
        }

    /** LeanType A: true while the pinned clips are expanded in the normal history. */
    val isPinnedExpanded: Boolean
        get() = !isPinnedFolded

    /** LeanType A: pin icon of the icon bar. Returns true when the pinned clips are shown now. */
    fun togglePinnedExpanded(): Boolean {
        isPinnedFolded = !isPinnedFolded
        refresh()
        return !isPinnedFolded
    }

    /** Names of the sections (id -> icon), for the small badge on search results. */
    var sectionIcons: Map<String, String> = emptyMap()

    var isSelectionMode = false
        private set
    val selectedEntryIds = mutableSetOf<Long>()

    var onSelectionChangedListener: ((selectedCount: Int, totalCount: Int) -> Unit)? = null
    var onClipLongClickListener: ((ClipboardHistoryEntry, View) -> Boolean)? = null

    private var adapterScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /** LeanType A: clipboard options (see ClipboardOptions), set by the view and applied when a card is shown. */
    var maxLinesOption = ClipboardOptions.DEFAULT_LINES
    var middleEllipsisOption = false
    private var attachedRecycler: RecyclerView? = null

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)
        attachedRecycler = recyclerView
        if (!adapterScope.isActive) {
            adapterScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
        }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        if (attachedRecycler === recyclerView) attachedRecycler = null
        adapterScope.cancel()
    }

    val isFiltering: Boolean
        get() = filteredList != null

    fun setSelectionMode(enabled: Boolean) {
        if (isSelectionMode != enabled) {
            isSelectionMode = enabled
            if (!enabled) {
                selectedEntryIds.clear()
            }
            refresh(refilter = false)
            onSelectionChangedListener?.invoke(selectedEntryIds.size, getAllClipEntries().size)
        }
    }

    fun toggleSelection(id: Long) {
        if (selectedEntryIds.contains(id)) {
            selectedEntryIds.remove(id)
        } else {
            selectedEntryIds.add(id)
        }
        refresh(refilter = false)
        onSelectionChangedListener?.invoke(selectedEntryIds.size, getAllClipEntries().size)
    }

    fun selectAll() {
        val all = getAllClipEntries()
        selectedEntryIds.clear()
        selectedEntryIds.addAll(all.map { it.id })
        refresh(refilter = false)
        onSelectionChangedListener?.invoke(selectedEntryIds.size, all.size)
    }

    fun deselectAll() {
        selectedEntryIds.clear()
        refresh(refilter = false)
        onSelectionChangedListener?.invoke(0, getAllClipEntries().size)
    }

    fun getAllClipEntries(): List<ClipboardHistoryEntry> {
        return computeVisibleClips()
    }

    /** The clips that are shown now (search result, a section, or the normal history with pinned clips if expanded). */
    private fun computeVisibleClips(): List<ClipboardHistoryEntry> {
        val all = clipboardHistoryManager?.getClips() ?: emptyList()
        filteredList?.let { return it }
        val section = activeSection
        if (section != null) return all.filter { it.section == section }
        val main = all.filter { it.section == null }
        return if (isPinnedFolded) main.filter { !it.isPinned } else main.filter { it.isPinned } + main.filter { !it.isPinned }
    }

    fun getSelectedEntries(): List<ClipboardHistoryEntry> {
        val all = getAllClipEntries()
        return all.filter { selectedEntryIds.contains(it.id) }
    }

    fun getItemById(id: Long): ClipboardHistoryEntry? {
        return getAllClipEntries().firstOrNull { it.id == id }
    }

    fun findEntryPosition(id: Long): Int {
        return displayList.indexOfFirst { it is ClipboardDisplayItem.Clip && it.entry.id == id }
    }

    private var searchJob: Job? = null
    @Volatile private var searchGeneration = 0

    /**
     * LeanType A: advanced search (see ClipboardSearch), over all clips including the sections.
     * While typing ([background] = true) the work is done off the main thread, so a big clipboard
     * can not freeze the keyboard; a newer search stops the older one.
     */
    fun filter(query: String, background: Boolean = false) {
        searchQuery = query
        val generation = ++searchGeneration
        searchJob?.cancel()
        searchJob = null
        if (query.isBlank()) {
            filteredList = null
            parsedQuery = null
            refresh(refilter = false)
            return
        }
        parsedQuery = ClipboardSearch.parse(query)
        val allClips = clipboardHistoryManager?.getClips() ?: emptyList()
        if (!background) {
            filteredList = ClipboardSearch.filter(allClips, query)
            refresh(refilter = false)
            return
        }
        searchJob = adapterScope.launch {
            val result = withContext(Dispatchers.Default) {
                ClipboardSearch.filter(allClips, query) { generation != searchGeneration }
            }
            if (generation == searchGeneration) {
                filteredList = result
                refresh(refilter = false)
            }
        }
    }

    fun rebuildDisplayList(refilter: Boolean = true) {
        displayList.clear()
        // a changed history (new clip, edited text) must also update an active search result
        if (refilter && searchQuery.isNotBlank() && filteredList != null) {
            filteredList = ClipboardSearch.filter(clipboardHistoryManager?.getClips() ?: emptyList(), searchQuery)
        }
        computeVisibleClips().forEach { displayList.add(ClipboardDisplayItem.Clip(it)) }
    }

    fun refresh(refilter: Boolean = true) {
        rebuildDisplayList(refilter)
        notifyDataSetChanged()
    }

    /** Fresh start of the list (other section, pinned list, ...): back to the top, columns laid out again. */
    fun refreshAndScrollToTop(recyclerView: RecyclerView) {
        refresh(refilter = false)
        (recyclerView.layoutManager as? StaggeredGridLayoutManager)?.invalidateSpanAssignments()
        recyclerView.stopScroll()
        recyclerView.scrollToPosition(0)
        recyclerView.post { recyclerView.scrollToPosition(0) }
    }

    companion object {
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_CLIP = 1
    }

    override fun getItemViewType(position: Int): Int {
        return when (displayList[position]) {
            is ClipboardDisplayItem.Header -> VIEW_TYPE_HEADER
            is ClipboardDisplayItem.Clip -> VIEW_TYPE_CLIP
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_HEADER) {
            val textView = TextView(parent.context).apply {
                val lp = StaggeredGridLayoutManager.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                lp.isFullSpan = true
                layoutParams = lp
                gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
                setPadding(36, 24, 36, 24)
            }
            clipboardLayoutParams.setItemProperties(textView)
            HeaderViewHolder(textView)
        } else {
            val view = LayoutInflater.from(parent.context)
                    .inflate(R.layout.clipboard_entry_key, parent, false)
            ClipViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = displayList[position]) {
            is ClipboardDisplayItem.Header -> (holder as HeaderViewHolder).bind(item)
            is ClipboardDisplayItem.Clip -> (holder as ClipViewHolder).setContent(item.entry)
        }
    }

    fun getItem(position: Int): ClipboardHistoryEntry? {
        val item = displayList.getOrNull(position)
        return if (item is ClipboardDisplayItem.Clip) item.entry else null
    }

    fun removeDisplayItem(position: Int): ClipboardDisplayItem? {
        if (position in 0 until displayList.size) {
            return displayList.removeAt(position)
        }
        return null
    }

    override fun getItemCount(): Int {
        return displayList.size
    }

    private fun createCardBackground(view: View): Drawable {
        val colors = Settings.getValues().mColors
        val radiusDp = Settings.getValues().mKeyBorderRadius.takeIf { it >= 0f } ?: 8f
        val radiusPx = radiusDp * view.resources.displayMetrics.density
        val cardBg = cardColor ?: colors.get(ColorType.POPUP_KEYS_BACKGROUND)
        val mainBg = colors.get(ColorType.MAIN_BACKGROUND)
        val isDark = if (cardColor != null) isDarkColor(cardBg) else (isDarkColor(mainBg) || isDarkColor(cardBg))

        val contentDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(cardBg)
        }

        val maskDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(Color.WHITE)
        }

        val rippleColor = if (isDark) {
            ColorUtils.setAlphaComponent(Color.WHITE, 0x26)
        } else {
            ColorUtils.setAlphaComponent(Color.BLACK, 0x18)
        }

        return RippleDrawable(ColorStateList.valueOf(rippleColor), contentDrawable, maskDrawable)
    }

    inner class HeaderViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView) {
        init {
            textView.apply {
                typeface = itemTypeFace
                setTextColor(itemTextColor)
                setTextSize(TypedValue.COMPLEX_UNIT_PX, itemTextSize)
                background = createCardBackground(this)
                clipToOutline = true
                
                setOnClickListener {
                    isPinnedFolded = !isPinnedFolded
                    refresh()
                }
            }
        }

        fun bind(header: ClipboardDisplayItem.Header) {
            textView.apply {
                text = buildString {
                    append(if (header.isFolded) "▶  " else "▼  ")
                    append(context.getString(R.string.clipboard_pinned))
                    append(" (")
                    append(header.count)
                    append(")")
                }
            }
        }
    }

    inner class ClipViewHolder(
            view: View
    ) : RecyclerView.ViewHolder(view), View.OnClickListener, View.OnTouchListener, View.OnLongClickListener {

        private val selectIconView: ImageView
        private val selectedOverlay: View?
        private val pinnedIconView: ImageView
        private val contentView: TextView
        private val imageContainer: View
        private val imageView: ImageView
        private val imageNameView: TextView

        init {
            view.apply {
                setOnClickListener(this@ClipViewHolder)
                setOnTouchListener(this@ClipViewHolder)
                setOnLongClickListener(this@ClipViewHolder)
                background = createCardBackground(this)
                isHapticFeedbackEnabled = false
                clipToOutline = true
            }
            selectIconView = view.findViewById(R.id.clipboard_entry_select_icon)
            selectedOverlay = view.findViewById(R.id.clipboard_entry_selected_overlay)
            selectedOverlay?.background = GradientDrawable().apply {
                val colors = Settings.getValues().mColors
                val accentColor = colors.get(ColorType.ACTION_KEY_BACKGROUND)
                val radiusDp = Settings.getValues().mKeyBorderRadius.takeIf { it >= 0f } ?: 8f
                val radiusPx = radiusDp * view.resources.displayMetrics.density
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setColor(ColorUtils.setAlphaComponent(accentColor, 0x26))
            }
            pinnedIconView = view.findViewById<ImageView>(R.id.clipboard_entry_pinned_icon).apply {
                visibility = View.GONE
                if (pinnedIconResId != 0) {
                    setImageResource(pinnedIconResId)
                }
            }
            imageContainer = view.findViewById<View>(R.id.clipboard_entry_image_container).apply {
                visibility = View.GONE
            }
            imageView = view.findViewById(R.id.clipboard_entry_image)
            imageNameView = view.findViewById(R.id.clipboard_entry_image_name)
            contentView = view.findViewById<TextView>(R.id.clipboard_entry_content).apply {
                typeface = itemTypeFace
                setTextColor(itemTextColor)
                setTextSize(TypedValue.COMPLEX_UNIT_PX, itemTextSize)
                maxLines = 4
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            clipboardLayoutParams.setItemProperties(view)
            val colors = Settings.getValues().mColors
            colors.setColor(pinnedIconView, ColorType.CLIPBOARD_PIN)
        }

        fun setContent(historyEntry: ClipboardHistoryEntry?) {
            val id = historyEntry?.id ?: 0L
            itemView.tag = id
            val isSelected = isSelectionMode && selectedEntryIds.contains(id)
            val colors = Settings.getValues().mColors

            if (pinnedIconResId != 0) {
                pinnedIconView.setImageResource(pinnedIconResId)
            }
            colors.setColor(pinnedIconView, ColorType.CLIPBOARD_PIN)

            if (isSelectionMode) {
                selectIconView.visibility = View.VISIBLE
                if (isSelected) {
                    selectIconView.setImageResource(R.drawable.ic_check_circle_filled)
                    selectIconView.alpha = 1.0f
                    colors.setColor(selectIconView, ColorType.ACTION_KEY_BACKGROUND)
                    selectedOverlay?.visibility = View.VISIBLE
                } else {
                    selectIconView.setImageResource(R.drawable.ic_check_circle_outline)
                    selectIconView.alpha = 0.5f
                    colors.setColor(selectIconView, ColorType.KEY_ICON)
                    selectedOverlay?.visibility = View.GONE
                }
            } else {
                selectIconView.visibility = View.GONE
                selectedOverlay?.visibility = View.GONE
            }

            if (historyEntry?.imageUri != null) {
                contentView.visibility = View.GONE
                imageContainer.visibility = View.VISIBLE
                val file = java.io.File(historyEntry.imageUri)
                if (file.exists()) {
                    imageNameView.text = file.name
                    val tag = file.absolutePath
                    imageView.tag = tag
                    imageView.setImageDrawable(null)
                    adapterScope.launch {
                        val bitmap = withContext(Dispatchers.IO) {
                            BitmapUtils.decodeSampledBitmap(file, maxDim = 256)
                        }
                        if (imageView.tag == tag) {
                            imageView.setImageBitmap(bitmap)
                        }
                    }
                }
            } else {
                contentView.visibility = View.VISIBLE
                imageContainer.visibility = View.GONE
                contentView.maxLines = maxLinesOption
                val q = parsedQuery
                val fullText = historyEntry?.text ?: ""
                if (q != null && filteredList != null && fullText.isNotEmpty()) {
                    // LeanType A: a search result shows the part around the match, with the match highlighted
                    val (shown, ranges) = ClipboardSearch.snippet(q, fullText.take(20000))
                    val sp = android.text.SpannableString(shown)
                    val hl = ColorUtils.setAlphaComponent(colors.get(ColorType.ACTION_KEY_BACKGROUND), 0x80)
                    for (r in ranges) {
                        val a = r.first.coerceIn(0, shown.length)
                        val b = (r.last + 1).coerceIn(0, shown.length)
                        if (b > a) sp.setSpan(android.text.style.BackgroundColorSpan(hl), a, b, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    val icon = historyEntry?.section?.let { sectionIcons[it] }
                    contentView.text = if (icon != null) android.text.SpannableStringBuilder("$icon ").append(sp) else sp
                } else {
                    contentView.maxLines = maxLinesOption
                    contentView.text = if (middleEllipsisOption) middleEllipsized(fullText) else fullText.take(1000) // truncate displayed text for performance reasons
                }
            }
            pinnedIconView.visibility = if (historyEntry?.isPinned == true) View.VISIBLE else View.GONE
        }

        /**
         * LeanType A: a long clip shows its first part, a row of dots, and its last words, so the end can be
         * recognised too. A clip that fits in the lines is shown as it is.
         */
        private fun middleEllipsized(text: String): CharSequence {
            val rv = attachedRecycler
            val spans = (rv?.layoutManager as? StaggeredGridLayoutManager)?.spanCount ?: 1
            val lines = maxLinesOption
            val lpMargins = (contentView.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.leftMargin + it.rightMargin } ?: 0
            val itemMargins = (itemView.layoutParams as? ViewGroup.MarginLayoutParams)?.let { it.leftMargin + it.rightMargin } ?: 0
            val width = ((rv?.width ?: 0) / spans.coerceAtLeast(1)) - itemMargins - lpMargins -
                contentView.paddingLeft - contentView.paddingRight - contentView.compoundPaddingLeft - contentView.compoundPaddingRight
            if (width < 40 || text.length < 20) return text.take(1000)
            val paint = contentView.paint
            fun lineCount(t: CharSequence): Int =
                android.text.StaticLayout.Builder.obtain(t, 0, t.length, paint, width).setIncludePad(false).build().lineCount

            val head0 = text.take(3000)
            if (text.length <= 3000 && lineCount(head0) <= lines) return text
            // the last words (at most 6, at most 40 characters)
            val tailSrc = text.takeLast(120)
            val words = tailSrc.trimEnd().split(Regex("\\s+"))
            var tail = ""
            for (i in words.indices.reversed()) {
                val candidate = if (tail.isEmpty()) words[i] else words[i] + " " + tail
                if (tail.isNotEmpty() && (candidate.length > 40 || words.size - i > 6)) break
                tail = candidate
            }
            if (tail.length >= text.length / 2) return text.take(1000)
            val dots = " ······ "
            // longest first part that still fits in the lines together with the dots and the last words
            var lo = 0
            var hi = head0.length.coerceAtMost(lines * 300)
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (lineCount(head0.substring(0, mid).trimEnd() + dots + tail) <= lines) lo = mid else hi = mid - 1
            }
            return head0.substring(0, lo).trimEnd() + dots + tail
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(view: View, event: MotionEvent): Boolean {
            if (isSelectionMode) return false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    keyEventListener.onKeyDown(view.tag as Long)
                    view.animate()
                        .scaleX(0.97f)
                        .scaleY(0.97f)
                        .setDuration(90)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (view.scaleX != 1.0f) {
                        view.animate()
                            .scaleX(1.0f)
                            .scaleY(1.0f)
                            .setDuration(120)
                            .start()
                    }
                }
            }
            return false
        }

        override fun onClick(view: View) {
            val id = view.tag as? Long ?: return
            if (isSelectionMode) {
                toggleSelection(id)
                return
            }
            keyEventListener.onKeyUp(id)
        }

        override fun onLongClick(view: View): Boolean {
            val id = view.tag as? Long ?: return false
            if (isSelectionMode) {
                toggleSelection(id)
                return true
            }
            val entry = getItemById(id) ?: return false
            view.isPressed = false
            return onClipLongClickListener?.invoke(entry, view) ?: false
        }
    }
}
