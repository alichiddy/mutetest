package a.a.strip

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import android.view.View

/**
 * One full-screen, touch-free view that exists only while the cells window is open and the option
 * "Show the names of all outside actions" and/or the cancel gap is on. It writes the name of every
 * outside field right at the start of that field (at the window's edge, or where the gap ends), lights
 * the one under the thumb, and paints each active gap band in the user's colour, glow or blur.
 */
class EdgeNames(context: Context) : View(context) {
    /** side: 0 Top, 1 Bottom, 2 Left, 3 Right (screen sides). (x, y) = the pill's anchor on the field's boundary; span = room along the side. */
    class Pill(val key: String, val text: String, val screenSide: Int, val x: Float, val y: Float, val span: Float, val room: Float)

    private var pills: List<Pill> = emptyList()
    private var bands: List<FloatArray> = emptyList()
    private var style = 2
    private var color = 0xFFFF3B30.toInt()
    private var active = ""
    private val dp = context.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val bgOn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * dp }
    private val ink = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); textSize = 13f * dp; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val inkOn = TextPaint(ink).apply { color = 0xFF102A2E.toInt() }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path()
    private val box = RectF()

    /** [bands]: one quad per gap band, 8 numbers each (x0,y0,...x3,y3). */
    fun set(list: List<Pill>, bands: List<FloatArray>, style: Int, color: Int) {
        pills = list; this.bands = bands; this.style = style; this.color = color
        // Blur and glow need the software canvas; only while this view exists.
        setLayerType(if (bands.isNotEmpty() && style != 0) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
        invalidate()
    }

    /** Key ("Side#zone") of the field under the thumb, "" for none. */
    fun setActive(key: String) {
        if (key == active) return
        active = key
        invalidate()
    }

    private fun drawBands(canvas: Canvas) {
        val r = (color shr 16) and 0xFF; val g = (color shr 8) and 0xFF; val b = color and 0xFF
        fun c(a: Int) = (a shl 24) or (r shl 16) or (g shl 8) or b
        for (q in bands) {
            path.reset(); path.moveTo(q[0], q[1]); path.lineTo(q[2], q[3]); path.lineTo(q[4], q[5]); path.lineTo(q[6], q[7]); path.close()
            when (style) {
                0 -> {
                    fill.maskFilter = null; fill.color = c(0x99); canvas.drawPath(path, fill)
                    line.maskFilter = null; line.color = c(0xFF); line.strokeWidth = 1.5f * dp; canvas.drawPath(path, line)
                }
                1 -> {
                    fill.maskFilter = null; fill.color = c(0x33); canvas.drawPath(path, fill)
                    line.maskFilter = BlurMaskFilter(9f * dp, BlurMaskFilter.Blur.NORMAL); line.color = c(0xFF); line.strokeWidth = 5f * dp
                    canvas.drawPath(path, line)
                    line.maskFilter = null; line.strokeWidth = 2f * dp; canvas.drawPath(path, line)
                }
                else -> {
                    fill.maskFilter = BlurMaskFilter(10f * dp, BlurMaskFilter.Blur.NORMAL); fill.color = c(0xB0)
                    canvas.drawPath(path, fill)
                    fill.maskFilter = null
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        drawBands(canvas)
        val h = 28f * dp
        val pad = 10f * dp
        val m = 4f * dp
        for (p in pills) {
            val on = p.key == active
            val paint = if (on) inkOn else ink
            val horizontalSide = p.screenSide <= 1
            // Beside the window the pill is laid flat when the room allows, else it reads from top to bottom.
            val textW = paint.measureText(p.text)
            val flat = horizontalSide || textW + 2f * pad <= p.room - m
            val maxLen = ((if (flat && horizontalSide) p.span else if (flat) p.room - m else p.span) - 2f * pad).coerceAtLeast(24f * dp)
            val t = TextUtils.ellipsize(p.text, paint, maxLen, TextUtils.TruncateAt.END).toString()
            val w = paint.measureText(t) + 2f * pad
            // Pill size on the screen: flat = w x h, upright = h x w.
            val sw = if (flat) w else h
            val sh = if (flat) h else w
            var cx = p.x; var cy = p.y
            when (p.screenSide) {
                0 -> { cy = p.y - m - sh / 2f }
                1 -> { cy = p.y + m + sh / 2f }
                2 -> { cx = p.x - m - sw / 2f }
                else -> { cx = p.x + m + sw / 2f }
            }
            cx = cx.coerceIn(sw / 2f + 2f * dp, (width - sw / 2f - 2f * dp).coerceAtLeast(sw / 2f))
            cy = cy.coerceIn(sh / 2f + 2f * dp, (height - sh / 2f - 2f * dp).coerceAtLeast(sh / 2f))
            canvas.save()
            canvas.translate(cx, cy)
            if (!flat) canvas.rotate(90f)
            box.set(-w / 2f, -h / 2f, w / 2f, h / 2f)
            canvas.drawRoundRect(box, h / 2f, h / 2f, if (on) bgOn else bg)
            if (!on) canvas.drawRoundRect(box, h / 2f, h / 2f, edge)
            canvas.drawText(t, 0f, -(paint.descent() + paint.ascent()) / 2f, paint)
            canvas.restore()
        }
    }
}
