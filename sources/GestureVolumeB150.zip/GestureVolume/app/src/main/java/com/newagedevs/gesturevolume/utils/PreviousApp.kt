package com.newagedevs.gesturevolume.utils

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences

/**
 * "Previous app": goes back to the app used before the one in front, like Recents then tap, but
 * skipping trampoline apps (Better open with, Universal Copy ...) that the user lists.
 *
 * Two sources, no background work of its own:
 *  1. Android's recents list, read on demand through Shizuku (`dumpsys activity recents`).
 *  2. A tiny list of the last few apps fed by the accessibility service's window changes, only
 *     while the "track apps" switch is on (the service then subscribes to window events).
 */
object PreviousApp {
    const val PREF_EXCLUDE = "prevAppExclude"
    const val PREF_TRACK = "prevAppTrack"

    /** One task of the recents list. */
    data class Task(val pkg: String, val component: String?, val visible: Boolean)

    private val history = ArrayList<String>()

    /** Called by the controller for each app that comes to the front. Keeps the last 8. */
    @Synchronized
    fun noteForeground(pkg: String) {
        if (history.isNotEmpty() && history[0] == pkg) return
        history.remove(pkg)
        history.add(0, pkg)
        while (history.size > 8) history.removeAt(history.size - 1)
    }

    @Synchronized
    private fun historyCopy(): List<String> = ArrayList(history)

    fun tracking(sp: SharedPreferences): Boolean = sp.getBoolean(PREF_TRACK, false)

    fun excluded(sp: SharedPreferences): Set<String> =
        sp.getString(PREF_EXCLUDE, "").orEmpty()
            .split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** Parses the output of `dumpsys activity recents`, newest first. */
    fun parse(text: String): List<Task> {
        val out = ArrayList<Task>()
        val starts = Regex("Recent #(\\d+):").findAll(text).toList()
        for ((i, m) in starts.withIndex()) {
            val end = if (i + 1 < starts.size) starts[i + 1].range.first else text.length
            val block = text.substring(m.range.first, end)
            val pkg = Regex("\\bA=(?:\\d+:)?([A-Za-z0-9_.]+)").find(block)?.groupValues?.get(1)
                ?: Regex("\\bI=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: Regex("cmp=([A-Za-z0-9_.]+)/").find(block)?.groupValues?.get(1)
                ?: continue
            val cmp = Regex("cmp=([A-Za-z0-9_.\$]+/[A-Za-z0-9_.\$]+)").find(block)?.groupValues?.get(1)
            out.add(Task(pkg, cmp, block.contains("visible=true")))
        }
        return out
    }

    private fun homePackages(context: Context): Set<String> = runCatching {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        context.packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
    }.getOrDefault(emptySet())

    /** Reads the recents list through Shizuku. Null when Shizuku is not ready or printed nothing usable. Blocking. */
    fun readRecents(): List<Task>? {
        if (!ShizukuShell.isReady()) return null
        val sb = StringBuilder()
        runCatching { ShizukuShell.run("dumpsys activity recents") { sb.append(it).append('\n') } }
        return parse(sb.toString()).takeIf { it.isNotEmpty() }
    }

    /** The task to go to from [tasks], or null. */
    fun pick(context: Context, tasks: List<Task>, skip: Set<String>): Task? {
        val own = context.packageName
        val home = homePackages(context)
        val usable = tasks.filter { it.pkg != own && it.pkg !in home }
        // The top task is the one in front when it is visible (or when the list says nothing about visibility).
        val anyVisibleInfo = tasks.any { it.visible }
        val first = tasks.firstOrNull { it.pkg != own }
        val current = if (first != null && (first.visible || !anyVisibleInfo) && first.pkg !in home) first.pkg else null
        return usable.firstOrNull { it.pkg != current && it.pkg !in skip }
    }

    /** What the Test button shows: the list found and the app it would go to. Blocking. */
    fun test(context: Context, sp: SharedPreferences): String {
        val skip = excluded(sp)
        val sb = StringBuilder()
        val tasks = readRecents()
        if (tasks != null) {
            sb.append("Shizuku recents (newest first):\n")
            tasks.forEachIndexed { n, t -> sb.append("${n + 1}. ${t.pkg}${if (t.visible) " (visible)" else ""}${if (t.pkg in skip) " (skipped)" else ""}\n") }
            sb.append("\nWould go to: ${pick(context, tasks, skip)?.pkg ?: "nothing found"}\n")
        } else {
            sb.append("Shizuku recents: not available (Shizuku not running/allowed, or nothing readable).\n")
        }
        val h = historyCopy()
        sb.append("\nTracked apps (accessibility, newest first, tracking is ${if (tracking(sp)) "ON" else "OFF"}):\n")
        if (h.isEmpty()) sb.append("(empty)\n") else h.forEachIndexed { n, p -> sb.append("${n + 1}. $p${if (p in skip) " (skipped)" else ""}\n") }
        return sb.toString().trim()
    }

    /**
     * Goes to the previous app. Blocking work runs on its own thread; [report] is called from it
     * with a short message when nothing could be done.
     */
    fun go(context: Context, sp: SharedPreferences, report: (String) -> Unit) {
        Thread {
            val skip = excluded(sp)
            val tasks = readRecents()
            val target = tasks?.let { pick(context, it, skip) }
            if (target != null) {
                val cmd = if (target.component != null) "am start -n ${target.component}"
                else "monkey -p ${target.pkg} -c android.intent.category.LAUNCHER 1"
                runCatching { ShizukuShell.run(cmd) { } }
                return@Thread
            }
            // Fallback: the tracked list. Index 0 is the app in front.
            val h = historyCopy()
            val own = context.packageName
            val cur = h.firstOrNull { it != own }
            val pkg = h.firstOrNull { it != own && it != cur && it !in skip }
            val intent = pkg?.let { context.packageManager.getLaunchIntentForPackage(it) }
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(intent) }
            } else {
                report("Previous app: nothing found (use Shizuku, or turn on app tracking)")
            }
        }.start()
    }
}
