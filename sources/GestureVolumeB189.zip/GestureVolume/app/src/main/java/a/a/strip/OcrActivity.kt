package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import a.a.flow.NativeActions
import a.a.utils.ShizukuShell

/**
 * One place for the OCR that reads digits. English digits work from the start; Persian and Arabic
 * digits are taught once here, from a live widget you can press, or from any part of the screen,
 * and then work everywhere (widget cells, the OCR shortcut, scripts).
 */
class OcrActivity : ComponentActivity() {
    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val main = Handler(Looper.getMainLooper())
    private var tick by mutableStateOf(0)
    private var pic by mutableStateOf<Bitmap?>(null)
    private var typed by mutableStateOf("")
    private var liveId by mutableStateOf(-1)
    private var liveView: AppWidgetHostView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    // A tap on the live widget may end on the home screen: bring this screen back (see ReturnGuard).
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val hit = ReturnGuard.hit(liveView, ev)
        val r = super.dispatchTouchEvent(ev)
        if (hit) ReturnGuard.after(this, OcrActivity::class.java)
        return r
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun bringBack() {
        runCatching {
            startActivity(Intent(this, OcrActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    /** A goes to the back; the person drags a box over any screen; then A either keeps the picture to teach from, or reads it. */
    private fun screenPick(learn: Boolean) {
        if (!ShizukuShell.isReady()) {
            toast("This needs Shizuku. Start Shizuku and allow A, then try again.")
            return
        }
        val app = applicationContext
        moveTaskToBack(true)
        Thread {
            try {
                Thread.sleep(500)
                if (learn) {
                    val b = ScreenOcr.snap(app)
                    main.post {
                        if (b == null) toast("Nothing was picked") else {
                            typed = ""
                            pic = b
                            toast("Picked. Open A to teach the digits.")
                            bringBack()
                        }
                    }
                } else {
                    val msg = try { NativeActions.run(app, "ocr_area", "copy", HashMap()) } catch (e: Throwable) { e.message ?: "Could not read it" }
                    main.post { toast(msg); bringBack() }
                }
            } finally {
                OtpOcr.release()
            }
        }.start()
    }

    /** A picture of the live widget as it looks now. */
    private fun liveSnapshot(): Bitmap? {
        val v = liveView ?: return null
        if (v.width < 8 || v.height < 8) return null
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.WHITE)
        v.draw(Canvas(b))
        return b
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Screen() {
        val known = remember(tick) { OtpOcr.learnedDigits(this@OcrActivity) }
        val saved = remember { WidgetKit.savedIds(this@OcrActivity) }
        Column(
            Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("OCR: reading digits", fontSize = 18.sp)
            Text(
                "English digits are read from the start. Persian and Arabic digits are taught once here, and then work everywhere: " +
                    "widget cells, the OCR shortcut and scripts.",
                fontSize = 12.sp,
            )
            Text(
                "Taught digits: " + if (known.isEmpty()) "none yet" else known.sorted().joinToString(" "),
                fontSize = 13.sp,
            )

            Text("1. Teach from a live widget", fontSize = 14.sp)
            Text("Pick a widget, press its button until the code shows inside it, then tap \"Read it and teach\".", fontSize = 11.sp)
            if (saved.isEmpty()) {
                Text("No widget yet. Add one in the Widgets window first.", fontSize = 12.sp)
            } else {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (id in saved) {
                        val name = mgr.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget $id"
                        OutlinedButton(onClick = { liveView = null; liveId = if (liveId == id) -1 else id }) {
                            Text(if (liveId == id) "Hide: $name" else name)
                        }
                    }
                }
            }
            val info = if (liveId != -1) mgr.getAppWidgetInfo(liveId) else null
            if (info != null) {
                key(liveId) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth.value.toInt()
                        val h = 220
                        AndroidView(
                            factory = { ctx -> host.createView(ctx, liveId, info).also { liveView = it } },
                            update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                            modifier = Modifier.fillMaxWidth().height(h.dp),
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        val b = liveSnapshot()
                        if (b == null) toast("The widget has not loaded yet") else { typed = ""; pic = b }
                    }) { Text("Read it and teach") }
                }
            }

            Text("2. Teach from the screen", fontSize = 14.sp)
            Text("A steps aside. Open the app that shows the digits, drag a box over them, then open A again.", fontSize = 11.sp)
            OutlinedButton(onClick = { screenPick(true) }) { Text("Pick digits on the screen") }

            Text("3. Try it", fontSize = 14.sp)
            Text("The same as the OCR shortcut: drag a box over digits and A copies them.", fontSize = 11.sp)
            OutlinedButton(onClick = { screenPick(false) }) { Text("Read part of the screen now") }

            TextButton(onClick = { OtpOcr.forget(this@OcrActivity); tick++ }) { Text("Forget everything taught") }
        }
        pic?.let { Teach(it) }
    }

    @Composable
    private fun Teach(b: Bitmap) {
        val reading = remember(b) { OtpOcr.read(this@OcrActivity, b) }
        val shapes = remember(b) { OtpOcr.shapeCount(b) }
        AlertDialog(
            onDismissRequest = { OtpOcr.release(); pic = null },
            title = { Text("Teach the digits") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().heightIn(max = 140.dp))
                    Text("Shapes found: $shapes. A reads it as: " + reading.ifEmpty { "nothing" }, fontSize = 12.sp)
                    OutlinedTextField(
                        value = typed, onValueChange = { typed = it }, singleLine = true,
                        label = { Text("Type the digits you see") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    toast(OtpOcr.learn(this@OcrActivity, b, typed))
                    OtpOcr.release()
                    tick++
                    pic = null
                }) { Text("Teach") }
            },
            dismissButton = { TextButton(onClick = { OtpOcr.release(); pic = null }) { Text("Cancel") } },
        )
    }
}
