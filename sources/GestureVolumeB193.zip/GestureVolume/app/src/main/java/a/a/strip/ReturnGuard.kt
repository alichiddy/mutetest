package a.a.strip

import android.content.Context
import android.content.Intent
import android.view.MotionEvent
import android.view.View
import a.a.utils.DiagLog
import a.a.utils.ShizukuShell

/**
 * A widget shown inside one of A's screens opens its own screen when tapped (the bank's fingerprint
 * screen, for example). When that screen closes by sending the phone to the home screen, A's screen
 * is gone too. This watches for that after a tap on the widget and brings A's screen back.
 * It needs Shizuku, runs only for a few seconds after the tap, and keeps nothing in memory.
 */
object ReturnGuard {
    @Volatile private var running = false

    /** True when the touch ended on [v] (the widget). */
    fun hit(v: View?, ev: MotionEvent): Boolean {
        if (v == null || ev.actionMasked != MotionEvent.ACTION_UP || v.width <= 0) return false
        return runCatching {
            val at = IntArray(2)
            v.getLocationOnScreen(at)
            val x = ev.rawX.toInt()
            val y = ev.rawY.toInt()
            x >= at[0] && x <= at[0] + v.width && y >= at[1] && y <= at[1] + v.height
        }.getOrDefault(false)
    }

    private fun pause(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { }
    }

    /** Every launcher installed (the default one may be a chooser, or not the one in use). */
    private fun homePackages(app: Context): Set<String> = runCatching {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        app.packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
    }.getOrDefault(emptySet())

    /** The app on top of the screen right now, or "". */
    private fun topPackage(): String {
        var out = ""
        ShizukuShell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'") { line ->
            if (out.isEmpty()) {
                val m = Regex("u\\d+ ([\\w.]+)/").find(line)
                if (m != null) out = m.groupValues[1]
            }
        }
        return out
    }

    /** Call after a tap on the widget: [screen] is the A screen to bring back. */
    fun after(context: Context, screen: Class<*>) {
        if (running || !ShizukuShell.isReady()) return
        running = true
        val app = context.applicationContext
        Thread {
            try {
                val mine = app.packageName
                val home = homePackages(app)
                DiagLog.note("ReturnGuard: tap on the widget, launchers=" + home.joinToString(","))
                var lastTop = ""
                val start = System.currentTimeMillis()
                var sawOther = false
                var homeSeen = 0
                while (System.currentTimeMillis() - start < 12000) {
                    pause(250)
                    val top = runCatching { topPackage() }.getOrDefault("")
                    if (top.isEmpty()) continue
                    if (top != lastTop) { DiagLog.note("ReturnGuard: top=" + top); lastTop = top }
                    if (top == mine) {
                        if (sawOther) break
                        if (System.currentTimeMillis() - start > 3000) { DiagLog.note("ReturnGuard: A stayed on top, nothing to do"); break }
                        continue
                    }
                    if (top in home) {
                        sawOther = true
                        if (++homeSeen >= 1) {
                            DiagLog.note("ReturnGuard: home screen reached, bringing A back")
                            runCatching { ShizukuShell.run("am start -n " + mine + "/" + screen.name + " -f 0x20000") { } }
                            break
                        }
                    } else {
                        sawOther = true
                        homeSeen = 0
                    }
                }
            } finally {
                running = false
            }
        }.start()
    }
}
