package a.a.ui.screens.ziptool

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.GroupHeading
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import java.util.zip.ZipFile

/**
 * "Rename app" for the one tab: the rules of the old Rename tab ([RenameLogic]) giving a [ZipPlan]. The two
 * names are looked for once when the source is loaded ([analyse]); the plan is worked out again only when a
 * new name is typed. Only the applicationId line and the app_name labels change.
 */
class RenameAction : ZipAction {
    /** The source that [analyse] has looked at (null while it has not). */
    var forSource by mutableStateOf<ZipSource?>(null)
    var error by mutableStateOf<String?>(null)
    var oldPkg by mutableStateOf("")
    var oldLabel by mutableStateOf("")
    var newPkg by mutableStateOf("")
    var newLabel by mutableStateOf("")
    var review by mutableStateOf("")

    val pkgOk: Boolean get() = RenameLogic.PKG_OK.matches(newPkg.trim())

    /** The last work-out of [RenameLogic.plan], kept so that the Check box does not read the zip again. */
    private class Calc(
        val src: ZipSource,
        val pkg: String,
        val label: String,
        val plan: RenameLogic.Plan?,
        val error: String?,
    )

    private var calc: Calc? = null

    /** Forgets everything about the last source (a new one was picked). */
    fun forget() {
        forSource = null
        error = null
        review = ""
        oldPkg = ""
        oldLabel = ""
        calc = null
    }

    /** Finds the two names and lists the hand-written spots. Blocks: run it on a worker thread. */
    fun analyse(src: ZipSource) {
        try {
            val found = ZipFile(src.file).use { zf -> RenameLogic.find(zf) }
            val spots = ZipFile(src.file).use { zf -> RenameLogic.reviewList(zf, found.pkg) }
            oldPkg = found.pkg
            oldLabel = found.label
            newPkg = found.pkg
            newLabel = found.label
            review = spots
            error = null
        } catch (e: Throwable) {
            error = e.message ?: e.javaClass.simpleName
            review = ""
        }
        forSource = src
    }

    private fun calcFor(src: ZipSource, pkg: String, label: String): Calc {
        val c = calc
        if (c != null && c.src === src && c.pkg == pkg && c.label == label) return c
        val n = try {
            Calc(src, pkg, label, ZipFile(src.file).use { zf -> RenameLogic.plan(zf, pkg, label) }, null)
        } catch (e: Throwable) {
            Calc(src, pkg, label, null, e.message ?: e.javaClass.simpleName)
        }
        calc = n
        return n
    }

    private fun blocked(vararg problems: String): ZipPlan =
        ZipPlan(emptyMap(), emptySet(), emptyList(), "", problems.toList(), emptyList())

    override fun plan(src: ZipSource): ZipPlan {
        if (forSource !== src) return blocked("Rename app: looking for the package name and app name in the project...")
        val err = error
        if (err != null) return blocked("Rename app: $err")
        val pkg = newPkg.trim()
        val label = newLabel.trim()
        val problems = ArrayList<String>()
        if (!RenameLogic.PKG_OK.matches(pkg)) {
            problems.add("Rename app: the package name needs two or more parts with dots, each starting with a letter (like a.a3).")
        }
        if (label.isEmpty()) problems.add("Rename app: type the new app name.")
        if (problems.isNotEmpty()) return blocked(*problems.toTypedArray())

        val c = calcFor(src, pkg, label)
        val rp = c.plan ?: return blocked("Rename app: ${c.error ?: "could not work out the changes."}")
        if (rp.edits.isEmpty()) {
            return ZipPlan(
                emptyMap(), emptySet(), emptyList(),
                "Rename app: the new names are the same as the old ones, nothing to change.",
                emptyList(), emptyList(),
            )
        }
        val replace = LinkedHashMap<String, ZipIo.Blob>()
        for ((name, bytes) in rp.edits) replace[name] = ZipIo.Blob(bytes)
        val sb = StringBuilder()
        sb.append("Rename app:\n")
        sb.append(" package: ${rp.oldPkg} -> $pkg\n")
        sb.append(" app name: ${rp.oldLabel} -> $label\n")
        sb.append(" will change ${rp.edits.size} file(s):\n")
        for (name in rp.edits.keys) sb.append("  ").append(src.shown(name)).append('\n')
        return ZipPlan(
            replace, emptySet(), emptyList(), sb.toString().trim(), emptyList(), emptyList(),
            check = { f, n -> RenameLogic.check(f, n, rp, pkg, label) },
            resultNote = "PACKAGE: ${rp.oldPkg} -> $pkg\nAPP NAME: ${rp.oldLabel} -> $label\n",
        )
    }
}

/** The boxes of "Rename app": the two names found now, and the two new names to type. */
@Composable
fun RenameSection(r: RenameAction, src: ZipSource) {
    val ready = r.forSource === src
    val ok = ready && r.error == null
    Column {
        GroupHeading("Rename app")
        RowGroup {
            KitRow(
                title = "Package name now",
                shape = cardShape(0, 2),
                summary = if (!ready) "Looking in the project..." else if (ok) r.oldPkg else "Not found",
            )
            KitRow(
                title = "App name now",
                shape = cardShape(1, 2),
                summary = if (!ready) "Looking in the project..." else if (ok) r.oldLabel else "Not found",
            )
        }
    }
    Column {
        GroupHeading("New names")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = r.newPkg,
                onValueChange = { r.newPkg = it },
                singleLine = true,
                enabled = ok,
                isError = r.newPkg.isNotBlank() && !r.pkgOk,
                label = { Text("New package name (like a.a3)") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = r.newLabel,
                onValueChange = { r.newLabel = it },
                singleLine = true,
                enabled = ok,
                label = { Text("New app name (like A3)") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
