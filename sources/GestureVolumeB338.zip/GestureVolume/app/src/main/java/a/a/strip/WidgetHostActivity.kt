package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.Bitmap
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.cardShape
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.ChipsRow
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.StepRow
import a.a.ui.screens.strip.ToggleRow
import a.a.ui.components.MsBox
import a.a.ui.components.MsFields
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.BuiltInPage
import a.a.ui.screens.strip.MyScriptsPage
import a.a.utils.HandlerActions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import a.a.ui.screens.strip.ChipsCardRow
import a.a.ui.screens.strip.SwitchRow

/**
 * The Widgets window. Widgets of other apps (Eitaa's chats, Hotspot Shield's VPN switch...) are
 * added here once; each one then becomes cells that:
 *
 * - float it over whatever app is in front ([WidgetFloat]): one widget, draggable and resizable,
 *   remembering where you left it, with settings for size, opacity, auto-close and more,
 * - or press one tile of it (a chat, the VPN switch), hidden or shown for a few seconds. The tile
 *   is chosen with "Grab a tile": the widget floats, you tap the tile, and A notes which one it
 *   is. Android hides the intent behind a tile, so the cell presses that tile in the widget.
 *
 * It works whether or not A is the default launcher.
 */
class WidgetHostActivity : ComponentActivity() {
    private class GrabResult(val wid: Int, val name: String, val pos: Int, val pkg: String, val details: String)

    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val prefs by lazy { WidgetKit.prefs(this) }
    private val ids = mutableStateListOf<Int>()
    private val frames = HashMap<Int, AppWidgetHostView>()
    private var picking by mutableStateOf(false)
    private var grabResult by mutableStateOf<GrabResult?>(null)
    private var settingsFor by mutableStateOf(-1)
    private var ocrTick by mutableStateOf(0)
    private var inspectText by mutableStateOf<String?>(null)
    private var cfgTick by mutableStateOf(0)
    private var pendingId = -1

    // Saved tiles (see WidgetTiles): the list under each widget, and the one being edited in the Grab it window.
    private var tiles by mutableStateOf<List<TileRec>>(emptyList())
    private var linkedTiles by mutableStateOf<Set<String>>(emptySet())
    private var editTile by mutableStateOf<TileRec?>(null)
    private var removeTile by mutableStateOf<TileRec?>(null)

    private fun refreshTiles() {
        val (t, l) = WidgetTiles.reconcile(this)
        tiles = t; linkedTiles = l
    }

    /** What the cell being saved will do: kept here so it survives the shortcut picker taking the screen. */
    private class Draft {
        var label by mutableStateOf("")
        var mode by mutableStateOf(1)        // 0 hidden, 1 show for [showMs], 2 never close
        var showMs by mutableStateOf(3000)
        var cover by mutableStateOf(true)       // Quick Settings tiles: hide the shade under a picture of the screen
        var findMs by mutableStateOf(8000)      // how long to look for the tile before saying it was not found
        var warm by mutableStateOf("")
        var warmLabel by mutableStateOf("")
        var warmMs by mutableStateOf(3000)
        var postMs by mutableStateOf(2000)
        val pre = mutableStateListOf<WStep>()
        val post = mutableStateListOf<WStep>()
        var again by mutableStateOf(false)       // press the tile a second time after the first shortcuts
        var againMs by mutableStateOf(3000)
        var post2Ms by mutableStateOf(2000)
        val post2 = mutableStateListOf<WStep>()
        var ocr by mutableStateOf(false)
        var ocrMs by mutableStateOf(40000)
        var ocrType by mutableStateOf(true)
        var ocrClose by mutableStateOf(true)
    }

    private val draft = Draft()
    private var stepPick by mutableStateOf(0)   // 1 = before the widget, 2 = after it, 3 = the app to open first, 4 = after the second run
    private var floatCell by mutableStateOf<Triple<Int, String, String>?>(null)
    private var toolCell by mutableStateOf<String?>(null)   // "notes" or "gallery"

    private fun resetDraft(label: String) {
        draft.label = label; draft.mode = 1; draft.showMs = 3000; draft.findMs = 8000; draft.cover = true
        draft.warm = ""; draft.warmLabel = ""; draft.warmMs = 3000; draft.postMs = 2000
        draft.pre.clear(); draft.post.clear()
        draft.again = false; draft.againMs = 3000; draft.post2Ms = 2000; draft.post2.clear()
        draft.ocr = false; draft.ocrMs = 40000; draft.ocrType = true; draft.ocrClose = true
    }

    private fun showValue(): Int = when (draft.mode) { 0 -> 0; 1 -> draft.showMs.coerceAtLeast(1); else -> -1 }

    private fun withSteps(i: Intent): Intent {
        i.putExtra("findMs", draft.findMs.coerceAtLeast(300)).putExtra("cover", draft.cover)
        if (draft.warm.isNotEmpty()) i.putExtra("warm", draft.warm).putExtra("warmMs", draft.warmMs)
        if (draft.pre.isNotEmpty()) i.putExtra("pre", WSteps.toJson(draft.pre.toList()))
        if (draft.post.isNotEmpty()) i.putExtra("post", WSteps.toJson(draft.post.toList())).putExtra("postMs", draft.postMs)
        if (draft.again) i.putExtra("again", true).putExtra("againMs", draft.againMs)
        if (draft.again && draft.post2.isNotEmpty()) i.putExtra("post2", WSteps.toJson(draft.post2.toList())).putExtra("post2Ms", draft.post2Ms)
        if (draft.ocr) i.putExtra("ocr", true).putExtra("ocrMs", draft.ocrMs).putExtra("ocrType", draft.ocrType).putExtra("ocrClose", draft.ocrClose)
        return i
    }

    private fun pressIntent(g: GrabResult, show: Int /* milliseconds */): Intent =
        Intent(this, WidgetFloatActivity::class.java)
            .putExtra("mode", if (g.pkg == QsTiles.PKG) "qs" else "press").putExtra("wid", g.wid).putExtra("pkg", g.pkg)
            .putExtra("tap", g.name).putExtra("pos", g.pos).putExtra("showMs", show)

    private fun floatIntent(id: Int, pkg: String): Intent =
        Intent(this, WidgetFloatActivity::class.java).putExtra("mode", "show").putExtra("wid", id).putExtra("pkg", pkg)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingId = savedInstanceState?.getInt("pending", -1) ?: -1
        ids.addAll(WidgetKit.savedIds(this))
        save()
        setContent {
            AWindow {
                if (picking) Picker() else if (stepPick != 0) StepPicker() else Main()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pending", pendingId)
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    // Coming back from the cells window: tiles whose cell was edited there are updated here.
    override fun onResume() {
        super.onResume()
        refreshTiles()
    }

    // A tap on a shown widget may end on the home screen: bring this screen back (see ReturnGuard).
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val hit = frames.values.any { ReturnGuard.hit(it, ev) }
        val r = super.dispatchTouchEvent(ev)
        if (hit) ReturnGuard.after(this, WidgetHostActivity::class.java)
        return r
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun save() = WidgetKit.saveIds(this, ids.toList())

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    /** True (and the permission screen opens) when A may not draw over other apps yet. */
    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        toast("Allow \"Display over other apps\" for A, then try again")
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun appLabel(info: AppWidgetProviderInfo): String =
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(info.provider.packageName, 0)).toString() }
            .getOrDefault(info.provider.packageName)

    // ---- adding a widget: bind (Android asks once), set up (the widget's own screen), keep ----

    private fun begin(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, p.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun afterBind(id: Int) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) {
            val ok = runCatching { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }.isSuccess
            if (!ok) {
                toast("The widget's setup screen would not open; added without it")
                finishAdd(id)
            }
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        if (id !in ids) ids.add(id)
        pendingId = -1
        save()
    }

    private fun cancelAdd() {
        if (pendingId != -1) runCatching { host.deleteAppWidgetId(pendingId) }
        pendingId = -1
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBind(id) else cancelAdd()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishAdd(id) else cancelAdd()
        }
    }

    // ---- the cells ----

    private fun saveWindowCell() {
        val i = Intent(this, WidgetHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        CellTarget.save(this, "Widgets", "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME))
        toast("Saved to cells")
    }

    private fun saveFloatCell(id: Int, pkg: String) {
        val i = withSteps(floatIntent(id, pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        CellTarget.save(this, draft.label.ifBlank { "Widget" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:$pkg")
        toast("Saved to cells")
    }

    private fun saveToolCell(kind: String) {
        val i = withSteps(Intent(this, WidgetFloatActivity::class.java).putExtra("mode", kind)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        CellTarget.save(this, draft.label.ifBlank { if (kind == "notes") "Notes" else "Gallery" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:" + packageName)
        toast("Saved to cells")
    }

    /** The raw text of the cell for [g] and the current draft; [tid] links it to its saved tile. */
    private fun tileAction(g: GrabResult, tid: String): String =
        "Intent:" + withSteps(pressIntent(g, showValue()).putExtra("tid", tid)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .toUri(Intent.URI_INTENT_SCHEME)

    /** New tile: kept in this window and, with [asCell], put on the strip too. */
    private fun savePressCell(g: GrabResult, asCell: Boolean = true) {
        val tid = WidgetTiles.newId()
        val name = draft.label.ifBlank { "Tile" }
        WidgetTiles.add(this, TileRec(tid, name, g.wid, g.pkg, g.details, tileAction(g, tid)), asCell)
        refreshTiles()
        toast(if (asCell) "Saved to cells and to this window" else "Saved in this window")
    }

    /** An edited tile: it and every cell of it change together. */
    private fun updateTile(old: TileRec, g: GrabResult) {
        WidgetTiles.update(this, old.copy(name = draft.label.ifBlank { "Tile" }, action = tileAction(g, old.id)))
        refreshTiles()
        toast("Saved")
    }

    /** Fills the Grab it window's draft from a saved tile's raw text. */
    private fun loadDraft(rec: TileRec) {
        resetDraft(rec.name)
        val i = WidgetTiles.parse(rec.action) ?: return
        val show = i.getIntExtra("showMs", 3000)
        draft.mode = when { show == 0 -> 0; show < 0 -> 2; else -> 1 }
        if (show > 0) draft.showMs = show
        draft.findMs = i.getIntExtra("findMs", 8000); draft.cover = i.getBooleanExtra("cover", true)
        draft.warm = i.getStringExtra("warm") ?: ""
        if (draft.warm.isNotEmpty()) {
            draft.warmLabel = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(draft.warm, 0)).toString() }.getOrDefault(draft.warm)
            draft.warmMs = i.getIntExtra("warmMs", 3000)
        }
        draft.pre.addAll(WSteps.parse(i.getStringExtra("pre")))
        draft.post.addAll(WSteps.parse(i.getStringExtra("post"))); draft.postMs = i.getIntExtra("postMs", 2000)
        draft.again = i.getBooleanExtra("again", false); draft.againMs = i.getIntExtra("againMs", 3000)
        draft.post2.addAll(WSteps.parse(i.getStringExtra("post2"))); draft.post2Ms = i.getIntExtra("post2Ms", 2000)
        draft.ocr = i.getBooleanExtra("ocr", false); draft.ocrMs = i.getIntExtra("ocrMs", 40000)
        draft.ocrType = i.getBooleanExtra("ocrType", true); draft.ocrClose = i.getBooleanExtra("ocrClose", true)
    }

    private fun editSaved(rec: TileRec) {
        val i = WidgetTiles.parse(rec.action)
        loadDraft(rec)
        editTile = rec
        grabResult = GrabResult(rec.wid, i?.getStringExtra("tap").orEmpty(), i?.getIntExtra("pos", 0) ?: 0, rec.pkg, rec.details)
    }

    private fun testSaved(rec: TileRec) {
        val i = WidgetTiles.parse(rec.action) ?: return
        if (i.getStringExtra("mode") != "qs" && needOverlay()) return
        if (i.getIntExtra("showMs", 3000) == 0 && i.getStringExtra("mode") != "qs") i.putExtra("showMs", 3000)
        WidgetFloat.handle(this, "press", i)
    }

    private fun closeGrab() { grabResult = null; editTile = null }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("A widget", text))
        toast("Copied")
    }

    // ---- screens ----

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Main() {
        val ic = Icons.Filled
        val me = this@WidgetHostActivity
        AWindowPage("Widgets", onBack = { finish() }) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp),
            ) {
                item(key = "start") {
                    CardGroup("Add and show", "Add a widget, try it floating above any app, then put it on your cells") {
                        row { sh -> LinkRow("Add a widget", "Pick one from the widgets your apps offer", sh, ic.Add) { picking = true } }
                        row { sh ->
                            SettingRow(
                                "Put this window on a cell", sh, icon = ic.Widgets,
                                summary = "A cell that opens this Widgets window", onClick = { saveWindowCell() },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                "Close all floating widgets", sh, icon = ic.Close,
                                summary = "Closes every widget that is floating now", onClick = { WidgetFloat.closeAll() },
                            )
                        }
                    }
                }
                item(key = "tools") {
                    CardGroup("Floating tools", "Small windows that float above any app") {
                        row { sh ->
                            SettingRow(
                                "Floating notes", sh, icon = ic.StickyNote2,
                                summary = "Type in a floating window. Tap to open or close it",
                                onClick = { FloatTools.toggle(me, "notes") },
                                trailing = { TextButton(onClick = { resetDraft("Notes"); toolCell = "notes" }) { Text("As a cell") } },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                "Floating gallery", sh, icon = ic.PhotoLibrary,
                                summary = "Look at your pictures in a floating window. Tap to open or close it",
                                onClick = { FloatTools.toggle(me, "gallery") },
                                trailing = { TextButton(onClick = { resetDraft("Gallery"); toolCell = "gallery" }) { Text("As a cell") } },
                            )
                        }
                        row { sh ->
                            LinkRow("Read text from the screen", "OCR: teach A the digits once, then read a code", sh, ic.TextFields) {
                                startActivity(Intent(me, OcrActivity::class.java))
                            }
                        }
                    }
                }
                item(key = "qs") { QsCard() }
                items(ids.toList(), key = { it }) { id -> WidgetCard(id) }
            }
        }
        grabResult?.let { GrabDialog(it) }
        removeTile?.let { t ->
            WidgetWindow("Remove \"" + t.name + "\"?", { removeTile = null }) {
                CardGroup("What happens") {
                    row { sh ->
                        SettingRow(title = "It leaves this list", sh, icon = Icons.Filled.Info,
                            summary = "The cell in your cells window stays and keeps working.",
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { WidgetTiles.remove(this@WidgetHostActivity, t.id); refreshTiles(); removeTile = null },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Remove") }
            }
        }
        floatCell?.let { FloatCellDialog(it) }
        toolCell?.let { ToolCellDialog(it) }
        if (settingsFor != -1) SettingsDialog(settingsFor)
        inspectText?.let { InspectDialog(it) }
    }

    /** One saved tile or button: its name, whether it is a cell yet, and what can be done with it. */
    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun SavedTileRow(t: TileRec, shape: Shape) {
        val linked = t.id in linkedTiles
        SettingRow(
            t.name.ifBlank { "Tile" }, shape, icon = Icons.Filled.TouchApp, lit = linked, compact = true,
            summary = if (linked) "Saved as a cell" else "Not a cell yet",
            footer = {
                FlowRow(
                    Modifier.padding(start = 12.dp, end = 12.dp, bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    TextButton(onClick = { editSaved(t) }) { Text("Edit") }
                    TextButton(onClick = { testSaved(t) }) { Text("Test") }
                    if (!linked) TextButton(onClick = {
                        CellTarget.save(this@WidgetHostActivity, t.name.ifBlank { "Tile" }, t.action, "app:" + t.pkg)
                        refreshTiles(); toast("Added as a cell")
                    }) { Text("Add as a cell") }
                    TextButton(onClick = { removeTile = t }) { Text("Remove") }
                }
            },
        )
    }

    /** Quick Settings tiles (Wi-Fi, Bluetooth...): grabbed in the shade and pressed from a cell, without Shizuku. */
    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun QsCard() {
        val ic = Icons.Filled
        val me = this@WidgetHostActivity
        val mine = tiles.filter { it.pkg == QsTiles.PKG }
        CardGroup(
            "Quick Settings tiles",
            "Wi-Fi, Bluetooth and the other tiles of the shade, pressed from a cell. Needs A's accessibility service, not Shizuku.",
        ) {
            row { sh ->
                SettingRow(
                    "Grab a tile", sh, icon = ic.TouchApp,
                    summary = "Tap it, tap the tile in the shade (it switches once), then save the cell",
                    onClick = {
                        QsTiles.grab(me) { name, pos, details ->
                            resetDraft(name.ifBlank { "Tile" })
                            draft.mode = 0
                            grabResult = GrabResult(-1, name, pos, QsTiles.PKG, details)
                        }
                    },
                )
            }
            mine.forEach { t -> row { sh -> SavedTileRow(t, sh) } }
        }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun WidgetCard(id: Int) {
        val info = remember(id) { mgr.getAppWidgetInfo(id) }
        if (info == null) return
        val cfg = remember(id, cfgTick) { WidgetKit.loadCfg(this@WidgetHostActivity, id) }
        val title = cfg.name.ifBlank { appLabel(info) }
        val density = LocalDensity.current
        val startH = with(density) { info.minHeight.toDp().value.toInt() }.coerceAtLeast(110)
        var h by remember(id) { mutableStateOf(prefs.getInt("h$id", startH)) }
        val ic = Icons.Filled
        val me = this@WidgetHostActivity
        val mine = tiles.filter { it.wid == id || (it.wid !in ids && it.pkg == info.provider.packageName) }
        Column(Modifier.fillMaxWidth()) {
            CardGroup(title) {
                row { sh ->
                    SettingRow(
                        "Show floating", sh, icon = ic.PlayArrow,
                        summary = "Float it above any app: drag it by its top bar, resize it from the corner",
                        onClick = { if (!needOverlay()) WidgetFloat.show(me, id) },
                    )
                }
                row { sh -> LinkRow("Floating settings", "Size, look, closing and where it appears", sh, ic.Tune) { settingsFor = id } }
                row { sh ->
                    SettingRow(
                        "Put on a cell", sh, icon = ic.Add,
                        summary = "A cell that shows this widget",
                        onClick = { resetDraft(title); floatCell = Triple(id, title, info.provider.packageName) },
                    )
                }
                row { sh ->
                    SettingRow(
                        "Grab a button", sh, icon = ic.TouchApp,
                        summary = "Tap a button or a chat inside the widget, then press it from a cell",
                        onClick = {
                            if (!needOverlay()) {
                                WidgetFloat.grab(me, id) { name, pos, details ->
                                    resetDraft(name.ifBlank { "Tile" })
                                    grabResult = GrabResult(id, name, pos, info.provider.packageName, details)
                                }
                            }
                        },
                    )
                }
                row { sh ->
                    SettingRow(
                        "See what it is made of", sh, icon = ic.Search,
                        summary = "Lists the widget's parts; [TAP] marks the ones that can be pressed",
                        onClick = { inspectText = frames[id]?.let { WidgetKit.dump(it) } ?: "The widget has not loaded yet." },
                    )
                }
                mine.forEach { t -> row { sh -> SavedTileRow(t, sh) } }
                row { sh ->
                    SettingRow(
                        "Remove this widget", sh, icon = ic.Delete,
                        summary = "Takes it off this list",
                        onClick = {
                            WidgetFloat.close(id)
                            runCatching { host.deleteAppWidgetId(id) }
                            frames.remove(id)
                            ids.remove(id)
                            WidgetKit.forget(me, id)
                            save()
                        },
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            BoxWithConstraints(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))) {
                val w = maxWidth.value.toInt()
                AndroidView(
                    factory = { ctx -> host.createView(ctx, id, info).also { frames[id] = it } },
                    update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                    modifier = Modifier.fillMaxWidth().height(h.dp),
                )
            }
            Spacer(Modifier.height(3.dp))
            StepRow(
                "Preview height", "$h dp", RoundedCornerShape(20.dp),
                { h = (h - 60).coerceAtLeast(60); prefs.edit().putInt("h$id", h).apply() },
                { h += 60; prefs.edit().putInt("h$id", h).apply() },
                compact = true,
            )
        }
    }

    // ---- small building blocks for the windows ----

    /** A full-screen window with the back arrow (back = close), the way the other Cell Settings windows are drawn. */
    @Composable
    private fun WidgetWindow(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
        Dialog(onDismissRequest = onBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                AWindowPage(title, onBack = onBack) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        content = content,
                    )
                }
            }
        }
    }

    /** A number on a bar, in its own row of the card; the value comes from the caller, so other rows can move it. */
    @Composable
    private fun SlideRow(title: String, value: Int, from: Int, to: Int, unit: String, shape: Shape, onChange: (Int) -> Unit) {
        SettingRow(
            title, shape,
            trailing = {
                Text("$value$unit", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            },
            footer = {
                Slider(
                    value = value.toFloat(), onValueChange = { onChange(it.toInt()) },
                    valueRange = from.toFloat()..to.toFloat(),
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 4.dp),
                )
            },
        )
    }

    /** A time (the bar and the seconds and milliseconds boxes, see MsBox) in its own row of the card. */
    @Composable
    private fun TimeRow(title: String, ms: Int, maxMs: Int, barMax: Int, shape: Shape, onChange: (Int) -> Unit) {
        Column(Modifier.fillMaxWidth().clip(shape).background(rowColor()).padding(horizontal = 14.dp, vertical = 10.dp)) {
            MsBox(title, ms, maxMs, barMax, onChange)
        }
    }

    /** The cell's name, in a card of its own. */
    @Composable
    private fun CellNameCard(hint: String? = null) {
        CardGroup("The cell", hint = hint) {
            row { sh ->
                SettingRow(title = "Cell name", sh, icon = Icons.Filled.Edit,
                    footer = {
                        OutlinedTextField(
                            value = draft.label, onValueChange = { draft.label = it }, singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                        )
                    },
                )
            }
        }
    }

    // ---- floating settings of one widget ----

    @Composable
    private fun SettingsDialog(id: Int) {
        var c by remember(id) { mutableStateOf(WidgetKit.loadCfg(this@WidgetHostActivity, id)) }
        var resetPos by remember(id) { mutableStateOf(false) }
        fun commit() {
            val cur = WidgetKit.loadCfg(this@WidgetHostActivity, id)
            // A saved position is measured from the top of the screen or from under the status bar, so it is
            // forgotten when that changes (otherwise the widget would jump by the height of the status bar).
            val forget = resetPos || c.overStatus != cur.overStatus
            WidgetKit.saveCfg(
                this@WidgetHostActivity, id,
                c.copy(x = if (forget) Int.MIN_VALUE else cur.x, y = if (forget) Int.MIN_VALUE else cur.y),
            )
            cfgTick++
        }
        val ic = Icons.Filled
        val sizeSel = when {
            c.wDp == 0 -> 0
            c.wDp <= 170 -> 1
            c.wDp <= 280 -> 2
            else -> 3
        }
        WidgetWindow(title = "Floating settings", { settingsFor = -1 }) {
            CardGroup("Name") {
                row { sh ->
                    SettingRow(title = "Name", sh, icon = ic.Edit, summary = "Shown on its bar and on the cell",
                        footer = {
                            OutlinedTextField(
                                value = c.name, onValueChange = { c = c.copy(name = it) }, singleLine = true,
                                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                            )
                        },
                    )
                }
            }
            CardGroup("Size") {
                row { sh ->
                    ChipsCardRow(title = "Size", listOf("Auto", "Small", "Medium", "Large").mapIndexed { i, l -> l to (i == sizeSel) }, sh,
                        onToggle = {
                            c = when (it) {
                                0 -> c.copy(wDp = 0, hDp = 0)
                                1 -> c.copy(wDp = 150, hDp = 100)
                                2 -> c.copy(wDp = 260, hDp = 180)
                                else -> c.copy(wDp = 340, hDp = 300)
                            }
                        },
                        icon = ic.Widgets, summary = "You can also drag its corner while it floats",
                    )
                }
                if (c.wDp > 0) {
                    row { sh -> SlideRow("Width", c.wDp, 96, 420, " dp", sh) { c = c.copy(wDp = it) } }
                    row { sh -> SlideRow("Height", c.hDp.coerceAtLeast(64), 64, 700, " dp", sh) { c = c.copy(hDp = it) } }
                }
            }
            CardGroup("How it looks") {
                row { sh -> SlideRow("Opacity", c.opacity, 20, 100, "%", sh) { c = c.copy(opacity = it) } }
                row { sh -> SlideRow("Rounded corners", c.radius, 0, 32, " dp", sh) { c = c.copy(radius = it) } }
                row { sh ->
                    ChipsCardRow(title = "Background behind the widget", listOf("None", "Dark", "Light").mapIndexed { i, l -> l to (i == c.bg) }, sh,
                        onToggle = { c = c.copy(bg = it) },
                    )
                }
            }
            CardGroup("The bar") {
                row { sh ->
                    SwitchRow(title = "Show the bar", c.handle, sh, icon = ic.Tune, summary = "Drag, minimize, close, resize") { c = c.copy(handle = it) }
                }
                if (c.handle) row { sh ->
                    SwitchRow(title = "Put the bar under the widget", c.barBottom, sh, summary = "Instead of above it") { c = c.copy(barBottom = it) }
                }
            }
            CardGroup("Where it floats") {
                row { sh ->
                    ChipsCardRow(title = "First position", listOf("Centre", "Top", "Bottom", "Left", "Right").mapIndexed { i, l -> l to (i == c.startAt) }, sh,
                        onToggle = { c = c.copy(startAt = it) },
                    )
                }
                row { sh -> SwitchRow(title = "Let it cover the status bar", c.overStatus, sh) { c = c.copy(overStatus = it) } }
                row { sh -> SwitchRow(title = "Lock position and size", c.lock, sh, icon = ic.Lock) { c = c.copy(lock = it) } }
                row { sh -> SwitchRow(title = "Remember where I leave it", c.remember, sh) { c = c.copy(remember = it) } }
                row { sh -> SwitchRow(title = "Snap to the screen edges", c.snap, sh) { c = c.copy(snap = it) } }
            }
            CardGroup("Closing") {
                row { sh -> SwitchRow(title = "Close when I tap outside it", c.outside, sh, icon = ic.Close) { c = c.copy(outside = it) } }
            }
            SecCard("Close after no touch for", c.autoClose, "Never close (stay until I close it)", 120000) { c = c.copy(autoClose = it) }
            SecCard("Close after I tap something in it", c.afterTap, "Off", 60000) { c = c.copy(afterTap = it) }
            CardGroup("Reading the code") { row { sh -> OcrTeach(sh) } }
            CardGroup("Try it") {
                row { sh ->
                    SettingRow(
                        if (resetPos) "Position will reset" else "Reset position", sh, icon = ic.Tune,
                        summary = "Forget where it was left; it starts at its first position",
                        onClick = { resetPos = true },
                    )
                }
                row { sh ->
                    SettingRow(title = "Try it now", sh, icon = ic.PlayArrow, summary = "Saves the settings and floats the widget",
                        onClick = {
                            if (!needOverlay()) {
                                commit()
                                WidgetFloat.reopen(this@WidgetHostActivity, id)
                            }
                        },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { commit(); settingsFor = -1 }, modifier = Modifier.fillMaxWidth()) { Text("Save") }
        }
    }

    // ---- save a grabbed tile ----

    @Composable
    private fun GrabDialog(g: GrabResult) {
        val what = if (g.pkg == QsTiles.PKG) "tile" else "button"
        val qs = g.pkg == QsTiles.PKG
        val ic = Icons.Filled
        val modeNames = listOf(
            if (qs) "Close the shade at once" else "Keep it hidden",
            if (qs) "Keep the shade open for some seconds" else "Show for some seconds",
            if (qs) "Leave the shade open" else "Never close it",
        )
        WidgetWindow(title = if (editTile != null) "Edit this saved $what" else "Save this $what as a cell", { closeGrab() }) {
            CardGroup("What was grabbed") {
                row { sh ->
                    SettingRow(title = "Details", sh, icon = ic.TouchApp,
                        trailing = { TextButton(onClick = { copy(g.details) }) { Text("Copy") } },
                        footer = {
                            Text(
                                g.details, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                            )
                        },
                    )
                }
            }
            CellNameCard()
            CardGroup(if (qs) "After pressing it (the shade)" else "After pressing it") {
                row { sh ->
                    ChipsCardRow(title = "What happens", modeNames.mapIndexed { i, l -> l to (i == draft.mode) }, sh,
                        onToggle = { draft.mode = it },
                    )
                }
                if (qs) row { sh ->
                    SwitchRow(title = "Hide the shade under a picture of the screen (Android 11+)", draft.cover, sh) { draft.cover = it }
                }
                if (draft.mode == 1) row { sh -> TimeRow("Show for", draft.showMs, 3600000, 60000, sh) { draft.showMs = it } }
                row { sh ->
                    TimeRow("Give up looking for the " + (if (qs) "tile" else "button") + " after", draft.findMs, 600000, 60000, sh) { draft.findMs = it }
                }
            }
            if (!qs) OcrBlock()
            StepsBlock()
            CardGroup("Try it", hint = if (editTile != null) "Saving changes this $what and every cell made from it." else null) {
                row { sh ->
                    SettingRow(title = "Test", sh, icon = ic.PlayArrow, summary = "Presses it once, right now",
                        onClick = {
                            if (qs || !needOverlay()) {
                                val show = if (draft.mode == 0 && !qs) 3000 else showValue()
                                WidgetFloat.handle(this@WidgetHostActivity, "press", withSteps(pressIntent(g, show)))
                            }
                        },
                    )
                }
                if (editTile == null) row { sh ->
                    SettingRow(title = "Save here only", sh, icon = ic.Widgets, summary = "Keeps it in this window without making a cell",
                        onClick = { savePressCell(g, asCell = false); closeGrab() },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val e = editTile
                    if (e != null) updateTile(e, g) else savePressCell(g)
                    closeGrab()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (editTile != null) "Save" else "Save as a cell") }
        }
    }

    @Composable
    private fun ToolCellDialog(kind: String) {
        val ic = Icons.Filled
        WidgetWindow(title = if (kind == "notes") "Save floating notes as a cell" else "Save floating gallery as a cell", { toolCell = null }) {
            CellNameCard("The cell opens it, and closes it when it is already open.")
            StepsBlock()
            CardGroup("Try it") {
                row { sh ->
                    SettingRow(title = "Test", sh, icon = ic.PlayArrow, summary = "Opens it once, right now",
                        onClick = {
                            WidgetFloat.handle(this@WidgetHostActivity, kind, withSteps(Intent(this@WidgetHostActivity, WidgetFloatActivity::class.java).putExtra("mode", kind)))
                        },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { saveToolCell(kind); toolCell = null }, modifier = Modifier.fillMaxWidth()) { Text("Save as a cell") }
        }
    }

    @Composable
    private fun FloatCellDialog(t: Triple<Int, String, String>) {
        val ic = Icons.Filled
        WidgetWindow(title = "Save this widget as a cell", { floatCell = null }) {
            CellNameCard()
            StepsBlock()
            CardGroup("Try it") {
                row { sh ->
                    SettingRow(title = "Test", sh, icon = ic.PlayArrow, summary = "Floats the widget once, right now",
                        onClick = {
                            if (!needOverlay()) WidgetFloat.handle(this@WidgetHostActivity, "show", withSteps(floatIntent(t.first, t.third)))
                        },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { saveFloatCell(t.first, t.third); floatCell = null }, modifier = Modifier.fillMaxWidth()) { Text("Save as a cell") }
        }
    }

    // ---- reading a code from the widget ----

    @Composable
    private fun OcrBlock() {
        CardGroup(
            "Reading the code",
            hint = if (draft.ocr) "The code is always copied too. Teach A the digits once in the OCR screen (Widgets window, \"Read text from the screen\")." else null,
        ) {
            row { sh -> SwitchRow(title = "Read the code with OCR and type it for me", draft.ocr, sh, icon = Icons.Filled.TextFields) { draft.ocr = it } }
            if (draft.ocr) {
                row { sh -> TimeRow("Look for the code for up to", draft.ocrMs, 3600000, 120000, sh) { draft.ocrMs = it } }
                row { sh -> SwitchRow(title = "Type it into the field that has the cursor (needs Shizuku)", draft.ocrType, sh) { draft.ocrType = it } }
                row { sh -> SwitchRow(title = "Close the widget once it is read", draft.ocrClose, sh) { draft.ocrClose = it } }
            }
        }
    }

    @Composable
    private fun OcrTeach(shape: Shape) {
        val known = remember(ocrTick) { OtpOcr.learnedCount(this@WidgetHostActivity) }
        LinkRow(title = "Reading the code (OCR)", "Digits taught: $known of 10. English digits need no teaching. What you teach is shared by every widget and shortcut.",
            shape, Icons.Filled.TextFields,
        ) { startActivity(Intent(this@WidgetHostActivity, OcrActivity::class.java)) }
    }

    // ---- times: a bar in milliseconds and a seconds box + a milliseconds box (MsBox) ----

    /** A time with a switch for "no time" ([zeroLabel], saved as 0) and, when off, the bar and the two boxes. [max] is the end of the bar, in milliseconds. */
    @Composable
    private fun SecCard(title: String, value: Int, zeroLabel: String, max: Int, onChange: (Int) -> Unit) {
        var last by remember { mutableStateOf(if (value > 0) value else 5000) }
        CardGroup(title) {
            row { sh ->
                SwitchRow(zeroLabel, value == 0, sh) { on ->
                    if (on) { if (value > 0) last = value; onChange(0) } else onChange(last)
                }
            }
            if (value > 0) row { sh ->
                TimeRow("Closes after", value, 3600000, max, sh) { last = it.coerceAtLeast(1); onChange(it.coerceAtLeast(1)) }
            }
        }
    }

    // ---- shortcuts before and after the widget ----

    /**
     * One list of shortcuts in its own card. [waitTitle] (with [waitMs] and [onWait]) adds, above the list, the time
     * that is waited before this list starts; it shows only once the list has a shortcut.
     */
    @Composable
    private fun StepList(
        title: String, list: MutableList<WStep>, which: Int, hint: String? = null,
        waitTitle: String? = null, waitMs: Int = 0, onWait: (Int) -> Unit = {},
    ) {
        CardGroup(title, hint = hint) {
            if (waitTitle != null && list.isNotEmpty()) row { sh -> TimeRow(waitTitle, waitMs, 3600000, 60000, sh, onWait) }
            list.forEachIndexed { n, s ->
                row { sh ->
                    SettingRow(
                        s.label.ifBlank { s.action.take(24) }, sh, icon = Icons.Filled.PlayArrow,
                        summary = "Then wait",
                        trailing = { TextButton(onClick = { list.removeAt(n) }) { Text("Remove") } },
                        footer = {
                            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                                MsFields(s.waitMs, 3600000, { v -> list[n] = s.copy(waitMs = v) })
                            }
                        },
                    )
                }
            }
            row { sh -> SettingRow(title = "Add a shortcut", sh, icon = Icons.Filled.Add, onClick = { stepPick = which }) }
        }
    }

    @Composable
    private fun StepsBlock() {
        // "Open an app first" is now a Scripts block (Open an app, go back after a time). Only a cell that
        // already uses it still shows it, so old cells keep working and can be cleared.
        if (draft.warm.isNotEmpty()) {
            CardGroup(
                "Open an app first",
                hint = "It opens without an animation, then you are taken back to where you were. With Shizuku it is quicker.",
            ) {
                row { sh ->
                    SettingRow(title = "App to open", sh, icon = Icons.Filled.PlayArrow, summary = draft.warmLabel.ifBlank { "none" },
                        trailing = { TextButton(onClick = { draft.warm = ""; draft.warmLabel = "" }) { Text("Clear") } },
                    )
                }
                row { sh -> TimeRow("Wait after opening it", draft.warmMs, 3600000, 30000, sh) { draft.warmMs = it } }
            }
        }
        StepList(
            "Shortcuts before the widget", draft.pre, 1,
            hint = if (draft.warm.isEmpty()) "To open an app first, add a script (My Scripts) with the Open an app block as a shortcut." else null,
        )
        StepList(
            "Shortcuts after the widget", draft.post, 2,
            waitTitle = "Start the after-shortcuts this long after the widget", waitMs = draft.postMs, onWait = { draft.postMs = it },
        )
        CardGroup("Run the widget again") {
            row { sh -> SwitchRow(title = "Run the widget again after the shortcuts above", draft.again, sh) { draft.again = it } }
            if (draft.again) row { sh -> TimeRow("Wait before running it again", draft.againMs, 3600000, 60000, sh) { draft.againMs = it } }
        }
        if (draft.again) StepList(
            "Shortcuts after the second run", draft.post2, 4,
            hint = "The wait is counted after the last shortcut above has started and its own wait is over.",
            waitTitle = "Start the next shortcuts this long after it", waitMs = draft.post2Ms, onWait = { draft.post2Ms = it },
        )
    }

    @Composable
    private fun StepPicker() {
        var page by remember { mutableStateOf(if (stepPick == 3) 2 else 0) }   // 0 menu, 1 built-in, 2 apps, 3 scripts
        BackHandler { if (page != 0 && stepPick != 3) page = 0 else stepPick = 0 }
        fun add(label: String, action: String) {
            if (action.isNotEmpty()) (when (stepPick) { 2 -> draft.post; 4 -> draft.post2; else -> draft.pre }).add(WStep(label, action, 1000))
            stepPick = 0
        }
        if (page == 0) {
            val ic = Icons.Filled
            AWindowPage("Add a shortcut", onBack = { stepPick = 0 }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                    CardGroup("Where is the shortcut?") {
                        row { sh -> LinkRow("Built-in shortcuts", "Device actions and the other shortcuts A has", sh, ic.Tune) { page = 1 } }
                        row { sh -> LinkRow("Open an app", "Pick an app to open", sh, ic.PlayArrow) { page = 2 } }
                        row { sh -> LinkRow("My Scripts", "A script you made or imported", sh, ic.Edit) { page = 3 } }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                when (page) {
                    1 -> BuiltInPage(
                        onPick = { entry, name -> add(name, entry.action) },
                        onBack = { page = 0 },
                        onPickAction = { a, n, _ -> add(n, a) },
                        onPickApp = { app, _, act -> add(app.label, act) },
                    )
                    2 -> AppList(
                        onPick = { app ->
                            if (stepPick == 3) { draft.warm = app.packageName; draft.warmLabel = app.label; stepPick = 0 }
                            else add(app.label, HandlerActions.launchApp(app.packageName))
                        },
                        onBack = { if (stepPick == 3) stepPick = 0 else page = 0 },
                    )
                    else -> MyScriptsPage(onPick = { label, action, _ -> add(label, action) }, onBack = { page = 0 })
                }
            }
        }
    }

    @Composable
    private fun InspectDialog(text: String) {
        WidgetWindow(title = "What the widget is made of", { inspectText = null }) {
            CardGroup("The parts of the widget", hint = "[TAP] marks the tiles that can be pressed.") {
                row { sh ->
                    SettingRow(title = "Structure", sh, icon = Icons.Filled.Search,
                        footer = {
                            Text(
                                text, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                            )
                        },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = { copy(text) }, modifier = Modifier.fillMaxWidth()) { Text("Copy") }
        }
    }

    // ---- picking a widget to add ----

    @Composable
    private fun Picker() {
        BackHandler { picking = false }
        var q by remember { mutableStateOf("") }
        val ic = Icons.Filled
        val all = remember {
            val pm = packageManager
            mgr.installedProviders.map { p ->
                val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() }.getOrDefault(p.provider.packageName)
                val name = runCatching { p.loadLabel(pm).toString() }.getOrDefault("")
                Triple(p, app, name)
            }.sortedBy { it.second.lowercase() }
        }
        val shown = all.filter { q.isBlank() || it.second.contains(q, true) || it.third.contains(q, true) || it.first.provider.packageName.contains(q, true) }
        AWindowPage("Pick a widget", onBack = { picking = false }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                OutlinedTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    label = { Text("Search (for example eitaa)") },
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                if (shown.isEmpty()) Text("No widgets found.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyColumn(
                    Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp),
                    contentPadding = PaddingValues(bottom = 24.dp),
                ) {
                    itemsIndexed(shown) { n, row ->
                        SettingRow(
                            row.third.ifBlank { row.second }, cardShape(n, shown.size), icon = ic.Widgets,
                            summary = row.second, onClick = { picking = false; begin(row.first) },
                        )
                    }
                }
            }
        }
    }

    private companion object {
        const val REQ_BIND = 7101
        const val REQ_CONFIG = 7102
    }
}

