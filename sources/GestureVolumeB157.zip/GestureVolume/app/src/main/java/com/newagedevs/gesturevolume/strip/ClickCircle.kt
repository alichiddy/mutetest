package com.newagedevs.gesturevolume.strip

import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.newagedevs.gesturevolume.service.OverlayRuntime
import com.newagedevs.gesturevolume.utils.ShizukuShell
import kotlin.math.abs

/**
 * The click circle ("sniper"): a small circle in the middle of the screen. Touch anywhere and move:
 * the circle moves by your movement times a speed factor, so the thumb never has to reach the spot.
 * Lift the thumb and the circle's spot is tapped. Keep the thumb still before lifting: after the
 * first time it is a long press, after the second a double tap. The X at the top closes it.
 *
 * Nothing exists until the action runs, and everything is gone when it has tapped (or after 10 s idle).
 */
class ClickCircle(
    private val context: Context,
    private val windowManager: WindowManager,
    private val windowType: Int,
    private val sp: android.content.SharedPreferences,
) {
    private val uiHandler = Handler(Looper.getMainLooper())
    private var view: CircleView? = null

    val isShowing: Boolean get() = view != null

    /** The real size of the display (the window covers all of it). */
    private fun screenSize(): Pair<Float, Float> {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val b = runCatching { windowManager.currentWindowMetrics.bounds }.getOrNull()
            if (b != null && b.width() > 0) return b.width().toFloat() to b.height().toFloat()
        }
        val dm = context.resources.displayMetrics
        return dm.widthPixels.toFloat() to dm.heightPixels.toFloat()
    }

    /**
     * Where the circle starts: per axis the middle of the screen, relative to where the thumb is (plus an
     * offset in dp, negative = left/above), or a percentage of the screen. Without a known thumb the middle.
     */
    private fun startPoint(sw: Float, sh: Float, tx: Float?, ty: Float?): Pair<Float, Float> {
        val d = context.resources.displayMetrics.density
        fun axis(size: Float, thumb: Float?, mode: Int, off: Int, pct: Int): Float = when (mode) {
            1 -> if (thumb != null) thumb + off * d else size / 2f
            2 -> size * pct.coerceIn(0, 100) / 100f
            else -> size / 2f
        }
        val x = axis(sw, tx, sp.getInt("clickCircleXMode", 0), sp.getInt("clickCircleXOffDp", 0), sp.getInt("clickCircleXPct", 50))
        val y = axis(sh, ty, sp.getInt("clickCircleYMode", 1), sp.getInt("clickCircleYOffDp", -150), sp.getInt("clickCircleYPct", 50))
        return x.coerceIn(0f, sw) to y.coerceIn(0f, sh)
    }

    /** [following] = the thumb that opened it is still down on another window: this one takes no touches and is moved by [follow]. */
    fun show(following: Boolean = false, startX: Float = -1f, startY: Float = -1f) {
        if (view != null) return
        val (sw, sh) = screenSize()
        val (px, py) = startPoint(sw, sh, if (startX >= 0f) startX else null, if (startY >= 0f) startY else null)
        val v = CircleView(context, sw, sh, px, py)
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (following) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, windowType,
            flags, PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (android.os.Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        if (runCatching { windowManager.addView(v, lp) }.isSuccess) {
            view = v
            if (following) v.begin(startX, startY) else armIdle()
        }
    }

    /** The still-down thumb moved (follow mode). */
    fun follow(x: Float, y: Float) { view?.move(x, y) }

    /** The still-down thumb lifted (follow mode): tap, long press or double tap, by how long it stayed still. */
    fun release() { view?.up() }

    fun dismiss() {
        uiHandler.removeCallbacks(idle)
        val v = view ?: return
        view = null
        runCatching { windowManager.removeView(v) }
    }

    private val idle = Runnable { dismiss() }

    private fun armIdle() {
        uiHandler.removeCallbacks(idle)
        uiHandler.postDelayed(idle, 10_000L)
    }

    /** 0 = tap, 1 = long press, 2 = double tap. */
    private fun fire(x: Float, y: Float, kind: Int) {
        if (sp.getBoolean("clickCircleKeep", false)) {
            sp.edit().putFloat("clickCircleX", x).putFloat("clickCircleY", y).apply()
        }
        dismiss()
        // Let the circle's window go first, so the tap reaches the app below.
        uiHandler.postDelayed({ send(x, y, kind) }, 120L)
    }

    private fun shell(x: Float, y: Float, kind: Int): Boolean {
        if (!ShizukuShell.isReady()) return false
        val xi = x.toInt(); val yi = y.toInt()
        val cmd = when (kind) {
            1 -> "input swipe $xi $yi $xi $yi 700"
            2 -> "input tap $xi $yi; sleep 0.12; input tap $xi $yi"
            else -> "input tap $xi $yi"
        }
        Thread { runCatching { ShizukuShell.run(cmd) { } } }.start()
        return true
    }

    private fun send(x: Float, y: Float, kind: Int) {
        val service = OverlayRuntime.accessibilityService
        if ((sp.getBoolean("clickCircleShizuku", false) || service == null) && shell(x, y, kind)) return
        service ?: return
        val b = GestureDescription.Builder()
        fun stroke(start: Long, dur: Long) {
            val p = Path().apply { moveTo(x, y); lineTo(x + 0.5f, y + 0.5f) }
            b.addStroke(GestureDescription.StrokeDescription(p, start, dur))
        }
        when (kind) {
            1 -> stroke(0L, 700L)
            2 -> { stroke(0L, 40L); stroke(130L, 40L) }
            else -> stroke(0L, 40L)
        }
        // If Android drops the gesture, Shizuku taps the same spot (when it is available).
        val cb = object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
            override fun onCancelled(g: GestureDescription?) { uiHandler.post { shell(x, y, kind) } }
        }
        val sent = runCatching { service.dispatchGesture(b.build(), cb, uiHandler) }.getOrDefault(false)
        if (!sent) shell(x, y, kind)
    }

    private inner class CircleView(ctx: Context, private val w: Float, private val h: Float, startX: Float, startY: Float) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private var cx = startX
        private var cy = startY
        private var lastX = 0f
        private var lastY = 0f
        private var anchorX = 0f
        private var anchorY = 0f
        private var stillSince = 0L
        private var touching = false
        private var stage = 0
        private val speed = sp.getInt("clickCircleSpeed", 150).coerceIn(50, 600) / 100f
        private val longMs = sp.getInt("clickCircleLongMs", 200).coerceIn(80, 2000)
        private val doubleMs = sp.getInt("clickCircleDoubleMs", 400).coerceIn(150, 4000)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val chip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC222222.toInt() }
        private val xPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
        private val chipX get() = w / 2f
        private val chipY = 72f * d
        private val chipR = 22f * d

        init {
            if (sp.getBoolean("clickCircleKeep", false) && sp.contains("clickCircleX")) {
                cx = sp.getFloat("clickCircleX", cx).coerceIn(0f, w)
                cy = sp.getFloat("clickCircleY", cy).coerceIn(0f, h)
            }
        }

        private val stageCheck = object : Runnable {
            override fun run() {
                if (!touching) return
                val still = System.currentTimeMillis() - stillSince
                val s = if (still >= doubleMs) 2 else if (still >= longMs) 1 else 0
                if (s != stage) {
                    stage = s
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    invalidate()
                }
                uiHandler.postDelayed(this, 40L)
            }
        }

        private val loc = IntArray(2)

        fun begin(x: Float, y: Float) {
            uiHandler.removeCallbacks(idle)
            touching = true
            lastX = x; lastY = y
            anchorX = x; anchorY = y
            stillSince = System.currentTimeMillis()
            stage = 0
            uiHandler.post(stageCheck)
            invalidate()
        }

        fun move(x: Float, y: Float) {
            if (!touching) return
            cx = (cx + (x - lastX) * speed).coerceIn(0f, w)
            cy = (cy + (y - lastY) * speed).coerceIn(0f, h)
            lastX = x; lastY = y
            if (abs(x - anchorX) > 4f * d || abs(y - anchorY) > 4f * d) {
                anchorX = x; anchorY = y
                stillSince = System.currentTimeMillis()
                if (stage != 0) { stage = 0 }
            }
            invalidate()
        }

        fun up() {
            if (!touching) return
            touching = false
            uiHandler.removeCallbacks(stageCheck)
            val still = System.currentTimeMillis() - stillSince
            val kind = if (still >= doubleMs) 2 else if (still >= longMs) 1 else 0
            fire(cx, cy, kind)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (abs(e.rawX - chipX) < chipR * 1.4f && abs(e.rawY - chipY) < chipR * 1.4f) {
                        dismiss()
                        return true
                    }
                    begin(e.rawX, e.rawY)
                }
                MotionEvent.ACTION_MOVE -> move(e.rawX, e.rawY)
                MotionEvent.ACTION_UP -> up()
                MotionEvent.ACTION_CANCEL -> {
                    touching = false
                    uiHandler.removeCallbacks(stageCheck)
                    armIdle()
                }
            }
            return true
        }

        override fun onDetachedFromWindow() {
            uiHandler.removeCallbacks(stageCheck)
            super.onDetachedFromWindow()
        }

        override fun onDraw(c: Canvas) {
            // cx/cy are screen coordinates; the window may start below the status bar or a cutout.
            getLocationOnScreen(loc)
            val ox = loc[0].toFloat(); val oy = loc[1].toFloat()
            val col = when (stage) { 2 -> 0xFF43A047.toInt(); 1 -> 0xFFFFA000.toInt(); else -> 0xFF1E88E5.toInt() }
            val r = (if (stage == 0) 16f else 20f) * d
            dot.color = col and 0x00FFFFFF or 0x66000000
            ring.color = col
            c.drawCircle(cx - ox, cy - oy, r, dot)
            c.drawCircle(cx - ox, cy - oy, r, ring)
            dot.color = Color.WHITE
            c.drawCircle(cx - ox, cy - oy, 2.5f * d, dot)
            val bx = chipX - ox; val by = chipY - oy
            c.drawCircle(bx, by, chipR, chip)
            val s = 7f * d
            c.drawLine(bx - s, by - s, bx + s, by + s, xPaint)
            c.drawLine(bx - s, by + s, bx + s, by - s, xPaint)
        }
    }
}
