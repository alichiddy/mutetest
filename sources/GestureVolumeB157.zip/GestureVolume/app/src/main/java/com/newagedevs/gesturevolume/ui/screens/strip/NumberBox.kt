package com.newagedevs.gesturevolume.ui.screens.strip

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A small box to type a whole number (any size from [min] up). [onValue] gets each valid number as it is typed;
 * an empty or half-typed box keeps the last good value.
 */
@Composable
internal fun NumberBox(label: String, value: Int, min: Int = 0, max: Int = 5000, onValue: (Int) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { t ->
                val clean = t.filterIndexed { i, c -> c.isDigit() || (c == '-' && i == 0 && min < 0) }.take(6)
                text = clean
                clean.toIntOrNull()?.let { onValue(it.coerceIn(min, max)) }
            },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = if (min < 0) KeyboardType.Text else KeyboardType.Number),
            modifier = Modifier.width(96.dp),
        )
    }
}
