package a.a.ui.screens.ziptool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage

/**
 * Zip/Patch Tools: one window, one tab, for everything done to zips and project folders. Pick a zip or a folder,
 * then choose what to do: replace or add files, rename the app, zip it as it is, delete files, compare with
 * another zip or folder and take what you choose, or take files out. Actions can be combined (except taking
 * files out).
 *
 * Every action saves a new zip (or folders) in Downloads, reads it back and checks it, and never changes what you
 * picked. Nothing runs or is held in memory until this window is open.
 */
class ZipToolActivity : ComponentActivity() {
    private val one by lazy { OneState(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modeFrom(intent)
        setContent {
            AWindow {
                AWindowPage("Zip/Patch Tools", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        OneTab(one)
                    }
                }
            }
        }
    }

    /** Shortcuts saved before the tools were merged still work: they open the first tab with that action ticked. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        modeFrom(intent)
    }

    private fun modeFrom(i: Intent?) {
        val key = i?.getStringExtra(EXTRA_MODE) ?: return
        val tick = when (key) {
            "one" -> i?.getStringExtra(EXTRA_TICK)
            "replace", "patch" -> "replace"
            "rename" -> "rename"
            "extract" -> "extract"
            "folder" -> "asis"
            "merge" -> "compare"
            else -> null
        }
        one.tickFromShortcut(tick)
    }

    override fun onDestroy() {
        if (isFinishing) {
            one.cleanup()
        }
        super.onDestroy()
    }

    companion object {
        /** "one" opens Zip/Patch Tools (with EXTRA_TICK ticked). The old keys replace, patch, rename, extract, folder and merge still work: they tick the matching action. */
        const val EXTRA_MODE = "zipToolMode"

        /** With EXTRA_MODE "one": the action to tick (replace, rename, asis, delete, compare or extract). */
        const val EXTRA_TICK = "zipToolTick"
    }
}
