package a.a.sides

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One segment: its own place, size and look on an edge, and what a touch on it does.
 * Empty text = nothing bound. Every segment is independent of the others on its side.
 */
data class Seg(
    /** A segment can be switched off without being deleted. */
    val on: Boolean = true,
    /** "actions", "volume" (a drag up and down sets the volume) or "brightness". */
    val mode: String = MODE_ACTIONS,
    val tap: String = "",
    val double: String = "",
    val long: String = "",
    val up: String = "",
    val down: String = "",
    val inward: String = "",
    val outward: String = "",
    /** Where it starts and how tall it is, in percent of the usable screen height. */
    val topPct: Int = 20,
    val heightPct: Int = 20,
    /** Top edge follows the main slider's top edge (live), moved by [shiftPct] of the screen. */
    val posMain: Boolean = false,
    val shiftPct: Int = 0,
    /** Height follows the main slider's height (live). */
    val heightMain: Boolean = false,
    /** Width in dp, or the main slider's width (live) when [copyWidth]. */
    val widthDp: Int = 16,
    val copyWidth: Boolean = false,
    /** Look: drawn by a real copy of the main slider (colour, fill, outline, corners, percentage, panel); gestures stay its own. */
    val copyLook: Boolean = true,
    /** Height and width both follow the main slider (live); off = [heightMain] and [copyWidth] decide one by one. */
    val sizeAll: Boolean = true,
    /** Slide-in distance, touch area and straight up/down all follow the main slider (live); off = the three switches below decide. */
    val feelAll: Boolean = true,
    /** Slide-in distance (dp): the main slider's, or its own ([inDp], 0 = automatic). */
    val inMain: Boolean = false,
    val inDp: Int = 0,
    /** Touch area: the main slider's rule, or its own ([touchDp] across at least, 0 = exactly as drawn). */
    val touchMain: Boolean = false,
    val touchDp: Int = 0,
    /** How far from straight up/down a stroke may be and still slide the level: the main slider's, or its own. */
    val vertMain: Boolean = true,
    val vertDeg: Int = 30,
    /** Place and height of another segment, live ("L1", "R2"…); "" = this segment's own. */
    val linkTo: String = "",
    /** All seven gestures follow another segment's gestures, live ("L1", "R2"…); "" = this segment's own. */
    val actFrom: String = "",
    /** "Action outside of cells window" of this segment, its own (never copied from the main slider): what a release above, left of, below or right of the window does. */
    val edgeOn: Boolean = false,
    val edgeTop: String = "",
    val edgeLeft: String = "",
    val edgeBottom: String = "",
    val edgeRight: String = "",
    /** Gap in dp between the screen's side and the cells window; -1 = the main slider's. */
    val gapDp: Int = -1,
    /** Outside actions: this segment follows the main slider's four (live) instead of its own. */
    val edgeFollow: Boolean = false,
    /** The cells window (and, when following the main slider, the outside actions) is the mirror image on a segment at the other side from the main bar. */
    val mirror: Boolean = true,
    /** More fields per outside side: JSON {"cTop":2,"Top1":"action",...}. Field 0 of a side is edgeTop/edgeLeft/edgeBottom/edgeRight. */
    val edgeMore: String = "",
    /** Never changes: names this segment's own cells window (its settings are kept under this id). */
    val id: String = newId(),
    /** This segment has its OWN cells window (empty to start with) instead of the main slider's. */
    val ownWindow: Boolean = false,
) {
    private fun moreJson(): JSONObject = runCatching { JSONObject(edgeMore.ifEmpty { "{}" }) }.getOrDefault(JSONObject())

    /** How many equal fields this segment's own outside side ("Top", "Left", "Bottom", "Right") is cut into (1-6). */
    fun edgeCount(side: String): Int = moreJson().optInt("c$side", 1).coerceIn(1, 6)

    /** The action of field [i] (0-based) of an own outside side. */
    fun edgeAct(side: String, i: Int): String {
        if (i <= 0) return when (side) { "Top" -> edgeTop; "Left" -> edgeLeft; "Bottom" -> edgeBottom; else -> edgeRight }
        return moreJson().optString("$side$i")
    }

    fun withEdgeAct(side: String, i: Int, v: String): Seg {
        if (i <= 0) return when (side) { "Top" -> copy(edgeTop = v); "Left" -> copy(edgeLeft = v); "Bottom" -> copy(edgeBottom = v); else -> copy(edgeRight = v) }
        val j = moreJson(); j.put("$side$i", v)
        return copy(edgeMore = j.toString())
    }

    fun withEdgeCount(side: String, n: Int): Seg {
        val j = moreJson(); j.put("c$side", n.coerceIn(1, 6))
        return copy(edgeMore = j.toString())
    }

    val hMain get() = sizeAll || heightMain
    val wMain get() = sizeAll || copyWidth
    val inM get() = feelAll || inMain
    val touchM get() = feelAll || touchMain
    val vertM get() = feelAll || vertMain

    companion object {
        fun newId(): String {
            val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
            return (1..6).map { chars[kotlin.random.Random.nextInt(chars.length)] }.joinToString("")
        }
        const val MODE_ACTIONS = "actions"
        const val MODE_VOLUME = "volume"
        const val MODE_BRIGHTNESS = "brightness"
        /** A gesture set to this follows whatever the main slider does for the same gesture, live. */
        const val MAIN = "@main"
        /** Opens the shortcut strip, like the main slider's swipe in. */
        const val STRIP = "@strip"
    }
}

/** One edge: switched on or off, with up to three independent segments. */
data class Side(
    val on: Boolean = false,
    val segs: List<Seg> = listOf(Seg(mode = Seg.MODE_VOLUME, topPct = 20, heightPct = 60)),
)

data class SideConfig(
    val left: Side = Side(),
    val right: Side = Side(),
    /** Put the bars away while the on-screen keyboard is open (for phones using the Back swipe). */
    val hideForKeyboard: Boolean = false,
    /** Keep the main slider's readout and panel away while a side segment changes the level. */
    val hideMainBar: Boolean = true,
    /** Side sliders may go on into the volume boost (the dB bar); off = they stop at the maximum volume. */
    val boostBar: Boolean = false,
) {
    fun any() = left.on || right.on

    /** The config as the bars use it: a segment that follows another segment's gestures gets them copied in now. */
    fun resolved(): SideConfig {
        fun find(code: String): Seg? {
            if (code.length < 2) return null
            val side = if (code[0] == 'L') left else if (code[0] == 'R') right else return null
            return side.segs.getOrNull((code.substring(1).toIntOrNull() ?: return null) - 1)
        }
        fun fix(side: Side, letter: Char) = side.copy(segs = side.segs.mapIndexed { i, g ->
            var src = g.actFrom; var hops = 0; var from: Seg? = null
            // Follows a chain (A follows B follows C), but never round a circle.
            while (src.isNotEmpty() && hops < 4 && src != "$letter${i + 1}") {
                from = find(src) ?: break
                src = from.actFrom; hops++
            }
            if (g.actFrom.isEmpty() || from == null) g
            else g.copy(tap = from.tap, double = from.double, long = from.long, up = from.up, down = from.down, inward = from.inward, outward = from.outward)
        })
        return copy(left = fix(left, 'L'), right = fix(right, 'R'))
    }

    fun toJson(): String = JSONObject().apply {
        put("kb", hideForKeyboard); put("hm", hideMainBar); put("bb", boostBar)
        put("l", side(left)); put("r", side(right))
    }.toString()

    private fun side(s: Side) = JSONObject().apply {
        put("on", s.on)
        put("segs", JSONArray().apply {
            s.segs.forEach { g ->
                put(JSONObject().apply {
                    put("on", g.on); put("m", g.mode)
                    put("t", g.tap); put("d", g.double); put("l", g.long)
                    put("u", g.up); put("n", g.down); put("i", g.inward); put("o", g.outward)
                    put("tp", g.topPct); put("hp", g.heightPct)
                    put("pm", g.posMain); put("sh", g.shiftPct); put("hm", g.heightMain)
                    put("wd", g.widthDp); put("cw", g.copyWidth); put("cl", g.copyLook); put("sa", g.sizeAll); put("fa", g.feelAll)
                    put("lk", g.linkTo); put("af", g.actFrom); put("vm", g.vertMain); put("vd", g.vertDeg); put("im", g.inMain); put("id", g.inDp); put("tm", g.touchMain); put("td", g.touchDp)
                    put("eo", g.edgeOn); put("et", g.edgeTop); put("el", g.edgeLeft); put("eb", g.edgeBottom); put("er", g.edgeRight); put("gp", g.gapDp); put("ef", g.edgeFollow); put("mr", g.mirror); put("em", g.edgeMore); put("sid", g.id); put("ow", g.ownWindow)
                })
            }
        })
    }

    companion object {
        private const val PREFS = "MyPrefs"
        const val KEY = "sidesV1"

        fun load(context: Context): SideConfig = runCatching {
            val s = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
                ?: return@runCatching SideConfig()
            val o = JSONObject(s)
            val oldWidth = o.optInt("w", 16)
            val madeId = BooleanArray(1)
            val c = SideConfig(parse(o.optJSONObject("l"), oldWidth, madeId), parse(o.optJSONObject("r"), oldWidth, madeId), o.optBoolean("kb", false), o.optBoolean("hm", true), o.optBoolean("bb", false))
            // Segments saved before B227 had no id: they got one now, and it is kept from here on.
            if (madeId[0]) save(context, c)
            c
        }.getOrDefault(SideConfig())

        fun save(context: Context, c: SideConfig) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, c.toJson()).apply()
        }

        private fun parse(o: JSONObject?, oldWidth: Int, madeId: BooleanArray): Side {
            if (o == null) return Side()
            val arr = o.optJSONArray("segs")
            val n = (arr?.length() ?: 0).coerceAtMost(3)
            // Older saves stacked the segments in one span with weights; turn that into a place each.
            val sideTop = o.optInt("top", 20); val sideH = o.optInt("h", 60)
            val weights = (0 until n).map { arr!!.getJSONObject(it).optDouble("w", 1.0) }
            val sumW = weights.sum().coerceAtLeast(0.1)
            var used = 0.0
            val segs = (0 until n).map {
                val g = arr!!.getJSONObject(it)
                val share = sideH * weights[it] / sumW
                val oldTop = (sideTop + used).toInt(); val oldH = share.toInt().coerceAtLeast(5)
                used += share
                // An older "exact clone" segment followed the main slider for everything: keep that.
                val cn = g.optBoolean("cn")
                fun gesture(k: String) = g.optString(k).let { v -> if (cn && v.isEmpty()) Seg.MAIN else v }
                val hm = g.optBoolean("hm"); val cw = g.optBoolean("cw")
                val im = g.optBoolean("im"); val tm = g.optBoolean("tm"); val vm = g.optBoolean("vm", true)
                Seg(
                    on = g.optBoolean("on", true), mode = if (cn) Seg.MODE_VOLUME else g.optString("m", Seg.MODE_ACTIONS),
                    tap = gesture("t"), double = gesture("d"), long = gesture("l"), up = gesture("u"), down = gesture("n"),
                    inward = gesture("i"), outward = gesture("o"),
                    topPct = g.optInt("tp", oldTop), heightPct = g.optInt("hp", oldH),
                    posMain = g.optBoolean("pm"), shiftPct = g.optInt("sh"), heightMain = hm,
                    widthDp = g.optInt("wd", oldWidth), copyWidth = cw,
                    copyLook = if (g.has("sa") || g.has("fa")) g.optBoolean("cl", true) else (g.optBoolean("cl") || cn),
                    sizeAll = if (g.has("sa")) g.optBoolean("sa") else (cn || (hm && cw)),
                    feelAll = if (g.has("fa")) g.optBoolean("fa") else (cn || (im && tm && vm)),
                    vertMain = vm, vertDeg = g.optInt("vd", 30), linkTo = g.optString("lk"), actFrom = g.optString("af"), inMain = im, inDp = g.optInt("id"), touchMain = tm, touchDp = g.optInt("td"),
                    edgeOn = g.optBoolean("eo"), edgeTop = g.optString("et"), edgeLeft = g.optString("el"), edgeBottom = g.optString("eb"), edgeRight = g.optString("er"), gapDp = g.optInt("gp", -1), edgeFollow = g.optBoolean("ef", false), mirror = g.optBoolean("mr", true), edgeMore = g.optString("em"),
                    id = g.optString("sid").ifEmpty { madeId[0] = true; Seg.newId() }, ownWindow = g.optBoolean("ow", false),
                )
            }.ifEmpty { listOf(Seg()) }
            return Side(o.optBoolean("on"), segs)
        }
    }
}
