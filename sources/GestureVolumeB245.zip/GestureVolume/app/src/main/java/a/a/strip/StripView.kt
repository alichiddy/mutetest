package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.floor

/**
 * The shortcut strip: a grid of cells drawn straight to the canvas.
 *
 * An icon costs nothing to keep: an emoji is a few bytes of text drawn by the system font, and an
 * app's icon is the drawable the package manager already holds, drawn in place and dropped with
 * this view when the finger lifts. No bitmaps, no animation, no Compose.
 *
 * It takes no touches of its own. The bar's window keeps the gesture and forwards the finger's
 * screen position to [setFinger]; this finds the cell under it and lights it.
 */
class StripView(
    context: Context,
    val items: List<StripItem>,
    val cellPx: Int,
    private val columns: Int,
    private val showLabels: Boolean,
    /** Columns run right to left, so cell 1 is nearest the right edge (for a bar on the left). */
    private val mirror: Boolean = false,
    /** A folder's window: reads its own look settings (see [LookPrefs]); any it does not have follow the cells window. */
    private val folderLook: Boolean = false,
    /** Where the look settings are read from: the main slider's (default) or a segment's own cells window. */
    prefs: android.content.SharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE),
) : View(context) {

    /**
     * How the cells look (settings in the cells window): 0 = tiles as always, 1 = icons only (no tile, no panel,
     * icons bigger), 2 = icons only on a very faint dark panel. [halo] = a soft dark glow around every icon and
     * name so they read on any background colour.
     */
    private val look: Int
    private val backdropAlpha: Int
    private val halo: Boolean
    /** The cells' own settings: tile colour (0 = the standard teal), icon size and the gap between cells, in percent. */
    private val tileColor: Int
    private val iconScale: Float
    private val gapPct: Int
    /** The names under the icons: size in percent (100 = as before) and an outline (colour 0 = none, width in percent of the text size). */
    private val labelMul: Float
    private val outlineColor: Int
    private val outlinePct: Int
    init {
        val sp = prefs
        fun k(name: String) = LookPrefs.readKey(sp, folderLook, name)
        look = sp.getInt(k("stripLook"), 0).coerceIn(0, 2)
        backdropAlpha = (sp.getInt(k("stripBackdropPct"), 18).coerceIn(0, 80) * 255 / 100)
        halo = sp.getBoolean(k("stripHalo"), false)
        tileColor = sp.getInt(k("stripTileColor"), 0)
        iconScale = sp.getInt(k("stripIconPct"), 100).coerceIn(50, 170) / 100f
        gapPct = sp.getInt(k("stripGapPct"), 8).coerceIn(0, 40)
        labelMul = sp.getInt(k("stripLabelPct"), 100).coerceIn(50, 200) / 100f
        outlineColor = sp.getInt(k("stripOutlineColor"), 0)
        outlinePct = sp.getInt(k("stripOutlinePct"), 14).coerceIn(4, 40)
    }
    /** Pinned cells: a small dot in the corner, or (instead) the cell's text in another colour. Same in folders. */
    private val pinDot: Boolean
    private val pinDotPx: Float
    private val pinDotColor: Int
    private val pinText: Boolean
    private val pinTextColor: Int
    private val pinCorner: Int
    private val pinDx: Float
    private val pinDy: Float
    init {
        val sp = prefs
        pinDot = sp.getBoolean("stripPinDot", true)
        pinDotPx = sp.getInt("stripPinDotPx", 5).coerceIn(1, 12) * context.resources.displayMetrics.density
        pinDotColor = sp.getInt("stripPinDotColor", 0xFFFF5252.toInt())
        pinText = sp.getBoolean("stripPinText", false)
        pinTextColor = sp.getInt("stripPinTextColor", 0xFFFFD600.toInt())
        pinCorner = sp.getInt("stripPinDotCorner", 0).coerceIn(0, 3)
        // Distance from the corner in dp; -1 = never chosen (the dot sits where it always did).
        val dens = context.resources.displayMetrics.density
        val hasD = sp.contains("stripPinDotX") || sp.contains("stripPinDotY")
        pinDx = if (hasD) sp.getInt("stripPinDotX", 3).coerceIn(0, 24) * dens else -1f
        pinDy = if (hasD) sp.getInt("stripPinDotY", 3).coerceIn(0, 24) * dens else -1f
    }
    private val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plain get() = look != 0
    private val iconPx: Int get() = (cellPx * (if (plain) 0.95f else 0.8f) * maxOf(1f, iconScale)).toInt().coerceIn(32, 384)

    private val rows = ((items.size + columns - 1) / columns).coerceAtLeast(1)
    private val gapPx = if (gapPct == 0) 0f else (cellPx * gapPct / 100f).coerceAtLeast(2f)

    private var originX = 0f
    private var originY = 0f

    /** The editor draws blank cells too, so one can be selected. */
    var editorMode = false

    /** The cell under the finger, or -1. */
    var hot = -1
        private set

    private val appIcons = HashMap<String, Bitmap?>()
    private val imgIcons = HashMap<String, Bitmap?>()
    /** After a release: the one cell that stays on screen, so the shortcut that ran can be seen. */
    private var only = -1
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val backdropPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = if (tileColor != 0) tileColor else 0xFF1F8A8A.toInt() }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3638.toInt() }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val rect2 = RectF()

    val panelWidthPx: Int get() = (columns * cellPx + gapPx * (columns + 1)).toInt()
    val panelHeightPx: Int get() = (rows * cellPx + gapPx * (rows + 1)).toInt()

    init {
        val pm = context.packageManager
        for (item in items) {
            val f = item.iconFile ?: continue
            if (f !in imgIcons) imgIcons[f] = runCatching {
                val raw = android.graphics.BitmapFactory.decodeFile(java.io.File(context.filesDir, "sicons/$f").path)
                val px = iconPx
                raw?.let { Bitmap.createScaledBitmap(it, px, px, true) }
            }.getOrNull()
        }
        for (item in items) {
            val pkg = item.appIconPackage ?: continue
            if (pkg !in appIcons) appIcons[pkg] = runCatching {
                // Drawn once into a plain bitmap: an adaptive icon drawn straight onto the (hardware)
                // canvas, one shared drawable re-bounded for every cell, left black patches while moving.
                val d = pm.getApplicationIcon(pkg)
                val px = iconPx
                Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888).also { bmp ->
                    val c = Canvas(bmp)
                    d.setBounds(0, 0, px, px)
                    d.draw(c)
                }
            }.getOrNull()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelWidthPx, panelHeightPx)
    }

    /** Where this panel sits on the screen, for telling which side of it the finger left by. */
    fun screenBounds(): android.graphics.RectF = android.graphics.RectF(originX, originY, originX + panelWidthPx, originY + panelHeightPx)

    fun setScreenOrigin(x: Float, y: Float) {
        originX = x
        originY = y
    }

    /** The cell at a screen position, or -1 for a gap, the margin or outside the panel. */
    fun cellAt(rawX: Float, rawY: Float): Int {
        val x = rawX - originX - gapPx
        val y = rawY - originY - gapPx
        if (x < 0f || y < 0f) return -1
        val step = cellPx + gapPx
        val col = floor(x / step).toInt()
        val row = floor(y / step).toInt()
        if (col !in 0 until columns || row !in 0 until rows) return -1
        val dataCol = if (mirror) columns - 1 - col else col
        if (x - col * step > cellPx || y - row * step > cellPx) {
            return hot.takeIf { it >= 0 && it == row * columns + dataCol } ?: -1
        }
        val index = row * columns + dataCol
        return if (index < items.size) index else -1
    }

    /** Whether a screen position is inside this panel (gaps and margin included). */
    fun contains(rawX: Float, rawY: Float): Boolean =
        rawX >= originX && rawY >= originY && rawX < originX + panelWidthPx && rawY < originY + panelHeightPx

    fun clearHot() { if (hot != -1) { hot = -1; invalidate() } }

    /** Where cell [index] is on the screen (the same frame as [screenBounds]). */
    fun cellScreenRect(index: Int): RectF {
        val col = if (mirror) columns - 1 - index % columns else index % columns
        val row = index / columns
        val left = originX + gapPx + col * (cellPx + gapPx)
        val top = originY + gapPx + row * (cellPx + gapPx)
        return RectF(left, top, left + cellPx, top + cellPx)
    }

    /** Draws one cell, lit, scaled to [sizePx], for the thumb popup. The same icon and name as in the panel. */
    fun drawTile(canvas: Canvas, index: Int, sizePx: Float) {
        val item = items.getOrNull(index) ?: return
        val s = sizePx / cellPx
        val box = RectF(0f, 0f, cellPx.toFloat(), cellPx.toFloat())
        canvas.save()
        canvas.scale(s, s)
        canvas.drawRoundRect(box, cellPx * 0.22f, cellPx * 0.22f, hotPaint)
        drawItem(canvas, item, box, 0xFF000000.toInt(), false, false)
        canvas.restore()
    }

    /** Which sides of the panel glow (bit 1 top, 2 left, 4 bottom, 8 right): the side whose outside action is about to run. */
    private var glow = 0
    fun setGlow(mask: Int) { if (mask != glow) { glow = mask; invalidate() } }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }

    /** The editor's multi-selection (and the cells being dragged). */
    private var marked: Set<Int> = emptySet()
    fun setMarked(set: Set<Int>) { if (set != marked) { marked = set; invalidate() } }

    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val markPath = android.graphics.Path()

    /** Lights one cell without a finger, for the editor's selection. */
    fun highlight(index: Int) {
        if (hot == index) return
        hot = index
        invalidate()
    }

    fun keepOnly(index: Int) {
        only = index
        hot = index
        invalidate()
    }

    fun setFinger(rawX: Float, rawY: Float) {
        val next = cellAt(rawX, rawY)
        if (next == hot) return
        hot = next
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        if (only < 0) when (look) {
            0 -> canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, panelPaint)
            2 -> canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, backdropPaint.apply { color = backdropAlpha shl 24 })
        }
        val radius = cellPx * 0.22f
        for (i in items.indices) {
            val item = items[i]
            val col = if (mirror) columns - 1 - i % columns else i % columns
            val row = i / columns
            val left = gapPx + col * (cellPx + gapPx)
            val top = gapPx + row * (cellPx + gapPx)
            rect.set(left, top, left + cellPx, top + cellPx)
            val blank = item.action.isEmpty() && item.label.isEmpty() && item.icon.isEmpty()
            if (blank && editorMode && only < 0) {
                // In the editor a blank cell is shown, so it can be seen and selected.
                canvas.drawRoundRect(rect, radius, radius, if (i == hot || i in marked) hotPaint else emptyPaint)
                continue
            }
            if (blank || (only >= 0 && i != only)) continue
            val lit = i == hot || i in marked
            // Icons-only looks: no tile behind a cell, except the lit one so the finger's cell still shows.
            if (!plain || lit) canvas.drawRoundRect(
                rect, radius, radius,
                when {
                    lit -> hotPaint
                    item.action.isNotEmpty() -> cellPaint
                    else -> emptyPaint
                }
            )
            val ink = if (lit) 0xFF000000.toInt() else if (item.pinned && pinText) pinTextColor else 0xFFFFFFFF.toInt()
            drawItem(canvas, item, rect, ink, halo && !lit, !lit)
            if (item.pinned && pinDot) {
                val r = pinDotPx / 2f
                val inset = maxOf(r, cellPx * 0.06f)
                val dx = if (pinDx < 0f) inset + r * 0.2f else pinDx + r
                val dy = if (pinDy < 0f) inset + r * 0.2f else pinDy + r
                val cx = if (pinCorner == 1 || pinCorner == 3) rect.right - dx else rect.left + dx
                val cy = if (pinCorner >= 2) rect.bottom - dy else rect.top + dy
                pinPaint.color = pinDotColor
                canvas.drawCircle(cx, cy, r, pinPaint)
            }
            if (item.isFolder) {
                // A small corner mark: this cell opens a folder.
                markPaint.color = ink
                val m = cellPx * 0.2f
                markPath.reset()
                markPath.moveTo(rect.right - m, rect.bottom - cellPx * 0.06f)
                markPath.lineTo(rect.right - cellPx * 0.06f, rect.bottom - cellPx * 0.06f)
                markPath.lineTo(rect.right - cellPx * 0.06f, rect.bottom - m)
                markPath.close()
                canvas.drawPath(markPath, markPaint)
            }
        }
        if (glow != 0) drawGlow(canvas)
    }

    private fun drawGlow(canvas: Canvas) {
        val t = (cellPx * 0.1f).coerceAtLeast(4f)
        val w = width.toFloat(); val h = height.toFloat()
        if (glow and 1 != 0) canvas.drawRect(0f, 0f, w, t, glowPaint)
        if (glow and 2 != 0) canvas.drawRect(0f, 0f, t, h, glowPaint)
        if (glow and 4 != 0) canvas.drawRect(0f, h - t, w, h, glowPaint)
        if (glow and 8 != 0) canvas.drawRect(w - t, 0f, w, h, glowPaint)
    }

    private val fitPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private val haloBlur = HashMap<Bitmap, Pair<Bitmap, IntArray>>()

    /** The soft dark glow of an icon picture: its own outline, blurred. Made once per picture. */
    private fun haloOf(bmp: Bitmap): Pair<Bitmap, IntArray> = haloBlur.getOrPut(bmp) {
        val off = IntArray(2)
        val p = Paint().apply { maskFilter = android.graphics.BlurMaskFilter((bmp.width * 0.07f).coerceAtLeast(2f), android.graphics.BlurMaskFilter.Blur.NORMAL) }
        bmp.extractAlpha(p, off) to off
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC000000.toInt() }

    private fun drawItem(canvas: Canvas, item: StripItem, box: RectF, ink: Int, glow: Boolean, outline: Boolean) {
        if (item.icon == FitText.NONE) {
            // No icon: what was typed fills the cell, up to three lines, no name underneath.
            if (glow) fitPaint.setShadowLayer(cellPx * 0.07f, 0f, 0f, 0xE6000000.toInt()) else fitPaint.clearShadowLayer()
            FitText.draw(canvas, fitPaint, item.label, box, ink, if (outline) outlineColor else 0, outlinePct)
            return
        }
        val appIcon = item.appIconPackage?.let { appIcons[it] } ?: item.iconFile?.let { imgIcons[it] }
        // An emoji this phone's font cannot draw (a newer one) would show as an empty box: try a
        // close older one, else fall back to the name.
        val glyph = if (item.icon.isEmpty() || item.appIconPackage != null || item.iconFile != null) item.icon
        else if (textPaint.hasGlyph(item.icon)) item.icon else (SUBSTITUTE[item.icon]?.takeIf { textPaint.hasGlyph(it) } ?: "")
        val hasIcon = appIcon != null || (glyph.isNotEmpty() && item.appIconPackage == null && item.iconFile == null)
        if (!hasIcon) {
            if (glow) textPaint.setShadowLayer(cellPx * 0.06f, 0f, 0f, 0xE6000000.toInt()) else textPaint.clearShadowLayer()
            drawLabel(canvas, item.label, box, box.centerY(), 0.24f, ink, outline)
            textPaint.clearShadowLayer()
            return
        }
        val labelled = showLabels && item.label.isNotEmpty()
        val iconBox = (if (plain) { if (labelled) box.height() * 0.72f else box.height() * 0.9f } else if (labelled) box.height() * 0.66f else box.height() * 0.78f) * iconScale
        // A bigger name pushes the icon up a little and the name down a little, so they do not touch.
        val bigger = (labelMul - 1f).coerceAtLeast(0f)
        val cy = if (labelled) box.top + box.height() * (0.38f - bigger * 0.06f) else box.centerY()
        if (appIcon != null) {
            val half = (iconBox / 2f).toInt()
            rect2.set(box.centerX() - half, cy - half, box.centerX() + half, cy + half)
            if (glow) {
                val (h, off) = haloOf(appIcon)
                val k = rect2.width() / appIcon.width
                val l = rect2.left + off[0] * k; val t = rect2.top + off[1] * k
                canvas.drawBitmap(h, null, RectF(l, t, l + h.width * k, t + h.height * k), haloPaint)
            }
            canvas.drawBitmap(appIcon, null, rect2, bitmapPaint)
        } else {
            textPaint.color = 0xFFFFFFFF.toInt()
            textPaint.textSize = iconBox * 0.86f
            val y = cy - (textPaint.descent() + textPaint.ascent()) / 2f
            if (glow) textPaint.setShadowLayer(cellPx * 0.06f, 0f, 0f, 0xE6000000.toInt())
            canvas.drawText(glyph, box.centerX(), y, textPaint)
            textPaint.clearShadowLayer()
        }
        if (labelled) {
            if (glow) textPaint.setShadowLayer(cellPx * 0.05f, 0f, 0f, 0xE6000000.toInt())
            drawLabel(canvas, item.label, box, box.top + box.height() * (0.86f + bigger * 0.04f).coerceAtMost(0.9f), 0.17f, ink, outline)
            textPaint.clearShadowLayer()
        }
    }

    private fun drawLabel(canvas: Canvas, label: String, box: RectF, centerY: Float, scale: Float, color: Int, outline: Boolean) {
        if (label.isEmpty()) return
        textPaint.color = color
        val base = cellPx * scale * labelMul
        textPaint.textSize = base
        // A long name is shrunk to fit; a bigger name may reach a little into the gaps.
        val room = box.width() * (0.92f + (labelMul - 1f).coerceAtLeast(0f) * 0.3f)
        val wide = textPaint.measureText(label)
        if (wide > room) textPaint.textSize = base * room / wide
        val y = centerY - (textPaint.descent() + textPaint.ascent()) / 2f
        if (outline && outlineColor != 0) {
            // The outline first (a thick stroke in the user's colour), the letters on top.
            textPaint.style = Paint.Style.STROKE
            textPaint.strokeJoin = Paint.Join.ROUND
            textPaint.strokeWidth = textPaint.textSize * outlinePct / 100f
            textPaint.color = outlineColor
            canvas.drawText(label, box.centerX(), y, textPaint)
            textPaint.style = Paint.Style.FILL
            textPaint.color = color
        }
        canvas.drawText(label, box.centerX(), y, textPaint)
    }

    private companion object {
        /** Newer emoji and the older look-alike that every phone can draw. */
        val SUBSTITUTE = mapOf(
            "\uD83D\uDEDC" to "\uD83D\uDCF6", "\uD83E\uDEAB" to "\uD83D\uDD0B", "\uD83E\uDEAA" to "\uD83D\uDEAA",
            "\uD83E\uDEE0" to "\uD83D\uDE42", "\uD83E\uDEE1" to "\uD83D\uDE42", "\uD83E\uDEE5" to "\uD83D\uDE36",
            "\uD83E\uDEE8" to "\uD83D\uDE2E", "\uD83E\uDEF6" to "\u2764\uFE0F", "\uD83E\uDEF0" to "\uD83D\uDC4D",
        )
    }
}
