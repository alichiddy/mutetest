package com.newagedevs.gesturevolume.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.floor

/**
 * The shortcut strip: a grid of cells drawn straight to the canvas.
 *
 * An icon costs nothing to keep: an emoji is a few bytes of text drawn by the system font, and an
 * app's icon is the drawable the package manager already holds, drawn in place and dropped with
 * this view when the finger lifts. No bitmaps, no animation, no Compose.
 *
 * It takes no touches of its own. The bar's window keeps the gesture and forwards the finger's
 * screen position to [setFinger]; this finds the cell under it and lights it.
 */
class StripView(
    context: Context,
    val items: List<StripItem>,
    val cellPx: Int,
    private val columns: Int,
    private val showLabels: Boolean,
    /** Columns run right to left, so cell 1 is nearest the right edge (for a bar on the left). */
    private val mirror: Boolean = false,
) : View(context) {

    private val rows = ((items.size + columns - 1) / columns).coerceAtLeast(1)
    private val gapPx = (cellPx * 0.08f).coerceAtLeast(2f)

    private var originX = 0f
    private var originY = 0f

    /** The editor draws blank cells too, so one can be selected. */
    var editorMode = false

    /** The cell under the finger, or -1. */
    var hot = -1
        private set

    private val appIcons = HashMap<String, Bitmap?>()
    private val imgIcons = HashMap<String, Bitmap?>()
    /** After a release: the one cell that stays on screen, so the shortcut that ran can be seen. */
    private var only = -1
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6102A2E.toInt() }
    private val cellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1F8A8A.toInt() }
    private val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A3638.toInt() }
    private val hotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFB300.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val rect2 = RectF()

    val panelWidthPx: Int get() = (columns * cellPx + gapPx * (columns + 1)).toInt()
    val panelHeightPx: Int get() = (rows * cellPx + gapPx * (rows + 1)).toInt()

    init {
        val pm = context.packageManager
        for (item in items) {
            val f = item.iconFile ?: continue
            if (f !in imgIcons) imgIcons[f] = runCatching {
                val raw = android.graphics.BitmapFactory.decodeFile(java.io.File(context.filesDir, "sicons/$f").path)
                val px = (cellPx * 0.8f).toInt().coerceIn(32, 192)
                raw?.let { Bitmap.createScaledBitmap(it, px, px, true) }
            }.getOrNull()
        }
        for (item in items) {
            val pkg = item.appIconPackage ?: continue
            if (pkg !in appIcons) appIcons[pkg] = runCatching {
                // Drawn once into a plain bitmap: an adaptive icon drawn straight onto the (hardware)
                // canvas, one shared drawable re-bounded for every cell, left black patches while moving.
                val d = pm.getApplicationIcon(pkg)
                val px = (cellPx * 0.8f).toInt().coerceIn(32, 192)
                Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888).also { bmp ->
                    val c = Canvas(bmp)
                    d.setBounds(0, 0, px, px)
                    d.draw(c)
                }
            }.getOrNull()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(panelWidthPx, panelHeightPx)
    }

    /** Where this panel sits on the screen, for telling which side of it the finger left by. */
    fun screenBounds(): android.graphics.RectF = android.graphics.RectF(originX, originY, originX + panelWidthPx, originY + panelHeightPx)

    fun setScreenOrigin(x: Float, y: Float) {
        originX = x
        originY = y
    }

    /** The cell at a screen position, or -1 for a gap, the margin or outside the panel. */
    fun cellAt(rawX: Float, rawY: Float): Int {
        val x = rawX - originX - gapPx
        val y = rawY - originY - gapPx
        if (x < 0f || y < 0f) return -1
        val step = cellPx + gapPx
        val col = floor(x / step).toInt()
        val row = floor(y / step).toInt()
        if (col !in 0 until columns || row !in 0 until rows) return -1
        val dataCol = if (mirror) columns - 1 - col else col
        if (x - col * step > cellPx || y - row * step > cellPx) {
            return hot.takeIf { it >= 0 && it == row * columns + dataCol } ?: -1
        }
        val index = row * columns + dataCol
        return if (index < items.size) index else -1
    }

    /** Whether a screen position is inside this panel (gaps and margin included). */
    fun contains(rawX: Float, rawY: Float): Boolean =
        rawX >= originX && rawY >= originY && rawX < originX + panelWidthPx && rawY < originY + panelHeightPx

    fun clearHot() { if (hot != -1) { hot = -1; invalidate() } }

    /** The editor's multi-selection (and the cells being dragged). */
    private var marked: Set<Int> = emptySet()
    fun setMarked(set: Set<Int>) { if (set != marked) { marked = set; invalidate() } }

    private val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val markPath = android.graphics.Path()

    /** Lights one cell without a finger, for the editor's selection. */
    fun highlight(index: Int) {
        if (hot == index) return
        hot = index
        invalidate()
    }

    fun keepOnly(index: Int) {
        only = index
        hot = index
        invalidate()
    }

    fun setFinger(rawX: Float, rawY: Float) {
        val next = cellAt(rawX, rawY)
        if (next == hot) return
        hot = next
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        if (only < 0) canvas.drawRoundRect(rect, cellPx * 0.2f, cellPx * 0.2f, panelPaint)
        val radius = cellPx * 0.22f
        for (i in items.indices) {
            val item = items[i]
            val col = if (mirror) columns - 1 - i % columns else i % columns
            val row = i / columns
            val left = gapPx + col * (cellPx + gapPx)
            val top = gapPx + row * (cellPx + gapPx)
            rect.set(left, top, left + cellPx, top + cellPx)
            val blank = item.action.isEmpty() && item.label.isEmpty() && item.icon.isEmpty()
            if (blank && editorMode && only < 0) {
                // In the editor a blank cell is shown, so it can be seen and selected.
                canvas.drawRoundRect(rect, radius, radius, if (i == hot || i in marked) hotPaint else emptyPaint)
                continue
            }
            if (blank || (only >= 0 && i != only)) continue
            canvas.drawRoundRect(
                rect, radius, radius,
                when {
                    i == hot || i in marked -> hotPaint
                    item.action.isNotEmpty() -> cellPaint
                    else -> emptyPaint
                }
            )
            val ink = if (i == hot || i in marked) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            drawItem(canvas, item, rect, ink)
            if (item.isFolder) {
                // A small corner mark: this cell opens a folder.
                markPaint.color = ink
                val m = cellPx * 0.2f
                markPath.reset()
                markPath.moveTo(rect.right - m, rect.bottom - cellPx * 0.06f)
                markPath.lineTo(rect.right - cellPx * 0.06f, rect.bottom - cellPx * 0.06f)
                markPath.lineTo(rect.right - cellPx * 0.06f, rect.bottom - m)
                markPath.close()
                canvas.drawPath(markPath, markPaint)
            }
        }
    }

    private val fitPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun drawItem(canvas: Canvas, item: StripItem, box: RectF, ink: Int) {
        if (item.icon == FitText.NONE) {
            // No icon: what was typed fills the cell, up to three lines, no name underneath.
            FitText.draw(canvas, fitPaint, item.label, box, ink)
            return
        }
        val appIcon = item.appIconPackage?.let { appIcons[it] } ?: item.iconFile?.let { imgIcons[it] }
        // An emoji this phone's font cannot draw (a newer one) would show as an empty box: try a
        // close older one, else fall back to the name.
        val glyph = if (item.icon.isEmpty() || item.appIconPackage != null || item.iconFile != null) item.icon
        else if (textPaint.hasGlyph(item.icon)) item.icon else (SUBSTITUTE[item.icon]?.takeIf { textPaint.hasGlyph(it) } ?: "")
        val hasIcon = appIcon != null || (glyph.isNotEmpty() && item.appIconPackage == null && item.iconFile == null)
        if (!hasIcon) {
            drawLabel(canvas, item.label, box, box.centerY(), 0.24f, ink)
            return
        }
        val labelled = showLabels && item.label.isNotEmpty()
        val iconBox = if (labelled) box.height() * 0.66f else box.height() * 0.78f
        val cy = if (labelled) box.top + box.height() * 0.38f else box.centerY()
        if (appIcon != null) {
            val half = (iconBox / 2f).toInt()
            rect2.set(box.centerX() - half, cy - half, box.centerX() + half, cy + half)
            canvas.drawBitmap(appIcon, null, rect2, bitmapPaint)
        } else {
            textPaint.color = 0xFFFFFFFF.toInt()
            textPaint.textSize = iconBox * 0.86f
            val y = cy - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(glyph, box.centerX(), y, textPaint)
        }
        if (labelled) drawLabel(canvas, item.label, box, box.top + box.height() * 0.86f, 0.17f, ink)
    }

    private fun drawLabel(canvas: Canvas, label: String, box: RectF, centerY: Float, scale: Float, color: Int) {
        if (label.isEmpty()) return
        textPaint.color = color
        val base = cellPx * scale
        textPaint.textSize = base
        val room = box.width() * 0.92f
        val wide = textPaint.measureText(label)
        if (wide > room) textPaint.textSize = base * room / wide
        val y = centerY - (textPaint.descent() + textPaint.ascent()) / 2f
        canvas.drawText(label, box.centerX(), y, textPaint)
    }

    private companion object {
        /** Newer emoji and the older look-alike that every phone can draw. */
        val SUBSTITUTE = mapOf(
            "\uD83D\uDEDC" to "\uD83D\uDCF6", "\uD83E\uDEAB" to "\uD83D\uDD0B", "\uD83E\uDEAA" to "\uD83D\uDEAA",
            "\uD83E\uDEE0" to "\uD83D\uDE42", "\uD83E\uDEE1" to "\uD83D\uDE42", "\uD83E\uDEE5" to "\uD83D\uDE36",
            "\uD83E\uDEE8" to "\uD83D\uDE2E", "\uD83E\uDEF6" to "\u2764\uFE0F", "\uD83E\uDEF0" to "\uD83D\uDC4D",
        )
    }
}
