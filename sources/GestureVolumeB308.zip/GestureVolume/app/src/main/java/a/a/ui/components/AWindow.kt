package a.a.ui.components

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import a.a.ui.motion.IconButton
import a.a.ui.theme.ATheme

/*
 * The windows that are their own screens (Widgets, Launcher mode, Scripts...) used to be drawn in the plain
 * default Material colours. This puts them in A's own theme, with the light/dark choice made in the main
 * screen, so they look like the windows that live inside the main app.
 */

/** A's theme (the app's light/dark choice, else the system's) and the page colour behind a window. */
@Composable
fun AWindow(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val mode = ctx.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE).getInt("app_theme", 0)
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    ATheme(darkTheme = dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

/** A window with the same top bar as the Cells window: a back arrow and the title. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AWindowPage(title: String, onBack: () -> Unit, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        content = content,
    )
}
