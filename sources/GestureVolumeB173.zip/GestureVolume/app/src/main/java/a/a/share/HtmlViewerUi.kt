package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebView
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView

/** A web view that tells its owner how far it is scrolled, for the quick scroll bar. */
class ScrollWebView(context: Context) : WebView(context) {
    var onScrolled: (() -> Unit)? = null
    fun range() = computeVerticalScrollRange()
    fun offset() = computeVerticalScrollOffset()
    fun extent() = computeVerticalScrollExtent()
    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrolled?.invoke()
    }
}

/**
 * The HTML viewer's own controls, drawn over the page only while they are used: a blue bar to scroll
 * quickly and, above it, up to three round buttons (screen mode, stay awake, settings). Scrolling or
 * touching shows them; 3 seconds without touching the bar or a button hides them again.
 *
 * Screen mode cycles: both system bars, status bar only, navigation bar only, full screen.
 * Everything is plain views and nothing runs while the controls are hidden.
 */
class HtmlViewerUi(private val act: Activity, private val web: ScrollWebView, private val frame: FrameLayout) {
    private val prefs = act.getSharedPreferences("html_viewer", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private val blue = 0xFF1E88E5.toInt()

    private val layer = FrameLayout(act)
    private val buttons = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val bar = Bar(act)
    private var clock: TextClock? = null
    private var mode = 0 // 0 both bars, 1 status bar only, 2 navigation bar only, 3 full screen
    private var awake = false
    private var holding = false
    private val hideRun = Runnable { if (!holding) layer.visibility = View.GONE }

    private val modeBtn = IconBtn(act, 0)
    private val awakeBtn = IconBtn(act, 1)
    private val setBtn = IconBtn(act, 2)

    fun start() {
        mode = prefs.getInt("mode", 0).coerceIn(0, 3)
        layer.visibility = View.GONE
        frame.addView(layer, FrameLayout.LayoutParams(-1, -1))
        layer.addView(bar, FrameLayout.LayoutParams(dp(44), -1, Gravity.END or Gravity.TOP))
        layer.addView(buttons, FrameLayout.LayoutParams(dp(52), -2, Gravity.END or Gravity.TOP))
        modeBtn.setOnClickListener { mode = (mode + 1) % 4; prefs.edit().putInt("mode", mode).apply(); applyMode(); show() }
        awakeBtn.setOnClickListener { awake = !awake; applyAwake(); show() }
        setBtn.setOnClickListener { holding = true; showSettings() }
        layoutButtons()
        web.onScrolled = { show() }
        applyMode()
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        web.onScrolled = null
    }

    fun reapply() = applyMode()

    private fun showBtn(key: String) = prefs.getBoolean(key, true)

    private fun layoutButtons() {
        buttons.removeAllViews()
        val list = ArrayList<IconBtn>()
        if (showBtn("showModeBtn")) list.add(modeBtn)
        if (showBtn("showAwakeBtn")) list.add(awakeBtn)
        list.add(setBtn)
        for (b in list) buttons.addView(b, LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(6) })
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0
        val top = dp(6) + list.size * dp(50)
        (bar.layoutParams as FrameLayout.LayoutParams).topMargin = top
        bar.layoutParams = bar.layoutParams
        bar.visibility = if (showBtn("showBar")) View.VISIBLE else View.GONE
    }

    /** Shows the controls and starts the 3 second countdown to hide them. */
    private fun show() {
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0
        modeBtn.invalidate(); awakeBtn.invalidate()
        bar.invalidate()
        layer.visibility = View.VISIBLE
        handler.removeCallbacks(hideRun)
        if (!holding) handler.postDelayed(hideRun, 3000)
    }

    private fun release() { holding = false; show() }

    @Suppress("DEPRECATION")
    private fun applyMode() {
        val hideStatus = mode == 2 || mode == 3
        val hideNav = mode == 1 || mode == 3
        val w = act.window
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = w.insetsController
            if (c != null) {
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (hideStatus) c.hide(WindowInsets.Type.statusBars()) else c.show(WindowInsets.Type.statusBars())
                if (hideNav) c.hide(WindowInsets.Type.navigationBars()) else c.show(WindowInsets.Type.navigationBars())
            }
        } else {
            var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            if (hideStatus) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN
            if (hideNav) f = f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            w.decorView.systemUiVisibility = f
        }
        modeBtn.state = mode; modeBtn.invalidate()
        updateClock()
    }

    private fun applyAwake() {
        if (awake) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        awakeBtn.state = if (awake) 1 else 0; awakeBtn.invalidate()
    }

    /** The floating clock: only while the status bar is hidden (its own clock is gone then) and when switched on. */
    private fun updateClock() {
        val want = prefs.getBoolean("showClock", false) && (mode == 2 || mode == 3)
        if (!want) { clock?.let { frame.removeView(it) }; clock = null; return }
        if (clock != null) return
        val c = TextClock(act).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0x99000000.toInt()) }
        }
        clock = c
        frame.addView(c, FrameLayout.LayoutParams(-2, -2, cornerGravity()).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        // Wherever it was dropped, when it has been moved by hand.
        if (prefs.contains("clockX")) c.post {
            c.x = prefs.getFloat("clockX", 0f) * (frame.width - c.width).coerceAtLeast(1)
            c.y = prefs.getFloat("clockY", 0f) * (frame.height - c.height).coerceAtLeast(1)
        }
        var dx = 0f; var dy = 0f
        c.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = v.x - e.rawX; dy = v.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    v.x = (e.rawX + dx).coerceIn(0f, (frame.width - v.width).toFloat().coerceAtLeast(0f))
                    v.y = (e.rawY + dy).coerceIn(0f, (frame.height - v.height).toFloat().coerceAtLeast(0f))
                }
                MotionEvent.ACTION_UP -> prefs.edit()
                    .putFloat("clockX", v.x / (frame.width - v.width).coerceAtLeast(1))
                    .putFloat("clockY", v.y / (frame.height - v.height).coerceAtLeast(1)).apply()
            }
            true
        }
    }

    private fun cornerGravity() = when (prefs.getInt("clockCorner", 2)) {
        0 -> Gravity.TOP or Gravity.START
        1 -> Gravity.TOP or Gravity.END
        3 -> Gravity.BOTTOM or Gravity.END
        else -> Gravity.BOTTOM or Gravity.START
    }

    private fun showSettings() {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        fun check(text: String, key: String, def: Boolean, after: (Boolean) -> Unit = {}) {
            col.addView(CheckBox(act).apply {
                this.text = text; isChecked = prefs.getBoolean(key, def)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after(on) }
            })
        }
        check("Show the quick scroll bar", "showBar", true) { layoutButtons() }
        check("Show the screen mode button (both bars / status bar / navigation bar / full screen)", "showModeBtn", true) { layoutButtons() }
        check("Show the stay awake button", "showAwakeBtn", true) { layoutButtons() }
        check("Show a floating clock when the status bar is hidden", "showClock", false) { clock?.let { frame.removeView(it) }; clock = null; updateClock() }
        col.addView(TextView(act).apply { text = "Clock corner (or just drag the clock where you want it):"; setPadding(0, dp(6), 0, 0) })
        val g = RadioGroup(act)
        listOf("Top left", "Top right", "Bottom left", "Bottom right").forEachIndexed { i, n ->
            g.addView(RadioButton(act).apply { text = n; id = 100 + i; isChecked = prefs.getInt("clockCorner", 2) == i })
        }
        g.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("clockCorner", id - 100).remove("clockX").remove("clockY").apply()
            clock?.let { frame.removeView(it) }; clock = null; updateClock()
        }
        col.addView(g)
        col.addView(CheckBox(act).apply {
            text = "Its own window in Recent apps (separate from A), from the next time a page is opened"
            isChecked = HtmlViewerSwitch.separate(act)
            setOnCheckedChangeListener { _, on -> HtmlViewerSwitch.setSeparate(act, on) }
        })
        AlertDialog.Builder(act).setTitle("HTML viewer settings").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Close", null).setOnDismissListener { release() }.show()
    }

    /** The blue quick scroll bar: touch or drag anywhere on it and the page follows. */
    private inner class Bar(ctx: Context) : View(ctx) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x331E88E5 }
        private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue }
        private var dragging = false
        private val r = RectF()

        private fun geometry(): FloatArray? {
            val range = web.range(); val ext = web.extent()
            if (range <= ext || height <= 0) return null
            val h = height.toFloat()
            val th = (h * ext / range).coerceIn(dp(56).toFloat(), h)
            val top = (h - th) * web.offset() / (range - ext)
            return floatArrayOf(th, top)
        }

        override fun onDraw(c: Canvas) {
            val g = geometry() ?: return
            val cx = width - dp(16).toFloat()
            val tw = dp(4) / 2f
            r.set(cx - tw, 0f, cx + tw, height.toFloat()); c.drawRoundRect(r, tw, tw, track)
            val w = (if (dragging) dp(14) else dp(8)) / 2f
            r.set(cx - w, g[1], cx + w, g[1] + g[0]); c.drawRoundRect(r, w, w, thumb)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val g = geometry() ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    parent.requestDisallowInterceptTouchEvent(true)
                    dragging = true; holding = true
                    val frac = ((e.y - g[0] / 2) / (height - g[0]).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    web.scrollTo(web.scrollX, (frac * (web.range() - web.extent())).toInt())
                    invalidate(); show()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; release() }
            }
            return true
        }
    }

    /** A round button drawn in code: 0 = screen mode (phone with its two bars), 1 = stay awake (sun), 2 = settings (sliders). */
    private inner class IconBtn(ctx: Context, private val kind: Int) : View(ctx) {
        var state = 0
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
            bg.color = if (kind == 1 && state == 1) 0xFFFFA000.toInt() else 0xE61E88E5.toInt()
            c.drawCircle(cx, cy, w / 2, bg)
            when (kind) {
                0 -> {
                    val pw = dp(9).toFloat(); val ph = dp(13).toFloat()
                    r.set(cx - pw, cy - ph, cx + pw, cy + ph); c.drawRoundRect(r, dp(3).toFloat(), dp(3).toFloat(), ink)
                    val statusOn = state == 0 || state == 1
                    val navOn = state == 0 || state == 2
                    if (statusOn) { r.set(cx - pw, cy - ph, cx + pw, cy - ph + dp(5)); c.drawRect(r, fill) }
                    if (navOn) { r.set(cx - pw, cy + ph - dp(5), cx + pw, cy + ph); c.drawRect(r, fill) }
                }
                1 -> {
                    c.drawCircle(cx, cy, dp(5).toFloat(), if (state == 1) fill else ink)
                    for (i in 0 until 8) {
                        val a = Math.toRadians(i * 45.0)
                        val x1 = cx + Math.cos(a).toFloat() * dp(8); val y1 = cy + Math.sin(a).toFloat() * dp(8)
                        val x2 = cx + Math.cos(a).toFloat() * dp(12); val y2 = cy + Math.sin(a).toFloat() * dp(12)
                        c.drawLine(x1, y1, x2, y2, ink)
                    }
                }
                else -> {
                    val xs = floatArrayOf(0.3f, 0.65f, 0.45f)
                    for (i in 0 until 3) {
                        val y = cy + (i - 1) * dp(8)
                        c.drawLine(cx - dp(11), y, cx + dp(11), y, ink)
                        c.drawCircle(cx - dp(11) + dp(22) * xs[i], y, dp(3).toFloat(), fill)
                    }
                }
            }
        }
    }
}
