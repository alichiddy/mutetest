package com.newagedevs.gesturevolume.share

import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import com.newagedevs.gesturevolume.utils.ShizukuShell

/**
 * Location and Wi-Fi switching for the share window.
 * Location: WRITE_SECURE_SETTINGS writes it directly (fastest); when that grant is missing and Shizuku
 * runs, Shizuku gives the grant once, so it also works later without Shizuku.
 * Wi-Fi: only Shizuku (svc wifi) can switch it on current Android; older Android can do it itself.
 * Return codes: 0 already in the wanted state, 1 changed by us, -1 could not (the window then asks the user).
 */
object ShareToggles {
    private const val WSS = "android.permission.WRITE_SECURE_SETTINGS"

    private fun canWrite(c: Context) = c.checkSelfPermission(WSS) == PackageManager.PERMISSION_GRANTED

    /** Gets WRITE_SECURE_SETTINGS through Shizuku when A does not have it yet. */
    fun ensureGrant(c: Context): Boolean {
        if (canWrite(c)) return true
        if (!ShizukuShell.isReady()) return false
        runCatching { ShizukuShell.run("pm grant ${c.packageName} $WSS") { } }
        return canWrite(c)
    }

    fun isLocationOn(c: Context): Boolean = Settings.Secure.getInt(c.contentResolver, "location_mode", 0) != 0

    fun isWifiOn(c: Context): Boolean {
        val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return wm.isWifiEnabled
    }

    private fun setLocation(c: Context, on: Boolean): Boolean {
        val v = if (on) 3 else 0
        if (canWrite(c)) {
            val ok = runCatching { Settings.Secure.putInt(c.contentResolver, "location_mode", v) }.getOrDefault(false)
            if (ok) return true
        }
        if (ShizukuShell.isReady()) {
            runCatching { ShizukuShell.run("settings put secure location_mode $v") { } }
            return isLocationOn(c) == on
        }
        return false
    }

    fun locationOn(c: Context): Int {
        if (isLocationOn(c)) return 0
        return if (setLocation(c, true)) 1 else -1
    }

    fun locationOff(c: Context) {
        setLocation(c, false)
    }

    @Suppress("DEPRECATION")
    private fun setWifi(c: Context, on: Boolean): Boolean {
        if (ShizukuShell.isReady()) {
            runCatching { ShizukuShell.run("svc wifi " + if (on) "enable" else "disable") { } }
            return true
        }
        if (Build.VERSION.SDK_INT < 29) {
            val wm = c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            return runCatching { wm.setWifiEnabled(on) }.getOrDefault(false)
        }
        return false
    }

    fun wifiOn(c: Context): Int {
        if (isWifiOn(c)) return 0
        return if (setWifi(c, true)) 1 else -1
    }

    fun wifiOff(c: Context) {
        setWifi(c, false)
    }

    fun waitFor(ms: Long, cond: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (cond()) return true
            try { Thread.sleep(300) } catch (e: InterruptedException) { return cond() }
        }
        return cond()
    }
}
