package com.newagedevs.gesturevolume.ui.screens.handler_action

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.newagedevs.gesturevolume.utils.VolumeBoost

/**
 * "What the boost is for": every sound (as before), or only the chosen streams, and on which output.
 * Shown under the Volume boost switch. Saved straight away and applied to a boost that is already on.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun BoostScopeSettings() {
    val ctx = LocalContext.current
    var streams by remember { mutableStateOf(VolumeBoost.savedStreams(ctx)) } // null = everything
    var route by remember { mutableStateOf(VolumeBoost.savedRoute(ctx)) }

    fun save(s: Set<Int>?, r: String) {
        streams = s; route = r
        VolumeBoost.saveScope(ctx, s, r)
    }

    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Boost applies to", style = MaterialTheme.typography.titleSmall)
        Text(
            "Android boosts the whole sound output, not one stream. So \"only media\" works by switching the boost on only while the chosen sound is playing, " +
                "and off again during anything else that is loud (a call, a ring, an alarm).",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = streams == null, onClick = { save(null, route) }, label = { Text("Everything") })
            for ((id, name, _) in VolumeBoost.STREAM_CHOICES) {
                FilterChip(
                    selected = streams?.contains(id) == true,
                    onClick = {
                        val cur = streams ?: emptySet()
                        val next = if (id in cur) cur - id else cur + id
                        // Un-ticking the last one goes back to everything rather than to a boost that never fires.
                        save(next.ifEmpty { null }, route)
                    },
                    label = { Text(name) },
                )
            }
        }
        val hints = VolumeBoost.STREAM_CHOICES.filter { streams?.contains(it.first) == true && it.first != VolumeBoost.S_MUSIC }
        for ((_, name, hint) in hints) {
            Text("$name: $hint", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Text("On which output", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 4.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((id, name) in VolumeBoost.ROUTE_CHOICES) {
                FilterChip(selected = route == id, onClick = { save(streams, id) }, label = { Text(name) })
            }
        }
        if (route == VolumeBoost.ROUTE_EARPIECE) {
            Text(
                "A normal phone call goes from the modem straight to the earpiece, past Android's mixer, so no app can boost it. The earpiece boost works for app calls and anything else played into the earpiece.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
