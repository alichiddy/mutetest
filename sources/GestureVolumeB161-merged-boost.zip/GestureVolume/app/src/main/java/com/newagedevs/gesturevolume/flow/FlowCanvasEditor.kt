@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.newagedevs.gesturevolume.flow

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlin.math.abs

/** Where a new block goes, and the dot it was dragged from (fromId 0 = none). */
private class AddCtx(val wx: Float, val wy: Float, val fromId: Int = 0, val slot: Int = 0)

private class CatalogEntry(val label: String, val make: () -> Step)

private fun catalog(): List<CatalogEntry> {
    val base = listOf(
        CatalogEntry("Show message") { Step(Step.MESSAGE) },
        CatalogEntry("Delay (wait)") { Step(Step.WAIT, "1000") },
        CatalogEntry("Decision (if yes / no)") { Step(Step.IF, "", "=", "") },
        CatalogEntry("Loop (repeat)") { Step(Step.REPEAT, "3") },
        CatalogEntry("Set variable") { Step(Step.SET) },
        CatalogEntry("Open app") { Step(Step.LAUNCH) },
        CatalogEntry("Run another script") { Step(Step.RUN) },
        CatalogEntry("Shell command") { Step(Step.SHELL) },
        CatalogEntry("Shizuku command") { Step(Step.SHIZUKU) },
        CatalogEntry("HTTP request") { Step(Step.HTTP, "", "GET") },
        CatalogEntry("Send intent") { Step(Step.INTENT) },
        CatalogEntry("Send broadcast") { Step(Step.BROADCAST) },
        CatalogEntry("Note") { Step(Step.NOTE) },
        CatalogEntry("Stop") { Step(Step.STOP) },
    )
    val actions = NativeActions.all.filter { !it.id.startsWith("A:") }
        .map { d -> CatalogEntry("Device: " + d.label) { Step(Step.ACTION, d.id) } }
    return base + actions
}

private val STATES = listOf(
    "Wi-Fi" to "wifi", "Bluetooth" to "bluetooth", "Airplane mode" to "airplane", "Location" to "location",
    "Mobile data" to "mobiledata", "Screen" to "screenon", "Charging" to "charging", "NFC" to "nfc",
    "Hotspot" to "hotspot", "Torch" to "torch", "Data saver" to "datasaver", "Phone locked" to "locked",
    "Music playing" to "musicplaying",
)

private val OPS = listOf(
    "is equal to" to "=", "is not equal to" to "!=", "contains" to "contains", "does not contain" to "!contains",
    "is greater than" to ">", "is less than" to "<", "is at least" to ">=", "is at most" to "<=",
)

/** The canvas editor: replaces the old card list. Nothing stays in memory once it is closed. */
@Composable
fun CanvasEditor(activity: ComponentActivity, name: String, close: () -> Unit) {
    val model = remember { GraphModel(FlowStore.loadGraph(activity, name)) }
    var version by remember { mutableStateOf(0) }
    val viewRef = remember { arrayOfNulls<FlowCanvasView>(1) }
    var running by remember { mutableStateOf(false) }
    var output by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf(0) }
    var menuId by remember { mutableStateOf(0) }
    var addAt by remember { mutableStateOf<AddCtx?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun save() { FlowStore.save(activity, name, model.blocks); version++ }

    fun runFrom(startAt: Int) {
        if (running) return
        save()
        running = true
        output = ""
        viewRef[0]?.clearRun()
        Thread {
            try {
                FlowRunner.run(
                    activity, name, { l -> output += l + "\n" }, { },
                    trace = { id, st, msg -> viewRef[0]?.setState(id, st, msg) },
                    startAt = startAt,
                )
            } finally {
                running = false
            }
        }.start()
    }

    fun addBlock(ctx: AddCtx, step: Step) {
        model.checkpoint()
        var x = ctx.wx
        var y = ctx.wy
        var guard = 0
        while (guard++ < 40 && model.blocks.any { abs(it.x - x) < 20f && abs(it.y - y) < 20f }) { x += 28f; y += 28f }
        val id = model.add(step, x, y)
        if (ctx.fromId != 0) model.connect(ctx.fromId, ctx.slot, id)
        save()
        viewRef[0]?.invalidate()
        if (step.type != Step.STOP) editId = id
    }

    BackHandler { save(); close() }

    val v = version   // read so the buttons below follow undo / redo
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(name, fontSize = 16.sp, modifier = Modifier.padding(end = 4.dp, top = 10.dp))
            Button(onClick = {
                val vw = viewRef[0]
                val cx = (vw?.centerWorldX() ?: 0f) - BlockStyle.W / 2f
                val cy = (vw?.centerWorldY() ?: 0f) - BlockStyle.H / 2f
                addAt = AddCtx(cx, cy)
            }) { Text("+ Block") }
            Button(enabled = !running, onClick = { runFrom(0) }) { Text("Run") }
            OutlinedButton(onClick = { FlowRunner.stop() }) { Text("Stop") }
            OutlinedButton(enabled = v >= 0 && model.canUndo, onClick = { if (model.undo()) { save(); viewRef[0]?.invalidate() } }) { Text("Undo") }
            OutlinedButton(enabled = v >= 0 && model.canRedo, onClick = { if (model.redo()) { save(); viewRef[0]?.invalidate() } }) { Text("Redo") }
            OutlinedButton(onClick = { viewRef[0]?.fit() }) { Text("Fit") }
            OutlinedButton(onClick = { save(); close() }) { Text("Save & close") }
            OutlinedButton(onClick = { confirmDelete = true }) { Text("Delete flow") }
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx ->
                FlowCanvasView(ctx, model).also { cv ->
                    cv.listener = object : FlowCanvasView.Listener {
                        override fun onTap(id: Int) { if (model.get(id)?.type != Step.BEGIN) editId = id }
                        override fun onLongPress(id: Int) { menuId = id }
                        override fun onBackgroundLongPress(wx: Float, wy: Float) { addAt = AddCtx(wx - BlockStyle.W / 2f, wy - BlockStyle.H / 2f) }
                        override fun onDropEmpty(fromId: Int, slot: Int, wx: Float, wy: Float) {
                            addAt = AddCtx(wx - BlockStyle.W / 2f, wy, fromId, slot)
                        }
                        override fun onChanged() { save() }
                    }
                    viewRef[0] = cv
                }
            },
        )
        val missing = remember(version) { PrivateValues.missing(activity, model.blocks) }
        if (missing.isNotEmpty()) Text(
            "These {blanks} still need a value: " + missing.joinToString(", "),
            fontSize = 12.sp, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 8.dp),
        )
        if (output.isNotEmpty()) Text(
            output.takeLast(600), fontFamily = FontFamily.Monospace, fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }

    // ---- add a block (search) ----
    val add = addAt
    if (add != null) {
        var q by remember(add) { mutableStateOf("") }
        val all = remember { catalog() }
        val shown = all.filter { q.isBlank() || it.label.contains(q.trim(), true) }
        AlertDialog(
            onDismissRequest = { addAt = null },
            title = { Text("Add a block") },
            text = {
                Column {
                    OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search blocks") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        if (GraphModel.clip != null && q.isBlank()) item {
                            Text(
                                "Paste the copied block", Modifier.fillMaxWidth().clickable {
                                    GraphModel.clip?.let { addBlock(add, it) }
                                    addAt = null
                                }.padding(vertical = 10.dp), fontSize = 14.sp, color = MaterialTheme.colorScheme.primary,
                            )
                        }
                        items(shown) { e ->
                            Text(
                                e.label, Modifier.fillMaxWidth().clickable { addAt = null; addBlock(add, e.make()) }.padding(vertical = 10.dp),
                                fontSize = 14.sp,
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { addAt = null }) { Text("Cancel") } },
        )
    }

    // ---- long-press menu ----
    val mid = menuId
    val ms = if (mid != 0) model.get(mid) else null
    if (ms != null) {
        AlertDialog(
            onDismissRequest = { menuId = 0 },
            title = { Text(BlockStyle.title(ms)) },
            text = {
                Column {
                    if (ms.type != Step.BEGIN) MenuItem("Edit") { menuId = 0; editId = mid }
                    MenuItem(if (ms.type == Step.BEGIN) "Run from the start" else "Start here (run from this block)") {
                        menuId = 0; runFrom(if (ms.type == Step.BEGIN) 0 else mid)
                    }
                    if (ms.type != Step.BEGIN) {
                        MenuItem("Copy") { menuId = 0; GraphModel.clip = ms }
                        MenuItem("Duplicate") { menuId = 0; model.checkpoint(); model.duplicate(mid); save(); viewRef[0]?.invalidate() }
                    }
                    if (ms.n != 0) MenuItem("Disconnect the bottom output") { menuId = 0; model.checkpoint(); model.disconnect(mid, 0); save(); viewRef[0]?.invalidate() }
                    if (ms.r != 0) MenuItem("Disconnect the side output") { menuId = 0; model.checkpoint(); model.disconnect(mid, 1); save(); viewRef[0]?.invalidate() }
                    if (ms.type != Step.BEGIN) MenuItem("Delete") { menuId = 0; model.checkpoint(); model.delete(mid); save(); viewRef[0]?.invalidate() }
                }
            },
            confirmButton = { TextButton(onClick = { menuId = 0 }) { Text("Close") } },
        )
    }

    // ---- block options ----
    val eid = editId
    val es = if (eid != 0) model.get(eid) else null
    if (es != null) {
        BlockForm(activity, es, onSave = { s ->
            model.checkpoint(); model.update(s.copy(id = eid)); save(); viewRef[0]?.invalidate(); editId = 0
        }, onCancel = { editId = 0 })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this flow?") },
            text = { Text(name) },
            confirmButton = { TextButton(onClick = { FlowStore.delete(activity, name); confirmDelete = false; close() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    Text(label, Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 10.dp), fontSize = 15.sp)
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun Pick(options: List<Pair<String, String>>, value: String, onPick: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (label, v) ->
            if (v == value) Button(onClick = {}) { Text(label, fontSize = 12.sp) }
            else OutlinedButton(onClick = { onPick(v) }) { Text(label, fontSize = 12.sp) }
        }
    }
}

/** The options of one block, in plain words: lists to pick from, no formulas to type. */
@Composable
private fun BlockForm(activity: ComponentActivity, s: Step, onSave: (Step) -> Unit, onCancel: () -> Unit) {
    var a by remember(s.id) { mutableStateOf(s.a) }
    var b by remember(s.id) { mutableStateOf(s.b) }
    var c by remember(s.id) { mutableStateOf(s.c) }
    // Decision: compare two values, or ask about the phone's state. Anything else (from an import) stays as a formula.
    val stateNow = s.b == "expr" && (s.a.startsWith("is(\"") || s.a.startsWith("!is(\""))
    var kind by remember(s.id) { mutableStateOf(if (s.type != Step.IF) "" else if (stateNow) "state" else if (s.b == "expr") "formula" else "cmp") }
    var stateKey by remember(s.id) { mutableStateOf(if (stateNow) s.a.substringAfter("is(\"").substringBefore("\")") else "wifi") }
    var stateOn by remember(s.id) { mutableStateOf(!s.a.startsWith("!")) }
    var op by remember(s.id) { mutableStateOf(if (s.b == "expr" || s.b.isEmpty()) "=" else s.b) }
    var choosing by remember(s.id) { mutableStateOf(false) }

    if (choosing) {
        val names = remember { FlowStore.names(activity) }
        AlertDialog(
            onDismissRequest = { choosing = false },
            title = { Text("Choose a script") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(names) { n -> Text(n, Modifier.fillMaxWidth().clickable { a = n; choosing = false }.padding(vertical = 10.dp), fontSize = 14.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { choosing = false }) { Text("Close") } },
        )
    }

    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(BlockStyle.title(s)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (s.type) {
                    Step.SHELL -> {
                        Field("Command", a) { a = it }
                        Field("Save the output in variable (empty = out)", b) { b = it }
                    }
                    Step.SHIZUKU -> {
                        Field("Command (runs with Shizuku)", a) { a = it }
                        Field("Save the output in variable (empty = out)", b) { b = it }
                        Pick(listOf("Fail without Shizuku" to "", "Skip quietly without Shizuku" to "optional"), c) { c = it }
                    }
                    Step.WAIT -> {
                        if (c == "expr") Field("Milliseconds (formula from an import)", a) { a = it }
                        else Field("Wait how many milliseconds (1000 = 1 second)", a) { a = it }
                    }
                    Step.MESSAGE -> {
                        Field("Text (you can use {variables})", a) { a = it }
                        Text("Show it as", fontSize = 12.sp)
                        Pick(listOf("Bar" to "", "Toast" to "toast", "Window" to "window"), c) { c = it }
                    }
                    Step.LAUNCH -> Field("App package name", a) { a = it }
                    Step.INTENT -> Field("Intent", a) { a = it }
                    Step.SET -> {
                        Field("Variable name", a) { a = it }
                        Field(if (c == "expr") "Value (formula from an import)" else "Value (you can use {variables})", b) { b = it }
                    }
                    Step.IF -> {
                        Pick(listOf("Compare two values" to "cmp", "Phone state" to "state") + (if (kind == "formula") listOf("Imported formula" to "formula") else emptyList()), kind) { kind = it }
                        when (kind) {
                            "cmp" -> {
                                Field("Value (or {variable})", a) { a = it }
                                Pick(OPS, op) { op = it }
                                Field("Compared with", c) { c = it }
                            }
                            "state" -> {
                                Pick(STATES, stateKey) { stateKey = it }
                                Pick(listOf("is on" to "on", "is off" to "off"), if (stateOn) "on" else "off") { stateOn = it == "on" }
                            }
                            else -> Field("Condition (from an import)", a) { a = it }
                        }
                        Text("Bottom dot = yes, side dot = no.", fontSize = 12.sp)
                    }
                    Step.REPEAT -> {
                        if (b == "each") {
                            Field("List (from an import)", a) { a = it }
                            Field("Variable for each item", c) { c = it }
                        } else Field("How many times", a) { a = it }
                        Text("Side dot = what to repeat, bottom dot = when finished.", fontSize = 12.sp)
                    }
                    Step.HTTP -> {
                        Field("Web address", a) { a = it }
                        Pick(listOf("GET" to "GET", "POST" to "POST"), b.ifEmpty { "GET" }) { b = it }
                        Field("Save the answer in variable (empty = answer)", c) { c = it }
                    }
                    Step.RUN -> {
                        OutlinedButton(onClick = { choosing = true }) { Text(if (a.isEmpty()) "Choose a script…" else a) }
                        Pick(listOf("Wait for it" to "", "At the same time" to "async", "Hand over (no return)" to "goto"), b) { b = it }
                    }
                    Step.NOTE -> Field("Note", a) { a = it }
                    Step.ACTION -> {
                        OutlinedButton(onClick = {
                            NativePicker.pick(activity) { act, _ ->
                                val body = act.removePrefix(NativePicker.PREFIX)
                                a = body.substringBefore('|'); b = body.substringAfter('|', "")
                            }
                        }) { Text(NativeActions.find(a)?.label ?: "Choose an action…") }
                        NativeActions.find(a)?.help?.takeIf { it.isNotEmpty() }?.let { Text(it, fontSize = 12.sp) }
                        Field("Argument (if the action takes one)", b) { b = it }
                        Pick(listOf("Fail without Shizuku" to "", "Skip quietly without Shizuku" to "optional"), c) { c = it }
                    }
                    Step.BROADCAST -> {
                        Field("Package or package/.Receiver", a) { a = it }
                        Field("Action", b) { b = it }
                        Field("Extras: key=value;key=value", c) { c = it }
                    }
                    Step.STOP -> Text("Stops the whole flow here.")
                    else -> Text(s.describe())
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val out = if (s.type == Step.IF) when (kind) {
                    "cmp" -> s.copy(a = a, b = op, c = c)
                    "state" -> s.copy(a = (if (stateOn) "" else "!") + "is(\"" + stateKey + "\")", b = "expr", c = "")
                    else -> s.copy(a = a, b = "expr", c = "")
                } else s.copy(a = a, b = b, c = c)
                onSave(out)
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}
