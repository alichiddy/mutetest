package com.newagedevs.gesturevolume.flow

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The flow list and the step editor. Nothing from here stays in memory once it is closed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class FlowActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var names by remember { mutableStateOf(FlowStore.names(this)) }
                    var open by remember { mutableStateOf<String?>(intent.getStringExtra("flow")?.takeIf { it in names }) }
                    var newName by remember { mutableStateOf(false) }
                    var info by remember { mutableStateOf("") }
                    var values by remember { mutableStateOf(false) }
                    var autos by remember { mutableStateOf(false) }
                    // "Add a shortcut": 0 closed, 1 menu, 2 open an app with Hail, 3 app shortcuts / Shortcut Maker.
                    var addSc by remember { mutableStateOf(0) }
                    val scCreator = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
                    ) { result ->
                        val data = result.data
                        @Suppress("DEPRECATION")
                        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
                        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
                            val nm = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME) ?: "Shortcut"
                            com.newagedevs.gesturevolume.strip.ActionSaver.saveToScripts(this@FlowActivity, nm, "Intent:" + picked.toUri(android.content.Intent.URI_INTENT_SCHEME))
                            names = FlowStore.names(this@FlowActivity); info = "Saved script: $nm"; addSc = 0
                        }
                    }
                    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            info = "Importing…"
                            Thread {
                                info = try {
                                    val n = AutomateImporter.import(this@FlowActivity, uri)
                                    names = FlowStore.names(this@FlowActivity)
                                    "Imported $n flows. Texts that are not commands are kept as Notes."
                                } catch (e: Throwable) { "Import failed: ${e.message}" }
                            }.start()
                        }
                    }
                    if (autos) {
                        com.newagedevs.gesturevolume.auto.AutomationsScreen { autos = false }
                    } else if (values) {
                        ValuesScreen { values = false }
                    } else if (open == null) {
                        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Flows (${names.size})", fontSize = 20.sp)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { newName = true }) { Text("New flow") }
                                Button(onClick = { addSc = 1 }) { Text("Add a shortcut") }
                                OutlinedButton(onClick = {
                                    val next = (FlowPrefs.mode(this@FlowActivity) + 1) % 3
                                    FlowPrefs.setMode(this@FlowActivity, next)
                                    info = "Message bar after a cell: " + FlowPrefs.modeName(next)
                                }) { Text("Message bar: " + FlowPrefs.modeName(FlowPrefs.mode(this@FlowActivity))) }
                                OutlinedButton(onClick = {
                                    info = "Adding…"
                                    Thread {
                                        info = try {
                                            val n = AutomateFlows.install(this@FlowActivity)
                                            names = FlowStore.names(this@FlowActivity)
                                            "Added $n converted Automate flows (named Automate: …). Numbers and codes are left as {blanks} in the steps."
                                        } catch (e: Throwable) { "Could not add: ${e.message}" }
                                    }.start()
                                }) { Text("Add my Automate flows") }
                                OutlinedButton(onClick = { autos = true }) { Text("Automations") }
                                OutlinedButton(onClick = {
                                    runCatching { startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                                }) { Text("Allow usage access") }
                                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import Automate backup") }
                            }
                            if (info.isNotEmpty()) Text(info, fontSize = 12.sp)
                            var query by remember { mutableStateOf("") }
                            var showParts by remember { mutableStateOf(false) }
                            OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search flows") }, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(onClick = { showParts = !showParts }) { Text(if (showParts) "Hiding nothing" else "Parts of flows are hidden - show") }
                            val shown = names.filter { (showParts || !AutomateFlows.isPart(it)) && (query.isBlank() || it.contains(query, true)) }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemsIndexed(shown) { _, n ->
                                    Text(n, Modifier.fillMaxWidth().clickable { open = n }.padding(vertical = 10.dp))
                                }
                            }
                        }
                        if (addSc != 0) androidx.compose.ui.window.Dialog(
                            onDismissRequest = { addSc = if (addSc == 1) 0 else 1 },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                        ) {
                            Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                                fun saveSc(name: String, action: String) {
                                    com.newagedevs.gesturevolume.strip.ActionSaver.saveToScripts(this@FlowActivity, name, action)
                                    names = FlowStore.names(this@FlowActivity); info = "Saved script: $name"; addSc = 0
                                }
                                when (addSc) {
                                    2 -> com.newagedevs.gesturevolume.ui.screens.strip.AppList(
                                        onPick = { app -> saveSc(com.newagedevs.gesturevolume.ui.screens.strip.plainAppLabel(app.label), com.newagedevs.gesturevolume.strip.ActionSaver.hailAction(app.packageName)) },
                                        onBack = { addSc = 1 },
                                        everything = true,
                                    )
                                    3 -> com.newagedevs.gesturevolume.ui.screens.strip.AppShortcutsPage(
                                        onCreator = { cr ->
                                            runCatching {
                                                scCreator.launch(
                                                    android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT).setClassName(cr.packageName, cr.className)
                                                )
                                            }
                                        },
                                        onShortcut = { sc -> saveSc(sc.label, "Intent:" + sc.intentUri) },
                                        onBack = { addSc = 1 },
                                    )
                                    else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Add a shortcut as a script", fontSize = 18.sp)
                                        Button(onClick = { addSc = 2 }) { Text("Open an app with Hail (any app, even hidden)") }
                                        Button(onClick = { addSc = 3 }) { Text("App shortcuts and Shortcut Maker") }
                                        TextButton(onClick = { addSc = 0 }) { Text("Cancel") }
                                    }
                                }
                            }
                        }
                        if (newName) {
                            var t by remember { mutableStateOf("") }
                            AlertDialog(
                                onDismissRequest = { newName = false },
                                title = { Text("Flow name") },
                                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                                confirmButton = { TextButton(onClick = {
                                    if (t.isNotBlank()) { FlowStore.save(this, t.trim(), emptyList()); names = FlowStore.names(this); open = t.trim() }
                                    newName = false
                                }) { Text("OK") } },
                            )
                        }
                    } else {
                        CanvasEditor(this, open!!) { names = FlowStore.names(this); open = null }
                    }
                }
            }
        }
    }

    @Composable
    private fun ValuesScreen(close: () -> Unit) {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("My values", fontSize = 20.sp)
            Text(
                "Keys, codes and names that flows use as {name}. They stay only on this phone: they are not in the settings backup and not in copies of the app.",
                fontSize = 12.sp,
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(PrivateValues.allSlots(this@FlowActivity)) { _, slot ->
                    var v by remember { mutableStateOf(PrivateValues.get(this@FlowActivity, slot.name)) }
                    OutlinedTextField(
                        v, { v = it; PrivateValues.set(this@FlowActivity, slot.name, it) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(slot.label + "   {" + slot.name + "}") },
                        supportingText = { if (slot.hint.isNotEmpty()) Text(slot.hint) },
                    )
                }
            }
            Button(onClick = close) { Text("Done") }
        }
    }
}
