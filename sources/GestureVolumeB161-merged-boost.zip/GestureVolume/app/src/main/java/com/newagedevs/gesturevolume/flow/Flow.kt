package com.newagedevs.gesturevolume.flow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Where flows live: one text value, so the settings backup carries them too. */
object FlowStore {
    private const val KEY = "flowsV1"

    private fun prefs(context: Context) = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    private fun all(context: Context): JSONObject =
        runCatching { JSONObject(prefs(context).getString(KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())

    fun names(context: Context): List<String> = all(context).keys().asSequence().sorted().toList()

    fun load(context: Context, name: String): List<Step> {
        val arr = all(context).optJSONArray(name) ?: return emptyList()
        return (0 until arr.length()).map { Step.fromJson(arr.getJSONObject(it)) }
    }

    /** The flow as canvas blocks: a flat (old) flow is converted, an empty one gets just its Start block. */
    fun loadGraph(context: Context, name: String): List<Step> = FlowGraph.normalize(load(context, name))

    fun save(context: Context, name: String, steps: List<Step>) {
        val o = all(context)
        o.put(name, JSONArray().apply { steps.forEach { put(it.toJson()) } })
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }

    fun saveAll(context: Context, flows: Map<String, List<Step>>) {
        val o = all(context)
        flows.forEach { (name, steps) -> o.put(name, JSONArray().apply { steps.forEach { put(it.toJson()) } }) }
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }

    fun delete(context: Context, name: String) {
        val o = all(context)
        o.remove(name)
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }
}
