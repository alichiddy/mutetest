package com.newagedevs.gesturevolume.flow

/**
 * The canvas model and its interpreter. No Android in here, so it can be tested on its own.
 * Every block has an input (top), a bottom output [Step.n] and a right output [Step.r].
 * Plain blocks: bottom = what comes next, right = a second thing that runs at the same time.
 * Decision: bottom = yes, right = no. Loop: bottom = when done, right = each time round.
 */
object FlowGraph {
    const val COL = 220f
    const val ROW = 110f

    fun isGraph(steps: List<Step>) = steps.any { it.id > 0 }

    /** Blocks that choose between their two outputs instead of running both. */
    fun branches(s: Step) = s.type == Step.IF || s.type == Step.REPEAT

    /** Blocks that have no outputs at all. */
    fun endsFlow(s: Step) = s.type == Step.STOP

    fun normalize(steps: List<Step>): List<Step> {
        if (steps.isEmpty()) return listOf(Step(Step.BEGIN, id = 1, x = 0f, y = 0f))
        if (!isGraph(steps)) return fromFlat(steps)
        if (steps.any { it.type == Step.BEGIN }) return steps
        // A canvas flow without a Start block: add one above the block nothing leads into.
        val targets = steps.flatMap { listOf(it.n, it.r) }.toSet()
        val first = steps.firstOrNull { it.id !in targets } ?: steps.first()
        val id = (steps.maxOf { it.id }) + 1
        return steps + Step(Step.BEGIN, n = first.id, id = id, x = first.x, y = first.y - ROW)
    }

    private class Exit(val id: Int, val slot: Int)
    private class Seq(val entry: Int, val exits: List<Exit>, val endY: Float)

    private class Builder(val steps: List<Step>) {
        val out = LinkedHashMap<Int, Step>()
        var pos = 0
        var next = 1

        fun link(e: Exit, to: Int) {
            val s = out[e.id] ?: return
            out[e.id] = if (e.slot == 0) s.copy(n = to) else s.copy(r = to)
        }

        fun seq(x: Float, y0: Float): Seq {
            var y = y0
            var entry = 0
            var exits: List<Exit> = emptyList()
            while (pos < steps.size && steps[pos].type != Step.ELSE && steps[pos].type != Step.END) {
                val s = steps[pos++]
                val id = next++
                out[id] = s.copy(id = id, n = 0, r = 0, x = x, y = y)
                if (entry == 0) entry = id else exits.forEach { link(it, id) }
                y += ROW
                when (s.type) {
                    Step.IF -> {
                        val yes = seq(x, y)
                        var no: Seq? = null
                        if (pos < steps.size && steps[pos].type == Step.ELSE) { pos++; no = seq(x + COL, y) }
                        if (pos < steps.size && steps[pos].type == Step.END) pos++
                        val ex = ArrayList<Exit>()
                        if (yes.entry != 0) { link(Exit(id, 0), yes.entry); ex += yes.exits } else ex += Exit(id, 0)
                        if (no != null && no.entry != 0) { link(Exit(id, 1), no.entry); ex += no.exits } else ex += Exit(id, 1)
                        exits = ex
                        y = maxOf(yes.endY, no?.endY ?: y)
                    }
                    Step.REPEAT -> {
                        val body = seq(x + COL, y)
                        if (pos < steps.size && steps[pos].type == Step.END) pos++
                        if (body.entry != 0) {
                            link(Exit(id, 1), body.entry)
                            body.exits.forEach { link(it, id) }   // the end of the body goes round again
                        }
                        exits = listOf(Exit(id, 0))
                        y = maxOf(y, body.endY)
                    }
                    Step.STOP -> exits = emptyList()
                    else -> exits = listOf(Exit(id, 0))
                }
            }
            return Seq(entry, exits, y)
        }
    }

    /** Old flat flow (if / else / end) to blocks laid out top to bottom, branches to the right. */
    fun fromFlat(steps: List<Step>): List<Step> {
        val b = Builder(steps)
        val begin = b.next++
        b.out[begin] = Step(Step.BEGIN, id = begin, x = 0f, y = 0f)
        var exits: List<Exit> = listOf(Exit(begin, 0))
        var y = ROW
        while (b.pos < steps.size) {
            val sq = b.seq(0f, y)
            if (sq.entry != 0) { exits.forEach { b.link(it, sq.entry) }; exits = sq.exits; y = sq.endY }
            if (b.pos < steps.size) b.pos++   // a stray else / end
        }
        return b.out.values.toList()
    }
}

/** The blocks being edited, with undo / redo. Positions are in world units (about 1 dp). */
class GraphModel(initial: List<Step>) {
    private var list = ArrayList<Step>(initial)
    private val undoStack = ArrayList<List<Step>>()
    private val redoStack = ArrayList<List<Step>>()

    val blocks: List<Step> get() = list
    fun get(id: Int): Step? = list.firstOrNull { it.id == id }
    fun beginId(): Int = list.firstOrNull { it.type == Step.BEGIN }?.id ?: 0
    private fun nextId() = (list.maxOfOrNull { it.id } ?: 0) + 1
    private fun put(s: Step) { val i = list.indexOfFirst { it.id == s.id }; if (i >= 0) list[i] = s }

    /** Call before a change you want to be able to undo. */
    fun checkpoint() {
        undoStack.add(ArrayList(list))
        if (undoStack.size > 80) undoStack.removeAt(0)
        redoStack.clear()
    }

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun undo(): Boolean {
        if (undoStack.isEmpty()) return false
        redoStack.add(ArrayList(list))
        list = ArrayList(undoStack.removeAt(undoStack.size - 1))
        return true
    }

    fun redo(): Boolean {
        if (redoStack.isEmpty()) return false
        undoStack.add(ArrayList(list))
        list = ArrayList(redoStack.removeAt(redoStack.size - 1))
        return true
    }

    fun move(id: Int, x: Float, y: Float) { get(id)?.let { put(it.copy(x = x, y = y)) } }

    fun add(s: Step, x: Float, y: Float): Int {
        val id = nextId()
        list.add(s.copy(id = id, n = 0, r = 0, x = x, y = y))
        return id
    }

    /** Removes a block. Blocks that led into it are joined to what it led to (not for decisions and loops). */
    fun delete(id: Int) {
        val gone = get(id) ?: return
        if (gone.type == Step.BEGIN) return
        val heal = if (FlowGraph.branches(gone)) 0 else gone.n
        list.removeAll { it.id == id }
        for (i in list.indices) {
            var t = list[i]
            if (t.n == id) t = t.copy(n = heal)
            if (t.r == id) t = t.copy(r = heal)
            list[i] = t
        }
    }

    fun connect(from: Int, slot: Int, to: Int): Boolean {
        if (from == to) return false
        val s = get(from) ?: return false
        val t = get(to) ?: return false
        if (t.type == Step.BEGIN || FlowGraph.endsFlow(s)) return false
        if (slot == 1 && s.type == Step.BEGIN) return false
        put(if (slot == 0) s.copy(n = to) else s.copy(r = to))
        return true
    }

    fun disconnect(from: Int, slot: Int) {
        val s = get(from) ?: return
        put(if (slot == 0) s.copy(n = 0) else s.copy(r = 0))
    }

    /** Changes what a block does; its place and its links stay. */
    fun update(s: Step) {
        val old = get(s.id) ?: return
        put(s.copy(id = old.id, n = old.n, r = old.r, x = old.x, y = old.y))
    }

    fun duplicate(id: Int): Int {
        val s = get(id) ?: return 0
        if (s.type == Step.BEGIN) return 0
        return add(s, s.x + 24f, s.y + 24f)
    }

    fun replaceAll(steps: List<Step>) { list = ArrayList(steps) }

    companion object {
        /** The block copied in the editor; kept for the process so it can be pasted into another flow. */
        var clip: Step? = null
    }
}

/** What the interpreter needs from the outside. The phone version is in FlowRunner; tests use a fake. */
interface FlowEnv {
    fun stopped(): Boolean
    /** Runs an ordinary block. Throw to fail it. [last] is true when nothing follows it. */
    fun exec(s: Step, vars: MutableMap<String, String>, last: Boolean)
    fun decide(s: Step, vars: MutableMap<String, String>): Boolean
    fun items(s: Step, vars: MutableMap<String, String>): List<String>?
    fun count(s: Step, vars: MutableMap<String, String>): Int
    fun gotoTarget(s: Step, vars: MutableMap<String, String>): String
    fun trace(id: Int, state: Int, msg: String)
    fun log(text: String)
    fun failed(s: Step, e: Throwable)
}

class Interpreter(blocks: List<Step>, private val env: FlowEnv, private val vars: MutableMap<String, String>) {
    companion object {
        const val RUNNING = 1
        const val OK = 2
        const val FAILED = 3
    }

    private val by: Map<Int, Step> = blocks.associateBy { it.id }
    private val start0: Int = blocks.firstOrNull { it.type == Step.BEGIN }?.id ?: blocks.firstOrNull()?.id ?: 0
    private val forks = ArrayList<Thread>()
    @Volatile private var halted = false
    @Volatile private var goto: String? = null

    /** Runs from [startAt] (or the Start block). Returns the name of a script to hand over to, if any. */
    fun run(startAt: Int = 0): String? {
        walk(if (startAt > 0 && by.containsKey(startAt)) startAt else start0)
        while (true) {
            val t = synchronized(forks) { forks.removeFirstOrNull() } ?: break
            t.join()
        }
        return goto
    }

    private fun walk(start: Int) {
        var cur = start
        var guard = 0
        val counters = HashMap<Int, Int>()
        val lists = HashMap<Int, List<String>>()
        while (cur != 0 && !halted && !env.stopped()) {
            if (++guard > 100_000) { env.log("Stopped: too many steps."); halted = true; return }
            val s = by[cur] ?: return
            val id = cur
            env.trace(id, RUNNING, "")
            try {
                when (s.type) {
                    Step.BEGIN, Step.NOTE -> cur = s.n
                    Step.IF -> cur = if (env.decide(s, vars)) s.n else s.r
                    Step.REPEAT -> {
                        if (s.b == "each") {
                            val list = lists.getOrPut(id) { env.items(s, vars) ?: emptyList() }
                            val k = counters.getOrPut(id) { 0 }
                            if (k >= list.size) { counters.remove(id); lists.remove(id); cur = s.n }
                            else {
                                vars[s.c.ifEmpty { "item" }] = list[k]
                                vars["index"] = (k + 1).toString()
                                counters[id] = k + 1
                                cur = if (s.r != 0) s.r else id
                            }
                        } else {
                            val n = counters.getOrPut(id) { env.count(s, vars) }
                            if (n <= 0) { counters.remove(id); cur = s.n }
                            else { counters[id] = n - 1; cur = if (s.r != 0) s.r else id }
                        }
                    }
                    Step.STOP -> { halted = true }
                    else -> {
                        if (s.type == Step.RUN && s.b == "goto") {
                            goto = env.gotoTarget(s, vars)
                            halted = true
                        } else {
                            env.exec(s, vars, s.n == 0 && s.r == 0)
                            cur = s.n
                            if (s.r != 0) {
                                val right = s.r
                                val t = Thread { walk(right) }
                                synchronized(forks) { forks.add(t) }
                                t.start()
                            }
                        }
                    }
                }
                env.trace(id, OK, "")
            } catch (e: Throwable) {
                env.trace(id, FAILED, e.message ?: e.javaClass.simpleName)
                env.failed(s, e)
                halted = true
                return
            }
        }
    }
}
