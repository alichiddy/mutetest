package com.newagedevs.gesturevolume.flow

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Runs a flow on its own thread and is gone when it ends. [log] gets one line per thing that
 * happens, [message] is where a Message step shows its text. [trace] (the canvas) hears which
 * block is running, finished or failed; [startAt] runs from a chosen block.
 */
object FlowRunner {
    @Volatile private var stopAll = false

    fun stop() { stopAll = true }

    fun run(
        context: Context, name: String, log: (String) -> Unit,
        message: (String) -> Unit = {}, vars: MutableMap<String, String> = HashMap(), depth: Int = 0,
        trace: ((Int, Int, String) -> Unit)? = null, startAt: Int = 0,
    ) {
        if (depth == 0) {
            stopAll = false
            // Personal values (keys, codes) are filled in as {name}; flow variables of the same name win.
            PrivateValues.all(context).forEach { (k, v) -> vars.putIfAbsent(k, v) }
        }
        // A "goto" Run step hands over to another flow without growing the stack (loops, joins).
        var cur = name
        var hops = 0
        while (true) {
            val next = runOnce(
                context, cur, log, message, vars, depth,
                if (hops == 0) trace else null, if (hops == 0) startAt else 0,
            ) ?: return
            if (stopAll || ++hops > 20_000) return
            cur = next
        }
    }

    private fun runOnce(
        context: Context, name: String, logFn: (String) -> Unit,
        message: (String) -> Unit, vars: MutableMap<String, String>, depth: Int,
        traceFn: ((Int, Int, String) -> Unit)?, startAt: Int,
    ): String? {
        if (depth > 8) { logFn("Too many flows inside flows."); return null }
        val graph = FlowStore.loadGraph(context, name)
        if (graph.none { it.type != Step.BEGIN }) { logFn("Flow '$name' is empty or missing."); return null }
        // Blocks that run at the same time share the variables.
        val shared = ConcurrentHashMap<String, String>(vars)
        fun sub(t: String): String {
            var r = t
            shared.forEach { (k, v) -> r = r.replace("{$k}", v) }
            return r
        }
        val env = object : FlowEnv {
            override fun stopped() = stopAll

            override fun trace(id: Int, state: Int, msg: String) {
                if (traceFn == null) return
                traceFn(id, state, msg)
                // On the canvas, give each block a moment so the highlight can be seen.
                if (state == Interpreter.RUNNING) {
                    try { Thread.sleep(220) } catch (_: InterruptedException) { }
                }
            }

            override fun log(text: String) = logFn(text)

            override fun decide(s: Step, vars: MutableMap<String, String>): Boolean =
                if (s.b == "expr") Expr.truth(evalExpr(context, s.a, vars)) else test(sub(s.a), s.b, sub(s.c))

            override fun items(s: Step, vars: MutableMap<String, String>): List<String>? =
                Expr.asList(evalExpr(context, s.a, vars))?.map { Expr.text(it) }

            override fun count(s: Step, vars: MutableMap<String, String>): Int = sub(s.a).toIntOrNull() ?: 1

            override fun gotoTarget(s: Step, vars: MutableMap<String, String>): String = sub(s.a)

            override fun failed(s: Step, e: Throwable) {
                if (e is NativeActions.NeedsShizuku) {
                    // Not an error: say what is missing and take the user to Shizuku.
                    message(e.message ?: "This needs Shizuku.")
                    log(e.message ?: "This needs Shizuku.")
                    NativeActions.openShizuku(context)
                } else {
                    val text = e.message ?: e.javaClass.simpleName
                    log("Failed (${s.describe()}): $text")
                    message(text)
                }
            }

            override fun exec(s: Step, vars: MutableMap<String, String>, last: Boolean) {
                when (s.type) {
                    Step.SHELL -> {
                        val out = StringBuilder()
                        val code = ShizukuShell.run(sub(s.a)) { line -> out.append(line).append('\n'); log(line) }
                        vars["code"] = code.toString()
                        vars[s.b.ifEmpty { "out" }] = out.toString().trim()
                    }
                    Step.WAIT -> Thread.sleep((if (s.c == "expr") Expr.num(evalExpr(context, s.a, vars)).toLong() else sub(s.a).toDoubleOrNull()?.toLong() ?: 0L).coerceAtLeast(0L))
                    Step.MESSAGE -> {
                        val text = sub(s.a)
                        log(text)
                        when (s.c) {
                            "window" -> ResultActivity.show(context, name, text)
                            "toast" -> android.os.Handler(android.os.Looper.getMainLooper()).post {
                                android.widget.Toast.makeText(context.applicationContext, text, android.widget.Toast.LENGTH_LONG).show()
                            }
                            else -> if (FlowPrefs.mode(context) != FlowPrefs.NEVER) message(text)
                        }
                    }
                    Step.LAUNCH -> context.packageManager.getLaunchIntentForPackage(sub(s.a))
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { context.startActivity(it) }
                        ?: log("App not found: ${s.a}")
                    Step.INTENT -> context.startActivity(
                        Intent.parseUri(sub(s.a), Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    Step.SET -> vars[s.a] = if (s.c == "expr") Expr.text(evalExpr(context, s.b, vars)) else sub(s.b)
                    Step.HTTP -> {
                        val c = URL(sub(s.a)).openConnection() as HttpURLConnection
                        c.requestMethod = s.b.ifEmpty { "GET" }
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        val text = (if (c.responseCode < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                        vars["status"] = c.responseCode.toString()
                        vars[s.c.ifEmpty { "answer" }] = text
                        c.disconnect()
                    }
                    Step.RUN -> if (s.b == "async") {
                        val copy = HashMap(vars); val target = sub(s.a)
                        Thread { run(context, target, logFn, message, copy, depth + 1) }.start()
                    } else run(context, sub(s.a), logFn, message, vars, depth + 1)
                    Step.ACTION -> {
                        try {
                            val result = NativeActions.run(context, s.a, sub(s.b), vars)
                            if (result.isNotBlank()) {
                                log(result)
                                if (NativeActions.staysOnScreen(s.a, result)) ResultActivity.show(context, name, result)
                                else if (FlowPrefs.mode(context) == FlowPrefs.ALWAYS && last) message(result)
                            }
                        } catch (e: NativeActions.NeedsShizuku) {
                            if (s.c != "optional") throw e
                            log("Skipped (needs Shizuku): ${s.a}")
                        }
                    }
                    Step.SHIZUKU -> {
                        if (s.c == "optional" && !ShizukuShell.isReady()) {
                            log("Skipped (needs Shizuku): ${s.a}")
                        } else {
                            val (code, out) = NativeActions.sh(sub(s.a))
                            vars["code"] = code.toString()
                            vars[s.b.ifEmpty { "out" }] = out
                            if (out.isNotBlank()) log(out.lines().last())
                        }
                    }
                    Step.BROADCAST -> {
                        val target = sub(s.a)
                        val intent = Intent(sub(s.b))
                        if (target.contains("/")) {
                            val pkg = target.substringBefore("/")
                            val cls = target.substringAfter("/").let { if (it.startsWith(".")) pkg + it else it }
                            intent.setClassName(pkg, cls)
                        } else if (target.isNotEmpty()) intent.setPackage(target)
                        sub(s.c).split(";").filter { it.contains("=") }.forEach {
                            intent.putExtra(it.substringBefore("=").trim(), it.substringAfter("=").trim())
                        }
                        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                        context.sendBroadcast(intent)
                        log("Broadcast sent to $target")
                    }
                    else -> {}
                }
            }
        }
        try {
            return Interpreter(graph, env, shared).run(startAt)
        } finally {
            vars.putAll(shared)
        }
    }

    private fun test(left: String, op: String, right: String): Boolean {
        val l = left.toDoubleOrNull(); val r = right.toDoubleOrNull()
        return when (op) {
            "=" -> if (l != null && r != null) l == r else left == right
            "!=" -> if (l != null && r != null) l != r else left != right
            "contains" -> left.contains(right)
            "!contains" -> !left.contains(right)
            ">" -> l != null && r != null && l > r
            "<" -> l != null && r != null && l < r
            ">=" -> l != null && r != null && l >= r
            "<=" -> l != null && r != null && l <= r
            else -> false
        }
    }

    /** Expression with {name} texts filled in first, plus checks such as is("wifi"). */
    private fun evalExpr(context: Context, text: String, vars: MutableMap<String, String>): Any? =
        Expr.eval(text, vars) { name, args -> NativeActions.check(context, name, args.map { Expr.text(it) }) }
}
