package com.newagedevs.gesturevolume.adb

import android.content.Context
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Something that moves ADB bytes: a USB cable today. */
interface AdbTransport {
    fun write(buf: ByteArray, len: Int)
    fun read(buf: ByteArray, off: Int, len: Int, timeoutMs: Int): Int
    fun alive(): Boolean
    fun close()
}

class AdbMessage(val cmd: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

private class AdbStream(val local: Int) {
    var remote: Int = 0
    var closed: Boolean = false
    var okays: Int = 0
    val inbox = java.util.ArrayDeque<ByteArray>()
}

/**
 * The ADB protocol, one command or one file push at a time. Talks to a phone, TV or any other
 * device that runs adbd. Call connect() first, from a background thread.
 */
class AdbConnection(private val ctx: Context, private val t: AdbTransport) {
    var banner: String = ""
        private set
    var features: String = ""
        private set

    @Volatile
    var stopped: Boolean = false

    private var maxData = 4096
    private var nextId = 1
    private var cur: AdbStream? = null

    // ------------------------------------------------------------------ messages

    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0)) {
        val b = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        var crc = 0
        for (x in data) crc += (x.toInt() and 0xFF)
        b.putInt(cmd)
        b.putInt(a0)
        b.putInt(a1)
        b.putInt(data.size)
        b.putInt(crc)
        b.putInt(cmd.inv())
        t.write(b.array(), 24)
        if (data.isNotEmpty()) t.write(data, data.size)
    }

    private fun readExact(buf: ByteArray, len: Int, firstTimeout: Int): Boolean {
        var got = 0
        var timeout = firstTimeout
        while (got < len) {
            val n = t.read(buf, got, len - got, timeout)
            if (n < 0) {
                if (got == 0) return false
                throw IOException("USB read failed")
            }
            got += n
            timeout = 5000
        }
        return true
    }

    private fun readMessage(timeoutMs: Int): AdbMessage? {
        val h = ByteArray(24)
        if (!readExact(h, 24, timeoutMs)) return null
        val b = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = b.getInt()
        val a0 = b.getInt()
        val a1 = b.getInt()
        val len = b.getInt()
        b.getInt()
        val magic = b.getInt()
        if (magic != cmd.inv() || len < 0 || len > 1048576) throw IOException("Unexpected reply from the device")
        val data = ByteArray(len)
        if (len > 0 && !readExact(data, len, 5000)) throw IOException("The device stopped sending")
        return AdbMessage(cmd, a0, a1, data)
    }

    // ------------------------------------------------------------------ connect

    /** onPrompt is called when the device shows its "Allow USB debugging?" window. */
    fun connect(onPrompt: () -> Unit) {
        send(A_CNXN, 0x01000001, MAX_DATA, "host::\u0000".toByteArray(Charsets.US_ASCII))
        var signed = false
        var sentKey = false
        val start = System.currentTimeMillis()
        while (true) {
            if (stopped) throw IOException("Stopped")
            val m = readMessage(2000)
            val elapsed = System.currentTimeMillis() - start
            if (m == null) {
                if (elapsed > (if (sentKey) 90000L else 15000L)) throw IOException("The device did not answer")
                continue
            }
            if (m.cmd == A_CNXN) {
                banner = String(m.data, Charsets.UTF_8).trimEnd('\u0000')
                features = Regex("features=([^;]*)").find(banner)?.groupValues?.get(1) ?: ""
                maxData = minOf(MAX_DATA, if (m.arg1 > 0) m.arg1 else 4096)
                return
            }
            if (m.cmd == A_AUTH && m.arg0 == 1) {
                if (!signed) {
                    send(A_AUTH, 2, 0, AdbKey.sign(ctx, m.data))
                    signed = true
                } else {
                    send(A_AUTH, 3, 0, AdbKey.publicKey(ctx))
                    sentKey = true
                    onPrompt()
                }
            }
        }
    }

    /** The device's own name from its banner, for the title bar. */
    fun deviceName(): String {
        val model = Regex("ro.product.model=([^;]*)").find(banner)?.groupValues?.get(1)
        val name = Regex("ro.product.name=([^;]*)").find(banner)?.groupValues?.get(1)
        return model ?: name ?: "device"
    }

    fun close() {
        stopped = true
        runCatching { t.close() }
    }

    // ------------------------------------------------------------------ streams

    private fun dispatch(m: AdbMessage) {
        val s = cur ?: return
        if (m.arg1 != s.local) return
        when (m.cmd) {
            A_OKAY -> {
                if (s.remote == 0) s.remote = m.arg0
                s.okays++
            }
            A_WRTE -> {
                s.inbox.add(m.data)
                send(A_OKAY, s.local, s.remote)
            }
            A_CLSE -> s.closed = true
        }
    }

    private fun pumpUntil(timeoutMs: Int, cond: () -> Boolean) {
        val end = if (timeoutMs > 0) System.currentTimeMillis() + timeoutMs else Long.MAX_VALUE
        while (!cond()) {
            if (stopped) throw IOException("Stopped")
            if (System.currentTimeMillis() > end) throw IOException("The device did not answer in time")
            val m = readMessage(1000)
            if (m == null) {
                if (!t.alive()) throw IOException("The device was unplugged")
                continue
            }
            dispatch(m)
        }
    }

    private fun openStream(service: String): AdbStream {
        val s = AdbStream(nextId++)
        cur = s
        send(A_OPEN, s.local, 0, (service + "\u0000").toByteArray(Charsets.UTF_8))
        pumpUntil(15000) { s.remote != 0 || s.closed }
        if (s.remote == 0) throw IOException("The device refused: $service")
        return s
    }

    private fun closeStream(s: AdbStream) {
        runCatching { if (!s.closed) send(A_CLSE, s.local, s.remote) }
        s.closed = true
        cur = null
    }

    private fun streamWrite(s: AdbStream, data: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val n = minOf(maxData, len - off)
            val before = s.okays
            send(A_WRTE, s.local, s.remote, data.copyOfRange(off, off + n))
            pumpUntil(30000) { s.okays > before || s.closed }
            if (s.closed) throw IOException("The device closed the connection")
            off += n
        }
    }

    /** The next piece of the device's answer, or null when the device closed the stream. 0 = wait as long as it takes. */
    private fun readChunk(s: AdbStream, timeoutMs: Int): ByteArray? {
        pumpUntil(timeoutMs) { s.inbox.isNotEmpty() || s.closed }
        return s.inbox.poll()
    }

    // ------------------------------------------------------------------ run a command

    /** Runs a shell command on the device; onText gets the output as it arrives. Returns the exit code (-1 if the device does not report one). */
    fun shell(cmd: String, onText: (String) -> Unit): Int {
        val v2 = features.split(',').contains("shell_v2")
        val s = openStream((if (v2) "shell,v2,raw:" else "shell:") + cmd)
        var exit = -1
        var acc = ByteArray(0)
        try {
            while (true) {
                val d = readChunk(s, 0) ?: break
                if (!v2) {
                    onText(String(d, Charsets.UTF_8))
                    continue
                }
                acc += d
                while (acc.size >= 5) {
                    val id = acc[0].toInt()
                    val len = le32(acc, 1)
                    if (len < 0 || acc.size < 5 + len) break
                    val payload = acc.copyOfRange(5, 5 + len)
                    acc = acc.copyOfRange(5 + len, acc.size)
                    if (id == 1 || id == 2) onText(String(payload, Charsets.UTF_8))
                    else if (id == 3 && len > 0) exit = payload[0].toInt() and 0xFF
                }
            }
        } finally {
            closeStream(s)
        }
        return exit
    }

    // ------------------------------------------------------------------ push a file

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    private fun syncPacket(id: String, data: ByteArray, len: Int): ByteArray {
        val out = ByteArray(8 + len)
        val idb = id.toByteArray(Charsets.US_ASCII)
        System.arraycopy(idb, 0, out, 0, 4)
        out[4] = (len and 0xFF).toByte()
        out[5] = ((len shr 8) and 0xFF).toByte()
        out[6] = ((len shr 16) and 0xFF).toByte()
        out[7] = ((len shr 24) and 0xFF).toByte()
        if (len > 0) System.arraycopy(data, 0, out, 8, len)
        return out
    }

    private fun failText(reply: ByteArray): String? {
        if (reply.size < 8 || String(reply, 0, 4, Charsets.US_ASCII) != "FAIL") return null
        val len = le32(reply, 4)
        val end = minOf(reply.size, 8 + maxOf(len, 0))
        return String(reply, 8, end - 8, Charsets.UTF_8)
    }

    /** Copies the stream to remotePath on the device (mode 0644). onBytes gets the running total. */
    fun push(input: InputStream, remotePath: String, onBytes: (Long) -> Unit) {
        val s = openStream("sync:")
        try {
            try {
                val spec = "$remotePath,33188".toByteArray(Charsets.UTF_8)
                val head = syncPacket("SEND", spec, spec.size)
                streamWrite(s, head, head.size)
                val buf = ByteArray(65536)
                var total = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    val pkt = syncPacket("DATA", buf, n)
                    streamWrite(s, pkt, pkt.size)
                    total += n
                    onBytes(total)
                }
                val done = syncPacket("DONE", ByteArray(0), 0)
                val mtime = (System.currentTimeMillis() / 1000).toInt()
                done[4] = (mtime and 0xFF).toByte()
                done[5] = ((mtime shr 8) and 0xFF).toByte()
                done[6] = ((mtime shr 16) and 0xFF).toByte()
                done[7] = ((mtime shr 24) and 0xFF).toByte()
                streamWrite(s, done, done.size)
            } catch (e: IOException) {
                var early = ByteArray(0)
                while (s.inbox.isNotEmpty()) early += s.inbox.poll()
                val why = failText(early)
                if (why != null) throw IOException(why)
                throw e
            }
            var reply = ByteArray(0)
            while (reply.size < 8) {
                val d = readChunk(s, 30000) ?: break
                reply += d
            }
            if (reply.size < 8) throw IOException("No answer from the device")
            if (String(reply, 0, 4, Charsets.US_ASCII) == "FAIL") {
                val need = 8 + maxOf(le32(reply, 4), 0)
                while (reply.size < need) {
                    val d = readChunk(s, 10000) ?: break
                    reply += d
                }
                throw IOException(failText(reply) ?: "The device refused the file")
            }
        } finally {
            closeStream(s)
        }
    }

    companion object {
        private const val A_CNXN = 0x4e584e43
        private const val A_AUTH = 0x48545541
        private const val A_OPEN = 0x4e45504f
        private const val A_OKAY = 0x59414b4f
        private const val A_CLSE = 0x45534c43
        private const val A_WRTE = 0x45545257
        private const val MAX_DATA = 262144
    }
}
