package com.newagedevs.gesturevolume.ui.screens.shell

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import com.newagedevs.gesturevolume.adb.AdbConnection
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CopyAll
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import com.newagedevs.gesturevolume.ui.motion.IconButton
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.utils.ShizukuShell

/** A plain shell: type a command, watch its output as it appears. Shizuku's privilege when allowed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class ShellActivity : ComponentActivity() {
    private var otgConn: AdbConnection? = null
    private var onPicked: ((List<Uri>) -> Unit)? = null
    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        onPicked?.invoke(uris)
    }

    override fun onDestroy() {
        otgConn?.close()
        otgConn = null
        super.onDestroy()
    }

    private fun nameOf(u: Uri): String {
        var n: String? = null
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var command by remember { mutableStateOf("") }
                    var output by remember { mutableStateOf("") }   // the last run
                    var log by remember { mutableStateOf("") }      // every run since the last clear, one after another
                    var lastCommand by remember { mutableStateOf("") }
                    var running by remember { mutableStateOf(false) }
                    var mode by remember { mutableStateOf(modeText()) }
                    var adb by remember { mutableStateOf<AdbConnection?>(null) }
                    var adbName by remember { mutableStateOf("") }
                    var showOtg by remember { mutableStateOf(false) }
                    var showPush by remember { mutableStateOf(false) }
                    var pushDir by remember { mutableStateOf(com.newagedevs.gesturevolume.utils.ShellFeedback.prefs(this@ShellActivity).getString("otgPushDir", "/sdcard/Download/") ?: "/sdcard/Download/") }
                    val scroll = rememberScrollState()

                    fun emit(text: String) { output += text; log += text }

                    fun launch(title: String, block: () -> Unit) {
                        if (running) return
                        running = true
                        lastCommand = title
                        output = ""
                        log += (if (log.isEmpty()) "" else "\n") + "$ $title\n"
                        Thread {
                            try { block() } catch (e: Throwable) { emit("ERROR: ${e.javaClass.simpleName}: ${e.message}") }
                            log += "\n"
                            running = false
                        }.start()
                    }

                    var enterRuns by remember { mutableStateOf(com.newagedevs.gesturevolume.utils.ShellFeedback.prefs(this@ShellActivity).getBoolean("enterRuns", false)) }
                    androidx.compose.runtime.LaunchedEffect(log) { if (running) scroll.scrollTo(scroll.maxValue) }

                    var showHistory by remember { mutableStateOf(false) }
                    fun runCommand(cmd: String) {
                        ShellHistory.recordRun(this@ShellActivity, cmd)
                        val a = adb
                        if (a != null) {
                            launch(cmd) {
                                val code = a.shell(cmd) { text -> emit(text) }
                                emit("\n[exit " + (if (code < 0) "?" else code.toString()) + "]")
                            }
                        } else launch(cmd) {
                            val code = ShizukuShell.run(cmd) { line -> emit(line + "\n") }
                            emit("\n[exit $code]")
                        }
                    }

                    fun runPush(uris: List<Uri>, dirIn: String) {
                        val c = adb ?: return
                        val dir = if (dirIn.endsWith("/")) dirIn else "$dirIn/"
                        launch("push " + uris.size + " file(s) to " + dir) {
                            c.shell("mkdir -p '" + dir.replace("'", "'\\''") + "'") { }
                            for (u in uris) {
                                val name = nameOf(u)
                                emit("$name ")
                                var sent = 0L
                                var mark = 0L
                                val ins = contentResolver.openInputStream(u) ?: throw java.io.IOException("Cannot read $name")
                                ins.use { stream ->
                                    c.push(stream, dir + name) { n ->
                                        sent = n
                                        if (n - mark >= 4000000L) { mark = n; emit(".") }
                                    }
                                }
                                emit(" done (" + sent + " bytes)\n")
                            }
                            emit("[push finished]")
                        }
                    }
                    if (showOtg) {
                        OtgDialog(
                            connectedName = if (adb != null) adbName else null,
                            onConnected = { c -> otgConn = c; adb = c; adbName = c.deviceName() },
                            onDisconnect = { otgConn?.close(); otgConn = null; adb = null; adbName = "" },
                            onDismiss = { showOtg = false },
                        )
                    }
                    if (showPush) {
                        PushDialog(
                            dir = pushDir,
                            onDismiss = { showPush = false },
                            onChoose = { d ->
                                pushDir = d
                                showPush = false
                                com.newagedevs.gesturevolume.utils.ShellFeedback.prefs(this@ShellActivity).edit().putString("otgPushDir", d).apply()
                                onPicked = { uris -> if (uris.isNotEmpty()) runPush(uris, d) }
                                pickFiles.launch(arrayOf("*/*"))
                            },
                        )
                    }
                    if (showHistory) {
                        ShellHistoryDialog(
                            onDismiss = { showHistory = false },
                            onUse = { command = it; showHistory = false },
                            onRun = { command = it; showHistory = false; runCommand(it) },
                            onCopy = { copy(it, "Command copied") },
                        )
                    }

                    var showFb by remember { mutableStateOf(false) }
                    if (showFb) {
                        val fp = com.newagedevs.gesturevolume.utils.ShellFeedback.prefs(this@ShellActivity)
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { showFb = false },
                            title = { Text("When a shell shortcut ends, show its result as") },
                            text = {
                                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Any mix: tick one, two or all three.", fontSize = 12.sp)
                                    for ((key, label, def, msKey, msDef, msLabel) in listOf(
                                        FbRow("bar", "Bar", true, "barMs", 3000, "Bar time (ms)"),
                                        FbRow("toast", "Toast", false, "", 0, ""),
                                        FbRow("notice", "Notification", false, "noticeMs", 4000, "Notification time (ms)"),
                                    )) {
                                        var on by remember { mutableStateOf(fp.getBoolean(key, def)) }
                                        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                            Text(label, Modifier.weight(1f))
                                            androidx.compose.material3.Switch(checked = on, onCheckedChange = { on = it; fp.edit().putBoolean(key, it).apply() })
                                        }
                                        if (msKey.isNotEmpty() && on) {
                                            var ms by remember { mutableStateOf(fp.getInt(msKey, msDef).toString()) }
                                            OutlinedTextField(
                                                value = ms, singleLine = true, label = { Text(msLabel) },
                                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                                                onValueChange = { v -> ms = v.filter { it.isDigit() }.take(6); ms.toIntOrNull()?.let { fp.edit().putInt(msKey, it).apply() } },
                                            )
                                        }
                                        if (key == "toast" && on) {
                                            var long by remember { mutableStateOf(fp.getBoolean("toastLong", false)) }
                                            androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                                Text("Long toast", Modifier.weight(1f))
                                                androidx.compose.material3.Switch(checked = long, onCheckedChange = { long = it; fp.edit().putBoolean("toastLong", it).apply() })
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = { androidx.compose.material3.TextButton(onClick = { showFb = false }) { Text("Done") } },
                        )
                    }
                    Column(
                        Modifier.fillMaxSize().statusBarsPadding().padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text("Shell  -  " + (if (adb != null) "OTG: $adbName" else mode), style = MaterialTheme.typography.titleMedium)
                        OutlinedTextField(
                            value = command,
                            onValueChange = { v ->
                                // One typed Enter runs the command; a paste (more than one character) keeps its new lines.
                                var i = 0
                                while (i < command.length && i < v.length && command[i] == v[i]) i++
                                val typedEnter = enterRuns && v.length == command.length + 1 && v[i] == '\n' && v.removeRange(i, i + 1) == command
                                if (typedEnter) { if (command.isNotBlank()) runCommand(command) } else command = v
                            },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Command") },
                        )
                        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("Enter key runs the command (pasted new lines stay)", Modifier.weight(1f), fontSize = 13.sp)
                            androidx.compose.material3.Switch(checked = enterRuns, onCheckedChange = {
                                enterRuns = it
                                com.newagedevs.gesturevolume.utils.ShellFeedback.prefs(this@ShellActivity).edit().putBoolean("enterRuns", it).apply()
                            })
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(enabled = !running, onClick = { runCommand(command) }) { Text("Run") }
                            OutlinedButton(onClick = { showOtg = true }) { Text(if (adb != null) "OTG: $adbName" else "OTG device") }
                            if (adb != null) OutlinedButton(enabled = !running, onClick = { showPush = true }) { Text("Push file") }
                            IconButton(onClick = { showHistory = true }, tooltip = "History and saved commands") {
                                Icon(Icons.Filled.History, contentDescription = null)
                            }
                            OutlinedButton(onClick = {
                                ShizukuShell.requestPermission { mode = modeText() }
                                mode = modeText()
                            }) { Text("Allow Shizuku") }
                            OutlinedButton(enabled = !running, onClick = {
                                launch("grant permissions") {
                                    val code = ShizukuShell.grantAll(this@ShellActivity) { line -> emit(line + "\n") }
                                    emit("\n[exit $code]")
                                }
                            }) { Text("Grant permissions") }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { copy(output, "Last output copied") }, tooltip = "Copy last output") {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null)
                            }
                            IconButton(onClick = { copy(log, "All output copied") }, tooltip = "Copy all output") {
                                Icon(Icons.Filled.CopyAll, contentDescription = null)
                            }
                            IconButton(onClick = { log = ""; output = "" }, tooltip = "Clear output") {
                                Icon(Icons.Filled.Close, contentDescription = null)
                            }
                            OutlinedButton(onClick = { saveTxt(lastCommand.ifBlank { command }, output) }) { Text("Save as txt") }
                            OutlinedButton(onClick = { showFb = true }) { Text("Shortcut feedback") }
                        }
                        androidx.compose.foundation.text.selection.SelectionContainer(
                            Modifier.fillMaxWidth().weight(1f).verticalScroll(scroll),
                        ) {
                            Text(log, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    private fun modeText(): String = when {
        ShizukuShell.isReady() -> "Shizuku (privileged)"
        ShizukuShell.isRunning() -> "Shizuku running, not allowed yet"
        else -> "normal (Shizuku is not running)"
    }

    private fun copy(text: String, done: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shell", text))
        Toast.makeText(this, done, Toast.LENGTH_SHORT).show()
    }

    /** Downloads/<first 15 characters of the command>.txt */
    private fun saveTxt(command: String, text: String) {
        val base = command.trim().take(15).replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "output" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "$base.txt")
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val ok = runCatching {
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Saved in Downloads as $base.txt" else "Could not save", Toast.LENGTH_SHORT).show()
    }
}

private data class FbRow(val key: String, val label: String, val def: Boolean, val msKey: String, val msDef: Int, val msLabel: String)
