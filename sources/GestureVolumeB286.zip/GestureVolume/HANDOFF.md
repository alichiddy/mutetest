# HANDOFF - state: B286 (zip GestureVolumeB286.zip, built from B285 which did not compile), not compiled. Next build: B287
- B286: B285 compile error fixed (FilePickActivity: Intent.setClipData returns Unit, now `result.clipData = clip`). Stale app shortcuts: a saved "Intent:" cell is a frozen copy, so an update of the target app (screen renamed/closed/removed) broke it until re-added. AppStarter now heals at run time, no Shizuku: componentMissing -> healed() = same shortcut (action+data+extras) in the app's current manifest shortcuts (loadStaticShortcuts(context, onlyPackage)), else same action without a screen so Android picks the current one. The cell itself is not rewritten. Every run notes "shortcut run: <pkg> v.. updated .. ; screen open/CLOSED/NOT in the app; intent" (DiagLog.note) and failures/heals are DiagLog.persist ("shortcut FAILED (...)", "shortcut healed"). Report ticks: "What the app noted" + "Saved events".
- B285: (1) App shortcuts without Shizuku: AppStarter.closedReason reads the target's manifest (not exported / needs a permission = no app but its owner or the shell may start it); then A opens that app's launcher screen instead and the bar says why (lastFailure). ShortcutRunActivity now starts an "Intent:" action itself while its screen is showing (before: posted to the bar after finish(), Android dropped it); AppStarter.plain starts from an Activity context when given one. Why a phone differs: Shizuku not running (needs a restart after a reboot) or a target that is not exported. (2) A's own file picker: share/FilePickActivity.kt answers GET_CONTENT, OPEN_DOCUMENT, CREATE_DOCUMENT, OPEN_DOCUMENT_TREE (manifest filters), browses real storage (needs All files access) and returns document URIs of PickerProvider, which now has a second root "A files" (ids "d:<path>", create/delete/rename/isChild). Appears next to Files in the system chooser; "Always" makes it the default. Photo Picker and apps that force the system Files app cannot be replaced. Not compiled here.
- B284: (1) App shortcuts ("Intent:" cells, Intent script step) did nothing: utils/AppStarter sent only MAIN+LAUNCHER intents through Shizuku `am start`; every other intent was a plain background start, which Android drops silently or refuses when the target activity is not exported (typical for an app's own shortcut targets). Now any intent of another app goes through `am start` when Shizuku is ready (AppStarter.shellCanStart: plain extras only, no URI grants/content/file data, not A's own screens), else the plain start as before; the real reason of a failed plain start is kept in AppStarter.lastFailure and shown on the bar (OverlayController Intent: branch). DiagLog notes `am start exit=... out=...`. (2) Backups window: "Share" next to each Backup (JSON through the share sheet, FileProvider cache path share/), and "Share <name>.apk" after Make APK (ApkCloner.makeAndSave returns the saved Uri). New strip/FileSharer.kt (shareUri/shareFile/shareText) for sharing any file. Not compiled here.

## B282: option "Put A back into the accessibility list if something removes it"
- New service/A11yKeeper.kt (pref keepA11yOn, off by default): ContentObserver on enabled_accessibility_services only while the service is connected and the option is on; if A (a.a.S) is missing it writes it back with WRITE_SECURE_SETTINGS (no Shizuku needed) and logs removed/added entries to the report (DiagLog.persist). Max 3 write-backs a minute, then rests 10 min.
- Hooks in GestureAccessibilityService (onServiceConnected sync, onUnbind changed, onDestroy stop); switch KeepA11yRow in ui/screens/shell/ShizukuGrantRow.kt, shown on the main screen under the Shizuku grant button.
- Why: A report from b279 showed A missing from the list at 3 disconnects (16:24, 16:29, 16:30); Automate and Vivo battery manager suspected.

## B281: Scripts window list (flow/FlowActivity.kt only)
"Options ▾" button collapses all option buttons (closed by default); "Select" button shows checkboxes on every row (All/None/Duplicate/Share/Delete, long press still works); switch "Search bar at the top" (pref FlowUi.searchTop, default on) puts search right under "Flows (n)". Not a script block (window UI).

## B277: GitHub build, new projects (utils/GitHubBuild.kt only)
Cause found from his Authenticator report: the zip upload worked but the workflow start (`dispatchWorkflow`) got 404 because the repo had no .github/workflows/authenticator.yml yet (the old 404 text wrongly said "'gv' release"). Now: on 404 the ticked yml of that project is put into the repo (GitHubApi.putFile, needs the token's Workflows permission), then the start is retried up to 8 times (4 s apart). With no matching ticked yml it says to tick it. The 404 text now shows GitHub's own reply. His earlier failed tries left Authenticator.zip / authenticator-*.yml in the gv and th releases: he must delete them (GitHub manager, Releases tab), else gv's workflow builds the wrong zip. Authenticator app itself = separate project (workflow authenticator.yml, release au).

## B275: All apps window (ui/screens/apps/AllAppsActivity.kt)
Same 4 kind filters as App icon / Open with Hail (User, User hidden/disabled, System, System hidden/disabled) with its OWN saved choice (MyPrefs allAppsKinds, default User). Off apps open through Hail (ActionSaver.hailAction). Grid settings (Grid button): columns (0 = auto), icon dp, name sp, name lines (0 = no names); keys allAppsCols/allAppsIconDp/allAppsTextSp/allAppsLines; icons drawn lazily per visible cell. File picker (PickerProvider) sort: NOT changed, system picker sorts itself (see chat).

## B274: every Swiftly Switch built-in shortcut added, duplicates removed (steps 1 and 2 done together, he asked for it at once)
Ali sent base_src.zip (apktool smali of Swiftly Switch, org.de_studio.recentappswitcher.trial; its shortcut names are in res/values/strings.xml `setting_shortcut_*`). Rule he gave: add all, delete duplicates in A's built-ins, keep the more advanced one (Shizuku when available).
Built (flow/SwiftlyActions.kt, registered at the end of NativeActions' init; ordinary "N:<id>" device actions, so they appear in the one Built-in shortcuts list, cells, segments, scripts, search, with icons from DeviceActionIcons):
- Dark theme: on/off/toggle (Shizuku `cmd uimode night yes|no`, else Display settings); NFC: on/off/toggle (Shizuku `svc nfc`, else NFC settings).
- Clean RAM (native killBackgroundProcesses for installed apps except A/keyboard/launcher, + Shizuku `am kill-all`; new permission KILL_BACKGROUND_PROCESSES; reports MB freed).
- Screen rotation (ONE entry, choices: auto / lock-toggle / portrait / landscape / portrait upside down / landscape reversed; Settings.System write or Shizuku `settings put system`; asks for "Modify system settings" otherwise) - replaces Swiftly's 4 rotation shortcuts.
- Ringer mode (ONE entry, choices: sound / vibrate / silent / sound-vibrate cycle / sound-silent cycle; silent needs DND access or Shizuku `cmd audio set-ringer-mode`).
- Split screen (accessibility GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN), Circle to Search (best effort: Shizuku `input keyevent --longpress 3`, else ACTION_ASSIST; UNTESTED, vivo may not have it).
- Openers: Call logs, Dialer, Contacts, Calendar, Record audio, Storage (Files app at primary storage, else storage settings).
Duplicates: HandlerActionCatalog.HIDDEN (Wi-Fi panel, Bluetooth settings, Flashlight, Auto-rotate, Ring/vibrate) are no longer offered in the picker or search (BuiltInPage, SearchSources); old cells that use them still run unchanged. The N: versions (Wi-Fi/Bluetooth/Flashlight with Shizuku and on/off/toggle, Screen rotation, Ringer mode) replace them. Swiftly shortcuts already in A and not added: Airplane, Mobile data, Wi-Fi, Bluetooth, Back/Home/Recents, Lock, Power menu, Notifications, Quick settings (Control Center), Screenshot, Flashlight, Google Assistant (Voice assistant), Last app (Previous app), All apps, media/volume, Scan code (Scan QR), Search, Panel Music/Calculator.
Skipped on purpose (Swiftly-only edge/panel handling, A has no such thing): Activate/Move/Remove Edge, Remove Edge in time, Set Remove Edge time, Reverse L-R edge, Move Edge to L-R, Move to Edge Screen, Show Trigger Zone, Open Panel by Edge position, Panel left on/off, Mode Extended Options, Mode Move Button, Panel Collection/View, Folder, List Folder, Open Manage App, Rotation and Volume Bar (= Screen rotation + Open volume UI in a script), Screen brightness panel (A has brightness actions).
Also in A: new items need no search-index rebuild (SearchSources reads the catalog at run time).
Changed files: flow/SwiftlyActions.kt (new), flow/NativeActions.kt, flow/ActionArgs.kt (rotation, ringer choices), utils/DeviceActionIcons.kt, utils/HandlerActionCatalog.kt, ui/screens/strip/ActionPages.kt, ui/screens/main/SearchSources.kt, AndroidManifest.xml.
He gives feedback himself; do not remind him what to test.

## (B273 handoff below)

## B273: search step 2 - scroll to the item and flash it
screens/main/SearchFocus.kt (set on tap, valid 8 s) + Modifier.searchTarget(label) on SwitchControl, SliderControl, SettingSwitchItem, ActionSettingItem (scroll into view after 450 ms, 3 flashes); AppearanceSection opens itself when it is the result's section. Not covered: items on the Cells editor, Side bars, Scripts etc. (they open the screen only); a cell result opens the Cells editor, not that cell.

## B272: "Search everything" in the main menu (step 1 of 2; step 2 = scroll to the item and flash it)
Ali asked (and chose: scope = settings + his own things; tap = open the screen AND flash the item, done in steps). The option he could not find is "Open the Cells window from the volume panel": Main > Appearance > Content section, under "No slider while sound plays".
Built:
- Main screen, three-lines menu: a "Search everything" pill at the top opens ui/screens/main/SearchDialog.kt (full-screen, one box, results with name + place "Appearance > Content" + info line).
- utils/SmartSearch.kt (pure Kotlin, unit-tested: app/src/test/.../SmartSearchTest.kt, also run here with kotlinc): any word order, wifi = wi-fi = wi fi, beginnings, plurals, one/two-letter typos (only when nothing matches exactly), synonyms (torch=flashlight, cells=shortcuts, ...), name beats info beats place; when no entry holds all words it shows the ones holding most.
- ui/screens/main/SearchSources.kt: collected only while the search is open (zero idle RAM): assets/search_index.json (screens + every label/title/summary/info text found in the screen sources), built-in shortcuts (HandlerActionCatalog), device actions (NativePicker.groups), his cells and folders (main Cells window + segments' own windows), his scripts.
- tool/make_search_index.py builds assets/search_index.json from the sources: RE-RUN IT (python3 tool/make_search_index.py) whenever screens or labels change. Screen/route table is at the top of the script.
- Tap = MainScreen.onPick: nav:<route> -> NavHost (new MainScreen param onNavigateToRoute), act:<class> -> that window, dlg:backups/github/report/presets -> main-screen dialogs, menu:Theme/Language/Reset, script:<name> -> FlowActivity (extra "flow").
Step 2 plan (not built): a global "search target" (title + section); AppearanceSection expands itself when its title is the target's section, SwitchControl / SliderControl / SettingSwitchItem / ActionSettingItem / HomeLinkRow / HomeToggleRow scroll themselves into view (BringIntoViewRequester) and flash when their label equals the target title. Cells: open the cell's editor.


## B271: merged the lit-cell fade into the "Swiftly Switch style" option
There were two B270s; B271 = the handoff's B270 (round zones, fly-out, window placed under the thumb) + a 100 ms colour fade of the lit cell (Swiftly's ofArgb backgroundColor, 0x64 ms), all behind the same switch `stripSwifty`. Only strip/StripView.kt (fade: `amt`, `fadeStep`, `litAmount`) and the switch's label changed. Option off = old paths. Not compiled.


## B270: "Swifty Switch style" option (built, NOT compiled, untested)
Ali asked for the exact logic of how Swifty Switch's Cells window opens and moves between shortcuts, as an OPTION (off by default). Switch: Cell Settings > "Swifty Switch style ..." (pref `stripSwifty`, per Cells window via StripScope; optional hidden pref `stripSwiftyMs`, default 250).

What was read in Swifty (base_src.zip = obfuscated smali of org.de_studio.recentappswitcher.trial):
- Touch -> la2 (OnTouchListener) -> NewServiceView.onTouch -> presenter kf1: F(x,y,id) = open, G(x,y) = every ACTION_MOVE, Q(x,y) = centre of the panel, clamped on screen with xe1.K/L.
- Grid hit test = xe1.H(...): for each cell centre (spacing = size*density + padding) the cell is hit when the finger is inside a CIRCLE of radius 35 dp (35*density) around the centre; first cell found in column-major order wins; gaps between circles = nothing lit (-1); finger farther than 90 dp from every centre (when the flag is on) = -2 (leave/cancel). Mirror: index = (cols-1-col) + row*cols. No hysteresis, no throttling.
- Opening (NewServiceView.b1): the panel is placed under the finger first; every cell starts translated by (panelCentre - cellPos)/2, alpha 0, then animates to 0 / alpha 1 with DecelerateInterpolator(3.0), duration = pref `animation_time` (default 250 ms). One branch also sets a start delay equal to that time: NOT understood, NOT copied.
- Not extracted: highlight drawing on index change, haptic on open (pref disable_haptic), hold-time before close.

What was built in A:
- strip/StripView.kt: `swifty` flag; `swiftyCellAt` (round zones, radius = max(35 dp, cell/2), first in column order, no sticky) used by cellAt (so highlight and release-run agree); `startOpen(ms)` + per-cell fly-out/fade in onDraw (only while opening; saveLayerAlpha per cell); animator cancelled on detach.
- service/OverlayController.kt: with the option on and not "Centered", showStrip builds the window but adds it only when the thumb's place is known (placeStripOnThumb -> attachStrip), at its final place in ONE addView (before: added invisible, then moved with updateViewLayout, up to 150 ms late); fallback adds it after 150 ms. Centered: added at once. `stripPendingParams`, `attachStrip`; hideStrip clears pending.
- ui/screens/strip/StripEditorScreen.kt: the switch.
- Option off = old code paths untouched.

Open questions for Ali's test: does the radius (35 dp / half cell) feel like Swifty's; is a different animation time wanted (then expose stripSwiftyMs as stepper); the unexplained start delay.
Next build: B271.

## (older handoff below, from B265; B266-B269 changes are not listed here)


## Working with Ali
Persian/English, voice dictation ("ID" = idea). NOT a developer: boxes/forms/lists, no code or formulas. Lean replies, accuracy over speed, talk first before big changes, never remind him what to test. App is just "A" (package a.a), repo alichiddy/mutetest; he builds on GitHub Actions and pastes errors (Claude cannot compile). Deliver the zip only (no YML), name the build number (next: B264), bracket-check changed .kt files against the originals. Zero idle RAM: any feature costs nothing when not used. Never wait for a double tap. Terms: "Cells window", "Segments". Source layout: app/src/main/java/a/a/{strip,service,utils,flow,share,ui}.

## Latest builds
- B265: A declares a HOME activity (launcher mode), so it counted as "the launcher" and was skipped even with the switch on; homePackages now drops A when the option is on.
- B264: Previous app report lines now show allowA and the skip list (debug for "A not chosen").
- B263: "Allow A as the previous app" option (Previous app dialog; PreviousApp.PREF_ALLOW_A, default off). On: A is no longer skipped by Previous app - Shizuku recents (counts/pick), the tracked history (OverlayController.onForegroundApp notes A's own screens only when the option is on) and the usage-events path (pickFromHistory). Off = as before. Changed: utils/PreviousApp.kt, service/OverlayController.kt, ui/screens/strip/StripEditorScreen.kt.
- B262: long info texts in the cells editor / outside actions folded behind "▾ Info".
- B260: Previous app without Shizuku = MyGesture's way (tracked list of 8 packages from accessibility window changes, launched with MAIN/LAUNCHER intent, flags 0x10200000, via PendingIntent). Needs "Track apps without Shizuku" ON or Usage access. Shizuku way: startActivityFromRecents, moveTaskToFront, `am task lock` (option "stop lock after unpinning").
- B283: backup now carries every picture any setting names (edge-action icons stripEdge*Meta too, also in a settings-only backup; restored whenever the file holds them). Folder's first-4 preview now draws each kid like its own cell: icon "none" -> its name fitted in the little square (no word "none"), no icon / icon that cannot load -> name, app/picture/emoji as before (StripView.kt, SettingsBackup.kt). Not done yet (asked next): app icons of apps not installed on the new phone are not embedded.
- B251: Wi-Fi share (3 QR codes, notification row, "Wi-Fi share window" shortcut, upload page).
- B247: tapping a .json opens "Import into A". B244: A in the system file picker.
- B242/B243: volume panel hands an inward swipe to the Cells window (switch panelOpensCells); test bar bottom-left (switch testBarOn).

## Open
1. Test bar visibility (needs Copy report, note "test bar x= y= w= h=").
2. Left vertical segment's volume panel shows a gap to the screen side in portrait (not fixed).
3. Landscape as two windows idea: discuss first.
4. Accessibility service sometimes dropped: his Automate flows overwrite enabled_accessibility_services (not proven); Copy report logs list changes.
5. Older untested items: bank (Resalat) widget sends A away after tap; Persian digit OCR; see his backlog.

## Reminders from the code
- Kept on purpose with old names: GitHubBuild.kt/SharedPref (workflow gesturevolume.yml, release tag gv), assets/automate_flows.json.
- Never put real keys in source (PrivateValues slots).
- Scripts-blocks principle: say whether a new feature is a user-buildable script block or a built-in.
