// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.os.Build
import android.os.SystemClock
import android.view.inputmethod.EditorInfo
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * LeanType A addition: a short log (kept in memory only) of the last things the keyboard did in the text
 * field, each with its time in seconds and milliseconds. The clipboard options window can copy it as a
 * report, to find out why the cursor jumps back after a paste or why a word gets typed twice.
 */
object InputTrace {
    private const val MAX = 400
    private const val MAX_TEXT = 60

    @Volatile var enabled = true
    @Volatile private var secret = false
    @Volatile private var fieldInfo = "(no field yet)"

    private class Item(val wall: Long, val up: Long, val tag: String, val msg: String)
    private val items = ArrayDeque<Item>(MAX + 1)

    /** Called when a text field gets the keyboard. Password fields are logged without their text. */
    fun onField(info: EditorInfo?, restarting: Boolean) {
        if (info == null) return
        val cls = info.inputType and EditorInfo.TYPE_MASK_CLASS
        val variation = info.inputType and EditorInfo.TYPE_MASK_VARIATION
        secret = cls == EditorInfo.TYPE_CLASS_TEXT && (variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD || variation == EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD) ||
            cls == EditorInfo.TYPE_CLASS_NUMBER && variation == EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD
        fieldInfo = "app=${info.packageName} inputType=0x${Integer.toHexString(info.inputType)} " +
            "(class=$cls variation=$variation flags=0x${Integer.toHexString(info.inputType and EditorInfo.TYPE_MASK_FLAGS)}) " +
            "initialSel=${info.initialSelStart}-${info.initialSelEnd} imeOptions=0x${Integer.toHexString(info.imeOptions)} hint=${if (secret) "-" else info.hintText?.toString()?.take(30)}"
        log("FIELD", "${if (restarting) "restart" else "start"} $fieldInfo${if (secret) " [password: text hidden]" else ""}")
    }

    fun log(tag: String, msg: String) {
        if (!enabled) return
        val item = Item(System.currentTimeMillis(), SystemClock.uptimeMillis(), tag, msg)
        synchronized(items) {
            items.addLast(item)
            while (items.size > MAX) items.removeFirst()
        }
    }

    /** Text of an edit; long text is shortened and shows its length, line breaks and spaces are made visible. */
    fun text(t: CharSequence?): String {
        if (t == null) return "null"
        if (secret) return "<${t.length} hidden>"
        val s = t.toString()
        val shown = if (s.length > MAX_TEXT) s.take(MAX_TEXT / 2) + "…" + s.takeLast(MAX_TEXT / 2 - 1) else s
        return "\"" + shown.replace("\n", "⏎").replace("\t", "⇥") + "\"(len=${s.length})"
    }

    fun clear() = synchronized(items) { items.clear() }

    fun size() = synchronized(items) { items.size }

    fun report(): String {
        val list = synchronized(items) { items.toList() }
        val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        val sb = StringBuilder()
        sb.append("LeanType A input report\n")
        sb.append("now: ").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())).append('\n')
        sb.append("device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (sdk ${Build.VERSION.SDK_INT})\n")
        sb.append("field: ").append(fieldInfo).append('\n')
        sb.append("lines: ${list.size} (newest at the bottom; time = HH:mm:ss.SSS, +ms = since the line before)\n")
        sb.append("-----\n")
        var prev = 0L
        for (i in list) {
            val delta = if (prev == 0L) 0L else i.up - prev
            prev = i.up
            sb.append(fmt.format(Date(i.wall))).append(" +").append(delta).append("ms ")
                .append(i.tag.padEnd(7)).append(' ').append(i.msg).append('\n')
        }
        if (list.isNotEmpty()) {
            val total = list.last().up - list.first().up
            sb.append("-----\nfirst to last line: ${total / 1000}.${(total % 1000).toString().padStart(3, '0')} s\n")
        }
        return sb.toString()
    }
}
