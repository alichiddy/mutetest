package a.b;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Full backup: sessions list + settings + bookmarks, logins (all WebView data), automations,
 * automation settings, saved back-history. One zip. Restore stages the zip and applies it at the
 * NEXT app start, before any WebView exists, so the data is replaced exactly.
 * The zip contains your logins: never upload it.
 */
final class Backup {

    static final String PENDING = "restore.zip";

    private static void put(ZipOutputStream z, String name, byte[] b) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(b);
        z.closeEntry();
    }

    private static void putFile(ZipOutputStream z, String name, File f) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        try (InputStream in = new FileInputStream(f)) { copy(in, z); }
        z.closeEntry();
    }

    private static void copy(InputStream in, OutputStream o) throws Exception {
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
    }

    private static final String[] URLS = {
            "https://accounts.google.com/", "https://accounts.google.com/o/oauth2/",
            "https://accounts.google.com/signin/", "https://accounts.google.com/v3/signin/",
            "https://accounts.google.com/gsi/", "https://www.google.com/",
            "https://myaccount.google.com/", "https://accounts.youtube.com/",
            "https://www.youtube.com/", "https://mail.google.com/",
            "https://claude.ai/", "https://www.claude.ai/", "https://api.claude.ai/",
            "https://claude.com/", "https://www.claude.com/",
            "https://console.anthropic.com/", "https://www.anthropic.com/"
    };

    private static String origin(String u) {
        try { android.net.Uri x = android.net.Uri.parse(u); return x.getScheme() + "://" + x.getHost() + "/"; }
        catch (Throwable e) { return null; }
    }

    /** UI thread. The cookies of every session as plain text (a second way to bring logins over). */
    static String collectCookies(Store store, boolean profilesOk) {
        JSONObject all = new JSONObject();
        if (!profilesOk) return all.toString();
        int n = 0;
        for (Store.Tab t : store.all()) {
            try {
                android.webkit.CookieManager cm = androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(t.id).getCookieManager();
                java.util.LinkedHashSet<String> urls = new java.util.LinkedHashSet<>(java.util.Arrays.asList(URLS));
                String o = origin(t.url);
                if (o != null && o.startsWith("http")) urls.add(o);
                org.json.JSONArray arr = new org.json.JSONArray();
                for (String u : urls) {
                    String ck = cm.getCookie(u);
                    if (ck == null || ck.isEmpty()) continue;
                    arr.put(new JSONObject().put("u", u).put("c", ck));
                    n++;
                }
                all.put(t.id, arr);
            } catch (Throwable ignored) { }
        }
        Dbg.d("backup cookies collected: " + n + " groups");
        return all.toString();
    }

    /** Runs at app start after WebView profiles are ready: puts the staged cookies in. Returns how many. */
    static int applyCookies(Context c, Store store, boolean profilesOk) {
        File f = new File(c.getFilesDir(), "restore_cookies.json");
        if (!f.exists()) return 0;
        int n = 0;
        try {
            if (profilesOk) {
                JSONObject all = new JSONObject(new String(Bake.readAll(new FileInputStream(f)), StandardCharsets.UTF_8));
                java.util.Iterator<String> it = all.keys();
                while (it.hasNext()) {
                    String id = it.next();
                    if (store.byId(id) == null) continue;
                    android.webkit.CookieManager cm = androidx.webkit.ProfileStore.getInstance().getOrCreateProfile(id).getCookieManager();
                    cm.setAcceptCookie(true);
                    org.json.JSONArray arr = all.getJSONArray(id);
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject g = arr.getJSONObject(i);
                        String u = g.getString("u");
                        for (String kv : g.getString("c").split(";\\s*")) {
                            if (kv.indexOf('=') <= 0) continue;
                            cm.setCookie(u, kv + "; Path=/; Secure; SameSite=None; Max-Age=31536000");
                            n++;
                        }
                    }
                    cm.flush();
                }
            }
        } catch (Throwable e) { Dbg.d("cookie restore failed: " + e); }
        f.delete();
        Dbg.d("backup cookies applied: " + n);
        return n;
    }

    /** Call off the UI thread, after pages are closed and cookies flushed. Returns where it was saved. */
    static String create(Context c, Store store, String cookiesJson) throws Exception {
        File out = buildZip(c, store, cookiesJson);
        return saveToDownloads(c, out);
    }

    /** The whole backup as one zip file in the cache (Make APK bakes this one into the clone). */
    static File buildZip(Context c, Store store, String cookiesJson) throws Exception {
        File sess = Bake.exportSessions(c, store, new File(c.getCacheDir(), "bk_sessions.zip"));
        File out = new File(c.getCacheDir(), "bk.zip");
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(out))) {
            z.setLevel(1);
            put(z, "info.txt", "AR-BACKUP 1".getBytes(StandardCharsets.UTF_8));
            put(z, "store.json", store.exportJson(false).getBytes(StandardCharsets.UTF_8));
            File fl = new File(c.getFilesDir(), "flows.json");
            if (fl.exists()) putFile(z, "flows.json", fl);
            JSONObject a = new JSONObject();
            for (Map.Entry<String, ?> e : Auto.p(c).getAll().entrySet()) {
                Object v = e.getValue();
                JSONObject j = new JSONObject();
                if (v instanceof Boolean) { j.put("t", "b"); j.put("v", v); }
                else if (v instanceof Integer) { j.put("t", "i"); j.put("v", v); }
                else if (v instanceof Long) { j.put("t", "l"); j.put("v", v); }
                else if (v instanceof Float) { j.put("t", "f"); j.put("v", ((Float) v).doubleValue()); }
                else if (v instanceof String) { j.put("t", "s"); j.put("v", v); }
                else continue;
                a.put(e.getKey(), j);
            }
            put(z, "cookies.json", cookiesJson.getBytes(StandardCharsets.UTF_8));
            put(z, "auto.json", a.toString().getBytes(StandardCharsets.UTF_8));
            File[] fs = c.getFilesDir().listFiles();
            if (fs != null) for (File f : fs)
                if (f.isFile() && f.getName().startsWith("ws_") && f.getName().endsWith(".bin")) putFile(z, "ws/" + f.getName(), f);
            putFile(z, "sessions.zip", sess);
        }
        sess.delete();
        return out;
    }

    private static String saveToDownloads(Context c, File out) throws Exception {
        String name = "AR-backup-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
                .format(new java.util.Date()) + ".zip";
        String where;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            android.net.Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IllegalStateException("cannot create file in Downloads");
            try (OutputStream o = c.getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(out)) { copy(in, o); }
            where = "Downloads/" + name;
        } else {
            File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
            File f = new File(dir, name);
            try (OutputStream o = new FileOutputStream(f); InputStream in = new FileInputStream(out)) { copy(in, o); }
            where = f.getAbsolutePath();
        }
        out.delete();
        return where;
    }

    /** Copies the chosen backup into the app; it is applied at the next start. Throws if it is not a backup. */
    static void stage(Context c, InputStream in) throws Exception {
        File dst = new File(c.getFilesDir(), PENDING);
        try (OutputStream o = new FileOutputStream(dst)) { copy(in, o); }
        boolean ok = false;
        try (ZipInputStream z = new ZipInputStream(new FileInputStream(dst))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) if (e.getName().equals("store.json")) ok = true;
        } catch (Exception ignored) { }
        if (!ok) { dst.delete(); throw new IllegalStateException("This is not an AR backup file."); }
    }

    /** Runs at app start BEFORE any WebView. Replaces everything with the staged backup. */
    static void applyPending(Context c, Store store) {
        File f = new File(c.getFilesDir(), PENDING);
        if (!f.exists()) return;
        File tmp = new File(c.getCacheDir(), "bk_apply");
        try {
            Bake.deleteRec(tmp);
            tmp.mkdirs();
            String tc = tmp.getCanonicalPath();
            try (ZipInputStream z = new ZipInputStream(new FileInputStream(f))) {
                ZipEntry e;
                while ((e = z.getNextEntry()) != null) {
                    if (e.isDirectory()) continue;
                    File o = new File(tmp, e.getName());
                    if (!o.getCanonicalPath().startsWith(tc + File.separator)) continue;
                    o.getParentFile().mkdirs();
                    try (OutputStream os = new FileOutputStream(o)) { copy(z, os); }
                }
            }
            File sj = new File(tmp, "store.json");
            if (!sj.exists()) throw new IllegalStateException("no store.json");
            // 1) logins / WebView data
            File sz = new File(tmp, "sessions.zip");
            if (sz.exists()) {
                try (InputStream in = new java.io.BufferedInputStream(new FileInputStream(sz), 65536)) { Bake.restoreSessions(c, in); }
            }
            // 2) automations
            File fl = new File(c.getFilesDir(), "flows.json");
            File nf = new File(tmp, "flows.json");
            fl.delete();
            if (nf.exists()) try (InputStream in = new FileInputStream(nf); OutputStream o = new FileOutputStream(fl)) { copy(in, o); }
            // 3) automation settings
            File af = new File(tmp, "auto.json");
            SharedPreferences.Editor ed = Auto.p(c).edit().clear();
            if (af.exists()) {
                JSONObject a = new JSONObject(new String(Bake.readAll(new FileInputStream(af)), StandardCharsets.UTF_8));
                java.util.Iterator<String> it = a.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject j = a.getJSONObject(k);
                    switch (j.getString("t")) {
                        case "b": ed.putBoolean(k, j.getBoolean("v")); break;
                        case "i": ed.putInt(k, j.getInt("v")); break;
                        case "l": ed.putLong(k, j.getLong("v")); break;
                        case "f": ed.putFloat(k, (float) j.getDouble("v")); break;
                        default: ed.putString(k, j.getString("v"));
                    }
                }
            }
            ed.commit();
            // 4) back history
            File[] old = c.getFilesDir().listFiles();
            if (old != null) for (File x : old) if (x.getName().startsWith("ws_") && x.getName().endsWith(".bin")) x.delete();
            File[] ws = new File(tmp, "ws").listFiles();
            if (ws != null) for (File x : ws)
                try (InputStream in = new FileInputStream(x); OutputStream o = new FileOutputStream(new File(c.getFilesDir(), x.getName()))) { copy(in, o); }
            // 4b) cookies as text: applied at start, once WebView profiles exist
            File cj = new File(tmp, "cookies.json");
            if (cj.exists()) try (InputStream in = new FileInputStream(cj); OutputStream o = new FileOutputStream(new File(c.getFilesDir(), "restore_cookies.json"))) { copy(in, o); }
            // 5) sessions list + settings + bookmarks
            if (store.importJson(new String(Bake.readAll(new FileInputStream(sj)), StandardCharsets.UTF_8))) store.save();
            Dbg.d("backup restored");
        } catch (Throwable e) {
            Dbg.d("backup restore failed: " + e);
        }
        Bake.deleteRec(tmp);
        f.delete();
    }
}
