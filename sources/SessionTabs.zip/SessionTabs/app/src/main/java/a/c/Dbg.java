package a.c;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.webkit.WebView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * Tiny event log for bug reports. Keeps the last ~400 lines in memory and in files/ar.log
 * (so it survives the app being killed). Never logs cookies, passwords or URL query strings.
 */
final class Dbg {
    private static final int MAX = 400;
    private static final ArrayDeque<String> buf = new ArrayDeque<>();
    private static File file;
    private static final SimpleDateFormat FMT = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US);

    static synchronized void init(Context c) {
        if (file != null) return;
        file = new File(c.getFilesDir(), "ar.log");
        try {
            if (file.exists()) {
                String s;
                try (FileInputStream in = new FileInputStream(file)) {
                    s = new String(Bake.readAll(in), StandardCharsets.UTF_8);
                }
                for (String line : s.split("\n")) {
                    if (!line.isEmpty()) { buf.addLast(line); if (buf.size() > MAX) buf.removeFirst(); }
                }
            }
        } catch (Throwable ignored) { }
        d("---- app process started ----");
    }

    static synchronized void d(String msg) {
        String line = FMT.format(new Date()) + " " + msg.replace('\n', ' ');
        buf.addLast(line);
        boolean trimmed = false;
        while (buf.size() > MAX) { buf.removeFirst(); trimmed = true; }
        if (file == null) return;
        try {
            if (trimmed && file.length() > 120 * 1024) {
                StringBuilder sb = new StringBuilder();
                for (String l : buf) sb.append(l).append('\n');
                try (FileOutputStream o = new FileOutputStream(file, false)) {
                    o.write(sb.toString().getBytes(StandardCharsets.UTF_8));
                }
            } else {
                try (FileOutputStream o = new FileOutputStream(file, true)) {
                    o.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                }
            }
        } catch (Throwable ignored) { }
    }

    /** URL without query string or fragment (those can hold login codes). */
    static String url(String u) {
        if (u == null) return "null";
        int q = u.indexOf('?');
        if (q >= 0) u = u.substring(0, q);
        int h = u.indexOf('#');
        if (h >= 0) u = u.substring(0, h);
        if (u.length() > 160) u = u.substring(0, 160) + "...";
        return u;
    }

    private static synchronized String lastLines(int n) {
        Object[] all = buf.toArray();
        int from = Math.max(0, all.length - n);
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < all.length; i++) sb.append(all[i]).append('\n');
        return sb.toString();
    }

    static String report(Context c, Store store, String curId, boolean webAlive, int lines) {
        StringBuilder sb = new StringBuilder("AR bug report\n");
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            sb.append("app ").append(pi.versionName).append(" (").append(pi.versionCode).append(")\n");
        } catch (Throwable ignored) { }
        sb.append("android ").append(Build.VERSION.RELEASE).append(" (sdk ").append(Build.VERSION.SDK_INT).append(") ")
                .append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        try {
            PackageInfo wv = WebView.getCurrentWebViewPackage();
            if (wv != null) sb.append("webview ").append(wv.packageName).append(' ').append(wv.versionName).append('\n');
        } catch (Throwable ignored) { }
        try {
            ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            sb.append("ram free ").append(mi.availMem / 1048576).append(" MB of ").append(mi.totalMem / 1048576)
                    .append(" MB, lowMemory=").append(mi.lowMemory).append('\n');
        } catch (Throwable ignored) { }
        sb.append("sessions=").append(store.tabs.size()).append(" main=").append(store.main() != null)
                .append(" lock=").append(store.lock).append(" current=").append(curId)
                .append(" pageAlive=").append(webAlive).append('\n');
        sb.append("---- last ").append(lines).append(" lines ----\n");
        sb.append(lastLines(lines));
        return sb.toString();
    }
}
