package a.b;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Runs an automation: its blocks one after another, skipping blocks whose "only if" is not met. */
final class Engine {
    private Engine() { }

    static volatile boolean running = false, stop = false;
    private static final Object LK = new Object();
    private static final java.util.ArrayDeque<String> queue = new java.util.ArrayDeque<>();
    private static PowerManager.WakeLock wl;

    private static final class Run {
        Flows.Flow f;
        boolean manual, wifi0, data0, locked0, inUse0, wasFg;
        boolean sent, userStop, flowStop;
        String err = "";
        final StringBuilder ok = new StringBuilder(), bad = new StringBuilder();
        int stopAt;
    }

    static void start(Context c, String fid, boolean manual) {
        final Context app = c.getApplicationContext();
        Dbg.init(app);
        Flows.load(app);
        final Flows.Flow f = Flows.byId(fid);
        if (f == null) { Dbg.d("flow: unknown id " + fid); return; }
        if (!manual) Auto.afterRun(app, f);
        synchronized (LK) {
            if (running) {
                if (!queue.contains(fid)) queue.add(fid);
                Dbg.d("flow: busy, queued " + f.name);
                return;
            }
            running = true;
            stop = false;
            queue.clear();
        }
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ar:flow");
            wl.acquire(30 * 60 * 1000L);
        } catch (Throwable ignored) { }
        final boolean man = manual;
        new Thread(() -> loop(app, fid, man)).start();
    }

    static void requestStop() {
        stop = true;
        synchronized (LK) { queue.clear(); }
        final MainActivity a = MainActivity.inst;
        if (a != null) a.runOnUiThread(a::engAbort);
    }

    private static void loop(Context c, String first, boolean manual) {
        String id = first;
        boolean man = manual;
        while (id != null) {
            Flows.Flow f = Flows.byId(id);
            if (f != null) {
                try { runOne(c, f, man); }
                catch (Throwable e) { Dbg.d("flow: error " + e); }
            }
            synchronized (LK) {
                id = stop ? null : queue.poll();
                if (id == null) { running = false; queue.clear(); }
            }
            man = false;
        }
        Auto.cancel(c, Auto.N_RUN);
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { }
    }

    private static void runOne(Context c, Flows.Flow f, boolean manual) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
        Run r = new Run();
        r.f = f;
        r.manual = manual;
        r.wifi0 = wifiOn(c);
        r.data0 = dataOn(c);
        boolean on = pm != null && pm.isInteractive();
        boolean kl = km != null && km.isKeyguardLocked();
        r.locked0 = !on || kl;
        r.inUse0 = on && !kl;
        r.wasFg = MainActivity.fg;
        Dbg.d("flow: start " + f.name + " wifi0=" + r.wifi0 + " data0=" + r.data0 + " locked0=" + r.locked0
                + " inUse0=" + r.inUse0 + " appFg=" + r.wasFg);
        int n = f.steps.size();
        for (int i = 0; i < n && !stop; i++) {
            Flows.Step s = f.steps.get(i);
            if (!cond(c, r, s)) { Dbg.d("flow: skip " + (i + 1) + " " + s.type); continue; }
            Auto.note(c, Auto.N_RUN, f.name, (i + 1) + "/" + n + ": " + Flows.label(s), 1);
            Dbg.d("flow: block " + (i + 1) + " " + s.type);
            boolean go;
            try { go = exec(c, r, s, i); }
            catch (Throwable e) { Dbg.d("flow: block error " + e); go = true; }
            if (!go) break;
        }
        if (stop) r.userStop = true;
        Auto.cancel(c, Auto.N_RUN);
        int nid = 900 + Flows.num(f);
        if (r.userStop) {
            Auto.note(c, nid, "Stopped: " + f.name, "You stopped it. "
                    + (r.ok.length() > 0 ? "Already sent to: " + r.ok : "Nothing was sent.") + "\nTap OK to remove this.", 2);
        } else {
            StringBuilder sb = new StringBuilder();
            if (r.ok.length() > 0) sb.append("Sent to: ").append(r.ok);
            if (r.bad.length() > 0) sb.append(sb.length() > 0 ? "\n" : "").append("Not sent: ").append(r.bad);
            if (sb.length() == 0) sb.append(r.flowStop ? "Not sent: no internet" : "No send block ran.");
            if (r.flowStop) sb.append("\nStopped at block ").append(r.stopAt);
            String title = r.bad.length() == 0 && r.ok.length() > 0 ? "Sent: " + f.name
                    : r.ok.length() > 0 ? "Partly sent: " + f.name : "Not sent: " + f.name;
            Auto.note(c, nid, title, sb.toString(), 0);
        }
        Dbg.d("flow: end " + f.name + " ok=[" + r.ok + "] bad=[" + r.bad + "] userStop=" + r.userStop);
    }

    // ------------------------------------------------------------------ conditions
    private static boolean cond(Context c, Run r, Flows.Step s) {
        if (s.cond.isEmpty()) return true;
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
        boolean on = pm != null && pm.isInteractive();
        boolean kl = km != null && km.isKeyguardLocked();
        boolean v;
        switch (s.cond) {
            case "screen_on": v = on; break;
            case "locked": v = kl; break;
            case "in_use": v = on && !kl; break;
            case "wifi_on": v = wifiOn(c); break;
            case "wifi_up": v = wifiUp(c); break;
            case "data_on": v = dataOn(c); break;
            case "net_up": v = netUp(c); break;
            case "s_wifi": v = r.wifi0; break;
            case "s_data": v = r.data0; break;
            case "s_locked": v = r.locked0; break;
            case "s_use": v = r.inUse0; break;
            default: v = true;
        }
        return s.not ? !v : v;
    }

    private static boolean wifiOn(Context c) {
        try {
            WifiManager w = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            return w != null && w.isWifiEnabled();
        } catch (Throwable e) { return false; }
    }

    private static boolean dataOn(Context c) {
        try { return Settings.Global.getInt(c.getContentResolver(), "mobile_data", 1) == 1; }
        catch (Throwable e) { return false; }
    }

    private static boolean net(Context c, boolean wifiOnly) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc == null || !nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) continue;
                if (!wifiOnly || nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private static boolean wifiUp(Context c) { return net(c, true); }
    private static boolean netUp(Context c) { return net(c, false); }

    // ------------------------------------------------------------------ blocks
    private static void sleepMs(long ms) {
        long end = SystemClock.elapsedRealtime() + ms;
        while (!stop && SystemClock.elapsedRealtime() < end) {
            try { Thread.sleep(Math.min(300, Math.max(1, end - SystemClock.elapsedRealtime()))); }
            catch (InterruptedException e) { return; }
        }
    }

    private static String sh(String cmd) {
        if (!Sh.granted()) Sh.waitReady(6000);
        return Sh.run(cmd);
    }

    private static boolean screenOn(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isInteractive();
    }

    private static void wake(Context c) {
        if (!screenOn(c)) { sh("input keyevent 224"); sleepMs(900); }
    }

    private static boolean exec(Context c, Run r, Flows.Step s, int idx) {
        switch (s.type) {
            case "wake":
                wake(c);
                break;
            case "unlock": {
                wake(c);
                KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
                if (km != null && km.isKeyguardLocked()) {
                    String pt = Auto.pat(c);
                    if (pt.isEmpty()) Dbg.d("flow: phone is locked but no pattern is saved");
                    else { sh(Auto.unlockCmd(c, pt)); sleepMs(500); }
                }
                break;
            }
            case "wifi_on":
                Dbg.d("flow: wifi on " + sh("svc wifi enable"));
                sleepMs(1500);
                break;
            case "wifi_off":
                Dbg.d("flow: wifi off " + sh("svc wifi disable"));
                sleepMs(1000);
                break;
            case "data_on":
                Dbg.d("flow: data on " + sh("svc data enable"));
                sleepMs(1500);
                break;
            case "data_off":
                Dbg.d("flow: data off " + sh("svc data disable"));
                sleepMs(1000);
                break;
            case "wait_net": {
                long end = SystemClock.elapsedRealtime() + s.num * 1000L;
                while (!stop && !netUp(c) && SystemClock.elapsedRealtime() < end) sleepMs(1000);
                boolean up = netUp(c);
                Dbg.d("flow: internet=" + up);
                if (up) sleepMs(1500);
                break;
            }
            case "wait":
                sleepMs(s.num * 1000L);
                break;
            case "ask": {
                if (!ensureUi(c)) { Dbg.d("flow: no screen for the question, continuing"); break; }
                final MainActivity a = MainActivity.inst;
                if (a == null) break;
                final CountDownLatch l = new CountDownLatch(1);
                final boolean[] ok = { true };
                StringBuilder names = new StringBuilder();
                for (int k = idx + 1; k < r.f.steps.size(); k++) {
                    Flows.Step ns = r.f.steps.get(k);
                    if (ns.type.equals("send")) {
                        String x = Flows.target(r.f, ns).sname;
                        if (names.indexOf(x) < 0) names.append(names.length() > 0 ? ", " : "").append(x);
                    }
                }
                final String nm = names.length() > 0 ? names.toString() : r.f.sname;
                final int secs = s.num;
                a.runOnUiThread(() -> a.engAsk(nm, secs, v -> { ok[0] = v; l.countDown(); }));
                await(l, secs + 40);
                if (!ok[0]) { r.userStop = true; stop = true; synchronized (LK) { queue.clear(); } return false; }
                break;
            }
            case "send": {
                final Flows.Flow tg = Flows.target(r.f, s);
                boolean more = false;
                for (int k = idx + 1; k < r.f.steps.size(); k++) if (r.f.steps.get(k).type.equals("send")) more = true;
                if (!ensureUi(c)) { r.bad.append(r.bad.length() > 0 ? "\n" : "").append(tg.sname).append(" - could not open AB"); break; }
                final MainActivity a = MainActivity.inst;
                if (a == null) { r.bad.append(r.bad.length() > 0 ? "\n" : "").append(tg.sname).append(" - AB is not open"); break; }
                final CountDownLatch l = new CountDownLatch(1);
                final String[] out = { "FAILED: no answer" };
                final boolean keepFront = r.wasFg || more, man = r.manual;
                a.runOnUiThread(() -> a.engSend(tg, keepFront, man, v -> { out[0] = v; l.countDown(); }));
                if (!await(l, 360)) { a.runOnUiThread(a::engAbort); out[0] = "FAILED: timed out"; }
                if (out[0].startsWith("sent")) {
                    r.sent = true;
                    r.ok.append(r.ok.length() > 0 ? ", " : "").append(tg.sname);
                } else if (!stop) {
                    r.bad.append(r.bad.length() > 0 ? "\n" : "").append(tg.sname).append(" - ").append(out[0].replace("FAILED: ", ""));
                }
                break;
            }
            case "shortcut": {
                if (s.data.isEmpty()) { Dbg.d("flow: no shortcut chosen"); break; }
                if (Sh.granted() || Sh.waitReady(5000)) {
                    String q = s.data.replace("'", "'\\''");
                    Dbg.d("flow: shortcut " + s.label + " -> " + Sh.run("am start --user 0 '" + q + "'"));
                } else {
                    try {
                        Intent si = Intent.parseUri(s.data, Intent.URI_INTENT_SCHEME);
                        si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(si);
                    } catch (Throwable ex) { Dbg.d("flow: shortcut failed " + ex); }
                }
                sleepMs(2500);
                break;
            }
            case "lock":
                sh("input keyevent 26");
                sleepMs(1000);
                break;
            case "stop":
                r.flowStop = true;
                r.stopAt = idx + 1;
                return false;
            default:
                break;
        }
        return !stop;
    }

    private static boolean await(CountDownLatch l, int sec) {
        try { return l.await(sec, TimeUnit.SECONDS); } catch (InterruptedException e) { return false; }
    }

    /** Bring AR to the front (over the lock screen) and wait until it is really visible. */
    private static boolean ensureUi(Context c) {
        if (MainActivity.inst != null && MainActivity.fg) return true;
        if (Sh.granted() || Sh.waitReady(5000)) {
            Dbg.d("flow: open AR " + Sh.run("am start -n a.b/a.b.MainActivity --ez eng true"));
        } else {
            try {
                Intent i = new Intent(c, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("eng", true);
                c.startActivity(i);
            } catch (Throwable e) { Dbg.d("flow: direct start failed " + e); }
        }
        long end = SystemClock.elapsedRealtime() + 25000;
        while (!stop && SystemClock.elapsedRealtime() < end) {
            if (MainActivity.inst != null && MainActivity.fg) { sleepMs(800); return true; }
            sleepMs(300);
        }
        return MainActivity.inst != null && MainActivity.fg;
    }
}
