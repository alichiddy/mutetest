package a.c;

import android.content.ContentValues;
import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * "Make APK": copies the installed APK, replaces two asset files (tabs/settings and,
 * optionally, the stored sessions), signs it on the phone with the same key as the
 * normal build, verifies it, and saves it to Downloads.
 * Same key + same package name = installs over the old app as an update.
 */
final class Cloner {

    private static final String A_TABS = "assets/" + Bake.ASSET_TABS;
    private static final String A_SESS = "assets/" + Bake.ASSET_SESS;

    /** Returns a message for the user (success or failure). */
    static String make(Context c, String tabsJson, File sessions) {
        File cache = new File(c.getCacheDir(), "clone");
        try {
            Bake.deleteRec(cache);
            cache.mkdirs();
            File unsigned = new File(cache, "unsigned.apk");
            File signed = new File(cache, "signed.apk");

            rewrite(new File(c.getApplicationInfo().sourceDir), unsigned, tabsJson, sessions);
            String p = checkLayout(unsigned);
            if (p != null) throw new IllegalStateException("bad layout before signing: " + p);

            sign(c, unsigned, signed);

            ApkVerifier.Result r = new ApkVerifier.Builder(signed).build().verify();
            if (!r.isVerified()) throw new IllegalStateException("signature check failed: " + r.getErrors());
            p = checkLayout(signed);
            if (p != null) throw new IllegalStateException("bad layout after signing: " + p);
            if (c.getPackageManager().getPackageArchiveInfo(signed.getAbsolutePath(), 0) == null)
                throw new IllegalStateException("Android cannot read the new APK");

            String name = "AR-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date()) + ".apk";
            String where = save(c, signed, name);
            return "Done. Saved in " + where;
        } catch (Throwable e) {
            return "Failed: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            Bake.deleteRec(cache);
            if (sessions != null) sessions.delete();
        }
    }

    // ---------- copy the APK, swapping our two assets ----------

    private static void rewrite(File source, File target, String tabsJson, File sessions) throws Exception {
        try (ZipFile zip = new ZipFile(source); ZipOut out = new ZipOut(target)) {
            Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String n = e.getName();
                if (e.isDirectory() || isSignature(n) || n.equals(A_TABS) || n.equals(A_SESS)) continue;
                byte[] data;
                try (InputStream in = zip.getInputStream(e)) { data = Bake.readAll(in); }
                boolean stored = e.getMethod() == ZipEntry.STORED || n.equals("resources.arsc");
                int align = !stored ? 0 : (n.endsWith(".so") ? 16384 : 4);
                out.add(n, data, stored, align);
            }
            out.add(A_TABS, tabsJson.getBytes(StandardCharsets.UTF_8), false, 0);
            if (sessions != null) out.addFile(A_SESS, sessions);
        }
    }

    private static boolean isSignature(String n) {
        if (!n.startsWith("META-INF/")) return false;
        String u = n.toUpperCase(Locale.ROOT);
        return u.endsWith(".SF") || u.endsWith(".RSA") || u.endsWith(".DSA") || u.endsWith(".EC")
                || u.equals("META-INF/MANIFEST.MF") || u.startsWith("META-INF/CERT.");
    }

    // ---------- signing with the same key as the Gradle build ----------

    private static byte[] asset(Context c, String name) throws Exception {
        try (InputStream in = c.getAssets().open(name)) { return Bake.readAll(in); }
    }

    private static void sign(Context c, File input, File output) throws Exception {
        String alg = new String(asset(c, "signer_alg.txt"), StandardCharsets.UTF_8).trim();
        PrivateKey key = KeyFactory.getInstance(alg).generatePrivate(new PKCS8EncodedKeySpec(asset(c, "signer_key.der")));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509")
                .generateCertificate(new ByteArrayInputStream(asset(c, "signer_cert.der")));
        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("ar", key, Collections.singletonList(cert)).build();
        ApkSigner.Builder b = new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(input)
                .setOutputApk(output)
                .setV1SigningEnabled(true)
                .setV2SigningEnabled(true)
                .setV3SigningEnabled(true)
                .setV4SigningEnabled(false);
        try {   // keep the alignment we wrote (older apksig versions may not have this)
            b.getClass().getMethod("setAlignmentPreserved", boolean.class).invoke(b, true);
        } catch (Throwable ignored) { }
        b.build().sign();
    }

    // ---------- save to Downloads ----------

    private static String save(Context c, File f, String name) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive");
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            android.net.Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IllegalStateException("cannot create file in Downloads");
            try (OutputStream o = c.getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(f)) {
                copy(in, o);
            }
            return "Downloads/" + name;
        }
        File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File out = new File(dir, name);
        try (OutputStream o = new FileOutputStream(out); InputStream in = new FileInputStream(f)) { copy(in, o); }
        return out.getAbsolutePath();
    }

    private static void copy(InputStream in, OutputStream o) throws Exception {
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
    }

    // ---------- layout check: resources.arsc stored+aligned, .so stored+aligned ----------

    private static int i16(byte[] b, int o) { return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8); }
    private static long i32(byte[] b, int o) {
        return (b[o] & 0xffL) | ((b[o + 1] & 0xffL) << 8) | ((b[o + 2] & 0xffL) << 16) | ((b[o + 3] & 0xffL) << 24);
    }

    /** Returns null if fine, otherwise a description of the problem. */
    static String checkLayout(File apk) throws Exception {
        try (RandomAccessFile f = new RandomAccessFile(apk, "r")) {
            long len = f.length();
            int tail = (int) Math.min(len, 65557);
            byte[] t = new byte[tail];
            f.seek(len - tail);
            f.readFully(t);
            int eocd = -1;
            for (int i = tail - 22; i >= 0; i--) {
                if (t[i] == 0x50 && t[i + 1] == 0x4b && t[i + 2] == 0x05 && t[i + 3] == 0x06) { eocd = i; break; }
            }
            if (eocd < 0) return "no end-of-directory record";
            long cdSize = i32(t, eocd + 12);
            long cdOff = i32(t, eocd + 16);
            if (cdOff + cdSize > len) return "central directory out of range";
            byte[] cd = new byte[(int) cdSize];
            f.seek(cdOff);
            f.readFully(cd);
            int p = 0;
            while (p + 46 <= cd.length) {
                if (i32(cd, p) != 0x02014b50L) break;
                int method = i16(cd, p + 10);
                int nl = i16(cd, p + 28), el = i16(cd, p + 30), cl = i16(cd, p + 32);
                long lho = i32(cd, p + 42);
                String name = new String(cd, p + 46, nl, StandardCharsets.UTF_8);
                byte[] lh = new byte[30];
                f.seek(lho);
                f.readFully(lh);
                if (i32(lh, 0) != 0x04034b50L) return "bad local header for " + name;
                long dataOff = lho + 30 + i16(lh, 26) + i16(lh, 28);
                if (name.equals("resources.arsc")) {
                    if (method != 0) return "resources.arsc is compressed";
                    if (dataOff % 4 != 0) return "resources.arsc not 4-byte aligned";
                }
                if (name.endsWith(".so")) {
                    if (method != 0) return name + " is compressed";
                    if (dataOff % 4096 != 0) return name + " not page aligned";
                }
                p += 46 + nl + el + cl;
            }
        }
        return null;
    }

    // ---------- minimal zip writer (keeps stored/aligned entries exactly as we want) ----------

    private static final class ZipOut implements Closeable {
        private static final class Rec {
            byte[] name; int method; long crc, csize, usize, offset;
        }

        private final OutputStream o;
        private long pos = 0;
        private final ArrayList<Rec> recs = new ArrayList<>();

        ZipOut(File f) throws Exception { o = new FileOutputStream(f); }

        private void w(byte[] b) throws Exception { o.write(b); pos += b.length; }
        private static byte[] le16(int v) { return new byte[]{(byte) v, (byte) (v >> 8)}; }
        private static byte[] le32(long v) { return new byte[]{(byte) v, (byte) (v >> 8), (byte) (v >> 16), (byte) (v >> 24)}; }

        void add(String name, byte[] data, boolean stored, int align) throws Exception {
            byte[] nb = name.getBytes(StandardCharsets.UTF_8);
            CRC32 crc = new CRC32();
            crc.update(data);
            byte[] body = data;
            int method = 0;
            if (!stored) {
                Deflater d = new Deflater(6, true);
                d.setInput(data);
                d.finish();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] tmp = new byte[16384];
                while (!d.finished()) bo.write(tmp, 0, d.deflate(tmp));
                d.end();
                if (bo.size() < data.length) { body = bo.toByteArray(); method = 8; }
            }
            int pad = 0;
            if (align > 0) {
                long dataStart = pos + 30 + nb.length;
                pad = (int) ((align - (dataStart % align)) % align);
            }
            Rec r = new Rec();
            r.name = nb; r.method = method; r.crc = crc.getValue();
            r.csize = body.length; r.usize = data.length; r.offset = pos;
            w(le32(0x04034b50L)); w(le16(20)); w(le16(0x0800)); w(le16(method)); w(le16(0)); w(le16(0x2821));
            w(le32(r.crc)); w(le32(r.csize)); w(le32(r.usize)); w(le16(nb.length)); w(le16(pad));
            w(nb);
            if (pad > 0) w(new byte[pad]);
            w(body);
            recs.add(r);
        }

        /** Streams a (big) file in as a stored entry without loading it into memory. */
        void addFile(String name, File f) throws Exception {
            byte[] nb = name.getBytes(StandardCharsets.UTF_8);
            CRC32 crc = new CRC32();
            byte[] buf = new byte[65536];
            try (InputStream in = new FileInputStream(f)) {
                int n;
                while ((n = in.read(buf)) > 0) crc.update(buf, 0, n);
            }
            long size = f.length();
            Rec r = new Rec();
            r.name = nb; r.method = 0; r.crc = crc.getValue(); r.csize = size; r.usize = size; r.offset = pos;
            w(le32(0x04034b50L)); w(le16(20)); w(le16(0x0800)); w(le16(0)); w(le16(0)); w(le16(0x2821));
            w(le32(r.crc)); w(le32(size)); w(le32(size)); w(le16(nb.length)); w(le16(0));
            w(nb);
            try (InputStream in = new FileInputStream(f)) {
                int n;
                while ((n = in.read(buf)) > 0) { o.write(buf, 0, n); pos += n; }
            }
            recs.add(r);
        }

        @Override public void close() throws java.io.IOException {
            try {
                long cdStart = pos;
                for (Rec r : recs) {
                    w(le32(0x02014b50L)); w(le16(20)); w(le16(20)); w(le16(0x0800)); w(le16(r.method));
                    w(le16(0)); w(le16(0x2821)); w(le32(r.crc)); w(le32(r.csize)); w(le32(r.usize));
                    w(le16(r.name.length)); w(le16(0)); w(le16(0)); w(le16(0)); w(le16(0));
                    w(le32(0)); w(le32(r.offset)); w(r.name);
                }
                long cdSize = pos - cdStart;
                w(le32(0x06054b50L)); w(le16(0)); w(le16(0)); w(le16(recs.size())); w(le16(recs.size()));
                w(le32(cdSize)); w(le32(cdStart)); w(le16(0));
            } catch (java.io.IOException e) {
                throw e;
            } catch (Exception e) {
                throw new java.io.IOException(e);
            } finally {
                o.close();
            }
        }
    }
}
