package a.c;

import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.util.Calendar;
import java.util.Locale;

/** Scheduled "salute": one exact alarm (no service, no RAM while waiting). Config in its own prefs. */
public final class Auto {
    private Auto() { }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("auto", Context.MODE_PRIVATE); }

    static boolean on(Context c) { return p(c).getBoolean("on", false); }
    static String sid(Context c) { return p(c).getString("sid", ""); }
    static java.util.List<String> sids(Context c) {
        java.util.List<String> l = new java.util.ArrayList<>();
        for (String s : sid(c).split(",")) if (!s.trim().isEmpty()) l.add(s.trim());
        return l;
    }
    static int hour(Context c) { return p(c).getInt("h", 8); }
    static int min(Context c) { return p(c).getInt("m", 0); }
    static String msg(Context c) { return p(c).getString("msg", "Hi"); }
    static boolean daily(Context c) { return p(c).getBoolean("daily", true); }

    static String label(Context c) {
        if (!on(c)) return "OFF";
        return String.format(Locale.US, "%02d:%02d %s", hour(c), min(c), daily(c) ? "daily" : "once");
    }

    /** The alarm fires this broadcast (a receiver can run from the background; an activity cannot on Vivo). */
    private static PendingIntent firePi(Context c) {
        Intent i = new Intent(c, Fire.class);
        return PendingIntent.getBroadcast(c, 78, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Tapping the alarm icon in the status bar just opens the app. */
    private static PendingIntent showPi(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, 79, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static String pat(Context c) { return p(c).getString("pat", ""); }

    /** Sets (or clears) the alarm from the saved config. Safe to call any time. */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = firePi(c);
        am.cancel(pi);
        if (!on(c) || sid(c).isEmpty()) { Dbg.d("auto: alarm cleared"); return; }
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, hour(c));
        t.set(Calendar.MINUTE, min(c));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 5000) t.add(Calendar.DAY_OF_YEAR, 1);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(t.getTimeInMillis(), showPi(c)), pi);
            Dbg.d("auto: alarm set for " + t.getTime());
        } catch (Throwable e) { Dbg.d("auto: alarm failed " + e); }
    }

    /** After a run: daily -> next day, once -> off. */
    static void afterRun(Context c) {
        if (!daily(c)) p(c).edit().putBoolean("on", false).apply();
        schedule(c);
    }


    /** Alarm time: wake the phone, unlock it (pattern), open AR. All through Shizuku. Runs on a worker thread. */
    static void fire(Context c) {
        Dbg.d("auto: alarm fired");
        afterRun(c);
        if (!Sh.waitReady(6000)) {
            Dbg.d("auto: Shizuku not ready (running=" + Sh.running() + " granted=" + Sh.granted() + ")");
            try {
                Intent i = new Intent(c, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("auto", true);
                c.startActivity(i);
            } catch (Throwable e) { Dbg.d("auto: direct start failed " + e); }
            return;
        }
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
        boolean wake = pm != null && !pm.isInteractive();
        if (wake) {
            Sh.run("input keyevent 224");
            try { Thread.sleep(700); } catch (InterruptedException ignored) { }
        }
        boolean locked = km != null && km.isKeyguardLocked();
        StringBuilder sb = new StringBuilder();
        if (locked) {
            String pt = pat(c);
            if (pt.isEmpty()) Dbg.d("auto: phone is locked but no pattern saved");
            else sb.append(unlockCmd(c, pt));
        }
        sb.append("am start -n a.c/a.c.MainActivity --ez auto true --ez relock ").append(wake || locked);
        String out = Sh.run(sb.toString());
        Dbg.d("auto: wake=" + wake + " locked=" + locked + " shell: " + out);
    }

    /** Swipe up, then draw the pattern. Dot positions are fractions of the real screen (measured on 720x1600). */
    private static String unlockCmd(Context c, String pt) {
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int w = dm.widthPixels, h = dm.heightPixels;
        double[] fx = {0.225, 0.5, 0.772}, fy = {0.561, 0.684, 0.8075};
        StringBuilder sb = new StringBuilder();
        sb.append("input swipe ").append(w / 2).append(' ').append((int) (h * 0.78)).append(' ')
                .append(w / 2).append(' ').append((int) (h * 0.31)).append(" 200; sleep 0.5; ");
        int px = 0, py = 0;
        for (int k = 0; k < pt.length(); k++) {
            int d = pt.charAt(k) - '1';
            int x = (int) (w * fx[d % 3]), y = (int) (h * fy[d / 3]);
            if (k == 0) {
                sb.append("input motionevent DOWN ").append(x).append(' ').append(y).append("; ");
            } else {
                for (int s = 1; s <= 3; s++) {
                    sb.append("input motionevent MOVE ").append(px + (x - px) * s / 3).append(' ')
                            .append(py + (y - py) * s / 3).append("; ");
                }
            }
            px = x; py = y;
        }
        sb.append("input motionevent UP ").append(px).append(' ').append(py).append("; sleep 1; ");
        return sb.toString();
    }

    public static final class Fire extends BroadcastReceiver {
        @Override public void onReceive(final Context c, Intent i) {
            Dbg.init(c);
            final PendingResult pr = goAsync();
            new Thread(() -> {
                try { fire(c.getApplicationContext()); }
                catch (Throwable e) { Dbg.d("auto: fire error " + e); }
                finally { pr.finish(); }
            }).start();
        }
    }

    /** Alarms are lost on reboot: set it again. */
    public static final class Boot extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { schedule(c); }
    }
}
