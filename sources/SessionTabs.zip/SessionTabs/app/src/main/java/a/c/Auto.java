package a.c;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.Locale;

/** Scheduled "salute": one exact alarm (no service, no RAM while waiting). Config in its own prefs. */
final class Auto {
    private Auto() { }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("auto", Context.MODE_PRIVATE); }

    static boolean on(Context c) { return p(c).getBoolean("on", false); }
    static String sid(Context c) { return p(c).getString("sid", ""); }
    static int hour(Context c) { return p(c).getInt("h", 8); }
    static int min(Context c) { return p(c).getInt("m", 0); }
    static String msg(Context c) { return p(c).getString("msg", "Hi"); }
    static boolean daily(Context c) { return p(c).getBoolean("daily", true); }

    static String label(Context c) {
        if (!on(c)) return "OFF";
        return String.format(Locale.US, "%02d:%02d %s", hour(c), min(c), daily(c) ? "daily" : "once");
    }

    private static PendingIntent pi(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.putExtra("auto", true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Sets (or clears) the alarm from the saved config. Safe to call any time. */
    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pi(c);
        am.cancel(pi);
        if (!on(c) || sid(c).isEmpty()) { Dbg.d("auto: alarm cleared"); return; }
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, hour(c));
        t.set(Calendar.MINUTE, min(c));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis() + 5000) t.add(Calendar.DAY_OF_YEAR, 1);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(t.getTimeInMillis(), pi), pi);
            Dbg.d("auto: alarm set for " + t.getTime());
        } catch (Throwable e) { Dbg.d("auto: alarm failed " + e); }
    }

    /** After a run: daily -> next day, once -> off. */
    static void afterRun(Context c) {
        if (!daily(c)) p(c).edit().putBoolean("on", false).apply();
        schedule(c);
    }

    /** Alarms are lost on reboot: set it again. */
    static final class Boot extends BroadcastReceiver {
        @Override public void onReceive(Context c, Intent i) { schedule(c); }
    }
}
