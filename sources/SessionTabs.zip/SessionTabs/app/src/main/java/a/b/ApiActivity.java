package a.b;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * API chat for one session. The screen itself is assets/api.html (a local page); this class is only the
 * bridge it needs: private storage, file picker, clipboard, voice, streaming HTTPS and the account lookup.
 * Everything is stored under files/api/<session id>/ and goes into the normal backup zip.
 */
public class ApiActivity extends Activity {

    private static final int REQ_PICK = 21, REQ_MIC = 22;
    private static final long MAX_BIN = 25L * 1024 * 1024, MAX_TEXT = 8L * 1024 * 1024;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, HttpURLConnection> conns = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Boolean> aborted = new ConcurrentHashMap<>();
    private WebView web;
    private boolean dead = false;
    private String sid = "", name = "", url = "";
    private File dir;
    private String pickReq = "";
    private int attSeq = 0;

    // voice
    private SpeechRecognizer sr;
    private boolean voiceOn = false, voiceWantPerm = false;
    private String voiceLang = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        sid = in.getStringExtra("sid") == null ? "" : in.getStringExtra("sid");
        name = in.getStringExtra("name") == null ? "" : in.getStringExtra("name");
        url = in.getStringExtra("url") == null ? "" : in.getStringExtra("url");
        if (sid.isEmpty()) { finish(); return; }
        dir = new File(getFilesDir(), "api/" + safe(sid));
        new File(dir, "att").mkdirs();

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Throwable ignored) { }
                return true;   // never leave the local page
            }
        });
        web.setWebChromeClient(new WebChromeClient() {   // the page uses confirm() / prompt()
            @Override public boolean onJsConfirm(WebView v, String u, String msg, final JsResult r) {
                new AlertDialog.Builder(ApiActivity.this).setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
            @Override public boolean onJsPrompt(WebView v, String u, String msg, String def, final JsPromptResult r) {
                final EditText e = new EditText(ApiActivity.this);
                e.setText(def);
                new AlertDialog.Builder(ApiActivity.this).setTitle(msg).setView(e)
                        .setPositiveButton("OK", (d, w) -> r.confirm(e.getText().toString()))
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel()).show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AB");
        FrameLayout root = new FrameLayout(this);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        web.loadUrl("https://appassets.androidplatform.net/assets/api.html");
    }

    @Override
    public void onBackPressed() {
        if (web != null && !dead) web.evaluateJavascript("window.__back?window.__back():AB.close()", null);
        else finish();
    }

    @Override
    protected void onDestroy() {
        dead = true;
        voiceOn = false;
        try { if (sr != null) { sr.destroy(); sr = null; } } catch (Throwable ignored) { }
        for (String k : new ArrayList<>(conns.keySet())) {
            aborted.put(k, true);
            try { conns.get(k).disconnect(); } catch (Throwable ignored) { }
        }
        try { ui.removeCallbacksAndMessages(null); } catch (Throwable ignored) { }
        try { if (web != null) { web.destroy(); web = null; } } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private static String safe(String s) { return s.replaceAll("[^A-Za-z0-9_-]", "_"); }

    /** Runs on the UI thread: tell the page something happened. */
    private void emit(final JSONObject o) {
        ui.post(() -> {
            if (dead || web == null) return;
            web.evaluateJavascript("window.__n(" + JSONObject.quote(o.toString()) + ")", null);
        });
    }

    private void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show()); }

    // =====================================================================
    // the bridge the page can call (name: AB)
    // =====================================================================

    private final class Bridge {

        @JavascriptInterface public String info() {
            try {
                JSONObject o = new JSONObject();
                o.put("sid", sid);
                o.put("name", name);
                o.put("url", url);
                o.put("provider", Report.provider(url));
                try (InputStream in = getAssets().open("api_seed.json")) {
                    JSONObject seed = new JSONObject(new String(Bake.readAll(in), StandardCharsets.UTF_8));
                    JSONObject mine = seed.optJSONObject(sid);
                    if (mine != null) o.put("seed", mine);
                } catch (Throwable ignored) { }
                return o.toString();
            } catch (Throwable e) {
                return "{}";
            }
        }

        @JavascriptInterface public String load(String key) {
            try {
                File f = new File(dir, safe(key) + ".json");
                if (!f.isFile()) return "";
                try (InputStream in = new FileInputStream(f)) { return new String(Bake.readAll(in), StandardCharsets.UTF_8); }
            } catch (Throwable e) {
                return "";
            }
        }

        @JavascriptInterface public boolean save(String key, String val) {
            try {
                File f = new File(dir, safe(key) + ".json");
                File t = new File(dir, safe(key) + ".tmp");
                try (OutputStream o = new FileOutputStream(t)) { o.write(val.getBytes(StandardCharsets.UTF_8)); }
                if (f.exists() && !f.delete()) return false;
                return t.renameTo(f);
            } catch (Throwable e) {
                return false;
            }
        }

        @JavascriptInterface public void del(String key) {
            try { new File(dir, safe(key) + ".json").delete(); } catch (Throwable ignored) { }
        }

        @JavascriptInterface public void delAtt(String id) {
            try { new File(dir, "att/" + safe(id)).delete(); } catch (Throwable ignored) { }
        }

        @JavascriptInterface public void copy(final String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("AB", text));
                    Toast.makeText(ApiActivity.this, "Copied", Toast.LENGTH_SHORT).show();
                } catch (Throwable e) {
                    Toast.makeText(ApiActivity.this, "Too long to copy. Use Export instead.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public String clip() {
            final String[] r = {""};
            final CountDownLatch l = new CountDownLatch(1);
            runOnUiThread(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData d = cm.getPrimaryClip();
                    if (d != null && d.getItemCount() > 0) {
                        CharSequence t = d.getItemAt(0).coerceToText(ApiActivity.this);
                        if (t != null) r[0] = t.toString();
                    }
                } catch (Throwable ignored) { }
                l.countDown();
            });
            try { l.await(3, TimeUnit.SECONDS); } catch (Exception ignored) { }
            return r[0];
        }

        @JavascriptInterface public void toast(String m) { ApiActivity.this.toast(m); }

        @JavascriptInterface public void close() { runOnUiThread(ApiActivity.this::finish); }

        @JavascriptInterface public String export(String fileName, String text) {
            try {
                String n = fileName.replaceAll("[^A-Za-z0-9._ -]", "_");
                if (n.isEmpty()) n = "chat.txt";
                return Report.save(ApiActivity.this, n, "text/plain", text.getBytes(StandardCharsets.UTF_8));
            } catch (Throwable e) {
                return "";
            }
        }

        // ---------------- files ----------------
        @JavascriptInterface public void pick(final String req) {
            runOnUiThread(() -> {
                try {
                    pickReq = req;
                    Intent in = new Intent(Intent.ACTION_GET_CONTENT);
                    in.addCategory(Intent.CATEGORY_OPENABLE);
                    in.setType("*/*");
                    in.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(in, REQ_PICK);
                } catch (Throwable e) {
                    Toast.makeText(ApiActivity.this, "No file picker found.", Toast.LENGTH_LONG).show();
                }
            });
        }

        // ---------------- network ----------------
        @JavascriptInterface public void stream(final String reqId, final String method, final String urlStr,
                                                final String headersJson, final String body) {
            new Thread(() -> doStream(reqId, method, urlStr, headersJson, body), "api-" + reqId).start();
        }

        @JavascriptInterface public void abort(String reqId) {
            aborted.put(reqId, true);
            HttpURLConnection c = conns.get(reqId);
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) { } }
        }

        // ---------------- voice ----------------
        @JavascriptInterface public void voice(final boolean on, final String lang) {
            runOnUiThread(() -> {
                voiceLang = lang == null ? "" : lang;
                if (!on) { stopVoice(); return; }
                if (!SpeechRecognizer.isRecognitionAvailable(ApiActivity.this)) {
                    emit(j("t", "voicestop", "d", "Speech recognition is not available on this phone (install / enable the Google app)."));
                    return;
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    voiceWantPerm = true;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    return;
                }
                startVoice();
            });
        }

        // ---------------- account ----------------
        @JavascriptInterface public void account(final String kind) {
            runOnUiThread(() -> {
                boolean ok = false;
                try { ok = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE); } catch (Throwable ignored) { }
                Report.probeOne(ApiActivity.this, ok, sid, kind, r -> {
                    JSONObject o = new JSONObject();
                    try { o.put("t", "acct"); o.put("kind", kind); o.put("d", r); } catch (Throwable ignored) { }
                    emit(o);
                });
            });
        }
    }

    private static JSONObject j(String... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i + 1 < kv.length; i += 2) o.put(kv[i], kv[i + 1]); } catch (Throwable ignored) { }
        return o;
    }

    // =====================================================================
    // streaming HTTPS: relays the raw answer text to the page, which parses it
    // =====================================================================

    private void doStream(String reqId, String method, String urlStr, String headersJson, String body) {
        final StringBuilder pending = new StringBuilder();
        final boolean[] scheduled = {false};
        final Runnable flush = new Runnable() {
            @Override public void run() {
                String d;
                synchronized (pending) {
                    d = pending.toString();
                    pending.setLength(0);
                    scheduled[0] = false;
                }
                if (d.isEmpty() || dead || web == null) return;
                JSONObject o = j("t", "net", "id", reqId, "k", "data", "d", d);
                web.evaluateJavascript("window.__n(" + JSONObject.quote(o.toString()) + ")", null);
            }
        };
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(urlStr).openConnection();
            conns.put(reqId, c);
            c.setRequestMethod(method);
            c.setConnectTimeout(20000);
            c.setReadTimeout(600000);
            JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
            Iterator<String> it = h.keys();
            while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, h.optString(k)); }
            if (body != null && !body.isEmpty()) {
                c.setDoOutput(true);
                c.setChunkedStreamingMode(0);
                try (OutputStream os = c.getOutputStream()) { writeBody(os, body); }
            }
            int code = c.getResponseCode();
            emit(j("t", "net", "id", reqId, "k", "status", "d", String.valueOf(code)));
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                try (InputStreamReader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                    char[] buf = new char[4096];
                    int n;
                    while ((n = r.read(buf)) > 0) {
                        synchronized (pending) {
                            pending.append(buf, 0, n);
                            if (!scheduled[0]) { scheduled[0] = true; ui.postDelayed(flush, 30); }
                        }
                    }
                }
            }
            ui.post(() -> { flush.run(); emit(j("t", "net", "id", reqId, "k", "end")); });
        } catch (final Throwable e) {
            final boolean ab = aborted.containsKey(reqId);
            ui.post(() -> {
                flush.run();
                if (ab) emit(j("t", "net", "id", reqId, "k", "end", "d", "aborted"));
                else emit(j("t", "net", "id", reqId, "k", "err", "d", e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage())));
            });
        } finally {
            conns.remove(reqId);
            aborted.remove(reqId);
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) { } }
        }
    }

    /** Writes the JSON body; every @@F:id@@ token becomes the base64 of that saved attachment (streamed, never fully in memory). */
    private void writeBody(OutputStream os, String body) throws Exception {
        int i = 0;
        while (true) {
            int k = body.indexOf("@@F:", i);
            if (k < 0) { os.write(body.substring(i).getBytes(StandardCharsets.UTF_8)); return; }
            int e = body.indexOf("@@", k + 4);
            if (e < 0) { os.write(body.substring(i).getBytes(StandardCharsets.UTF_8)); return; }
            String id = body.substring(k + 4, e);
            File f = new File(dir, "att/" + safe(id));
            if (!id.matches("[A-Za-z0-9]+") || !f.isFile()) {   // not ours: leave the text as it is
                os.write(body.substring(i, e + 2).getBytes(StandardCharsets.UTF_8));
                i = e + 2;
                continue;
            }
            os.write(body.substring(i, k).getBytes(StandardCharsets.UTF_8));
            try (InputStream in = new FileInputStream(f)) {
                byte[] buf = new byte[3 * 16384];
                while (true) {
                    int got = 0, r;
                    while (got < buf.length && (r = in.read(buf, got, buf.length - got)) > 0) got += r;
                    if (got <= 0) break;
                    os.write(Base64.encode(buf, 0, got, Base64.NO_WRAP));
                    if (got < buf.length) break;
                }
            }
            i = e + 2;
        }
    }

    // =====================================================================
    // file picker result
    // =====================================================================

    @Override
    protected void onActivityResult(int rq, int rs, final Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq != REQ_PICK) return;
        final String req = pickReq;
        final ArrayList<Uri> uris = new ArrayList<>();
        if (rs == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
        }
        if (uris.isEmpty()) { emit(j("t", "picked", "id", req, "files", "[]")); return; }
        new Thread(() -> {
            JSONArray out = new JSONArray();
            for (Uri u : uris) {
                try { out.put(readPicked(u)); } catch (Throwable e) {
                    try { out.put(new JSONObject().put("name", "file").put("kind", "error").put("err", String.valueOf(e.getMessage()))); } catch (Throwable ignored) { }
                }
            }
            JSONObject o = new JSONObject();
            try { o.put("t", "picked"); o.put("id", req); o.put("files", out); } catch (Throwable ignored) { }
            emit(o);
        }).start();
    }

    private JSONObject readPicked(Uri u) throws Exception {
        String nm = "file";
        long size = -1;
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0 && c.getString(ni) != null) nm = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Throwable ignored) { } finally { if (c != null) c.close(); }
        String mime = getContentResolver().getType(u);
        String lower = nm.toLowerCase(Locale.ROOT);
        String ext = lower.contains(".") ? lower.substring(lower.lastIndexOf('.') + 1) : "";
        if (mime == null || mime.equals("application/octet-stream")) {
            String m2 = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            if (m2 != null) mime = m2;
        }
        if (mime == null) mime = "application/octet-stream";
        JSONObject o = new JSONObject();
        o.put("name", nm);
        o.put("mime", mime);
        String id = Long.toString(System.nanoTime(), 36) + (attSeq++);
        id = id.replaceAll("[^A-Za-z0-9]", "");
        o.put("id", id);
        boolean image = mime.equals("image/jpeg") || mime.equals("image/png") || mime.equals("image/gif") || mime.equals("image/webp");
        boolean pdf = mime.equals("application/pdf") || ext.equals("pdf");
        File dst = new File(dir, "att/" + id);
        ByteArrayOutputStream mem = (image || pdf) ? null : new ByteArrayOutputStream();
        long total = 0;
        try (InputStream in = getContentResolver().openInputStream(u);
             OutputStream out = (mem == null) ? new FileOutputStream(dst) : mem) {
            byte[] buf = new byte[65536];
            int n;
            long limit = mem == null ? MAX_BIN : MAX_TEXT;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > limit) { o.put("kind", "toolarge"); o.put("size", total); dst.delete(); return o; }
                out.write(buf, 0, n);
            }
        }
        o.put("size", total);
        if (image) { o.put("kind", "image"); return o; }
        if (pdf) { o.put("kind", "pdf"); return o; }
        byte[] all = mem.toByteArray();
        for (int i = 0; i < Math.min(all.length, 8000); i++) if (all[i] == 0) { o.put("kind", "bin"); return o; }
        o.put("kind", "text");
        o.put("text", new String(all, StandardCharsets.UTF_8));
        return o;
    }

    // =====================================================================
    // voice (speech to text, keeps listening until you stop it)
    // =====================================================================

    @Override
    public void onRequestPermissionsResult(int rq, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rq, perms, res);
        if (rq != REQ_MIC) return;
        boolean ok = res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED;
        if (ok && voiceWantPerm) startVoice();
        else emit(j("t", "voicestop", "d", "Microphone permission is off for this app."));
        voiceWantPerm = false;
    }

    private void startVoice() {
        voiceOn = true;
        listenOnce();
    }

    private void stopVoice() {
        voiceOn = false;
        try { if (sr != null) { sr.cancel(); sr.destroy(); sr = null; } } catch (Throwable ignored) { }
        emit(j("t", "voicestop", "d", ""));
    }

    private void listenOnce() {
        if (!voiceOn || dead) return;
        try {
            if (sr != null) { try { sr.destroy(); } catch (Throwable ignored) { } }
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle p) { emit(j("t", "voicestate", "d", "listening")); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onEvent(int t, Bundle p) { }
                @Override public void onPartialResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) emit(j("t", "voice", "d", l.get(0), "fin", "0"));
                }
                @Override public void onResults(Bundle b) {
                    ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l != null && !l.isEmpty()) emit(j("t", "voice", "d", l.get(0), "fin", "1"));
                    ui.postDelayed(ApiActivity.this::listenOnce, 150);
                }
                @Override public void onError(int err) {
                    if (!voiceOn) return;
                    if (err == SpeechRecognizer.ERROR_NO_MATCH || err == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        ui.postDelayed(ApiActivity.this::listenOnce, 150);
                    } else if (err == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        ui.postDelayed(ApiActivity.this::listenOnce, 600);
                    } else {
                        voiceOn = false;
                        emit(j("t", "voicestop", "d", "Voice stopped (error " + err + "). Check internet / the Google app."));
                    }
                }
            });
            Intent in = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            in.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            in.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            in.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            if (!voiceLang.isEmpty()) in.putExtra(RecognizerIntent.EXTRA_LANGUAGE, voiceLang);
            sr.startListening(in);
        } catch (Throwable e) {
            voiceOn = false;
            emit(j("t", "voicestop", "d", "Voice failed: " + e.getClass().getSimpleName()));
        }
    }
}
