package a.b;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;

/**
 * READABLE backup: everything in the app written as plain JSON + a short text summary, so a person
 * (or Claude) can read it. Unlike Backup (a binary zip that restores logins), this cannot restore anything.
 *
 * SAFE mode : cookie NAMES only (no values), no phone unlock pattern. Fine to send to Claude.
 * FULL mode : also cookie values + unlock pattern = live logins. Private.
 *
 * It also opens every signed-in Claude / ChatGPT session in an invisible WebView and reads which account
 * it is (email, name, organizations). Tokens are never saved.
 */
final class Report {
    private Report() { }

    interface Progress { void say(String s); }
    interface Done { void done(String where, String error); }

    private static final String[] HOSTS = {
            "https://accounts.google.com/", "https://www.google.com/", "https://myaccount.google.com/",
            "https://accounts.youtube.com/", "https://www.youtube.com/", "https://mail.google.com/",
            "https://aistudio.google.com/", "https://gemini.google.com/",
            "https://claude.ai/", "https://www.claude.ai/", "https://api.claude.ai/", "https://claude.com/",
            "https://platform.claude.com/", "https://console.anthropic.com/", "https://www.anthropic.com/",
            "https://chatgpt.com/", "https://chat.openai.com/", "https://auth.openai.com/",
            "https://platform.openai.com/", "https://openai.com/",
            "https://chat.qwen.ai/", "https://qwen.ai/", "https://www.qwen.ai/", "https://tongyi.aliyun.com/",
            "https://www.qianwen.com/", "https://qianwen.com/",
            "https://login.microsoftonline.com/", "https://login.live.com/", "https://account.microsoft.com/",
            "https://outlook.live.com/", "https://www.office.com/", "https://www.bing.com/",
            "https://github.com/"
    };

    private static final String[] COLORS = {"none", "red", "green", "blue"};

    // =====================================================================
    // entry point (UI thread)
    // =====================================================================

    static void run(final Activity a, final Store store, final boolean profilesOk, final boolean withValues,
                    final Progress prog, final Done done) {
        final JSONObject cookieInfo = new JSONObject();
        final ArrayList<String[]> probes = new ArrayList<>();   // {sessionId, kind}
        prog.say("Reading cookies...");
        try {
            for (Store.Tab t : store.all()) {
                try {
                    JSONObject o = collect(t, profilesOk, withValues);
                    cookieInfo.put(t.id, o);
                    if (o.optBoolean("claude_signed_in")) probes.add(new String[]{t.id, "claude"});
                    if (o.optBoolean("chatgpt_signed_in")) probes.add(new String[]{t.id, "chatgpt"});
                } catch (Throwable e) {
                    Dbg.d("report: cookies of " + t.id + " failed: " + e);
                }
            }
        } catch (Throwable e) {
            Dbg.d("report: cookies failed: " + e);
        }
        final JSONObject probeRes = new JSONObject();   // sessionId -> { claude: {...}, chatgpt: {...} }
        nextProbe(a, store, profilesOk, probes, 0, probeRes, prog,
                () -> finish(a, store, withValues, cookieInfo, probeRes, done));
    }

    // =====================================================================
    // cookies
    // =====================================================================

    private static String hostOf(String u) {
        try {
            String h = Uri.parse(u).getHost();
            return h == null ? "" : h.toLowerCase(Locale.ROOT);
        } catch (Throwable e) {
            return "";
        }
    }

    private static void addOrigin(LinkedHashSet<String> urls, String u) {
        if (u == null || !u.startsWith("http")) return;
        String h = hostOf(u);
        if (h.isEmpty()) return;
        urls.add((u.startsWith("http://") ? "http://" : "https://") + h + "/");
    }

    private static JSONObject collect(Store.Tab t, boolean profilesOk, boolean withValues) throws Exception {
        JSONObject o = new JSONObject();
        CookieManager cm = profilesOk
                ? ProfileStore.getInstance().getOrCreateProfile(t.id).getCookieManager()
                : CookieManager.getInstance();
        LinkedHashSet<String> urls = new LinkedHashSet<>(Arrays.asList(HOSTS));
        addOrigin(urls, t.url);
        for (String[] c : t.chats) addOrigin(urls, c[0]);
        JSONArray groups = new JSONArray();
        boolean claude = false, chatgpt = false, google = false, qwen = false;
        String org = "";
        int total = 0;
        for (String u : urls) {
            String ck = cm.getCookie(u);
            if (ck == null || ck.isEmpty()) continue;
            String host = hostOf(u);
            JSONArray list = new JSONArray();
            for (String kv : ck.split(";\\s*")) {
                if (kv.isEmpty()) continue;
                int i = kv.indexOf('=');
                String n = i > 0 ? kv.substring(0, i) : kv;
                String v = i > 0 ? kv.substring(i + 1) : "";
                JSONObject c = new JSONObject();
                c.put("name", n);
                c.put("value_length", v.length());
                if (withValues) c.put("value", v);
                list.put(c);
                total++;
                if (host.endsWith("claude.ai") && n.equals("sessionKey")) claude = true;
                if (host.endsWith("claude.ai") && n.equals("lastActiveOrg") && org.isEmpty()) org = v;   // organization id, not a secret
                if ((host.endsWith("chatgpt.com") || host.endsWith("openai.com")) && n.contains("session-token")) chatgpt = true;
                if (host.contains("google") && (n.equals("SID") || n.equals("__Secure-1PSID") || n.equals("SAPISID"))) google = true;
                if (host.contains("qwen") || host.contains("qianwen") || host.contains("tongyi")) qwen = true;
            }
            JSONObject g = new JSONObject();
            g.put("url", u);
            g.put("count", list.length());
            g.put("cookies", list);
            groups.put(g);
        }
        o.put("claude_signed_in", claude);          // a sessionKey cookie exists on claude.ai
        o.put("claude_last_active_org_id", org);
        o.put("chatgpt_signed_in", chatgpt);        // a session-token cookie exists on chatgpt.com / openai.com
        o.put("google_cookies_present", google);    // Google login cookies (SID...) exist
        o.put("qwen_cookies_present", qwen);        // any cookie exists on a Qwen host
        o.put("total_cookies", total);
        o.put("groups", groups);
        return o;
    }

    // =====================================================================
    // which account is this session? (invisible WebView, one at a time)
    // =====================================================================

    private static Store.Tab findTab(Store store, String id) {
        for (Store.Tab t : store.all()) if (t.id.equals(id)) return t;
        return null;
    }

    private static void nextProbe(final Activity a, final Store store, final boolean profilesOk,
                                  final ArrayList<String[]> q, final int i, final JSONObject out,
                                  final Progress prog, final Runnable then) {
        if (i >= q.size()) { then.run(); return; }
        final String[] p = q.get(i);
        final Store.Tab t = findTab(store, p[0]);
        if (t == null) { nextProbe(a, store, profilesOk, q, i + 1, out, prog, then); return; }
        prog.say("Reading which account is signed in " + (i + 1) + "/" + q.size() + "\n" + t.name + " (" + p[1] + ")");
        probeOne(a, profilesOk, t, p[1], r -> {
            try {
                JSONObject s = out.optJSONObject(t.id);
                if (s == null) { s = new JSONObject(); out.put(t.id, s); }
                s.put(p[1], r);
            } catch (Throwable ignored) { }
            nextProbe(a, store, profilesOk, q, i + 1, out, prog, then);
        });
    }

    private static void probeOne(final Activity a, final boolean profilesOk, final Store.Tab t, final String kind,
                                 final java.util.function.Consumer<JSONObject> cb) {
        final JSONObject res = new JSONObject();
        final boolean[] fin = {false};
        final WebView[] box = new WebView[1];
        final Handler h = new Handler(Looper.getMainLooper());
        final String url = kind.equals("claude") ? "https://claude.ai/api/account" : "https://chatgpt.com/api/auth/session";
        final Runnable end = new Runnable() {
            @Override public void run() {
                if (fin[0]) return;
                fin[0] = true;
                h.removeCallbacksAndMessages(null);
                try { if (box[0] != null) { box[0].stopLoading(); box[0].destroy(); } } catch (Throwable ignored) { }
                cb.accept(res);
            }
        };
        try {
            res.put("status", "timeout (page did not answer in 20 s)");
            WebView w = new WebView(a);
            box[0] = w;
            if (profilesOk) {
                ProfileStore.getInstance().getOrCreateProfile(t.id);
                WebViewCompat.setProfile(w, t.id);   // before any other call on this WebView
            }
            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(final WebView v, final String u) {
                    if (fin[0]) return;
                    v.evaluateJavascript("(function(){try{return document.body?document.body.innerText:''}catch(e){return ''}})()", r -> {
                        if (fin[0]) return;
                        if (parse(kind, u, unquote(r), res)) end.run();
                    });
                }
            });
            h.postDelayed(end, 20000);
            w.loadUrl(url);
        } catch (Throwable e) {
            try { res.put("status", "error: " + e.getClass().getSimpleName()); } catch (Throwable ignored) { }
            end.run();
        }
    }

    private static String unquote(String r) {
        if (r == null) return "";
        try {
            Object v = new JSONTokener(r).nextValue();
            return v instanceof String ? (String) v : "";
        } catch (Throwable e) {
            return "";
        }
    }

    private static String str(JSONObject j, String k) {
        if (j == null || j.isNull(k)) return "";
        return j.optString(k, "");
    }

    /** true = the answer is final; false = keep waiting (a check page may still redirect to the real answer). */
    private static boolean parse(String kind, String pageUrl, String txt, JSONObject res) {
        try {
            String host = hostOf(pageUrl);
            res.put("final_host", host);
            String t = txt == null ? "" : txt.trim();
            if (!t.startsWith("{")) {
                res.put("status", "not JSON (login page or Cloudflare check?)");
                res.put("page_text_start", t.length() > 120 ? t.substring(0, 120) : t);
                return false;
            }
            res.remove("page_text_start");
            JSONObject j = new JSONObject(t);
            if (kind.equals("claude")) {
                String email = str(j, "email_address");
                if (email.isEmpty()) email = str(j, "email");
                res.put("email", email);
                res.put("name", str(j, "full_name"));
                res.put("account_uuid", str(j, "uuid"));
                JSONArray orgs = new JSONArray();
                JSONArray ms = j.optJSONArray("memberships");
                if (ms != null) for (int k = 0; k < ms.length(); k++) {
                    JSONObject m = ms.optJSONObject(k);
                    JSONObject o = m == null ? null : m.optJSONObject("organization");
                    if (o == null) continue;
                    JSONObject x = new JSONObject();
                    x.put("uuid", str(o, "uuid"));
                    x.put("name", str(o, "name"));
                    x.put("rate_limit_tier", str(o, "rate_limit_tier"));
                    x.put("billing_type", str(o, "billing_type"));
                    x.put("role", str(m, "role"));
                    JSONArray caps = o.optJSONArray("capabilities");
                    if (caps != null) x.put("capabilities", caps);
                    orgs.put(x);
                }
                res.put("organizations", orgs);
                if (!email.isEmpty()) {
                    res.put("status", "ok");
                } else {
                    JSONArray keys = new JSONArray();
                    Iterator<String> it = j.keys();
                    while (it.hasNext()) keys.put(it.next());
                    res.put("status", "JSON without an email (logged out, or a different format)");
                    res.put("json_keys", keys);
                }
                return true;
            }
            // chatgpt: only name / email / id of the user. The access token in the same answer is never read or saved.
            JSONObject u = j.optJSONObject("user");
            if (u != null) {
                res.put("email", str(u, "email"));
                res.put("name", str(u, "name"));
                res.put("user_id", str(u, "id"));
                res.put("status", "ok");
            } else {
                res.put("status", "not signed in (empty answer)");
            }
            return true;
        } catch (Throwable e) {
            try { res.put("status", "could not read the answer: " + e.getClass().getSimpleName()); } catch (Throwable ignored) { }
            return false;
        }
    }

    // =====================================================================
    // build the files (background thread)
    // =====================================================================

    private static void finish(final Activity a, final Store store, final boolean withValues,
                               final JSONObject cookieInfo, final JSONObject probeRes, final Done done) {
        new Thread(() -> {
            String where = null, err = null;
            try {
                JSONObject root = build(a, store, withValues, cookieInfo, probeRes);
                String json = root.toString(2);
                String txt = summary(root);
                String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date());
                String base = "AR-readable-" + (withValues ? "FULL-PRIVATE-" : "SAFE-") + stamp;
                String w1 = save(a, base + ".json", "application/json", json.getBytes(StandardCharsets.UTF_8));
                String w2 = save(a, base + ".txt", "text/plain", txt.getBytes(StandardCharsets.UTF_8));
                where = w1 + "\n" + w2;
            } catch (Throwable e) {
                err = e.getClass().getSimpleName() + ": " + e.getMessage();
            }
            final String w = where, er = err;
            a.runOnUiThread(() -> done.done(w, er));
        }).start();
    }

    private static String fmt(long ms) {
        if (ms <= 0) return "";
        return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(ms));
    }

    private static String provider(String u) {
        String h = hostOf(u);
        if (h.contains("claude.ai") || h.contains("claude.com") || h.contains("anthropic")) return "claude";
        if (h.contains("chatgpt") || h.contains("openai")) return "chatgpt";
        if (h.contains("qwen") || h.contains("qianwen") || h.contains("tongyi")) return "qwen";
        if (h.contains("gemini.google") || h.contains("aistudio")) return "gemini";
        if (h.contains("google") || h.contains("youtube")) return "google";
        return h.isEmpty() ? "unknown" : h;
    }

    private static JSONObject appInfo(Context c) {
        JSONObject o = new JSONObject();
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            o.put("package", c.getPackageName());
            o.put("version_name", pi.versionName);
            o.put("version_code", pi.versionCode);
        } catch (Throwable ignored) { }
        try {
            o.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            o.put("android", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
        } catch (Throwable ignored) { }
        try {
            PackageInfo w = WebViewCompat.getCurrentWebViewPackage(c);
            if (w != null) o.put("webview", w.packageName + " " + w.versionName);
        } catch (Throwable ignored) { }
        return o;
    }

    private static String mainName(Store store, int grp) {
        for (Store.Tab t : store.all()) if (t.main && t.grp == grp) return t.name;
        return "";
    }

    private static JSONObject sessionJson(Context c, Store store, Store.Tab t, boolean removed,
                                          JSONObject cookies, JSONObject probe) throws Exception {
        JSONObject j = new JSONObject();
        j.put("id", t.id);
        j.put("name", t.name);
        j.put("in_list", !removed);
        j.put("url", t.url);
        j.put("host", hostOf(t.url));
        j.put("provider_by_url", provider(t.url));
        j.put("folder", t.folder);
        j.put("color_mark", COLORS[Math.max(0, Math.min(3, t.color))]);
        j.put("is_main_google_session", t.main);
        if (t.main) j.put("main_number", t.grp);
        j.put("google_accounts_copied_from", t.link ? mainName(store, t.grp) : "");
        j.put("keep_page_alive", t.pin == 0 ? "auto" : t.pin == 1 ? "on" : "off");
        j.put("limit_until", fmt(t.limitUntil));
        j.put("last_used", fmt(t.lastUsed));
        j.put("automation_on_limit", Auto.limitAuto(c, t.id));
        j.put("automation_mark", Auto.mark(c, t.id));
        JSONArray chats = new JSONArray();
        for (String[] ch : t.chats) {
            JSONObject x = new JSONObject();
            x.put("url", ch[0]);
            x.put("title", ch[1]);
            long when = 0;
            try { when = Long.parseLong(ch[2]); } catch (Exception ignored) { }
            x.put("time", fmt(when));
            chats.put(x);
        }
        j.put("recent_chats", chats);
        if (cookies != null) j.put("cookies", cookies);
        if (probe != null) j.put("accounts_read", probe);
        return j;
    }

    private static JSONObject accounts(Store store, JSONObject probeRes) throws Exception {
        JSONObject acc = new JSONObject();
        for (String kind : new String[]{"claude", "chatgpt"}) {
            LinkedHashMap<String, ArrayList<String>> by = new LinkedHashMap<>();
            LinkedHashMap<String, JSONObject> first = new LinkedHashMap<>();
            ArrayList<String> unread = new ArrayList<>();
            for (Store.Tab t : store.all()) {
                JSONObject s = probeRes.optJSONObject(t.id);
                JSONObject r = s == null ? null : s.optJSONObject(kind);
                if (r == null) continue;
                String em = r.optString("email", "");
                if (em.isEmpty()) { unread.add(t.name); continue; }
                ArrayList<String> l = by.get(em);
                if (l == null) { l = new ArrayList<>(); by.put(em, l); first.put(em, r); }
                l.add(t.name);
            }
            JSONArray list = new JSONArray();
            for (Map.Entry<String, ArrayList<String>> e : by.entrySet()) {
                JSONObject x = new JSONObject();
                JSONObject r = first.get(e.getKey());
                x.put("email", e.getKey());
                x.put("name", r.optString("name", ""));
                if (r.optJSONArray("organizations") != null) x.put("organizations", r.optJSONArray("organizations"));
                x.put("sessions", new JSONArray(e.getValue()));
                list.put(x);
            }
            JSONObject k = new JSONObject();
            k.put("different_accounts", by.size());
            k.put("accounts", list);
            k.put("signed_in_but_account_not_read", new JSONArray(unread));
            acc.put(kind, k);
        }
        JSONObject g = new JSONObject();
        JSONArray mains = new JSONArray(), linked = new JSONArray();
        for (Store.Tab t : store.all()) {
            if (t.main) mains.put("MAIN " + t.grp + ": " + t.name);
            else if (t.link) linked.put(t.name + " <- MAIN " + t.grp + " (" + mainName(store, t.grp) + ")");
        }
        g.put("main_sessions", mains);
        g.put("linked_sessions", linked);
        g.put("note", "How many Google accounts a MAIN session holds cannot be read from outside the page.");
        acc.put("google", g);
        return acc;
    }

    private static JSONObject build(Context c, Store store, boolean withValues,
                                    JSONObject cookieInfo, JSONObject probeRes) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "AR-READABLE 1");
        root.put("created", fmt(System.currentTimeMillis()));
        root.put("mode", withValues ? "FULL (cookie values + unlock pattern inside: PRIVATE, never upload)"
                : "SAFE (cookie names only, no values, no unlock pattern)");
        root.put("app", appInfo(c));
        root.put("store", new JSONObject(store.exportJson(false)));   // sessions list, folders, bookmarks, settings (raw)
        JSONArray sessions = new JSONArray();
        for (Store.Tab t : store.all()) {
            sessions.put(sessionJson(c, store, t, store.parked.contains(t),
                    cookieInfo.optJSONObject(t.id), probeRes.optJSONObject(t.id)));
        }
        root.put("sessions", sessions);
        root.put("accounts", accounts(store, probeRes));

        File fl = new File(c.getFilesDir(), "flows.json");
        if (fl.exists()) {
            try (FileInputStream in = new FileInputStream(fl)) {
                root.put("automations", new JSONTokener(new String(Bake.readAll(in), StandardCharsets.UTF_8)).nextValue());
            } catch (Throwable e) {
                root.put("automations", "unreadable: " + e.getClass().getSimpleName());
            }
        } else {
            root.put("automations", new JSONArray());
        }

        JSONObject ap = new JSONObject();
        for (Map.Entry<String, ?> e : Auto.p(c).getAll().entrySet()) {
            Object v = e.getValue();
            if (e.getKey().equals("pat") && !withValues) { ap.put("pat", "(hidden in SAFE mode)"); continue; }
            if (v instanceof Boolean || v instanceof Integer || v instanceof Long || v instanceof String) ap.put(e.getKey(), v);
            else if (v instanceof Float) ap.put(e.getKey(), ((Float) v).doubleValue());
        }
        root.put("automation_settings", ap);

        JSONArray ws = new JSONArray();
        File[] fs = c.getFilesDir().listFiles();
        if (fs != null) for (File f : fs)
            if (f.isFile() && f.getName().startsWith("ws_") && f.getName().endsWith(".bin"))
                ws.put(new JSONObject().put("file", f.getName()).put("bytes", f.length()));
        root.put("saved_back_history_files", ws);
        return root;
    }

    // =====================================================================
    // short text summary (for people)
    // =====================================================================

    private static String summary(JSONObject root) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("AR readable backup\n").append(root.optString("created")).append('\n')
                .append(root.optString("mode")).append("\n\n");
        JSONObject app = root.optJSONObject("app");
        if (app != null) sb.append("App ").append(app.optString("version_name")).append("  |  ")
                .append(app.optString("device")).append("  |  Android ").append(app.optString("android"))
                .append("  |  WebView ").append(app.optString("webview")).append("\n\n");

        JSONObject acc = root.optJSONObject("accounts");
        sb.append("== ACCOUNTS ==\n");
        if (acc != null) {
            for (String kind : new String[]{"claude", "chatgpt"}) {
                JSONObject k = acc.optJSONObject(kind);
                if (k == null) continue;
                sb.append(kind.toUpperCase(Locale.ROOT)).append(": ").append(k.optInt("different_accounts"))
                        .append(" different account(s)\n");
                JSONArray l = k.optJSONArray("accounts");
                if (l != null) for (int i = 0; i < l.length(); i++) {
                    JSONObject x = l.getJSONObject(i);
                    sb.append("  - ").append(x.optString("email"));
                    String nm = x.optString("name");
                    if (!nm.isEmpty()) sb.append(" (").append(nm).append(')');
                    JSONArray og = x.optJSONArray("organizations");
                    if (og != null) for (int o = 0; o < og.length(); o++) {
                        JSONObject oo = og.getJSONObject(o);
                        sb.append("  [org ").append(oo.optString("name")).append(' ').append(oo.optString("rate_limit_tier")).append(']');
                    }
                    sb.append("  <- sessions: ").append(x.optJSONArray("sessions")).append('\n');
                }
                JSONArray un = k.optJSONArray("signed_in_but_account_not_read");
                if (un != null && un.length() > 0)
                    sb.append("  signed in, but the account could not be read: ").append(un).append('\n');
            }
            JSONObject g = acc.optJSONObject("google");
            if (g != null) sb.append("GOOGLE: MAIN ").append(g.optJSONArray("main_sessions"))
                    .append("  linked ").append(g.optJSONArray("linked_sessions")).append('\n');
        }

        sb.append("\n== SESSIONS ==\n");
        JSONArray ss = root.optJSONArray("sessions");
        if (ss != null) for (int i = 0; i < ss.length(); i++) {
            JSONObject s = ss.getJSONObject(i);
            sb.append(i + 1).append(". ").append(s.optString("name")).append("  [").append(s.optString("id")).append("]")
                    .append(s.optBoolean("in_list") ? "" : "  (removed from list)").append('\n');
            sb.append("   ").append(s.optString("provider_by_url")).append("  ").append(s.optString("url")).append('\n');
            if (!s.optString("folder").isEmpty()) sb.append("   folder: ").append(s.optString("folder")).append('\n');
            if (s.optBoolean("is_main_google_session")) sb.append("   MAIN ").append(s.optInt("main_number")).append(" (holds Google accounts)\n");
            if (!s.optString("google_accounts_copied_from").isEmpty())
                sb.append("   Google accounts copied from: ").append(s.optString("google_accounts_copied_from")).append('\n');
            JSONObject ar = s.optJSONObject("accounts_read");
            if (ar != null) for (String kind : new String[]{"claude", "chatgpt"}) {
                JSONObject r = ar.optJSONObject(kind);
                if (r == null) continue;
                sb.append("   ").append(kind).append(" account: ")
                        .append(r.optString("email").isEmpty() ? "(not read: " + r.optString("status") + ")" : r.optString("email")).append('\n');
            }
            JSONObject ck = s.optJSONObject("cookies");
            if (ck != null) {
                sb.append("   cookies: ").append(ck.optInt("total_cookies")).append(" total; claude=")
                        .append(ck.optBoolean("claude_signed_in") ? "signed in" : "no")
                        .append(", chatgpt=").append(ck.optBoolean("chatgpt_signed_in") ? "signed in" : "no")
                        .append(", google=").append(ck.optBoolean("google_cookies_present") ? "yes" : "no")
                        .append(", qwen=").append(ck.optBoolean("qwen_cookies_present") ? "yes" : "no").append('\n');
            }
            JSONArray ch = s.optJSONArray("recent_chats");
            sb.append("   recent chats saved: ").append(ch == null ? 0 : ch.length())
                    .append("  |  last used: ").append(s.optString("last_used")).append("\n\n");
        }
        sb.append("Full details are in the .json file.\n");
        return sb.toString();
    }

    // =====================================================================
    // save to Downloads
    // =====================================================================

    private static String save(Context c, String name, String mime, byte[] data) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new IllegalStateException("cannot create file in Downloads");
            try (OutputStream o = c.getContentResolver().openOutputStream(u)) { o.write(data); }
            return "Downloads/" + name;
        }
        File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dir, name);
        try (OutputStream o = new FileOutputStream(f)) { o.write(data); }
        return f.getAbsolutePath();
    }
}
