package a.c;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Copies the stored data (cookies, localStorage, IndexedDB...) of every session
 * into / out of a zip. That zip is what "Make APK" bakes into the clone, and what a
 * fresh install restores BEFORE any WebView starts.
 */
final class Bake {

    static final String ASSET_TABS = "tabs_default.json";
    static final String ASSET_SESS = "sessions_default.zip";

    private static final HashSet<String> SKIP = new HashSet<>(Arrays.asList(
            "Cache", "Code Cache", "GPUCache", "GrShaderCache", "ShaderCache", "DawnCache",
            "DawnGraphiteCache", "DawnWebGPUCache", "Service Worker", "blob_storage", "Crashpad",
            "component_crx_cache", "LOCK", "lockfile", "SingletonLock"));

    static String note = "";

    private static File webBase(Context c) {
        return new File(c.getDataDir(), "app_webview");
    }

    /** Finds the folder WebView uses for one profile (by name, up to 3 levels deep). */
    static File findProfileDir(File dir, String id, int depth) {
        File[] ch = dir.listFiles();
        if (ch == null) return null;
        for (File f : ch) {
            if (!f.isDirectory()) continue;
            String n = f.getName();
            if (n.equals(id) || n.equals("Profile " + id) || n.equals("Profile_" + id)) return f;
        }
        if (depth < 3) {
            for (File f : ch) {
                if (!f.isDirectory()) continue;
                File r = findProfileDir(f, id, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static long size(File f) {
        if (f.isFile()) return f.length();
        long s = 0;
        File[] ch = f.listFiles();
        if (ch != null) for (File x : ch) s += size(x);
        return s;
    }

    /** Writes all sessions into outZip. Sets Bake.note with what was found. */
    static File exportSessions(Context c, Store store, File outZip) throws Exception {
        File base = webBase(c);
        JSONObject map = new JSONObject();
        StringBuilder missing = new StringBuilder();
        int found = 0;
        byte[] buf = new byte[65536];
        try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(outZip))) {
            z.setLevel(6);
            for (Store.Tab t : store.tabs) {
                File d = findProfileDir(base, t.id, 0);
                if (d == null) {
                    if (missing.length() > 0) missing.append(", ");
                    missing.append(t.name);
                    continue;
                }
                String rel = d.getAbsolutePath().substring(base.getAbsolutePath().length() + 1);
                map.put(t.id, rel);
                found++;
                addDir(z, d, t.id, buf);
            }
            z.putNextEntry(new ZipEntry("map.json"));
            z.write(map.toString().getBytes(StandardCharsets.UTF_8));
            z.closeEntry();
        }
        note = found + " of " + store.tabs.size() + " sessions copied with their logins"
                + (missing.length() > 0 ? ". No stored data yet for: " + missing + " (never opened?)" : "");
        return outZip;
    }

    private static void addDir(ZipOutputStream z, File dir, String prefix, byte[] buf) throws Exception {
        File[] ch = dir.listFiles();
        if (ch == null) return;
        for (File f : ch) {
            if (SKIP.contains(f.getName())) continue;
            String name = prefix + "/" + f.getName();
            if (f.isDirectory()) {
                addDir(z, f, name, buf);
            } else {
                try (InputStream in = new FileInputStream(f)) {
                    z.putNextEntry(new ZipEntry(name));
                    int n;
                    while ((n = in.read(buf)) > 0) z.write(buf, 0, n);
                    z.closeEntry();
                } catch (java.io.IOException skipFile) {
                    // a file that vanished while copying: ignore it
                }
            }
        }
    }

    /**
     * First launch of a cloned APK: restore tabs + settings + session data.
     * Never runs on an update (store is not fresh then), so it cannot overwrite logins.
     */
    static boolean applyBakedIfFresh(Context c, Store store) {
        if (!store.isFresh()) return false;
        try {
            String json;
            try (InputStream in = c.getAssets().open(ASSET_TABS)) {
                json = new String(readAll(in), StandardCharsets.UTF_8);
            }
            try (InputStream in = new BufferedInputStream(c.getAssets().open(ASSET_SESS), 65536)) {
                restoreSessions(c, in);
            } catch (java.io.FileNotFoundException noSessions) {
                // clone made without logins: fine
            } catch (Exception restoreFailed) {
                // keep going: tabs and settings are still restored, sessions just need a new login
            }
            if (store.importJson(json)) store.save();
            return true;
        } catch (Exception e) {
            return false;   // normal install: no baked data
        }
    }

    private static void restoreSessions(Context c, InputStream raw) throws Exception {
        File base = webBase(c);
        base.mkdirs();
        String baseCanon = base.getCanonicalPath();
        // the zip is written files-first, map.json last, so buffer the files to a temp dir
        File tmp = new File(c.getCacheDir(), "restore");
        deleteRec(tmp);
        tmp.mkdirs();
        String tmpCanon = tmp.getCanonicalPath();
        JSONObject map = null;
        byte[] buf = new byte[65536];
        try (ZipInputStream z = new ZipInputStream(raw)) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                if (e.getName().equals("map.json")) {
                    map = new JSONObject(new String(readAll(z), StandardCharsets.UTF_8));
                    continue;
                }
                File out = new File(tmp, e.getName());
                if (!out.getCanonicalPath().startsWith(tmpCanon + File.separator)) continue;
                out.getParentFile().mkdirs();
                try (OutputStream o = new FileOutputStream(out)) {
                    int n;
                    while ((n = z.read(buf)) > 0) o.write(buf, 0, n);
                }
            }
        }
        if (map != null) {
            java.util.Iterator<String> it = map.keys();
            while (it.hasNext()) {
                String id = it.next();
                File src = new File(tmp, id);
                File dst = new File(base, map.getString(id));
                if (!dst.getCanonicalPath().startsWith(baseCanon + File.separator)) continue;
                if (!src.isDirectory()) continue;
                deleteRec(dst);
                dst.getParentFile().mkdirs();
                if (!src.renameTo(dst)) copyRec(src, dst, buf);
            }
        }
        deleteRec(tmp);
    }

    /** Short report for the "Check session storage" button. */
    static String describe(Context c, Store store) {
        File base = webBase(c);
        StringBuilder sb = new StringBuilder();
        for (Store.Tab t : store.tabs) {
            File d = findProfileDir(base, t.id, 0);
            sb.append(t.name).append(": ");
            if (d == null) sb.append("no data yet\n");
            else sb.append(size(d) / 1024).append(" KB  (")
                    .append(d.getAbsolutePath().substring(base.getAbsolutePath().length() + 1)).append(")\n");
        }
        sb.append("\nWebView folder:\n");
        File[] top = base.listFiles();
        if (top == null) sb.append("(none yet)");
        else for (File f : top) {
            sb.append("- ").append(f.getName()).append('\n');
            File[] sub = f.listFiles();
            if (sub != null && f.isDirectory() && sub.length < 25)
                for (File s : sub) if (s.isDirectory()) sb.append("    - ").append(s.getName()).append('\n');
        }
        return sb.toString();
    }

    static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toByteArray();
    }

    static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] ch = f.listFiles();
        if (ch != null) for (File x : ch) deleteRec(x);
        f.delete();
    }

    private static void copyRec(File src, File dst, byte[] buf) throws Exception {
        if (src.isDirectory()) {
            dst.mkdirs();
            File[] ch = src.listFiles();
            if (ch != null) for (File x : ch) copyRec(x, new File(dst, x.getName()), buf);
        } else {
            try (InputStream in = new FileInputStream(src); OutputStream o = new FileOutputStream(dst)) {
                int n;
                while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            }
        }
    }
}
