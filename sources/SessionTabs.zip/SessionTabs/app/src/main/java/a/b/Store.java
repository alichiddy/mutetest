package a.b;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * All saved sessions + settings, kept as one JSON blob in SharedPreferences "s".
 * The OLD format ("tabs" = "profile|url" lines) is migrated automatically and
 * left untouched, so existing logins (profiles p1, p2, ...) survive the update.
 */
final class Store {

    static final class Tab {
        String id;      // WebView profile name: this IS the session (never change it)
        String name;
        String url;
        boolean main;   // holds the Google accounts
        boolean link;   // use Google accounts from the main session
        long lastUsed = 0;     // when the session was last used
        long lastLimit = 0;    // last limit end the user cleared (stale banners in the chat must not mark it again)
        long limitUntil = 0;   // Claude usage limit seen on this session: epoch ms when it ends
        int grp = 1;    // main: which MAIN it is (1 or 2); linked: which MAIN it copies from
        long lastSync;  // not saved
        final ArrayList<String[]> chats = new ArrayList<>();   // recent Claude chats of this session, newest first: {url, title, time}
        Tab(String id, String name, String url) { this.id = id; this.name = name; this.url = url; }
    }

    static final String DEFAULT_HOME = "https://claude.ai";

    final ArrayList<Tab> tabs = new ArrayList<>();
    final ArrayList<String> pendingDel = new ArrayList<>();
    final ArrayList<String[]> marks = new ArrayList<>();   // bookmarks for the MAIN session: {name, url}
    int counter = 0;
    boolean lock = false;
    boolean fast = false;   // Fast start: preload last session at app start
    String lastId = "";
    String recent = "";   // the last two sessions opened (most recent first), for Fast start
    int marksV = 0;
    final ArrayList<Tab> parked = new ArrayList<>();   // removed from the list, but their logins/data are kept

    ArrayList<Tab> all() {
        ArrayList<Tab> a = new ArrayList<>(tabs);
        a.addAll(parked);
        return a;
    }

    /** Claude chat link without query/fragment, or "" if the page is not a chat. */
    static String chatUrl(String u) {
        if (u == null) return "";
        int q = u.indexOf('?'); if (q >= 0) u = u.substring(0, q);
        q = u.indexOf('#'); if (q >= 0) u = u.substring(0, q);
        return u.matches("https://claude\\.ai/chat/[^/]+") ? u : "";
    }

    /** This chat was just used: it goes first in the session's list (keeps the last 15). */
    void noteChat(Tab t, String u) {
        u = chatUrl(u);
        if (t == null || u.isEmpty()) return;
        if (!t.chats.isEmpty() && t.chats.get(0)[0].equals(u)) return;
        String title = "";
        for (int i = 0; i < t.chats.size(); i++) if (t.chats.get(i)[0].equals(u)) { title = t.chats.get(i)[1]; t.chats.remove(i); break; }
        t.chats.add(0, new String[]{u, title, String.valueOf(System.currentTimeMillis())});
        while (t.chats.size() > 15) t.chats.remove(t.chats.size() - 1);
        save();
    }

    void noteTitle(Tab t, String u, String title) {
        u = chatUrl(u);
        if (t == null || u.isEmpty() || title == null) return;
        title = title.replaceAll("\\s*[-\u2013|]\\s*Claude\\s*$", "").trim();
        if (title.isEmpty() || title.equalsIgnoreCase("Claude")) return;
        for (String[] c : t.chats) if (c[0].equals(u)) { if (!c[1].equals(title)) { c[1] = title; save(); } return; }
    }

    void touch(String id) {
        lastId = id;
        java.util.ArrayList<String> l = new java.util.ArrayList<>();
        l.add(id);
        for (Tab q : tabs) if (q.id.equals(id)) q.lastUsed = System.currentTimeMillis();
        for (String x : recent.split(",")) if (!x.isEmpty() && !x.equals(id) && l.size() < 2) l.add(x);
        String n = android.text.TextUtils.join(",", l);
        if (!n.equals(recent)) { recent = n; save(); }
    }
    int dlMode = 0;   // 0 ask, 1 replace, 2 normal, 3 rename, 4 other app
    String home = DEFAULT_HOME;
    int statusColor = 0;   // 0 = system default, else ARGB of the status bar background
    int statusIcons = 0;   // clock/icons: 0 auto (by contrast), 1 dark, 2 light

    private final SharedPreferences p;

    Store(Context c) {
        p = c.getSharedPreferences("s", Context.MODE_PRIVATE);
        load();
    }

    /** True only on a brand-new install (nothing saved yet, not even the old format). */
    boolean isFresh() {
        return !p.contains("tabsV2") && !p.contains("tabs");
    }

    Tab byId(String id) {
        for (Tab t : tabs) if (t.id.equals(id)) return t;
        return null;
    }

    Tab main() {
        for (Tab t : tabs) if (t.main) return t;
        return null;
    }

    Tab main(int g) {
        for (Tab t : tabs) if (t.main && t.grp == g) return t;
        return null;
    }

    Tab create(String name) {
        Tab t = new Tab("p" + (++counter), name, home);
        t.link = false;   // the New session dialog decides
        tabs.add(t);
        return t;
    }

    void save() {
        p.edit().putString("tabsV2", exportJson(false)).apply();
    }

    static void defaultMarks(ArrayList<String[]> m) {
        m.clear();
        m.add(new String[]{"Gmail", "https://mail.google.com/"});
        m.add(new String[]{"Add Google account", "https://accounts.google.com/AddSession"});
        m.add(new String[]{"My Google account", "https://myaccount.google.com/"});
        m.add(new String[]{"2-Step / backup codes", "https://myaccount.google.com/signinoptions/two-step-verification"});
        m.add(new String[]{"YouTube", "https://www.youtube.com/"});
        m.add(new String[]{"Claude", "https://claude.ai/"});
    }

    private void load() {
        defaultMarks(marks);
        String j = p.getString("tabsV2", null);
        if (j != null) {
            importJson(j);
            return;
        }
        // migrate the old format
        counter = p.getInt("n", 0);
        String s = p.getString("tabs", "");
        for (String line : s.split("\n")) {
            int k = line.indexOf('|');
            if (k > 0) {
                String id = line.substring(0, k);
                tabs.add(new Tab(id, "Session " + id.replaceAll("[^0-9]", ""), line.substring(k + 1)));
                try {
                    int num = Integer.parseInt(id.replaceAll("[^0-9]", ""));
                    if (num > counter) counter = num;
                } catch (Exception ignored) { }
            }
        }
        if (!tabs.isEmpty()) save();
    }

    private static JSONObject tabJson(Tab t) throws org.json.JSONException {
        JSONObject j = new JSONObject();
        j.put("id", t.id);
        j.put("name", t.name);
        j.put("url", t.url);
        j.put("main", t.main);
        j.put("link", t.link);
        j.put("grp", t.grp);
        j.put("lim", t.limitUntil);
        j.put("lim0", t.lastLimit);
        j.put("used", t.lastUsed);
        JSONArray ca = new JSONArray();
        for (String[] c : t.chats) ca.put(new JSONArray().put(c[0]).put(c[1]).put(c[2]));
        j.put("chats", ca);
        return j;
    }

    private Tab tabFrom(JSONObject j) throws org.json.JSONException {
        Tab t = new Tab(j.getString("id"), j.optString("name", "Session"), j.optString("url", home));
        t.main = j.optBoolean("main", false);
        t.link = j.optBoolean("link", false);
        t.grp = j.optInt("grp", 1) == 2 ? 2 : 1;
        t.limitUntil = j.optLong("lim", 0);
        t.lastLimit = j.optLong("lim0", 0);
        t.lastUsed = j.optLong("used", 0);
        JSONArray ca = j.optJSONArray("chats");
        if (ca != null) for (int i = 0; i < ca.length(); i++) {
            JSONArray c = ca.optJSONArray(i);
            if (c != null) t.chats.add(new String[]{c.optString(0), c.optString(1), c.optString(2)});
        }
        try {
            int num = Integer.parseInt(t.id.replaceAll("[^0-9]", ""));
            if (num > counter) counter = num;
        } catch (Exception ignored) { }
        return t;
    }

    String exportJson(boolean forApk) {
        try {
            JSONObject o = new JSONObject();
            o.put("format", 2);
            o.put("counter", counter);
            o.put("lock", lock);
            o.put("fast", fast);
            o.put("lastId", lastId);
            o.put("recent", recent);
            o.put("marksV", marksV);
            o.put("dlMode", dlMode);
            o.put("home", home);
            o.put("statusColor", statusColor);
            o.put("statusIcons", statusIcons);
            JSONArray a = new JSONArray();
            for (Tab t : tabs) a.put(tabJson(t));
            o.put("tabs", a);
            JSONArray pk = new JSONArray();
            for (Tab t : parked) pk.put(tabJson(t));
            o.put("parked", pk);
            JSONArray mk = new JSONArray();
            for (String[] m : marks) {
                JSONObject j = new JSONObject();
                j.put("n", m[0]);
                j.put("u", m[1]);
                mk.put(j);
            }
            o.put("marks", mk);
            if (!forApk) {
                JSONArray d = new JSONArray();
                for (String s : pendingDel) d.put(s);
                o.put("del", d);
            }
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    boolean importJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            tabs.clear();
            pendingDel.clear();
            counter = o.optInt("counter", 0);
            lock = o.optBoolean("lock", false);
            fast = o.optBoolean("fast", false);
            lastId = o.optString("lastId", "");
            recent = o.optString("recent", "");
            dlMode = Math.max(0, Math.min(4, o.optInt("dlMode", 0)));
            home = o.optString("home", DEFAULT_HOME);
            statusColor = o.optInt("statusColor", 0);
            statusIcons = Math.max(0, Math.min(2, o.optInt("statusIcons", 0)));
            JSONArray a = o.optJSONArray("tabs");
            if (a != null) for (int i = 0; i < a.length(); i++) tabs.add(tabFrom(a.getJSONObject(i)));
            parked.clear();
            JSONArray pk = o.optJSONArray("parked");
            if (pk != null) for (int i = 0; i < pk.length(); i++) parked.add(tabFrom(pk.getJSONObject(i)));
            JSONArray mk = o.optJSONArray("marks");
            if (mk == null) {
                defaultMarks(marks);
            } else {
                marks.clear();
                for (int i = 0; i < mk.length(); i++) {
                    JSONObject j = mk.getJSONObject(i);
                    marks.add(new String[]{j.optString("n", "Link"), j.optString("u", "https://")});
                }
            }
            if (o.optInt("marksV", 0) < 1) {   // one time: add the 2-Step / backup codes bookmark to existing lists
                boolean has = false;
                for (String[] m : marks) if (m[1].contains("two-step-verification")) has = true;
                if (!has) marks.add(Math.min(3, marks.size()), new String[]{"2-Step / backup codes", "https://myaccount.google.com/signinoptions/two-step-verification"});
            }
            marksV = 1;
            JSONArray d = o.optJSONArray("del");
            if (d != null) for (int i = 0; i < d.length(); i++) pendingDel.add(d.getString(i));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
