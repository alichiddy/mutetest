package a.b;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * All saved sessions + settings, kept as one JSON blob in SharedPreferences "s".
 * The OLD format ("tabs" = "profile|url" lines) is migrated automatically and
 * left untouched, so existing logins (profiles p1, p2, ...) survive the update.
 */
final class Store {

    static final class Tab {
        String id;      // WebView profile name: this IS the session (never change it)
        String name;
        String url;
        boolean main;   // holds the Google accounts
        boolean link;   // use Google accounts from the main session
        long limitUntil = 0;   // Claude usage limit seen on this session: epoch ms when it ends
        int grp = 1;    // main: which MAIN it is (1 or 2); linked: which MAIN it copies from
        long lastSync;  // not saved
        Tab(String id, String name, String url) { this.id = id; this.name = name; this.url = url; }
    }

    static final String DEFAULT_HOME = "https://claude.ai";

    final ArrayList<Tab> tabs = new ArrayList<>();
    final ArrayList<String> pendingDel = new ArrayList<>();
    final ArrayList<String[]> marks = new ArrayList<>();   // bookmarks for the MAIN session: {name, url}
    int counter = 0;
    boolean lock = false;
    boolean fast = false;   // Fast start: preload last session at app start
    String lastId = "";
    String recent = "";   // the last two sessions opened (most recent first), for Fast start
    int marksV = 0;

    void touch(String id) {
        lastId = id;
        java.util.ArrayList<String> l = new java.util.ArrayList<>();
        l.add(id);
        for (String x : recent.split(",")) if (!x.isEmpty() && !x.equals(id) && l.size() < 2) l.add(x);
        String n = android.text.TextUtils.join(",", l);
        if (!n.equals(recent)) { recent = n; save(); }
    }
    int dlMode = 0;   // 0 ask, 1 replace, 2 normal, 3 rename, 4 other app
    String home = DEFAULT_HOME;

    private final SharedPreferences p;

    Store(Context c) {
        p = c.getSharedPreferences("s", Context.MODE_PRIVATE);
        load();
    }

    /** True only on a brand-new install (nothing saved yet, not even the old format). */
    boolean isFresh() {
        return !p.contains("tabsV2") && !p.contains("tabs");
    }

    Tab byId(String id) {
        for (Tab t : tabs) if (t.id.equals(id)) return t;
        return null;
    }

    Tab main() {
        for (Tab t : tabs) if (t.main) return t;
        return null;
    }

    Tab main(int g) {
        for (Tab t : tabs) if (t.main && t.grp == g) return t;
        return null;
    }

    Tab create(String name) {
        Tab t = new Tab("p" + (++counter), name, home);
        t.link = main() != null;
        tabs.add(t);
        return t;
    }

    void save() {
        p.edit().putString("tabsV2", exportJson(false)).apply();
    }

    static void defaultMarks(ArrayList<String[]> m) {
        m.clear();
        m.add(new String[]{"Gmail", "https://mail.google.com/"});
        m.add(new String[]{"Add Google account", "https://accounts.google.com/AddSession"});
        m.add(new String[]{"My Google account", "https://myaccount.google.com/"});
        m.add(new String[]{"2-Step / backup codes", "https://myaccount.google.com/signinoptions/two-step-verification"});
        m.add(new String[]{"YouTube", "https://www.youtube.com/"});
        m.add(new String[]{"Claude", "https://claude.ai/"});
    }

    private void load() {
        defaultMarks(marks);
        String j = p.getString("tabsV2", null);
        if (j != null) {
            importJson(j);
            return;
        }
        // migrate the old format
        counter = p.getInt("n", 0);
        String s = p.getString("tabs", "");
        for (String line : s.split("\n")) {
            int k = line.indexOf('|');
            if (k > 0) {
                String id = line.substring(0, k);
                tabs.add(new Tab(id, "Session " + id.replaceAll("[^0-9]", ""), line.substring(k + 1)));
                try {
                    int num = Integer.parseInt(id.replaceAll("[^0-9]", ""));
                    if (num > counter) counter = num;
                } catch (Exception ignored) { }
            }
        }
        if (!tabs.isEmpty()) save();
    }

    String exportJson(boolean forApk) {
        try {
            JSONObject o = new JSONObject();
            o.put("format", 2);
            o.put("counter", counter);
            o.put("lock", lock);
            o.put("fast", fast);
            o.put("lastId", lastId);
            o.put("recent", recent);
            o.put("marksV", marksV);
            o.put("dlMode", dlMode);
            o.put("home", home);
            JSONArray a = new JSONArray();
            for (Tab t : tabs) {
                JSONObject j = new JSONObject();
                j.put("id", t.id);
                j.put("name", t.name);
                j.put("url", t.url);
                j.put("main", t.main);
                j.put("link", t.link);
                j.put("grp", t.grp);
                j.put("lim", t.limitUntil);
                a.put(j);
            }
            o.put("tabs", a);
            JSONArray mk = new JSONArray();
            for (String[] m : marks) {
                JSONObject j = new JSONObject();
                j.put("n", m[0]);
                j.put("u", m[1]);
                mk.put(j);
            }
            o.put("marks", mk);
            if (!forApk) {
                JSONArray d = new JSONArray();
                for (String s : pendingDel) d.put(s);
                o.put("del", d);
            }
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    boolean importJson(String s) {
        try {
            JSONObject o = new JSONObject(s);
            tabs.clear();
            pendingDel.clear();
            counter = o.optInt("counter", 0);
            lock = o.optBoolean("lock", false);
            fast = o.optBoolean("fast", false);
            lastId = o.optString("lastId", "");
            recent = o.optString("recent", "");
            dlMode = Math.max(0, Math.min(4, o.optInt("dlMode", 0)));
            home = o.optString("home", DEFAULT_HOME);
            JSONArray a = o.optJSONArray("tabs");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    JSONObject j = a.getJSONObject(i);
                    Tab t = new Tab(j.getString("id"), j.optString("name", "Session"), j.optString("url", home));
                    t.main = j.optBoolean("main", false);
                    t.link = j.optBoolean("link", false);
                    t.grp = j.optInt("grp", 1) == 2 ? 2 : 1;
                    t.limitUntil = j.optLong("lim", 0);
                    tabs.add(t);
                    try {
                        int num = Integer.parseInt(t.id.replaceAll("[^0-9]", ""));
                        if (num > counter) counter = num;
                    } catch (Exception ignored) { }
                }
            }
            JSONArray mk = o.optJSONArray("marks");
            if (mk == null) {
                defaultMarks(marks);
            } else {
                marks.clear();
                for (int i = 0; i < mk.length(); i++) {
                    JSONObject j = mk.getJSONObject(i);
                    marks.add(new String[]{j.optString("n", "Link"), j.optString("u", "https://")});
                }
            }
            if (o.optInt("marksV", 0) < 1) {   // one time: add the 2-Step / backup codes bookmark to existing lists
                boolean has = false;
                for (String[] m : marks) if (m[1].contains("two-step-verification")) has = true;
                if (!has) marks.add(Math.min(3, marks.size()), new String[]{"2-Step / backup codes", "https://myaccount.google.com/signinoptions/two-step-verification"});
            }
            marksV = 1;
            JSONArray d = o.optJSONArray("del");
            if (d != null) for (int i = 0; i < d.length(); i++) pendingDel.add(d.getString(i));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
