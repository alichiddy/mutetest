package a.b;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/** Keeps the AB process alive (quiet notification) so loaded pages are not thrown away by Android. */
public class Keep extends Service {
    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel("keep") == null) {
                NotificationChannel c = new NotificationChannel("keep", "Keep AB fast", NotificationManager.IMPORTANCE_MIN);
                c.setShowBadge(false);
                nm.createNotificationChannel(c);
            }
            Notification n = new Notification.Builder(this, "keep")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("AB is kept ready")
                    .setOngoing(true).build();
            startForeground(77, n);
        } catch (Throwable e) { Dbg.d("keep service failed: " + e); }
        return START_STICKY;
    }
}
