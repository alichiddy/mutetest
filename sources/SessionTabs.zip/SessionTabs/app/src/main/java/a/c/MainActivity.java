package a.c;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;

/**
 * Minimal browser: every tab is bound to its own WebView Profile
 * (separate cookies, localStorage, cache, logins). Only the active tab
 * has a live WebView, so RAM stays low.
 */
public class MainActivity extends Activity {

    private static final String HOME = "https://duckduckgo.com";

    private static class Tab {
        String profile;
        String url;
        Tab(String p, String u) { profile = p; url = u; }
    }

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private int counter = 0;
    private boolean profilesOk;

    private WebView web;
    private EditText urlBar;
    private Button tabBtn;
    private FrameLayout holder;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("s", MODE_PRIVATE);
        profilesOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        tabBtn = new Button(this);
        tabBtn.setMinWidth(0);
        tabBtn.setMinimumWidth(0);
        tabBtn.setOnClickListener(v -> showTabMenu());
        bar.addView(tabBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO
                    || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        bar.addView(urlBar, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        holder = new FrameLayout(this);
        root.addView(holder, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (!profilesOk) {
            Toast.makeText(this,
                    "Update 'Android System WebView' / Chrome: per-tab sessions unsupported.",
                    Toast.LENGTH_LONG).show();
        }

        load();
        String incoming = getIntent() != null && getIntent().getData() != null
                ? getIntent().getData().toString() : null;
        if (tabs.isEmpty()) newTab(incoming != null ? incoming : HOME);
        else {
            open(Math.min(prefs.getInt("cur", 0), tabs.size() - 1));
            if (incoming != null) go(incoming);
        }
    }

    @Override
    protected void onNewIntent(android.content.Intent i) {
        super.onNewIntent(i);
        Uri d = i.getData();
        if (d != null) newTab(d.toString());
    }

    // ---------- tabs ----------

    private void newTab(String url) {
        tabs.add(new Tab("p" + (++counter), url));
        open(tabs.size() - 1);
    }

    private void open(int i) {
        if (web != null) {
            holder.removeView(web);
            web.destroy();   // free RAM; session data stays in the profile
            web = null;
        }
        current = i;
        Tab t = tabs.get(i);

        web = new WebView(this);
        if (profilesOk) {
            // must be called before any other call on this WebView
            ProfileStore.getInstance().getOrCreateProfile(t.profile);
            WebViewCompat.setProfile(web, t.profile);
        }
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(false);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { sync(u); }
            @Override public void onPageFinished(WebView v, String u) { sync(u); }
        });
        holder.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        web.loadUrl(t.url);
        urlBar.setText(t.url);
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    private void sync(String u) {
        if (u == null || current < 0) return;
        tabs.get(current).url = u;
        if (!urlBar.hasFocus()) urlBar.setText(u);
    }

    private void closeCurrent() {
        Tab t = tabs.remove(current);
        holder.removeView(web);
        web.destroy();
        web = null;
        if (profilesOk) {
            try { ProfileStore.getInstance().deleteProfile(t.profile); }  // wipes that session
            catch (Exception ignored) { }
        }
        if (tabs.isEmpty()) newTab(HOME);
        else open(Math.max(0, current - 1));
    }

    private void showTabMenu() {
        int n = tabs.size();
        String[] items = new String[n + 2];
        items[0] = "+  New tab (fresh session)";
        items[1] = "x  Close this tab (deletes its logins)";
        for (int i = 0; i < n; i++) {
            String host = Uri.parse(tabs.get(i).url).getHost();
            items[i + 2] = (i == current ? "● " : "○ ") + (i + 1) + ". "
                    + (host != null ? host : tabs.get(i).url);
        }
        new AlertDialog.Builder(this).setItems(items, (d, w) -> {
            if (w == 0) newTab(HOME);
            else if (w == 1) closeCurrent();
            else if (w - 2 != current) open(w - 2);
        }).show();
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty() || web == null) return;
        String u;
        if (in.startsWith("http://") || in.startsWith("https://")) u = in;
        else if (in.contains(" ") || !in.contains(".")) u = "https://duckduckgo.com/?q=" + Uri.encode(in);
        else u = "https://" + in;
        web.loadUrl(u);
    }

    // ---------- persistence ----------

    private void save() {
        StringBuilder sb = new StringBuilder();
        for (Tab t : tabs) sb.append(t.profile).append('|').append(t.url).append('\n');
        prefs.edit().putString("tabs", sb.toString())
                .putInt("cur", Math.max(current, 0)).putInt("n", counter).apply();
    }

    private void load() {
        counter = prefs.getInt("n", 0);
        String s = prefs.getString("tabs", "");
        for (String line : s.split("\n")) {
            int k = line.indexOf('|');
            if (k > 0) tabs.add(new Tab(line.substring(0, k), line.substring(k + 1)));
        }
    }

    @Override protected void onPause() {
        super.onPause();
        save();
        if (web != null) web.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
