package a.c;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.view.MotionEvent;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import androidx.core.content.FileProvider;
import android.database.Cursor;
import android.content.ContentUris;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.WebBackForwardList;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.Profile;
import androidx.webkit.UserAgentMetadata;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashSet;
import java.util.Locale;

/**
 * Minimal multi-session browser.
 * - Every saved session has its own WebView Profile (own cookies/logins), kept until YOU delete it.
 * - Nothing loads at launch. Only the page you tap is alive (one WebView at a time).
 * - One "main" session holds the Google accounts; linked sessions copy them live.
 * - Settings > Make APK builds a signed clone of this app with your sessions inside.
 */
public class MainActivity extends Activity {

    private static final int REQ_PERM = 1, REQ_FILE = 2, REQ_KEY = 3, REQ_STORAGE = 4;
    private static final long RELOCK_MS = 2 * 60 * 1000L;
    private static final long SYNC_TICK_MS = 4 * 60 * 1000L;

    // Hosts whose cookies make up "being signed in to Google"
    private static final String[] GOOGLE_URLS = {
            "https://accounts.google.com/", "https://accounts.google.com/o/oauth2/",
            "https://accounts.google.com/signin/", "https://accounts.google.com/v3/signin/",
            "https://accounts.google.com/gsi/", "https://www.google.com/",
            "https://myaccount.google.com/", "https://accounts.youtube.com/",
            "https://www.youtube.com/", "https://mail.google.com/"
    };

    // Injected into every page (and iframe): tells the app the real file name / type of downloads
    private static final String HOOK_JS = "(function(){if(window.__arHook)return;window.__arHook=1;"
            + "function note(a){try{if(a&&a.hasAttribute&&a.hasAttribute('download')&&window.ARB)"
            + "ARB.note(String(a.href),a.getAttribute('download')||'')}catch(e){}}"
            + "var oc=HTMLAnchorElement.prototype.click;"
            + "HTMLAnchorElement.prototype.click=function(){note(this);return oc.apply(this,arguments)};"
            + "window.addEventListener('click',function(e){var t=e.target;"
            + "note(t&&t.closest?t.closest('a[download]'):null)},true);"
            + "var cu=URL.createObjectURL;"
            + "URL.createObjectURL=function(b){var u=cu.apply(this,arguments);"
            + "try{if(window.ARB)ARB.type(String(u),(b&&b.type)?String(b.type):'')}catch(e){}return u};})();";

    private final ConcurrentHashMap<String, String> dlNames = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, String> dlTypes = new ConcurrentHashMap<>();

    private Store store;
    private Store.Tab cur;              // session whose page is loaded (null = none)
    private boolean profilesOk;

    private WebView web;
    private final java.util.HashMap<String, Integer> lastSync = new java.util.HashMap<>();
    private WebView popup;   // login popup (e.g. Sign in with Google), same session
    private CookieManager cookies;
    private FrameLayout holder;
    private LinearLayout sessionsView, bottomBar;
    private Button countBtn, pageBtn;
    private TextView nameLabel, hint;
    private EditText urlBar;
    private ListView list;
    private Rows rows;
    private LinearLayout lockView;

    private PermissionRequest pendingPerm;
    private ValueCallback<Uri[]> filePathCb;
    private String pendingLink;
    private String[] pendingDownload;

    private boolean locked = false, authBusy = false, inForeground = false;
    private long pausedAt = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable syncTick = new Runnable() {
        @Override public void run() {
            if (cur != null && web != null) {
                syncFromMain(cur, true);
                handler.postDelayed(this, SYNC_TICK_MS);
            }
        }
    };

    // =====================================================================
    // lifecycle
    // =====================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Dbg.init(this);
        final Thread.UncaughtExceptionHandler prevHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
            try {
                String[] st = android.util.Log.getStackTraceString(ex).split("\n");
                StringBuilder sb = new StringBuilder("CRASH in " + th.getName() + ": ");
                for (int i = 0; i < Math.min(st.length, 8); i++) sb.append(st[i].trim()).append(" | ");
                Dbg.d(sb.toString());
            } catch (Throwable ignored) { }
            if (prevHandler != null) prevHandler.uncaughtException(th, ex);
        });
        store = new Store(this);
        Bake.applyBakedIfFresh(this, store);          // fresh clone: restore sessions BEFORE any WebView
        profilesOk = WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        Dbg.d("onCreate recreatedBySystem=" + (b != null) + " sessions=" + store.tabs.size()
                + " profilesOk=" + profilesOk + " lock=" + store.lock);

        buildUi();
        if (!profilesOk) {
            Toast.makeText(this, "Update 'Android System WebView' / Chrome: per-session logins unsupported.",
                    Toast.LENGTH_LONG).show();
        }
        retryPendingDeletes();

        Uri d = getIntent() != null ? getIntent().getData() : null;
        if (d != null) pendingLink = d.toString();

        showSessions();
        Auto.schedule(this);   // re-arm (alarms are lost after force-stop / reboot)
        if (store.lock && deviceSecure()) {
            showLock();
        } else {
            runPendingLink();
        }
        if (b == null && getIntent() != null && getIntent().getBooleanExtra("auto", false)) {
            getIntent().removeExtra("auto");
            autoRelock = getIntent().getBooleanExtra("relock", false);
            runAuto(false);
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        Uri d = i.getData();
        Dbg.d("onNewIntent link=" + (d != null ? Dbg.url(d.toString()) : "none"));
        if (i.getBooleanExtra("auto", false)) { autoRelock = i.getBooleanExtra("relock", false); runAuto(false); return; }
        if (d != null) {
            pendingLink = d.toString();
            if (!locked) runPendingLink();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        inForeground = false;
        Dbg.d("onPause web=" + (web != null));
        pausedAt = SystemClock.elapsedRealtime();
        if (cur != null && web != null) {
            String u = web.getUrl();
            if (u != null) cur.url = u;
        }
        store.save();
        saveWebState(cur);
        if (cookies != null) cookies.flush();
        if (web != null) web.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Dbg.d("onStop");
    }

    @Override
    protected void onDestroy() {
        Dbg.d("onDestroy isFinishing=" + isFinishing());
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        inForeground = true;
        Dbg.d("onResume web=" + (web != null) + " locked=" + locked);
        if (web != null) web.onResume();
        if (store.lock && deviceSecure() && !locked && pausedAt > 0
                && SystemClock.elapsedRealtime() - pausedAt > RELOCK_MS) {
            showLock();
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        Dbg.d("onTrimMemory level=" + level + " foreground=" + inForeground);
        // Android is short of RAM and we are in the background: drop the page, keep the session
        if (level >= TRIM_MEMORY_BACKGROUND && !inForeground && web != null) {
            // keep the page while a file picker / permission dialog is open, or the upload is lost
            if (filePathCb != null || pendingPerm != null) { Dbg.d("trim skipped: picker/permission open"); return; }
            closePage("trim-memory");
        }
    }

    @Override
    public void onBackPressed() {
        Dbg.d("BACK pressed: " + backState());
        if (popup != null) { Dbg.d("BACK -> closing popup"); closePopup(); return; }
        if (locked) { Dbg.d("BACK -> locked, moving app to background"); moveTaskToBack(true); return; }
        if (sessionsView.getVisibility() == View.VISIBLE) {
            if (web != null) { Dbg.d("BACK -> sessions list, returning to page"); showPage(); }
            else { Dbg.d("BACK -> sessions list, no page: leaving app"); super.onBackPressed(); }
        } else if (web != null && web.canGoBack()) {
            Dbg.d("BACK -> web.goBack()");
            web.goBack();
        } else {
            Dbg.d("BACK -> no history in this page, showing sessions list");
            showSessions();
        }
    }

    private String backState() {
        StringBuilder sb = new StringBuilder();
        sb.append("sessionsList=").append(sessionsView.getVisibility() == View.VISIBLE ? "visible" : "hidden");
        sb.append(" locked=").append(locked).append(" urlBarFocus=").append(urlBar.hasFocus());
        if (web == null) {
            sb.append(" page=none");
        } else {
            try {
                WebBackForwardList l = web.copyBackForwardList();
                int idx = l.getCurrentIndex();
                sb.append(" canGoBack=").append(web.canGoBack()).append(" history=").append(idx).append('/')
                        .append(l.getSize() - 1).append(" url=").append(Dbg.url(web.getUrl()));
                if (idx > 0) sb.append(" prev=").append(Dbg.url(l.getItemAtIndex(idx - 1).getUrl()));
            } catch (Throwable e) {
                sb.append(" (history unreadable: ").append(e).append(')');
            }
        }
        return sb.toString();
    }

    // =====================================================================
    // UI
    // =====================================================================

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    private void buildUi() {
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        FrameLayout outer = new FrameLayout(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        holder = new FrameLayout(this);
        root.addView(holder, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        // ---- sessions screen ----
        sessionsView = new LinearLayout(this);
        sessionsView.setOrientation(LinearLayout.VERTICAL);
        sessionsView.setBackgroundColor(Color.WHITE);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setPadding(dp(6), dp(6), dp(6), 0);
        Button nb = button("+ New session");
        nb.setOnClickListener(v -> newSession());
        pageBtn = button("Back to page");
        pageBtn.setOnClickListener(v -> showPage());
        Button sb = button("Settings");
        sb.setOnClickListener(v -> showSettings());
        head.addView(nb, new LinearLayout.LayoutParams(0, WRAP, 1f));
        head.addView(pageBtn, new LinearLayout.LayoutParams(0, WRAP, 1f));
        head.addView(sb, new LinearLayout.LayoutParams(0, WRAP, 1f));
        sessionsView.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        hint = new TextView(this);
        hint.setTextSize(12);
        hint.setTextColor(0xFF666666);
        hint.setPadding(dp(14), dp(6), dp(14), dp(6));
        sessionsView.addView(hint, new LinearLayout.LayoutParams(MATCH, WRAP));

        list = new ListView(this);
        rows = new Rows();
        list.setAdapter(rows);
        list.setOnTouchListener((v, e) -> gripTouch(e));
        list.setOnItemClickListener((p, v, pos, id) -> openTab(store.tabs.get(pos), null));
        list.setOnItemLongClickListener((p, v, pos, id) -> { tabOptions(store.tabs.get(pos)); return true; });
        sessionsView.addView(list, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        holder.addView(sessionsView, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- bottom bar (tabs + address) ----
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.VERTICAL);
        bottomBar.setBackgroundColor(0xFFF1F3F4);

        // one slim row: [tabs] [ session name / address ] [menu]; buttons are as tall as the middle block
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(4), dp(12), dp(4));

        countBtn = button("1");
        countBtn.setMinWidth(dp(56));
        countBtn.setMinimumWidth(dp(56));
        countBtn.setMinHeight(0);
        countBtn.setMinimumHeight(0);
        countBtn.setPadding(dp(14), 0, dp(14), 0);
        countBtn.setOnClickListener(v -> showSessions());
        bar.addView(countBtn, new LinearLayout.LayoutParams(WRAP, MATCH));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);

        nameLabel = new TextView(this);
        nameLabel.setTextSize(12);
        nameLabel.setTypeface(Typeface.DEFAULT_BOLD);
        nameLabel.setSingleLine(true);
        nameLabel.setEllipsize(TextUtils.TruncateAt.END);
        nameLabel.setPadding(dp(8), 0, dp(8), 0);
        mid.addView(nameLabel, new LinearLayout.LayoutParams(MATCH, WRAP));

        urlBar = new EditText(this);
        urlBar.setSingleLine(true);
        urlBar.setSelectAllOnFocus(true);
        urlBar.setTextSize(14);
        urlBar.setMinHeight(0);
        urlBar.setMinimumHeight(0);
        urlBar.setPadding(dp(8), dp(2), dp(8), dp(6));
        urlBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBar.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        mid.addView(urlBar, new LinearLayout.LayoutParams(MATCH, WRAP));
        LinearLayout.LayoutParams midLp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        midLp.setMargins(dp(8), 0, dp(8), 0);
        bar.addView(mid, midLp);

        Button menu = button("\u22EE");
        menu.setMinWidth(dp(56));
        menu.setMinimumWidth(dp(56));
        menu.setMinHeight(0);
        menu.setMinimumHeight(0);
        menu.setPadding(dp(14), 0, dp(14), 0);
        menu.setOnClickListener(v -> pageMenu());
        bar.addView(menu, new LinearLayout.LayoutParams(WRAP, MATCH));

        bottomBar.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(bottomBar, new LinearLayout.LayoutParams(MATCH, WRAP));
        bottomBar.setVisibility(View.GONE);

        outer.addView(root, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- lock overlay ----
        lockView = new LinearLayout(this);
        lockView.setOrientation(LinearLayout.VERTICAL);
        lockView.setGravity(Gravity.CENTER);
        lockView.setBackgroundColor(Color.WHITE);
        lockView.setClickable(true);
        TextView lt = new TextView(this);
        lt.setText("AR is locked");
        lt.setTextSize(20);
        lt.setGravity(Gravity.CENTER);
        lockView.addView(lt, new LinearLayout.LayoutParams(WRAP, WRAP));
        Button ub = button("Unlock");
        ub.setOnClickListener(v -> authenticate());
        lockView.addView(ub, new LinearLayout.LayoutParams(WRAP, WRAP));
        lockView.setVisibility(View.GONE);
        outer.addView(lockView, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(outer);
    }

    private boolean dragging = false;
    private int dragPos = -1;
    private int GRIP_DP_W() { return dp(56); }
    private final Runnable dragScroll = new Runnable() {
        @Override public void run() {
            if (!dragging) return;
            if (dragY < dp(70)) list.smoothScrollBy(-dp(18), 0);
            else if (dragY > list.getHeight() - dp(70)) list.smoothScrollBy(dp(18), 0);
            handler.postDelayed(this, 30);
        }
    };
    private float dragY;

    /** Touch on the right-hand grip (the three lines) drags that session up or down. */
    private boolean gripTouch(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            if (e.getX() < list.getWidth() - GRIP_DP_W()) return false;
            int pos = list.pointToPosition((int) e.getX(), (int) e.getY());
            if (pos == ListView.INVALID_POSITION) return false;
            dragging = true; dragPos = pos; dragY = e.getY();
            list.requestDisallowInterceptTouchEvent(true);
            rows.notifyDataSetChanged();
            handler.post(dragScroll);
            return true;
        }
        if (!dragging) return false;
        if (a == MotionEvent.ACTION_MOVE) {
            dragY = e.getY();
            int pos = list.pointToPosition(list.getWidth() / 2, (int) Math.max(0, Math.min(e.getY(), list.getHeight() - 1)));
            if (pos != ListView.INVALID_POSITION && pos != dragPos && pos < store.tabs.size()) {
                Store.Tab t = store.tabs.remove(dragPos);
                store.tabs.add(pos, t);
                dragPos = pos;
                rows.notifyDataSetChanged();
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            dragging = false; dragPos = -1;
            handler.removeCallbacks(dragScroll);
            store.save();
            rows.notifyDataSetChanged();
            return true;
        }
        return true;
    }

    private final class Rows extends BaseAdapter {
        @Override public int getCount() { return store.tabs.size(); }
        @Override public Object getItem(int i) { return store.tabs.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View old, ViewGroup parent) {
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(dp(16), dp(12), dp(16), dp(12));
            Store.Tab t = store.tabs.get(i);

            TextView title = new TextView(MainActivity.this);
            title.setTextSize(17);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(0xFF111111);
            title.setText((t == cur && web != null ? "\u25CF " : "") + (t.main ? "\u2605 " : "") + t.name);
            row.addView(title);

            TextView sub = new TextView(MainActivity.this);
            sub.setTextSize(12);
            sub.setTextColor(0xFF666666);
            String host = Uri.parse(t.url).getHost();
            StringBuilder sb = new StringBuilder(host != null ? host : t.url);
            if (t.main) sb.append("  \u00B7  MAIN (Google accounts)");
            else if (t.link) sb.append("  \u00B7  linked to main");
            sub.setText(sb.toString());
            row.addView(sub);

            LinearLayout outer = new LinearLayout(MainActivity.this);
            outer.setOrientation(LinearLayout.HORIZONTAL);
            outer.setGravity(Gravity.CENTER_VERTICAL);
            outer.addView(row, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            TextView grip = new TextView(MainActivity.this);   // drag here to reorder
            grip.setText("\u2261");
            grip.setTextSize(26);
            grip.setTextColor(0xFF888888);
            grip.setGravity(Gravity.CENTER);
            grip.setPadding(dp(8), 0, dp(8), 0);
            outer.addView(grip, new LinearLayout.LayoutParams(GRIP_DP_W(), LinearLayout.LayoutParams.MATCH_PARENT));
            if (dragging && i == dragPos) outer.setBackgroundColor(0x2233AAFF);
            return outer;
        }
    }

    private void refreshList() {
        rows.notifyDataSetChanged();
        countBtn.setText(String.valueOf(store.tabs.size()));
        hint.setText(store.tabs.isEmpty()
                ? "No sessions yet. Tap \"+ New session\"."
                : "Tap = open  \u00B7  Hold = options  \u00B7  Drag \u2261 = move");
        pageBtn.setVisibility(web != null ? View.VISIBLE : View.GONE);
    }

    private void showSessions() {
        closePopup();   // popup sits on top of the list and would hide it and the bar
        refreshList();
        sessionsView.setVisibility(View.VISIBLE);
        bottomBar.setVisibility(View.GONE);
        if (web != null) web.setVisibility(View.GONE);
        hideKeyboard();
    }

    private void showPage() {
        if (web == null || cur == null) { showSessions(); return; }
        sessionsView.setVisibility(View.GONE);
        bottomBar.setVisibility(View.VISIBLE);
        web.setVisibility(View.VISIBLE);
        nameLabel.setText((cur.main ? "\u2605 " : "") + cur.name);
        countBtn.setText(String.valueOf(store.tabs.size()));
        web.requestFocus();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null && urlBar != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    // =====================================================================
    // sessions: create / rename / main / link / delete
    // =====================================================================

    private void askText(String title, String initial, final TextCallback cb) {
        final EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(initial);
        e.setSelectAllOnFocus(true);
        FrameLayout f = new FrameLayout(this);
        f.setPadding(dp(20), dp(8), dp(20), 0);
        f.addView(e);
        new AlertDialog.Builder(this).setTitle(title).setView(f)
                .setPositiveButton("OK", (d, w) -> cb.ok(e.getText().toString().trim()))
                .setNegativeButton("Cancel", null).show();
    }

    private interface TextCallback { void ok(String s); }

    private void newSession() {
        askText("Name this session", "Session " + (store.counter + 1), s -> {
            Store.Tab t = store.create(s);
            if (s.isEmpty()) t.name = "Session " + store.counter;
            store.save();
            refreshList();
            openTab(t, null);
        });
    }

    private void tabOptions(final Store.Tab t) {
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        labels.add("Rename");
        acts.add(() -> askText("Rename session", t.name, s -> {
            if (!s.isEmpty()) { t.name = s; store.save(); refreshList(); }
        }));
        if (t.main) {
            labels.add("Remove main flag");
            acts.add(() -> { t.main = false; store.save(); refreshList(); });
        } else {
            labels.add("Set as MAIN (holds the Google accounts)");
            acts.add(() -> {
                for (Store.Tab o : store.tabs) o.main = false;
                t.main = true;
                t.link = false;
                store.save();
                refreshList();
                Toast.makeText(this, "Sign in to your Google accounts in this session. Linked sessions copy them.",
                        Toast.LENGTH_LONG).show();
            });
            labels.add(t.link ? "Unlink from main" : "Link Google accounts to main");
            acts.add(() -> { t.link = !t.link; store.save(); refreshList(); });
        }
        labels.add("Delete session (erases its logins)");
        acts.add(() -> confirmDelete(t));
        new AlertDialog.Builder(this).setTitle(t.name)
                .setItems(labels.toArray(new String[0]), (d, w) -> acts.get(w).run()).show();
    }

    private void confirmDelete(final Store.Tab t) {
        new AlertDialog.Builder(this)
                .setTitle("Delete \"" + t.name + "\"?")
                .setMessage("Its logins and data are erased. This cannot be undone.")
                .setPositiveButton("Delete", (d, w) -> deleteTab(t))
                .setNegativeButton("Cancel", null).show();
    }

    private void deleteTab(Store.Tab t) {
        if (t == cur) closePage("delete");
        store.tabs.remove(t);
        stateFile(t.id).delete();
        Dbg.d("deleted session " + t.id);
        if (!deleteProfileNow(t.id)) store.pendingDel.add(t.id);
        store.save();
        refreshList();
    }

    private boolean deleteProfileNow(String id) {
        if (!profilesOk) return true;
        try {
            ProfileStore.getInstance().deleteProfile(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void retryPendingDeletes() {
        if (store.pendingDel.isEmpty()) return;
        ArrayList<String> left = new ArrayList<>();
        for (String id : store.pendingDel) if (!deleteProfileNow(id)) left.add(id);
        store.pendingDel.clear();
        store.pendingDel.addAll(left);
        store.save();
    }

    // =====================================================================
    // the page
    // =====================================================================

    private boolean has(String perm) { return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED; }

    /** Hide the "Android WebView" brand in client hints (Google sign-in checks it). */
    private void chromeBrands(WebSettings ws) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) return;
            String ua = ws.getUserAgentString();
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("Chrome/(\\d+)\\.([\\d.]+)").matcher(ua);
            if (!m.find()) return;
            String major = m.group(1), full = m.group(1) + "." + m.group(2);
            java.util.List<UserAgentMetadata.BrandVersion> b = new java.util.ArrayList<>();
            b.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build());
            b.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build());
            b.add(new UserAgentMetadata.BrandVersion.Builder().setBrand("Not.A/Brand").setMajorVersion("99").setFullVersion("99.0.0.0").build());
            WebSettingsCompat.setUserAgentMetadata(ws, new UserAgentMetadata.Builder()
                    .setBrandVersionList(b).setPlatform("Android").setMobile(true).build());
        } catch (Throwable e) { Dbg.d("brands failed: " + e); }
    }

    private void closePopup() {
        if (popup == null) return;
        try { if (cookies != null) cookies.flush(); } catch (Throwable ignored) { }
        holder.removeView(popup);
        popup.destroy();
        popup = null;
    }

    private void destroyWeb(String reason) {
        Dbg.d("destroyWeb reason=" + reason + " page=" + (web != null) + (web != null ? " " + backState() : ""));
        handler.removeCallbacks(syncTick);
        closePopup();
        pendingPerm = null;
        if (filePathCb != null) { filePathCb.onReceiveValue(null); filePathCb = null; }
        if (web != null) {
            if (!"render-gone".equals(reason)) {
                try {
                    String u = web.getUrl();
                    if (u != null && cur != null) cur.url = u;
                } catch (Exception ignored) { }
                saveWebState(cur);   // keeps the back history for when you open the session again
                if (cookies != null) cookies.flush();
            }
            holder.removeView(web);
            web.destroy();                // frees RAM; the session's data stays on disk
            web = null;
        }
        cookies = null;
    }

    /** Unload the page but KEEP the session. */
    private void closePage(String why) {
        destroyWeb(why);
        cur = null;
        store.save();
        showSessions();
    }

    private void openTab(Store.Tab t, String urlOverride) {
        if (t == cur && web != null && urlOverride == null) { showPage(); return; }
        Dbg.d("openTab " + t.id + " (" + t.name + ") main=" + t.main + " link=" + t.link);
        destroyWeb("switch");
        cur = t;

        web = new WebView(this);
        if (profilesOk) {
            // must be called before any other call on this WebView
            Profile p = ProfileStore.getInstance().getOrCreateProfile(t.id);
            WebViewCompat.setProfile(web, t.id);
            cookies = p.getCookieManager();
        } else {
            cookies = CookieManager.getInstance();
        }
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(web, true);   // needed by many login flows

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);    // voice-mode audio replies
        s.setAllowFileAccess(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        // look like Chrome, not a WebView (helps Google sign-in pages)
        s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
        chromeBrands(s);
        try {   // do not announce our package name to websites (Google checks this header)
            if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
                WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, new HashSet<String>());
            }
        } catch (Throwable ignored) { }

        web.addJavascriptInterface(new Bridge(), "ARB");
        try {   // run in every frame before the page's own scripts
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(web, HOOK_JS, new HashSet<String>(Arrays.asList("*")));
            }
        } catch (Throwable e) {
            Dbg.d("document-start script failed: " + e);
        }

        final Store.Tab mine = t;
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, Bitmap f) {
                Dbg.d("page started " + Dbg.url(u));
                onUrl(mine, u);
            }
            @Override public void onPageFinished(WebView v, String u) {
                Dbg.d("page finished " + Dbg.url(u));
                v.evaluateJavascript(HOOK_JS, null);   // fallback if the document-start script is unsupported
                onUrl(mine, u);
            }
            @Override public void doUpdateVisitedHistory(WebView v, String u, boolean isReload) {
                try {
                    WebBackForwardList l = v.copyBackForwardList();
                    Dbg.d("history update " + Dbg.url(u) + " idx=" + l.getCurrentIndex() + "/" + (l.getSize() - 1)
                            + (isReload ? " reload" : ""));
                } catch (Throwable ignored) { }
                onUrl(mine, u);
            }
            @Override public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                Dbg.d("RENDER PROCESS GONE crashed=" + d.didCrash() + " (killed by Android = low memory)");
                if (v == web) {
                    destroyWeb("render-gone");
                    cur = null;
                    store.save();
                    showSessions();
                    Toast.makeText(MainActivity.this,
                            "The page was closed (probably low memory). Tap the session to reopen it.",
                            Toast.LENGTH_LONG).show();
                }
                return true;   // we handled it: the app itself keeps running
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")
                        || u.startsWith("blob:") || u.startsWith("data:") || u.startsWith("javascript:")) {
                    return false;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); }   // mailto:, tel:, apps
                catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                try {
                    closePopup();
                    final WebView pw = new WebView(MainActivity.this);
                    if (profilesOk) WebViewCompat.setProfile(pw, mine.id);
                    CookieManager cm = profilesOk ? ProfileStore.getInstance().getOrCreateProfile(mine.id).getCookieManager()
                            : CookieManager.getInstance();
                    cm.setAcceptThirdPartyCookies(pw, true);
                    WebSettings ps = pw.getSettings();
                    ps.setJavaScriptEnabled(true);
                    ps.setDomStorageEnabled(true);
                    ps.setSupportMultipleWindows(false);
                    ps.setUserAgentString(ps.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
                    chromeBrands(ps);
                    try {
                        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST))
                            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(ps, new HashSet<String>());
                    } catch (Throwable ignored) { }
                    pw.setWebViewClient(new WebViewClient());
                    pw.setWebChromeClient(new WebChromeClient() {
                        @Override public void onCloseWindow(WebView w) { Dbg.d("popup closed by page"); closePopup(); }
                    });
                    popup = pw;
                    holder.addView(pw, new FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                    WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                    tr.setWebView(pw);
                    msg.sendToTarget();
                    Dbg.d("popup opened");
                    return true;
                } catch (Throwable e) { Dbg.d("popup failed: " + e); return false; }
            }
            @Override public void onCloseWindow(WebView w) { closePopup(); }
            // microphone + camera (voice messages, voice mode, camera input)
            @Override public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    ArrayList<String> grant = new ArrayList<>();
                    ArrayList<String> need = new ArrayList<>();
                    for (String res : r.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                            grant.add(res);
                            if (!has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                        } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)) {
                            grant.add(res);
                            if (!has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                        }
                    }
                    if (grant.isEmpty()) { r.deny(); return; }
                    if (need.isEmpty()) { r.grant(grant.toArray(new String[0])); return; }
                    pendingPerm = r;
                    requestPermissions(need.toArray(new String[0]), REQ_PERM);
                });
            }

            // file / photo upload
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) filePathCb.onReceiveValue(null);
                filePathCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((du, dua, dcd, dmime, dlen) -> download(du, dua, dcd, dmime));

        holder.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        syncFromMain(t, false);
        boolean restored = false;
        Bundle st = loadWebState(t.id);
        if (st != null) {
            try {
                WebBackForwardList rl = web.restoreState(st);
                restored = rl != null && rl.getSize() > 0;
            } catch (Throwable e) {
                Dbg.d("restoreState failed: " + e);
            }
        }
        String target = urlOverride != null ? urlOverride : t.url;
        if (urlOverride != null || !restored) {
            t.url = target;
            web.loadUrl(target);
        }
        Dbg.d("opened " + t.id + " historyRestored=" + restored + " url=" + Dbg.url(target));
        urlBar.setText(target);
        if (t.link && !t.main) handler.postDelayed(syncTick, SYNC_TICK_MS);
        showPage();
    }

    private void onUrl(Store.Tab t, String u) {
        if (u == null || t != cur) return;
        t.url = u;
        if (!urlBar.hasFocus()) urlBar.setText(u);
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty() || web == null) return;
        String u;
        if (in.startsWith("http://") || in.startsWith("https://")) u = in;
        else if (in.contains(" ") || !in.contains(".")) u = "https://www.google.com/search?q=" + Uri.encode(in);
        else u = "https://" + in;
        web.loadUrl(u);
    }

    private void pageMenu() {
        if (cur == null) return;
        final ArrayList<String> labels = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        if (cur.main) { labels.add("Bookmarks"); acts.add(this::showBookmarks); }
        if (web != null && web.canGoForward()) { labels.add("Forward"); acts.add(() -> { if (web != null) web.goForward(); }); }
        labels.add("Reload");
        acts.add(() -> { if (web != null) web.reload(); });
        labels.add("Rename this session");
        acts.add(() -> askText("Rename session", cur.name, s -> {
            if (!s.isEmpty() && cur != null) { cur.name = s; store.save(); nameLabel.setText(s); }
        }));
        labels.add("Copy bug report");
        acts.add(this::copyBugReport);
        labels.add("Close page (keeps the session)");
        acts.add(() -> closePage("menu"));
        new AlertDialog.Builder(this).setTitle(cur.name)
                .setItems(labels.toArray(new String[0]), (d, w) -> acts.get(w).run()).show();
    }

    // ---------- bookmarks (main session only) ----------

    private void showBookmarks() {
        if (cur == null || web == null) return;
        final int n = store.marks.size();
        String[] labels = new String[n + 2];
        for (int i = 0; i < n; i++) labels[i] = store.marks.get(i)[0];
        labels[n] = "+ Add this page";
        labels[n + 1] = "- Remove a bookmark...";
        new AlertDialog.Builder(this).setTitle("Bookmarks").setItems(labels, (d, w) -> {
            if (w < n) {
                Dbg.d("bookmark opened: " + Dbg.url(store.marks.get(w)[1]));
                go(store.marks.get(w)[1]);
            } else if (w == n) {
                addBookmark();
            } else {
                removeBookmark();
            }
        }).show();
    }

    private void addBookmark() {
        if (web == null) return;
        final String u = web.getUrl();
        if (u == null) return;
        String t = web.getTitle();
        askText("Bookmark name", t != null && !t.isEmpty() ? t : Uri.parse(u).getHost(), s -> {
            if (s.isEmpty()) return;
            store.marks.add(new String[]{s, u});
            store.save();
            Toast.makeText(this, "Bookmark added", Toast.LENGTH_SHORT).show();
        });
    }

    private void removeBookmark() {
        if (store.marks.isEmpty()) return;
        String[] labels = new String[store.marks.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = store.marks.get(i)[0];
        new AlertDialog.Builder(this).setTitle("Tap a bookmark to remove it").setItems(labels, (d, w) -> {
            String name = store.marks.get(w)[0];
            store.marks.remove(w);
            store.save();
            Toast.makeText(this, "Removed " + name, Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Cancel", null).show();
    }

    // ---------- bug report ----------

    private void copyBugReport() {
        String r = Dbg.report(this, store, cur != null ? cur.id : "none", web != null, 200);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("AR bug report", r));
            Toast.makeText(this, "Bug report copied. Paste it in a chat with Claude.", Toast.LENGTH_LONG).show();
        } catch (Throwable e) {
            Toast.makeText(this, "Could not copy: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ---------- keep each page's back history while it is unloaded ----------

    private File stateFile(String id) { return new File(getFilesDir(), "ws_" + id + ".bin"); }

    private void saveWebState(Store.Tab t) {
        if (web == null || t == null) return;
        Parcel p = Parcel.obtain();
        try {
            Bundle st = new Bundle();
            WebBackForwardList l = web.saveState(st);
            if (l == null || l.getSize() == 0) return;
            p.writeBundle(st);
            byte[] b = p.marshall();
            if (b.length > 4 * 1024 * 1024) return;
            try (FileOutputStream o = new FileOutputStream(stateFile(t.id))) { o.write(b); }
        } catch (Throwable e) {
            Dbg.d("saveState failed: " + e);
        } finally {
            p.recycle();
        }
    }

    private Bundle loadWebState(String id) {
        File f = stateFile(id);
        if (!f.exists()) return null;
        Parcel p = Parcel.obtain();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = Bake.readAll(in);
            p.unmarshall(b, 0, b.length);
            p.setDataPosition(0);
            return p.readBundle(getClassLoader());
        } catch (Throwable e) {
            Dbg.d("loadState failed: " + e);
            return null;
        } finally {
            p.recycle();
        }
    }

    private void runPendingLink() {
        final String link = pendingLink;
        pendingLink = null;
        if (link == null) return;
        if (web != null && cur != null) { showPage(); web.loadUrl(link); return; }
        if (store.tabs.isEmpty()) {
            Toast.makeText(this, "Create a session first, then open the link again.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[store.tabs.size()];
        for (int i = 0; i < names.length; i++) names[i] = store.tabs.get(i).name;
        new AlertDialog.Builder(this).setTitle("Open link in which session?")
                .setItems(names, (d, w) -> openTab(store.tabs.get(w), link))
                .setNegativeButton("Cancel", null).show();
    }

    // =====================================================================
    // Google accounts: main session -> linked sessions
    // =====================================================================

    /** Copies the Google cookies of the MAIN session into this (linked) session. Best effort. */
    private void syncFromMain(Store.Tab t, boolean force) {
        if (!profilesOk || t == null || !t.link || t.main) return;
        Store.Tab m = store.main();
        if (m == null || m.id.equals(t.id)) return;
        long now = SystemClock.elapsedRealtime();
        if (!force && t.lastSync != 0 && now - t.lastSync < 20000) return;
        t.lastSync = now;
        try {
            long t0 = SystemClock.elapsedRealtime();
            ProfileStore ps = ProfileStore.getInstance();
            CookieManager src = ps.getOrCreateProfile(m.id).getCookieManager();
            StringBuilder all = new StringBuilder();
            ArrayList<String> got = new ArrayList<>();
            for (String u : GOOGLE_URLS) {
                String ck = src.getCookie(u);
                got.add(ck == null ? "" : ck);
                all.append(ck).append('|');
            }
            Integer h = all.toString().hashCode();
            if (h.equals(lastSync.get(t.id))) { Dbg.d("google link: unchanged, skipped"); return; }   // saves ~0.7 s per tab open
            CookieManager dst = ps.getOrCreateProfile(t.id).getCookieManager();
            int copied = 0;
            for (int i = 0; i < GOOGLE_URLS.length; i++) {
                String u = GOOGLE_URLS[i], ck = got.get(i);
                if (ck.isEmpty()) continue;
                for (String kv : ck.split(";\\s*")) {
                    if (kv.indexOf('=') <= 0) continue;
                    dst.setCookie(u, kv + "; Path=/; Secure; SameSite=None; Max-Age=31536000");
                    copied++;
                }
            }
            dst.flush();
            lastSync.put(t.id, h);
            Dbg.d("google link: " + copied + " cookies main->" + t.id + " " + (SystemClock.elapsedRealtime() - t0) + "ms");
        } catch (Throwable e) {
            Dbg.d("google link failed: " + e);
        }
    }

    // =====================================================================
    // settings + Make APK
    // =====================================================================

    private void showSettings() {
        final String[] items = {
                "Copy bug report (last 200 lines)",
                "Make APK (clone with my sessions)...",
                "Fingerprint / screen lock: " + (store.lock ? "ON" : "OFF"),
                "Home page for new sessions:\n" + store.home,
                "Downloads: " + DL_LABELS[store.dlMode],
                "Check session storage",
                "Automation (salute): " + Auto.label(this)
        };
        new AlertDialog.Builder(this).setTitle("Settings").setItems(items, (d, w) -> {
            if (w == 0) copyBugReport();
            else if (w == 1) askMakeApk();
            else if (w == 2) toggleLock();
            else if (w == 3) askText("Home page", store.home, s -> {
                if (!s.isEmpty()) {
                    store.home = (s.startsWith("http://") || s.startsWith("https://")) ? s : "https://" + s;
                    store.save();
                }
            });
            else if (w == 4) new AlertDialog.Builder(this).setTitle("Downloads")
                    .setSingleChoiceItems(DL_LABELS, store.dlMode, (d2, k) -> {
                        store.dlMode = k;
                        store.save();
                        d2.dismiss();
                        Toast.makeText(this, "Downloads: " + DL_LABELS[k], Toast.LENGTH_SHORT).show();
                    }).setNegativeButton("Cancel", null).show();
            else if (w == 6) showAuto();
            else new AlertDialog.Builder(this).setTitle("Session storage")
                    .setMessage(Bake.describe(this, store)).setPositiveButton("OK", null).show();
        }).show();
    }


    // ---------------- Automation: send a message in a session at a set time ----------------
    private boolean autoBusy = false, autoRelock = false;
    private int autoTries = 0, autoI = 0;
    private final java.util.List<Store.Tab> autoQ = new java.util.ArrayList<>();
    private String autoSum = "";
    private final android.os.Handler autoH = new android.os.Handler(android.os.Looper.getMainLooper());

    private void showAuto() {
        final StringBuilder sn = new StringBuilder();
        for (String id : Auto.sids(this)) { Store.Tab x = store.byId(id); if (x != null) sn.append(sn.length() > 0 ? ", " : "").append(x.name); }
        final String sname = sn.length() == 0 ? "(none)" : sn.toString();
        final String[] items = {
                "Enabled: " + (Auto.on(this) ? "ON" : "OFF"),
                "Sessions: " + sname,
                String.format(java.util.Locale.US, "Time: %02d:%02d", Auto.hour(this), Auto.min(this)),
                "Message: " + Auto.msg(this),
                "Repeat: " + (Auto.daily(this) ? "every day" : "one time"),
                "Run test now",
                "Phone unlock pattern: " + (Auto.pat(this).isEmpty() ? "not set" : "set"),
                "Shizuku: " + (Sh.granted() ? "ready" : Sh.running() ? "running, tap to allow AR" : "not running")
        };
        new AlertDialog.Builder(this).setTitle("Automation").setItems(items, (d, w) -> {
            android.content.SharedPreferences.Editor e = Auto.p(this).edit();
            if (w == 0) {
                if (!Auto.on(this) && Auto.sid(this).isEmpty()) {
                    Toast.makeText(this, "Pick a session first.", Toast.LENGTH_SHORT).show();
                } else { e.putBoolean("on", !Auto.on(this)).apply(); Auto.schedule(this); }
                showAuto();
            } else if (w == 1) {
                final int n = store.tabs.size();
                String[] names = new String[n];
                final boolean[] chk = new boolean[n];
                java.util.List<String> cur0 = Auto.sids(this);
                for (int i = 0; i < n; i++) { names[i] = store.tabs.get(i).name; chk[i] = cur0.contains(store.tabs.get(i).id); }
                new AlertDialog.Builder(this).setTitle("Sessions (in order)").setMultiChoiceItems(names, chk, (d2, k, on) -> chk[k] = on)
                        .setPositiveButton("OK", (d2, k) -> {
                            StringBuilder ids = new StringBuilder();
                            for (int i = 0; i < n; i++) if (chk[i]) ids.append(ids.length() > 0 ? "," : "").append(store.tabs.get(i).id);
                            Auto.p(this).edit().putString("sid", ids.toString()).apply();
                            Auto.schedule(this);
                            showAuto();
                        }).setNegativeButton("Cancel", (d2, k) -> showAuto()).show();
            } else if (w == 2) {
                new android.app.TimePickerDialog(this, (tp, h, m) -> {
                    Auto.p(this).edit().putInt("h", h).putInt("m", m).apply();
                    Auto.schedule(this);
                    showAuto();
                }, Auto.hour(this), Auto.min(this), true).show();
            } else if (w == 3) {
                askText("Message", Auto.msg(this), s -> {
                    if (!s.isEmpty()) Auto.p(this).edit().putString("msg", s).apply();
                    showAuto();
                });
            } else if (w == 4) {
                e.putBoolean("daily", !Auto.daily(this)).apply();
                Auto.schedule(this);
                showAuto();
            } else if (w == 5) {
                runAuto(true);
            } else if (w == 6) {
                askText("Pattern dots 1-9 (1 2 3 / 4 5 6 / 7 8 9). Empty = none", "", s -> {
                    boolean ok = s.isEmpty() || (s.matches("[1-9]{2,9}") && s.chars().distinct().count() == s.length());
                    if (ok) Auto.p(this).edit().putString("pat", s).apply();
                    else Toast.makeText(this, "Digits 1-9, no repeats.", Toast.LENGTH_LONG).show();
                    showAuto();
                });
            } else {
                if (Sh.granted()) Toast.makeText(this, "Shizuku is ready.", Toast.LENGTH_SHORT).show();
                else if (Sh.running()) Sh.request(100);
                else Toast.makeText(this, "Start Shizuku first (Wireless debugging).", Toast.LENGTH_LONG).show();
            }
        }).setNegativeButton("Close", null).show();
    }

    /** Opens the chosen session on claude.ai/new, waits (pages are slow) until the box exists, sends, closes. */
    private void runAuto(final boolean test) {
        if (autoBusy) { Dbg.d("auto: already running"); return; }
        final boolean wasFg = inForeground;
        autoQ.clear();
        for (String id : Auto.sids(this)) { Store.Tab x = store.byId(id); if (x != null) autoQ.add(x); }
        if (!test) Auto.afterRun(this);
        if (autoQ.isEmpty()) { Dbg.d("auto: session missing"); return; }
        if (store.lock && deviceSecure() && !test) { Dbg.d("auto: skipped, app lock is ON"); return; }
        autoBusy = true;
        autoI = 0;
        autoSum = "";
        try {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
        runAutoOne(autoQ.get(0), test, wasFg);
    }

    private void runAutoOne(final Store.Tab t, final boolean test, final boolean wasFg) {
        autoTries = 0;
        Dbg.d("auto: start test=" + test + " session=" + t.id + " (" + (autoI + 1) + "/" + autoQ.size() + ")");
        // ?q= pre-fills the box (more reliable than typing); the script types only if the box is still empty
        openTab(t, "https://claude.ai/new?q=" + android.net.Uri.encode(Auto.msg(this)));
        final String js = "(function(){try{"
                + "var p=location.pathname;"
                + "if(p.indexOf('/login')==0)return 'login';"
                + "if(window.__arClicked)return p.indexOf('/chat/')==0?'sent':'clicked';"
                + "if(p.indexOf('/new')!=0&&p!=='/')return 'wait';"
                + "var ed=document.querySelector('div.ProseMirror[contenteditable=\"true\"]')"
                + "||document.querySelector('div[contenteditable=\"true\"]')||document.querySelector('textarea');"
                + "if(!ed)return 'wait';"
                + "var txt=(ed.value!==undefined?ed.value:ed.innerText)||'';"
                + "if(!txt.trim()){"
                + "if((window.__arTyped||0)>=3)return 'empty';"
                + "window.__arTyped=(window.__arTyped||0)+1;ed.focus();"
                + "if(ed.tagName=='TEXTAREA'){var st=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;"
                + "st.call(ed,MSG);ed.dispatchEvent(new Event('input',{bubbles:true}));}"
                + "else{document.execCommand('insertText',false,MSG);}"
                + "return 'typed';}"
                + "var b=null,bs=document.querySelectorAll('button');"
                + "for(var i=0;i<bs.length;i++){var l=(bs[i].getAttribute('aria-label')||'')+' '+(bs[i].getAttribute('data-testid')||'');"
                + "if(/send|submit/i.test(l)&&!bs[i].disabled){b=bs[i];break;}}"
                + "if(!b){var c=ed;for(var k=0;k<5&&c.parentElement;k++)c=c.parentElement;"
                + "var er=ed.getBoundingClientRect(),best=-1,cb=c.querySelectorAll('button');"
                + "for(var j=0;j<cb.length;j++){var r=cb[j].getBoundingClientRect();"
                + "if(!cb[j].disabled&&r.width>0&&r.top>=er.top-10&&r.left>best){best=r.left;b=cb[j];}}}"
                + "if(b){b.click();window.__arClicked=true;return 'clicked';}"
                + "var n=[];for(var m=0;m<bs.length;m++)n.push((bs[m].getAttribute('aria-label')||'?').slice(0,20)+(bs[m].disabled?'(d)':''));"
                + "return 'nobtn:'+n.join('|');"
                + "}catch(e){return 'err '+e;}})()";
        final String script = js.replace("MSG", org.json.JSONObject.quote(Auto.msg(this)));
        final Runnable[] poll = new Runnable[1];
        final String[] last = { "" };
        poll[0] = () -> {
            if (web == null || cur != t) { autoEnd(test, wasFg, "FAILED: page gone"); return; }
            autoTries++;
            web.evaluateJavascript(script, r -> {
                String res = r == null ? "" : r.replace("\"", "");
                if (!res.equals(last[0])) { last[0] = res; Dbg.d("auto: try " + autoTries + " -> " + res); }
                if (res.equals("sent")) {
                    autoH.postDelayed(() -> autoEnd(test, wasFg, "sent (chat opened)"), 5000);
                } else if (res.equals("login")) {
                    autoEnd(test, wasFg, "FAILED: session is logged out");
                } else if (res.equals("empty")) {
                    autoEnd(test, wasFg, "FAILED: could not put text in the box");
                } else if (autoTries >= 75) {
                    autoEnd(test, wasFg, "FAILED: not sent, last=" + res);
                } else {
                    autoH.postDelayed(poll[0], 2000);
                }
            });
        };
        autoH.postDelayed(poll[0], 6000);
    }

    private void autoEnd(boolean test, boolean wasFg, String why) {
        autoH.removeCallbacksAndMessages(null);
        Dbg.d("auto: end " + why);
        autoSum += (autoSum.isEmpty() ? "" : "; ") + (autoI < autoQ.size() ? autoQ.get(autoI).name : "?") + ": " + why;
        if (autoI + 1 < autoQ.size()) {   // next session in the list
            if (web != null) closePage("auto " + why);
            autoI++;
            final Store.Tab nt = autoQ.get(autoI);
            autoH.postDelayed(() -> runAutoOne(nt, test, wasFg), 2500);
            return;
        }
        autoBusy = false;
        try {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (!wasFg) { setShowWhenLocked(false); setTurnScreenOn(false); }
        } catch (Throwable ignored) { }
        if (web != null) closePage("auto " + why);
        if (!wasFg) moveTaskToBack(true);
        if (autoRelock) {
            autoRelock = false;
            autoH.postDelayed(() -> new Thread(() -> Dbg.d("auto: relock " + Sh.run("input keyevent 26"))).start(), 1500);
        }
        if (test) Toast.makeText(this, "Automation: " + autoSum, Toast.LENGTH_LONG).show();
    }

    private void toggleLock() {
        if (!store.lock && !deviceSecure()) {
            Toast.makeText(this, "Set a screen lock or fingerprint in the phone's Settings first.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        store.lock = !store.lock;
        store.save();
        Toast.makeText(this, "Lock " + (store.lock ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
    }

    private void askMakeApk() {
        new AlertDialog.Builder(this)
                .setTitle("Make APK")
                .setMessage("Builds a signed copy of this app in Downloads, with your sessions, names and settings inside. "
                        + "It installs over the old app as an update, or on another phone as a fresh install.\n\n"
                        + "WITH logins: everyone who has the APK file gets your logged-in accounts. Keep it private.\n\n"
                        + "Any open page is closed while building.")
                .setPositiveButton("With logins", (d, w) -> makeApk(true))
                .setNeutralButton("Without logins", (d, w) -> makeApk(false))
                .setNegativeButton("Cancel", null).show();
    }

    private void makeApk(final boolean withLogins) {
        Dbg.d("makeApk start withLogins=" + withLogins);
        if (cur != null || web != null) closePage("makeapk");
        if (profilesOk) {   // push cookies to disk before copying
            for (Store.Tab t : store.tabs) {
                try {
                    Profile p = ProfileStore.getInstance().getProfile(t.id);
                    if (p != null) p.getCookieManager().flush();
                } catch (Throwable ignored) { }
            }
        }
        store.save();
        final String json = store.exportJson(true);
        final AlertDialog wait = new AlertDialog.Builder(this)
                .setTitle("Making APK").setMessage("Please wait, this can take a minute...")
                .setCancelable(false).show();
        new Thread(() -> {
            String msg;
            try {
                File zip = null;
                String note = "";
                if (withLogins) {
                    Thread.sleep(1500);   // let WebView finish writing to disk
                    zip = Bake.exportSessions(this, store, new File(getCacheDir(), "sessions.zip"));
                    note = "\n\n" + Bake.note;
                }
                msg = Cloner.make(this, json, zip) + note;
            } catch (Throwable e) {
                msg = "Failed: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            }
            final String m = msg;
            Dbg.d("makeApk result: " + (m.length() > 150 ? m.substring(0, 150) : m));
            runOnUiThread(() -> {
                try { wait.dismiss(); } catch (Exception ignored) { }
                new AlertDialog.Builder(this).setTitle("Make APK").setMessage(m)
                        .setPositiveButton("OK", null).show();
            });
        }).start();
    }

    // =====================================================================
    // lock (fingerprint, falls back to the phone's PIN / pattern)
    // =====================================================================

    private boolean deviceSecure() {
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    private void showLock() {
        Dbg.d("lock shown");
        locked = true;
        lockView.setVisibility(View.VISIBLE);
        hideKeyboard();
        lockView.post(this::authenticate);
    }

    private void unlock() {
        Dbg.d("unlocked");
        locked = false;
        authBusy = false;
        lockView.setVisibility(View.GONE);
        runPendingLink();
    }

    private void authenticate() {
        if (!locked || authBusy) return;
        if (Build.VERSION.SDK_INT >= 28) {
            authBusy = true;
            try {
                BiometricPrompt.Builder b = new BiometricPrompt.Builder(this).setTitle("Unlock AR");
                if (Build.VERSION.SDK_INT >= 30) {
                    b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK
                            | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                } else if (Build.VERSION.SDK_INT >= 29) {
                    b.setDeviceCredentialAllowed(true);
                } else {
                    b.setNegativeButton("Use PIN / pattern", getMainExecutor(), (dlg, which) -> {
                        authBusy = false;
                        keyguardFallback();
                    });
                }
                b.build().authenticate(new CancellationSignal(), getMainExecutor(),
                        new BiometricPrompt.AuthenticationCallback() {
                            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                                unlock();
                            }
                            @Override public void onAuthenticationError(int code, CharSequence msg) {
                                authBusy = false;
                                if (Build.VERSION.SDK_INT < 29 && code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                        && code != BiometricPrompt.BIOMETRIC_ERROR_CANCELED) {
                                    keyguardFallback();
                                }
                            }
                        });
            } catch (Throwable e) {
                authBusy = false;
                keyguardFallback();
            }
        } else {
            keyguardFallback();
        }
    }

    private void keyguardFallback() {
        try {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            Intent i = km.createConfirmDeviceCredentialIntent("Unlock AR", null);
            if (i != null) { authBusy = true; startActivityForResult(i, REQ_KEY); }
            else unlock();   // no lock screen set: nothing to ask
        } catch (Throwable e) {
            authBusy = false;
        }
    }

    // =====================================================================
    // results: permissions, file chooser, lock
    // =====================================================================

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == REQ_STORAGE) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingDownload != null) {
                String[] d = pendingDownload;
                pendingDownload = null;
                download(d[0], d[1], d[2], d[3]);
            }
            return;
        }
        if (pendingPerm == null) return;
        ArrayList<String> ok = new ArrayList<>();
        for (String r : pendingPerm.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && has(Manifest.permission.RECORD_AUDIO)) ok.add(r);
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && has(Manifest.permission.CAMERA)) ok.add(r);
        }
        if (ok.isEmpty()) pendingPerm.deny();
        else pendingPerm.grant(ok.toArray(new String[0]));
        pendingPerm = null;
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == REQ_KEY) {
            authBusy = false;
            if (rs == RESULT_OK) unlock();
            return;
        }
        if (rq == REQ_FILE && filePathCb != null) {
            filePathCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, data));
            filePathCb = null;
        }
    }

    // =====================================================================
    // downloads
    // =====================================================================

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
    }

    private void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_SHORT).show());
    }

    /** Receives blob: files read by JavaScript and saves them to Downloads. */
    private class Bridge {
        @JavascriptInterface
        public void note(String href, String name) {
            if (href == null) return;
            if (dlNames.size() > 60) dlNames.clear();
            dlNames.put(href, name == null ? "" : name);
        }

        @JavascriptInterface
        public void type(String href, String type) {
            if (href == null) return;
            if (dlTypes.size() > 60) dlTypes.clear();
            dlTypes.put(href, type == null ? "" : type);
        }

        @JavascriptInterface
        public void save(String b64, String mime, String name) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                if (bytes.length == 0 || bytes.length > 100 * 1024 * 1024) return;
                saveBytes(bytes, mime, name, saveMode);
            } catch (Exception ignored) { }
        }
    }

    private static String fromContentDisposition(String cd) {
        if (cd == null || cd.isEmpty()) return null;
        Matcher m = Pattern.compile("filename\\*\\s*=\\s*([^']*)'[^']*'([^;]+)", Pattern.CASE_INSENSITIVE).matcher(cd);
        if (m.find()) {
            String n = Uri.decode(m.group(2).trim().replace("\"", ""));
            if (!n.isEmpty()) return n;
        }
        m = Pattern.compile("filename\\s*=\\s*(?:\"([^\"]+)\"|([^;]+))", Pattern.CASE_INSENSITIVE).matcher(cd);
        if (m.find()) {
            String n = (m.group(1) != null ? m.group(1) : m.group(2)).trim();
            if (!n.isEmpty()) return n;
        }
        return null;
    }

    private static String sniffExt(byte[] b) {
        if (b == null || b.length < 4) return null;
        if (b[0] == '%' && b[1] == 'P' && b[2] == 'D' && b[3] == 'F') return "pdf";
        if ((b[0] & 0xff) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "png";
        if ((b[0] & 0xff) == 0xFF && (b[1] & 0xff) == 0xD8 && (b[2] & 0xff) == 0xFF) return "jpg";
        if (b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8') return "gif";
        if (b.length > 11 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F'
                && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return "webp";
        if (b[0] == 'P' && b[1] == 'K' && b[2] == 3 && b[3] == 4) return "zip";
        return null;
    }

    /** Safe file name with a proper extension (from the mime type, or the file's first bytes). */
    private static String finalName(String name, String mime, byte[] head) {
        if (name == null) name = "";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        boolean bin = name.toLowerCase(Locale.ROOT).endsWith(".bin");
        String base = bin ? name.substring(0, name.length() - 4) : name;
        int dot = base.lastIndexOf('.');
        boolean noExt = dot < 0 || dot == base.length() - 1;
        if (base.isEmpty() || base.matches("[0-9a-fA-F-]{12,}|[0-9]+")) {   // blob ids / bare numbers
            base = "download-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new java.util.Date());
            noExt = true;
        }
        if (noExt && base.endsWith(".")) base = base.substring(0, base.length() - 1);
        if (noExt || bin) {
            String ext = null;
            if (mime != null && !mime.isEmpty() && !mime.toLowerCase(Locale.ROOT).startsWith("application/octet-stream")) {
                ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.split(";")[0].trim().toLowerCase(Locale.ROOT));
            }
            if (ext == null) ext = sniffExt(head);
            if (ext != null) return base + "." + ext;
            return bin ? base + ".bin" : base;
        }
        return base;
    }

    private static final int DL_ASK = 0, DL_REPLACE = 1, DL_NORMAL = 2, DL_RENAME = 3, DL_SHARE = 4;
    private static final String[] DL_LABELS = {"ask each time", "replace same name", "normal (keep both)", "rename each time", "send to another app"};
    private volatile int saveMode = DL_NORMAL;
    private interface ModeCb { void go(int mode, String name); }

    private void download(final String url, final String agent, String cd, String mime) {
        String hint = dlNames.get(url);
        String bt = dlTypes.get(url);
        if ((mime == null || mime.isEmpty() || mime.toLowerCase(Locale.ROOT).startsWith("application/octet-stream"))
                && bt != null && !bt.isEmpty()) mime = bt;
        String name = hint != null && !hint.trim().isEmpty() ? hint.trim() : fromContentDisposition(cd);
        if (name == null) name = URLUtil.guessFileName(url, cd, mime);
        name = finalName(name, mime, null);
        Dbg.d("download " + Dbg.url(url) + " page-name=" + hint + " mime=" + mime + " -> " + name);
        final String fm = mime;
        chooseMode(name, (mode, nm) -> startDownload(url, agent, fm, finalName(nm, fm, null), mode));
    }

    /** Replace / normal / rename / send to another app: asks, or uses the mode chosen in Settings. */
    private void chooseMode(final String name, final ModeCb cb) {
        int m = store.dlMode;
        if (m == DL_RENAME) { askText("Save as", name, s -> { if (!s.isEmpty()) cb.go(DL_NORMAL, s); }); return; }
        if (m != DL_ASK) { cb.go(m, name); return; }
        String[] items = {"Replace if same name", "Download normally (keep both)", "Rename...", "Send to another app"};
        new AlertDialog.Builder(this).setTitle(name).setItems(items, (d, w) -> {
            if (w == 0) cb.go(DL_REPLACE, name);
            else if (w == 1) cb.go(DL_NORMAL, name);
            else if (w == 2) askText("Save as", name, s -> { if (!s.isEmpty()) cb.go(DL_NORMAL, s); });
            else cb.go(DL_SHARE, name);
        }).setNegativeButton("Cancel", null).show();
    }

    private void startDownload(String url, String agent, String mime, String name, int mode) {
        try {
            if (url.startsWith("blob:")) {
                if (web == null || url.contains("'") || url.contains("\\")) return;
                saveMode = mode;
                web.evaluateJavascript("(function(){var x=new XMLHttpRequest();x.open('GET','" + url
                        + "',true);x.responseType='blob';x.onload=function(){var r=new FileReader();"
                        + "r.onloadend=function(){ARB.save(String(r.result).split(',')[1]||'','"
                        + "'+(x.response.type||'" + esc(mime) + "')+'" + "','" + esc(name) + "')};r.readAsDataURL(x.response)};x.send()})()", null);
                toast("Downloading " + name);
            } else if (url.startsWith("data:")) {
                int c = url.indexOf(',');
                if (c < 0) return;
                String head = url.substring(5, c);
                String payload = url.substring(c + 1);
                byte[] bytes = head.endsWith(";base64")
                        ? Base64.decode(payload, Base64.DEFAULT)
                        : Uri.decode(payload).getBytes(StandardCharsets.UTF_8);
                saveBytes(bytes, mime, name, mode);
            } else if (mode == DL_SHARE) {
                fetchAndShare(url, agent, mime, name, cookies != null ? cookies.getCookie(url) : null);
            } else {
                if (Build.VERSION.SDK_INT < 29 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    pendingDownload = new String[]{url, agent, "", mime};
                    requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
                    return;
                }
                if (mode == DL_REPLACE) deleteExisting(name);
                DownloadManager.Request rq = new DownloadManager.Request(Uri.parse(url));
                if (mime != null && !mime.isEmpty()) rq.setMimeType(mime);
                rq.addRequestHeader("User-Agent", agent);
                String ck = cookies != null ? cookies.getCookie(url) : null;
                if (ck != null) rq.addRequestHeader("Cookie", ck);
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(rq);
                toast("Downloading " + name);
            }
        } catch (Exception e) {
            toast("Download failed");
        }
    }

    /** Deletes a file of this name in Downloads (only files this app saved are visible to it). */
    private void deleteExisting(String name) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                Uri base = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                try (Cursor c = getContentResolver().query(base, new String[]{MediaStore.Downloads._ID},
                        MediaStore.Downloads.DISPLAY_NAME + "=? AND " + MediaStore.Downloads.RELATIVE_PATH + " LIKE ?",
                        new String[]{name, "Download%"}, null)) {
                    while (c != null && c.moveToNext()) {
                        try { getContentResolver().delete(ContentUris.withAppendedId(base, c.getLong(0)), null, null); }
                        catch (Exception ignored) { }
                    }
                }
            } else {
                new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name).delete();
            }
        } catch (Throwable e) { Dbg.d("replace: delete failed " + e); }
    }

    // ---- send to another app (it does its own replace / rename) ----
    private File cacheFile(String name) {
        File dir = new File(getCacheDir(), "dl");
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) o.delete();
        return new File(dir, name.replaceAll("[\\\\/:*?\"<>|]", "_"));
    }

    private void shareFile(final File f, String mime) {
        if (mime == null || mime.isEmpty() || mime.toLowerCase(Locale.ROOT).startsWith("application/octet-stream")) {
            String n = f.getName();
            int d = n.lastIndexOf('.');
            String g = d > 0 ? MimeTypeMap.getSingleton().getMimeTypeFromExtension(n.substring(d + 1).toLowerCase(Locale.ROOT)) : null;
            mime = g != null ? g : "*/*";
        }
        final String mt = mime;
        runOnUiThread(() -> {
            try {
                Uri u = FileProvider.getUriForFile(this, "a.c.files", f);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mt);
                i.putExtra(Intent.EXTRA_STREAM, u);
                i.setClipData(ClipData.newRawUri(f.getName(), u));
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Send " + f.getName() + " to"));
            } catch (Exception e) { toast("No app to send to"); }
        });
    }

    private void shareBytes(byte[] bytes, String mime, String name) {
        try {
            File f = cacheFile(name);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
            shareFile(f, mime);
        } catch (Exception e) { toast("Send failed"); }
    }

    private void fetchAndShare(final String url, final String agent, final String mime, final String name, final String ck) {
        toast("Fetching " + name);
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(60000);
                c.setRequestProperty("User-Agent", agent);
                if (ck != null) c.setRequestProperty("Cookie", ck);
                File f = cacheFile(name);
                try (InputStream in = c.getInputStream(); FileOutputStream o = new FileOutputStream(f)) {
                    byte[] buf = new byte[32768];
                    long tot = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        tot += n;
                        if (tot > 200L * 1024 * 1024) throw new java.io.IOException("too big");
                        o.write(buf, 0, n);
                    }
                }
                shareFile(f, mime);
            } catch (Exception e) { toast("Fetch failed"); }
        }).start();
    }

    private void saveBytes(byte[] bytes, String mime, String name) { saveBytes(bytes, mime, name, DL_NORMAL); }

    private void saveBytes(byte[] bytes, String mime, String name, int mode) {
        name = finalName(name, mime, bytes);
        if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
        if (mode == DL_SHARE) { shareBytes(bytes, mime, name); return; }
        if (mode == DL_REPLACE) deleteExisting(name);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = getContentResolver().openOutputStream(u)) { o.write(bytes); }
            } else {
                File f = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name);
                if (mode != DL_REPLACE) {
                    int dot = name.lastIndexOf('.');
                    String b0 = dot > 0 ? name.substring(0, dot) : name, e0 = dot > 0 ? name.substring(dot) : "";
                    for (int k = 1; f.exists() && k < 1000; k++) f = new File(f.getParentFile(), b0 + " (" + k + ")" + e0);
                }
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
            }
            toast("Saved to Downloads: " + name);
        } catch (Exception e) {
            toast("Save failed");
        }
    }
}
