package a.c;

import android.content.pm.PackageManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Runs shell commands (uid 2000) through Shizuku. */
final class Sh {
    private Sh() { }

    static boolean running() {
        try { return Shizuku.pingBinder(); } catch (Throwable e) { return false; }
    }

    static boolean granted() {
        try {
            return running() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable e) { return false; }
    }

    /** The Shizuku binder arrives a moment after our process starts: wait for it. */
    static boolean waitReady(long ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (granted()) return true;
            try { Thread.sleep(200); } catch (InterruptedException e) { break; }
        }
        return granted();
    }

    static void request(int code) {
        try { Shizuku.requestPermission(code); } catch (Throwable e) { Dbg.d("shizuku request failed: " + e); }
    }

    /** Blocking. Call from a background thread. Returns trimmed output (or "ERR ..."). */
    static String run(String cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[]{ new String[]{"sh", "-c", cmd}, null, null });
            String out = read(p.getInputStream());
            String err = read(p.getErrorStream());
            p.waitFor();
            String r = (out + " " + err).trim();
            return r.length() > 200 ? r.substring(0, 200) : r;
        } catch (Throwable e) { return "ERR " + e; }
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toString("UTF-8");
    }
}
