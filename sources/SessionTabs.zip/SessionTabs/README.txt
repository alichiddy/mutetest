AR - tiny WebView browser, one isolated session (WebView Profile) per tab.
Package: a.c   Label: AR

RULES FOR NO-UNINSTALL UPDATES
1. Never change applicationId (a.c).
2. Never change/replace app/ar-release.keystore (back it up somewhere safe, outside GitHub too).
3. Keep it in a PRIVATE repo: the key + passwords are inside build.gradle.
4. versionCode is automatic and always increases.
5. Don't raise minSdk above your phone's Android version.

BUILD: Android Studio > Build APK(s), or: gradle assembleRelease
