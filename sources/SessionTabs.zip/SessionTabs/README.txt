AR - multi-session browser (package a.c)

KEEP FOREVER: applicationId a.c and app/ar-release.keystore (same key + same package = updates keep all logins).

What it does
- Sessions screen is the home screen. Nothing loads until you tap a session. One WebView alive at a time.
- Closing a page keeps the session. Only "Delete session" (confirmed) erases logins.
- Hold a session: Rename / Set as MAIN / Link to main / Delete.
- MAIN session holds your Google accounts. Linked sessions copy its Google cookies when opened,
  on Google/YouTube navigation, and every 4 minutes while open (best effort; Google may still ask to verify).
- Settings: Make APK (with or without logins), fingerprint/screen lock, home page, storage check.
- Old installs are migrated automatically (profiles p1, p2... keep their logins).

Bookmarks (main session only): page menu > Bookmarks. Defaults: Gmail, Add Google account, My Google account, YouTube, Claude.
  "+ Add this page" / "- Remove a bookmark". Saved in the Make APK clone too.

Back button: each page's back history is saved when the page is unloaded and restored when you open the session again.
If Android kills the page for low RAM the app no longer crashes: it returns to the sessions list.

Bug report: Settings (or page menu) > Copy bug report. Copies device info + the last 200 log lines
(back presses with history position, page loads, memory events, crashes). No cookies; URLs without query strings.

Make APK
- Copies the installed APK, replaces assets/tabs_default.json (+ assets/sessions_default.zip with logins),
  signs on the phone with the key built into assets, verifies, saves to Downloads.
- Fresh install of a clone restores everything once. Updates never touch existing data.
- A clone made WITH logins = your accounts. Never upload it or put it in the repo.

Build: unchanged (gradle assembleRelease, AGP 8.5.2). Gradle task genSigner exports the key from the keystore into assets.
