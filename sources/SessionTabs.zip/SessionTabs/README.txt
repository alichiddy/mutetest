AR - multi-session browser (package a.b)

KEEP FOREVER: applicationId a.b and app/ar-release.keystore (same key + same package = updates keep all logins).

What it does
- Sessions screen is the home screen. Nothing loads until you tap a session. One WebView alive at a time.
- Closing a page keeps the session. Only "Delete session" (confirmed) erases logins.
- Hold a session: Rename / Set as MAIN / Link to main / Delete.
- Pencil (edit) icon on every session row = rename with one tap.
- Color dot on every session row: tap to cycle empty > red > green > blue (your own marks, e.g. "has the latest source").
- Folders: "+ New folder" at the top of the list, or hold a session > "Move to folder...". Tap a folder to open it
  (Back row or Android back returns). Hold a folder: Rename / Delete (sessions inside go back to the main window).
  Sessions not in a folder stay in the main window. Folders and colors are saved in backups and in Make APK.
- MAIN session holds your Google accounts. Linked sessions copy its Google cookies when opened,
  on Google/YouTube navigation, and every 4 minutes while open (best effort; Google may still ask to verify).
- Settings: Make APK (with or without logins), fingerprint/screen lock, home page, storage check.
- Old installs are migrated automatically (profiles p1, p2... keep their logins).

Automation at limit (per session)
- Hold a session > "Automation when the limit is set: ON". From then on, whenever that session gets a limit time
  (read from the Claude page, or set by hand with "Set limit time"), a one-time automation is created for the exact minute the
  limit ends (always a new chat, fixed message: Salawat + "And just talk English please") and switched ON. Notifications must be allowed.
- Marks on the right of the session row: "Auto" with a green check = automation created and waiting;
  thumbs up "Sent" = the message was sent; thumbs down "Not sent" = it failed or was stopped.
  The result mark goes away when you open the session.
- The same automation is re-used and re-armed for the next limit (no pile of automations). "Clear limit mark" or
  turning the option OFF switches it off. You can still edit it in Automations (name: "<session> - limit").

Bookmarks (main session only): page menu > Bookmarks. Defaults: Gmail, Add Google account, My Google account, YouTube, Claude.
  "+ Add this page" / "- Remove a bookmark". Saved in the Make APK clone too.

Back button: each page's back history is saved when the page is unloaded and restored when you open the session again.
If Android kills the page for low RAM the app no longer crashes: it returns to the sessions list.

Bug report: Settings (or page menu) > Copy bug report. Copies device info + the last 200 log lines
(back presses with history position, page loads, memory events, crashes). No cookies; URLs without query strings.

Downloads: a small script (injected into every page and iframe) tells the app the real file name the website gave
(the <a download="..."> name) and the file type. Names also come from Content-Disposition (incl. UTF-8 names).
If a file still has no usable name it is called download-DATE-TIME with the right extension (from its type or first bytes).

Make APK
- Copies the installed APK, replaces assets/tabs_default.json (+ assets/sessions_default.zip with logins),
  signs on the phone with the key built into assets, verifies, saves to Downloads.
- Fresh install of a clone restores everything once. Updates never touch existing data.
- A clone made WITH logins = your accounts. Never upload it or put it in the repo.

Build: unchanged (gradle assembleRelease, AGP 8.5.2). Gradle task genSigner exports the key from the keystore into assets.
