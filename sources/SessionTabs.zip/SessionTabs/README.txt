AR - multi-session browser (package a.c)

KEEP FOREVER: applicationId a.c and app/ar-release.keystore (same key + same package = updates keep all logins).

What it does
- Sessions screen is the home screen. Nothing loads until you tap a session. One WebView alive at a time.
- Closing a page keeps the session. Only "Delete session" (confirmed) erases logins.
- Hold a session: Rename / Set as MAIN / Link to main / Delete.
- MAIN session holds your Google accounts. Linked sessions copy its Google cookies when opened,
  on Google/YouTube navigation, and every 4 minutes while open (best effort; Google may still ask to verify).
- Settings: Make APK (with or without logins), fingerprint/screen lock, home page, storage check.
- Old installs are migrated automatically (profiles p1, p2... keep their logins).

Make APK
- Copies the installed APK, replaces assets/tabs_default.json (+ assets/sessions_default.zip with logins),
  signs on the phone with the key built into assets, verifies, saves to Downloads.
- Fresh install of a clone restores everything once. Updates never touch existing data.
- A clone made WITH logins = your accounts. Never upload it or put it in the repo.

Build: unchanged (gradle assembleRelease, AGP 8.5.2). Gradle task genSigner exports the key from the keystore into assets.
