package a.a.strip

import android.content.SharedPreferences

/**
 * The "+" options of a cells window (settings in the cells window, same names per window scope):
 *
 *  - [PLUS_EMPTY]: a + in every empty cell. Releasing the thumb on it (or tapping it in the editor) opens that cell's editing window.
 *  - [HOLD_EDIT]: only when the + above is off: holding the thumb on an empty cell for the system's hold time opens its editing window.
 *  - [PLUS_END]: a + after the last cell, empty cell or not. Releasing on it adds a blank cell and opens its editing window; Cancel deletes it again.
 *
 * Each has a "where" (both / the main window only / folders only); [PLUS_END] also says from where it shows (both /
 * only from a gesture, the slide-in / only in the cells editing window).
 */
object CellPlus {
    const val PLUS_EMPTY = "stripPlusEmpty"
    const val PLUS_EMPTY_WHERE = "stripPlusEmptyWhere"
    const val HOLD_EDIT = "stripHoldEdit"
    const val PLUS_END = "stripPlusEnd"
    const val PLUS_END_WHERE = "stripPlusEndWhere"
    const val PLUS_END_FROM = "stripPlusEndFrom"

    const val WHERE_BOTH = 0
    const val WHERE_MAIN = 1
    const val WHERE_FOLDERS = 2

    const val FROM_BOTH = 0
    const val FROM_GESTURE = 1
    const val FROM_EDITOR = 2

    private fun whereOk(where: Int, folder: Boolean) = when (where) {
        WHERE_MAIN -> !folder
        WHERE_FOLDERS -> folder
        else -> true
    }

    /** A + in empty cells of this window (a folder's window when [folder]). */
    fun emptyOn(sp: SharedPreferences, folder: Boolean): Boolean =
        sp.getBoolean(PLUS_EMPTY, false) && whereOk(sp.getInt(PLUS_EMPTY_WHERE, WHERE_BOTH), folder)

    /** Holding on an empty cell opens its editing window (only while the + in empty cells is off). */
    fun holdOn(sp: SharedPreferences): Boolean = !sp.getBoolean(PLUS_EMPTY, false) && sp.getBoolean(HOLD_EDIT, false)

    /** A + after the last cell of this window, drawn by the slide-in or by the cells editing window ([editor]). */
    fun endOn(sp: SharedPreferences, folder: Boolean, editor: Boolean): Boolean {
        if (!sp.getBoolean(PLUS_END, false) || !whereOk(sp.getInt(PLUS_END_WHERE, WHERE_BOTH), folder)) return false
        return when (sp.getInt(PLUS_END_FROM, FROM_BOTH)) {
            FROM_GESTURE -> !editor
            FROM_EDITOR -> editor
            else -> true
        }
    }

    /**
     * What the slide-in asks the cells editing window to do when it opens: [path] is the folder (indices from the
     * top, empty = the main window); [index] the empty cell to edit; [add] = add a blank cell at the end of that
     * folder and edit it (deleted again when cancelled). Same process, so a plain field carries it.
     */
    data class Request(val windowId: String, val path: List<Int>, val index: Int, val add: Boolean)

    @Volatile var pending: Request? = null

    fun isBlank(c: StripItem) = c.action.isEmpty() && c.label.isEmpty() && c.icon.isEmpty() && c.children == null
}
