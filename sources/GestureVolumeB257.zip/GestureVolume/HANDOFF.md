# HANDOFF (newest first)

## B251 - Wi-Fi share: 3 QR codes + notification row, "Wi-Fi share window" shortcut, upload page (not compiled)
Base B250. Ali's 3 requests:
1. Third QR code = web address on the Wi-Fi the phone is connected to now (WifiShareService.lanIp: wlan* first, any other site-local IPv4 as fallback; refreshed every 4 s while sharing, redraws the notification only when a code changes). The window shows 3 codes in a row (tap one = big), the notification shows all 3 in one line in its expanded view (new res/layout/share_note.xml, DecoratedCustomViewStyle + setCustomBigContentView; collapsed text stays plain with the Stop button). Codes missing (no Wi-Fi / group not up yet) are hidden.
2. Built-in shortcut HandlerActions.WIFI_SHARE "Open Wi-Fi share window" (catalog Share icon, A windows list, OverlayController starts WifiShareActivity with action a.a.share.START). Starts the service with no files: Location/Wi-Fi switched on as before, group + server + QR window + notification. The same action is exported in the manifest for other launchers/automation apps.
3. Upload: server route PUT/POST /up/<name> (raw body, Content-Length required, streamed, no size limit) saved to Download through DownloadSaver (Android 10+ renames "name (1)"). Web page has "Choose files to send" + drag and drop with progress per file. Setting "Let the other device send files to this phone" (SharePrefs.upload, default on, read on every request, so no restart). Window shows files received.
Files: share/WifiShareServer.kt, WifiShareService.kt, WifiShareActivity.kt, WifiShareState.kt, res/layout/share_note.xml, strings.xml, AndroidManifest.xml, utils/HandlerActions.kt, HandlerActionCatalog.kt, ui/screens/strip/ActionPages.kt, service/OverlayController.kt (one line). Brackets of all changed .kt files balanced vs the B250 originals.
Notes: uploads are open to anyone on the network the page is reachable from (Direct group has its password; the current-Wi-Fi address is open to everyone on that router, so the checkbox can switch it off). Android 9 and older would need the storage permission at run time (not asked). The notification row could not be tested.
Script-blocks principle: built-in shortcut and share feature, not a user-buildable block (the shortcut can be run from a Scripts "Run raw shortcut" block).

## B249 - Previous app: "stop the phone locking after it switches" is now an OPTION (off by default) (not compiled)
Problem: Huawei EVR-AL00 (Android 10), power saving mode: Previous app switched, then the phone asked for the passcode. Cause: PreviousApp.resume step 3 uses `am task lock <id>` / `lock stop` (screen pinning); unpinning locks the phone when Settings.Secure lock_to_app_exit_locked is not 0. He fixed his own phone by turning that system setting off.
B248 did the guard always; B249 makes it an option: pref prevAppPinFix (PreviousApp.PREF_PIN_FIX, default false), toggle in the Previous app dialog (StripEditorScreen.kt) above "Track apps without Shizuku". On: read lock_to_app_exit_locked, set 0 (WRITE_SECURE_SETTINGS first, then `settings put secure` via Shizuku), run the pin way, restore in a finally (never-set value deleted again); if it cannot be turned off the pin way is skipped. Off: the pin way runs as before B248.
Files: utils/PreviousApp.kt (resume now takes sp), ui/screens/strip/StripEditorScreen.kt.
Script-blocks principle: built-in option, not a user-buildable block.

## B247 - tapping any .json opens "Import into A" (not compiled)
- Ali: tapping a JSON file in any app should ask to import the settings. New `strip/SettingsImportActivity.kt` (plain framework dialogs, no Compose) + manifest entry (VIEW application/json, text/json, any mime with a *.json path, SEND application/json).
- Flow: reads the file (32 MB max), must hold "prefs" else toast "not an A backup"; offers Everything / Settings only / Scripts only (only the parts the file has) / Cancel; saves the undo copy (SettingsBackup.saveUndo) and the auto backup (when on) first; SettingsBackup.apply; result box with "Undo import" (undoLast) and OK. The GitHub token is kept (restore clears it and backups never carry it).
- As Scripts blocks: not applicable (an Android file-open entry, not a user action).
- Brackets of the new file balanced; no other .kt file changed.

## B244 - A in the system file picker (not compiled)
- New `share/PickerProvider.kt` (DocumentsProvider) + manifest provider `${applicationId}.docs`: "A" shows in the picker's side menu (three lines). Opening it lists newest photos and Download files in one flat list (MediaStore, 300 max, newest first), with thumbnails; Recent also lists it. Multi-select is the picker's own.
- Needs "All files access" (already used) so non-image Download files (zips, .md) are listed. Without it only photos/own files.


## B243 - quick fixes after B242 (not compiled)
- Ali's report on B242: (a) strip opened from the volume panel on the left was not mirrored (looked like the right side); (b) the bottom-left test bar did not show at all; (c) left vertical side bar adjusts volume fine, its volume panel shows a gap between the screen side and the panel (portrait, under the status bar) - NOT fixed; (d) top-right (lying main bar on top) broke in B241: the notification shade comes in and the bar only flashes.
- (a) panelStripHandoff.onBegin sets stripSideLeft = panel side (QuickSliderView.isDrawnOnLeft()) and stripMirrorNext = side != sidesMainLeft() && prefs stripMirror (default true). Segment-owned mirror key/outside actions of the segment are not used (stripSeg = null).
- (b) test bar y now from the whole display height (screenSize()), stronger grey. Unknown why it did not show: SideSegments only builds while `allowed` (not while A's own app is in the foreground, not hidden). Ask Ali for Copy report (look for the "test bar x= y=" note).
- (d) reverted to B240: lying TOP bar margin max(edge margin, statusBarPx); side segment minTop = status bar height in landscape (aw > ah).
- (c) open: the Quick panel window is placed from the handler/anchor params, not flush display coordinates; probably the edge margin or a cut-out/status-bar inset. Needs a Copy report.
- Brackets of the 3 changed files balanced vs B241 originals (only added lines).

## B242 - volume panel hands an inward swipe to the Cells window; test bar bottom-left
- Both open requests of HANDOFF_B241_next_chat.md built on Ali's "build the ones that aren't built" (no talk first; details below are by reading, not verified).
- (2) Switch "Open the Cells window from the volume panel" (HandlerAppearanceSettingsContent, key panelOpensCells, MyPrefs, default off). QuickSliderView.StripHandoff: with it on (and not turned/lying), the first touch on the panel waits: an inward move (>= 2x slop and clearly sideways) calls OverlayController.panelStripHandoff.onBegin (panel alpha 0, showStrip(), finger forwarded through stripPoint/placeStripOnThumb/stripFinger, lift = endStrip then hideQuickSlider); a vertical move or a lift sets the level as before (so with the switch on the level is picked on first vertical move/lift, not on touch-down). Lying (turned) panel not covered. Off = code path unchanged.
- (1) Test bar: switch in the Side bars screen (key testBarOn, MyPrefs). SideSegments.addTestBar(): 240x36 dp window flush at the bottom-left of the glass (display coords, Host.origin/flush), TestBarView slides along x: left = 0, right = 100 percent, host.setLevel(MODE_VOLUME) + message. Independent of segments, so it tells whether the volume path works at all on the left. Notes: "test bar x= y= w= h= ...". refreshSides builds SideSegments also when only the test bar is on.
- Not asked Ali which left segment failed; if the test bar works but the left segment does not, the fault is in the segment (clone/SegView/stacking), see B241 notes.
- Not compiled. Brackets of the 5 changed files differ from B241 only by the added lines.

## B241 - top bars flush with the glass again (test build)
- Ali: B240 works (main bar bottom right; left side bar flush in every app he tried). Asked to put the top bar flush again to test whether the pull-down shade still steals the touch.
- OverlayController.applyHandlerGeometry(): a lying TOP bar uses the plain edge margin again (B239 clamp to statusBarPx removed). SideSegments.placeOf(): minTop = 0 (B239 clamp removed). statusBarPx() stays in HandlerGeometry, unused.
- NOT done, left for the next chat (needs talking first, see HANDOFF_B241_next_chat.md): (a) a horizontal bar at the bottom-left to test the volume swipe, (b) option to open the Cells window while the Quick volume panel (sliderView) is up.
- Not compiled. Brackets of both changed files equal the B240 originals.

## B240 - landscape: left side bars flush with the glass
- Ali (b233, vivo V2111 1600x720, 3-button nav on the right): main bar (bottom right, flush, triggers before the nav bar) now works; a side bar on the LEFT still does not trigger. His copied report was taken after turning back to portrait, so no landscape side line exists.
- Cause (by reading, not verified): side windows used the usable frame (display less camera cut-out, fitInsets displayCutout). In landscape the cut-out sits on the left short edge, so x = 0 was a cut-out's width away from the glass. The right edge has no cut-out, which is why the right worked.
- Fix: SideSegments places every window in display coordinates: x = margin (left) or displayWidth - width - margin (right), y = insetTop + top; Host.origin() (insetLeft, insetTop, displayWidth) and Host.flush(params) (LAYOUT_IN_SCREEN + NO_LIMITS, fit insets none, cut-out mode ALWAYS/SHORT_EDGES). Portrait is unchanged (no left/right insets). The "side seg" note now prints origin=.
- Not compiled. Brackets balanced; counts differ from B239 only by the added lines. If the left still fails: Copy report while in landscape (the notes show x via origin and the side seg lines).

## B239 - landscape: bars stay clear of the status bar
- Ali's report (b232, landscape 1600x720 vivo): main bar at top (Dynamic position, lying) - slide-in showed the cells window and "strip hide from ..." straight away (system notification shade takes touches that begin in the status bar zone, finger y 25-35 < 54 px); side bars were built from a stale portrait area (720x1554) - fixed in B238.
- HandlerGeometry.statusBarPx(ctx). applyHandlerGeometry(): a lying bar on the TOP uses margin max(edge offset, status bar height). SideSegments.placeOf(): in landscape a segment's top is at least the status bar height.
- Not compiled. Not verified on device (cannot be). If the shade still steals the touch, next idea: Shizuku/accessibility swallow of the status-bar pull, or option to put the bar on the bottom edge.

## B238 - landscape: side bars and main bar
- Ali: "fix the landscape nightmare" (side bars / main bar). Causes found by reading (no device report):
  1. mainBounds() returned the main bar's y/height even while it lies along the top/bottom (landscape, Dynamic position) = its thickness, so segments that follow the main bar (default "same size") came out tiny and misplaced. Now null while lying; SideSegments falls back to the saved height and place (position fraction uses the portrait key when Dynamic position is on, as persistDynamicPosition writes it).
  2. mainIsLeft() for the side bars used the lying bar's x (meaningless) so mirroring flipped at random. New OverlayController.sidesMainLeft(): lying -> saved upright side (getHandlerPosition), else handlerIsLeft(). Also used in the onStripBegin path.
  3. Host.area() preferred the cached `frame`, stale after a turn when the main bar is not up; now readFrame() first.
  4. onConfigurationChanged() now also calls refreshSides() (identical rebuilds are skipped by the signature).
- Not compiled. Brackets of OverlayController.kt and SideSegments.kt equal the B237 originals.

## B237 - the known gaps of B236 filled (1, 2, 3, 5; 4 and 6 left on purpose)
- 1 Mirrored lives in the window: key stripMirror (per window, default on). SidesActivity shows the switch bound to it when the segment has an own window (the segment's Seg.mirror is used only without own window). migrateLegacy copies Seg.mirror into it. "Copy once" keeps it, "Delete own window" removes it. SideSegments passes only `mirrored`; OverlayController.segMirror(seg) decides (also in the onStripBegin path, which ignored seg.mirror before).
- 2 Tiles in every window: strip/WidgetTiles.kt reconcile() and update() go through the main window and every own window (StripScope.load/save), shared stamp map, so a tile edited in the Widgets window rewrites its cells everywhere and cells saved in an own window get linked. Tile store itself stays one global list (so the backup covers it).
- 3 flow/SeedFlows.convertCells() converts old Automate cells in every window, not only the main one. (installExamples only writes scripts, never cells.)
- 5 Cold start into a segment's own window: MainNavigation takes the route strip_editor_scope/<id> as start destination (pattern with the id as default argument), no main screen first; Back closes the activity.
- 4 (old Seg.edge*/gapDp in JSON) kept on purpose: still used while a segment has no own window, and switching back restores them. 6 is by design: names exist only in an own window (migration moves old actions there, where they can be named).
- Not compiled. Brackets of the 7 changed files equal the B236 originals.

## B236 - names/gap bands stuck after a touch-run Click circle
- Cause: hideStrip() removed the EdgeNames view and THEN called closeFoldersFrom(0), which (since B234) calls updateEdgeNames(); stripView was still set, so the view was created again and nothing removed it. Fix: hideStrip() now closes the folders first, then removeStripTip() and removeEdgeNames().
- Not compiled. Only that block moved; brackets unchanged.

## B235 - folder options for names and glow; outside options moved next to the counts
- B234 hid the names unconditionally when a folder opened; now it is an option. New keys (window prefs): stripEdgeNamesHideFolder (hide the names of all outside actions while a folder is open, default off) and stripEdgeGlowHideFolder (hide the glow while a folder is open, default off: the outside-side glow of the thumb AND the gap bands).
- OverlayController.updateEdgeNames(): names/gaps flags now include those options (the view is removed only when neither names nor bands remain); view key includes them. updateStripTip(): glow = 0 when a folder is open and the glow option is on. Tip/popup stays on top (tipToFront).
- StripEditorScreen.kt EdgeCounts: the four -/+ counts are one column stuck to the left; on the right are three switches: "Show the names of all outside actions..." (moved here from the Gap, popup and effects dialog, key stripEdgeAll unchanged), "Hide those names when a folder is opened", "Hide the glow when a folder is opened".
- Not compiled. Bracket balance of both changed files equals the B233 originals' difference.

## B234 - names hidden while a folder is open, popup always on top
- OverlayController.updateEdgeNames(): returns (and removes the EdgeNames view) while folderLevels is not empty; openFolder and closeFoldersFrom call it so names/bands go at once and come back when the folders close.
- New tipToFront(): the cell popup (StripTip window) is removed and re-added after the EdgeNames window is added and after a folder window opens, so it is always the top-most window.
- The "Show the names of all outside actions..." switch already lives in the Gap, popup and effects dialog (key stripEdgeAll); unchanged.
- Not compiled. Brackets checked against B233 original: same balance.

## B233 - names on screen fixed, gap shown at true size, Gap switch moved under the live view
- Names/bands were drawn too low on screen: the full-screen EdgeNames window was pushed down by the status bar / camera cut-out (about 30 dp on Ali's Vivo) while the window bounds are absolute screen px. OverlayController.updateEdgeNames(): the window now has layoutInDisplayCutoutMode ALWAYS (SHORT_EDGES below R). strip/EdgeNames.kt also draws back by getLocationOnScreen() as a safety net, and the pill margin to the window/gap end is 2 dp (was 4).
- Editor live view (EdgeFrame in StripEditorScreen.kt): the gap is drawn at its true size (dp x density, same px as on screen). Each side's frame = the strip of fields shown + that side's gap. If the picture is wider than the screen the whole thing shrinks together (graphicsLayer scale, layout reports the scaled size), so sizes stay true to each other. Hit test uses the per-side frame.
- GapPanel moved from the top of the list to directly under the live view and above "+ Add a cell / + Add a folder". One row: "Gap" + on/off switch (stripCxlOn) + button "Show gap options" / "Hide gap options". The options (4 sliders, Blur/Glow/Colour, swatches, #RRGGBB) open under that row and can be hidden while the gap stays on. State: gapOnS (on) and gapMode (options shown, default hidden) in the screen. Tapping a field toggles its gap only while options are shown AND the gap is on.
- Not compiled. Brackets of EdgeNames.kt, OverlayController.kt, StripEditorScreen.kt checked against the B232 originals: same balance.

## B232 - cancel gap redone the way Ali imagined (per side, per field, live in the editor, coloured)
- Replaces B231's gap (its dialog switch/slider and keys stripEdgeGapOn/stripEdgeGapDp are gone; the "Show the names of all outside actions" switch stays in the Popup/effects dialog, key stripEdgeAll).
- Keys (window prefs, all "strip..." so scoped + in the backup as settings): stripCxlOn (whole idea), stripCxlDp<Side> (0..150 dp, default 24, per side), stripCxl<Side>_<zone> (that field's gap active, default true), stripCxlStyle (2 blur default, 1 glow, 0 colour), stripCxlColor (ARGB, default red). Helpers in strip/EdgeFields.kt (gapOn/gapDp/gapActive/gapFor/gapStyle/gapColor, GAP_MAX_DP).
- ui/screens/strip/StripEditorScreen.kt: `GapPanel` is the FIRST item of the list (main window only): a "Gap" button that opens the controls in place (no sub menu): whole-idea switch, 4 sliders (Top/Bottom, Left/Right), Blur/Glow/Colour choice, 8 colour swatches + #RRGGBB field. While it is open the long outside-actions text and the Select-fields row are hidden so the picture comes up close. In the live picture (EdgeFrame) every field draws its gap band (colour/style) and the fields are squeezed by it (slider 0..150 dp = 0..(strip depth - 14 dp)); tapping a field while Gap is open switches the gap next to it on/off (instead of opening its editor); a cancelled field has no band and keeps its full depth.
- service/OverlayController.kt: gapPxFor(side, zone); outsideAt() returns null when the best distance <= that field's gap (release, touch-run, glow, tip all follow). updateEdgeNames() builds the one touch-free full-screen EdgeNames view when names and/or gap is on: gap bands = the frame between window edge and d px out, split per field (45 deg at the ends, same wedge rule as outsideAt), names placed where each field STARTS (window edge, or far end of that field's gap). Same mirrored-window mapping as outsideAt.
- strip/EdgeNames.kt rewritten: pills anchored at the field start; beside the window the name is upright (top to bottom) when the room is too narrow for it flat; blur/glow use BlurMaskFilter with a software layer (only while the view exists).
- Gap applies on screen only to fields with an action (an empty field does nothing anyway); the editor picture shows bands for every field.
- Names still match the settings (EdgeFields.displayName).
- Not compiled. Brackets of OverlayController.kt, StripEditorScreen.kt, EdgeFields.kt balance; EdgeNames.kt new.

## B231 - outside actions: cancel gap, names of all fields, live names
- Ali's ask: (1) optional gap, user-sized, between the cells window and the outside actions, so releasing the thumb in it cancels without running anything when every side/cell is full; (2) optional display of the names of ALL outside actions the moment the slide-in opens; (3) the name shown at the thumb and in that overview must match the name in the Cells window settings (live).
- Prefs (per window, via stripPrefs / the editor's `sp`): `stripEdgeGapOn` (bool, default off), `stripEdgeGapDp` (int 0..150 in the UI, default 24), `stripEdgeAll` (bool, default off). Settings: the Popup/effects dialog of the cells window editor, under "A tick when the thumb enters such a side".
- service/OverlayController.kt: edgeDeadPx(); outsideAt() returns null when the best distance <= gap (so release, touch-run, glow and name all ignore the gap; exactly the window inflated by the gap). edgeNameFor() = EdgeFields.displayName (user's own name, else action name; own-segment outside actions have no names kept, so the action name). The thumb label now uses it (fallback: old SidePicker.label). updateEdgeNames() (called from stripFinger after updateStripTip) builds one full-screen touch-free EdgeNames view when the option is on and the thumb is on the strip; rebuilt only when the window bounds change; removed in endStrip and hideStrip. Idle: nothing exists. Mirrored windows use the same side/zone mapping as outsideAt.
- New strip/EdgeNames.kt: pills with each field's name at the field's centre (above/below: along the window; beside: in the room left of/right of it), the field under the thumb lit amber, a dashed outline of the gap when it is on. Fields with no room (<30 dp) get no pill.
- strip/EdgeFields.kt: actionName(context, action) (moved from the editor, plus "Script: <name>" for MyFlow:) and displayName(...). The editor's edgeActionName delegates to it, so both places always agree.
- Not done: names are built when the window opens (a name can not change while the thumb is down); a segment's own outside actions do not show user names (none kept).
- Not compiled. Brackets of OverlayController.kt, StripEditorScreen.kt, EdgeFields.kt balance like the B230 originals (new file EdgeNames.kt balances).

## B230 - merge: Segments line (own cells windows) + running-scripts line (OCR/countdown, notifications, tiles backup, cell fixes)
- Two lines were built in parallel from B225 and both used the numbers B226..B229. Base of this build = Segments B229 (scope plumbing, own windows, CellTarget, outside-field moves); everything of the other line was added on top. The other line's entries are kept below with the suffix "-run line".
- Taken whole from the run line (Segments line never touched them): flow/Countdown.kt, FlowActivity.kt, FlowCanvasEditor.kt, FlowHelpers.kt, FlowRunner.kt, Step.kt, new flow/RunningNotes.kt, strip/ScreenOcr.kt, strip/WidgetFloat.kt (readNow accept), strip/StripConfig.kt (settlePins keepPath/keep, firstBlank, withNewCell), manifest receiver .flow.FlowStopReceiver.
- Hand-merged: strip/SettingsBackup.kt = Segments' isStripKey() + the tiles backup (widgetTiles + widgetTilesGone in the scripts part, restoreTiles in apply); ui/screens/strip/StripEditorScreen.kt = Segments' windowId/sp/StripScope + commit/commitItems keep, "+ Add a cell" takes the first blank, "+ Add a folder" uses withNewCell; strip/LauncherCatcher.kt = Segments' saveToCellsIn(id) + withNewCell/keep (so every cell saved from outside takes the first blank, in the main or an own window).
- Everything else is the Segments file unchanged (StripScope, CellTarget, SidesActivity, SideConfig, OverlayController, EdgeFields, StripView, WidgetHostActivity, WidgetTiles, MainActivity, MainNavigation).
- Known gaps: tile backup covers the main tile store only (tiles are not per window); a tile saved into a segment's own window is not kept in sync (as in Segments B229). The ask-which-window dialog saves through saveToCellsIn, so it gets the first-blank rule too.
- Not compiled. Brackets of the merged files match the sources; manifest parses.

## B229-run line - B228 fixed: layout logic is B227's again; add cell / folder take the first blank
- B228 added a padding rule to settlePins that made blank rows undeletable and put added folders on the right; it is gone. settlePins is exactly B227's, plus two optional params (keepPath, keep) that keep the last `keep` cells of one folder level from the trailing-blank trim.
- strip/StripConfig.kt: firstBlank(list) = first unpinned blank cell; withNewCell(list, fresh) = fresh replaces the first blank, else goes at the end (settlePins then gives it its own row above the pinned bottom row, blank cells fill the row); a blank fresh cell returns keep = 1 so it is not trimmed.
- ui/screens/strip/StripEditorScreen.kt: "+ Add a cell" selects the first blank, or adds one; "+ Add a folder" uses withNewCell; commit/commitItems take keep. strip/LauncherCatcher.kt ActionSaver.saveToCells uses withNewCell (built-in shortcuts, widgets, Grab it).
- strip/SettingsBackup.kt (from B228, unchanged): widgetTiles + widgetTilesGone in the scripts part of the backup, merged by tile id on restore.
- Not compiled. Brackets of the changed files match the B227 originals.

## B227-run line - running scripts: notifications with Stop, Always On, stop one / stop all, running on top
- Ali's request (step 1 of 2; sorting options are NOT built yet, asked for the next step): each running script shows a notification with a Stop button; scripts with the "Always On" box ticked share ONE notification; every running script can be stopped separately in the Scripts window (also Always On ones); running scripts sorted to the top; a "Stop all running scripts" button.
- flow/FlowRunner.kt: the single global stopAll flag is gone. Run(id, name, since, alwaysOn) with @Volatile stopped and the run's thread; registry runs (ConcurrentHashMap). run() makes a Run at depth 0 (own = true), registers it, and removes it in finally (Thread.interrupted() clears a late interrupt). Nested and "at the same time" scripts get the same token (new param token). API: running(): List<RunInfo>, isRunning(id), stop(id), stopByName(name), stopAllRuns(alwaysOnOnly), stop() = all. halt() sets the flag and interrupts the run's thread so a Wait block ends at once; failed() says "Stopped" instead of an error when the run was stopped. Every old `{ stopAll }` lambda now reads tk.stopped (OCR wait, countdown, field wait, rate limit).
- New flow/RunningNotes.kt: channel "scripts_running" (low). started() posts nothing for the first 1000 ms (quick cell presses stay silent), then refresh(): own notification per non-Always-On run (title = script, chronometer, Stop action, tap opens Scripts), one shared notification for Always On runs (InboxStyle with names, action "Stop all of them"); ended() refreshes, so notifications vanish when the run ends. FlowStopReceiver (manifest receiver, exported=false) handles the Stop buttons; if the run is no longer known (process was killed) it removes the stale notification. ids: 7390 shared, 7500 + runId % 900.
- flow/FlowHelpers.kt FlowPrefs: isAlwaysOn / setAlwaysOn (string set "alwaysOn" in prefs FlowPrefs, keyed by the script id so renames keep it; not in the settings backup).
- flow/FlowCanvasEditor.kt: "Always On" checkbox in the top bar of the script editor; the editor's Stop button now stops only this script (stopByName).
- flow/FlowActivity.kt: runningNow polled once a second only while the list is open; "Stop all running scripts (N)" button; running scripts sorted first (stable) with "running" / "Always On, running" and a Stop button on the row.
- AndroidManifest.xml: receiver .flow.FlowStopReceiver.
- Not compiled. Brackets of the changed files balance like the B226 originals; manifest parses. Android 13+ needs the notification permission to be granted for the notifications to show.
- Next (asked, not built): sort options in the Scripts list (name, last used, last opened, created, last modified, type with its branches Cell/Automate/Script/Widget/Imported/Restored), as checkboxes with a priority order; this needs "last used / opened / created / modified" times, which are not stored yet.

## B226-run line - OCR wait skips wrong readings; new countdown (movable, opacity, minimize, bar/notification, one shared countdown)
- Ali's report (installed b218): the widget shows the bank's error word (khata, Persian) first; the OCR reads it as digits (00040, or 90400900) and OCR wait took it, so the real code (e.g. 02827, in the same candidate list, the Persian zero is a small dot) was lost; the countdown also restarted on every rerun and the pill could not be moved.
- flow/Step.kt: two new optional fields e and f (JSON "e", "f", written only when not empty; old flows load as before). OCRWAIT: e = exactly this many digits ("" any), f = readings to ignore, comma separated. COUNTDOWN: c = bar | notice | both | none, d = opacity 10..100, e = name (same name = one countdown), f = join | stop | restart. RATELIMIT: e = show as, f = opacity.
- strip/ScreenOcr.kt waitRead(..., digitCount, ignore, stop): acceptable(v) rejects an ignored reading (Persian digits and spaces normalised) and an all-digit reading of the wrong length; used for the widget path and the box path; a rejected reading is skipped and the wait goes on until the time is up (then ocr_found = no). DiagLog line "OCR wait: ... digits=N ignore=..." shows the settings.
- strip/WidgetFloat.kt readNow(app, id, timeoutMs, accept): picks the first candidate that passes accept (length 4..12 first), no fallback to a rejected one. Default accepts everything (NativeActions caller unchanged).
- flow/Countdown.kt rewritten: Opts(show, opacity, name, again); sessions map by name (users counted, the last one out removes the bar and the notification). Bar: touchable, drag anywhere (position kept in prefs file "countdown_pos"), "-" shrinks it to the time only ("+" restores), opacity = view alpha. Notification: channel "countdown" (low importance), chronometer counting down by itself (no updates), ongoing, auto-removed. A rerun with again = join continues the same countdown; stop = returns false and FlowRunner stops that run; restart = new one. RATELIMIT joins "limit:<name>".
- flow/FlowRunner.kt, flow/FlowCanvasEditor.kt (forms: digits count pick, ignore field, countdown show-as / opacity / name / when-already pick; BlockForm keeps e and f), Step.describe.
- Script guide (A_script_guide_for_AI.txt) updated: e and f fields, countdown options, and a rule that the AI should describe a missing block for the code AI instead of only refusing.
- RsaltMe_Bank_widget_code_fixed.afl uses e="5", f="00040,90400900", countdown name "bank code wait" (same id #q4w8e2r6: importing replaces the earlier copy).
- Not compiled. Brackets of the 6 changed .kt files balance like the originals. Not done yet (asked, waiting): notifications with a Stop button per running script, "Always On" shared notification, Stop all running scripts button, sort options in the Scripts list.

## B229 - old rows move into the own window, "ask which window", delete button
- strip/StripScope.kt: migrateLegacy(context, seg, mirrored) (called once when a segment is first switched to its own window: its old gap and, unless edgeFollow, outside actions/field counts go into the new scope; written swapped (Left<->Right, Top/Bottom zones reversed) when the segment is mirrored, because the new window is swapped at runtime like the main one while old own actions kept their sides); deleteWindow(id); exists(id). Old Seg fields stay in the JSON, unused.
- sides/SidesActivity.kt: the "Mirrored" row stays visible with an own window (no scope key exists for it; Seg.mirror is still what the runtime reads); button "Delete this segment's own window" (confirm; removes all strip*_<id> keys, ownWindow = false).
- New strip/CellTarget.kt: CellTarget.save(context, label, action, icon) = main window, or, with the switch "Ask me which cells window..." (pref cellTargetAsk, in the Widgets/Launcher mode window) on and at least one own window, a small dialog (CellTargetActivity, registered in the manifest, transparent, no history) listing Main slider + each own window. ActionSaver.saveToCellsIn(context, id, ...) does the saving; saveToCells = main. Used by WidgetHostActivity (4), PinCatcherActivity, WidgetTiles.add.
- Not routed: SeedFlows.installExamples (installs examples into the main window only, by design). Tile <-> cell syncing (WidgetTiles.reconcile/update) looks at the main window only, so a tile saved into a segment's window is not kept in sync.
- Backup checked by reading, no change needed: stripConfigV1_<id> = "scripts"; the other scoped keys (strip*_<id>) and the side config = "settings"; restoring one part without the other leaves a window empty or its keys unused, no crash; a restore on a phone without that segment id keeps the keys, ignored.
- Not compiled.

## B228 - segment UI: own cells window switch, settings button, editor route
- sides/SidesActivity.kt (segment box): switch "Cells window: same as the main slider" (on = ownWindow false). Turning it off the first time (no stripConfigV1_<id> yet) asks "This segment gets its own empty cells window"; later switching back and forth keeps the window saved. Button "Cells window settings" opens the editor: main window when on, the segment's own window (extra scope = seg.id) when off. Button "Copy the main slider's cells and settings once" (only when off): replaces the own window by a copy of stripConfigV1 and every strip* key (keys of other segments' windows skipped; shared non-strip keys untouched). The old rows (gap, mirrored, Action outside of cells window) are hidden while ownWindow is on and kept while it is off.
- ui/activities/MainActivity.kt: EXTRA_SCOPE + routeOf(intent) -> "strip_editor_scope/<id>" (works on a running instance via onNewIntent and on a cold start via the LaunchedEffect; a cold start goes through "main" first). MainNavigation.kt accepts that route.
- ui/screens/strip/StripEditorScreen.kt: title "Cells window of Left 1" for an own window; "Cells enabled" switch hidden there; a note says Widgets/Launcher mode, Previous app, Click circle are shared.
- Not done (B229): migration of the old rows' values, "ask which window", backups check, delete own window button. Built on B227, so no merge problem. Not compiled.

## B227 - scope plumbing for per-segment cells windows (no visible change yet)
- Plan and the other builds (B228 segment switch + button, B229 migration/ask-which-window/merge): see HANDOFF_segment_windows_B226.md (Ali has it).
- strip/StripScope.kt: StripScope.prefs/configKey/load/save/ownWindowIds + ScopedPrefs (adds "_<id>" to every name starting with "strip"; other names pass through; its editor's clear() only removes this window's own names). A segment's own window starts empty (StripConfig(items = emptyList())), never the built-in list.
- sides/SideConfig.kt: Seg.id (JSON "sid"; ids made on load for old saves and saved back) and Seg.ownWindow (JSON "ow", default false = same as main).
- ui/screens/strip/StripEditorScreen.kt: new parameter windowId (default ""); `sp` = the window's prefs for every "strip..." setting (40 places), cells load/save through StripScope; click circle / previous app settings stay on pref.sharedPreferences. ui/activities/MainNavigation.kt: route "strip_editor_scope/{scope}".
- strip/StripView.kt: constructor takes `prefs` (default MyPrefs). service/OverlayController.kt: stripScopeId()/stripPrefs()/stripConfig() (cache keyed by window id) from `stripSeg`; edge fields, gap, popup/effects, folder options, StripView creation read that window; legacy per-segment edge rows are ignored when ownWindow.
- strip/SettingsBackup.kt: isStripKey() (stripConfigV1 and stripConfigV1_<id> are "scripts"); icon export scans all of them.
- With every segment on "same as main" nothing changes from B226. Not compiled.

## B226 - outside fields (main slider) can be swapped, moved and deleted
- Ali's request: the "Actions outside of the cells window" fields freely movable: hold one and drop it on another to swap (or on an empty one to move); Select several, move them to other fields (replacing what is there), delete several.
- strip/EdgeFields.kt: parse(key), sorted(keys), swap(sp, a, b) (action with its @touch: mark and the Meta travel), move(sp, from, side, zone0) (the picked fields, in Top/Left/Bottom/Right then zone order, go to consecutive fields of one side starting at zone0; targets are replaced, sources not covered become empty, the side's field count is raised when needed, 6 at most, else a message and nothing changes), clearMany(sp, keys). One apply() each, sources are read before anything is written.
- ui/screens/strip/StripEditorScreen.kt: EdgeFrame got a second pointerInput (detectDragGesturesAfterLongPress; only a field that has an action can be picked up; a ghost "swap" tile follows the finger; the field under it lights up; release on another field = onSwap) and params marked/onSwap; a tap still opens the editor, but in Select mode it ticks/unticks the field (ticked fields are lit), and after "Move to..." it is the target. "Select fields" button row under the outside-actions toggle: N selected, Move to..., Delete, Clear. Status line says Swapped / Moved N / Deleted N / not enough room.
- Not done: a segment's OWN outside fields (sides/SidesActivity.kt dialog, Seg.edgeMore) are a separate list screen and storage and do not have this yet; segments that follow the main slider already show the moved fields. Not compiled.

## B225 - pinned cells really stay; pin dot corner and distance
- Ali's request: a pinned cell stays where it is when cells are deleted or added; the bottom-right pin stays bottom-right when a row is added (blank cells fill the new row); pin dot corner + distance; make the follow-the-bottom behaviour an option (pinned folders in the corner opened while passing), also "only folders".
- strip/StripConfig.kt: StripItem.pinBottom + pinCol (JSON "pb" = column, only when pinned and in the bottom row). settlePins(list, columns, follow): grid of `columns` (folders use their own cols), rows = ceil(size/columns). A pin that is pinBottom and allowed by `follow` (PIN_ALL 0 / PIN_FOLDERS 1 / PIN_NONE 2) goes to the last row, its column (next free if taken); other pins keep pinSlot (next free down, else up); other cells fill the free slots in order; free slots that end up below a pin become blank cells; the list ends at the last pin or cell. Blank cells at the very end of the non-pin cells are dropped first when a following pin exists (they are only padding), so deleting the cell in front of the pin lets the row go. After placing, every pin's pinSlot/pinBottom/pinCol is rewritten to where it landed (so the stored place always matches). anchorPin(l, at, columns) = a pin moved on purpose. deleteCells(list, ids): a deleted cell with a pin after it (a pin not deleted) becomes a blank; no pin after = removed; a blank is always removed.
- ui/screens/strip/StripEditorScreen.kt: commit settles with next.columns and pref "stripPinFollow" (default 0); anchor/applyDrop/Pin button use anchorPin with viewCols; Delete (single and multi) uses deleteCells. Add/Copy/Blank/Make folder need no change: settlePins does the work after them.
- strip/LauncherCatcher.kt saveToCells: settles after appending.
- strip/StripView.kt + ui/screens/strip/LookDialog.kt ("Pinned cells"): prefs stripPinFollow (0 all, 1 only folders, 2 never), stripPinDotCorner (0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right), stripPinDotX / stripPinDotY (0..24 dp, gap between the dot and the cell's side / top-bottom). Until X or Y is touched the dot sits exactly as before (top-left). With mirror on the corner is the corner as drawn. New PickRow composable in LookDialog.
- Old saves have no "pb": the first change of the cells marks the pins that sit in the bottom row as followers. The option is read at the next change of the cells (not live).
- Not compiled. Logic checked by a Python port (example from the handoff, delete with/without pin after, add x3, folders-only, collapse of the extra row).

## B224 - the bubble can hide half outside the screen
- Ali's request: let the minimized bubble sit half outside the screen, so only its other half shows.
- strip/FloatBubble.kt: the position range is now -half .. screen-half on both axes (half = 23 dp), and the window has FLAG_LAYOUT_IN_SCREEN | FLAG_LAYOUT_NO_LIMITS (without NO_LIMITS Android pushes an overlay back inside). The visible half still takes the tap and the drag. Positions saved in B223 load fine; y is now measured from the very top of the screen (a few dp shift at most). No snapping: it stays where it is dropped. Not compiled.

## B223 - minimize button on floating popups (widgets, notes, gallery)
- Ali's request: a button next to the x of any floating popup, especially Notes and Gallery, to move the window away temporarily instead of closing it, easy to move and restore.
- New strip/FloatBubble.kt: a 46 dp round overlay (first letter of the window), draggable anywhere (touch slop, clamped to the screen), tap = restore; position kept per window in prefs file "float_bubbles"; a second bubble starts lower so they do not overlap; exists only while something is minimized (no idle cost). show() returns false when it cannot be added, then the window is left as it was.
- strip/WidgetFloat.kt FloatWindow: "-" button before the x in the top bar (only when the top bar is shown); minimize() = bubble + root GONE + FLAG_NOT_TOUCHABLE, auto-close timer cancelled; restore() = back as it was, auto-close rescheduled; close() removes the bubble; press() restores first (a tile cannot be pressed in a hidden window); WidgetFloat.show(toggle) restores a minimized window instead of closing it.
- strip/FloatTools.kt ToolWindow (Notes, Gallery): same "-" button, minimize()/restore(), also NOT_FOCUSABLE while hidden so no keyboard; FloatTools.toggle restores a minimized window instead of closing it; close() removes the bubble.
- Not done: no close button on the bubble itself (restore, then x); minimized windows are not remembered after A is killed. Not compiled.

## B222 - saved tiles: edit after saving, list in the widget window, live both ways
- Ali's request: edit the Grab it window after the cell is saved; also save the tile in the widget window (a widget can have several buttons, e.g. Eitaa chats); edits in either place (or in the cell's raw text) update the other. Answers: deleting the cell keeps the tile; old tiles appear too.
- New strip/WidgetTiles.kt: TileRec(id, name, wid, pkg, details, action) kept in prefs file "widget_tiles" (+ string set "removed"). The link between tile and cell is the extra "tid" inside the cell's raw "Intent:" text, so cells keep working with no other change. reconcile(): (1) a cell whose raw text or name differs from its tile wins and updates the tile; (2) tile cells without tid (saved before B222) get a tid and a tile (identical cells share one tile); (3) a tile whose cell was deleted stays; (4) a tid with no tile (restored backup) recreates the tile; tids in "removed" are ignored. update(): rewrites the tile and every cell with that tid (nested folders too). remove(): list only, cells stay, tid tombstoned.
- strip/WidgetHostActivity.kt: reconcile in onResume (so edits made in the cells window show on return); "Saved tiles" list under each widget card (Edit, Test, Add as a cell when it has no cell, Remove with a confirm); Grab it dialog has an edit mode (title "Edit this saved tile", Save changes tile and all its cells) built by loadDraft(rec) from the raw extras; new tiles go to the list and the strip, plus a "Save here only" button. A tile shows under a widget when wid matches, or when its widget id is gone and the package matches.
- Not done: tile records are not in the settings backup (a restore recreates them from cells that carry tid; tiles saved with "Save here only" are lost in a restore). Raw edited into something that is no longer a widget press stops being a tile. Not compiled.

## B221 - A opens .afl files (import by tapping the file)
- Ali's request: like Automate opens .flo files, A should recognise .afl so he can import faster.
- New flow/FlowImportActivity.kt (translucent, no history, not in recents, exported): reads the file from VIEW data or SEND EXTRA_STREAM (or EXTRA_TEXT) with FlowShare.import / importText, toasts "Imported N script(s): names" or "That is not an A scripts file (.afl).", then opens FlowActivity with extra "flow" = first imported script (editor opens at once, so he can paste the raw shortcut). Nothing runs at import; same id overwrites the same script.
- AndroidManifest.xml: three intent filters. (1) VIEW, scheme content/file, host *, mimeType */*, pathPattern ending in .afl (4 variants for names with dots). (2) VIEW with mime application/x-afl. (3) SEND with application/x-afl and application/octet-stream (chat apps often send .afl as octet-stream with no extension in the path; A then shows in the share sheet for those files and the importer rejects non-.afl content with a toast). Label "Import into A".
- Not compiled. If a file manager does not offer A for the file, "Import shared flows" in Scripts still works.

## B220 - example scripts for the widget code (editable blocks)
- Ali asked for the actual scripts, built from the new blocks, editable in the canvas editor.
- flow/SeedFlows.kt: `examples` + installExamples(context) (adds only missing ones). Script 1 "Example: widget button missing": If widget button NOT found -> Shizuku `am force-stop mob.banking.android.resalat` -> wait 500 -> Open app (go back after 1500 ms) -> note about adding Run raw shortcut -> End -> Stop. Script 2 "Example: read code and paste": 2-minute rule (countdown, 120000 ms) -> If widget button found -> Read with OCR and wait (widgetnow, digits, 40000 ms, variable ocr) -> If ocr_found = yes: Copy text {ocr}, Wait for a field with the cursor (30000), Paste; Else: Countdown 120000 with a note to add the widget run again + another OCR wait. Package, times and source are values to edit in the blocks.
- flow/FlowActivity.kt: button "Add example scripts" in the Scripts list. The raw shortcut block is not pre-filled (it would fail empty): the note says where to add it. Not compiled.

## B219 - Previous app: killed-in-background tasks count, App Clone tasks count, report line
- Ali's report (installed build was b211, so B212-B218 were not on the phone yet): after leaving Eitaa with Back, Previous app said "nothing found" although Recents holds many apps.
- Likely cause (a fact from the code, not yet confirmed by a report): PreviousApp.parse() marked every task with "sz=0" as hiddenFromRecents. sz=0 is a task whose process was killed in the background; Recents still lists it and startActivityFromRecents restores it. On his RAM-starved phone most older tasks are like that, so only the live one (Eitaa) counted, and as the current app it was skipped. Now only FLAG_EXCLUDE_FROM_RECENTS and isAvailable=false mean hidden.
- counts(): a task of another user (user != 0, e.g. the vivo App Clone) skips isUsableApp (package list is per user).
- go(): one DiagLog.note line "Previous app: pkg#taskId uN vis hidden home skipped NO ... -> chosen" for the first 10 tasks, so the next report shows why an app was skipped ("NO" = does not count). Not compiled.

## B218 - Previous app: no launcher-icon steps, quick-switch without Shizuku
- Ali's request: return to the previous app exactly as left, only apps still in recents, nothing when none; Swiftly-Switch-style last-used list (already: Shizuku `dumpsys activity recents`, skips A, launcher, systemui, pickers, hidden-from-recents, frozen/suspended apps).
- utils/PreviousApp.kt resume(): removed step "replay the task's start intent" and step "launcher icon" (both land on the main screen). Order now: startActivityFromRecents -> moveTaskToFront(WITH_HOME) -> `am task lock` / `lock stop`; each checked with isFront().
- go(): the old fallback that started the app's launcher intent from the usage/tracked history is gone. With no readable Shizuku recents: if pickFromHistory (usage events / tracked) finds a valid previous app, quickSwitch() = accessibility GLOBAL_ACTION_RECENTS twice 170 ms apart (via OverlayRuntime.accessibilityService.performSystemAction(RECENTS)), lastHow = "accessibility quick-switch (Recents twice)" (shown by the Test button); else the existing "nothing found" message (bar or toast option). Vivo (Funtouch) may treat double Recents differently: unverified, ask Ali for the Test text if it fails. Not compiled.

## B217 - OCR boxes are in the backup
- strip/SettingsBackup.kt: the scripts part ("A only scripts" and "A all settings") now carries "ocrBoxes" (prefs file ocr_boxes) and "ocrBoxAliases" (ocr_box_aliases) as name -> text; restoreOcr() writes them back when scripts are restored (same names replaced, other boxes stay; undo-last-restore does not remove boxes a restore added). Older backups without these keys restore as before. Needs SettingsBackup.init (already called from the Application). Not compiled.

## B216 - renamed OCR boxes keep working
- Ali picked option 3 (boxes follow renames). Done without turning boxes into flows: strip/ScreenOcr.kt keeps a second prefs file "ocr_box_aliases" (old name -> new name, like FlowStore aliases). renameBox records it, saveBox clears an alias of the same name, new currentName(app, name) follows the chain (max 8 hops) and box() uses it, so the OCR shortcut, OCR wait block and old cells that still say the old name find the renamed box. Delete does not clear aliases (harmless).
- Rename dialog in the Scripts list now says so. Not done: boxes as real flows (id, in the flow backup) - ocr_boxes prefs may not be in the settings backup; check SettingsBackup if Ali wants boxes backed up. Also verified: clip_set substitutes {variables} (FlowRunner sub(s.b)), no change needed. Not compiled.

## B215 - Save-tile dialog: "Open an app first" hidden unless used
- strip/WidgetHostActivity.kt StepsBlock: the "Open an app first" chooser is gone for new cells (a Scripts block does it); a cell that already has one still shows it with Clear and its wait box, so old cells keep working. A hint says to add a script as a shortcut.
- Kept on purpose: the "+ Add a shortcut" lists (they are the only way to attach a My Script to a widget cell); removing them would lose that. Ask Ali only if he still wants them removed. stepPick 3 is now unused code. Not compiled.

## B214 - OCR boxes in the Scripts list
- Ali's answers: boxes appear BOTH in the normal Scripts list (marked "OCR box: name") AND in an "OCR boxes only" view; old boxes are not important; OCR pickers keep boxes plus widget / USSD choices (unchanged, ActionArgs "ocr_area" and the OCRWAIT form already do that).
- Storage unchanged: boxes stay in prefs file "ocr_boxes" (ScreenOcr.boxNames/saveBox/renameBox/deleteBox); the Scripts list shows them as virtual rows, so every old box appears at once and nothing is migrated. They are not real flows (no id, not in backups of flows, not selectable with the flow checkboxes).
- flow/FlowActivity.kt: resumeTick (refresh on onResume), buttons "Show OCR boxes only" and "New OCR box", box rows first in the list (search also matches "ocr"), tap a row -> dialog: Draw it again on the screen / Rename / Delete. Renaming does not update shortcuts that already use the old name (stated in the dialog).
- strip/OcrActivity.kt: extras "boxnew" (true) and "boxredo" (box name) start boxPick at once; fromScripts makes bringBack() return to FlowActivity (REORDER_TO_FRONT) and finish.
- Not done: the old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (ask Ali). Not compiled.

## B213 - built-in "Open an app" can go back after a time
- utils/HandlerActions.kt: launchApp(pkg, backMs = -1) stores "Launch app:<pkg>|back=<ms>"; launchedPackage() ignores the suffix (so every old caller, name and icon still works); new launchedBackMs(action) (null = stay open).
- service/OverlayController.kt: the Launch-app action with a back time runs WidgetFloat.openThenBack(context, pkg, ms) on a thread (same logic as the script block and Grab it).
- ui/screens/strip/ActionPages.kt (BuiltInPage): after picking an app a dialog asks "Stay open" / "Go back after a time" (ms box, default 1500). onPickApp is now (InstalledApp, backMs) -> Unit; the 4 callers updated (StripEditorScreen, SegmentPickerUi, ShortcutActivities, WidgetHostActivity). The older ActionPicker.kt app path is unchanged (stay open only).
- Not done: old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (ask Ali), B214 OCR boxes as Scripts items (design still to be agreed with Ali). Not compiled.

## B212 - universal script blocks (part 2): OCR wait, countdown, wait for a field, rate limit
- New block types in flow/Step.kt (all are plain linear blocks, run in FlowRunner.exec): OCRWAIT (a = source "box:<name>" | "widget" | "widgetnow", b = digits | text | both | word:<w>, c = ms, d = variable; also sets ocr_found yes/no), COUNTDOWN (a = ms, b = text), FIELDWAIT (a = ms; sets field_found yes/no), RATELIMIT (a = name, b = ms between runs, c = countdown | wait | stop, d = text; last run time kept in prefs file "flow_limits").
- strip/ScreenOcr.kt: waitRead() (written text first through the text reader, picture only for digits, same value twice in a row, one DiagLog line "OCR wait: ..." per run, returns "" on timeout, no error) and waitField(). Widgets are digits only (WidgetFloat.readNow got a timeoutMs parameter). strip/TextReaderService.kt: hasInputFocus() (focused editable node).
- New file flow/Countdown.kt: dark pill overlay at the top, not touchable, removed when done (toast when overlay is not allowed).
- flow/FlowGraph.kt Interpreter: after a block, vars["__stop__"] makes the flow stop (used by RATELIMIT "stop").
- Editor: FlowCanvasEditor catalog entries and forms ("Read with OCR and wait", "Countdown", "Wait for a field with the cursor", "Limit how often (2-minute rule)"), BlockForm now saves d too; FlowPickers.variablesIn lists ocr, ocr_found, field_found; FlowCanvasView titles.
- Copy to clipboard and Paste already exist as "Device: Copy text to the clipboard" (argument {ocr}) and "Device: Paste into the focused field". Not changed: the old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (still there, to be removed once Ali agrees), the built-in shortcut "Open an app" go-back option. Not compiled.

## B211 - universal script blocks (part 1): widget button found, open app and go back, raw shortcut, run widget again
- Principle (Ali): anything he asks for should be buildable by the user as a Scripts (flow) block, not hard-coded, like Automate; blocks are reused so the app stays small.
- strip/WidgetFloat.kt: pressState (0 none, 1 looking, 2 pressed, 3 tile not found) set by press()/FloatWindow.press()/handleNow(); waitPress(maxMs) blocks until settled; openThenBack(app, pkg, ms) = the Grab it "open an app, wait, go back" logic (warmUp + wait + PreviousApp.go + 600 ms), now also used by handle() for the cell's warm-up app. handle(): new extras "again", "againMs", "post2", "post2Ms": after the after-shortcuts the same tile is pressed again, then post2 shortcuts run.
- flow/NativeActions.kt check(): is("widgetbutton") waits up to 60 s for the last widget press and answers found / not found.
- flow/FlowCanvasEditor.kt: Decision -> "Phone state" -> "Widget button" (was found / was not found). Open app block: "Stay open" or "Go back after a time" (ms box; stored in Step.b). New catalog entry "Run raw shortcut (paste it)" = Step.INTENT with b = "raw" (text field + paste button); FlowRunner strips a leading "Intent:" so a cell's stored action text can be pasted as it is.
- flow/FlowRunner.kt LAUNCH uses openThenBack when b is set; flow/Step.kt, flow/FlowCanvasView.kt: labels.
- strip/WidgetHostActivity.kt (Save this tile as a cell): toggle "Run the widget again after the shortcuts above", wait box, and a third list "Shortcuts after the second run" (stepPick 4; Draft.again/againMs/post2/post2Ms).
- Not done on purpose: the old "Open an app first" and the two "Add a shortcut" lists stay in the Save-tile dialog until scripts can fully replace them (B212). The built-in shortcut "Open an app" (BuiltInPage onPickApp, many callers) has no go-back option yet: only the script block has it. Not compiled.

## B210 - OCR diagnostics
- strip/ScreenOcr.kt: read(app, saved, given, boxName) now wraps readCore() and writes ONE line per run to A's report (DiagLog.note "OCR run: path=... text=... box=... top=... tries=... lastPicture=... ms=... result=..."). path says which reader gave the answer: "text", or "text ignored (no digits), then picture", "text empty, then picture", "text reader off, then picture". top = screen on top when the run started (dumpsys, through Shizuku).
- Behaviour change in readCore(): written text from the text reader that has no digit (Character.isDigit, so Persian/Arabic digits count) is ignored and the picture reader runs. Suspected cause of the bug "later runs paste the bank name": the text reader returned "Risalat Banking" before the picture was read. Still a guess until a report shows the line.
- flow/NativeActions.kt: the box name is passed to read(boxName = name) so the line shows it. Not compiled.
- Next: B211 (OTP button not found: force-stop bank app, reopen, move its window away; 2-minute OTP block with countdown; needs the bank app package name), then B212 (OCR boxes saved into Scripts as OCR items).

## B209 - bank widget return fix (ReturnGuard)
- strip/ReturnGuard.kt: topPackage() now also reads the resumed screen's class name (topAct). If the top app is A itself but the screen is not the tapped one (for example LauncherModeActivity after the bank's screen closed), it runs "am start -n a.a/<screen> -f 0x20000" and clears the "other app" mark. Before, a.a on top was always treated as fine. Nothing else changed. Not compiled.

## B208 - OCR named boxes, version code follows the build number, Home entry renamed
- app/build.gradle.kts: versionCode = buildNo (the GitHub run number) when it is a number, else 42, so every build is a real update.
- OCR shortcut (ocr_area): the argument list no longer has "choose it when it runs" or "last saved part". It lists the NAMED BOXES made in the OCR screen (section 4: New box / Rename / Drag again / Delete; prefs file "ocr_boxes", name -> l,t,r,b as screen fractions) plus selected widget, widget on screen now and USSD, each as Copy it / Copy and type it. Stored argument: "copy:box:<name>" or "type:box:<name>". Old values "copy", "copy:region", "type", "type:region" still run and show a label. ActionArgs.specFor(id, ctx) takes a context to name the boxes; ScreenOcr.read(app, given = region). Renaming a box does not update shortcuts that already use the old name.
- Manifest: LauncherHomeActivity (the temporary launcher mode HOME entry) has its own label "A Home", so launchers that list it no longer show a second "A". Nothing in .kt changed. Not compiled.

## B179 - fix B178 (duplicate manifest activities) + separate "Build errors" notification
- B178 failed lint: the widget block copied from B177 dragged the rest of the manifest with it (21 DuplicateActivity). Now only the 4 widget activities are added.
- GitHubBuild: when the watched run ends in failure, fetchFailureLog() is posted as its own notification (channel "build_error", importance HIGH, id 7315, so the user can give it a sound in Android's channel settings). Tap or "Copy error" copies the full report (saved as ghLastError) via ButtonReceiver ACTION_COPY_ERROR. The normal status notification is unchanged. Uncompiled.

## B178 - merge of B176 (cells Look dialog, name outline, folder look) and B177 (widgets)
- Base = B176. Added from B177: strip/WidgetHostActivity, WidgetFloat, WidgetFloatActivity, WidgetKit (hosts other apps' widgets, e.g. Eitaa chats, floating widget window), their 4 manifest entries, "Widgets" buttons in Launcher mode (LauncherHomeActivity + LauncherModeActivity), ActionSaver.saveToCells(icon) parameter, "Widgets/Launcher mode" name (strings + cells editor button).
- Kept from B176 (B177 was older): LookDialog/LookPrefs, HtmlViewerTools, Flow.links, "Open an app" inside the pickers, Scripts row on the main screen, stripGapPct edge gap. Uncompiled.

## B176 - "Look of the cells": name outline + size, own look for folders, live view inside
- New file ui/screens/strip/LookDialog.kt replaces the old AlertDialog in StripEditorScreen. Full-screen dialog: the same StripView as the editor stays on top (true size, shrunk only to fit, tap a cell to light it, preview background Dark/Grey/White/Both saved as `stripLookPreviewBg`), settings scroll below. Tabs: Cells window | Folders.
- New settings (cells and folders): `stripLabelPct` (names under icons, 50-200, default 100), `stripOutlineColor` (0 = none, else ARGB), `stripOutlinePct` (thickness, % of text size, default 14). StripView.drawLabel draws a stroke pass then the fill; the lit cell and the thumb popup get no outline. FitText.draw got optional strokeColor/strokePct (no-icon cells).
- Folders: strip/LookPrefs.kt. Every look key has a folder twin `stripF<Name>` (stripFLook, stripFTileColor, ...). StripView(folderLook = true) reads the folder key if it exists, else the cells key, so nothing changes until the Folders tab is used. "Folders follow the cells window again" clears all stripF* look keys. OverlayController.openFolder passes folderLook = true; the editor view uses it when inside a folder (path not empty).
- Bigger names (>100%) move the icon up a little and the name down a little; long names still shrink to the cell width (+30% of the extra). Uncompiled.

## B174 - HTML viewer controls: position, line, hide time
- Settings (HtmlViewerUi.showSettings): side (right/left) for bar + buttons, buttons at top / middle / bottom (bar keeps clear of them; in the middle they sit beside the bar), switch for the faint line along the whole bar (`showTrack`), hide delay in milliseconds (`hideMs`, default 3000, min 200). Uncompiled.

## B173 - separate windows in Recent apps, HTML viewer controls, cells "Look"
- Manifest: documentLaunchMode="intoExisting" on GitHubSettings, Shell, Sides (segments), Flow (scripts), Downloads, AllApps, LauncherMode and the HTML viewer, so each is its own entry in Recent apps. Not changed: WifiShare (singleTask + share target), Cells/Appearance/Backups (inside MainActivity's Compose screens).
- HTML viewer: share/HtmlViewerUi.kt (plain views): blue quick-scroll bar on the right + three round buttons above it (screen mode cycling both bars / status only / nav only / full screen; stay awake; settings), all shown by scrolling or touching and hidden after 3 s idle; floating clock when the status bar is hidden (4 corners or dragged, saved); settings dialog (show bar / mode button / awake button / clock / corner / own Recent-apps window). Prefs file "html_viewer". The own-window option swaps two manifest entries: HtmlViewerActivity (document task, enabled by default) and HtmlViewerSameTaskActivity (disabled by default) via share/HtmlViewerSwitch.kt; Appearance "Show A HTML Viewer" switch and the "Open a file" action use it.
- StripView look (prefs stripLook 0/1/2, stripBackdropPct, stripHalo): 1 = icons only with no tiles/panel and bigger icons, 2 = icons only on a very faint dark panel (slider), halo = blurred dark outline behind icons and names. Editor: "Look of the cells" button. Uncompiled.

## B172 - fix B171 compile error
- B171 failed: maxWidth (BoxWithConstraints) was used inside a Column lambda (DSL_SCOPE_VIOLATION); it is now copied to availW before the Column.

## B171 - cells window true size, outside fields drawn as they really work
- Editor (StripEditorScreen): the cells window is no longer shrunk by the fields; it is the same size as on screen. The fields take the space left around it (thickness 22-56 dp).
- Switch off = only the fields fade (alpha 0.4); the cells window stays clear.
- Fields are drawn with the real geometry of OverlayController.outsideAt: side furthest past wins (corners cut at 45 degrees), equal parts along the window, end fields reach past the window corners. Tap hit-test uses the same rule. Only a strip of the fields can be shown (on screen they go to the screen edge).
- The −/+ per side moved from the corners to a row above the grid (EdgeCounts). Old EdgeCorner/EdgeSideFields removed. Uncompiled.

## B170 - fix B169 compile error + build notification opens the runs window
- B169 failed: actionDisplayName is @Composable and was called from a plain function/remember; edgeActionName(context, action) is now plain Kotlin.
- The build notification (id 7311, also the "A build FAILED" one) opens GitHubSettingsActivity with extra openRuns=true; GitHubSettingsDialog(openRuns) then loads and shows the workflow runs window by itself (Error report / copy there).

## B169 - base = B168-icons (B168 fields + the other account's icons-in-backup)
- Fresh install now starts from his own settings: assets/settings_default.json = his "A all settings" backup minus GitHub/auto-backup/personal run state (gh*, autoBackup*, isRunning, shellHistoryV1, ...). SettingsBackup.applyBaked applies settings AND scripts (strip + flows + sides); firstLaunch=false in it, so the tutorial walkthrough is skipped. Cells with an `img:` icon in that backup have no picture (the backup had no "icons" part): re-export with a build that has icons, then re-bake.
- Outside fields are drawn on the cells grid in the editor (EdgeFrame in StripEditorScreen): −/+ in the four corners cut each side into 1-6 equal fields at real length, tap a field = same ItemEditor as a cell (shows current action/name/icon, icon undo/redo). The old "Action outside of cells window" button/dialog is gone; the On switch is above the grid. Storage/helpers: strip/EdgeFields.kt (field meta = name+icon in `<key>Meta`). Segments keep their own dialog (SidesActivity).
- Device actions are now inside the built-in shortcuts list (BuiltInPage onPickAction, NativePicker.groups()/choose(), utils/DeviceActionIcons.kt); the separate "Device actions" buttons are removed from the cell editor, segment picker and the other-apps picker. The main Actions screen picker (ActionPicker) still has its own Device actions button.
- Click circle icon = utils/ClickCircleIcon.kt (ring + dot, like the circle drawn on screen).
- Uncompiled.

## B168 - more fields per outside side
- "Action outside of cells window": each side (Top/Left/Bottom/Right) can be cut into 1-6 equal fields, each with its own action (+/- stepper above that side's rows). 1 = old behaviour. Main: prefs `stripEdgeCnt<Side>`, field i>=1 = `stripEdge<Side>_<i>` (field 0 is the old `stripEdge<Side>`). Segments: `Seg.edgeMore` JSON (key "em"), helpers edgeCount/edgeAct/withEdgeAct/withEdgeCount.
- Fields are measured along the main cells window (left to right above/below, top to bottom beside), end fields reach past its corners. Zone = where the thumb is. Corner rule unchanged (furthest-past side wins).
- Segments that "follow main" use the main's fields; when mirrored, Left/Right swap as before and above/below fields run reversed. Own segment actions are never mirrored.
- Code: OverlayController.outsideAt / edgeCountFor / edgeActionFor; StripEditorScreen edge dialog; SidesActivity edge dialog. Uncompiled.

## B167 - everything is just "A"
- Source package is now `a.a` (was com.newagedevs.gesturevolume): folders under app/src/main/java/a/a and app/src/test/java/a/a, namespace "a.a", rootProject.name "A", themes `ATheme` / `Theme.A`.
- Shared flow files are `.afl` (marker "afl" inside, flow ids travel with the flows).
- Left on purpose: GitHubBuild.kt and SharedPref (they find the repo workflow `gesturevolume.yml`, release tag `gv`, and his zip names), assets/automate_flows.json (names of his GitHub release assets), LEGACY_CHANNEL_ID (it deletes an old notification channel), external URLs (privacy, terms, upstream source).
- Earlier in B162-B166: flow ids and rename-safe links (FlowStore: "#id" refs + aliases), flow list with multi-select (delete / duplicate / share / rename), tap-to-choose canvas forms (flow/ActionArgs.kt, flow/FlowPickers.kt), Volume boost as its own screen with stream and output scope (utils/VolumeBoost.kt, ui/screens/boost), Previous app resumes the task (utils/PreviousApp.kt).

## Accessibility service gets dropped (open)
- Report shows A's entry missing from enabled_accessibility_services at every disconnect; the list holds Undo, Automate (two services) and Universal Copy.
- Found in assets/automate_flows.json: several of his Automate flows run `settings put secure enabled_accessibility_services <whole list>` ("Toggles - Accessibility Services Enable", "Re-enable Accessibility Service", "Auto Enable Accessibility"). Any of them overwrites the list and drops A. Not proven to be the cause.
- B167 added to the report: pid on service CONNECTED / UNBOUND / DESTROYED / INTERRUPTED, a verdict on every list change ("A removed ALONE" vs "LIST REPLACED"), and at each disconnect: the raw list, `dumpsys accessibility`, install/update times and pid. Command labels are no longer cut.

## How to work with him
Ali, Persian/English, voice dictation ("ID" = "idea"). Lean replies, accuracy over speed, talk first for big things. NOT a developer: Automate-style boxes and forms, pick from lists, no formulas or code. Zero idle RAM. Never wait for a double tap. Deliver the zip only (no YML), name the build number, bracket-check changed .kt against the originals. Claude cannot compile Android: he builds on GitHub Actions (repo alichiddy/mutetest) and pastes errors.

## Still to do (his list)
Ask block; Show message "notification" target; Wait until (conditions from lists, timeout); Screen block via Shizuku; Accessibility "Interact" block; FIUSR asks which user; USSD flows.

---- Older notes below ----

# HANDOFF: native replacement for the Automate cells

Base: GestureVolume B56 (with the VolumeUp import fix and the "Resume build status" action).
This change adds an in-app action engine and built-in flows so the strip's cells no longer need Automate.
It could not be compiled where it was written: if GitHub reports `e:` lines, they point at the files below.

## New files (all in `flow/`, so merges stay easy)
- `NativeActions.kt`: every built-in action (id, label, what it needs). Ids starting with `A:` run one of A's own actions (Screenshot, Power menu, Shell runner...).
- `SeedFlows.kt`: the built-in flows (one per old Automate cell) and the table that maps old `Flow:468/233`-style cells to them. "Install my cells and flows" in the Flows screen runs it.
- `FlowHelpers.kt`: `PrivateValues` (keys/codes, stored in the separate `PrivateValues` prefs file, never in the settings backup or a cloned APK), plus two see-through helper activities (clipboard read, file pick).
- `assets/scripts/*.sh`: shell scripts copied exactly from the old Automate flows (`@PKG@`, `@MASK@`, `@TARGET_USER@` are filled in at run time).

## Changed files
- `flow/Flow.kt`: three new step types (`act`, `psh`, `bcast`).
- `flow/FlowRunner.kt`: runs them; fills `{name}` from PrivateValues; a missing-Shizuku step shows a message and opens Shizuku instead of failing.
- `flow/FlowActivity.kt`: action picker, "My values", "Install my cells and flows", "Allow usage access".
- `ui/screens/shell/ShizukuGrantRow.kt`: button label is now "Load My Automate".
- `AndroidManifest.xml`: 2 helper activities, PACKAGE_USAGE_STATS, WRITE_SECURE_SETTINGS, READ_PHONE_STATE, ACCESS_WIFI_STATE.
- `assets/grant.sh`: also grants usage access, secure settings, phone state, call phone, mock location (for the map in the next step).
- `utils/GitHubBuild.kt`, `HandlerActions.kt`, `HandlerActionCatalog.kt`, `OverlayController.kt`, `strings.xml`: "Resume build status" action (watch a build already started, no re-upload).
- `utils/HandlerActionCatalog.kt`: VolumeUp import fix.

## Rules of the engine
- NONE: works with the permissions A already has. ONCE: needs the one-time secure-settings grant (Grant button via Shizuku), else falls back to Shizuku. BETTER: opens the system panel without Shizuku. SHIZUKU: needs Shizuku every time.
- Steps can be marked "skips quietly without Shizuku" (`c = "optional"`).
- Never put real keys in source: use `{name}` and a slot in `PrivateValues.slots`.

## Not done yet
Fake-GPS map screen, Google Drive upload with sign-in, QR generator, the accessibility tap in WShr, Lens sharing step in LNS.
Five cells (2GOnly, WShr, DSave, PWR, WG Tunnel All) point at statement ids that are newer than the Automate backup this was built from: they were mapped by label. Verify them.

## B59 (on top of B58): messages, windows, wireless fixes
Touches only my files plus one line in `OverlayController.kt` (the "last result" bar in the `MyFlow:` branch).
- `FlowHelpers.kt`: `FlowPrefs` (message-bar mode: always / messages and failures [default] / only failures; button in the Flows screen) and `ResultActivity` (a window that stays until closed, with Copy).
- `FlowRunner.kt`: Message steps with `c = "window"` open the window; action results that should stay (uploads, grant/revoke, diagnostics) open it automatically (`NativeActions.staysOnScreen`).
- `NativeActions.kt`: Bluetooth tries `svc bluetooth` then `cmd bluetooth_manager` and checks the result; hotspot tries each stop/start command, checks the result and shows what the phone answered; new `wireless_diag` action; `bgshell` output is now `$ command` then the output (and `[exit N]` on failure), and `plain` copies nothing and uploads nothing.
- `SeedFlows.kt`: WifiOn and ALOF use the hotspot action. Existing installed flows are not overwritten: delete them in the Flows screen and press "Install my cells and flows" again to get the new versions.

## B60: Lens OCR ("NOW ON TAP") as one native action
- `NativeActions.kt`: new `lens_ocr`: runs `lensnet.sh prep` (stop VPNs, cut Wi-Fi/data, screenshot to /Documents/screenshot.png), opens it in Google Lens through A's FileProvider, waits until Lens/Google is left (max 3 min), then always runs `lensnet.sh on` (restores Wi-Fi and data, also when something fails).
- `AndroidManifest.xml`: FileProvider `${applicationId}.files`; new `res/xml/file_paths.xml`.
- `SeedFlows.kt`: LNS is now just `lens_ocr`. Delete the old LNS flow and press "Install my cells and flows" to get it.
- Needs "All files access" (the Grant button) so A can read the screenshot Shizuku's shell wrote.
- Not done: always-on automations (copy OTP, actions when apps open, unlock/charger/Wi-Fi triggers). They need a trigger engine; it touches `OverlayService` (start line), `GestureAccessibilityService` (app-in-front event) and the manifest (SMS receiver).

## B61: "Save to Downloads" in the share sheet
- New `share/SaveToDownloadsActivity.kt` + manifest entry: A appears in every app's share sheet as "Save to Downloads" and writes files (or shared text) into Download through MediaStore (no storage permission on Android 10+; `WRITE_EXTERNAL_STORAGE` maxSdk 28 for older phones).
- In a second profile (dual apps) with Shizuku ready it also copies the file to the main profile's Download folder (`/data/media/0/Download`). That copy is best effort and untested.

## B62 – Automations (always-on rules)
New package `app/src/main/java/com/newagedevs/gesturevolume/auto/` (Automations.kt, AutomationsScreen.kt). Rules (trigger, arg, flow) live in prefs "AutoRules". Triggers: SMS received (flow vars {otp},{message},{sender}), app opened (UsageStats poll, 2 s, screen on only), unlock, charger on/off, Wi-Fi connected, app installed. Seed flow "CopyOTP" (added from the screen's "Copy OTP from texts" button).
Existing files touched (one small edit each):
- AndroidManifest.xml: permissions ACCESS_NETWORK_STATE, RECEIVE_SMS; receiver `.auto.SmsRuleReceiver` (BROADCAST_SMS).
- service/OverlayService.kt: one line in onCreate: `Automations.start(this)`.
- flow/FlowActivity.kt: `autos` state, branch to `AutomationsScreen`, "Automations" button.
- assets/grant.sh: `pm grant … RECEIVE_SMS`.
Untested/uncompiled.

## B63 – merge of the other Claude's B59 (Automate-flow converter) + my B62
Three-way merge (base B58). Taken from the other Claude: Expr.kt, AutomateFlows.kt, assets/automate_flows.json, Flow.kt, FlowRunner.kt (goto-run, expr conditions, for-each), importedSlots in FlowHelpers.kt, NativeActions additions, "Add my Automate flows" button.
Kept from mine: FlowPrefs/ResultActivity, MESSAGE "window", Save to Downloads, Automations (auto/), Lens etc.
Only two hand-resolved spots: FlowRunner (WAIT = his expr version; MESSAGE = my FlowPrefs/window version) and FlowActivity (both buttons kept). Uncompiled.

## B245 – Keep the bar above other apps' overlays (Quick Cursor case)
Finding: Quick Cursor draws its edge bars as TYPE_ACCESSIBILITY_OVERLAY windows (flags 808, gesture-exclusion rect). Windows of the same type stack in the order they were added, so whichever app added its window later gets the touch. A's bars are the same type (when "Above the notification shade" is on and the accessibility service is bound), so a bar added after A's wins; with the foreground-service host (TYPE_APPLICATION_OVERLAY) A always loses.
Change: accessibility service lists windows (typeWindowsChanged + FLAG_RETRIEVE_INTERACTIVE_WINDOWS, set at runtime only while the new switch is on and the bar is accessibility-hosted). `checkBarCovered()` (GestureAccessibilityService) finds each bar window in the front-to-back list by its bounds; if an accessibility overlay of another package (window root package) is above it and intersects it, `OverlayController.raiseBarWindow` removes and re-adds that window. Guards: same covering ids -> no repeat; max 4 raises per 10 s, then 30 s pause; only covered windows are touched. Switch "Keep the bar above other apps' edge bars" (key handlerKeepBarOnTop, default on) under "Above the notification shade" in Visibility.
Manifest-level: accessibility_service_config.xml canRetrieveWindowContent=true, eventTypes += typeWindowsChanged; service description string updated. Copy report notes "keep on top: ..." lines.
Untested/uncompiled. If the service goes off after the update (capability changed), turn it on again.

## B250 (not compiled yet)
Goal: make the cells window open as light as Swiftly Switch. Finding: StripView's init decoded every icon file and asked the package manager for every app icon on the main thread while the finger was down. Step 1 (option): strip/IconCache.kt keeps the drawn icons for N seconds after last use (setting "Keep the icons ready (opens faster)" in the cells editor, pref stripIconKeepSec, default 300 s, 0 = off = old behaviour; dropped by itself, no idle RAM). Files: IconCache.kt (new), StripView.kt, StripEditorScreen.kt. Next ideas (each as its own option): warm the cache when the thumb touches the bar; pre-measure/pre-draw; fewer redraws while moving.
Script-blocks note: not a script feature (internal speed).
