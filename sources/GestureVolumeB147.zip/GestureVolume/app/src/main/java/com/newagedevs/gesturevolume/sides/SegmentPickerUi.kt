package com.newagedevs.gesturevolume.sides

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.newagedevs.gesturevolume.ui.screens.strip.AppList
import com.newagedevs.gesturevolume.ui.screens.strip.AppShortcutsPage
import com.newagedevs.gesturevolume.ui.screens.strip.BuiltInPage
import com.newagedevs.gesturevolume.ui.screens.strip.INTENT_ACTION_PREFIX
import com.newagedevs.gesturevolume.ui.screens.strip.MyScriptsPage
import com.newagedevs.gesturevolume.ui.screens.strip.loadCreators
import com.newagedevs.gesturevolume.utils.HandlerActions

private enum class PickPage { MENU, BUILTIN, APPS, SHORTCUTS, SCRIPTS }

/**
 * The action picker of a segment gesture. It uses the very same pages as the cell editor
 * (Built-in shortcuts with search and "A Windows Shortcuts", apps with icons, App shortcuts, My Scripts).
 */
@Composable
fun SegmentPicker(activity: SidesActivity, slot: String, onPicked: (String) -> Unit, onClose: () -> Unit) {
    var page by remember { mutableStateOf(PickPage.MENU) }
    var shell by remember { mutableStateOf(false) }
    var shellText by remember { mutableStateOf("") }
    fun done(a: String) { onClose(); onPicked(a) }
    val fileLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { activity.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            done("File:$uri")
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
            when (page) {
                PickPage.MENU -> {
                    val mainNow = SidePicker.mainNow(activity, slot)
                    val rows = ArrayList<Pair<String, () -> Unit>>()
                    // An outside-window action is its own: nothing to follow or copy from the main slider.
                    if (slot != "edge") {
                        rows += "Same as Main Slider (Live)" to { done(Seg.MAIN) }
                        rows += "Copy Main Slider's current: ${SidePicker.label(activity, mainNow)} (Stays Fixed)" to { done(mainNow) }
                    }
                    if (slot == "in") rows += "Cells window, mirrored for this side" to { done(Seg.STRIP) }
                    rows += "Open an app" to { page = PickPage.APPS }
                    rows += "Built-in Shortcuts" to { page = PickPage.BUILTIN }
                    rows += "Device Actions" to { com.newagedevs.gesturevolume.flow.NativePicker.pick(activity) { a, _ -> done(a) } }
                    rows += "App shortcuts" to { page = PickPage.SHORTCUTS }
                    rows += "Automate flow" to {
                        val cr = runCatching { loadCreators(activity) }.getOrDefault(emptyList()).firstOrNull { it.packageName == "com.llamalab.automate" }
                        if (cr == null) page = PickPage.SHORTCUTS
                        else { onClose(); SidePicker.launchCreator(activity, cr.packageName, cr.className, onPicked) }
                    }
                    rows += "Open a file" to { fileLauncher.launch(arrayOf("*/*")) }
                    rows += "Shell command" to { shell = true }
                    rows += "My Scripts" to { page = PickPage.SCRIPTS }
                    rows += "Nothing" to { done("") }
                    Column(Modifier.fillMaxSize().padding(12.dp)) {
                        Text("Choose an action", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 8.dp))
                        androidx.compose.foundation.lazy.LazyColumn(Modifier.weight(1f)) {
                            items(rows) { (name, go) ->
                                Text(name, Modifier.fillMaxWidth().clickable { go() }.padding(vertical = 14.dp, horizontal = 6.dp))
                            }
                        }
                        TextButton(onClick = onClose) { Text("Cancel") }
                    }
                    if (shell) AlertDialog(
                        onDismissRequest = { shell = false },
                        title = { Text("Shell command") },
                        text = { OutlinedTextField(value = shellText, onValueChange = { shellText = it }, label = { Text("Runs with Shizuku when allowed") }) },
                        confirmButton = { TextButton(onClick = { shell = false; if (shellText.isNotBlank()) done("Shell:" + shellText.trim()) }) { Text("Use") } },
                        dismissButton = { TextButton(onClick = { shell = false }) { Text("Cancel") } },
                    )
                }
                PickPage.BUILTIN -> BuiltInPage(onPick = { entry, _ -> done(entry.action) }, onBack = { page = PickPage.MENU })
                PickPage.APPS -> AppList(onPick = { app -> done(HandlerActions.launchApp(app.packageName)) }, onBack = { page = PickPage.MENU })
                PickPage.SHORTCUTS -> AppShortcutsPage(
                    onCreator = { cr -> onClose(); SidePicker.launchCreator(activity, cr.packageName, cr.className, onPicked) },
                    onShortcut = { sc -> done(INTENT_ACTION_PREFIX + sc.intentUri) },
                    onBack = { page = PickPage.MENU },
                )
                PickPage.SCRIPTS -> MyScriptsPage(onPick = { _, action, _ -> done(action) }, onBack = { page = PickPage.MENU })
            }
        }
    }
}
