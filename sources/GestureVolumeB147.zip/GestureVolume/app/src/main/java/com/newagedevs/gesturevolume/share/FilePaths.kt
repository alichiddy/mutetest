package com.newagedevs.gesturevolume.share

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.File

/** Small helpers for "Open a file": Android's own storage path when it can be read, the picked URI otherwise. */
object FilePaths {
    /** The real path behind a file or storage-provider URI, or null when there is none to be had. */
    fun pathOf(uri: Uri): String? {
        if (uri.scheme == "file") return uri.path
        if (uri.authority == "com.android.externalstorage.documents") {
            val id = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull() ?: return null
            val parts = id.split(":", limit = 2)
            if (parts.size != 2) return null
            return if (parts[0] == "primary") Environment.getExternalStorageDirectory().path + "/" + parts[1]
            else "/storage/" + parts[0] + "/" + parts[1]
        }
        return null
    }

    /** The file itself when this app may read it by path (storage access granted), else null: then the URI is used. */
    fun readable(uri: Uri): File? = pathOf(uri)?.let { File(it) }?.takeIf { it.isFile && it.canRead() }

    /** The file's name as the picker shows it. */
    fun displayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')

    /** A name for an action saved as "File:<uri>". */
    fun nameOf(action: String): String =
        Uri.parse(action.removePrefix("File:").substringBefore('\n').trim()).lastPathSegment
            ?.substringAfterLast('/')?.substringAfterLast(':').orEmpty().ifEmpty { "file" }
}
