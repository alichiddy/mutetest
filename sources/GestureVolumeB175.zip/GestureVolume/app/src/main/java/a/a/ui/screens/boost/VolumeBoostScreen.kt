package a.a.ui.screens.boost

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RingVolume
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import a.a.ui.viewmodels.MainViewModel
import a.a.ui.components.KitRow
import a.a.ui.motion.IconButton
import a.a.ui.screens.handler_action.segmentShape
import a.a.ui.screens.main.HomeHeading
import a.a.ui.screens.main.HomeSegments
import a.a.ui.screens.main.HomeToggleRow
import a.a.utils.VolumeBoost

private fun iconOf(stream: Int): ImageVector = when (stream) {
    VolumeBoost.S_MUSIC -> Icons.Filled.MusicNote
    VolumeBoost.S_VOICE_CALL -> Icons.Filled.Call
    VolumeBoost.S_RING -> Icons.Filled.RingVolume
    VolumeBoost.S_ALARM -> Icons.Filled.Alarm
    VolumeBoost.S_NOTIFICATION -> Icons.Filled.Notifications
    else -> Icons.Filled.TouchApp
}

private fun iconOfRoute(route: String): ImageVector = when (route) {
    VolumeBoost.ROUTE_SPEAKER -> Icons.Filled.Speaker
    VolumeBoost.ROUTE_EARPIECE -> Icons.Filled.PhoneInTalk
    VolumeBoost.ROUTE_HEADPHONES -> Icons.Filled.Headphones
    else -> Icons.Filled.Tune
}

/**
 * Volume boost, in its own window like the other options: the switch, which sounds it is for, and
 * on which output. Same rows and headings as the home screen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VolumeBoostScreen(viewModel: MainViewModel, onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val preference = viewModel.preference
    var boostOn by remember { mutableStateOf(preference.sharedPreferences.getBoolean("volumeBoostAllowed", false)) }
    var streams by remember { mutableStateOf(VolumeBoost.savedStreams(context)) } // null = everything
    var route by remember { mutableStateOf(VolumeBoost.savedRoute(context)) }

    fun save(s: Set<Int>?, r: String) {
        streams = s; route = r
        VolumeBoost.saveScope(context, s, r)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Volume boost") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, tooltip = "Back") {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { inner ->
        Column(
            Modifier.fillMaxSize().padding(inner).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            HomeSegments {
                HomeToggleRow(
                    icon = Icons.AutoMirrored.Filled.VolumeUp,
                    title = "Volume boost",
                    summary = "Swiping up at the maximum, or sliding the Quick slider on, goes past 100% up to +32 dB. Loud: it can distort and hurt ears and speakers.",
                    checked = boostOn,
                    shape = segmentShape(0, 1),
                    highlight = true,
                    onCheckedChange = {
                        boostOn = it
                        preference.sharedPreferences.edit().putBoolean("volumeBoostAllowed", it).apply()
                        if (!it) {
                            VolumeBoost.release()
                            Thread {
                                val v = VolumeBoost.verifyOff() ?: "gain set to 0 dB (Shizuku is needed to double-check)"
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    android.widget.Toast.makeText(context, "Boost off - $v", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }.start()
                        }
                    },
                )
            }

            if (boostOn) {
                Spacer(Modifier.height(12.dp))
                HomeHeading("Boost which sound", "Android boosts the whole output, so this works by switching the boost on only while the chosen sound plays.")
                val choices = VolumeBoost.STREAM_CHOICES
                HomeSegments {
                    HomeToggleRow(
                        icon = Icons.Filled.AllInclusive,
                        title = "Everything",
                        summary = "The whole sound output, whatever is playing",
                        checked = streams == null,
                        shape = segmentShape(0, choices.size + 1),
                        onCheckedChange = { if (it) save(null, route) else save(setOf(VolumeBoost.S_MUSIC), route) },
                    )
                    choices.forEachIndexed { i, (id, name, hint) ->
                        HomeToggleRow(
                            icon = iconOf(id),
                            title = name,
                            summary = hint,
                            checked = streams?.contains(id) == true,
                            shape = segmentShape(i + 1, choices.size + 1),
                            onCheckedChange = { on ->
                                val cur = streams ?: emptySet()
                                val next = if (on) cur + id else cur - id
                                // Un-ticking the last one goes back to everything, not to a boost that never fires.
                                save(next.ifEmpty { null }, route)
                            },
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                HomeHeading("On which output", "Speaker, the earpiece you hold to your ear, or headphones.")
                val routes = VolumeBoost.ROUTE_CHOICES
                HomeSegments {
                    routes.forEachIndexed { i, (id, name) ->
                        KitRow(
                            title = name,
                            shape = segmentShape(i, routes.size),
                            leading = { Icon(iconOfRoute(id), contentDescription = null) },
                            onClick = { save(streams, id) },
                            trailing = { RadioButton(selected = route == id, onClick = null) },
                        )
                    }
                }
                if (route == VolumeBoost.ROUTE_EARPIECE || streams?.contains(VolumeBoost.S_VOICE_CALL) == true) {
                    Spacer(Modifier.height(8.dp))
                    HomeSegments {
                        KitRow(
                            title = "About calls and the earpiece",
                            shape = segmentShape(0, 1),
                            description = "A normal phone call goes from the modem straight to the earpiece, past Android's mixer, so no app can boost it. " +
                                "This works for app calls (WhatsApp, Meet and similar) and anything else played into the earpiece.",
                        )
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
