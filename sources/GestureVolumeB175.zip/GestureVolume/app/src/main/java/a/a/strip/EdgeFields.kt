package a.a.strip

import android.content.SharedPreferences
import org.json.JSONObject

/**
 * The main slider's "actions outside of the cells window": each side (Top, Left, Bottom, Right) is
 * cut into 1-6 equal fields. Field 0 keeps the old key (`stripEdge<Side>`), field i is
 * `stripEdge<Side>_<i>`; the count is `stripEdgeCnt<Side>`. A field can also keep the name and icon
 * the user gave it (`<key>Meta`), which the editor shows; the running code only needs the action.
 */
object EdgeFields {
    val SIDES = listOf("Top", "Left", "Bottom", "Right")
    const val MAX = 6

    fun key(side: String, zone: Int) = if (zone <= 0) "stripEdge$side" else "stripEdge${side}_$zone"

    fun count(sp: SharedPreferences, side: String) = sp.getInt("stripEdgeCnt$side", 1).coerceIn(1, MAX)

    fun setCount(sp: SharedPreferences, side: String, n: Int) {
        sp.edit().putInt("stripEdgeCnt$side", n.coerceIn(1, MAX)).apply()
    }

    fun action(sp: SharedPreferences, side: String, zone: Int) = sp.getString(key(side, zone), "").orEmpty()

    /** The name and icon the user gave a field: (label, icon), empty when none. */
    fun meta(sp: SharedPreferences, key: String): Pair<String, String> {
        val raw = sp.getString(key + "Meta", null) ?: return "" to ""
        return runCatching { JSONObject(raw).let { it.optString("l") to it.optString("i") } }.getOrDefault("" to "")
    }

    fun save(sp: SharedPreferences, key: String, action: String, label: String, icon: String) {
        val e = sp.edit().putString(key, action)
        if (action.isEmpty() || (label.isEmpty() && icon.isEmpty())) e.remove(key + "Meta")
        else e.putString(key + "Meta", JSONObject().put("l", label).put("i", icon).toString())
        e.apply()
    }

    fun clear(sp: SharedPreferences, key: String) = save(sp, key, "", "", "")
}
