package a.a.share

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "A Wi-Fi Share" in the share sheet of any app: starts WifiShareService with the shared files and
 * shows the two QR codes (join the Wi-Fi, open the file page), the name, password and a Stop button.
 */
class WifiShareActivity : ComponentActivity() {
    private var pending: Intent? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val i = pending
        pending = null
        if (i != null) startShare(i)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ShareScreen(
                        onApply = { n, p, b -> applySettings(n, p, b) },
                        onStop = { stopShare() },
                        onOpen = { what -> openPanel(what) }
                    )
                }
            }
        }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent) {
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE) {
            if (urisOf(i).isEmpty()) {
                Toast.makeText(this, "Nothing to share (only files can be shared over Wi-Fi).", Toast.LENGTH_LONG).show()
                return
            }
            val need = ArrayList<String>()
            if (Build.VERSION.SDK_INT >= 33) {
                need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                need.add(Manifest.permission.POST_NOTIFICATIONS)
            } else need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) startShare(i) else {
                pending = i
                permLauncher.launch(missing.toTypedArray())
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun urisOf(i: Intent): List<Uri> {
        val list = ArrayList<Uri>()
        if (i.action == Intent.ACTION_SEND) {
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.add(it) }
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.addAll(it) }
        }
        return list
    }

    private fun startShare(i: Intent) {
        val uris = urisOf(i)
        if (uris.isEmpty()) return
        val s = Intent(this, WifiShareService::class.java)
        s.putParcelableArrayListExtra(WifiShareService.EXTRA_URIS, ArrayList(uris))
        val clip = ClipData.newRawUri("files", uris[0])
        for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
        s.clipData = clip
        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startForegroundService(s)
    }

    private fun applySettings(name: String, pass: String, band: Int) {
        SharePrefs.save(this, name, pass, band)
        startService(Intent(this, WifiShareService::class.java).setAction(WifiShareService.ACTION_REGROUP))
    }

    private fun stopShare() {
        startService(Intent(this, WifiShareService::class.java).setAction(WifiShareService.ACTION_STOP))
    }

    private fun openPanel(what: String) {
        val action = if (what == "wifi") {
            if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
        } else Settings.ACTION_LOCATION_SOURCE_SETTINGS
        runCatching { startActivity(Intent(action)) }
    }
}

@Composable
private fun ShareScreen(onApply: (String, String, Int) -> Unit, onStop: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val ui by WifiShareState.ui.collectAsState()
    var name by remember { mutableStateOf(SharePrefs.ssid(ctx)) }
    var pass by remember { mutableStateOf(SharePrefs.pass(ctx)) }
    var band by remember { mutableIntStateOf(SharePrefs.band(ctx)) }
    val wifiBmp = remember(ui.wifiQr) { if (ui.wifiQr.isEmpty()) null else QrImage.make(ui.wifiQr, 640) }
    val urlBmp = remember(ui.url) { if (ui.url.isEmpty()) null else QrImage.make(ui.url, 640) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Share over Wi-Fi", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(if (ui.status.isEmpty()) "Waiting for files..." else ui.status)
        if (ui.need.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Button(onClick = { onOpen(ui.need) }) {
                Text(if (ui.need == "wifi") "Open Wi-Fi panel" else "Open Location settings")
            }
        }
        if (wifiBmp != null && urlBmp != null) {
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        bitmap = wifiBmp.asImageBitmap(), contentDescription = "Join the Wi-Fi",
                        modifier = Modifier.size(160.dp).background(Color.White).padding(4.dp)
                    )
                    Text("1. Join the Wi-Fi", fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        bitmap = urlBmp.asImageBitmap(), contentDescription = "Open the files",
                        modifier = Modifier.size(160.dp).background(Color.White).padding(4.dp)
                    )
                    Text("2. Open the files", fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("Network: " + ui.ssid)
            Text("Password: " + ui.pass)
            Text("Band: " + ui.bandText)
            Text("Address: " + ui.url)
            Text("Downloads started: " + ui.served)
        }
        if (ui.files.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Files (" + ui.files.size + ")", fontWeight = FontWeight.Bold)
            for (f in ui.files) Text(f, fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Settings", fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = name, onValueChange = { name = it }, singleLine = true,
            label = { Text("Network name (starts with DIRECT-xx)") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, singleLine = true,
            label = { Text("Password (8 or more characters)") }, modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = band == 5, onClick = { band = 5 })
            Text("5 GHz")
            Spacer(Modifier.width(16.dp))
            RadioButton(selected = band == 2, onClick = { band = 2 })
            Text("2.4 GHz")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { onApply(name, pass, band) }) { Text("Apply and restart") }
            Button(onClick = onStop) { Text("Stop server") }
        }
    }
}
