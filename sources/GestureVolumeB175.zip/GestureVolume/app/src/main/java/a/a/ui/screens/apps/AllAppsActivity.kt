package a.a.ui.screens.apps

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import a.a.utils.PreviousApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One launcher icon of an installed app. */
class AppEntry(val label: String, val pkg: String, val cls: String, val system: Boolean, val icon: ImageBitmap?)

/**
 * A window with every app that shows in a launcher, user and system together (with All / User / System
 * and a search box). Hidden, frozen, disabled and suspended apps are not listed. Tap an app to open it.
 * Nothing runs until the window is open (zero idle cost).
 */
class AllAppsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    AllAppsScreen(onOpen = { e -> open(e) })
                }
            }
        }
    }

    private fun open(e: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(e.pkg, e.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val ok = runCatching { startActivity(i) }.isSuccess
        if (ok) finish() else Toast.makeText(this, "Could not open " + e.label, Toast.LENGTH_SHORT).show()
    }
}

/** What a launcher shows: every launcher entry of an enabled, not suspended app, sorted by name. Blocking. */
private fun loadVisibleApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val sizePx = (48 * context.resources.displayMetrics.density).toInt().coerceAtLeast(1)
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolved = runCatching { pm.queryIntentActivities(intent, 0) }.getOrDefault(emptyList())
    val out = ArrayList<AppEntry>()
    for (ri in resolved) {
        val ai = ri.activityInfo ?: continue
        val pkg = ai.packageName
        if (pkg == context.packageName) continue
        if (!PreviousApp.isUsableApp(context, pkg)) continue
        val system = (ai.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        val label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg)
        val icon = runCatching { ri.loadIcon(pm).toBitmap(sizePx, sizePx).asImageBitmap() }.getOrNull()
        out.add(AppEntry(label, pkg, ai.name, system, icon))
    }
    return out.sortedBy { it.label.lowercase() }
}

@Composable
private fun AllAppsScreen(onOpen: (AppEntry) -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>?>(null) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { loadVisibleApps(ctx) }
    }
    val list = apps
    val q = query.trim()
    val shown = (list ?: emptyList()).filter { e ->
        (filter == 0 || (filter == 1 && !e.system) || (filter == 2 && e.system)) &&
            (q.isEmpty() || e.label.contains(q, ignoreCase = true) || e.pkg.contains(q, ignoreCase = true))
    }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("All apps" + (if (list != null) " (" + shown.size + ")" else ""), style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search") }, modifier = Modifier.fillMaxWidth(),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, name) in listOf("All", "User", "System").withIndex()) {
                if (filter == i) Button(onClick = { filter = i }) { Text(name) }
                else OutlinedButton(onClick = { filter = i }) { Text(name) }
            }
        }
        if (list == null) {
            Text("Loading...")
        } else {
            LazyVerticalGrid(columns = GridCells.Adaptive(80.dp), modifier = Modifier.fillMaxSize()) {
                items(shown) { e ->
                    Column(
                        Modifier.fillMaxWidth().clickable { onOpen(e) }.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        val icon = e.icon
                        if (icon != null) Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(48.dp))
                        else Spacer(Modifier.size(48.dp))
                        Text(e.label, fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
