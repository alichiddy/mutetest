package a.a.ui.screens.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.utils.DiagLog
import a.a.ui.screens.strip.NumberBox

/** "Copy report": pick how far back to look and what to include, then copy. The choices are remembered. */
@Composable
fun ReportDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sp = remember { context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE) }
    var minutes by remember { mutableIntStateOf(sp.getInt("rep_min", 5)) }
    var secs by remember { mutableIntStateOf(sp.getInt("rep_sec", 0)) }
    // Bumped by the preset buttons so the number boxes show the new values.
    var boxes by remember { mutableIntStateOf(0) }
    var phone by remember { mutableStateOf(sp.getBoolean("rep_phone", false)) }
    var settings by remember { mutableStateOf(sp.getBoolean("rep_settings", false)) }
    var audio by remember { mutableStateOf(sp.getBoolean("rep_audio", false)) }
    var saved by remember { mutableStateOf(sp.getBoolean("rep_saved", true)) }
    var notes by remember { mutableStateOf(sp.getBoolean("rep_notes", true)) }
    var system by remember { mutableStateOf(sp.getBoolean("rep_system", false)) }
    var disc by remember { mutableStateOf(sp.getBoolean("rep_disc", false)) }
    var applog by remember { mutableStateOf(sp.getBoolean("rep_applog", true)) }
    var clear by remember { mutableStateOf(sp.getBoolean("rep_clear", false)) }

    @Composable
    fun Tick(text: String, v: Boolean, set: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = v, onCheckedChange = set)
            Text(text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Copy report") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("How far back (0 and 0 = everything kept)", fontSize = 13.sp)
                androidx.compose.runtime.key(boxes) {
                    NumberBox("Minutes", minutes, max = 100000) { minutes = it }
                    NumberBox("Seconds", secs, max = 100000) { secs = it }
                }
                Text("Include", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                Tick("What the app noted (gestures, cells, errors)", notes) { notes = it }
                Tick("Saved events (kept after the app was killed)", saved) { saved = it }
                Tick("The app's warnings and errors from the system log", applog) { applog = it }
                Tick("Phone model and Android version", phone) { phone = it }
                Tick("Permissions and settings state", settings) { settings = it }
                Tick("Volume streams and a test write", audio) { audio = it }
                Tick("Disconnections of the accessibility service", disc) { disc = it }
                Tick("Why the system ended the app earlier (needs Shizuku, long)", system) { system = it }
                Tick("Start empty after copying", clear) { clear = it }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OutlinedButton(onClick = {
                        minutes = 1; secs = 0; boxes++; notes = true; saved = true; applog = true; phone = false; settings = false; audio = false; disc = false; system = false
                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Just now", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        minutes = 60; secs = 0; boxes++; notes = true; saved = true; applog = true; phone = false; settings = true; audio = false; disc = true; system = true
                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Service stopped", fontSize = 12.sp) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                sp.edit().putInt("rep_min", minutes).putInt("rep_sec", secs).putBoolean("rep_phone", phone).putBoolean("rep_settings", settings)
                    .putBoolean("rep_audio", audio).putBoolean("rep_saved", saved).putBoolean("rep_notes", notes)
                    .putBoolean("rep_system", system).putBoolean("rep_disc", disc).putBoolean("rep_applog", applog)
                    .putBoolean("rep_clear", clear).apply()
                val opts = DiagLog.ReportOptions(minutes * 60 + secs, phone, settings, audio, saved, notes, system, disc, applog)
                // Shizuku and the log are read off the main thread; the copy happens when they are done.
                Thread {
                    val text = DiagLog.report(context, opts)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("A report", text))
                        if (clear) DiagLog.clear(context)
                        Toast.makeText(context, "Report copied (${text.length / 1000} KB)", Toast.LENGTH_SHORT).show()
                    }
                }.start()
                onDismiss()
            }) { Text("Copy") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
