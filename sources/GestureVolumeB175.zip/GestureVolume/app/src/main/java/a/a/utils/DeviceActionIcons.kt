package a.a.utils

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.ui.graphics.vector.ImageVector

/** An icon for a device action (Wi-Fi, flashlight, airplane...), picked by what its name says, so every row in the built-in shortcuts list has one. */
object DeviceActionIcons {
    fun forTitle(title: String): ImageVector {
        val t = title.lowercase()
        fun has(vararg w: String) = w.any { t.contains(it) }
        return when {
            has("hotspot", "tether", "router") -> Icons.Filled.Router
            has("wi-fi", "wifi", "wlan") -> Icons.Filled.Wifi
            has("bluetooth") -> Icons.Filled.Bluetooth
            has("airplane", "flight") -> Icons.Filled.AirplanemodeActive
            has("flash", "torch") -> Icons.Filled.FlashOn
            has("lock") -> Icons.Filled.Lock
            has("vpn") -> Icons.Filled.VpnKey
            has("nfc") -> Icons.Filled.Nfc
            has("location", "gps") -> Icons.Filled.LocationOn
            has("rotat") -> Icons.Filled.ScreenRotation
            has("network", "mobile", "data", "4g", "5g", "lte", "2g", "3g") -> Icons.Filled.SignalCellularAlt
            has("volume", "sound", "ring", "mute", "media") -> Icons.Filled.VolumeUp
            has("brightness", "screen", "display") -> Icons.Filled.BrightnessMedium
            has("vibrat") -> Icons.Filled.Vibration
            has("disturb", "dnd", "silent") -> Icons.Filled.DoNotDisturbOn
            has("notif") -> Icons.Filled.Notifications
            has("photo", "camera", "screenshot") -> Icons.Filled.PhotoCamera
            has("power", "reboot", "restart", "shutdown") -> Icons.Filled.PowerSettingsNew
            has("clip", "paste", "copy") -> Icons.Filled.ContentPaste
            has("shell", "command", "adb") -> Icons.Filled.Terminal
            has("web", "url", "http", "browser") -> Icons.Filled.Language
            else -> Icons.Filled.Tune
        }
    }
}
