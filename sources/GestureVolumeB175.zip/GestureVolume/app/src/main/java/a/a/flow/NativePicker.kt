package a.a.flow

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout

/**
 * Every built-in device action (flashlight, Wi-Fi, airplane, network mode, ...) as an ordinary A
 * action. Stored as "N:<id>" or "N:<id>|<argument>". One entry per thing: on / off / toggle are
 * chosen after picking it. Plain Android dialogs, so nothing costs memory while idle.
 */
object NativePicker {
    const val PREFIX = "N:"

    fun isNative(action: String) = action.startsWith(PREFIX)

    private fun idOf(action: String) = action.removePrefix(PREFIX).substringBefore('|')
    private fun argOf(action: String) = action.substringAfter('|', "")

    fun label(action: String): String {
        val d = NativeActions.find(idOf(action)) ?: return action
        val a = argOf(action)
        return d.label + if (a.isNotEmpty()) " (" + ActionArgs.label(idOf(action), a) + ")" else ""
    }

    fun isValid(action: String) = isNative(action) && NativeActions.find(idOf(action)) != null

    /** Blocking: call from a background thread. Returns the result line. */
    fun run(context: Context, action: String): String =
        NativeActions.run(context, idOf(action), argOf(action), HashMap())

    /** One device action as the pickers list it: its name, and its On / Off / Toggle modes (mode label, id), or one entry with an empty label. */
    class Group(val title: String, val options: List<Pair<String, String>>)

    fun groups(): List<Group> {
        val out = ArrayList<Group>()
        val byBase = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        for (d in NativeActions.all) {
            if (d.id.startsWith("A:")) continue
            val mode = when {
                d.id.endsWith("_toggle") && d.label.contains(": toggle") -> "Toggle"
                d.id.endsWith("_on") -> "On"
                d.id.endsWith("_off") -> "Off"
                else -> null
            }
            if (mode != null && d.label.contains(": ")) {
                val base = d.label.substringBefore(": ")
                byBase.getOrPut(base) { ArrayList() }.add(mode to d.id)
            } else out += Group(d.label, listOf("" to d.id))
        }
        for ((base, opts) in byBase) {
            val order = listOf("On", "Off", "Toggle")
            out += Group(base, opts.sortedBy { order.indexOf(it.first) })
        }
        return out.sortedBy { it.title.lowercase() }
    }

    /** Shows a searchable list; calls [onPicked] with the action string and a readable name. */
    fun pick(context: Context, onCancel: (() -> Unit)? = null, onPicked: (action: String, label: String) -> Unit) {
        val all = groups()
        val box = EditText(context).apply { hint = "Search"; setSingleLine(true) }
        val list = android.widget.ListView(context)
        var shown = all
        fun fill() {
            val q = box.text.toString().trim().lowercase()
            shown = all.filter { q.isEmpty() || it.title.lowercase().contains(q) }
            list.adapter = android.widget.ArrayAdapter(context, android.R.layout.simple_list_item_1, shown.map { it.title })
        }
        fill()
        box.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { fill() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(box)
            addView(list, LinearLayout.LayoutParams(-1, (context.resources.displayMetrics.heightPixels * 0.55).toInt()))
        }
        val dialog = AlertDialog.Builder(context).setTitle("Device actions").setView(col).setNegativeButton("Cancel") { _, _ -> onCancel?.invoke() }.setOnCancelListener { onCancel?.invoke() }.show()
        list.setOnItemClickListener { _, _, pos, _ ->
            val g = shown[pos]
            dialog.dismiss()
            choose(context, g, onPicked)
        }
    }

    /** Asks for the mode (On / Off / Toggle) and the argument a device action needs, then calls [onPicked]. */
    fun choose(context: Context, g: Group, onPicked: (action: String, label: String) -> Unit) {
        if (g.options.size == 1) withArg(context, g.options[0].second, g.title, onPicked)
        else AlertDialog.Builder(context).setTitle(g.title)
            .setItems(g.options.map { it.first }.toTypedArray()) { _, i ->
                withArg(context, g.options[i].second, g.title + ": " + g.options[i].first.lowercase(), onPicked)
            }.show()
    }

    private fun withArg(context: Context, id: String, name: String, onPicked: (String, String) -> Unit) {
        val d = NativeActions.find(id)
        // Actions with a fixed set of arguments: pick from a list, nothing to type.
        when (val spec = ActionArgs.specFor(id)) {
            is ActionArgs.Choices -> {
                val labels = spec.options.map { it.first }.toTypedArray()
                AlertDialog.Builder(context).setTitle(name).setItems(labels) { _, i ->
                    val v = spec.options[i].second
                    onPicked(PREFIX + id + "|" + v, "$name (${spec.options[i].first})")
                }.setNegativeButton("Cancel", null).show()
                return
            }
            ActionArgs.StreamPercent -> {
                AlertDialog.Builder(context).setTitle("$name: which sound?")
                    .setItems(ActionArgs.STREAMS.map { it.first }.toTypedArray()) { _, si ->
                        val st = ActionArgs.STREAMS[si]
                        AlertDialog.Builder(context).setTitle("${st.first}: how loud?")
                            .setItems(ActionArgs.PERCENTS.map { it.first }.toTypedArray()) { _, pi ->
                                val p = ActionArgs.PERCENTS[pi]
                                onPicked(PREFIX + id + "|" + st.second + ":" + p.second, "$name (${st.first} ${p.first})")
                            }.setNegativeButton("Cancel", null).show()
                    }.setNegativeButton("Cancel", null).show()
                return
            }
            null -> {}
        }
        val wantsArg = d != null && (d.label.contains("argument", true) || d.help.contains("Argument", true))
        if (!wantsArg) { onPicked(PREFIX + id, name); return }
        val input = EditText(context).apply { inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true); hint = d!!.help.ifBlank { "Argument" } }
        AlertDialog.Builder(context).setTitle(name).setView(input)
            .setPositiveButton("OK") { _, _ ->
                val a = input.text.toString().trim()
                onPicked(PREFIX + id + if (a.isNotEmpty()) "|$a" else "", if (a.isNotEmpty()) "$name ($a)" else name)
            }
            .setNegativeButton("Cancel", null).show()
    }
}
