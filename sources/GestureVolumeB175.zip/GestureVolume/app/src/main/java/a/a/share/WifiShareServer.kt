package a.a.share

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class SharedFile(val uri: Uri, val name: String, val size: Long, val mime: String)

/**
 * A tiny web server for the share window: a page listing the files (tick boxes, one-by-one,
 * zip of the selected, zip of all), each file with resume support, and zips streamed on the fly
 * (nothing is copied or stored). Lives only while the window is sharing.
 */
class WifiShareServer(
    private val resolver: ContentResolver,
    val files: CopyOnWriteArrayList<SharedFile>,
    private val onServed: () -> Unit
) {
    private var socket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    @Volatile
    private var running = false

    var port: Int = 0
        private set

    fun start(): Boolean {
        for (p in 8080..8099) {
            try {
                socket = ServerSocket(p)
                port = p
                break
            } catch (e: IOException) {
                socket = null
            }
        }
        val s = socket ?: return false
        running = true
        Thread {
            while (running) {
                val c = try { s.accept() } catch (e: IOException) { break }
                pool.execute { handle(c) }
            }
        }.start()
        return true
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        socket = null
        pool.shutdownNow()
    }

    // ------------------------------------------------------------------ requests

    private fun handle(s: Socket) {
        try {
            s.soTimeout = 30000
            val input = s.getInputStream().buffered()
            val reqLine = readLine(input) ?: return
            val headers = HashMap<String, String>()
            while (true) {
                val l = readLine(input) ?: break
                if (l.isEmpty()) break
                val i = l.indexOf(':')
                if (i > 0) headers[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
            }
            val parts = reqLine.split(' ')
            if (parts.size < 2) return
            val head = parts[0] == "HEAD"
            val target = parts[1]
            val path = target.substringBefore('?')
            val query = target.substringAfter('?', "")
            val out = BufferedOutputStream(s.getOutputStream(), 65536)
            when {
                path == "/" || path == "/index.html" -> sendPage(out, head)
                path.startsWith("/f/") -> sendFile(out, head, path, headers["range"])
                path == "/zip" -> sendZip(out, head, query)
                path == "/favicon.ico" -> header(out, "204 No Content", "Content-Length: 0")
                else -> simple(out, "404 Not Found", "Not found")
            }
            out.flush()
        } catch (e: IOException) {
            // The other device went away; nothing to do.
        } catch (e: RuntimeException) {
            // A broken request must never stop the server.
        } finally {
            runCatching { s.close() }
        }
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    private fun header(out: OutputStream, status: String, vararg h: String) {
        val sb = StringBuilder("HTTP/1.1 ").append(status).append("\r\n")
        for (x in h) sb.append(x).append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun simple(out: OutputStream, status: String, text: String) {
        val body = text.toByteArray(Charsets.UTF_8)
        header(out, status, "Content-Type: text/plain; charset=utf-8", "Content-Length: ${body.size}")
        out.write(body)
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    private fun esc(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;").replace("\"", "&quot;")

    private fun disposition(name: String): String {
        val ascii = name.map { if (it in ' '..'~' && it != '"' && it != '\\') it else '_' }.joinToString("")
        return "Content-Disposition: attachment; filename=\"$ascii\"; filename*=UTF-8''${enc(name)}"
    }

    // ------------------------------------------------------------------ the page

    private fun sendPage(out: OutputStream, head: Boolean) {
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html><head><meta charset='utf-8'>")
        sb.append("<meta name='viewport' content='width=device-width,initial-scale=1'><title>A Wi-Fi Share</title><style>")
        sb.append("body{font-family:sans-serif;margin:0;padding:14px;background:#f4f5f7;color:#1b1b1b}")
        sb.append("h2{margin:4px 0 12px}.bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}")
        sb.append("button,a.btn{background:#2d6cdf;color:#fff;border:0;border-radius:8px;padding:10px 14px;font-size:15px;text-decoration:none;cursor:pointer}")
        sb.append("button.g{background:#6b7280}")
        sb.append(".row{display:flex;align-items:center;gap:10px;background:#fff;border-radius:10px;padding:10px 12px;margin-bottom:8px}")
        sb.append(".n{flex:1;word-break:break-all}.s{color:#6b7280;font-size:13px;white-space:nowrap}")
        sb.append("a.dl{color:#2d6cdf;text-decoration:none;font-weight:bold}input.c{width:20px;height:20px}")
        sb.append("@media (prefers-color-scheme:dark){body{background:#15171a;color:#eee}.row{background:#22262b}}")
        sb.append("</style></head><body><h2>Files (").append(files.size).append(")</h2><div class='bar'>")
        sb.append("<button class='g' onclick='setAll(true)'>Select all</button>")
        sb.append("<button class='g' onclick='setAll(false)'>Select none</button>")
        sb.append("<button onclick='zipSel()'>Download selected (zip)</button>")
        sb.append("<button onclick='oneByOne()'>Download selected one by one</button>")
        sb.append("<a class='btn' href='/zip'>Download all (zip)</a></div>")
        for ((i, f) in files.withIndex()) {
            val u = "/f/$i/" + enc(f.name)
            sb.append("<div class='row'><input class='c' type='checkbox' value='").append(i)
            sb.append("' data-u='").append(u).append("'><span class='n'>").append(esc(f.name))
            sb.append("</span><span class='s'>").append(sizeText(f.size))
            sb.append("</span><a class='dl' href='").append(u).append("'>Download</a></div>")
        }
        sb.append("<script>")
        sb.append("function cs(){return Array.prototype.slice.call(document.querySelectorAll('input.c'));}")
        sb.append("function sel(){return cs().filter(function(c){return c.checked;});}")
        sb.append("function setAll(v){cs().forEach(function(c){c.checked=v;});}")
        sb.append("function zipSel(){var r=sel();if(!r.length){alert('Tick the files first');return;}")
        sb.append("location.href='/zip?i='+r.map(function(c){return c.value;}).join('&i=');}")
        sb.append("function oneByOne(){var r=sel();if(!r.length){alert('Tick the files first');return;}")
        sb.append("r.forEach(function(c,k){setTimeout(function(){var a=document.createElement('a');")
        sb.append("a.href=c.getAttribute('data-u');a.download='';document.body.appendChild(a);a.click();")
        sb.append("document.body.removeChild(a);},k*700);});}")
        sb.append("</script></body></html>")
        val body = sb.toString().toByteArray(Charsets.UTF_8)
        header(out, "200 OK", "Content-Type: text/html; charset=utf-8", "Content-Length: ${body.size}", "Cache-Control: no-store")
        if (!head) out.write(body)
    }

    // ------------------------------------------------------------------ one file, with resume

    private fun sendFile(out: OutputStream, head: Boolean, path: String, range: String?) {
        val idx = path.split('/').getOrNull(2)?.toIntOrNull()
        val f = if (idx != null) files.getOrNull(idx) else null
        if (f == null) { simple(out, "404 Not Found", "No such file"); return }
        var start = 0L
        var end = f.size - 1
        var partial = false
        if (range != null && f.size > 0 && range.startsWith("bytes=")) {
            val spec = range.substring(6).substringBefore(',').trim()
            val a = spec.substringBefore('-')
            val b = spec.substringAfter('-', "")
            if (a.isEmpty()) {
                val n = b.toLongOrNull() ?: -1L
                if (n > 0) { start = maxOf(0L, f.size - n); partial = true }
            } else {
                val s = a.toLongOrNull()
                if (s != null) {
                    start = s
                    val e = b.toLongOrNull()
                    if (e != null && e < end) end = e
                    partial = true
                }
            }
            if (partial && (start > end || start >= f.size)) {
                header(out, "416 Range Not Satisfiable", "Content-Range: bytes */${f.size}", "Content-Length: 0")
                return
            }
        }
        val ins = resolver.openInputStream(f.uri)
        if (ins == null) { simple(out, "500 Internal Server Error", "Cannot open the file"); return }
        ins.use { stream ->
            val hs = ArrayList<String>()
            hs.add("Content-Type: ${f.mime}")
            hs.add(disposition(f.name))
            if (f.size >= 0) {
                hs.add("Accept-Ranges: bytes")
                hs.add("Content-Length: ${end - start + 1}")
                if (partial) hs.add("Content-Range: bytes $start-$end/${f.size}")
            }
            header(out, if (partial) "206 Partial Content" else "200 OK", *hs.toTypedArray())
            if (head) return
            if (start == 0L) onServed()
            skipFully(stream, start)
            copy(stream, out, if (f.size >= 0) end - start + 1 else -1L)
        }
    }

    // ------------------------------------------------------------------ zip of all or of the selected

    private fun sendZip(out: OutputStream, head: Boolean, query: String) {
        val picked = ArrayList<SharedFile>()
        val wanted = query.split('&').filter { it.startsWith("i=") }
            .mapNotNull { URLDecoder.decode(it.substring(2), "UTF-8").toIntOrNull() }
        if (wanted.isEmpty()) picked.addAll(files) else for (i in wanted) files.getOrNull(i)?.let { picked.add(it) }
        if (picked.isEmpty()) { simple(out, "404 Not Found", "Nothing selected"); return }
        header(out, "200 OK", "Content-Type: application/zip", disposition("A-share.zip"))
        if (head) return
        onServed()
        val zos = ZipOutputStream(out)
        zos.setLevel(1)
        val used = HashSet<String>()
        for (f in picked) {
            var n = f.name
            var k = 1
            while (!used.add(n)) {
                val dot = f.name.lastIndexOf('.')
                n = if (dot > 0) f.name.substring(0, dot) + " (" + k + ")" + f.name.substring(dot) else f.name + " (" + k + ")"
                k++
            }
            val ins = resolver.openInputStream(f.uri) ?: continue
            ins.use { stream ->
                zos.putNextEntry(ZipEntry(n))
                copy(stream, zos, -1L)
                zos.closeEntry()
            }
        }
        zos.finish()
        zos.flush()
    }

    private fun skipFully(i: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = i.skip(left)
            if (k <= 0) {
                if (i.read() < 0) return
                left -= 1
            } else left -= k
        }
    }

    private fun copy(i: InputStream, o: OutputStream, limit: Long) {
        val buf = ByteArray(65536)
        var left = limit
        while (left != 0L) {
            val want = if (left < 0 || left > buf.size) buf.size else left.toInt()
            val n = i.read(buf, 0, want)
            if (n < 0) break
            o.write(buf, 0, n)
            if (left > 0) left -= n
        }
    }
}
