package a.a.utils

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioPlaybackConfiguration
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * Louder than the system's maximum: a loudness effect on the global audio output, stepped
 * off, +8, +16, +24, +32 dB-hundredths (800 to 3200 millibels) with each trigger and back to off.
 *
 * The effect is a few kilobytes and lives only while a boost is on; at "off" it is released and
 * nothing is kept. It is attached to the global output mix (session 0), which not every phone
 * allows — when it is refused the action says so instead of pretending.
 *
 * A boost can distort and, at the top levels, hurt hearing and speakers: the steps are deliberately
 * small, and the last one is the limit.
 *
 * **Scope.** Android attaches this kind of effect to the whole output mix, never to one stream, so
 * "boost only media" cannot be done by pointing the effect at a stream. It is done by *gating*: the
 * gain the user asked for ([mb]) is kept, but the effect is only attached while the streams chosen
 * in the settings are the ones playing (and the sound is on the chosen output: speaker, the
 * built-in earpiece, or headphones). A call, ringtone or alarm that is not in the chosen set takes
 * the effect off for as long as it lasts; it comes back by itself afterwards.
 *
 * Limit worth knowing: a normal phone call is carried by the modem and never passes through the
 * Android mixer, so no software boost can reach it. The earpiece boost works for what *does* pass
 * through the mixer: calls made through apps (WhatsApp, Telegram, Meet...) and anything else that
 * plays into the earpiece.
 */
object VolumeBoost {
    private val LEVELS_MB = intArrayOf(0, 800, 1600, 2400, 3200)
    private var level = 0
    private var effect: LoudnessEnhancer? = null

    const val MAX_MB = 3200

    // ---- scope: which streams and which output the boost is for -------------------------------

    /** Preference keys, in the app's own preference file. */
    const val PREFS_FILE = "MyPrefs"
    /** "all" (the whole mix, as before) or a comma list of the stream numbers below. */
    const val PREF_STREAMS = "volumeBoostStreams"
    /** One of [ROUTE_ANY], [ROUTE_SPEAKER], [ROUTE_EARPIECE], [ROUTE_HEADPHONES]. */
    const val PREF_ROUTE = "volumeBoostRoute"

    const val ROUTE_ANY = "any"
    const val ROUTE_SPEAKER = "speaker"
    const val ROUTE_EARPIECE = "earpiece"
    const val ROUTE_HEADPHONES = "headphones"

    // Framework stream numbers (stable since API 1).
    const val S_VOICE_CALL = 0
    const val S_SYSTEM = 1
    const val S_RING = 2
    const val S_MUSIC = 3
    const val S_ALARM = 4
    const val S_NOTIFICATION = 5

    /** What the settings list: stream number, name, and a hint. */
    val STREAM_CHOICES: List<Triple<Int, String, String>> = listOf(
        Triple(S_MUSIC, "Media", "Music, video, podcasts, games"),
        Triple(S_VOICE_CALL, "Calls", "App calls (WhatsApp, Meet...) and the earpiece; a normal phone call cannot be boosted"),
        Triple(S_RING, "Ringtone", "Incoming call ring"),
        Triple(S_ALARM, "Alarm", "Alarms and timers"),
        Triple(S_NOTIFICATION, "Notifications", "Notification sounds"),
        Triple(S_SYSTEM, "System sounds", "Touch and keyboard sounds"),
    )

    val ROUTE_CHOICES: List<Pair<String, String>> = listOf(
        ROUTE_ANY to "Any output",
        ROUTE_SPEAKER to "Speaker",
        ROUTE_EARPIECE to "Earpiece (built-in earphone)",
        ROUTE_HEADPHONES to "Headphones (wired or Bluetooth)",
    )

    /** Streams whose sound should never ride on a boost meant for others: they hold the gate shut. */
    private val LOUD_STREAMS = setOf(S_VOICE_CALL, S_RING, S_ALARM)

    @Volatile private var scopeAll = true
    @Volatile private var scopeStreams: Set<Int> = setOf(S_MUSIC)
    @Volatile private var scopeRoute = ROUTE_ANY
    private var appCtx: Context? = null
    private val main = Handler(Looper.getMainLooper())

    /** True when the boost is for the whole mix (no gating at all): the original behaviour. */
    val isEverything: Boolean get() = scopeAll && scopeRoute == ROUTE_ANY

    /** Whether a swipe or slider that is driving [stream] may go on into the boost. */
    fun streamAllowed(stream: Int): Boolean = if (scopeAll) stream == S_MUSIC else stream in scopeStreams

    /**
     * Reads the scope from the preferences and re-applies the boost to it. Call once at start-up
     * and after the settings change.
     */
    @Synchronized
    fun configure(context: Context) {
        val ctx = context.applicationContext ?: context
        appCtx = ctx
        val p = ctx.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        val raw = p.getString(PREF_STREAMS, "all") ?: "all"
        if (raw == "all" || raw.isBlank()) {
            scopeAll = true
            scopeStreams = setOf(S_MUSIC)
        } else {
            scopeAll = false
            scopeStreams = raw.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet().ifEmpty { setOf(S_MUSIC) }
        }
        scopeRoute = p.getString(PREF_ROUTE, ROUTE_ANY)?.takeIf { r -> ROUTE_CHOICES.any { it.first == r } } ?: ROUTE_ANY
        reapply()
    }

    /** Saves a new scope ([streams] null = everything) and applies it. */
    fun saveScope(context: Context, streams: Set<Int>?, route: String) {
        context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit()
            .putString(PREF_STREAMS, if (streams == null) "all" else streams.sorted().joinToString(","))
            .putString(PREF_ROUTE, route)
            .apply()
        configure(context)
    }

    /** The saved scope as the settings show it: null streams = everything. */
    fun savedStreams(context: Context): Set<Int>? {
        val raw = context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
            .getString(PREF_STREAMS, "all") ?: "all"
        if (raw == "all" || raw.isBlank()) return null
        return raw.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet().ifEmpty { null }
    }

    fun savedRoute(context: Context): String =
        context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
            .getString(PREF_ROUTE, ROUTE_ANY)?.takeIf { r -> ROUTE_CHOICES.any { it.first == r } } ?: ROUTE_ANY

    // ---- the gain -------------------------------------------------------------------------------

    /** The gain the user asked for, in millibels (0 = off), whether or not the gate lets it through now. */
    @get:Synchronized
    val mb: Int get() = wantedMb

    /** True while a boost is asked for but held off because the wrong stream or output is playing. */
    @get:Synchronized
    val held: Boolean get() = wantedMb > 0 && effect == null

    private var wantedMb = 0
    private var currentMb = 0

    /**
     * Sets the gain exactly (the sliders use this), 0 turning the boost off. False when the phone
     * refuses the effect.
     */
    @Synchronized
    fun setMb(target: Int): Boolean {
        val mb = target.coerceIn(0, MAX_MB)
        wantedMb = mb
        if (mb == 0) { release(); return true }
        return reapply()
    }

    /** Moves to the next level and returns what to tell the user. */
    @Synchronized
    fun step(): String {
        level = (level + 1) % LEVELS_MB.size
        if (level == 0) {
            release()
            return "Volume boost off"
        }
        wantedMb = LEVELS_MB[level]
        if (!reapply()) {
            level = 0
            return "Volume boost is not supported on this phone"
        }
        return if (held) "Volume boost +${LEVELS_MB[level] / 100} dB (waits for ${scopeText()})"
        else "Volume boost +${LEVELS_MB[level] / 100} dB"
    }

    /**
     * Puts the effect in line with what is wanted and what is playing: attached when the gate is
     * open, taken off (the wanted gain kept) when it is not. False only when the phone refuses.
     */
    @Synchronized
    private fun reapply(): Boolean {
        if (wantedMb <= 0) { dropEffect(); stopWatching(); return true }
        if (!isEverything) startWatching()
        if (!gateOpen()) { dropEffect(); return true }
        return try {
            val e = effect ?: LoudnessEnhancer(0).also { effect = it }
            e.setTargetGain(wantedMb)
            e.enabled = true
            currentMb = wantedMb
            true
        } catch (t: Throwable) {
            DiagLog.note("volume boost failed: $t")
            release()
            false
        }
    }

    private fun dropEffect() {
        runCatching { effect?.setTargetGain(0) }
        runCatching { effect?.enabled = false }
        runCatching { effect?.release() }
        effect = null
        currentMb = 0
    }

    private fun scopeText(): String {
        val s = if (scopeAll) "everything" else STREAM_CHOICES.filter { it.first in scopeStreams }.joinToString(" + ") { it.second }
        val r = ROUTE_CHOICES.firstOrNull { it.first == scopeRoute }?.second ?: ""
        return if (scopeRoute == ROUTE_ANY) s else "$s on $r"
    }

    // ---- the gate -------------------------------------------------------------------------------

    private fun gateOpen(): Boolean {
        if (isEverything) return true
        val ctx = appCtx ?: return true // not configured yet: behave as before
        val am = runCatching { ctx.getSystemService(AudioManager::class.java) }.getOrNull() ?: return true
        val active = activeStreams(am)
        if (!scopeAll) {
            if (active.none { it in scopeStreams }) return false
            // A call, ring or alarm that is not in the chosen set shuts the gate for its duration.
            if (active.any { it in LOUD_STREAMS && it !in scopeStreams }) return false
        }
        if (scopeRoute != ROUTE_ANY && currentRoute(am) != scopeRoute) return false
        return true
    }

    private fun activeStreams(am: AudioManager): Set<Int> {
        val out = HashSet<Int>()
        val mode = runCatching { am.mode }.getOrDefault(AudioManager.MODE_NORMAL)
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) out += S_VOICE_CALL
        if (mode == AudioManager.MODE_RINGTONE) out += S_RING
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching { am.activePlaybackConfigurations }.getOrNull()?.forEach { c: AudioPlaybackConfiguration ->
                val st = runCatching { c.audioAttributes.volumeControlStream }.getOrNull() ?: return@forEach
                out += if (st < 0) S_MUSIC else st
            }
        }
        if (runCatching { am.isMusicActive }.getOrDefault(false)) out += S_MUSIC
        return out
    }

    /** Where the sound is going now: one of the ROUTE_* values (never ROUTE_ANY). */
    private fun currentRoute(am: AudioManager): String {
        val mode = runCatching { am.mode }.getOrDefault(AudioManager.MODE_NORMAL)
        val inCall = mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION
        if (inCall) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val t = runCatching { am.communicationDevice?.type }.getOrNull()
                if (t != null) return routeOfType(t)
            }
            @Suppress("DEPRECATION")
            if (runCatching { am.isSpeakerphoneOn }.getOrDefault(false)) return ROUTE_SPEAKER
            @Suppress("DEPRECATION")
            if (runCatching { am.isBluetoothScoOn }.getOrDefault(false)) return ROUTE_HEADPHONES
            return if (hasHeadphones(am)) ROUTE_HEADPHONES else ROUTE_EARPIECE
        }
        // Media: headphones win whenever they are connected, otherwise the speaker.
        return if (hasHeadphones(am)) ROUTE_HEADPHONES else ROUTE_SPEAKER
    }

    private fun routeOfType(type: Int): String = when (type) {
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> ROUTE_EARPIECE
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER, AudioDeviceInfo.TYPE_BUILTIN_SPEAKER_SAFE -> ROUTE_SPEAKER
        else -> ROUTE_HEADPHONES
    }

    private fun hasHeadphones(am: AudioManager): Boolean =
        runCatching { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS) }.getOrNull()?.any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_HEARING_AID ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        } ?: false

    // ---- watching what plays, only while a gated boost is wanted --------------------------------

    private var watching = false
    private val playbackCb = object : AudioManager.AudioPlaybackCallback() {
        override fun onPlaybackConfigChanged(configs: MutableList<AudioPlaybackConfiguration>?) = kick()
    }
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = kick()
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = kick()
    }
    private var modeCb: Any? = null

    private fun kick() { main.post { synchronized(this) { if (wantedMb > 0) reapply() } } }

    private fun startWatching() {
        if (watching) return
        val am = appCtx?.getSystemService(AudioManager::class.java) ?: return
        watching = true
        runCatching { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) am.registerAudioPlaybackCallback(playbackCb, main) }
        runCatching { am.registerAudioDeviceCallback(deviceCb, main) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                val l = AudioManager.OnModeChangedListener { _ -> kick() }
                am.addOnModeChangedListener({ r -> main.post(r) }, l)
                modeCb = l
            }
            runCatching {
                val l = AudioManager.OnCommunicationDeviceChangedListener { _ -> kick() }
                am.addOnCommunicationDeviceChangedListener({ r -> main.post(r) }, l)
                commCb = l
            }
        }
    }
    private var commCb: Any? = null

    private fun stopWatching() {
        if (!watching) return
        watching = false
        val am = appCtx?.getSystemService(AudioManager::class.java) ?: return
        runCatching { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) am.unregisterAudioPlaybackCallback(playbackCb) }
        runCatching { am.unregisterAudioDeviceCallback(deviceCb) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching { (modeCb as? AudioManager.OnModeChangedListener)?.let { am.removeOnModeChangedListener(it) } }
            runCatching { (commCb as? AudioManager.OnCommunicationDeviceChangedListener)?.let { am.removeOnCommunicationDeviceChangedListener(it) } }
        }
        modeCb = null; commCb = null
    }

    /** What A holds right now, for the report. */
    @Synchronized
    fun status(): String {
        val e = effect ?: return if (wantedMb > 0) "A is holding the boost off for now (wants +${wantedMb / 100} dB; waits for ${scopeText()})" else "A holds no boost effect (gain 0 dB)"
        return "A holds an effect: gain ${currentMb / 100} dB, enabled=${runCatching { e.enabled }.getOrNull()}, control=${runCatching { e.hasControl() }.getOrNull()}"
    }

    /**
     * Asks the audio system itself (needs Shizuku) whether any loudness effect is still active.
     * Blocking: call from a background thread. Null when it cannot be checked.
     */
    fun verifyOff(): String? {
        if (!ShizukuShell.isReady()) return null
        var found = 0
        val code = ShizukuShell.run("dumpsys media.audio_flinger") { line ->
            if (line.contains("loudness", true) || line.contains("fa415329-2034-4bea-b5dc-5b381c8d1e2c")) found++
        }
        if (code != 0) return null
        return if (found == 0) "checked with the system: no loudness effect is active"
        else "the system still lists a loudness effect ($found lines) - it is not held by A; restart the phone's audio (stop/start the player) or reboot"
    }

    @Synchronized
    fun release() {
        // Gain first: even if the phone leaves the effect object alive, it adds nothing.
        dropEffect()
        stopWatching()
        level = 0
        wantedMb = 0
    }
}
