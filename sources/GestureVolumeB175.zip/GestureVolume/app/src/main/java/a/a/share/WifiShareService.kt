package a.a.share

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import kotlinx.coroutines.flow.update
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Runs the share: switches Location and Wi-Fi on when needed, starts the web server and a Wi-Fi Direct
 * group with the saved name and password, and puts everything back when the server is stopped.
 * Exists only while sharing (zero idle cost).
 */
class WifiShareService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var server: WifiShareServer? = null
    private var p2p: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private val shared = CopyOnWriteArrayList<SharedFile>()
    private var changedLocation = false
    private var changedWifi = false
    private var bandNote = ""
    private var served = 0

    @Volatile
    private var active = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_REGROUP -> {
                if (active) {
                    upd { it.copy(status = "Restarting Wi-Fi Direct...", wifiQr = "", url = "") }
                    startGroup()
                } else stopSelf()
                return START_NOT_STICKY
            }
        }
        goForeground()
        addFiles(readUris(intent))
        if (!active) {
            active = true
            Thread { boot() }.start()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun upd(f: (ShareUi) -> ShareUi) {
        WifiShareState.ui.update(f)
    }

    // ------------------------------------------------------------------ foreground notification

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Wi-Fi share", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WifiShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, WifiShareActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop server", stop
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Sharing files over Wi-Fi")
            .setContentText("Tap to open the QR codes")
            .setContentIntent(open)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else startForeground(NOTE_ID, n)
    }

    // ------------------------------------------------------------------ files

    @Suppress("DEPRECATION")
    private fun readUris(i: Intent?): List<Uri> {
        if (i == null) return emptyList()
        return i.getParcelableArrayListExtra<Uri>(EXTRA_URIS) ?: emptyList()
    }

    private fun addFiles(uris: List<Uri>) {
        for (u in uris) {
            var name: String? = null
            var size = -1L
            runCatching {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
            }
            if (u.scheme == "file" && u.path != null) {
                val f = File(u.path!!)
                if (name == null) name = f.name
                if (size < 0) size = f.length()
            }
            val shown = name ?: u.lastPathSegment ?: "file"
            val mime = contentResolver.getType(u) ?: "application/octet-stream"
            shared.add(SharedFile(u, shown.substringAfterLast('/'), size, mime))
        }
        upd { it.copy(files = shared.map { f -> f.name + "  " + sizeText(f.size) }) }
    }

    // ------------------------------------------------------------------ start

    private fun boot() {
        upd { ShareUi(running = true, status = "Preparing Location and Wi-Fi...", files = it.files) }
        ShareToggles.ensureGrant(this)
        val loc = ShareToggles.locationOn(this)
        if (loc == 1) changedLocation = true
        val wf = ShareToggles.wifiOn(this)
        if (wf == 1) changedWifi = true
        if (loc < 0) upd { it.copy(status = "Turn Location on (Wi-Fi Direct needs it).", need = "location") }
        if (wf < 0) upd { it.copy(status = "Turn Wi-Fi on.", need = "wifi") }
        val wifiOk = ShareToggles.waitFor(20000) { ShareToggles.isWifiOn(this) }
        val locOk = ShareToggles.waitFor(20000) { ShareToggles.isLocationOn(this) }
        upd { it.copy(need = "") }
        if (!active) return
        if (!wifiOk || !locOk) {
            upd { it.copy(status = "Wi-Fi or Location is still off. Turn it on, then press Apply and restart.") }
            startServer()
            return
        }
        startServer()
        startGroup()
    }

    private fun startServer() {
        if (server != null) return
        val s = WifiShareServer(contentResolver, shared) {
            served++
            upd { it.copy(served = served) }
        }
        if (s.start()) server = s else upd { it.copy(status = "The web server could not start (no free port).") }
    }

    private fun startGroup() {
        main.post { doGroup(0) }
    }

    @SuppressLint("MissingPermission")
    private fun doGroup(attempt: Int) {
        if (!active) return
        var m = p2p
        if (m == null) {
            m = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
            p2p = m
        }
        if (m == null) { fail("This phone has no Wi-Fi Direct."); return }
        var ch = channel
        if (ch == null) {
            ch = m.initialize(this, Looper.getMainLooper(), null)
            channel = ch
        }
        if (ch == null) { fail("Wi-Fi Direct could not be opened."); return }
        val pass = SharePrefs.pass(this)
        if (Build.VERSION.SDK_INT >= 29 && attempt < 2 && (pass.length < 8 || pass.length > 63)) {
            fail("The password needs 8 to 63 characters.")
            return
        }
        val band = SharePrefs.band(this)
        val cfg = buildConfig(attempt, band, pass)
        bandNote = when {
            cfg == null -> "chosen by the phone"
            attempt == 0 -> if (band == 5) "5 GHz" else "2.4 GHz"
            else -> if (band == 5) "2.4 GHz (5 GHz was refused)" else "5 GHz (2.4 GHz was refused)"
        }
        val mm = m
        val cc = ch
        upd { it.copy(status = "Starting Wi-Fi Direct...") }
        mm.removeGroup(cc, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { create(mm, cc, cfg, attempt) }
            override fun onFailure(reason: Int) { create(mm, cc, cfg, attempt) }
        })
    }

    @SuppressLint("NewApi")
    private fun buildConfig(attempt: Int, band: Int, pass: String): WifiP2pConfig? {
        if (Build.VERSION.SDK_INT < 29 || attempt >= 2) return null
        val use = if (attempt == 0) band else (if (band == 5) 2 else 5)
        return runCatching {
            WifiP2pConfig.Builder()
                .setNetworkName(SharePrefs.fixSsid(SharePrefs.ssid(this)))
                .setPassphrase(pass)
                .enablePersistentMode(false)
                .setGroupOperatingBand(if (use == 5) WifiP2pConfig.GROUP_OWNER_BAND_5GHZ else WifiP2pConfig.GROUP_OWNER_BAND_2GHZ)
                .build()
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    private fun create(m: WifiP2pManager, ch: WifiP2pManager.Channel, cfg: WifiP2pConfig?, attempt: Int) {
        if (!active) return
        val listener = object : WifiP2pManager.ActionListener {
            override fun onSuccess() { main.postDelayed({ readGroup(m, ch, 0) }, 700) }
            override fun onFailure(reason: Int) {
                if (attempt < 2 && Build.VERSION.SDK_INT >= 29) doGroup(attempt + 1)
                else fail("Wi-Fi Direct could not start (code $reason). Check that Wi-Fi and Location are on.")
            }
        }
        if (cfg != null) m.createGroup(ch, cfg, listener) else m.createGroup(ch, listener)
    }

    @SuppressLint("MissingPermission")
    private fun readGroup(m: WifiP2pManager, ch: WifiP2pManager.Channel, tries: Int) {
        if (!active) return
        m.requestGroupInfo(ch) { g ->
            val name = g?.networkName
            if (g == null || name.isNullOrEmpty()) {
                if (tries < 8) main.postDelayed({ readGroup(m, ch, tries + 1) }, 700)
                else fail("Wi-Fi Direct started but its details could not be read.")
            } else {
                onGroup(name, g.passphrase ?: "")
            }
        }
    }

    private fun onGroup(ssid: String, pass: String) {
        val port = server?.port ?: 0
        val url = "http://" + p2pIp() + ":" + port + "/"
        val qr = "WIFI:T:WPA;S:" + wifiEsc(ssid) + ";P:" + wifiEsc(pass) + ";;"
        upd {
            it.copy(
                running = true, status = "Sharing. Scan code 1 to join, then code 2 to open the files.",
                ssid = ssid, pass = pass, bandText = bandNote, url = url, wifiQr = qr
            )
        }
    }

    private fun fail(msg: String) {
        upd { it.copy(status = msg) }
    }

    private fun wifiEsc(s: String): String =
        s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")

    /** The phone's own address inside its Wi-Fi Direct group (192.168.49.1 on almost every phone). */
    private fun p2pIp(): String {
        runCatching {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.name.startsWith("p2p")) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress ?: "192.168.49.1"
                }
            }
        }
        return "192.168.49.1"
    }

    // ------------------------------------------------------------------ stop

    private fun shutdown() {
        val wasActive = active
        active = false
        server?.stop()
        server = null
        val m = p2p
        val ch = channel
        p2p = null
        channel = null
        if (m != null && ch != null) {
            val done = object : WifiP2pManager.ActionListener {
                override fun onSuccess() { closeChannel(ch) }
                override fun onFailure(reason: Int) { closeChannel(ch) }
            }
            runCatching { m.removeGroup(ch, done) }.onFailure { closeChannel(ch) }
        }
        WifiShareState.ui.value = ShareUi(status = "Stopped.")
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        val loc = changedLocation
        val wf = changedWifi
        changedLocation = false
        changedWifi = false
        shared.clear()
        val ctx = applicationContext
        Thread {
            if (wasActive) {
                try { Thread.sleep(1200) } catch (e: InterruptedException) { }
                if (loc) ShareToggles.locationOff(ctx)
                if (wf) ShareToggles.wifiOff(ctx)
            }
            main.post { stopSelf() }
        }.start()
    }

    private fun closeChannel(ch: WifiP2pManager.Channel) {
        if (Build.VERSION.SDK_INT >= 27) runCatching { ch.close() }
    }

    companion object {
        const val ACTION_STOP = "a.a.share.STOP"
        const val ACTION_REGROUP = "a.a.share.REGROUP"
        const val EXTRA_URIS = "a.a.share.URIS"
        private const val CHANNEL = "wifishare"
        private const val NOTE_ID = 7731
    }
}
