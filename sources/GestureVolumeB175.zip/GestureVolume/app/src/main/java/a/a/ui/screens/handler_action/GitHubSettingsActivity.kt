package a.a.ui.screens.handler_action

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import a.a.data.local.SharedPref

/** The GitHub build settings window on its own, so a strip cell or a Deck shortcut can open it. */
class GitHubSettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pref = SharedPref(this)
        setContent {
            MaterialTheme {
                GitHubSettingsDialog(pref, openRuns = intent.getBooleanExtra("openRuns", false)) { finish() }
            }
        }
    }
}
