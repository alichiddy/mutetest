package a.a.flow

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import a.a.strip.WhenRules
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * The "When" block of a script: the same events as the "When..." list of the main bar (strip/WhenRules.kt).
 * The main bar and the side segments call [fire] when an event happens (WhenRules goes through OverlayController.runWhen);
 * [src] says which one it was, and a block listens to the main bar, the side bars, one segment or all of them.
 *  - A block that WAITS: the script stops at it ([await]) until [fire] is called for its event.
 *  - A block that STARTS: the script runs by itself from that block. Which scripts have such a block is read
 *    from the saved scripts only when they changed since the last event, so nothing runs or waits while idle.
 * "Only if" blocks use WhenRules.holdsNow, the same check as the rows of the list.
 */
object WhenEvents {
    const val MODE_START = "start"
    const val MODE_WAIT = "wait"
    const val MODE_BOTH = "both"

    val MODES = listOf(
        "Start the script" to MODE_START,
        "Wait for it" to MODE_WAIT,
        "Both" to MODE_BOTH,
    )

    const val FLAG_AGAIN = "again"    // start even if the script is still running from the last time
    const val FLAG_NOOPEN = "noopen"  // slide in: the cells window does not open
    const val FLAG_LIFT = "lift"      // slide in: floating windows it opened close when the thumb lifts

    /** The bar a block listens to is kept in its flags as "from=<where>" (nothing = the main bar, as before). */
    private const val FROM = "from="

    fun fromOf(flags: String): String = flags.split(',').map { it.trim() }.firstOrNull { it.startsWith(FROM) }?.removePrefix(FROM) ?: ""

    fun setFrom(flags: String, where: String): String {
        val rest = flags.split(',').map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith(FROM) }
        return (if (where.isEmpty()) rest else rest + (FROM + where)).joinToString(",")
    }

    /** "  [side bars]" for a block that listens to more than the main bar, else "". */
    fun fromLabel(flags: String): String = WhenRules.whereShort(fromOf(flags)).let { if (it.isEmpty()) "" else "  [$it]" }

    fun hasFlag(flags: String, flag: String): Boolean = flags.split(',').any { it.trim() == flag }

    fun setFlag(flags: String, flag: String, on: Boolean): String {
        val rest = flags.split(',').map { it.trim() }.filter { it.isNotEmpty() && it != flag }
        return (if (on) rest + flag else rest).joinToString(",")
    }

    private val SHORT_EVENT = mapOf(
        WhenRules.SLIDE_IN to "Slide in",
        WhenRules.VOL_UP to "Volume up",
        WhenRules.VOL_DOWN to "Volume down",
        WhenRules.AT_ZERO to "Volume at 0%",
        WhenRules.AT_FULL to "Volume at 100%",
        WhenRules.CELL_RUNS to "A cell runs",
        WhenRules.CLOSES to "Window closes",
    )

    /** Short words for the block on the canvas and the list. */
    fun eventLabel(event: String, cellName: String = ""): String {
        val base = SHORT_EVENT[event] ?: event
        return if (event == WhenRules.CELL_RUNS && cellName.isNotEmpty()) "$base: $cellName" else base
    }

    fun modeLabel(mode: String): String = when (mode.ifEmpty { MODE_START }) {
        MODE_WAIT -> "wait"
        MODE_BOTH -> "start + wait"
        else -> "start"
    }

    fun onlyLabel(only: String, pkg: String): String = when (only) {
        WhenRules.ONLY_APP -> if (pkg.isEmpty()) "an app is in front" else "$pkg is in front"
        WhenRules.ONLY_PORTRAIT -> "portrait"
        WhenRules.ONLY_LANDSCAPE -> "landscape"
        WhenRules.ONLY_KEYBOARD -> "keyboard open"
        WhenRules.ONLY_HEADPHONES -> "headphones connected"
        else -> only
    }

    // ---- waiting ----------------------------------------------------------------------------------

    private class Waiter(val event: String, val cellKey: String, val where: String) {
        val latch = CountDownLatch(1)
    }

    private val waiters = ArrayList<Waiter>()

    /**
     * Stops the calling script thread until [event] happens. [limitMs] 0 = as long as it takes. True when it
     * happened, false when the time ran out. A stop of the script interrupts the wait, like a Delay block.
     */
    fun await(event: String, cellKey: String, limitMs: Long, where: String = ""): Boolean {
        val w = Waiter(event, cellKey, where)
        synchronized(waiters) { waiters.add(w) }
        try {
            return if (limitMs > 0L) w.latch.await(limitMs, TimeUnit.MILLISECONDS) else { w.latch.await(); true }
        } finally {
            synchronized(waiters) { waiters.remove(w) }
        }
    }

    // ---- starting ---------------------------------------------------------------------------------

    data class ArmedInfo(val script: String, val label: String, val alwaysOn: Boolean)

    private class Start(
        val script: String,
        val block: Int,
        val event: String,
        val cellKey: String,
        val flags: String,
        val nextId: Int = 0,
        val forkId: Int = 0,
        val byId: Map<Int, Step> = emptyMap(),
    ) {
        val where: String get() = fromOf(flags)
    }

    @Volatile private var source: String? = null
    @Volatile private var starts: List<Start> = emptyList()

    private fun uiPrefs(context: Context) = context.getSharedPreferences("FlowUi", Context.MODE_PRIVATE)

    fun isBgEnabled(context: Context): Boolean = uiPrefs(context).getBoolean("bgChecksAsRunning", true)

    fun setBgEnabled(context: Context, on: Boolean) {
        uiPrefs(context).edit().putBoolean("bgChecksAsRunning", on).apply()
    }

    fun stoppedScripts(context: Context): Set<String> =
        uiPrefs(context).getStringSet("stoppedWhenScripts", emptySet())?.toSet() ?: emptySet()

    private fun saveStopped(context: Context, set: Set<String>) {
        uiPrefs(context).edit().putStringSet("stoppedWhenScripts", HashSet(set)).apply()
    }

    fun arm(context: Context, script: String) {
        val cur = stoppedScripts(context)
        if (script in cur) saveStopped(context, cur - script)
    }

    fun stop(context: Context, script: String) {
        val cur = stoppedScripts(context)
        if (script !in cur) saveStopped(context, cur + script)
    }

    fun stopAll(context: Context) {
        val names = startsOf(context).map { it.script }.toSet()
        if (names.isEmpty()) return
        saveStopped(context, stoppedScripts(context) + names)
    }

    /** Active background triggers (`Step.WHEN` Start/Both) that have not been stopped. */
    fun armed(context: Context): List<ArmedInfo> {
        val list = startsOf(context)
        if (list.isEmpty()) return emptyList()
        val stopped = stoppedScripts(context)
        val byScript = LinkedHashMap<String, MutableList<String>>()
        for (s in list) {
            if (s.script in stopped) continue
            byScript.getOrPut(s.script) { ArrayList() }.add(eventLabel(s.event, s.cellKey))
        }
        return byScript.map { (script, events) ->
            ArmedInfo(
                script = script,
                label = "Waiting for: " + events.distinct().joinToString(", "),
                alwaysOn = FlowPrefs.isAlwaysOn(context, script),
            )
        }
    }

    /** The blocks that start a script. Read again only when the saved scripts are a different text than last time. */
    private fun startsOf(context: Context): List<Start> {
        val json = FlowStore.rawJson(context)
        if (json == null) { source = null; starts = emptyList(); return emptyList() }
        if (json === source) return starts
        val out = ArrayList<Start>()
        // Scripts are saved without spaces, so this finds out cheaply whether any script has such a block.
        if (json.contains("\"t\":\"" + Step.WHEN + "\"")) runCatching {
            val all = JSONObject(json)
            for (name in all.keys()) {
                val arr = all.optJSONArray(name) ?: continue
                val whenIndices = ArrayList<Int>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    if (o.optString("t") == Step.WHEN && o.optInt("i", 0) > 0 && o.optString("b") != MODE_WAIT) {
                        whenIndices.add(i)
                    }
                }
                if (whenIndices.isEmpty()) continue
                val byId = HashMap<Int, Step>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val st = Step.fromJson(o)
                    if (st.id > 0) byId[st.id] = st
                }
                for (idx in whenIndices) {
                    val o = arr.optJSONObject(idx) ?: continue
                    val id = o.optInt("i", 0)
                    out.add(
                        Start(
                            script = name,
                            block = id,
                            event = o.optString("a"),
                            cellKey = o.optString("c"),
                            flags = o.optString("f"),
                            nextId = o.optInt("n", 0),
                            forkId = o.optInt("r", 0),
                            byId = byId,
                        )
                    )
                }
            }
        }
        starts = out
        source = json
        return out
    }

    private fun canReachActionNow(context: Context, s: Start): Boolean {
        if (s.forkId != 0 || s.nextId == 0) return true
        var cur = s.nextId
        var hops = 0
        while (cur != 0 && hops++ < 16) {
            val step = s.byId[cur] ?: return true
            when (step.type) {
                Step.NOTE -> {
                    if (step.r != 0) return true
                    cur = step.n
                }
                Step.ONLYIF -> {
                    if (step.b.contains('{')) return true
                    cur = if (WhenRules.holdsNow(context, step.a, step.b.trim())) step.n else step.r
                }
                Step.STOP -> return false
                else -> return true
            }
        }
        return cur != 0
    }

    /**
     * An event of the main bar happened: lets waiting scripts go on and starts the scripts that begin at it.
     * Returns, for the slide-in event, one row per script block that matched, so the main bar knows whether the
     * cells window still opens and whether floating windows close when the thumb lifts.
     */
    fun fire(context: Context, event: String, cellKey: String = "", src: String = ""): List<WhenRules.Rule> {
        synchronized(waiters) {
            for (w in waiters) {
                if (w.event == event && (event != WhenRules.CELL_RUNS || w.cellKey == cellKey) && WhenRules.sourceMatches(w.where, src)) w.latch.countDown()
            }
        }
        val list = startsOf(context)
        if (list.isEmpty()) return emptyList()
        val stopped = stoppedScripts(context)
        val matched = ArrayList<WhenRules.Rule>()
        for (s in list) {
            if (s.script in stopped) continue
            if (s.event != event || (event == WhenRules.CELL_RUNS && s.cellKey != cellKey) || !WhenRules.sourceMatches(s.where, src)) continue
            if (!canReachActionNow(context, s)) continue
            if (event == WhenRules.SLIDE_IN) {
                matched.add(WhenRules.Rule(event, alsoOpen = !hasFlag(s.flags, FLAG_NOOPEN), closeOnLift = hasFlag(s.flags, FLAG_LIFT)))
            }
            if (!hasFlag(s.flags, FLAG_AGAIN) && FlowRunner.running(includeBackground = false).any { it.name == s.script }) continue
            launch(context, s)
        }
        return matched
    }

    private fun launch(context: Context, s: Start) {
        val app = context.applicationContext
        val vars = HashMap<String, String>()
        vars["__when_start__"] = s.block.toString()
        vars["event"] = s.event
        Thread {
            runCatching {
                FlowRunner.run(
                    app, s.script, log = {},
                    message = { t -> Handler(Looper.getMainLooper()).post { Toast.makeText(app, t, Toast.LENGTH_SHORT).show() } },
                    vars = vars, startAt = s.block,
                )
            }
        }.start()
    }
}
