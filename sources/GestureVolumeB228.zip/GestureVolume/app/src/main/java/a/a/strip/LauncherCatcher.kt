package a.a.strip

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.flow.FlowStore
import a.a.flow.Step
import a.a.utils.ShizukuShell

/** Saving a shortcut's action into the cells or into My Scripts (used by the details panels). */
object ActionSaver {
    private fun prefs(context: Context) = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    /** Adds a cell at the end of the cells window's top level. */
    fun saveToCells(context: Context, label: String, action: String, icon: String = "") {
        val p = prefs(context)
        val cfg = StripConfig.load(context, p.getString(SettingsBackup.STRIP_KEY, null))
        val cols = cfg.columns.coerceIn(1, 16)
        val follow = p.getInt("stripPinFollow", StripConfig.PIN_ALL)
        val (added, keep) = StripConfig.withNewCell(cfg.items, StripItem(label.ifBlank { "Shortcut" }, icon, action), cols, follow)
        val next = cfg.copy(items = StripConfig.settlePins(added, cols, follow, emptyList(), keep))
        p.edit().putString(SettingsBackup.STRIP_KEY, next.toJson()).apply()
    }

    /**
     * The action that opens [pkg] through Hail (also when the app is hidden/frozen): the same intent
     * Shortcut Maker makes for a Hail shortcut, Hail's own API screen with the target in the "package" extra.
     */
    fun hailAction(pkg: String): String {
        val i = Intent("com.aistra.hail.action.LAUNCH")
            .setPackage("com.aistra.hail")
            .setComponent(android.content.ComponentName("com.aistra.hail", "com.aistra.hail.ui.api.ApiActivity"))
            .putExtra("package", pkg)
            .addFlags(0x14000000)
        return "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME)
    }

    /** Saves an app shortcut (intent) or a shell command as a one-step script. False for other kinds. */
    fun saveToScripts(context: Context, name: String, action: String): Boolean {
        val step = when {
            action.startsWith("Intent:") -> Step(Step.INTENT, action.removePrefix("Intent:"))
            action.startsWith("Shell:") -> Step(Step.SHELL, action.removePrefix("Shell:"))
            else -> return false
        }
        var n = name.ifBlank { "Shortcut" }
        val have = FlowStore.names(context).toSet()
        if (n in have) { var i = 2; while ("$n $i" in have) i++; n = "$n $i" }
        FlowStore.save(context, n, listOf(step))
        return true
    }
}

/** Finds a shortcut's real intent in `dumpsys shortcut` (needs Shizuku); the launcher API hides it. Blocking. */
object ShortcutDump {
    fun intentUri(pkg: String, id: String): String? {
        if (!ShizukuShell.isReady()) return null
        val q = id.replace("'", "'\\''")
        val sb = StringBuilder()
        runCatching { ShizukuShell.run("dumpsys shortcut | grep -F 'id=$q,'") { sb.append(it).append('\n') } }
        val line = sb.lines().firstOrNull { it.contains("Intent {") && (it.contains(pkg)) } ?: return null
        val body = line.substringAfter("Intent {").substringBefore("}").trim()
        val i = Intent()
        var data: Uri? = null
        var type: String? = null
        for (t in body.split(' ')) {
            when {
                t.startsWith("act=") -> i.action = t.removePrefix("act=")
                t.startsWith("dat=") -> data = Uri.parse(t.removePrefix("dat="))
                t.startsWith("typ=") -> type = t.removePrefix("typ=")
                t.startsWith("flg=0x") -> i.flags = t.removePrefix("flg=0x").toLongOrNull(16)?.toInt() ?: 0
                t.startsWith("pkg=") -> i.`package` = t.removePrefix("pkg=")
                t.startsWith("cmp=") -> ComponentName.unflattenFromString(t.removePrefix("cmp="))?.let { i.component = it }
                t.startsWith("cat=[") -> t.removePrefix("cat=[").removeSuffix("]").split(',').filter { it.isNotBlank() }.forEach { i.addCategory(it) }
            }
        }
        if (data != null && type != null) i.setDataAndType(data, type) else if (data != null) i.data = data else if (type != null) i.type = type
        return i.toUri(Intent.URI_INTENT_SCHEME)
    }
}

private const val HOME_ALIAS = "a.a.strip.LauncherHomeActivity"

/** What Android gives a launcher about a shortcut someone is pinning, with the actions to keep it. */
class PinCatcherActivity : ComponentActivity() {
    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val la = getSystemService(LauncherApps::class.java)
        val req = runCatching { la.getPinItemRequest(intent) }.getOrNull()
        val si = req?.takeIf { it.isValid }?.shortcutInfo
        if (si == null) { finish(); return }
        val info = StringBuilder()
        runCatching {
            info.append("Name: ${si.shortLabel}\n")
            si.longLabel?.let { info.append("Long name: $it\n") }
            info.append("Id: ${si.id}\nPackage: ${si.`package`}\n")
            si.activity?.let { info.append("Activity: ${it.flattenToString()}\n") }
            si.categories?.let { info.append("Categories: ${it.joinToString()}\n") }
            @Suppress("DEPRECATION")
            si.extras?.let { ex -> for (k in ex.keySet()) info.append("Extra $k = ${ex.get(k)}\n") }
            info.append("User: ${si.userHandle}\n")
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var uri by remember { mutableStateOf("") }
                    var looked by remember { mutableStateOf(false) }
                    var name by remember { mutableStateOf(si.shortLabel?.toString().orEmpty()) }
                    Column(Modifier.statusBarsPadding().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("A pinned shortcut", fontSize = 18.sp)
                        androidx.compose.foundation.text.selection.SelectionContainer {
                            Text(info.toString() + if (uri.isNotEmpty()) "\nIntent: $uri" else "", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        if (uri.isEmpty()) {
                            Text(
                                if (looked) "The real intent was not found (Android hides it from launchers; Shizuku can read it)."
                                else "Android hides the real intent from launchers. With Shizuku running it can be read from the system's shortcut list.",
                                fontSize = 12.sp,
                            )
                            OutlinedButton(onClick = {
                                Thread {
                                    val r = ShortcutDump.intentUri(si.`package`, si.id)
                                    runOnUiThread { uri = r.orEmpty(); looked = true }
                                }.start()
                            }) { Text("Read the intent with Shizuku") }
                        }
                        OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                        val action = if (uri.isNotEmpty()) "Intent:$uri" else ""
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = {
                                val cm = getSystemService(android.content.ClipboardManager::class.java)
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", info.toString() + (if (uri.isNotEmpty()) "Intent: $uri" else "")))
                                Toast.makeText(this@PinCatcherActivity, "Copied", Toast.LENGTH_SHORT).show()
                            }) { Text("Copy info") }
                            if (action.isNotEmpty()) {
                                OutlinedButton(onClick = {
                                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", action))
                                    Toast.makeText(this@PinCatcherActivity, "Copied", Toast.LENGTH_SHORT).show()
                                }) { Text("Copy raw") }
                                OutlinedButton(onClick = {
                                    ActionSaver.saveToCells(this@PinCatcherActivity, name, action)
                                    Toast.makeText(this@PinCatcherActivity, "Saved to cells", Toast.LENGTH_SHORT).show()
                                }) { Text("Save to cells") }
                                OutlinedButton(onClick = {
                                    ActionSaver.saveToScripts(this@PinCatcherActivity, name, action)
                                    Toast.makeText(this@PinCatcherActivity, "Saved to My Scripts", Toast.LENGTH_SHORT).show()
                                }) { Text("Save to My Scripts") }
                            }
                            OutlinedButton(onClick = {
                                runCatching { req?.accept() }
                                finish()
                            }) { Text("Let it be added (accept)") }
                            OutlinedButton(onClick = { finish() }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }
}

/** What the home button shows while A is the temporary launcher. */
class LauncherHomeActivity : ComponentActivity() {
    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // "A is the launcher while I use widgets/OCR": show nothing. The bank's screen just closed -> back to the
        // widget/OCR screen; any other home press -> the launcher that was in use before.
        if (LauncherGuard.isOn(this)) {
            val screen = LauncherGuard.screen(this)
            a.a.utils.DiagLog.note("Home pressed while A is the launcher: screen=" + screen + " otherRecent=" + LauncherGuard.otherRecent(this))
            if (screen != null && LauncherGuard.otherRecent(this)) {
                LauncherGuard.clearOther(this)
                runCatching {
                    startActivity(Intent().setClassName(this, screen).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                }
                finish(); overridePendingTransition(0, 0); return
            }
            val prev = LauncherGuard.prevHome(this)?.let { ComponentName.unflattenFromString(it) }
            if (prev != null) {
                val ok = runCatching {
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setComponent(prev).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.isSuccess
                if (ok) { finish(); overridePendingTransition(0, 0); return }
            }
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    val pm = packageManager
                    val others = remember {
                        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                        pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
                    }
                    Column(Modifier.statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("A is the temporary launcher", fontSize = 18.sp)
                        Text("Pin shortcuts now (for example from Hail) and A shows what they contain. Open your usual launcher with a button below, and switch back when you are done.", fontSize = 13.sp)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (ri in others) {
                                OutlinedButton(onClick = {
                                    val ai = ri.activityInfo
                                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                                        .setComponent(ComponentName(ai.packageName, ai.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }) { Text(ri.loadLabel(pm).toString()) }
                            }
                            OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Choose the default home app") }
                            OutlinedButton(onClick = { startActivity(Intent(this@LauncherHomeActivity, LauncherModeActivity::class.java)) }) { Text("Launcher mode window") }
                            OutlinedButton(onClick = { startActivity(Intent(this@LauncherHomeActivity, WidgetHostActivity::class.java)) }) { Text("Widgets") }
                        }
                    }
                }
            }
        }
    }
}

/** The switch for the temporary launcher mode, and the steps to use it. */
class LauncherModeActivity : ComponentActivity() {
    private fun enabled(): Boolean = packageManager.getComponentEnabledSetting(ComponentName(this, HOME_ALIAS)) ==
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var on by remember { mutableStateOf(enabled()) }
                    var status by remember { mutableStateOf("") }
                    var tmp by remember { mutableStateOf(LauncherGuard.isOn(this@LauncherModeActivity)) }
                    Column(Modifier.statusBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Widgets/Launcher mode", fontSize = 18.sp)
                        Text("Catches shortcuts pinned by other apps (Hail and others) and shows everything Android gives about them, with Copy, Save to cells and Save to My Scripts. It costs nothing while off.", fontSize = 13.sp)
                        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("1. Let A be chosen as a launcher", modifier = Modifier.weight(1f))
                            Switch(checked = on, onCheckedChange = {
                                on = it
                                packageManager.setComponentEnabledSetting(
                                    ComponentName(this@LauncherModeActivity, HOME_ALIAS),
                                    if (it) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                                    PackageManager.DONT_KILL_APP,
                                )
                            })
                        }
                        OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }) { Text("2. Open Android's default home app setting") }
                        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { startActivity(Intent(this@LauncherModeActivity, WidgetHostActivity::class.java)) }) { Text("Widgets") }
                            Switch(checked = tmp, onCheckedChange = { want ->
                                status = if (want) "Turning on…" else "Turning off…"
                                LauncherGuard.set(this@LauncherModeActivity, want) { _, msg ->
                                    runOnUiThread { tmp = LauncherGuard.isOn(this@LauncherModeActivity); status = msg }
                                }
                            })
                            Text("A is the launcher while I use widgets/OCR (turn it on before going in, off when done)", fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                        Text("Choose A there. Pin the shortcut from the other app; A opens and shows it. When done, choose your usual launcher again there (and turn the switch off).", fontSize = 12.sp)
                        OutlinedButton(onClick = { status = if (isDefaultHome()) "A is the default launcher now." else "A is not the default launcher." }) { Text("Check: is A the launcher now?") }
                        if (status.isNotEmpty()) Text(status)
                        Text("Notes: Android hides a pinned shortcut's real intent from launchers, so A also offers to read it with Shizuku. A shortcut that is a plain activity intent keeps working in cells without A being the launcher; one that only the launcher can start needs A to be the launcher when it runs.", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
