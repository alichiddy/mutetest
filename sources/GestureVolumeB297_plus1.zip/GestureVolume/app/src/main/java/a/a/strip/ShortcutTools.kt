package a.a.strip

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * What any chosen shortcut can do besides being saved: run now (Test), go onto a launcher's home
 * screen, or become an app of its own (a ready slot, or a new APK built here).
 *
 * Nothing here runs until one of those buttons is pressed.
 */
object ShortcutTools {
    /** Every helper app's package starts with this; the slots are a.a.sc.s1 .. s10, built ones a.a.sc.b<random>. */
    const val STUB_PREFIX = "a.a.sc."
    const val SLOTS = 10
    private const val MAP_KEY = "stubMap"

    class Entry(val label: String, val icon: String, val action: String, val appName: String = "", val iconHash: String = "")

    private fun prefs(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

    // ---- the question window when a shortcut is picked (off unless the person turns it on) ----

    private const val ASK_KEY = "pickAsk"
    fun askOnPick(c: Context): Boolean = prefs(c).getBoolean(ASK_KEY, false)
    fun setAskOnPick(c: Context, on: Boolean) { prefs(c).edit().putBoolean(ASK_KEY, on).apply() }

    // ---- Test -------------------------------------------------------------------------------

    @Volatile private var testToken: String? = null
    @Volatile private var testUntil = 0L

    /** True for a run started by [test] a moment ago: it may run an action that is not saved anywhere yet. */
    fun isTrusted(token: String?): Boolean = token != null && token == testToken && System.currentTimeMillis() < testUntil

    fun runIntent(c: Context, label: String, icon: String, action: String): Intent =
        Intent(c, ShortcutRunActivity::class.java).setAction(Intent.ACTION_MAIN)
            .putExtra("n", label).putExtra("a", action).putExtra("i", icon)

    /** Runs the shortcut now, the way a cell would, without saving it. */
    fun test(c: Context, label: String, icon: String, action: String) {
        if (action.isBlank()) { toast(c, "Nothing to run yet"); return }
        val token = java.util.UUID.randomUUID().toString()
        testToken = token
        testUntil = System.currentTimeMillis() + 15_000L
        c.startActivity(runIntent(c, label, icon, action).putExtra("t", token).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---- icon -------------------------------------------------------------------------------

    private fun bitmapOf(d: android.graphics.drawable.Drawable, size: Int): Bitmap =
        Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { d.setBounds(0, 0, size, size); d.draw(Canvas(it)) }

    private fun tile(size: Int): Pair<Bitmap, Canvas> {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val r = size * 0.21f
        cv.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF37474F.toInt() })
        return out to cv
    }

    /** The cell's own picture, app icon or emoji as a picture; A's own icon when it has none. */
    fun iconBitmap(c: Context, label: String, icon: String, action: String, size: Int = 96): Bitmap {
        val item = StripItem(label, icon, action)
        item.iconFile?.let { f ->
            runCatching { BitmapFactory.decodeFile(File(c.filesDir, "sicons/$f").path) }.getOrNull()?.let { src ->
                val (out, cv) = tile(size)
                val inner = (size * 2 / 3f).toInt()
                val off = (size - inner) / 2f
                cv.drawBitmap(Bitmap.createScaledBitmap(src, inner, inner, true), off, off, null)
                return out
            }
        }
        item.appIconPackage?.let { pkg ->
            runCatching { bitmapOf(c.packageManager.getApplicationIcon(pkg), size) }.getOrNull()?.let { return it }
        }
        if (item.iconFile == null && item.appIconPackage == null && icon.isNotBlank() && icon != "none" && icon.length <= 12) {
            val (out, cv) = tile(size)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size * 0.58f; textAlign = Paint.Align.CENTER }
            cv.drawText(icon, size / 2f, size / 2f - (p.descent() + p.ascent()) / 2f, p)
            return out
        }
        return bitmapOf(c.packageManager.getApplicationIcon(c.packageName), size)
    }

    // ---- launchers --------------------------------------------------------------------------

    fun defaultLauncher(c: Context): String? =
        c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName

    /** Every installed launcher except A itself and the default one: package and name. */
    fun otherLaunchers(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val def = defaultLauncher(c)
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != c.packageName && it.first != def }
            .distinctBy { it.first }
    }

    /** Asks the default launcher for a home-screen icon; the launcher shows its own "Add" question. False when it does not accept. */
    fun pinToDefault(c: Context, label: String, icon: String, action: String): Boolean = runCatching {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(c)) return false
        val name = label.ifBlank { "A" }
        val info = ShortcutInfoCompat.Builder(c, "a_" + Integer.toHexString((label + "|" + action).hashCode()))
            .setShortLabel(name.take(24)).setLongLabel(name)
            .setIntent(runIntent(c, label, icon, action))
            .setIcon(IconCompat.createWithBitmap(iconBitmap(c, label, icon, action)))
            .build()
        ShortcutManagerCompat.requestPinShortcut(c, info, null)
    }.getOrDefault(false)

    /** The old "install shortcut" request, sent to one launcher. Only launchers that still listen to it add the icon. */
    fun sendLegacy(c: Context, pkg: String, label: String, icon: String, action: String) {
        val i = Intent("com.android.launcher.action.INSTALL_SHORTCUT").setPackage(pkg)
            .putExtra(Intent.EXTRA_SHORTCUT_INTENT, runIntent(c, label, icon, action))
            .putExtra(Intent.EXTRA_SHORTCUT_NAME, label.ifBlank { "A" })
            .putExtra(Intent.EXTRA_SHORTCUT_ICON, iconBitmap(c, label, icon, action))
        c.sendBroadcast(i)
    }

    // ---- apps of their own ------------------------------------------------------------------

    fun stubEntry(c: Context, pkg: String): Entry? = runCatching {
        val o = JSONObject(prefs(c).getString(MAP_KEY, "{}") ?: "{}").optJSONObject(pkg) ?: return null
        Entry(o.optString("n"), o.optString("i"), o.optString("a"), o.optString("x"), o.optString("h"))
    }.getOrNull()

    fun assignStub(c: Context, pkg: String, e: Entry) {
        val m = runCatching { JSONObject(prefs(c).getString(MAP_KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())
        m.put(pkg, JSONObject().put("n", e.label).put("i", e.icon).put("a", e.action).put("x", e.appName).put("h", e.iconHash))
        prefs(c).edit().putString(MAP_KEY, m.toString()).apply()
    }

    fun isInstalled(c: Context, pkg: String): Boolean =
        runCatching { c.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

    private fun shareDir(c: Context) = File(c.cacheDir, "share").apply { mkdirs() }

    /** Opens the system installer for [f]; first sends the person to the "allow installing" switch when it is off. */
    fun installFile(c: Context, f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls()) {
            toast(c, "Allow A to install apps on the next screen, then press the button again.")
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        c.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /**
     * Option A: the ready slot app number [n] is given this shortcut and the name [appName]. A slot that is not installed
     * is installed with that name; an installed one whose name changed is installed again over itself with the new name
     * (if Android refuses, uninstall that slot once and press again).
     */
    fun useSlot(c: Context, n: Int, label: String, icon: String, action: String, appName: String) {
        val pkg = STUB_PREFIX + "s$n"
        val name = appName.trim().ifBlank { "A $n" }.take(30)
        val old = stubEntry(c, pkg)
        val installed = isInstalled(c, pkg)
        // The slot gets the picture chosen for the shortcut too; a changed picture or name installs the slot again over itself.
        val png = ByteArrayOutputStream().also { iconBitmap(c, label, icon, action, 192).compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        val hash = Integer.toHexString(java.util.Arrays.hashCode(png))
        assignStub(c, pkg, Entry(label, icon, action, name, hash))
        if (installed && old != null && old.appName == name && old.iconHash == hash) { toast(c, "App \"$name\" now runs: ${label.ifBlank { action.take(30) }}"); return }
        val app = c.applicationContext
        Thread {
            val main = Handler(Looper.getMainLooper())
            try {
                val apk = ApkCloner.makeShortcutApp(app, pkg, name, png, asset = "stub/s$n.apk", oldPkg = pkg, oldLabel = "A $n")
                main.post { installFile(app, apk) }
            } catch (e: Throwable) {
                a.a.utils.DiagLog.e("Slot app", e)
                main.post { toast(app, "Could not make the slot app: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }.start()
    }

    /** Option B: builds a new APK app for this shortcut (own name, own icon, signed here), keeps a copy in Downloads and opens the installer. */
    fun buildOwnApp(c: Context, label: String, icon: String, action: String, appName: String) {
        val app = c.applicationContext
        toast(app, "Building the app…")
        Thread {
            val main = Handler(Looper.getMainLooper())
            try {
                val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
                val rnd = java.util.Random()
                val pkg = STUB_PREFIX + "b" + (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
                val name = appName.trim().ifBlank { label.ifBlank { "A shortcut" } }.take(30)
                val png = ByteArrayOutputStream().also { iconBitmap(app, label, icon, action, 192).compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                val apk = ApkCloner.makeShortcutApp(app, pkg, name, png)
                assignStub(app, pkg, Entry(label, icon, action, name))
                val saved = ApkCloner.copyToDownloads(app, apk, "A-" + name.replace(Regex("[^A-Za-z0-9._-]+"), "_") + ".apk")
                main.post {
                    toast(app, if (saved) "Saved in Downloads. Install it to finish." else "Built. Install it to finish.")
                    installFile(app, apk)
                }
            } catch (e: Throwable) {
                a.a.utils.DiagLog.e("Shortcut app", e)
                main.post { toast(app, "Could not build the app: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }.start()
    }
}
