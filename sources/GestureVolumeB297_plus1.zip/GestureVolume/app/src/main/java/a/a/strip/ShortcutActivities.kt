package a.a.strip

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.Toast
import a.a.flow.FlowStore
import a.a.service.OverlayRuntime
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import a.a.flow.NativePicker
import a.a.ui.screens.strip.BuiltInPage
import a.a.ui.screens.strip.BuiltInIcons
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.MyScriptsPage
import a.a.R

/**
 * A's shortcuts for other apps (KeyMapper, launchers, Automate...): they pick one of A's strip
 * cells or scripts here, and get back a shortcut that runs it through [ShortcutRunActivity].
 *
 * Both are plain activities with no UI framework and nothing running in between, so they cost
 * nothing while idle.
 */
class ShortcutPickerActivity : androidx.activity.ComponentActivity() {
    private class Choice(val label: String, val action: String, val item: StripItem?)

    private enum class Page { MENU, BUILTIN, APPS, SCRIPTS }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The same windows as inside A: Open an app, Built-in shortcuts (search, A Windows Shortcuts, icons),
        // Device actions, My Scripts. Back goes one step; only Back on the first list closes the picker.
        setContent {
            androidx.compose.material3.MaterialTheme {
                androidx.compose.material3.Surface(androidx.compose.ui.Modifier.fillMaxSize().statusBarsPadding()) {
                    var page by remember { mutableStateOf(Page.MENU) }
                    androidx.activity.compose.BackHandler(enabled = page != Page.MENU) { page = Page.MENU }
                    when (page) {
                        Page.MENU -> Column(androidx.compose.ui.Modifier.fillMaxSize().padding(12.dp)) {
                            androidx.compose.material3.Text("A shortcut", style = androidx.compose.material3.MaterialTheme.typography.titleLarge, modifier = androidx.compose.ui.Modifier.padding(bottom = 8.dp))
                            listOf(
                                "Built-in shortcuts (with device actions)" to { page = Page.BUILTIN },
                                "My Scripts" to { page = Page.SCRIPTS },
                            ).forEach { (name, go) ->
                                androidx.compose.material3.Text(name, androidx.compose.ui.Modifier.fillMaxWidth().clickable { go() }.padding(vertical = 14.dp, horizontal = 6.dp))
                            }
                            androidx.compose.material3.TextButton(onClick = { setResult(RESULT_CANCELED); finish() }) { Text("Cancel") }
                        }
                        Page.BUILTIN -> BuiltInPage(
                            onPick = { entry, name ->
                                val icon = BuiltInIcons.save(this@ShortcutPickerActivity, entry.icon, entry.action).orEmpty()
                                pick(Choice(name, entry.action, StripItem(name, icon, entry.action)))
                            },
                            onBack = { page = Page.MENU },
                            onPickAction = { a, n, ic ->
                                val icon = BuiltInIcons.save(this@ShortcutPickerActivity, ic, a).orEmpty()
                                pick(Choice(n, a, StripItem(n, icon, a)))
                            },
                            onPickApp = { app, _, act -> pick(Choice(app.label, act, StripItem(app.label, "app:${app.packageName}", ""))) },
                        )
                        Page.APPS -> AppList(
                            onPick = { app -> pick(Choice(app.label, HandlerActions.launchApp(app.packageName), StripItem(app.label, "app:${app.packageName}", ""))) },
                            onBack = { page = Page.MENU },
                        )
                        Page.SCRIPTS -> MyScriptsPage(
                            onPick = { label, action, cell -> pick(Choice(label, action, cell)) },
                            onBack = { page = Page.MENU },
                        )
                    }
                }
            }
        }
    }

    private fun pick(c: Choice) {
        val run = Intent(this, ShortcutRunActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .putExtra("n", c.label).putExtra("a", c.action)
            .putExtra("i", c.item?.icon.orEmpty())
        val result = Intent()
            .putExtra(Intent.EXTRA_SHORTCUT_INTENT, run)
            .putExtra(Intent.EXTRA_SHORTCUT_NAME, c.label)
        iconFor(c.item)?.let { result.putExtra(Intent.EXTRA_SHORTCUT_ICON, it) }
            ?: result.putExtra(
                Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                Intent.ShortcutIconResource.fromContext(this, R.mipmap.ic_launcher)
            )
        setResult(RESULT_OK, result)
        finish()
    }

    /** The cell's own picture or app icon as a bitmap; null for an emoji or none (A's icon is used). */
    private fun iconFor(item: StripItem?): Bitmap? {
        if (item == null) return null
        item.iconFile?.let { f ->
            // A's own drawn icons are white: put them on a dark rounded tile so a launcher shows them.
            runCatching { android.graphics.BitmapFactory.decodeFile(java.io.File(filesDir, "sicons/$f").path) }.getOrNull()?.let { src ->
                val out = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                c.drawRoundRect(android.graphics.RectF(0f, 0f, 96f, 96f), 20f, 20f, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF37474F.toInt() })
                c.drawBitmap(Bitmap.createScaledBitmap(src, 64, 64, true), 16f, 16f, null)
                return out
            }
        }
        val pkg = item.appIconPackage ?: return null
        return runCatching {
            val d = packageManager.getApplicationIcon(pkg)
            Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888).also { bm -> d.setBounds(0, 0, 96, 96); d.draw(Canvas(bm)) }
        }.getOrNull()
    }
}

/** Runs the action it was given (an invisible activity, gone as soon as it has handed it over). */
class ShortcutRunActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        execute(
            this, intent.getStringExtra("n").orEmpty(), intent.getStringExtra("i").orEmpty(), intent.getStringExtra("a").orEmpty(),
            ShortcutTools.isTrusted(intent.getStringExtra("t")),
        )
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    companion object {
        /**
         * Runs [action] from [act] (which must still be showing). [trusted] is only true for the Test button: it may run
         * an action that is not saved anywhere yet.
         */
        fun execute(act: Activity, name: String, icon: String, action: String, trusted: Boolean = false) {
            val item = StripItem(name, icon, action)
            val controller = OverlayRuntime.activeController
            // Only what A itself holds may run: any app can send this activity an intent, so an action
            // that is not one of the strip's cells or one of the scripts is ignored.
            val cfg = StripConfig.load(act, act.getSharedPreferences("MyPrefs", Activity.MODE_PRIVATE).getString(SettingsBackup.STRIP_KEY, null))
            val pkgOpened = HandlerActions.launchedPackage(action)
            val known = trusted || cfg.items.any { it.action == action } ||
                HandlerActionCatalog.entryFor(action) != null ||
                NativePicker.isValid(action) ||
                (pkgOpened != null && runCatching { act.packageManager.getPackageInfo(pkgOpened, 0) }.isSuccess) ||
                (action.startsWith("MyFlow:") && FlowStore.resolve(act, action.removePrefix("MyFlow:")) != null)
            if (action.isEmpty() || !known) {
                // nothing to run
            } else if (action.startsWith("Intent:")) {
                // An app's own shortcut is started from this screen while it is still showing: Android
                // drops a start made after it closes (that is what a post to the bar's handler did).
                val target = runCatching { Intent.parseUri(action.removePrefix("Intent:"), Intent.URI_INTENT_SCHEME) }.getOrNull()
                if (target == null || !a.a.utils.AppStarter.start(act, target)) {
                    Toast.makeText(act, a.a.utils.AppStarter.lastFailure ?: "This action is not available on this device", Toast.LENGTH_LONG).show()
                } else StripHeal.saveIfHealed(act, action)
            } else if (controller != null) {
                controller.runStripItem(item)
            } else {
                Toast.makeText(act, "Turn A on first", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/**
 * Started by a helper app of its own (the ready slots and the APKs built from A's shortcut windows): it looks up the
 * shortcut that app was given and runs it. Invisible; nothing stays.
 */
class StubRunActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val stub = intent.getStringExtra("stub").orEmpty()
        val e = if (stub.startsWith(ShortcutTools.STUB_PREFIX)) ShortcutTools.stubEntry(this, stub) else null
        if (e == null) Toast.makeText(this, "This app has no shortcut yet. Give it one in A (Add to launcher).", Toast.LENGTH_LONG).show()
        else ShortcutRunActivity.execute(this, e.label, e.icon, e.action)
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
