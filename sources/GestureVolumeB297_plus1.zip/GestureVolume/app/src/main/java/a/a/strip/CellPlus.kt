package a.a.strip

import android.content.SharedPreferences

/**
 * Option "Show a + in empty cells" (cells window settings, saved per cells window).
 * Letting go of the thumb on the + of an empty cell opens that cell's editing window; in the editor a tap does.
 * [PLUS_EMPTY_WHERE] says where it shows: both the main window and folders, the main window only, or folders only.
 */
object CellPlus {
    const val PLUS_EMPTY = "stripPlusEmpty"
    const val PLUS_EMPTY_WHERE = "stripPlusEmptyWhere"

    const val WHERE_BOTH = 0
    const val WHERE_MAIN = 1
    const val WHERE_FOLDERS = 2

    /** Whether empty cells of this window show a + ([folder] = a folder's window). */
    fun emptyOn(sp: SharedPreferences, folder: Boolean): Boolean {
        if (!sp.getBoolean(PLUS_EMPTY, false)) return false
        return when (sp.getInt(PLUS_EMPTY_WHERE, WHERE_BOTH)) {
            WHERE_MAIN -> !folder
            WHERE_FOLDERS -> folder
            else -> true
        }
    }

    fun isBlank(c: StripItem) = c.action.isEmpty() && c.label.isEmpty() && c.icon.isEmpty() && c.children == null

    /**
     * What the slide-in asks the cells editing window to open: the window [windowId], the folder [path] (cell indices
     * from the top, empty = the main window) and the empty cell [index]. Same process, so a plain field carries it.
     * It is dropped when older than a few seconds, so a request nobody took never opens a window later by surprise.
     */
    class Request(val windowId: String, val path: List<Int>, val index: Int, val at: Long = android.os.SystemClock.uptimeMillis())

    @Volatile var pending: Request? = null

    /** Takes the waiting request for [windowId] (once), or null. */
    @Synchronized fun take(windowId: String): Request? {
        val r = pending ?: return null
        if (android.os.SystemClock.uptimeMillis() - r.at > 8000L) { pending = null; return null }
        if (r.windowId != windowId) return null
        pending = null
        return r
    }
}
