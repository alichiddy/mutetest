package a.a.ui.screens.patchtool

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.File
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Patch tool: replaces several files inside a project zip in one go.
 * You pick the source zip, tick the files to replace from a searchable list, then give the new versions either as
 * several loose files (matched by file name) or as one zip holding them (matched by path). A Check box shows
 * exactly what goes where before anything is built. Replacement files that contain placeholder text instead of
 * real code are refused. The new zip is saved in Downloads, read back and checked.
 * Nothing runs or is held in memory until this window is open.
 */
class PatchToolActivity : ComponentActivity() {
    private var srcName by mutableStateOf<String?>(null)
    private var srcFile by mutableStateOf<File?>(null)
    private var srcEntries by mutableStateOf<List<String>>(emptyList())
    private var chosen by mutableStateOf<Set<String>>(emptySet())
    private var looseFiles by mutableStateOf<List<Pair<String, Uri>>>(emptyList())
    private var repZipName by mutableStateOf<String?>(null)
    private var repZipFile by mutableStateOf<File?>(null)
    private var repEntries by mutableStateOf<List<String>>(emptyList())
    private var outName by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var log by mutableStateOf("")
    private var showList by mutableStateOf(false)

    private val pickSrc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) loadSrc(u)
    }
    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.isNotEmpty()) useLoose(us)
    }
    private val pickRepZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) loadRepZip(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                val res = remember(srcEntries, chosen, looseFiles, repEntries) { resolveAll() }
                val toApply = chosen.filter { res.map.containsKey(it) }.sorted()
                val missing = chosen.filter { !res.map.containsKey(it) }.sorted()
                val hasRep = looseFiles.isNotEmpty() || repEntries.isNotEmpty()
                val ready = srcFile != null && toApply.isNotEmpty() && missing.isEmpty() &&
                    res.problems.isEmpty() && outName.isNotBlank()
                AWindowPage("Patch tool", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        HeroCard(
                            title = "Replace several files in a zip",
                            text = "Pick the source zip, tick the files to replace, then give the new versions as files or as one zip. A new zip is saved in Downloads and checked.",
                            leading = { IconTile(Icons.Filled.Settings, lit = true) },
                        )
                        Column {
                            GroupHeading("Source")
                            RowGroup {
                                KitRow(
                                    title = "Source zip",
                                    shape = cardShape(0, 2),
                                    leading = { IconTile(Icons.Filled.Folder) },
                                    summary = srcName ?: "Tap to choose",
                                    description = if (srcName != null) "${srcEntries.size} files inside" else null,
                                    onClick = { if (!busy) pickSrc.launch(arrayOf("*/*")) },
                                )
                                KitRow(
                                    title = "Files to replace",
                                    shape = cardShape(1, 2),
                                    summary = if (chosen.isEmpty()) "Tap to choose from the list" else "${chosen.size} chosen",
                                    description = when {
                                        srcEntries.isEmpty() -> "Choose the source zip first"
                                        chosen.isEmpty() -> null
                                        else -> names(chosen.sorted())
                                    },
                                    onClick = { if (!busy && srcEntries.isNotEmpty()) showList = true },
                                )
                            }
                        }
                        Column {
                            GroupHeading("New versions (use one of the two)")
                            RowGroup {
                                KitRow(
                                    title = "Several files",
                                    shape = cardShape(0, 2),
                                    summary = if (looseFiles.isEmpty()) "Tap to choose the new files" else "${looseFiles.size} files",
                                    description = if (looseFiles.isEmpty()) "Matched to the zip by file name" else names(looseFiles.map { it.first }),
                                    onClick = { if (!busy) pickFiles.launch(arrayOf("*/*")) },
                                )
                                KitRow(
                                    title = "One zip with the files",
                                    shape = cardShape(1, 2),
                                    summary = repZipName ?: "Tap to choose the zip",
                                    description = if (repZipName != null) "${repEntries.size} files inside" else "Matched to the zip by path",
                                    onClick = { if (!busy) pickRepZip.launch(arrayOf("*/*")) },
                                )
                            }
                        }
                        if (srcFile != null && (chosen.isNotEmpty() || hasRep)) {
                            Column {
                                GroupHeading("Check")
                                TextBox(previewText(res, toApply, missing))
                            }
                        }
                        Column {
                            GroupHeading("Save as")
                            OutlinedTextField(
                                value = outName,
                                onValueChange = { outName = it },
                                singleLine = true,
                                label = { Text("File name (saved in Downloads)") },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Button(
                            onClick = { make() },
                            enabled = ready && !busy,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (busy) "Working..." else "Replace and make zip") }
                        if (log.isNotEmpty()) {
                            Column {
                                GroupHeading("Result")
                                TextBox(log)
                            }
                        }
                    }
                }
                if (showList) {
                    var query by remember { mutableStateOf("") }
                    val shown = remember(srcEntries, query) {
                        val q = query.trim()
                        if (q.isEmpty()) srcEntries else srcEntries.filter { it.contains(q, ignoreCase = true) }
                    }
                    CardWindow(title = "Files to replace", onBack = { showList = false }, scroll = false) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            label = { Text("Search (${shown.size} files, ${chosen.size} chosen)") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        )
                        LazyColumn(
                            Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp),
                        ) {
                            items(shown) { path ->
                                val on = path in chosen
                                KitRow(
                                    title = path.substringAfterLast('/'),
                                    shape = RoundedCornerShape(14.dp),
                                    description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                                    background = if (on) MaterialTheme.colorScheme.primaryContainer else rowColor(),
                                    onClick = { chosen = if (on) chosen - path else chosen + path },
                                    trailing = { if (on) Icon(Icons.Filled.Check, contentDescription = null) },
                                )
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Button(
                                onClick = { chosen = emptySet() },
                                enabled = chosen.isNotEmpty(),
                                modifier = Modifier.weight(1f),
                            ) { Text("Clear") }
                            Button(
                                onClick = { showList = false },
                                modifier = Modifier.weight(1f),
                            ) { Text("Done (${chosen.size})") }
                        }
                    }
                }
            }
        }
    }

    @androidx.compose.runtime.Composable
    private fun TextBox(text: String) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(rowColor()).padding(14.dp),
        ) { Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
    }

    override fun onDestroy() {
        if (isFinishing) {
            File(cacheDir, SRC_TMP).delete()
            File(cacheDir, REP_TMP).delete()
            File(cacheDir, OUT_TMP).delete()
        }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- picking

    /** Copies the source zip into the app's cache and lists the files inside it. */
    private fun loadSrc(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = nameOf(u)
        Thread {
            try {
                val f = File(cacheDir, SRC_TMP)
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val names = listFiles(f)
                srcFile = f
                srcName = name
                srcEntries = names
                chosen = emptySet()
                outName = Regex("(?i)\\.zip$").replace(name, "") + "_patched.zip"
                autoSelect()
            } catch (e: Throwable) {
                log = "PATCH ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    /** Several loose files were picked: they replace any replacement zip picked before. */
    private fun useLoose(us: List<Uri>) {
        if (busy) return
        File(cacheDir, REP_TMP).delete()
        repZipFile = null
        repZipName = null
        repEntries = emptyList()
        looseFiles = us.map { nameOf(it) to it }
        log = ""
        autoSelect()
    }

    /** One zip holding the new files was picked: it replaces any loose files picked before. */
    private fun loadRepZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = nameOf(u)
        Thread {
            try {
                val f = File(cacheDir, REP_TMP)
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val names = listFiles(f)
                looseFiles = emptyList()
                repZipFile = f
                repZipName = name
                repEntries = names
                autoSelect()
            } catch (e: Throwable) {
                log = "PATCH ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    private fun listFiles(f: File): List<String> {
        val names = ArrayList<String>()
        ZipFile(f).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory) names.add(e.name)
            }
        }
        return names.sorted()
    }

    /** Every file that has a new version is ticked for you (you can untick any in the list). */
    private fun autoSelect() {
        val r = resolveAll()
        if (r.map.isNotEmpty()) chosen = chosen + r.map.keys
    }

    // ---------------------------------------------------------------- matching

    /** One new version: a loose file (uri) or an entry of the replacement zip. */
    private class Rep(val label: String, val uri: Uri?, val entry: String?)

    /** [map] holds source path -> its new version. [unmatched] are new versions that fit no file in the source zip. */
    private class Resolved(val map: LinkedHashMap<String, Rep>, val problems: List<String>, val unmatched: List<String>)

    private fun rootOf(src: List<String>): String {
        if (src.isEmpty()) return ""
        val first = src[0].substringBefore('/', "")
        return if (first.isNotEmpty() && src.all { it.startsWith("$first/") }) "$first/" else ""
    }

    private fun resolveAll(): Resolved {
        val map = LinkedHashMap<String, Rep>()
        val problems = ArrayList<String>()
        val unmatched = ArrayList<String>()
        val src = srcEntries
        if (src.isEmpty()) return Resolved(map, problems, unmatched)
        val srcSet = src.toHashSet()
        val root = rootOf(src)
        if (looseFiles.isNotEmpty()) {
            for ((name, uri) in looseFiles) {
                val cands = src.filter { it.substringAfterLast('/') == name }
                var target: String? = null
                var skip = false
                if (cands.size == 1) {
                    target = cands[0]
                } else if (cands.size > 1) {
                    val inChosen = cands.filter { it in chosen }
                    if (inChosen.size == 1) {
                        target = inChosen[0]
                    } else {
                        problems.add("$name fits ${cands.size} files in the zip. Tick the one you mean in the list.")
                        skip = true
                    }
                }
                if (skip) continue
                if (target == null) {
                    unmatched.add(name)
                    continue
                }
                if (map.containsKey(target)) {
                    problems.add("Two new files are named $name.")
                    continue
                }
                map[target] = Rep(name, uri, null)
            }
        } else {
            for (p in repEntries) {
                val target = resolve(p, src, srcSet, root)
                if (target == null) {
                    unmatched.add(p)
                    continue
                }
                val prev = map[target]
                if (prev != null) {
                    problems.add("${prev.label} and $p both fit ${target.removePrefix(root)}.")
                    continue
                }
                map[target] = Rep(p, null, p)
            }
        }
        return Resolved(map, problems, unmatched)
    }

    /** Finds which source file a path from the replacement zip stands for (same path, with or without the project folder). */
    private fun resolve(p: String, src: List<String>, srcSet: Set<String>, root: String): String? {
        if (p in srcSet) return p
        if (root.isNotEmpty() && (root + p) in srcSet) return root + p
        val rest = p.substringAfter('/', "")
        if (rest.isNotEmpty()) {
            if (rest in srcSet) return rest
            if (root.isNotEmpty() && (root + rest) in srcSet) return root + rest
        }
        if (p.contains('/')) {
            val hits = src.filter { it.endsWith("/" + p) }
            return if (hits.size == 1) hits[0] else null
        }
        val hits = src.filter { it.substringAfterLast('/') == p }
        return if (hits.size == 1) hits[0] else null
    }

    private fun names(list: List<String>): String {
        val first = list.take(3).joinToString(", ") { it.substringAfterLast('/') }
        return if (list.size > 3) "$first and ${list.size - 3} more" else first
    }

    private fun previewText(res: Resolved, toApply: List<String>, missing: List<String>): String {
        val root = rootOf(srcEntries)
        val sb = StringBuilder()
        sb.append("Will replace ${toApply.size} file(s):\n")
        for (t in toApply) sb.append(" ${t.removePrefix(root)}\n    <- ${res.map[t]!!.label}\n")
        if (missing.isNotEmpty()) {
            sb.append("\nNo new version found for:\n")
            for (t in missing) sb.append(" ${t.removePrefix(root)}\n")
        }
        val left = res.map.keys.count { it !in chosen }
        if (left > 0) sb.append("\nLeft alone (fits a file, not ticked): $left\n")
        if (res.unmatched.isNotEmpty()) {
            sb.append("\nNot in the source zip, ignored: ${res.unmatched.size}\n")
            for (u in res.unmatched.take(8)) sb.append(" $u\n")
            if (res.unmatched.size > 8) sb.append(" ...and ${res.unmatched.size - 8} more\n")
        }
        for (p in res.problems) sb.append("\nPROBLEM: $p")
        return sb.toString().trim()
    }

    // ---------------------------------------------------------------- building

    private fun make() {
        val src = srcFile ?: return
        if (busy) return
        val res = resolveAll()
        val targets = chosen.filter { res.map.containsKey(it) }.sorted()
        val missing = chosen.filter { !res.map.containsKey(it) }
        if (res.problems.isNotEmpty() || missing.isNotEmpty() || targets.isEmpty()) {
            log = "PATCH ERROR: fix what the Check box shows first.\nNothing was saved."
            return
        }
        busy = true
        log = ""
        val saveName = cleanName(outName)
        val repFile = repZipFile
        val useRepZip = looseFiles.isEmpty() && repFile != null
        val root = rootOf(srcEntries)
        Thread {
            val tmp = File(cacheDir, OUT_TMP)
            var repZip: ZipFile? = null
            try {
                if (useRepZip) repZip = ZipFile(repFile!!)
                val newBytes = LinkedHashMap<String, ByteArray>()
                val problems = ArrayList<String>()
                val warnings = ArrayList<String>()
                var codeChecked = 0
                for (t in targets) {
                    val b = bytesOf(res.map[t]!!, repZip)
                    newBytes[t] = b
                    val leaf = t.substringAfterLast('/')
                    if (b.isEmpty()) {
                        problems.add("$leaf: the new file is empty.")
                        continue
                    }
                    val ext = leaf.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext in TEXT_EXT) {
                        val text = String(b, Charsets.UTF_8)
                        val hit = placeholderHit(text)
                        if (hit != null) {
                            problems.add("$leaf line ${hit.first}: ${hit.second}")
                        } else if (ext == "kt" || ext == "java") {
                            codeChecked++
                            val note = bracketNote(text)
                            if (note != null) warnings.add("$leaf: $note")
                        }
                    }
                }
                if (problems.isNotEmpty()) {
                    throw IllegalStateException("A new file was not accepted:\n" + problems.joinToString("\n") { " - $it" })
                }
                val expectCrc = HashMap<String, Long>()
                var replaced = 0
                var written = 0
                var skipped = 0
                ZipFile(src).use { zf ->
                    ZipOutputStream(tmp.outputStream().buffered()).use { zo ->
                        val seen = HashSet<String>()
                        val en = zf.entries()
                        while (en.hasMoreElements()) {
                            val e = en.nextElement()
                            if (!seen.add(e.name)) { skipped++; continue }
                            val out = ZipEntry(e.name)
                            if (e.time != -1L) out.time = e.time
                            if (e.comment != null) out.comment = e.comment
                            val edited = newBytes[e.name]
                            if (edited != null) {
                                replaced++
                                val crc = CRC32()
                                crc.update(edited)
                                expectCrc[e.name] = crc.value
                                if (e.method == ZipEntry.STORED) {
                                    out.method = ZipEntry.STORED
                                    out.size = edited.size.toLong()
                                    out.compressedSize = edited.size.toLong()
                                    out.crc = crc.value
                                } else {
                                    out.method = ZipEntry.DEFLATED
                                }
                                zo.putNextEntry(out)
                                zo.write(edited)
                                zo.closeEntry()
                            } else if (e.isDirectory) {
                                out.method = ZipEntry.STORED
                                out.size = 0L
                                out.compressedSize = 0L
                                out.crc = 0L
                                zo.putNextEntry(out)
                                zo.closeEntry()
                            } else if (e.method == ZipEntry.STORED) {
                                expectCrc[e.name] = e.crc
                                out.method = ZipEntry.STORED
                                out.size = e.size
                                out.compressedSize = e.size
                                out.crc = e.crc
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            } else {
                                expectCrc[e.name] = e.crc
                                out.method = ZipEntry.DEFLATED
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            }
                            written++
                        }
                    }
                }
                if (replaced != newBytes.size) throw IllegalStateException("Only $replaced of ${newBytes.size} files were found in the zip.")
                val sb = StringBuilder("REPLACED ${targets.size} file(s):\n")
                for (t in targets) sb.append(" - ${t.removePrefix(root)}\n")
                if (skipped > 0) sb.append("Note: $skipped repeated file name(s) in the zip were left out.\n")
                if (warnings.isEmpty()) {
                    sb.append("Brackets: $codeChecked code file(s) balanced.\n")
                } else {
                    for (w in warnings) sb.append("WARNING brackets: $w\n")
                }
                val problem = check(tmp, written, expectCrc)
                if (problem != null) {
                    sb.append("PATCH ERROR: $problem\nNothing was saved.")
                } else {
                    val where = saveToDownloads(tmp, saveName)
                    sb.append("Created: $where (${mb(tmp.length())})\n")
                    sb.append("Read back and checked. $written files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "PATCH ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                runCatching { repZip?.close() }
                tmp.delete()
                busy = false
            }
        }.start()
    }

    private fun bytesOf(rep: Rep, repZip: ZipFile?): ByteArray {
        val u = rep.uri
        if (u != null) return contentResolver.openInputStream(u)!!.use { it.readBytes() }
        val zf = repZip ?: throw IllegalStateException("The replacement zip is not open.")
        val e = zf.getEntry(rep.entry!!) ?: throw IllegalStateException("${rep.entry} is missing in the replacement zip.")
        return zf.getInputStream(e).use { it.readBytes() }
    }

    /** Reads the whole new zip back: every file's checksum must match what it should be. Null when all is well. */
    private fun check(file: File, expected: Int, expectCrc: Map<String, Long>): String? {
        return try {
            var n = 0
            var files = 0
            ZipInputStream(file.inputStream().buffered()).use { zi ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val e = zi.nextEntry ?: break
                    val crc = CRC32()
                    while (true) {
                        val r = zi.read(buf)
                        if (r < 0) break
                        crc.update(buf, 0, r)
                    }
                    n++
                    if (e.isDirectory) continue
                    files++
                    val want = expectCrc[e.name] ?: return "${e.name} is in the new zip but was not expected."
                    if (want != crc.value) return "${e.name} in the new zip does not match."
                }
            }
            when {
                n != expected -> "the new zip holds $n entries, expected $expected."
                files != expectCrc.size -> "the new zip holds $files files, expected ${expectCrc.size}."
                else -> null
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    // ---------------------------------------------------------------- checks on the new files

    /** The first line that looks like a placeholder instead of real code, as (line number, the line), or null. */
    private fun placeholderHit(text: String): Pair<Int, String>? {
        var line = 0
        for (l in text.split('\n')) {
            line++
            if (l.length > 400) continue
            for (rx in PLACEHOLDERS) {
                if (rx.containsMatchIn(l)) return line to l.trim().take(90)
            }
        }
        return null
    }

    /** Null when every bracket closes. Strings (also with ${...} inside), characters and comments are skipped. */
    private fun bracketNote(t: String): String? {
        val st = ArrayList<Char>()
        val n = t.length
        var i = 0
        var mode = 0
        while (i < n) {
            val c = t[i]
            if (mode == 1) {
                when {
                    c == '\\' -> i += 2
                    c == '"' -> { mode = 0; i++ }
                    c == '$' && i + 1 < n && t[i + 1] == '{' -> { st.add('T'); mode = 0; i += 2 }
                    else -> i++
                }
                continue
            }
            if (mode == 2) {
                when {
                    t.startsWith("\"\"\"", i) -> {
                        i += 3
                        while (i < n && t[i] == '"') i++
                        mode = 0
                    }
                    c == '$' && i + 1 < n && t[i + 1] == '{' -> { st.add('R'); mode = 0; i += 2 }
                    else -> i++
                }
                continue
            }
            when {
                t.startsWith("//", i) -> {
                    while (i < n && t[i] != '\n') i++
                }
                t.startsWith("/*", i) -> {
                    var depth = 1
                    i += 2
                    while (i < n && depth > 0) {
                        if (t.startsWith("/*", i)) { depth++; i += 2 }
                        else if (t.startsWith("*/", i)) { depth--; i += 2 }
                        else i++
                    }
                }
                t.startsWith("\"\"\"", i) -> { mode = 2; i += 3 }
                c == '"' -> { mode = 1; i++ }
                c == '`' -> {
                    i++
                    while (i < n && t[i] != '`') i++
                    i++
                }
                c == '\'' -> {
                    i++
                    while (i < n && t[i] != '\'') {
                        if (t[i] == '\\') i++
                        i++
                    }
                    i++
                }
                c == '(' || c == '[' || c == '{' -> { st.add(c); i++ }
                c == ')' || c == ']' || c == '}' -> {
                    val top = if (st.isEmpty()) ' ' else st[st.size - 1]
                    if (c == '}' && (top == 'T' || top == 'R')) {
                        st.removeAt(st.size - 1)
                        mode = if (top == 'T') 1 else 2
                    } else if ((c == ')' && top == '(') || (c == ']' && top == '[') || (c == '}' && top == '{')) {
                        st.removeAt(st.size - 1)
                    } else {
                        val at = t.substring(0, minOf(i, n)).count { it == '\n' } + 1
                        return "line $at: unexpected $c"
                    }
                    i++
                }
                else -> i++
            }
        }
        return if (st.isEmpty() && mode == 0) null else "ends with ${st.size} bracket(s) still open"
    }

    // ---------------------------------------------------------------- saving

    /** Puts the zip in Downloads and returns where it ended up (Android adds (1) if the name is taken). */
    @Suppress("DEPRECATION")
    private fun saveToDownloads(file: File, name: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads.")
            contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            var finalName = name
            runCatching {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { finalName = it }
                }
            }
            return "Downloads/$finalName"
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val dest = File(dir, name)
        file.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return "Downloads/$name"
    }

    private fun cleanName(s: String): String {
        var n = s.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) n = "patched"
        if (!n.endsWith(".zip", ignoreCase = true)) n += ".zip"
        return n
    }

    private fun mb(bytes: Long): String = String.format(Locale.US, "%.2f MB", bytes / 1048576.0)

    private fun nameOf(u: Uri): String {
        var n: String? = null
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    private companion object {
        const val SRC_TMP = "patch_tool_src.zip"
        const val REP_TMP = "patch_tool_rep.zip"
        const val OUT_TMP = "patch_tool_out.zip"

        /** Files whose text is looked through for placeholders. */
        val TEXT_EXT = setOf("kt", "java", "xml", "kts", "gradle")

        /** Lines that stand in for real code: a capital-letter note in square brackets, a comment that is only dots, or a comment saying the old code goes here. */
        val PLACEHOLDERS = listOf(
            Regex("""\[(KEEP|REST OF|EXISTING|UNCHANGED|SAME AS|YOUR CODE|INSERT|PLACE)[A-Z0-9,._'/-]* [A-Z0-9 ,._'/-]*\]"""),
            Regex("""(?i)(//|/\*)\s*\.\.\.\s*((\*/)?\s*$|(existing|rest|more|other|previous|remaining|unchanged|same|omitted|code)\b)"""),
            Regex(
                """(?i)(//|/\*).*(existing\s+(code|logic|implementation)\s+(here|unchanged|remains|stays|goes)|omitted\s+for\s+brevity|keep\s+existing|rest\s+of\s+(the\s+)?(file|code|class|function|method|logic)\s+(here|unchanged|remains|stays|as\s+is|as\s+before|goes))""",
            ),
        )
    }
}
