package a.a.ui.screens.renametool

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Rename tool (light): pick a project zip, see its package name (applicationId) and app name (app_name label)
 * found for you, type the new ones, and save a new zip in Downloads that is read back and checked.
 * Only the applicationId line and the app_name label are changed. The code namespace and every .kt file stay
 * as they are. Each line is changed only when it is found exactly once, otherwise nothing is saved.
 * Nothing runs or is held in memory until this window is open.
 */
class RenameToolActivity : ComponentActivity() {
    private var zipName by mutableStateOf<String?>(null)
    private var srcFile by mutableStateOf<File?>(null)
    private var oldPkg by mutableStateOf("")
    private var oldLabel by mutableStateOf("")
    private var newPkg by mutableStateOf("")
    private var newLabel by mutableStateOf("")
    private var outName by mutableStateOf("")
    private var review by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var log by mutableStateOf("")

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) loadZip(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                val pkgOk = PKG_OK.matches(newPkg.trim())
                val ready = srcFile != null && pkgOk && newLabel.isNotBlank() && outName.isNotBlank()
                AWindowPage("Rename tool", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        HeroCard(
                            title = "Rename the app in a zip",
                            text = "Pick the project zip. Type the new package name and app name. A new zip is saved in Downloads and checked. Only those two things change.",
                            leading = { IconTile(Icons.Filled.Edit, lit = true) },
                        )
                        Column {
                            GroupHeading("Project zip")
                            RowGroup {
                                KitRow(
                                    title = "Zip file",
                                    shape = cardShape(0, 3),
                                    leading = { IconTile(Icons.Filled.Folder) },
                                    summary = zipName ?: "Tap to choose",
                                    onClick = { if (!busy) pickZip.launch(arrayOf("*/*")) },
                                )
                                KitRow(
                                    title = "Package name now",
                                    shape = cardShape(1, 3),
                                    summary = if (srcFile != null) oldPkg else "Found after you choose the zip",
                                )
                                KitRow(
                                    title = "App name now",
                                    shape = cardShape(2, 3),
                                    summary = if (srcFile != null) oldLabel else "Found after you choose the zip",
                                )
                            }
                        }
                        Column {
                            GroupHeading("New names")
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = newPkg,
                                    onValueChange = { newPkg = it },
                                    singleLine = true,
                                    isError = newPkg.isNotBlank() && !pkgOk,
                                    label = { Text("New package name (like a.a3)") },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                OutlinedTextField(
                                    value = newLabel,
                                    onValueChange = { newLabel = it },
                                    singleLine = true,
                                    label = { Text("New app name (like A3)") },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                OutlinedTextField(
                                    value = outName,
                                    onValueChange = { outName = it },
                                    singleLine = true,
                                    label = { Text("File name (saved in Downloads)") },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                        Button(
                            onClick = { make() },
                            enabled = ready && !busy,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (busy) "Working..." else "Rename and make zip") }
                        if (log.isNotEmpty()) {
                            Column {
                                GroupHeading("Result")
                                TextBox(log)
                            }
                        }
                        if (review.isNotEmpty()) {
                            Column {
                                GroupHeading("To review (not changed)")
                                TextBox(review)
                            }
                        }
                    }
                }
            }
        }
    }

    @androidx.compose.runtime.Composable
    private fun TextBox(text: String) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(rowColor()).padding(14.dp),
        ) { Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
    }

    override fun onDestroy() {
        if (isFinishing) {
            File(cacheDir, SRC_TMP).delete()
            File(cacheDir, OUT_TMP).delete()
        }
        super.onDestroy()
    }

    /** Copies the chosen zip into the app's cache, finds the two names and lists the hand-written spots. */
    private fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        review = ""
        val name = nameOf(u)
        Thread {
            try {
                val f = File(cacheDir, SRC_TMP)
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val found = ZipFile(f).use { zf -> find(zf) }
                val spots = ZipFile(f).use { zf -> reviewList(zf, found.pkg) }
                srcFile = f
                zipName = name
                oldPkg = found.pkg
                oldLabel = found.label
                newPkg = found.pkg
                newLabel = found.label
                outName = Regex("(?i)\\.zip$").replace(name, "") + "_renamed.zip"
                review = spots
            } catch (e: Throwable) {
                srcFile = null
                zipName = null
                log = "RENAME ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was changed."
            } finally {
                busy = false
            }
        }.start()
    }

    private fun make() {
        val src = srcFile ?: return
        if (busy) return
        val pkg = newPkg.trim()
        val label = newLabel.trim()
        if (!PKG_OK.matches(pkg)) {
            log = "RENAME ERROR: the package name needs two or more parts with dots, each starting with a letter (like a.a3)."
            return
        }
        busy = true
        log = ""
        val saveName = cleanName(outName)
        Thread {
            val tmp = File(cacheDir, OUT_TMP)
            try {
                val plan = ZipFile(src).use { zf -> plan(zf, pkg, label) }
                if (plan.edits.isEmpty()) throw IllegalStateException("The new names are the same as the old ones. Nothing to change.")
                var written = 0
                var skipped = 0
                ZipFile(src).use { zf ->
                    ZipOutputStream(tmp.outputStream().buffered()).use { zo ->
                        val seen = HashSet<String>()
                        val en = zf.entries()
                        while (en.hasMoreElements()) {
                            val e = en.nextElement()
                            if (!seen.add(e.name)) { skipped++; continue }
                            val out = ZipEntry(e.name)
                            if (e.time != -1L) out.time = e.time
                            if (e.comment != null) out.comment = e.comment
                            val edited = plan.edits[e.name]
                            if (edited != null) {
                                if (e.method == ZipEntry.STORED) {
                                    val crc = java.util.zip.CRC32()
                                    crc.update(edited)
                                    out.method = ZipEntry.STORED
                                    out.size = edited.size.toLong()
                                    out.compressedSize = edited.size.toLong()
                                    out.crc = crc.value
                                } else {
                                    out.method = ZipEntry.DEFLATED
                                }
                                zo.putNextEntry(out)
                                zo.write(edited)
                                zo.closeEntry()
                            } else if (e.isDirectory) {
                                out.method = ZipEntry.STORED
                                out.size = 0L
                                out.compressedSize = 0L
                                out.crc = 0L
                                zo.putNextEntry(out)
                                zo.closeEntry()
                            } else if (e.method == ZipEntry.STORED) {
                                out.method = ZipEntry.STORED
                                out.size = e.size
                                out.compressedSize = e.size
                                out.crc = e.crc
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            } else {
                                out.method = ZipEntry.DEFLATED
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            }
                            written++
                        }
                    }
                }
                val sb = StringBuilder()
                sb.append("PACKAGE: ${plan.oldPkg} -> $pkg\n")
                sb.append("APP NAME: ${plan.oldLabel} -> $label\n")
                sb.append("Changed files:\n")
                for (n in plan.edits.keys) sb.append(" - $n\n")
                if (skipped > 0) sb.append("Note: $skipped repeated file name(s) in the zip were left out.\n")
                val problem = check(tmp, written, plan, pkg, label)
                if (problem != null) {
                    sb.append("RENAME ERROR: $problem\nNothing was saved.")
                } else {
                    val where = saveToDownloads(tmp, saveName)
                    sb.append("Created: $where (${mb(tmp.length())})\n")
                    sb.append("Read back and checked. $written files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "RENAME ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                tmp.delete()
                busy = false
            }
        }.start()
    }

    /** Reads the whole new zip back: every checksum, every edited file, and finds the two names again. */
    private fun check(file: File, expected: Int, plan: Plan, pkg: String, label: String): String? {
        return try {
            var n = 0
            val got = HashMap<String, ByteArray>()
            ZipInputStream(file.inputStream().buffered()).use { zi ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val e = zi.nextEntry ?: break
                    val sink = if (plan.edits.containsKey(e.name)) java.io.ByteArrayOutputStream() else null
                    while (true) {
                        val r = zi.read(buf)
                        if (r < 0) break
                        sink?.write(buf, 0, r)
                    }
                    if (sink != null) got[e.name] = sink.toByteArray()
                    n++
                }
            }
            if (n != expected) return "the new zip holds $n files, expected $expected."
            for ((name, bytes) in plan.edits) {
                val back = got[name] ?: return "$name is missing in the new zip."
                if (!back.contentEquals(bytes)) return "$name in the new zip does not match what was written."
            }
            val again = ZipFile(file).use { zf -> find(zf) }
            when {
                again.pkg != pkg -> "the new zip says package ${again.pkg}, expected $pkg."
                again.label != label -> "the new zip says app name ${again.label}, expected $label."
                else -> null
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Puts the zip in Downloads and returns where it ended up (Android adds (1) if the name is taken). */
    @Suppress("DEPRECATION")
    private fun saveToDownloads(file: File, name: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads.")
            contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            var finalName = name
            runCatching {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { finalName = it }
                }
            }
            return "Downloads/$finalName"
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val dest = File(dir, name)
        file.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return "Downloads/$name"
    }

    private fun cleanName(s: String): String {
        var n = s.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) n = "renamed"
        if (!n.endsWith(".zip", ignoreCase = true)) n += ".zip"
        return n
    }

    private fun mb(bytes: Long): String = String.format(Locale.US, "%.2f MB", bytes / 1048576.0)

    private fun nameOf(u: Uri): String {
        var n: String? = null
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    /** The two names found in a zip (as shown to you, label unescaped). */
    private class Found(val pkg: String, val label: String)

    /** What will be written: the new bytes of each edited file, keyed by its name in the zip. */
    private class Plan(val oldPkg: String, val oldLabel: String, val edits: LinkedHashMap<String, ByteArray>)

    private fun readText(zf: ZipFile, e: ZipEntry): String {
        val bytes = zf.getInputStream(e).use { it.readBytes() }
        val text = String(bytes, Charsets.UTF_8)
        if (!text.toByteArray(Charsets.UTF_8).contentEquals(bytes)) {
            throw IllegalStateException("${e.name} is not clean UTF-8 text, so it is not touched.")
        }
        return text
    }

    private fun isGradle(name: String): Boolean {
        val leaf = name.substringAfterLast('/')
        return leaf == "build.gradle.kts" || leaf == "build.gradle"
    }

    /** Finds the one applicationId line and the one default app_name label. Refuses anything but exactly once. */
    private fun find(zf: ZipFile): Found {
        val ids = ArrayList<Pair<String, String>>()
        val en = zf.entries()
        val names = ArrayList<ZipEntry>()
        while (en.hasMoreElements()) names.add(en.nextElement())
        for (e in names) {
            if (e.isDirectory || !isGradle(e.name)) continue
            for (m in APP_ID.findAll(readText(zf, e))) ids.add(e.name to m.groupValues[2])
        }
        if (ids.isEmpty()) throw IllegalStateException("No applicationId line was found in the zip.")
        if (ids.size > 1) {
            throw IllegalStateException("applicationId was found ${ids.size} times (" + ids.joinToString { it.first } + "). It must be exactly once.")
        }
        val defaults = names.filter { !it.isDirectory && DEFAULT_STRINGS.matches(it.name) }
        val hits = ArrayList<Pair<ZipEntry, MatchResult>>()
        for (e in defaults) {
            val ms = LABEL.findAll(readText(zf, e)).toList()
            if (ms.size > 1) throw IllegalStateException("app_name was found ${ms.size} times in ${e.name}. It must be exactly once.")
            if (ms.size == 1) hits.add(e to ms[0])
        }
        if (hits.isEmpty()) throw IllegalStateException("No app_name label was found in res/values/strings.xml.")
        if (hits.size > 1) {
            throw IllegalStateException("app_name was found in ${hits.size} default strings.xml files (" + hits.joinToString { it.first.name } + "). It must be exactly one.")
        }
        return Found(ids[0].second, unescape(hits[0].second.groupValues[2]))
    }

    /** Works out the new bytes of every file to change, again from the zip itself, with the same exactly-once rule. */
    private fun plan(zf: ZipFile, pkg: String, label: String): Plan {
        val found = find(zf)
        val edits = LinkedHashMap<String, ByteArray>()
        val names = ArrayList<ZipEntry>()
        val en = zf.entries()
        while (en.hasMoreElements()) names.add(en.nextElement())
        if (pkg != found.pkg) {
            for (e in names) {
                if (e.isDirectory || !isGradle(e.name)) continue
                val text = readText(zf, e)
                val m = APP_ID.findAll(text).toList()
                if (m.size != 1) continue
                val g = m[0].groups[2]!!
                edits[e.name] = (text.substring(0, g.range.first) + pkg + text.substring(g.range.last + 1)).toByteArray(Charsets.UTF_8)
            }
        }
        if (label != found.label) {
            val def = names.first { !it.isDirectory && DEFAULT_STRINGS.matches(it.name) && LABEL.containsMatchIn(readText(zf, it)) }
            val resDir = def.name.removeSuffix("values/strings.xml")
            val esc = escape(label)
            for (e in names) {
                if (e.isDirectory) continue
                if (!(e.name == def.name || (e.name.startsWith(resDir + "values-") && e.name.endsWith("/strings.xml") &&
                        e.name.removePrefix(resDir).count { it == '/' } == 1))) continue
                val text = readText(zf, e)
                val ms = LABEL.findAll(text).toList()
                if (ms.size > 1) throw IllegalStateException("app_name was found ${ms.size} times in ${e.name}. It must be exactly once.")
                if (ms.size != 1) continue
                val g = ms[0].groups[2]!!
                edits[e.name] = (text.substring(0, g.range.first) + esc + text.substring(g.range.last + 1)).toByteArray(Charsets.UTF_8)
            }
        }
        return Plan(found.pkg, found.label, edits)
    }

    /**
     * Lists the places where the old package name is written by hand (so it will not follow the rename),
     * plus names that would clash if both copies of the app are installed together. Nothing here is changed.
     */
    private fun reviewList(zf: ZipFile, old: String): String {
        val token = Regex("(?<![A-Za-z0-9_.])" + Regex.escape(old) + "(?![A-Za-z0-9_])(?!\\.[A-Za-z_\"])")
        val hand = ArrayList<String>()
        var handTotal = 0
        val clash = ArrayList<String>()
        val en = zf.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory || e.size > MAX_SCAN) continue
            val leaf = e.name.substringAfterLast('/')
            val ext = leaf.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in SCAN_EXT) continue
            val bytes = zf.getInputStream(e).use { it.readBytes() }
            val text = String(bytes, Charsets.UTF_8)
            for (m in token.findAll(text)) {
                val idx = m.range.first
                val ls = text.lastIndexOf('\n', idx) + 1
                val head = if (idx - ls < 200) text.substring(ls, idx).trim() else ""
                if (head == "package" || head == "import" || head.startsWith("namespace") || head.startsWith("applicationId")) continue
                val lineNo = text.substring(0, idx).count { it == '\n' } + 1
                val from = maxOf(0, idx - 36)
                val to = minOf(text.length, m.range.last + 37)
                val snip = text.substring(from, to).replace('\n', ' ').replace('\r', ' ').trim()
                handTotal++
                if (hand.size < MAX_LINES) hand.add("${e.name.substringAfter('/')}:$lineNo  …$snip…")
            }
            if (leaf == "AndroidManifest.xml") {
                val xml = text
                for (m in PERMISSION.findAll(xml)) clash.add("permission ${m.groupValues[1]}")
                for (m in AUTHORITY.findAll(xml)) {
                    if (!m.groupValues[1].contains("\${applicationId}")) clash.add("provider name ${m.groupValues[1]}")
                }
            }
        }
        val sb = StringBuilder()
        sb.append("Package name written by hand: $handTotal place(s)\n")
        if (handTotal == 0) sb.append("(none found)\n")
        for ((i, s) in hand.withIndex()) sb.append("${i + 1}. $s\n")
        if (handTotal > hand.size) sb.append("...and ${handTotal - hand.size} more\n")
        sb.append("\nFixed names that clash if the old app and the renamed app are both installed:\n")
        if (clash.isEmpty()) sb.append("(none found)") else for (c in clash.distinct()) sb.append("- $c\n")
        return sb.toString().trimEnd()
    }

    private fun escape(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '\'' -> sb.append("\\'")
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun unescape(s: String): String {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
            .replace("\\'", "'").replace("\\\"", "\"").replace("\\\\", "\\").replace("&amp;", "&").trim()
    }

    private companion object {
        const val SRC_TMP = "rename_tool_src.zip"
        const val OUT_TMP = "rename_tool_out.zip"
        const val MAX_SCAN = 3L * 1024 * 1024
        const val MAX_LINES = 40

        val PKG_OK = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
        val APP_ID = Regex("""(?m)^([ \t]*applicationId[ \t]*=?[ \t]*\x22)([^\x22\r\n]*)(\x22)""")
        val LABEL = Regex("""<string\s+name\s*=\s*\x22app_name\x22([^>]*)>(.*?)</string>""", RegexOption.DOT_MATCHES_ALL)
        val DEFAULT_STRINGS = Regex("""(.*/)?res/values/strings\.xml""")
        val PERMISSION = Regex("""<permission\s[^>]*?android:name\s*=\s*\x22([^\x22]+)\x22""")
        val AUTHORITY = Regex("""android:authorities\s*=\s*\x22([^\x22]+)\x22""")
        val SCAN_EXT = setOf("kt", "java", "xml", "json", "kts", "gradle", "pro", "yml", "yaml", "properties", "txt")
    }
}
