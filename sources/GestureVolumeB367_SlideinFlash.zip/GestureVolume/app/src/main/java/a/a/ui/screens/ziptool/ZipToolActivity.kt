package a.a.ui.screens.ziptool

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Zip tool: swaps one file inside a zip for a new file and saves the result as a new zip in Downloads.
 * Three boxes (the zip, the file inside it picked from a list, the new file), a name, one button.
 * Every other file is copied across with its name, date, comment and storage method, then the new zip is
 * read back in full and checked. Nothing runs or is held in memory until this window is open.
 */
class ZipToolActivity : ComponentActivity() {
    private var zipName by mutableStateOf<String?>(null)
    private var srcFile by mutableStateOf<File?>(null)
    private var entries by mutableStateOf<List<String>>(emptyList())
    private var target by mutableStateOf<String?>(null)
    private var targetAuto = false
    private var newUri by mutableStateOf<Uri?>(null)
    private var newName by mutableStateOf<String?>(null)
    private var newSize by mutableStateOf(0L)
    private var outName by mutableStateOf("")
    private var busy by mutableStateOf(false)
    private var log by mutableStateOf("")
    private var showList by mutableStateOf(false)

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) loadZip(u)
    }
    private val pickNew = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            newUri = u
            newName = nameOf(u)
            newSize = sizeOf(u)
            autoMatch()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                val ready = srcFile != null && target != null && newUri != null && outName.isNotBlank()
                AWindowPage("Zip tool", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        HeroCard(
                            title = "Replace one file in a zip",
                            text = "Pick the zip, pick the file inside it, pick the new file. A new zip is saved in Downloads and checked.",
                            leading = { IconTile(Icons.Filled.Folder, lit = true) },
                        )
                        Column {
                            GroupHeading("Pick")
                            RowGroup {
                                KitRow(
                                    title = "Zip file",
                                    shape = cardShape(0, 3),
                                    leading = { IconTile(Icons.Filled.Folder) },
                                    summary = zipName ?: "Tap to choose",
                                    description = if (zipName != null) "${entries.size} files inside" else null,
                                    onClick = { if (!busy) pickZip.launch(arrayOf("*/*")) },
                                )
                                KitRow(
                                    title = "File inside the zip",
                                    shape = cardShape(1, 3),
                                    summary = target ?: "Tap to choose from the list",
                                    description = if (entries.isEmpty()) "Choose the zip first" else null,
                                    onClick = { if (!busy && entries.isNotEmpty()) showList = true },
                                )
                                KitRow(
                                    title = "New file",
                                    shape = cardShape(2, 3),
                                    summary = newName ?: "Tap to choose",
                                    description = if (newName != null) mb(newSize) else null,
                                    onClick = { if (!busy) pickNew.launch(arrayOf("*/*")) },
                                )
                            }
                        }
                        Column {
                            GroupHeading("Save as")
                            OutlinedTextField(
                                value = outName,
                                onValueChange = { outName = it },
                                singleLine = true,
                                label = { Text("File name (saved in Downloads)") },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Button(
                            onClick = { make() },
                            enabled = ready && !busy,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (busy) "Working..." else "Replace and make zip") }
                        if (log.isNotEmpty()) {
                            Column {
                                GroupHeading("Result")
                                Box(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                        .background(rowColor()).padding(14.dp),
                                ) { Text(log, fontFamily = FontFamily.Monospace, fontSize = 13.sp) }
                            }
                        }
                    }
                }
                if (showList) {
                    var query by remember { mutableStateOf("") }
                    val wanted = newName
                    val shown = remember(entries, query, wanted) {
                        val q = query.trim()
                        val hits = if (q.isEmpty()) entries else entries.filter { it.contains(q, ignoreCase = true) }
                        // Files named like the new file come first.
                        hits.sortedBy { if (wanted != null && it.substringAfterLast('/') == wanted) 0 else 1 }
                    }
                    CardWindow(title = "File inside the zip", onBack = { showList = false }, scroll = false) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            label = { Text("Search (${shown.size} files)") },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        )
                        LazyColumn(
                            Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp),
                        ) {
                            items(shown) { path ->
                                KitRow(
                                    title = path.substringAfterLast('/'),
                                    shape = RoundedCornerShape(14.dp),
                                    description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                                    onClick = {
                                        target = path
                                        targetAuto = false
                                        showList = false
                                    },
                                    trailing = null,
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        if (isFinishing) {
            File(cacheDir, SRC_TMP).delete()
            File(cacheDir, OUT_TMP).delete()
        }
        super.onDestroy()
    }

    /** Copies the chosen zip into the app's cache and lists the files inside it. */
    private fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = nameOf(u)
        Thread {
            try {
                val f = File(cacheDir, SRC_TMP)
                contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val names = ArrayList<String>()
                ZipFile(f).use { zf ->
                    val en = zf.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (!e.isDirectory) names.add(e.name)
                    }
                }
                srcFile = f
                zipName = name
                entries = names.sorted()
                outName = Regex("(?i)\\.zip$").replace(name, "") + "_updated.zip"
                target = null
                targetAuto = false
                autoMatch()
            } catch (e: Throwable) {
                log = "ZIP ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    /** When the new file's name fits exactly one file in the zip, that one is chosen for you. */
    private fun autoMatch() {
        val n = newName ?: return
        if (target != null && !targetAuto) return
        val hits = entries.filter { it.substringAfterLast('/') == n }
        if (hits.size == 1) {
            target = hits[0]
            targetAuto = true
        }
    }

    private fun make() {
        val src = srcFile ?: return
        val tgt = target ?: return
        val nu = newUri ?: return
        if (busy) return
        busy = true
        log = ""
        val saveName = cleanName(outName)
        Thread {
            val tmp = File(cacheDir, OUT_TMP)
            try {
                val newBytes = contentResolver.openInputStream(nu)!!.use { it.readBytes() }
                var replaced = 0
                var written = 0
                var skipped = 0
                ZipFile(src).use { zf ->
                    ZipOutputStream(tmp.outputStream().buffered()).use { zo ->
                        val seen = HashSet<String>()
                        val en = zf.entries()
                        while (en.hasMoreElements()) {
                            val e = en.nextElement()
                            if (!seen.add(e.name)) { skipped++; continue }
                            val out = ZipEntry(e.name)
                            if (e.time != -1L) out.time = e.time
                            if (e.comment != null) out.comment = e.comment
                            if (e.name == tgt) {
                                replaced++
                                putBytes(zo, out, e.method, newBytes)
                            } else if (e.isDirectory) {
                                out.method = ZipEntry.STORED
                                out.size = 0L
                                out.compressedSize = 0L
                                out.crc = 0L
                                zo.putNextEntry(out)
                                zo.closeEntry()
                            } else if (e.method == ZipEntry.STORED) {
                                out.method = ZipEntry.STORED
                                out.size = e.size
                                out.compressedSize = e.size
                                out.crc = e.crc
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            } else {
                                out.method = ZipEntry.DEFLATED
                                zo.putNextEntry(out)
                                zf.getInputStream(e).use { it.copyTo(zo) }
                                zo.closeEntry()
                            }
                            written++
                        }
                    }
                }
                if (replaced == 0) throw IllegalStateException("$tgt was not found in the zip.")
                val sb = StringBuilder("REPLACED: $tgt\n")
                if (skipped > 0) sb.append("Note: $skipped repeated file name(s) in the zip were left out.\n")
                val problem = check(tmp, written, tgt, newBytes)
                if (problem != null) {
                    sb.append("ZIP ERROR: $problem\nNothing was saved.")
                } else {
                    val where = saveToDownloads(tmp, saveName)
                    sb.append("Created: $where (${mb(tmp.length())})\n")
                    sb.append("ZIP integrity check passed. $written files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.javaClass.simpleName}: ${e.message}\nNothing was saved."
            } finally {
                tmp.delete()
                busy = false
            }
        }.start()
    }

    private fun putBytes(zo: ZipOutputStream, out: ZipEntry, method: Int, data: ByteArray) {
        if (method == ZipEntry.STORED) {
            val crc = CRC32()
            crc.update(data)
            out.method = ZipEntry.STORED
            out.size = data.size.toLong()
            out.compressedSize = data.size.toLong()
            out.crc = crc.value
        } else {
            out.method = ZipEntry.DEFLATED
        }
        zo.putNextEntry(out)
        zo.write(data)
        zo.closeEntry()
    }

    /** Reads the whole new zip back (every file's checksum is verified on the way). Null when all is well. */
    private fun check(file: File, expected: Int, tgt: String, newBytes: ByteArray): String? {
        return try {
            var n = 0
            var same = false
            ZipInputStream(file.inputStream().buffered()).use { zi ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val e = zi.nextEntry ?: break
                    val sink = if (e.name == tgt) ByteArrayOutputStream() else null
                    while (true) {
                        val r = zi.read(buf)
                        if (r < 0) break
                        sink?.write(buf, 0, r)
                    }
                    if (sink != null) same = sink.toByteArray().contentEquals(newBytes)
                    n++
                }
            }
            when {
                n != expected -> "the new zip holds $n files, expected $expected."
                !same -> "$tgt in the new zip does not match the new file."
                else -> null
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Puts the zip in Downloads and returns where it ended up (Android adds (1) if the name is taken). */
    @Suppress("DEPRECATION")
    private fun saveToDownloads(file: File, name: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads.")
            contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            var finalName = name
            runCatching {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { finalName = it }
                }
            }
            return "Downloads/$finalName"
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val dest = File(dir, name)
        file.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return "Downloads/$name"
    }

    private fun cleanName(s: String): String {
        var n = s.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) n = "updated"
        if (!n.endsWith(".zip", ignoreCase = true)) n += ".zip"
        return n
    }

    private fun mb(bytes: Long): String = String.format(Locale.US, "%.2f MB", bytes / 1048576.0)

    private fun nameOf(u: Uri): String {
        var n: String? = null
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    private fun sizeOf(u: Uri): Long {
        var s = 0L
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) s = c.getLong(0)
            }
        }
        return s
    }

    private companion object {
        const val SRC_TMP = "zip_tool_src.zip"
        const val OUT_TMP = "zip_tool_out.zip"
    }
}
