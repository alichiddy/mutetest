package com.newagedevs.gesturevolume.ui.screens.handler_action

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.data.local.SharedPref
import com.newagedevs.gesturevolume.utils.GitHubApi
import com.newagedevs.gesturevolume.utils.GitHubBuild
import java.io.File

private val uiHandler = Handler(Looper.getMainLooper())
private fun bg(block: () -> Unit) { Thread { block() }.start() }
private fun post(block: () -> Unit) { uiHandler.post(block) }
private fun toast(c: Context, t: String) { Toast.makeText(c, t, Toast.LENGTH_LONG).show() }

private fun displayName(context: Context, uri: Uri): String? = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
}.getOrNull()

private fun kb(bytes: Long) = if (bytes >= 1024 * 1024) "%.1f MB".format(bytes / 1048576.0) else "${bytes / 1024} KB"

/** The name a workflow file must have in .github/workflows, from the name of the file on the phone. */
private fun workflowName(fileName: String): String {
    val k = fileName.lowercase()
    return when {
        "leantype" in k -> "leantype.yml"
        "blackbox" in k -> "blackbox.yml"
        else -> "gesturevolume.yml"
    }
}

/**
 * One window for everything on GitHub besides starting builds: browse the repository and download,
 * replace or delete any file in it (workflow ymls included), see and download what the releases
 * hold, and take single files (build.gradle.kts, say) out of the zips on the phone.
 * The token and repository are the ones saved in GitHub build settings.
 */
@Composable
internal fun GitHubManagerDialog(preference: SharedPref, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val token = preference.getGhToken()
    val repo = preference.getGhRepo()
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Repo files", "Releases", "My zips")
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.fillMaxWidth(0.97f),
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("GitHub manager") },
        text = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    tabs.forEachIndexed { i, t ->
                        TextButton(onClick = { tab = i }) {
                            Text(t, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                Text(repo, fontSize = 11.sp)
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (token.isEmpty()) Text("Set your GitHub token first (GitHub build settings), then open this again.")
                    else when (tab) {
                        0 -> RepoTab(context, preference, token, repo)
                        1 -> ReleasesTab(context, token, repo)
                        else -> ZipsTab(context, preference, token, repo)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun RepoTab(context: Context, preference: SharedPref, token: String, repo: String) {
    var path by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf<List<GitHubApi.Entry>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var askDelete by remember { mutableStateOf<GitHubApi.Entry?>(null) }

    fun load(p: String) {
        msg = "Reading…"
        bg {
            val r = runCatching { GitHubApi.listDir(token, repo, p) }
            post {
                r.onSuccess { entries = it; path = p; msg = if (it.isEmpty()) "Empty folder." else "" }
                    .onFailure { msg = GitHubBuild.explain(it) }
            }
        }
    }
    LaunchedEffect(Unit) { load("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val dir = path
            msg = "Uploading…"
            bg {
                val r = runCatching {
                    val name = displayName(context, uri) ?: error("That file has no name.")
                    val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    GitHubApi.putFile(token, repo, (if (dir.isEmpty()) "" else "$dir/") + name, bytes, "Upload $name from phone")
                }
                post {
                    r.onSuccess { toast(context, it); load(dir) }.onFailure { msg = GitHubBuild.explain(it) }
                }
            }
        }
    }

    Row(Modifier.horizontalScroll(rememberScrollState())) {
        TextButton(onClick = { load("") }) { Text("Root") }
        TextButton(onClick = { load(".github/workflows") }) { Text(".github/workflows") }
        TextButton(onClick = { load("sources") }) { Text("sources") }
    }
    Text("Folder: /$path", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        if (path.isNotEmpty()) TextButton(onClick = { load(path.substringBeforeLast('/', "")) }) { Text("Up") }
        TextButton(onClick = { load(path) }) { Text("Refresh") }
        TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Upload a file here") }
    }
    for (e in entries) {
        Column(Modifier.fillMaxWidth()) {
            if (e.dir) {
                TextButton(onClick = { load(e.path) }) { Text("[folder]  ${e.name}", fontSize = 14.sp) }
            } else {
                Text("${e.name}   ${kb(e.size)}", fontSize = 13.sp, modifier = Modifier.padding(start = 12.dp))
                Row {
                    TextButton(onClick = {
                        bg {
                            val r = runCatching { GitHubApi.downloadRepoFile(context, token, repo, e.path, e.name) }
                            post { toast(context, r.map { "Saved to Downloads: $it" }.getOrElse { GitHubBuild.explain(it) }) }
                        }
                    }) { Text("Download") }
                    TextButton(onClick = { askDelete = e }) { Text("Delete") }
                }
            }
        }
    }
    OutlinedButton(onClick = {
        val ymls = preference.getGhFiles("yml").filter { it.on && it.path.isNotBlank() }
        msg = "Sending the ticked workflow files…"
        bg {
            val out = StringBuilder()
            for (f in ymls) {
                val file = GitHubBuild.newest(File(f.path))
                if (file == null) { out.append("Not found: ${File(f.path).name}\n"); continue }
                val target = workflowName(file.name)
                val r = runCatching { GitHubApi.putFile(token, repo, ".github/workflows/$target", file.readBytes(), "Update $target from phone") }
                out.append(r.getOrElse { "$target: " + GitHubBuild.explain(it) }).append('\n')
            }
            if (ymls.isEmpty()) out.append("No workflow yml is ticked in GitHub build settings.")
            post { msg = out.toString().trim(); toast(context, msg); load(".github/workflows") }
        }
    }) { Text("Put my ticked ymls into .github/workflows") }
    Text(
        "This replaces the workflow files in the repository with the ticked yml files from GitHub build settings. " +
            "The token needs the Workflows permission for it.",
        fontSize = 11.sp,
    )

    askDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { askDelete = null },
            title = { Text("Delete ${e.name}?") },
            text = { Text("It is removed from the repository (${e.path}).") },
            confirmButton = {
                TextButton(onClick = {
                    askDelete = null
                    bg {
                        val r = runCatching { GitHubApi.deleteFile(token, repo, e.path, e.sha) }
                        post { toast(context, r.getOrElse { GitHubBuild.explain(it) }); load(path) }
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { askDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun ReleasesTab(context: Context, token: String, repo: String) {
    var rels by remember { mutableStateOf<List<GitHubApi.Rel>>(emptyList()) }
    var msg by remember { mutableStateOf("") }

    fun load() {
        msg = "Reading…"
        bg {
            val r = runCatching { GitHubApi.listReleases(token, repo) }
            post {
                r.onSuccess { rels = it; msg = if (it.isEmpty()) "No releases in $repo." else "" }
                    .onFailure { msg = GitHubBuild.explain(it) }
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    TextButton(onClick = { load() }) { Text("Refresh") }
    if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
    Text(
        "A zip sent for a build stays here only until the workflow has started; the workflow then removes it. " +
            "To keep your sources, turn on \"Keep a copy of every uploaded zip in the repo\" in GitHub build settings.",
        fontSize = 11.sp,
    )
    for (rel in rels) {
        Text("Release: ${rel.tag}", fontWeight = FontWeight.SemiBold)
        if (rel.assets.isEmpty()) Text("(no files)", fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp))
        for (a in rel.assets) {
            Text("${a.name}   ${kb(a.size)}\n${a.created}", fontSize = 12.sp, modifier = Modifier.padding(start = 12.dp), fontFamily = FontFamily.Monospace)
            Row {
                TextButton(onClick = {
                    bg {
                        val r = runCatching { GitHubApi.downloadAsset(context, token, repo, a.id, a.name) }
                        post { toast(context, r.map { "Saved to Downloads: $it" }.getOrElse { GitHubBuild.explain(it) }) }
                    }
                }) { Text("Download") }
                TextButton(onClick = {
                    bg {
                        val r = runCatching { GitHubApi.deleteAsset(token, repo, a.id) }
                        post { toast(context, r.getOrElse { GitHubBuild.explain(it) }); load() }
                    }
                }) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun ZipsTab(context: Context, preference: SharedPref, token: String, repo: String) {
    val zips = remember {
        preference.getGhFiles("zip").filter { it.path.isNotBlank() }
            .mapNotNull { GitHubBuild.newest(File(it.path)) }.distinctBy { it.absolutePath }
    }
    var opened by remember { mutableStateOf<File?>(null) }
    var items by remember { mutableStateOf<List<GitHubApi.ZipItem>>(emptyList()) }
    var filter by remember { mutableStateOf("build.gradle") }
    var msg by remember { mutableStateOf("") }

    Text("The zips from GitHub build settings, as they are on this phone. Open one and take any single file out of it.", fontSize = 12.sp)
    if (zips.isEmpty()) Text("No zip was found at the paths in GitHub build settings.")
    for (z in zips) {
        Text("${z.name}   ${kb(z.length())}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Row {
            TextButton(onClick = {
                opened = z; items = emptyList(); msg = "Reading…"
                bg {
                    val r = runCatching { GitHubApi.zipEntries(z) }
                    post { r.onSuccess { items = it; msg = "${it.size} files" }.onFailure { msg = GitHubBuild.explain(it) } }
                }
            }) { Text("Show files") }
            TextButton(onClick = {
                msg = "Saving ${z.name} in the repo (sources/)…"
                bg {
                    val r = runCatching { GitHubApi.putFile(token, repo, "sources/${z.name}", z.readBytes(), "Source copy of ${z.name}") }
                    post { msg = r.getOrElse { GitHubBuild.explain(it) }; toast(context, msg) }
                }
            }) { Text("Save copy in repo") }
        }
    }
    if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp)
    opened?.let { z ->
        OutlinedTextField(
            value = filter, onValueChange = { filter = it }, singleLine = true,
            label = { Text("Search in ${z.name}") }, modifier = Modifier.fillMaxWidth(),
        )
        val shown = items.filter { it.path.contains(filter.trim(), ignoreCase = true) }
        if (shown.size > 60) Text("Showing 60 of ${shown.size}: type more of the name.", fontSize = 11.sp)
        for (item in shown.take(60)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${item.path}\n${kb(item.size)}", Modifier.weight(1f), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                TextButton(onClick = {
                    bg {
                        val r = runCatching { GitHubApi.extractEntry(context, z, item) }
                        post { toast(context, r.map { n -> "Saved to Downloads: $n" }.getOrElse { e -> GitHubBuild.explain(e) }) }
                    }
                }) { Text("Download") }
            }
        }
    }
}
