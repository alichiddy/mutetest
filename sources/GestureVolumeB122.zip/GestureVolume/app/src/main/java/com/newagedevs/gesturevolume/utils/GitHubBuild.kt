package com.newagedevs.gesturevolume.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import com.newagedevs.gesturevolume.data.local.SharedPref
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.time.Instant

/**
 * One gesture that does the whole phone-to-GitHub build: uploads the project zip (and a freshly
 * saved workflow yml) to the `gv` release, starts the "Build GestureVolume" workflow, watches it,
 * downloads the finished APK to Downloads and opens the installer.
 *
 * Everything says what it is doing through [say] (the bar's message line), and every failure says
 * in plain words what to do, not a stack trace. Runs on its own thread, one build at a time.
 */
object GitHubBuild {
    // Which project is being built: A (gv release, gesturevolume.yml) or the LeanType A keyboard
    // (lt release, leantype.yml), chosen from the zip's file name.
    private class Proj(val tag: String, val workflow: String, val apk: String, val prefix: String)
    // Each build thread has its own project, so several projects can be built at the same time.
    private val cur = ThreadLocal.withInitial { Proj("gv", "gesturevolume.yml", "GestureVolume.apk", "gesturevolume") }
    private val TAG get() = cur.get()!!.tag
    private val WORKFLOW get() = cur.get()!!.workflow
    private val APK_ASSET get() = cur.get()!!.apk
    private val YML_PREFIX get() = cur.get()!!.prefix

    /** The release a file goes to when the user did not choose one: by the file's name. */
    private fun autoTag(name: String) = when {
        name.startsWith("LeanType", true) -> "lt"
        name.startsWith("blackbox", true) -> "bb"
        else -> "gv"
    }
    private fun tagOf(name: String, rel: String) = rel.trim().ifEmpty { autoTag(name) }

    private fun select(name: String, rel: String = "") {
        val tag = tagOf(name, rel)
        cur.set(
            when {
                name.startsWith("LeanType", true) -> Proj(tag, "leantype.yml", "LeanType.apk", "leantype")
                name.startsWith("blackbox", true) -> Proj(tag, "blackbox.yml", "BlackBox.apk", "blackbox")
                else -> Proj(tag, "gesturevolume.yml", "GestureVolume.apk", "gesturevolume")
            }
        )
    }

    /** The release the zip goes to; created the first time when it does not exist yet. */
    private fun releaseOf(token: String, repo: String): JSONObject = try {
        JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG"))
    } catch (e: HttpError) {
        if (e.code != 404) throw e
        JSONObject(api(token, "POST", "https://api.github.com/repos/$repo/releases",
            "{\"tag_name\":\"$TAG\",\"name\":\"$TAG\",\"prerelease\":true}"))
    }
    private const val POLL_MS = 20_000L
    private const val MAX_WAIT_MS = 20 * 60_000L
    private const val YML_FRESH_MS = 5 * 60_000L

    /** One zip being uploaded or built from this phone: its own Stop button stops only this one. */
    private class BuildJob(val key: String, val label: String) {
        @Volatile var cancel = false
        @Volatile var status = "Starting…"
    }
    class JobInfo(val key: String, val label: String, val status: String)
    private val jobs = java.util.concurrent.ConcurrentHashMap<String, BuildJob>()
    private val curJob = ThreadLocal<BuildJob?>()
    private fun jobStopped() = curJob.get()?.cancel == true
    /** The files being uploaded or built right now, for the Stop buttons in the settings window. */
    fun activeJobs(): List<JobInfo> = jobs.values.map { JobInfo(it.key, it.label, it.status) }.sortedBy { it.label }
    /** Stops one file: its upload is cut, or its build is cancelled on GitHub. The other files are not touched. */
    fun stopJob(key: String) { jobs[key]?.cancel = true }

    @Volatile private var running = false
    @Volatile private var cancelRequested = false
    /** The notification's Stop only stops watching; the build on GitHub carries on. The shortcut's second tap also cancels it there. */
    @Volatile private var watchOnly = false
    private val main = Handler(Looper.getMainLooper())

    internal class HttpError(val code: Int, val body: String) : Exception("HTTP $code")
    private open class Stop(message: String) : Exception(message)
    /** A single file was stopped from the Stop button of its own row (the others carry on). */
    private class JobStopped(message: String) : Stop(message)

    const val ACTION_STOP = "a.a.BUILD_STOP"
    const val ACTION_RESUME = "a.a.BUILD_RESUME"

    /** Where a status line goes (notification, toast, bar: the user's choice); returns (running line, final line). */
    private fun makeOutput(app: Context, sp: android.content.SharedPreferences, say: (String) -> Unit): Pair<(String) -> Unit, (String) -> Unit> {
        fun show(text: String, ongoing: Boolean) {
            val lines = record(text)
            if (sp.getBoolean("ghShowNotif", true)) notify(app, lines, ongoing)
            if (sp.getBoolean("ghShowToast", false)) main.post { runCatching { android.widget.Toast.makeText(app, text, android.widget.Toast.LENGTH_LONG).show() } }
            if (sp.getBoolean("ghShowBar", false)) main.post { say(text) }
        }
        return Pair({ t: String -> show(t, true) }, { t: String -> show(t, false) })
    }

    /** Downloads the APK of a finished run (its artifact) and installs it, like the end of a build. */
    fun installRun(context: Context, pref: SharedPref, runId: Long, runName: String, say: (String) -> Unit) {
        // Its own job, notification and Stop button: it never waits for, or touches, an upload being watched.
        if (installing) { say("An install download is already running. Stop it from its notification."); return }
        installing = true; installCancel = false; installHistory.clear()
        val app = context.applicationContext
        val sp = pref.sharedPreferences
        fun show(text: String, ongoing: Boolean) {
            val lines = synchronized(installHistory) {
                installHistory.add("${clock.format(java.util.Date())}  $text"); installHistory.takeLast(6).joinToString("\n")
            }
            DiagLog.note("install: $text")
            if (sp.getBoolean("ghShowNotif", true)) notifyInstall(app, lines, ongoing)
            if (sp.getBoolean("ghShowToast", false)) main.post { runCatching { android.widget.Toast.makeText(app, text, android.widget.Toast.LENGTH_LONG).show() } }
            if (sp.getBoolean("ghShowBar", false)) main.post { say(text) }
        }
        val out = { t: String -> show(t, true) }
        val last = { t: String -> show(t, false) }
        Thread {
            installThread.set(true)
            try {
                val token = pref.getGhToken(); val repo = pref.getGhRepo()
                out("Finding the APK of run $runName…")
                val arts = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs/$runId/artifacts")).getJSONArray("artifacts")
                val art = (0 until arts.length()).map { arts.getJSONObject(it) }.firstOrNull { !it.optBoolean("expired") }
                    ?: throw Stop("That run has no downloadable file any more (GitHub keeps them 90 days).")
                val apkName = if (runName.contains("LeanType", true)) "LeanType.apk" else "A.apk"
                out("Downloading ${art.getString("name")} (${art.getLong("size_in_bytes") / 1024} KB)…")
                val (uri, fileName) = download(app, token, "https://api.github.com/repos/$repo/actions/artifacts/${art.getLong("id")}/zip", apkName, unzip = true)
                installApk(app, uri, fileName, out)
                last("Done: $fileName")
            } catch (e: Stop) { last(e.message ?: "Stopped.") } catch (e: Throwable) { last(explain(e)) } finally { installing = false }
        }.start()
    }

    @Volatile private var installing = false
    @Volatile private var installCancel = false
    private val installHistory = ArrayList<String>()
    private val installThread = ThreadLocal<Boolean>()
    const val ACTION_STOP_INSTALL = "a.a.INSTALL_STOP"

    /** The install download's own notification (separate from the upload's). */
    private fun notifyInstall(context: Context, text: String, ongoing: Boolean) {
        runCatching {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("build", "Build from GitHub", android.app.NotificationManager.IMPORTANCE_LOW))
            val b = android.app.Notification.Builder(context, "build")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("A install download")
                .setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
            if (ongoing) b.addAction(button(context, "Stop", ACTION_STOP_INSTALL))
            nm.notify(7313, b.build())
        }
    }

    /** Copies a download, giving up quickly when the install download is stopped. */
    private fun copyStoppable(input: java.io.InputStream, out: java.io.OutputStream) {
        val buf = ByteArray(64 * 1024)
        while (true) {
            if (installThread.get() == true && installCancel) throw Stop("Stopped. Nothing was installed.")
            val n = input.read(buf); if (n < 0) break
            out.write(buf, 0, n)
        }
    }

    /** Hands the downloaded APK to the system installer (tap-to-install; no silent install). */
    private fun installApk(context: Context, uri: Uri, fileName: String, say: (String) -> Unit) {
        val info = runCatching {
            context.packageManager.getPackageArchiveInfo("/sdcard/Download/$fileName", 0)
        }.getOrNull()
        val version = info?.versionName?.let { "$it" } ?: "unknown version"
        val kb = runCatching { java.io.File("/sdcard/Download/$fileName").length() / 1024 }.getOrDefault(0L)
        val at = clock.format(java.util.Date())
        say("Ready at $at: $fileName, version $version (${kb} KB). Tap the notification to install.")
        offerInstall(context, uri, "$fileName  v$version  ready $at")
        runCatching {
            context.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    /** Cancels the workflow runs still going or waiting; returns how many. */
    private fun cancelRunning(token: String, repo: String): Int {
        var n = 0
        fetchRuns(token, repo).getOrNull()?.filter { !it.finished }?.forEach {
            runCatching { api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/${it.id}/cancel"); n++ }
        }
        return n
    }

    /** Stop watching (the notification's Stop button). The build on GitHub keeps running. */
    fun requestStop() { if (running) { watchOnly = true; cancelRequested = true } }
    fun requestStopInstall() { if (installing) installCancel = true }

    /** Receives the notification's Stop and Resume buttons. */
    class ButtonReceiver : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_STOP -> requestStop()
                ACTION_STOP_INSTALL -> requestStopInstall()
                ACTION_RESUME -> if (!running) start(context, SharedPref(context.applicationContext), resume = true) { }
            }
        }
    }

    private fun button(context: Context, label: String, action: String): android.app.Notification.Action {
        val i = Intent(action).setClass(context, ButtonReceiver::class.java)
        val pi = android.app.PendingIntent.getBroadcast(context, action.hashCode(), i, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        return android.app.Notification.Action.Builder(null as android.graphics.drawable.Icon?, label, pi).build()
    }

    /** Identity of a file as last seen: a build counts as done for it only when it finished. */
    private fun sig(f: File) = "${f.name}|${f.length()}|${f.lastModified()}"
    private fun done(sp: android.content.SharedPreferences, f: File) = sp.getString("ghDone_" + f.name.lowercase().filter { it.isLetterOrDigit() }, null) == sig(f)
    /** A file the user stopped: it is not sent again until it changes (or "Build all ticked now"). */
    private fun stopped(sp: android.content.SharedPreferences, f: File) = sp.getString("ghStop_" + f.name.lowercase().filter { it.isLetterOrDigit() }, null) == sig(f)
    private fun markStopped(sp: android.content.SharedPreferences, f: File) =
        sp.edit().putString("ghStop_" + f.name.lowercase().filter { it.isLetterOrDigit() }, sig(f)).apply()
    private fun markDone(sp: android.content.SharedPreferences, f: File) =
        sp.edit().putString("ghDone_" + f.name.lowercase().filter { it.isLetterOrDigit() }, sig(f)).apply()

    fun start(context: Context, pref: SharedPref, resume: Boolean = false, force: Boolean = false, say: (String) -> Unit) {
        DiagLog.note("build action tapped (already running=$running)")
        if (running) {
            // Tapping again stops the build (and cancels it on GitHub); tap once more to start again.
            watchOnly = false
            cancelRequested = true
            say("Stopping the build… Tap again to start it again.")
            return
        }
        running = true
        cancelRequested = false; watchOnly = false
        val app = context.applicationContext
        history.clear(); hadProblems = false
        // Where the status goes is the user's choice (GitHub build settings): notification (the
        // default), toast, bar message.
        val sp = pref.sharedPreferences
        val (out, last) = makeOutput(app, sp, say)
        if (sp.getBoolean("ghShowNotif", true) &&
            !runCatching { app.getSystemService(android.app.NotificationManager::class.java).areNotificationsEnabled() }.getOrDefault(true)) {
            say("Notifications are off. Please turn them on to see the build status.")
        }
        val zipItems = pref.getGhFiles("zip").filter { it.on && it.path.isNotBlank() }
        val ymlItems = pref.getGhFiles("yml").filter { it.on && it.path.isNotBlank() }
        val zips = zipItems.map { it.path }
        val ymls = ymlItems.map { it.path }
        val zipRel = zipItems.associate { it.path to it.rel }
        val zipDebug = zipItems.associate { it.path to it.debug }
        val ymlRel = ymlItems.associate { it.path to it.rel }
        Thread {
            try {
                if (resume) {
                    run(app, pref.getGhToken(), pref.getGhRepo(), zips.firstOrNull() ?: "", ymls, out, true, sp, zipRel[zips.firstOrNull() ?: ""] ?: "", ymlRel, zipDebug[zips.firstOrNull() ?: ""] ?: false)
                } else {
                    // Every checked zip that exists is built in turn; a missing one is just skipped.
                    val onlyChanged = !force && sp.getBoolean("ghOnlyChanged", true)
                    val allPresent = zips.filter { newest(File(it)) != null }
                    val stoppedBefore = if (force) emptyList() else allPresent.filter { stopped(sp, newest(File(it))!!) }
                    val present = allPresent.filter { it !in stoppedBefore && (!onlyChanged || !done(sp, newest(File(it))!!)) }
                    if (stoppedBefore.isNotEmpty()) out("Not sent again, you stopped it and it has not changed since: " + stoppedBefore.joinToString { newest(File(it))!!.name } + ". Save a new version of the file to send it.")
                    val unchanged = allPresent - present.toSet() - stoppedBefore.toSet()
                    if (unchanged.isNotEmpty()) out("Skipped, nothing new since the last finished build: " + unchanged.joinToString { newest(File(it))!!.name })
                    val missing = zips.filter { newest(File(it)) == null }
                    val ymlsFound = ymls.filter { newest(File(it)) != null && (force || !stopped(sp, newest(File(it))!!)) && (!onlyChanged || !done(sp, newest(File(it))!!)) }
                    out("Checked files: zips found " + (present.joinToString { newest(File(it))!!.name }.ifEmpty { "none" }) +
                        (if (missing.isNotEmpty()) "; not found: " + missing.joinToString { File(it).name } else "") +
                        "; ymls found " + (ymlsFound.joinToString { newest(File(it))!!.name }.ifEmpty { "none" }) + ".")
                    // A ticked yml whose project has no zip this time is still uploaded, on its own.
                    val projectsBuilt = present.map { tagOf(File(it).name, zipRel[it] ?: "") }.toSet()
                    val loneYmls = ymlsFound.filter { tagOf(File(it).name, ymlRel[it] ?: "") !in projectsBuilt }
                    // Everything goes up at the same time: lone ymls and every project's build.
                    val parts = present.map { newest(File(it))!!.name } + loneYmls.map { newest(File(it))!!.name }
                    if (parts.size > 1) out("Uploading ${parts.size} files at the same time: " + parts.joinToString())
                    val workers = ArrayList<Thread>()
                    val failures = java.util.Collections.synchronizedList(ArrayList<Throwable>())
                    val problems = java.util.Collections.synchronizedList(ArrayList<String>())
                    for (y in loneYmls) workers += Thread {
                        try {
                            select(File(y).name, ymlRel[y] ?: "")
                            val rel = releaseOf(pref.getGhToken(), pref.getGhRepo())
                            val f = newest(File(y))!!
                            upload(pref.getGhToken(), pref.getGhRepo(), rel.getLong("id"), "$YML_PREFIX-${f.lastModified()}.yml", "text/plain", f)
                            markDone(sp, f)
                            out("Uploaded ${f.name} to the $TAG release (it takes effect at the next build of that project).")
                        } catch (e: Throwable) {
                            if (cancelRequested && !watchOnly) newest(File(y))?.let { markStopped(sp, it) }
                            out("${File(y).name}: " + explain(e)); failures += e; problems += "${File(y).name}: " + explain(e)
                        }
                    }
                    if (present.isEmpty()) {
                        if (loneYmls.isNotEmpty()) {
                            workers.forEach { it.start() }; workers.forEach { it.join() }
                            throw Stop("Uploaded the checked workflow file(s). No zip was found, so nothing was built.")
                        }
                        if (allPresent.isNotEmpty()) throw Stop("Nothing new to build: every checked file was already built. Change a file, or use \"Build all ticked now\" in GitHub build settings.")
                        throw Stop("None of the checked files was found. Check the paths in GitHub build settings.")
                    }
                    for (z in present) workers += Thread {
                        try {
                            val label = File(z).nameWithoutExtension
                            val say2: (String) -> Unit = if (present.size > 1) { t -> out("[$label] $t") } else out
                            run(app, pref.getGhToken(), pref.getGhRepo(), z, ymls, say2, false, sp, zipRel[z] ?: "", ymlRel, zipDebug[z] ?: false)
                        } catch (e: Stop) {
                            if ((cancelRequested && !watchOnly) || e is JobStopped) newest(File(z))?.let { markStopped(sp, it) }
                            out("[${File(z).nameWithoutExtension}] ${e.message}"); failures += e; problems += "[${File(z).nameWithoutExtension}] ${e.message}"
                        }
                        catch (e: Throwable) {
                            if (cancelRequested && !watchOnly) newest(File(z))?.let { markStopped(sp, it) }
                            out("[${File(z).nameWithoutExtension}] " + explain(e)); failures += e; problems += "[${File(z).nameWithoutExtension}] " + explain(e)
                        }
                    }
                    workers.forEach { it.start() }
                    workers.forEach { it.join() }
                    // The same notification always ends with a clear result: what failed and why, or that all went well.
                    if (problems.isNotEmpty()) { hadProblems = true; last("FAILED:\n" + problems.joinToString("\n")) }
                    else last("All builds finished without errors.")
                }
            } catch (e: Stop) {
                last(e.message ?: "Stopped.")
            } catch (e: Throwable) {
                last(explain(e))
            } finally {
                running = false
            }
        }.start()
    }

    @Volatile private var hadProblems = false
    private val history = ArrayList<String>()
    private val clock = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)

    /** Adds a line to the running history and returns the last lines, one per row, for the notification. */
    @Synchronized
    private fun record(text: String): String {
        DiagLog.note("build: $text")
        history.add("${clock.format(java.util.Date())}  $text")
        return history.takeLast(8).joinToString("\n")
    }

    /** The build's status as a notification, so it can be followed with the app closed. */
    private fun notify(context: Context, text: String, ongoing: Boolean) {
        runCatching {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(
                android.app.NotificationChannel("build", "Build from GitHub", android.app.NotificationManager.IMPORTANCE_LOW)
            )
            val n = android.app.Notification.Builder(context, "build")
                .setSmallIcon(if (!ongoing && hadProblems) android.R.drawable.stat_notify_error else android.R.drawable.stat_sys_upload)
                .setContentTitle(if (!ongoing && hadProblems) "A build FAILED" else "A build")
                .setContentText(text)
                .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true)
                .addAction(if (ongoing) button(context, "Stop", ACTION_STOP) else button(context, "Resume", ACTION_RESUME))
                .build()
            nm.notify(7311, n)
        }
    }

    /** A notification that opens the installer for the downloaded APK when tapped (a background app cannot open it by itself). */
    private fun offerInstall(context: Context, uri: Uri, detail: String = "Tap to install") {
        runCatching {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val pi = android.app.PendingIntent.getActivity(context, 0, view, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            val n = android.app.Notification.Builder(context, "build")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("New A build ready")
                .setContentText(detail)
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(7312, n)
            context.startActivity(view)
        }
    }

    private fun isNetworkError(e: Throwable) =
        e is UnknownHostException || e is SocketTimeoutException || e is java.net.ConnectException ||
            e is javax.net.ssl.SSLException || e is java.net.SocketException

    internal fun explain(e: Throwable): String = when {
        isNetworkError(e) ->
            "No internet, or GitHub is unreachable. Turn on the VPN, then run Resume build status. " +
                "If the upload had not finished, run Build from GitHub again instead."
        e is HttpError -> when (e.code) {
            401 -> "GitHub refused the token (wrong or expired). Set it again in GitHub build settings."
            403 -> "The token is not allowed to do this. It needs Contents, Actions and Workflows read and write."
            404 -> "Repository or the 'gv' release was not found. Check the repo name and that the token can see it."
            422 -> "GitHub refused the upload: a file with that name already exists."
            else -> "GitHub answered with error ${e.code}: ${e.body.take(120)}"
        }
        else -> "Build stopped: ${e.javaClass.simpleName}: ${e.message}"
    }

    private fun run(
        context: Context, token: String, repo: String, zipPath: String, ymlPaths: List<String>,
        say: (String) -> Unit, resume: Boolean, sp: android.content.SharedPreferences,
        zipRel: String, ymlRels: Map<String, String>, debug: Boolean = false,
    ) {
        val key = if (resume) "resume" else File(zipPath).name
        val job = BuildJob(key, if (resume) "Resumed build" else File(zipPath).nameWithoutExtension)
        jobs[key] = job; curJob.set(job)
        val say2: (String) -> Unit = { t -> job.status = t; say(t) }
        try {
            runInner(context, token, repo, zipPath, ymlPaths, say2, resume, sp, zipRel, ymlRels, debug)
        } finally { jobs.remove(key); curJob.set(null) }
    }

    private fun runInner(
        context: Context, token: String, repo: String, zipPath: String, ymlPaths: List<String>,
        say: (String) -> Unit, resume: Boolean, sp: android.content.SharedPreferences,
        zipRel: String, ymlRels: Map<String, String>, debug: Boolean = false,
    ) {
        if (token.isEmpty()) throw Stop("Set your GitHub token first (Actions, GitHub build settings).")
        if (!Environment.isExternalStorageManager()) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            throw Stop("Allow \"all files access\" for this app, then try again.")
        }
        if (resume) select(sp.getString("ghProject", "GestureVolume") ?: "GestureVolume", sp.getString("ghProjectRel", "") ?: "")
        else {
            select(File(zipPath).name, zipRel)
            sp.edit().putString("ghProject", File(zipPath).name).putString("ghProjectRel", zipRel).apply()
        }
        val startedAt: Instant
        if (resume) {
            // Picks up the build started earlier, without uploading anything again.
            val saved = sp.getLong("ghStartedAt", 0L)
            if (saved == 0L || System.currentTimeMillis() - saved > 60 * 60_000L) {
                throw Stop("No recent build to resume. Run Build from GitHub to start a new one.")
            }
            startedAt = Instant.ofEpochMilli(saved)
            say("Resuming the build started at ${clock.format(java.util.Date(saved))}. Nothing is uploaded again.")
        } else {
        // The newest file that starts like the chosen one: a browser renames repeats to "name (1).zip".
        val zip = newest(File(zipPath)) ?: kotlin.run {
            val seen = File(zipPath).parentFile?.listFiles()?.map { it.name }.orEmpty()
            val like = seen.filter { it.contains("gesture", true) }.take(6)
            throw Stop("Zip not found: $zipPath. Folder shows ${seen.size} files; ones named like it: ${like.ifEmpty { listOf("none") }.joinToString(", ")}. Check the zip path in GitHub build settings.")
        }
        val zipName = File(zipPath).name

        checkStop()
        val release = releaseOf(token, repo)
        val releaseId = release.getLong("id")

        // Clear a stale zip of the same name and any old APK, so the finished APK is unmistakable.
        deleteAssets(token, repo, release.getJSONArray("assets")) { it == zipName || it == APK_ASSET || it.endsWith(".apk", true) }

        checkStop()
        // The project's workflow file goes up beside the zip, not after it. (leantype*.yml go with the keyboard.)
        val ymlThreads = ArrayList<Thread>()
        for (p in ymlPaths) {
            if (tagOf(File(p).name, ymlRels[p] ?: "") != TAG) continue
            val yml = newest(File(p)) ?: continue
            if (sp.getBoolean("ghOnlyChanged", true) && done(sp, yml)) continue
            ymlThreads += Thread {
                runCatching {
                    say("Uploading ${yml.name} (${yml.length() / 1024} KB)…")
                    upload(token, repo, releaseId, "$YML_PREFIX-${yml.lastModified()}.yml", "text/plain", yml)
                    markDone(sp, yml)
                    say("Workflow file uploaded too: ${yml.name}.")
                }.onFailure { say("The yml was not uploaded: " + explain(it)) }
            }.also { it.start() }
        }
        // Debug: the workflow file is not changed, so the switch travels inside the zip. A copy with a
        // `debug.flag` file added goes up; the project's Gradle script sees the file and builds the
        // "release" APK debuggable, unshrunk and with a "-debug" version name.
        val toSend = if (debug) withDebugFlag(context, zip) else zip
        say("Uploading ${zip.nameWithoutExtension}" + (if (debug) " as DEBUG" else "") + " (${toSend.length() / 1024} KB, saved ${clock.format(java.util.Date(zip.lastModified()))})…")
        try {
            upload(token, repo, releaseId, zipName, "application/zip", toSend)
        } finally { ymlThreads.forEach { it.join() }; if (toSend !== zip) toSend.delete() }
        sp.edit().putString("ghPendingZip_$TAG", zip.absolutePath).putString("ghPendingSig_$TAG", sig(zip)).apply()

        checkStop("Stopped before the build was started. The upload is on GitHub but nothing is building.")
        startedAt = Instant.now().minusSeconds(30)
        api(token, "POST", "https://api.github.com/repos/$repo/actions/workflows/$WORKFLOW/dispatches", "{\"ref\":\"main\"}")
        sp.edit().putLong("ghStartedAt", startedAt.toEpochMilli()).apply()
        say("Build started on GitHub (checking every ${POLL_MS / 1000} s)…")
        // Optional: keep the uploaded zip in the repository (sources/), because the workflow removes it from the release.
        if (sp.getBoolean("ghKeepSource", false)) {
            runCatching {
                say("Saving a copy of ${zip.name} in the repo (sources/)…")
                say(GitHubApi.putFile(token, repo, "sources/${zip.name}", zip.readBytes(), "Source copy of ${zip.name}"))
            }.onFailure { say("The source copy was not saved: " + explain(it)) }
        }
        }

        val begin = System.currentTimeMillis()
        var lastReport = 0L
        var netFails = 0
        while (true) {
            if (System.currentTimeMillis() - begin > MAX_WAIT_MS) throw Stop("The build took more than 20 minutes. Check GitHub Actions.")
            var waited = 0L
            while (waited < POLL_MS) {
                if (jobStopped()) {
                    val n = runCatching { cancelRunsOf(token, repo, WORKFLOW) }.getOrDefault(0)
                    throw JobStopped(if (n > 0) "Stopped. This build was cancelled on GitHub." else "Stopped watching this build.")
                }
                if (cancelRequested && watchOnly) throw Stop("Stopped watching. The build keeps running on GitHub.")
                if (cancelRequested) {
                    val n = runCatching { cancelRunning(token, repo) }.getOrDefault(0)
                    throw Stop(if (n > 0) "Stopped. The build was cancelled on GitHub. Tap the shortcut to build it again." else "Stopped watching. Tap the shortcut to build again.")
                }
                Thread.sleep(1000)
                waited += 1000
            }
            runCatching { failedRun(token, repo, startedAt, WORKFLOW, sp) }.getOrNull()?.let {
                throw Stop("The build $it. Open GitHub Actions to see why.")
            }
            val assets = try {
                JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$TAG")).getJSONArray("assets")
                    .also { netFails = 0 }
            } catch (e: Throwable) {
                if (!isNetworkError(e)) throw e
                // A dropped connection must not end the watching: wait and ask again.
                if (++netFails > 15) throw Stop("Lost the connection for 5 minutes. Turn on the VPN, then run Resume build status (nothing is uploaded again).")
                notify(context, record("Connection lost, trying again ($netFails)…"), true)
                continue
            }
            val apk = (0 until assets.length()).map { assets.getJSONObject(it) }.filter { it.getString("name").endsWith(".apk", true) && !Instant.parse(it.getString("created_at")).isBefore(startedAt) }
                .maxByOrNull { it.getString("created_at") }
            if (apk != null) {
                say("Build ready: ${apk.getString("name")} (${apk.getLong("size") / 1024} KB). Downloading…")
                val (uri, fileName) = download(context, token, repo, apk.getLong("id"))
                sp.getString("ghPendingZip_$TAG", null)?.let { p ->
                    val z = File(p)
                    if (z.exists() && sig(z) == sp.getString("ghPendingSig_$TAG", "")) markDone(sp, z)
                }
                installApk(context, uri, fileName, say)
                return
            }
            val minutes = (System.currentTimeMillis() - begin) / 60_000
            val secs = (System.currentTimeMillis() - begin) / 1000
            if (minutes > lastReport) { lastReport = minutes; say("Still building… $minutes min (checked at ${clock.format(java.util.Date())})") }
            else notify(context, record("Checked GitHub, ${secs / 60}:${"%02d".format(secs % 60)} in, not finished"), true)
        }
    }

    /** A copy of [zip] in the cache with an empty-ish `debug.flag` added inside the project's top folder. */
    private fun withDebugFlag(context: Context, zip: File): File {
        val out = File(context.cacheDir, "debug-" + zip.name)
        java.util.zip.ZipFile(zip).use { zf ->
            val entries = zf.entries().toList()
            val root = entries.firstOrNull { it.name.contains('/') }?.name?.substringBefore('/')?.plus("/") ?: ""
            java.util.zip.ZipOutputStream(out.outputStream().buffered()).use { zo ->
                for (e in entries) {
                    if (e.name == root + "debug.flag") continue
                    zo.putNextEntry(java.util.zip.ZipEntry(e.name).also { it.time = e.time })
                    if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zo) }
                    zo.closeEntry()
                }
                zo.putNextEntry(java.util.zip.ZipEntry(root + "debug.flag"))
                zo.write("debug".toByteArray())
                zo.closeEntry()
            }
        }
        return out
    }

    /** The most recently modified file in the same folder whose name starts like [wanted] and ends the same. */
    internal fun newest(wanted: File): File? {
        val dir = wanted.parentFile ?: return null
        val ext = wanted.extension.lowercase()
        // Letters and digits only, so "GestureVolume (3).zip", "GestureVolume-2.zip" and
        // "gesture_volume.zip" all count, wherever the browser put the number or dash.
        fun key(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        val base = key(wanted.nameWithoutExtension)
        return dir.listFiles { f ->
            f.isFile && !f.name.startsWith(".") && f.name.lowercase().contains(".$ext") && key(f.name.substringBeforeLast(".$ext", f.name)).startsWith(base)
        }?.maxByOrNull { it.lastModified() }
    }

    /** The conclusion of the run this build started, when it ended badly; null while fine or unknown. */
    private fun failedRun(token: String, repo: String, since: Instant, workflow: String, sp: android.content.SharedPreferences): String? {
        val runs = JSONObject(
            api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?event=workflow_dispatch&per_page=10")
        ).getJSONArray("workflow_runs")
        for (i in 0 until runs.length()) {
            val r = runs.getJSONObject(i)
            if (Instant.parse(r.getString("created_at")).isBefore(since)) continue
            if (!r.optString("path", "").endsWith(workflow)) continue
            val num = r.optInt("run_number")
            rememberRun(sp, r.optString("name"), num, r.optString("conclusion").ifEmpty { r.optString("status") }, r.optString("created_at").replace('T', ' ').removeSuffix("Z"))
            return when (val c = r.optString("conclusion", "")) {
                "failure", "cancelled", "timed_out" -> (if (c == "failure") "failed" else c.replace('_', ' ')) + " (run #$num)"
                else -> null
            }
        }
        return null
    }

    private fun deleteAssets(token: String, repo: String, assets: JSONArray, match: (String) -> Boolean) {
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (match(a.getString("name"))) {
                api(token, "DELETE", "https://api.github.com/repos/$repo/releases/assets/${a.getLong("id")}")
            }
        }
    }

    internal fun open(url: String, method: String, token: String?, accept: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = false
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "A-app")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            if (token != null) setRequestProperty("Authorization", "Bearer $token")
        }

    internal fun api(token: String, method: String, url: String, body: String? = null): String {
        val c = open(url, method, token, "application/vnd.github+json")
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw HttpError(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    /**
     * Deletes every workflow run of the repository: failed, successful and cancelled ones. A run
     * still going is cancelled first and left for the next time. Blocking: use a background
     * thread. Returns a sentence to show.
     */
    fun deleteAllRuns(token: String, repo: String, progress: (String) -> Unit = {}): String {
        if (token.isEmpty()) return "Set your GitHub token first."
        var deleted = 0
        var busy = 0
        return try {
            for (round in 0 until 30) {
                val runs = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=100")).getJSONArray("workflow_runs")
                if (runs.length() == 0) break
                var progressMade = false
                for (i in 0 until runs.length()) {
                    val r = runs.getJSONObject(i)
                    val id = r.getLong("id")
                    if (r.optString("status") != "completed") {
                        runCatching { api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/$id/cancel") }
                        busy++
                        continue
                    }
                    api(token, "DELETE", "https://api.github.com/repos/$repo/actions/runs/$id")
                    deleted++; progressMade = true
                    if (deleted % 10 == 0) progress("Deleted $deleted…")
                }
                if (!progressMade) break
            }
            "Deleted $deleted workflow runs." + if (busy > 0) " $busy still running: cancelled, delete them again in a minute." else ""
        } catch (e: HttpError) {
            if (e.code == 403 || e.code == 404) "GitHub refused (${e.code}). The token needs the Actions: read and write permission for $repo."
            else "GitHub answered with error ${e.code}. Deleted $deleted so far."
        } catch (e: Throwable) {
            "Stopped after $deleted: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    class RunInfo(val id: Long, val number: Int, val name: String, val state: String, val created: String, val finished: Boolean, val path: String = "")

    /** The repository's newest 100 workflow runs with their status (blocking; background thread). */
    fun fetchRuns(token: String, repo: String, sp: android.content.SharedPreferences? = null): Result<List<RunInfo>> = runCatching {
        if (token.isEmpty()) error("Set your GitHub token first.")
        val runs = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=100")).getJSONArray("workflow_runs")
        (0 until runs.length()).map {
            val r = runs.getJSONObject(it)
            val status = r.optString("status")
            RunInfo(
                r.getLong("id"), r.optInt("run_number"), r.optString("name"),
                r.optString("conclusion").ifEmpty { status },
                r.optString("created_at").replace('T', ' ').removeSuffix("Z"), status == "completed",
                r.optString("path", ""),
            )
        }.also { list -> if (sp != null) list.distinctBy { it.name }.forEach { rememberRun(sp, it.name, it.number, it.state, it.created) } }
    }

    /** Keeps the newest run number of each workflow on the phone, so it can still be shown when GitHub's list is empty. */
    internal fun rememberRun(sp: android.content.SharedPreferences, name: String, number: Int, state: String, created: String) {
        if (name.isBlank() || number <= 0) return
        runCatching {
            val o = JSONObject(sp.getString("ghLastRuns", "{}") ?: "{}")
            val old = o.optJSONObject(name)
            if (old != null && old.optInt("n") > number) return
            o.put(name, JSONObject().put("n", number).put("s", state).put("t", created))
            sp.edit().putString("ghLastRuns", o.toString()).apply()
        }
    }

    /** One line per workflow: its last known build number, result and time. */
    fun lastRuns(sp: android.content.SharedPreferences): List<String> = runCatching {
        val o = JSONObject(sp.getString("ghLastRuns", "{}") ?: "{}")
        o.keys().asSequence().sorted().map { k -> val v = o.getJSONObject(k); "$k  #${v.optInt("n")}  ${v.optString("s")}  ${v.optString("t")}" }.toList()
    }.getOrDefault(emptyList())

    /**
     * A readable error report for one failed run: a short summary (run number, failed job and step,
     * every compiler error with its file and line, Gradle's own message), then the end of the log.
     * Blocking: call on a worker thread.
     */
    fun fetchFailureLog(token: String, repo: String, runId: Long, runNumber: Int = 0): String {
        if (token.isBlank()) return "Set your GitHub token first."
        return try {
            val jobs = JSONObject(
                api(token, "GET", "https://api.github.com/repos/$repo/actions/runs/$runId/jobs?per_page=100")
            ).getJSONArray("jobs")
            val failedJobs = (0 until jobs.length()).map { jobs.getJSONObject(it) }.filter {
                val c = it.optString("conclusion")
                c == "failure" || c == "timed_out" || c == "action_required"
            }
            if (failedJobs.isEmpty()) {
                return "No failed jobs were returned for this run. It may have failed before a job started, or the token may not have permission to read Actions."
            }
            val report = StringBuilder("GitHub Actions build error, repo $repo, run" + (if (runNumber > 0) " #$runNumber" else "") + " (id $runId)\n")
            for (job in failedJobs) {
                if (report.length >= 40_000) break
                val jobName = job.optString("name", "job")
                report.append("\nJob: $jobName (${job.optString("conclusion")})\n")
                val steps = job.optJSONArray("steps")
                if (steps != null) for (i in 0 until steps.length()) {
                    val st = steps.getJSONObject(i)
                    if (st.optString("conclusion") == "failure") report.append("Failed step: ").append(st.optString("name")).append('\n')
                }
                report.append(condenseLog(jobLogText(token, repo, job.getLong("id"))))
            }
            report.toString()
        } catch (e: HttpError) {
            if (e.code == 403 || e.code == 404) "GitHub refused (${e.code}). Check that the token has Actions: read permission for $repo."
            else "GitHub returned error ${e.code} while reading the build logs."
        } catch (e: Throwable) {
            "Could not read build logs: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** The plain text of one job's log (GitHub redirects to it; a ZIP is unpacked just in case). */
    private fun jobLogText(token: String, repo: String, jobId: Long): String {
        val req = open("https://api.github.com/repos/$repo/actions/jobs/$jobId/logs", "GET", token, "application/vnd.github+json")
        val url: String
        try {
            val code = req.responseCode
            if (code !in 300..399) throw HttpError(code, (req.errorStream ?: req.inputStream)?.bufferedReader()?.use { it.readText() } ?: "")
            url = req.getHeaderField("Location") ?: error("GitHub returned no download address for the log.")
        } finally { req.disconnect() }
        val conn = open(url, "GET", null, "*/*")
        try {
            if (conn.responseCode !in 200..299) throw HttpError(conn.responseCode, "Could not download the job log.")
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192); var total = 0
            conn.inputStream.use { inp ->
                while (total < 20 * 1024 * 1024) { val n = inp.read(buf); if (n < 0) break; out.write(buf, 0, n); total += n }
            }
            val raw = out.toByteArray()
            if (raw.size >= 4 && raw[0] == 0x50.toByte() && raw[1] == 0x4b.toByte()) {
                val sb = StringBuilder()
                java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(raw)).use { z ->
                    while (true) { val e = z.nextEntry ?: break; if (!e.isDirectory) sb.append(z.readBytes().toString(Charsets.UTF_8)).append('\n') }
                }
                return sb.toString()
            }
            return String(raw, Charsets.UTF_8)
        } finally { conn.disconnect() }
    }

    /** Takes the noise out of a build log and puts what matters first: the errors, Gradle's message, then the log's end. */
    private fun condenseLog(text: String): String {
        val stamp = Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ?")
        val dir = Regex("file:///home/runner/work/[^/]+/[^/]+/")
        val lines = text.lines().map { dir.replace(stamp.replace(it, "").trimEnd(), "") }.filter { it.isNotBlank() }
        val noise = Regex("^(WARNING:|The current default|It will be removed|To suppress this warning|> Task :\\S+( UP-TO-DATE| NO-SOURCE)?$|gradle/actions:)")
        val kept = lines.filter { !noise.containsMatchIn(it) }
        val errs = kept.filter { it.startsWith("e: ") || it.startsWith("error:") || it.contains(": error:") || it.startsWith("> Task") && it.endsWith("FAILED") }
        val sb = StringBuilder()
        if (errs.isNotEmpty()) {
            sb.append("\nERRORS (${errs.size}; the first ones are the cause, the rest usually follow from them):\n")
            errs.take(40).forEach { sb.append(it.take(400)).append('\n') }
            if (errs.size > 40) sb.append("… and ${errs.size - 40} more\n")
        }
        val w = kept.indexOfFirst { it.contains("What went wrong") }
        if (w >= 0) { sb.append("\nGRADLE SAYS:\n"); kept.subList(w, minOf(kept.size, w + 10)).forEach { sb.append(it.take(300)).append('\n') } }
        sb.append("\nEND OF LOG (last ${minOf(kept.size, 60)} lines, noise removed):\n")
        kept.takeLast(60).forEach { sb.append(it.take(300)).append('\n') }
        return sb.toString()
    }

    /** Stops one workflow run on GitHub (a run still waiting or building). */
    fun cancelRun(token: String, repo: String, id: Long): String = try {
        api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/$id/cancel"); "Stopping that run on GitHub…"
    } catch (e: Throwable) { explain(e) }

    /** Cancels the unfinished runs of one workflow file only; returns how many. */
    private fun cancelRunsOf(token: String, repo: String, workflow: String): Int {
        var n = 0
        fetchRuns(token, repo).getOrNull()?.filter { !it.finished && it.path.endsWith(workflow) }?.forEach {
            runCatching { api(token, "POST", "https://api.github.com/repos/$repo/actions/runs/${it.id}/cancel"); n++ }
        }
        return n
    }

    /** Deletes only the runs given (finished ones; a run still going is never touched). */
    fun deleteRuns(token: String, repo: String, ids: List<Long>): String {
        var deleted = 0; var failed = 0
        for (id in ids) {
            try { api(token, "DELETE", "https://api.github.com/repos/$repo/actions/runs/$id"); deleted++ } catch (e: Throwable) { failed++ }
        }
        return "Deleted $deleted workflow runs." + if (failed > 0) " $failed could not be deleted (still running, or the token lacks Actions write)." else ""
    }

    /** A readable list of the repository's workflow runs (newest first), to check what is there. */
    fun listRuns(token: String, repo: String): String {
        if (token.isEmpty()) return "Set your GitHub token first."
        return try {
            val o = JSONObject(api(token, "GET", "https://api.github.com/repos/$repo/actions/runs?per_page=50"))
            val total = o.optInt("total_count", 0)
            val runs = o.getJSONArray("workflow_runs")
            if (total == 0 || runs.length() == 0) return "No workflow runs in $repo."
            val sb = StringBuilder("$total workflow runs in $repo")
            if (total > runs.length()) sb.append(" (newest ${runs.length()} shown)")
            sb.append(":\n\n")
            for (i in 0 until runs.length()) {
                val r = runs.getJSONObject(i)
                val state = r.optString("conclusion").ifEmpty { r.optString("status") }
                val mark = when (state) { "success" -> "OK"; "failure" -> "FAILED"; "cancelled" -> "CANCELLED"; else -> state.uppercase() }
                sb.append("#${r.optInt("run_number")}  $mark  ${r.optString("name")}  ${r.optString("created_at").replace('T', ' ').removeSuffix("Z")}\n")
            }
            sb.toString()
        } catch (e: HttpError) {
            if (e.code == 403 || e.code == 404) "GitHub refused (${e.code}). Check the token and the repository name; the token needs Actions: read."
            else "GitHub answered with error ${e.code}."
        } catch (e: Throwable) {
            "Could not read: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun checkStop(text: String = "Stopped before anything was built.") {
        if (jobStopped()) throw JobStopped("Stopped by you before anything was built.")
        if (cancelRequested) throw Stop(text)
    }

    private fun upload(token: String, repo: String, releaseId: Long, name: String, type: String, file: File) {
        val url = "https://uploads.github.com/repos/$repo/releases/$releaseId/assets?name=" + Uri.encode(name)
        val c = open(url, "POST", token, "application/vnd.github+json")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", type)
            c.setFixedLengthStreamingMode(file.length())
            c.outputStream.use { out ->
                file.inputStream().use { input ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        // Stop pressed: cut the connection, GitHub throws the half file away.
                        if (jobStopped()) { c.disconnect(); throw JobStopped("Stopped while uploading. Nothing was built.") }
                        if (cancelRequested) { c.disconnect(); throw Stop("Stopped while uploading. Nothing was built.") }
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            val code = c.responseCode
            if (code != 201) {
                throw HttpError(code, (c.errorStream ?: c.inputStream)?.bufferedReader()?.use { it.readText() } ?: "")
            }
        } finally {
            c.disconnect()
        }
    }

    /** Downloads the asset into Downloads/A.apk (the token is not sent to the storage host). */
    private fun download(context: Context, token: String, repo: String, assetId: Long): Pair<Uri, String> =
        download(context, token, "https://api.github.com/repos/$repo/releases/assets/$assetId", "A.apk", unzip = false)

    /** [unzip]: the address gives a zip (a workflow artifact); its APK is what is saved. */
    private fun download(context: Context, token: String, apiUrl: String, saveAs: String, unzip: Boolean): Pair<Uri, String> {
        // The artifact zip endpoint refuses "octet-stream" (error 415); it wants the plain GitHub type.
        val first = open(apiUrl, "GET", token, if (unzip) "application/vnd.github+json" else "application/octet-stream")
        val location: String
        try {
            val code = first.responseCode
            if (code !in 300..399) throw HttpError(code, "")
            location = first.getHeaderField("Location") ?: throw Stop("GitHub gave no download address.")
        } finally {
            first.disconnect()
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, saveAs)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Stop("Could not create $saveAs in Downloads.")
        val c = open(location, "GET", null, "application/octet-stream")
        try {
            c.readTimeout = 120_000
            if (c.responseCode !in 200..299) throw HttpError(c.responseCode, "")
            if (!unzip) {
                resolver.openOutputStream(uri)!!.use { out -> c.inputStream.use { copyStoppable(it, out) } }
            } else {
                java.util.zip.ZipInputStream(c.inputStream).use { zin ->
                    var found = false
                    while (true) {
                        val e = zin.nextEntry ?: break
                        if (!e.isDirectory && e.name.endsWith(".apk", true)) {
                            resolver.openOutputStream(uri)!!.use { out -> copyStoppable(zin, out) }
                            found = true; break
                        }
                    }
                    if (!found) throw Stop("The downloaded file held no APK.")
                }
            }
        } finally {
            c.disconnect()
        }
        val name = resolver.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: saveAs
        return uri to name
    }
}

/**
 * What the GitHub manager window does besides building: look through the repository, download or
 * replace any file in it (including the workflow yml files), look at the releases' files, and
 * take single files out of a zip on the phone. Everything blocks, so call it from a background thread.
 */
object GitHubApi {
    class Entry(val name: String, val path: String, val dir: Boolean, val size: Long, val sha: String)
    class Asset(val id: Long, val name: String, val size: Long, val created: String)
    class Rel(val tag: String, val assets: List<Asset>)
    class ZipItem(val path: String, val size: Long, val saveAs: String)

    private const val API = "https://api.github.com/repos"
    private const val MAX_PUT = 90L * 1024 * 1024

    private fun enc(path: String) =
        path.split('/').filter { it.isNotEmpty() }.joinToString("/") { Uri.encode(it) }

    private fun contentsUrl(repo: String, path: String): String {
        val e = enc(path)
        return "$API/$repo/contents" + if (e.isEmpty()) "" else "/$e"
    }

    /** The files and folders inside [path] ("" is the root), folders first. */
    fun listDir(token: String, repo: String, path: String): List<Entry> {
        if (token.isEmpty()) error("Set your GitHub token first.")
        val arr = JSONArray(GitHubBuild.api(token, "GET", contentsUrl(repo, path)))
        val list = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Entry(o.getString("name"), o.getString("path"), o.getString("type") == "dir", o.optLong("size"), o.optString("sha"))
        }
        return list.sortedWith(compareBy({ !it.dir }, { it.name.lowercase() }))
    }

    /** The id of the file's current version, or null when the file does not exist yet. */
    private fun shaOf(token: String, repo: String, path: String): String? = try {
        JSONObject(GitHubBuild.api(token, "GET", contentsUrl(repo, path))).optString("sha").ifEmpty { null }
    } catch (e: GitHubBuild.HttpError) {
        if (e.code == 404) null else throw e
    }

    /** Adds the file at [path], or replaces it when it is there already. Returns a sentence to show. */
    fun putFile(token: String, repo: String, path: String, bytes: ByteArray, message: String): String {
        if (bytes.size > MAX_PUT) error("That file is too big for GitHub's file upload (90 MB).")
        val sha = shaOf(token, repo, path)
        val body = JSONObject().put("message", message).put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
        if (sha != null) body.put("sha", sha)
        GitHubBuild.api(token, "PUT", contentsUrl(repo, path), body.toString())
        return (if (sha == null) "Added " else "Replaced ") + path
    }

    fun deleteFile(token: String, repo: String, path: String, sha: String): String {
        val body = JSONObject().put("message", "Delete $path from phone").put("sha", sha)
        GitHubBuild.api(token, "DELETE", contentsUrl(repo, path), body.toString())
        return "Deleted $path"
    }

    /** Saves a repository file into Downloads under [saveAs]. Returns the name it got. */
    fun downloadRepoFile(context: Context, token: String, repo: String, path: String, saveAs: String): String =
        download(context, token, contentsUrl(repo, path), "application/vnd.github.raw", saveAs)

    /** The releases (newest first) with the files each one holds. */
    fun listReleases(token: String, repo: String): List<Rel> {
        if (token.isEmpty()) error("Set your GitHub token first.")
        val arr = JSONArray(GitHubBuild.api(token, "GET", "$API/$repo/releases?per_page=30"))
        return (0 until arr.length()).map {
            val r = arr.getJSONObject(it)
            val a = r.optJSONArray("assets") ?: JSONArray()
            Rel(r.optString("tag_name"), (0 until a.length()).map { i ->
                val x = a.getJSONObject(i)
                Asset(x.getLong("id"), x.getString("name"), x.optLong("size"), x.optString("created_at").replace('T', ' ').removeSuffix("Z"))
            })
        }
    }

    fun downloadAsset(context: Context, token: String, repo: String, id: Long, saveAs: String): String =
        download(context, token, "$API/$repo/releases/assets/$id", "application/octet-stream", saveAs)

    fun deleteAsset(token: String, repo: String, id: Long): String {
        GitHubBuild.api(token, "DELETE", "$API/$repo/releases/assets/$id")
        return "Deleted"
    }

    /** The files inside a zip on the phone. Names that appear twice (two build.gradle.kts) get their folder in the saved name. */
    fun zipEntries(file: File): List<ZipItem> {
        val names = java.util.zip.ZipFile(file).use { z ->
            z.entries().toList().filter { !it.isDirectory }.map { it.name to it.size }
        }
        val count = names.groupingBy { it.first.substringAfterLast('/') }.eachCount()
        return names.map { (n, size) ->
            val last = n.substringAfterLast('/')
            val parent = n.substringBeforeLast('/', "").substringAfterLast('/')
            ZipItem(n, size, if ((count[last] ?: 0) > 1 && parent.isNotEmpty()) "${parent}_$last" else last)
        }.sortedBy { it.path.lowercase() }
    }

    /** Takes one file out of the zip into Downloads. Returns the name it got. */
    fun extractEntry(context: Context, file: File, item: ZipItem): String =
        java.util.zip.ZipFile(file).use { z ->
            val e = z.getEntry(item.path) ?: error("${item.path} is not in the zip.")
            save(context, item.saveAs) { out -> z.getInputStream(e).use { it.copyTo(out) } }
        }

    /** Streams a GitHub address into Downloads, following GitHub's redirect without sending the token on. */
    private fun download(context: Context, token: String, url: String, accept: String, saveAs: String): String {
        val first = GitHubBuild.open(url, "GET", token, accept)
        var conn = first
        try {
            var code = first.responseCode
            if (code in 300..399) {
                val loc = first.getHeaderField("Location") ?: error("GitHub gave no download address.")
                first.disconnect()
                conn = GitHubBuild.open(loc, "GET", null, "application/octet-stream")
                code = conn.responseCode
            }
            if (code !in 200..299) throw GitHubBuild.HttpError(code, "")
            conn.readTimeout = 120_000
            return save(context, saveAs) { out -> conn.inputStream.use { it.copyTo(out) } }
        } finally {
            conn.disconnect()
        }
    }

    /** Writes into Downloads. "octet-stream" keeps Android from adding ".txt" to names like build.gradle.kts. */
    private fun save(context: Context, name: String, write: (OutputStream) -> Unit): String {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("Could not create $name in Downloads.")
        try {
            resolver.openOutputStream(uri)!!.use { write(it) }
        } catch (e: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return resolver.query(uri, arrayOf(MediaStore.Downloads.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: name
    }
}
