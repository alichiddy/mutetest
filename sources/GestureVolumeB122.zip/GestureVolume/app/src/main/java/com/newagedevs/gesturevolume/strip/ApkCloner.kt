package com.newagedevs.gesturevolume.strip

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * Makes a copy of this very app with every current setting (the strip included) baked in as its defaults.
 *
 * An APK is a zip: the installed one is copied entry by entry (stored entries kept stored and
 * aligned, as Android requires), `assets/strip_default.json` is replaced, and the copy is signed
 * with the same key the CI builds use, so it installs over this app as an update and keeps every
 * setting, and on a phone without the app it simply starts with this strip.
 *
 * Runs only when asked, from the settings screen. Nothing here is loaded by the overlay.
 */
object ApkCloner {

    private const val ASSET = "assets/strip_default.json"
    private const val ASSET_ALL = "assets/settings_default.json"

    /** Returns a short message for the screen: where the file went, or why it failed. */
    /** Pass null for a part to leave whatever the copied APK already carries for it. */
    fun make(context: Context, name: String, stripJson: String?, settingsJson: String?): String = try {
        val cache = File(context.cacheDir, "clone").apply { deleteRecursively(); mkdirs() }
        val unsigned = File(cache, "unsigned.apk")
        val signed = File(cache, "signed.apk")
        rewrite(File(context.applicationInfo.sourceDir), unsigned, stripJson, settingsJson)
        sign(context, unsigned, signed)
        // Checked before it is offered for install, so a bad file says why instead of "corrupt".
        val check = com.android.apksig.ApkVerifier.Builder(signed).build().verify()
        if (!check.isVerified) {
            error("signature check failed: " + check.errors.joinToString { it.toString() }.take(300))
        }
        checkLayout(signed)?.let { error(it) }
        if (context.packageManager.getPackageArchiveInfo(signed.absolutePath, 0) == null) {
            error("Android cannot read the new file (it parses as an invalid package)")
        }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("could not create the file in Downloads")
        resolver.openOutputStream(uri)!!.use { out -> signed.inputStream().use { it.copyTo(out) } }
        cache.deleteRecursively()
        "Saved in Downloads as $name"
    } catch (e: Throwable) {
        com.newagedevs.gesturevolume.utils.DiagLog.e("Make APK", e)
        "Failed: ${e.javaClass.simpleName}: ${e.message}"
    }

    /**
     * What the system's installer insists on and a plain signature check does not: resources.arsc
     * stored and 4-byte aligned, stored native libraries page aligned, no duplicate names. Returns
     * the first problem as text, or null when the layout is fine.
     */
    private fun checkLayout(file: File): String? = runCatching {
        java.io.RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val tailLen = minOf(len, 70000L).toInt()
            val tail = ByteArray(tailLen)
            raf.seek(len - tailLen); raf.readFully(tail)
            fun i32(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)
            fun i16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
            var eocd = -1
            for (p in tailLen - 22 downTo 0) if (i32(tail, p) == 0x06054b50) { eocd = p; break }
            if (eocd < 0) return@use "no zip directory at the end of the new file"
            val count = i16(tail, eocd + 10)
            val cdSize = i32(tail, eocd + 12)
            val cdOff = i32(tail, eocd + 16).toLong() and 0xFFFFFFFFL
            val cd = ByteArray(cdSize); raf.seek(cdOff); raf.readFully(cd)
            val seen = HashSet<String>()
            var p = 0
            repeat(count) {
                if (i32(cd, p) != 0x02014b50) return@use "zip directory is damaged"
                val method = i16(cd, p + 10)
                val nameLen = i16(cd, p + 28); val extraLen = i16(cd, p + 30); val commentLen = i16(cd, p + 32)
                val lho = i32(cd, p + 42).toLong() and 0xFFFFFFFFL
                val name = String(cd, p + 46, nameLen, Charsets.UTF_8)
                if (!seen.add(name)) return@use "duplicate entry $name"
                val lh = ByteArray(30); raf.seek(lho); raf.readFully(lh)
                val dataOff = lho + 30 + i16(lh, 26) + i16(lh, 28)
                if (name == "resources.arsc" && (method != 0 || dataOff % 4 != 0L)) return@use "resources.arsc is compressed or misaligned (method $method, offset ${dataOff % 4})"
                if (name.endsWith(".so") && method == 0 && dataOff % 4096 != 0L) return@use "$name is stored but not page-aligned"
                p += 46 + nameLen + extraLen + commentLen
            }
            null
        }
    }.getOrElse { "layout check failed: ${it.message}" }

    /** Our own zip writer, so every byte offset is known and alignment cannot drift. */
    private class ZipOut(file: File) : AutoCloseable {
        private val out = java.io.BufferedOutputStream(file.outputStream(), 1 shl 16)
        var pos = 0L
            private set
        private class Rec(val name: ByteArray, val method: Int, val crc: Long, val csize: Long, val usize: Long, val offset: Long)
        private val recs = ArrayList<Rec>()

        private fun w(b: ByteArray) { out.write(b); pos += b.size }
        private fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
        private fun le32(v: Long) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())

        /** [align] > 0: the data starts at a multiple of it (stored entries only). */
        fun add(name: String, data: ByteArray, stored: Boolean, align: Int) {
            val nameBytes = name.toByteArray(Charsets.UTF_8)
            val crc = java.util.zip.CRC32().apply { update(data) }.value
            val body: ByteArray = if (stored) data else {
                val d = java.util.zip.Deflater(6, true)
                val bos = java.io.ByteArrayOutputStream(data.size / 2 + 64)
                java.util.zip.DeflaterOutputStream(bos, d).use { it.write(data) }
                d.end(); bos.toByteArray()
            }
            // A stored entry that would not shrink is kept stored; a deflated one that grew is too.
            val useStored = stored || body.size >= data.size
            val payload = if (useStored) data else body
            // A deflated entry that fell back to stored (small, incompressible) still needs its alignment.
            val al = if (align > 0) align else if (name.endsWith(".so")) 16384 else if (name == "resources.arsc") 4 else 0
            var extra = ByteArray(0)
            if (useStored && al > 0) {
                val base = pos + 30 + nameBytes.size
                var need = ((al - base % al) % al).toInt()
                if (need in 1..3) need += al
                if (need > 0) {
                    extra = ByteArray(need)
                    extra[0] = 0x35; extra[1] = 0xD9.toByte()
                    extra[2] = ((need - 4) and 0xFF).toByte(); extra[3] = (((need - 4) shr 8) and 0xFF).toByte()
                }
            }
            val method = if (useStored) 0 else 8
            val offset = pos
            w(le32(0x04034b50L)); w(le16(20)); w(le16(0x0800)); w(le16(method))
            w(le16(0)); w(le16(0x2821))                 // a fixed time and date
            w(le32(crc)); w(le32(payload.size.toLong())); w(le32(data.size.toLong()))
            w(le16(nameBytes.size)); w(le16(extra.size)); w(nameBytes); w(extra)
            w(payload)
            recs += Rec(nameBytes, method, crc, payload.size.toLong(), data.size.toLong(), offset)
        }

        override fun close() {
            val cdStart = pos
            for (r in recs) {
                w(le32(0x02014b50L)); w(le16(20)); w(le16(20)); w(le16(0x0800)); w(le16(r.method))
                w(le16(0)); w(le16(0x2821))
                w(le32(r.crc)); w(le32(r.csize)); w(le32(r.usize))
                w(le16(r.name.size)); w(le16(0)); w(le16(0)); w(le16(0)); w(le16(0)); w(le32(0)); w(le32(r.offset))
                w(r.name)
            }
            val cdSize = pos - cdStart
            w(le32(0x06054b50L)); w(le16(0)); w(le16(0)); w(le16(recs.size)); w(le16(recs.size))
            w(le32(cdSize)); w(le32(cdStart)); w(le16(0))
            out.flush(); out.close()
        }
    }

    private fun rewrite(source: File, target: File, json: String?, settingsJson: String?) {
        ZipFile(source).use { zip ->
            ZipOut(target).use { out ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    val name = e.name
                    if (e.isDirectory || isSignatureFile(name)) continue
                    if ((name == ASSET && json != null) || (name == ASSET_ALL && settingsJson != null)) continue
                    val data = zip.getInputStream(e).use { it.readBytes() }
                    // Stored stays stored (and aligned: 16 KB for native libraries, 4 bytes for the rest);
                    // resources.arsc must be stored whatever the source did.
                    val stored = e.method == ZipEntry.STORED || name == "resources.arsc"
                    val align = when { !stored -> 0; name.endsWith(".so") -> 16384; else -> 4 }
                    out.add(name, data, stored, align)
                }
                if (json != null) out.add(ASSET, json.toByteArray(Charsets.UTF_8), stored = false, align = 0)
                if (settingsJson != null) out.add(ASSET_ALL, settingsJson.toByteArray(Charsets.UTF_8), stored = false, align = 0)
            }
        }
    }

    private fun isSignatureFile(name: String): Boolean {
        if (!name.startsWith("META-INF/")) return false
        val n = name.uppercase()
        return n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") ||
            n.endsWith(".DSA") || n.endsWith(".EC")
    }

    private fun sign(context: Context, input: File, output: File) {
        val keyBytes = context.assets.open("signer_key.der").use { it.readBytes() }
        val certBytes = context.assets.open("signer_cert.der").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(certBytes.inputStream()) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("debug", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setV4SigningEnabled(false)
            .build()
            .sign()
    }
}
