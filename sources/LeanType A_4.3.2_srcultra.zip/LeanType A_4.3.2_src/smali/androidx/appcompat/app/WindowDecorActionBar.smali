.class public final Landroidx/appcompat/app/WindowDecorActionBar;
.super Landroidx/appcompat/app/ActionBar;
.source "WindowDecorActionBar.java"

# interfaces
.implements Landroidx/appcompat/widget/ActionBarOverlayLayout$ActionBarVisibilityCallback;


# instance fields
.field public mHiddenBySystem:Z


# virtual methods
.method public final updateVisibility(Z)V
    .locals 0

    const/4 p0, 0x0

    throw p0
.end method
