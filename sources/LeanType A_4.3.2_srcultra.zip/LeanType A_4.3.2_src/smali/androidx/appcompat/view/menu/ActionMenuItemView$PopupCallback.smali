.class public abstract Landroidx/appcompat/view/menu/ActionMenuItemView$PopupCallback;
.super Ljava/lang/Object;
.source "ActionMenuItemView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/ActionMenuItemView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "PopupCallback"
.end annotation
