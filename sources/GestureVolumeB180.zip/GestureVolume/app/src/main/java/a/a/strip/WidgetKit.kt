package a.a.strip

import android.annotation.SuppressLint
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.AdapterView
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONObject

/** How one widget behaves when it floats over other apps. Saved per widget. */
data class FloatCfg(
    val name: String = "",
    val wDp: Int = 0,            // 0 = the widget's own size
    val hDp: Int = 0,
    val x: Int = Int.MIN_VALUE,  // last position in px; MIN_VALUE = not moved yet
    val y: Int = Int.MIN_VALUE,
    val opacity: Int = 100,      // percent
    val bg: Int = 1,             // 0 none, 1 dark card, 2 light card
    val radius: Int = 16,        // dp
    val handle: Boolean = true,  // the bar to drag it by, with the close button
    val lock: Boolean = false,   // no moving or resizing
    val remember: Boolean = true,
    val snap: Boolean = true,
    val autoClose: Int = 0,      // seconds without a touch; 0 = stay
    val outside: Boolean = true, // close when you tap outside it
    val afterTap: Int = 0,       // close this many seconds after a tap inside it; 0 = off
    val startAt: Int = 0,        // first position: 0 centre, 1 top, 2 bottom, 3 left, 4 right
) {
    fun toJson(): String {
        val o = JSONObject()
            .put("n", name).put("w", wDp).put("h", hDp).put("o", opacity).put("bg", bg).put("r", radius)
            .put("hd", handle).put("lk", lock).put("rm", remember).put("sn", snap)
            .put("ac", autoClose).put("os", outside).put("at", afterTap).put("st", startAt)
        if (x != Int.MIN_VALUE && y != Int.MIN_VALUE) o.put("x", x).put("y", y)
        return o.toString()
    }

    companion object {
        fun from(json: String?): FloatCfg {
            if (json.isNullOrBlank()) return FloatCfg()
            return runCatching {
                val o = JSONObject(json)
                FloatCfg(
                    name = o.optString("n"),
                    wDp = o.optInt("w", 0),
                    hDp = o.optInt("h", 0),
                    x = if (o.has("x")) o.optInt("x") else Int.MIN_VALUE,
                    y = if (o.has("y")) o.optInt("y") else Int.MIN_VALUE,
                    opacity = o.optInt("o", 100),
                    bg = o.optInt("bg", 1),
                    radius = o.optInt("r", 16),
                    handle = o.optBoolean("hd", true),
                    lock = o.optBoolean("lk", false),
                    remember = o.optBoolean("rm", true),
                    snap = o.optBoolean("sn", true),
                    autoClose = o.optInt("ac", 0),
                    outside = o.optBoolean("os", true),
                    afterTap = o.optInt("at", 0),
                    startAt = o.optInt("st", 0),
                )
            }.getOrDefault(FloatCfg())
        }
    }
}

/**
 * What the widget windows share: one widget host for the whole app, the saved widget ids, each
 * widget's floating settings, and the "tile" helpers.
 *
 * A tile is a view inside a hosted widget that reacts to a tap (one chat in a chats widget, the
 * switch in a VPN widget). Android hides what a tile's tap will start, so instead of copying an
 * intent the grabber notes which tile it is (its name, and its place), and the runner later
 * presses that same tile in the widget, which fires the widget's own tap exactly as a finger would.
 */
object WidgetKit {
    const val HOST_ID = 1717
    private const val PREFS = "widgets"

    fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- one host for everything; it listens while at least one window needs it ----

    private var hostObj: AppWidgetHost? = null
    private var hostUsers = 0

    fun host(ctx: Context): AppWidgetHost =
        hostObj ?: AppWidgetHost(ctx.applicationContext, HOST_ID).also { hostObj = it }

    fun hostStart(ctx: Context) {
        val h = host(ctx)
        if (hostUsers++ == 0) runCatching { h.startListening() }
    }

    fun hostStop() {
        if (hostUsers > 0 && --hostUsers == 0) runCatching { hostObj?.stopListening() }
    }

    // ---- saved widgets and their settings ----

    fun savedIds(ctx: Context): List<Int> {
        val mgr = AppWidgetManager.getInstance(ctx)
        val h = host(ctx)
        val out = ArrayList<Int>()
        for (id in prefs(ctx).getString("ids", "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }) {
            if (mgr.getAppWidgetInfo(id) != null) out += id else runCatching { h.deleteAppWidgetId(id) }
        }
        return out
    }

    fun saveIds(ctx: Context, ids: List<Int>) {
        prefs(ctx).edit().putString("ids", ids.joinToString(",")).apply()
    }

    fun providerPackage(ctx: Context, id: Int): String =
        AppWidgetManager.getInstance(ctx).getAppWidgetInfo(id)?.provider?.packageName.orEmpty()

    fun loadCfg(ctx: Context, id: Int): FloatCfg = FloatCfg.from(prefs(ctx).getString("fl$id", null))

    fun saveCfg(ctx: Context, id: Int, cfg: FloatCfg) {
        prefs(ctx).edit().putString("fl$id", cfg.toJson()).apply()
    }

    fun forget(ctx: Context, id: Int) {
        prefs(ctx).edit().remove("fl$id").remove("h$id").apply()
    }

    // ---- tiles ----

    /** A row of a widget's list: its tap belongs to the list (Eitaa's chats are like this), not to the row. */
    fun isListRow(v: View): Boolean {
        val p = v.parent as? AbsListView ?: return false
        return p.onItemClickListener != null
    }

    /** Presses a tile the way a finger would; a list row goes through its list. */
    fun click(tile: View) {
        val p = tile.parent as? AbsListView
        if (p != null && !tile.hasOnClickListeners() && p.onItemClickListener != null) {
            val pos = p.getPositionForView(tile)
            p.performItemClick(tile, pos, p.getItemIdAtPosition(pos))
        } else {
            tile.performClick()
        }
    }

    /** Every tappable view inside the widget, in a fixed order (the widget itself only if nothing else taps). */
    fun tiles(root: View): List<View> {
        val out = ArrayList<View>()
        fun walk(v: View) {
            if (v.visibility == View.GONE) return
            if (v !== root && (v.hasOnClickListeners() || isListRow(v))) out += v
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(root)
        if (out.isEmpty() && root.hasOnClickListeners()) out += root
        return out
    }

    private fun collect(v: View, texts: MutableList<String>, descs: MutableList<String>) {
        if (v.visibility == View.GONE) return
        if (v is TextView) {
            val t = v.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) texts += t
        }
        val d = v.contentDescription?.toString()?.trim().orEmpty()
        if (d.isNotEmpty()) descs += d
        if (v is ViewGroup) for (i in 0 until v.childCount) collect(v.getChildAt(i), texts, descs)
    }

    private fun hasLetter(s: String) = s.any { it.isLetter() }

    /**
     * The tile's name: the first text with a letter in it, else the first description with one
     * (counts such as "3" or "99+" and times change, a chat's name does not). Empty when the tile
     * shows nothing readable.
     */
    fun nameOf(tile: View, root: View): String {
        var t: View = tile
        for (step in 0 until 3) {
            val texts = ArrayList<String>()
            val descs = ArrayList<String>()
            collect(t, texts, descs)
            val found = texts.firstOrNull { hasLetter(it) } ?: descs.firstOrNull { hasLetter(it) }
            if (found != null) return found.take(60)
            val p = t.parent as? ViewGroup ?: return ""
            if (p === root || p is AdapterView<*>) return ""
            t = p
        }
        return ""
    }

    /**
     * The tile's place: its row in the widget's list when it is in one (the row number stays the
     * same when the list is scrolled), otherwise its number among the tiles.
     */
    fun placeOf(tile: View, root: View): Int {
        var c: View = tile
        while (true) {
            val p = c.parent as? ViewGroup ?: break
            if (p is AbsListView) return p.firstVisiblePosition + p.indexOfChild(c)
            if (p === root) break
            c = p
        }
        return tiles(root).indexOf(tile)
    }

    /** The tappable view under a point (in [root]'s own coordinates), or null. */
    fun tileAt(root: View, x: Float, y: Float): View? {
        fun hit(v: View, px: Float, py: Float): View? {
            if (px < 0 || py < 0 || px >= v.width || py >= v.height) return null
            if (v is ViewGroup) {
                for (i in v.childCount - 1 downTo 0) {
                    val c = v.getChildAt(i)
                    if (c.visibility != View.VISIBLE) continue
                    val found = hit(c, px + v.scrollX - c.left, py + v.scrollY - c.top)
                    if (found != null) return found
                }
            }
            return v
        }
        var t: View? = hit(root, x, y)
        while (t != null) {
            if (t.hasOnClickListeners() || isListRow(t)) return t
            if (t === root) break
            t = t.parent as? View
        }
        return null
    }

    /** The tile to press: by name when it has one (a changed name is not guessed), else by its place. */
    fun pick(root: View, name: String, pos: Int): View? {
        val ts = tiles(root)
        if (name.isNotBlank()) {
            val m = ts.filter { nameOf(it, root).equals(name, ignoreCase = true) }
            return m.firstOrNull { placeOf(it, root) == pos } ?: m.firstOrNull()
        }
        return ts.firstOrNull { placeOf(it, root) == pos }
    }

    /** Scrolls the widget's list down by about a page; false when there is nothing left to scroll. */
    fun scrollPage(root: View): Boolean {
        var list: AbsListView? = null
        fun find(v: View) {
            if (list != null) return
            if (v is AbsListView && v.canScrollVertically(1)) {
                list = v
                return
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) find(v.getChildAt(i))
        }
        find(root)
        val l = list ?: return false
        l.smoothScrollBy((l.height * 0.8f).toInt().coerceAtLeast(40), 250)
        return true
    }

    /** A readable description of a tile, for the "Save this tile" window. */
    fun describe(tile: View, root: View): String {
        val texts = ArrayList<String>()
        val descs = ArrayList<String>()
        collect(tile, texts, descs)
        val idName = if (tile.id != View.NO_ID) runCatching { tile.resources.getResourceEntryName(tile.id) }.getOrNull() else null
        return buildString {
            append("Name: ").append(nameOf(tile, root).ifBlank { "(none)" }).append('\n')
            append("Place: ").append(placeOf(tile, root)).append(" (").append(tiles(root).size).append(" tiles shown)\n")
            append("Type: ").append(tile.javaClass.simpleName)
            if (idName != null) append(" #").append(idName)
            append('\n')
            append("Texts: ").append(texts.joinToString(" | ").ifBlank { "(none)" }).append('\n')
            append("Descriptions: ").append(descs.joinToString(" | ").ifBlank { "(none)" }).append('\n')
            append("Widget app: ").append(tile.context.packageName)
        }
    }

    /** The widget's whole view tree as text, so its tiles can be inspected (and pasted to a developer). */
    fun dump(root: View): String {
        val sb = StringBuilder()
        var lines = 0
        fun walk(v: View, depth: Int) {
            if (lines >= 400) return
            lines++
            val idName = if (v.id != View.NO_ID) runCatching { v.resources.getResourceEntryName(v.id) }.getOrNull() else null
            sb.append("  ".repeat(depth)).append(v.javaClass.simpleName)
            if (idName != null) sb.append(" #").append(idName)
            if (v is TextView && v.text.isNotBlank()) sb.append(" \"").append(v.text.toString().take(40)).append('"')
            val d = v.contentDescription?.toString().orEmpty()
            if (d.isNotBlank()) sb.append(" desc=\"").append(d.take(40)).append('"')
            if (v.hasOnClickListeners()) sb.append(" [TAP]")
            if (isListRow(v)) sb.append(" [ROW]")
            if (v.visibility != View.VISIBLE) sb.append(" (hidden)")
            sb.append(' ').append(v.width).append('x').append(v.height).append('\n')
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString()
    }
}

/**
 * Holds a hosted widget. While [grabbing] it swallows the tap, so nothing opens, and reports the
 * tile that was under the finger.
 */
class GrabFrame(context: Context, val hv: AppWidgetHostView) : FrameLayout(context) {
    var grabbing = false
    var onGrab: ((View?) -> Unit)? = null

    init {
        addView(hv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = grabbing

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!grabbing) return super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP) {
            onGrab?.invoke(WidgetKit.tileAt(hv, ev.x - hv.left, ev.y - hv.top))
        }
        return true
    }
}
