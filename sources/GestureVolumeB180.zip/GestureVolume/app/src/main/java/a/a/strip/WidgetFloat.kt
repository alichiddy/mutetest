package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Floating widgets: a widget drawn in its own small window over whatever app is in front. No
 * activity is involved, so showing one never switches app or lands on a home screen.
 *
 * - [show] floats one widget (a second call closes it again).
 * - [press] presses one tile of a widget, hidden or shown for a few seconds so you can see the
 *   result (the Hotspot Shield switch, a chat).
 * - [grab] opens the widget in "tap the tile you want" mode and reports which tile it was.
 */
object WidgetFloat {
    private val windows = HashMap<Int, FloatWindow>()

    fun toast(ctx: Context, text: String) {
        Toast.makeText(ctx.applicationContext, text, Toast.LENGTH_LONG).show()
    }

    /** True when A may draw over other apps; otherwise opens the permission screen. */
    private fun allowed(app: Context): Boolean {
        if (Settings.canDrawOverlays(app)) return true
        toast(app, "Allow \"Display over other apps\" for A, then try again")
        runCatching {
            app.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
        return false
    }

    fun isOpen(id: Int) = windows.containsKey(id)

    fun closeAll() {
        windows.values.toList().forEach { it.close() }
    }

    fun close(id: Int) {
        windows[id]?.close()
    }

    /** Floats the widget; when it is already floating, closes it instead. */
    fun show(ctx: Context, id: Int, toggle: Boolean = true): Boolean {
        val app = ctx.applicationContext
        if (!allowed(app)) return false
        val existing = windows[id]
        if (existing != null) {
            if (toggle) existing.close()
            return true
        }
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = false)) {
            toast(app, "That widget could not be shown")
            return false
        }
        windows[id] = w
        return true
    }

    /** Closes the window if it is open and shows it again, so new settings are used. */
    fun reopen(ctx: Context, id: Int): Boolean {
        close(id)
        return show(ctx, id, toggle = false)
    }

    /** Presses one tile. [showSec] = 0 keeps the widget hidden; above 0 shows it that many seconds. */
    fun press(ctx: Context, id: Int, name: String, pos: Int, showSec: Int): Boolean {
        val app = ctx.applicationContext
        if (!allowed(app)) return false
        val existing = windows[id]
        if (existing != null) {
            existing.press(name, pos, showSec, closeAfter = false)
            return true
        }
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = showSec <= 0)) {
            toast(app, "That widget could not be shown")
            return false
        }
        windows[id] = w
        w.press(name, pos, showSec, closeAfter = true)
        return true
    }

    /** Opens the widget in grab mode; [onDone] gets the tile's name, place and description. */
    fun grab(ctx: Context, id: Int, onDone: (String, Int, String) -> Unit): Boolean {
        val app = ctx.applicationContext
        if (!allowed(app)) return false
        close(id)
        val w = FloatWindow(app, id) { windows.remove(it) }
        if (!w.show(silent = false, forceHandle = true)) {
            toast(app, "That widget could not be shown")
            return false
        }
        windows[id] = w
        w.startGrab(onDone)
        return true
    }

    /** Runs what a cell asked for (see [WidgetFloatActivity]). */
    fun handle(ctx: Context, mode: String, i: Intent): Boolean {
        val app = ctx.applicationContext
        val pkg = i.getStringExtra("pkg").orEmpty()
        val wid = i.getIntExtra("wid", -1)
        val saved = WidgetKit.savedIds(app)
        if (saved.isEmpty()) {
            toast(app, "No widget saved in A yet")
            return false
        }
        val byPkg = saved.filter { pkg.isEmpty() || WidgetKit.providerPackage(app, it) == pkg }
        val id = if (wid in saved) wid else (byPkg.firstOrNull() ?: -1)
        if (mode == "press") {
            if (id == -1) {
                toast(app, "The widget for this cell is not saved in A any more")
                return false
            }
            return press(app, id, i.getStringExtra("tap").orEmpty(), i.getIntExtra("pos", -1), i.getIntExtra("show", 0))
        }
        if (wid == -1 && pkg.isEmpty()) return saved.map { show(app, it) }.all { it }
        if (id == -1) {
            toast(app, "The widget for this cell is not saved in A any more")
            return false
        }
        return show(app, id)
    }
}

/** The window's root: reports taps inside it and taps outside it. */
class FloatRoot(context: Context) : FrameLayout(context) {
    var onOutside: (() -> Unit)? = null
    var onTouched: ((MotionEvent) -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside?.invoke()
            return true
        }
        onTouched?.invoke(ev)
        return super.dispatchTouchEvent(ev)
    }
}

/** One floating widget window. */
class FloatWindow(private val app: Context, private val wid: Int, private val onClosed: (Int) -> Unit) {
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val d = app.resources.displayMetrics.density
    private val sw: Int get() = app.resources.displayMetrics.widthPixels
    private val sh: Int get() = app.resources.displayMetrics.heightPixels
    private var cfg = WidgetKit.loadCfg(app, wid)
    private var root: FloatRoot? = null
    private var lp: WindowManager.LayoutParams? = null
    private var frame: GrabFrame? = null
    private var hv: AppWidgetHostView? = null
    private var bar: LinearLayout? = null
    private var title: TextView? = null
    private var handlePx = 0
    private var closed = false
    private var grabbing = false
    private val closeRun = Runnable { close() }

    // ---- showing ----

    fun show(silent: Boolean, forceHandle: Boolean = false): Boolean {
        val info = AppWidgetManager.getInstance(app).getAppWidgetInfo(wid) ?: return false
        val view = runCatching { WidgetKit.host(app).createView(app, wid, info) }.getOrNull() ?: return false
        hv = view
        cfg = WidgetKit.loadCfg(app, wid)
        val showHandle = (cfg.handle || forceHandle) && !silent
        handlePx = if (showHandle) (28 * d).toInt() else 0

        val maxW = maxOf(96, (sw / d).toInt() - 8)
        val maxH = maxOf(64, (sh / d).toInt() - 40)
        val wDp = (if (cfg.wDp > 0) cfg.wDp else maxOf(96, (info.minWidth / d).toInt())).coerceIn(96, maxW)
        val hDp = (if (cfg.hDp > 0) cfg.hDp else maxOf(64, (info.minHeight / d).toInt() + (handlePx / d).toInt())).coerceIn(64, maxH)
        val wPx = (wDp * d).toInt()
        val hPx = (hDp * d).toInt()
        val fg = if (cfg.bg == 2) 0xFF202124.toInt() else 0xFFFFFFFF.toInt()

        val card = LinearLayout(app)
        card.orientation = LinearLayout.VERTICAL
        val gf = GrabFrame(app, view)
        frame = gf

        if (showHandle) {
            val b = LinearLayout(app)
            b.orientation = LinearLayout.HORIZONTAL
            b.gravity = Gravity.CENTER_VERTICAL
            b.setBackgroundColor(0x33000000)
            val t = TextView(app)
            t.text = "≡  " + cfg.name.ifBlank { runCatching { info.loadLabel(app.packageManager) }.getOrDefault("") }
            t.setTextColor(fg)
            t.textSize = 12f
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            t.gravity = Gravity.CENTER_VERTICAL
            t.setPadding((8 * d).toInt(), 0, 0, 0)
            t.setOnTouchListener(dragListener)
            b.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            val x = TextView(app)
            x.text = "✕"
            x.textSize = 16f
            x.gravity = Gravity.CENTER
            x.setTextColor(fg)
            x.setPadding((14 * d).toInt(), 0, (14 * d).toInt(), 0)
            x.setOnClickListener { close() }
            b.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            card.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, handlePx))
            bar = b
            title = t
        }
        card.addView(gf, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val r = FloatRoot(app)
        r.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (showHandle && !cfg.lock) {
            val grip = TextView(app)
            grip.text = "◢"
            grip.setTextColor(fg)
            grip.textSize = 16f
            grip.gravity = Gravity.END or Gravity.BOTTOM
            grip.setPadding(0, 0, (4 * d).toInt(), 0)
            grip.setOnTouchListener(resizeListener)
            val glp = FrameLayout.LayoutParams((34 * d).toInt(), (34 * d).toInt())
            glp.gravity = Gravity.END or Gravity.BOTTOM
            r.addView(grip, glp)
        }
        val bgDrawable = GradientDrawable()
        bgDrawable.setColor(
            when (cfg.bg) {
                0 -> 0
                2 -> 0xF2FFFFFF.toInt()
                else -> 0xE6202124.toInt()
            },
        )
        bgDrawable.cornerRadius = cfg.radius * d
        r.background = bgDrawable
        r.clipToOutline = true
        r.outlineProvider = ViewOutlineProvider.BACKGROUND
        r.alpha = if (silent) 0f else cfg.opacity / 100f
        r.onOutside = { if (cfg.outside && !grabbing && !silent) close() }
        r.onTouched = { ev -> onTouched(ev) }
        root = r

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (silent) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else if (cfg.outside) flags = flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        val p = WindowManager.LayoutParams(wPx, hPx, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        val (px, py) = place(wPx, hPx)
        p.x = px
        p.y = py
        lp = p

        WidgetKit.hostStart(app)
        val added = runCatching { wm.addView(r, p) }.isSuccess
        if (!added) {
            WidgetKit.hostStop()
            root = null
            return false
        }
        view.updateAppWidgetSize(null, wDp, hDp - (handlePx / d).toInt(), wDp, hDp - (handlePx / d).toInt())
        if (cfg.autoClose > 0 && !silent) schedule(cfg.autoClose)
        return true
    }

    private fun place(wPx: Int, hPx: Int): Pair<Int, Int> {
        if (cfg.remember && cfg.x != Int.MIN_VALUE && cfg.y != Int.MIN_VALUE) {
            return clampX(cfg.x, wPx) to clampY(cfg.y, hPx)
        }
        val cx = (sw - wPx) / 2
        val cy = (sh - hPx) / 2
        val edge = (8 * d).toInt()
        return when (cfg.startAt) {
            1 -> cx to (sh * 0.08f).toInt()
            2 -> cx to (sh - hPx - (sh * 0.12f).toInt())
            3 -> edge to cy
            4 -> (sw - wPx - edge) to cy
            else -> cx to cy
        }
    }

    private fun clampX(x: Int, wPx: Int) = x.coerceIn(0, maxOf(0, sw - wPx))
    private fun clampY(y: Int, hPx: Int) = y.coerceIn(0, maxOf(0, sh - hPx))

    private fun update() {
        val r = root ?: return
        val p = lp ?: return
        runCatching { wm.updateViewLayout(r, p) }
    }

    // ---- moving and resizing ----

    private var dsx = 0f
    private var dsy = 0f
    private var dox = 0
    private var doy = 0

    private val dragListener = View.OnTouchListener { _, e ->
        val p = lp
        if (p == null || cfg.lock) {
            false
        } else {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dsx = e.rawX
                    dsy = e.rawY
                    dox = p.x
                    doy = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = clampX(dox + (e.rawX - dsx).toInt(), p.width)
                    p.y = clampY(doy + (e.rawY - dsy).toInt(), p.height)
                    update()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (cfg.snap) snap(p)
                    update()
                    savePos(p)
                    true
                }
                else -> false
            }
        }
    }

    private fun snap(p: WindowManager.LayoutParams) {
        val th = (16 * d).toInt()
        if (p.x < th) p.x = 0
        if (sw - (p.x + p.width) < th) p.x = maxOf(0, sw - p.width)
        if (p.y < th) p.y = 0
        if (sh - (p.y + p.height) < th) p.y = maxOf(0, sh - p.height)
    }

    private fun savePos(p: WindowManager.LayoutParams) {
        if (!cfg.remember) return
        cfg = cfg.copy(x = p.x, y = p.y)
        WidgetKit.saveCfg(app, wid, cfg)
    }

    private var rsx = 0f
    private var rsy = 0f
    private var rw = 0
    private var rh = 0

    private val resizeListener = View.OnTouchListener { _, e ->
        val p = lp
        if (p == null || cfg.lock) {
            false
        } else {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    rsx = e.rawX
                    rsy = e.rawY
                    rw = p.width
                    rh = p.height
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (rw + (e.rawX - rsx).toInt()).coerceIn((96 * d).toInt(), maxOf((96 * d).toInt(), sw - p.x))
                    p.height = (rh + (e.rawY - rsy).toInt()).coerceIn((64 * d).toInt(), maxOf((64 * d).toInt(), sh - p.y))
                    update()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wDp = (p.width / d).toInt()
                    val hDp = (p.height / d).toInt()
                    cfg = cfg.copy(wDp = wDp, hDp = hDp)
                    WidgetKit.saveCfg(app, wid, cfg)
                    hv?.updateAppWidgetSize(null, wDp, hDp - (handlePx / d).toInt(), wDp, hDp - (handlePx / d).toInt())
                    true
                }
                else -> false
            }
        }
    }

    // ---- closing ----

    private fun schedule(sec: Int) {
        handler.removeCallbacks(closeRun)
        handler.postDelayed(closeRun, sec * 1000L)
    }

    private fun onTouched(ev: MotionEvent) {
        if (grabbing) return
        if (ev.actionMasked == MotionEvent.ACTION_UP && cfg.afterTap > 0 && ev.y > handlePx) {
            schedule(cfg.afterTap)
        } else if (cfg.autoClose > 0 && ev.actionMasked == MotionEvent.ACTION_DOWN) {
            schedule(cfg.autoClose)
        }
    }

    fun close() {
        if (closed) return
        closed = true
        handler.removeCallbacksAndMessages(null)
        root?.let { r -> runCatching { wm.removeView(r) } }
        root = null
        WidgetKit.hostStop()
        onClosed(wid)
    }

    // ---- pressing a tile ----

    fun press(name: String, pos: Int, showSec: Int, closeAfter: Boolean) {
        val h = hv ?: return
        var tries = 0
        var idle = 0
        val r = object : Runnable {
            override fun run() {
                if (closed) return
                val tile = WidgetKit.pick(h, name, pos)
                if (tile != null) {
                    WidgetKit.click(tile)
                    if (closeAfter) {
                        if (showSec > 0) schedule(showSec) else handler.postDelayed({ close() }, 500)
                    }
                    return
                }
                tries++
                // Not on screen yet: after a few seconds, page down through the widget's list.
                if (tries > 12 && tries % 4 == 0) {
                    if (WidgetKit.scrollPage(h)) idle = 0 else idle++
                    if (idle >= 3) {
                        WidgetFloat.toast(app, "That tile was not found in the widget")
                        if (closeAfter) close()
                        return
                    }
                }
                if (tries > 160) {
                    WidgetFloat.toast(app, "That tile was not found in the widget")
                    if (closeAfter) close()
                    return
                }
                handler.postDelayed(this, 250)
            }
        }
        handler.postDelayed(r, 300)
    }

    // ---- grabbing a tile ----

    fun startGrab(onDone: (String, Int, String) -> Unit) {
        val gf = frame ?: return
        val h = hv ?: return
        grabbing = true
        gf.grabbing = true
        title?.text = "🎯  Tap the tile you want"
        gf.onGrab = { tile ->
            if (tile == null) {
                WidgetFloat.toast(app, "Tap right on the tile (a chat, a button)")
            } else {
                val name = WidgetKit.nameOf(tile, h)
                val place = WidgetKit.placeOf(tile, h)
                val details = WidgetKit.describe(tile, h)
                gf.grabbing = false
                grabbing = false
                close()
                onDone(name, place, details)
            }
        }
        // 🎯 switches grabbing off so the widget can be scrolled, and on again.
        val b = bar ?: return
        val t = TextView(app)
        t.text = "🎯"
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
        t.setOnClickListener {
            gf.grabbing = !gf.grabbing
            grabbing = gf.grabbing
            title?.text = if (gf.grabbing) "🎯  Tap the tile you want" else "↕  Scroll, then tap 🎯"
        }
        b.addView(t, 1, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }
}
