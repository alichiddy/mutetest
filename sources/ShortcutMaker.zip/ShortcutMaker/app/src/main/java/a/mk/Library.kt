package a.mk

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/**
 * The files kept inside this app. Each file lives in a folder of its own (files/lib/<id>/<name>), so nothing depends on
 * where the file was on the phone. Any file type can be added; HTML pages open in the viewer, the rest in whatever app
 * on the phone opens that type.
 */
object Lib {
    class Item(val id: String, val file: File) {
        val name: String get() = file.name
        val size: Long get() = file.length()
        val ext: String get() = file.extension.lowercase()
    }

    private fun root(c: Context) = File(c.filesDir, "lib").apply { mkdirs() }

    fun list(c: Context): List<Item> =
        (root(c).listFiles() ?: emptyArray()).filter { it.isDirectory }
            .sortedByDescending { it.lastModified() }
            .mapNotNull { d -> d.listFiles()?.firstOrNull { it.isFile }?.let { Item(d.name, it) } }

    fun get(c: Context, id: String): Item? {
        if (id.isEmpty() || !id.all { it.isLetterOrDigit() }) return null
        val d = File(root(c), id)
        return d.listFiles()?.firstOrNull { it.isFile }?.let { Item(id, it) }
    }

    fun isHtml(name: String): Boolean = name.substringAfterLast('.', "").lowercase().let { it == "html" || it == "htm" || it == "xhtml" }

    fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "*/*"

    fun uriOf(item: Item): Uri = Uri.parse("mk://item/" + item.id)

    private fun cleanName(raw: String?): String {
        var n = (raw ?: "").substringAfterLast('/').replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim()
        if (n.isEmpty() || n == "." || n == "..") n = "file"
        if (n.length > 90) {
            val ext = n.substringAfterLast('.', "").take(10)
            n = n.take(80) + if (ext.isNotEmpty()) ".$ext" else ""
        }
        return n
    }

    fun nameOf(c: Context, uri: Uri): String? = runCatching {
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) cur.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment

    /** Copies the file behind [uri] into the app. Null when it cannot be read. */
    fun add(c: Context, uri: Uri): Item? {
        val name = cleanName(nameOf(c, uri))
        var id = java.lang.Long.toString(System.currentTimeMillis(), 36)
        while (File(root(c), id).exists()) id += "x"
        val dir = File(root(c), id).apply { mkdirs() }
        val f = File(dir, name)
        val ok = runCatching {
            c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } != null
        }.getOrDefault(false)
        if (!ok || !f.isFile) { dir.deleteRecursively(); return null }
        return Item(id, f)
    }

    fun remove(c: Context, item: Item) {
        File(root(c), item.id).deleteRecursively()
    }

    /** Opens the file: an HTML page in the viewer, any other type in the app the phone picks for it. */
    fun open(c: Context, item: Item) {
        c.startActivity(Intent(Intent.ACTION_VIEW).setClass(c, EntryActivity::class.java).setData(uriOf(item)))
    }

    /** Hands [file] to whatever app opens its type (or [share] it instead). */
    fun external(c: Context, file: File, share: Boolean = false): Boolean = try {
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", file)
        val mime = mime(file.name)
        val i = if (share) Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri), "Share")
        else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        true
    } catch (e: Throwable) {
        Tools.toast(c, "No app on this phone can open that file.")
        false
    }

    /** A shortcut for the file on the home screen (the launcher asks the person to place it). */
    fun pin(c: Context, item: Item) {
        val sm = c.getSystemService(android.content.pm.ShortcutManager::class.java)
        if (sm == null || !sm.isRequestPinShortcutSupported) { Tools.toast(c, "This launcher cannot add shortcuts."); return }
        val icon = android.graphics.drawable.Icon.createWithBitmap(Icons.badge(item.ext, item.name))
        val intent = Intent(Intent.ACTION_VIEW).setClass(c, EntryActivity::class.java).setData(uriOf(item))
        val info = android.content.pm.ShortcutInfo.Builder(c, "item_" + item.id)
            .setShortLabel(item.name.substringBeforeLast('.').ifBlank { item.name }.take(24))
            .setLongLabel(item.name.take(60))
            .setIcon(icon).setIntent(intent).build()
        sm.requestPinShortcut(info, null)
    }
}

/**
 * The one file built into a made app (assets/embedded/file, its real name in assets/embedded/name). A normal copy of this
 * app has none; a made app opens it as soon as it starts.
 */
object Embedded {
    const val DIR = "embedded"
    const val FILE = "embedded/file"
    const val NAME = "embedded/name"

    fun exists(c: Context): Boolean = runCatching { c.assets.list(DIR)?.contains("file") == true }.getOrDefault(false)

    fun name(c: Context): String = runCatching { c.assets.open(NAME).use { String(it.readBytes(), Charsets.UTF_8) } }.getOrDefault("file")

    fun bytes(c: Context): ByteArray? = runCatching { c.assets.open(FILE).use { it.readBytes() } }.getOrNull()

    /** A made app is only a reader of its one file: it is no longer offered in Open with / Share lists. */
    fun switchOffExtras(c: Context) {
        for (cls in listOf(OpenWithActivity::class.java, ImportActivity::class.java, ShareActivity::class.java)) {
            runCatching {
                c.packageManager.setComponentEnabledSetting(
                    ComponentName(c, cls), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP,
                )
            }
        }
    }
}

/** Little pictures drawn in code (for the app made for a file, and for its home screen shortcut). */
object Icons {
    /** A coloured rounded square with the file type in it; the colour comes from [seed], so each file looks its own. */
    fun badge(ext: String, seed: String): Bitmap {
        val s = 192
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val hue = (Math.abs(seed.hashCode()) % 360).toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.72f))
        c.drawRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), 44f, 44f, p)
        val t = (if (ext.isBlank()) "FILE" else ext.uppercase()).take(4)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.isFakeBoldText = true
        p.textSize = if (t.length <= 3) 68f else 52f
        c.drawText(t, s / 2f, s / 2f - (p.descent() + p.ascent()) / 2f, p)
        return b
    }

    fun png(b: Bitmap): ByteArray = java.io.ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
}

/**
 * Where every file starts: the app's icon, a home screen shortcut of a file, and a made app. It decides what to show and
 * is gone at once (no window). A made app (it has a built-in file) opens that file; this app opens its list.
 */
class EntryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            route()
        } catch (e: Throwable) {
            Tools.toast(this, "Could not open it: ${e.javaClass.simpleName}")
        }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    private fun route() {
        val d = intent?.data
        if (d != null && d.scheme == "mk" && d.host == "item") {
            val item = Lib.get(this, d.lastPathSegment.orEmpty())
            if (item == null) Tools.toast(this, "That file is no longer in the app.") else openItem(item)
            return
        }
        if (Embedded.exists(this)) {
            Embedded.switchOffExtras(this)
            val name = Embedded.name(this)
            if (Lib.isHtml(name)) {
                startActivity(Intent(this, ViewerActivity::class.java).setData(Uri.parse("mk://embedded")))
            } else {
                // Not a page: written out once and handed to the app that opens its type.
                val dir = File(cacheDir, "open").apply { mkdirs() }
                val f = File(dir, name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "file" })
                if (!f.isFile) Embedded.bytes(this)?.let { f.writeBytes(it) }
                Lib.external(this, f)
            }
            return
        }
        startActivity(Intent(this, MainActivity::class.java))
    }

    private fun openItem(item: Lib.Item) {
        if (Lib.isHtml(item.name)) startActivity(Intent(this, ViewerActivity::class.java).setData(Lib.uriOf(item)))
        else Lib.external(this, item.file)
    }
}

/** "Share" to this app from another app: any file is added to the list here. */
class ImportActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris = ArrayList<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND -> intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
        }
        if (uris.isEmpty()) {
            Tools.toast(this, "There is no file in what was shared.")
            finish(); return
        }
        val app = applicationContext
        Thread {
            val n = uris.count { Lib.add(app, it) != null }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Tools.toast(app, if (n == 0) "Could not read the file." else "Added $n file(s). Open Shortcut APK to use them.")
            }
        }.start()
        finish()
    }
}

/** "Share" a link or text to this app: opens the first screen with it in the link box. */
class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
        startActivity(Intent(this, MainActivity::class.java).putExtra("shared", t.orEmpty()))
        finish()
    }
}
