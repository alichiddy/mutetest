package a.mk

import java.io.ByteArrayOutputStream

/**
 * Changes text inside an Android compiled manifest (binary XML) or a compiled resource table (resources.arsc) without
 * any tool: the string pool is read, the wanted strings are replaced and the pool is written again. Everything else
 * in the file refers to the strings by number, so nothing else has to move. Used for the package name and name of a
 * shortcut's own app (the manifest holds the package, the resource table holds the name shown under the icon).
 */
object Axml {
    private fun u16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
    private fun u32(b: ByteArray, o: Int) = u16(b, o) or (u16(b, o + 2) shl 16)
    private fun ByteArrayOutputStream.w16(v: Int) { write(v and 255); write((v shr 8) and 255) }
    private fun ByteArrayOutputStream.w32(v: Int) { w16(v and 0xFFFF); w16((v ushr 16) and 0xFFFF) }

    /** Every string that equals a key of [map] becomes the value. */
    fun replaceStrings(src: ByteArray, map: Map<String, String>): ByteArray {
        // 0x0003 = compiled XML (header 8 bytes), 0x0002 = resource table (header 12 bytes); the string pool comes first in both.
        require(src.size > 16 && (u16(src, 0) == 0x0003 || u16(src, 0) == 0x0002)) { "not a compiled manifest or resource table" }
        val p = u16(src, 2)
        require(u16(src, p) == 0x0001) { "the file has no string pool" }
        val ph = u16(src, p + 2)
        val poolSize = u32(src, p + 4)
        val count = u32(src, p + 8)
        val styles = u32(src, p + 12)
        val flags = u32(src, p + 16)
        val stringsStart = u32(src, p + 20)
        require(styles == 0) { "the file has styled strings" }
        val utf8 = (flags and 0x100) != 0

        val strings = ArrayList<String>(count)
        for (i in 0 until count) {
            var o = p + stringsStart + u32(src, p + ph + i * 4)
            if (utf8) {
                // characters (1 or 2 bytes), then bytes (1 or 2 bytes), then the text
                if ((src[o].toInt() and 0x80) != 0) o += 2 else o += 1
                var blen = src[o].toInt() and 255
                if ((blen and 0x80) != 0) { blen = ((blen and 0x7F) shl 8) or (src[o + 1].toInt() and 255); o += 2 } else o += 1
                strings += String(src, o, blen, Charsets.UTF_8)
            } else {
                var len = u16(src, o); o += 2
                if ((len and 0x8000) != 0) { len = ((len and 0x7FFF) shl 16) or u16(src, o); o += 2 }
                strings += String(src, o, len * 2, Charsets.UTF_16LE)
            }
        }

        val data = ByteArrayOutputStream()
        val offsets = IntArray(count)
        for (i in 0 until count) {
            val s = map[strings[i]] ?: strings[i]
            offsets[i] = data.size()
            if (utf8) {
                val bytes = s.toByteArray(Charsets.UTF_8)
                fun len8(n: Int) { if (n > 0x7F) { data.write((n shr 8) or 0x80); data.write(n and 255) } else data.write(n) }
                len8(s.length); len8(bytes.size)
                data.write(bytes); data.write(0)
            } else {
                val n = s.length
                if (n > 0x7FFF) { data.w16((n ushr 16) or 0x8000); data.w16(n and 0xFFFF) } else data.w16(n)
                data.write(s.toByteArray(Charsets.UTF_16LE)); data.w16(0)
            }
        }
        while (data.size() % 4 != 0) data.write(0)

        val newStringsStart = ph + count * 4
        val newPoolSize = newStringsStart + data.size()
        val pool = ByteArrayOutputStream()
        val head = src.copyOfRange(p, p + ph)
        fun put32(at: Int, v: Int) { for (k in 0..3) head[at + k] = ((v ushr (8 * k)) and 255).toByte() }
        put32(4, newPoolSize)
        put32(16, flags and 1.inv())       // the strings are no longer sorted
        put32(20, newStringsStart)
        pool.write(head)
        for (o in offsets) pool.w32(o)
        pool.write(data.toByteArray())

        val out = ByteArrayOutputStream(src.size + 256)
        out.write(src, 0, p)
        out.write(pool.toByteArray())
        out.write(src, p + poolSize, src.size - p - poolSize)
        val result = out.toByteArray()
        val total = result.size
        for (k in 0..3) result[4 + k] = ((total ushr (8 * k)) and 255).toByte()
        return result
    }
}
