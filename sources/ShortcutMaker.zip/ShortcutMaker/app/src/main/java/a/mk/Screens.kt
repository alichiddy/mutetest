package a.mk

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

/** Plain system views only: no libraries, so the app stays small. */
object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun column(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 16)
        setPadding(p, p, p, p)
    }

    fun text(col: LinearLayout, s: String, size: Float = 15f, bold: Boolean = false): TextView {
        val t = TextView(col.context).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(col.context, 8), 0, dp(col.context, 4))
        }
        col.addView(t)
        return t
    }

    fun button(col: LinearLayout, s: String, onClick: () -> Unit): Button {
        val b = Button(col.context).apply {
            text = s
            isAllCaps = false
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            setOnClickListener { onClick() }
        }
        col.addView(b)
        return b
    }

    /** A scrolling page with a title; returns the column to add things to. */
    fun page(a: Activity, title: String): LinearLayout {
        val col = column(a)
        a.setContentView(ScrollView(a).apply { fitsSystemWindows = true; addView(col) })
        text(col, title, 22f, bold = true)
        return col
    }
}

/** First screen: the files kept in this app, and where a shortcut can come from. */
class MainActivity : Activity() {
    private companion object { const val REQ_ADD = 21; const val REQ_COPY = 22 }

    private var fileList: LinearLayout? = null
    private var copyFrom: Lib.Item? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = Ui.page(this, "Shortcut APK")

        Ui.text(col, "My files", 18f, bold = true)
        Ui.text(col, "Add any file (HTML pages most of all). A file is kept inside this app, so it does not matter where it was on the phone. Open it here, put it on the home screen, or build an app of its own for it.", 14f)
        Ui.button(col, "＋ Add files…") {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true),
                REQ_ADD,
            )
        }
        fileList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(fileList)

        Ui.text(col, "Make an app from a shortcut", 18f, bold = true)
        Ui.text(col, "Take a shortcut from anywhere and turn it into an app of its own.", 14f)
        Ui.button(col, "1. A shortcut from an app on this phone") {
            startActivity(Intent(this, PickActivity::class.java).putExtra("mode", "apps"))
        }
        Ui.button(col, "2. A shortcut an app offers (Tasker, Automate, Shortcut makers…)") {
            startActivity(Intent(this, PickActivity::class.java).putExtra("mode", "offers"))
        }
        Ui.text(col, "3. Paste or share a link: an intent link (intent:#Intent;…;end, also with Intent: in front) or a web address.", 14f)
        val shared = intent?.getStringExtra("shared")
        val box = EditText(this).apply {
            hint = "Link"
            minLines = 2
            setText(shared.orEmpty())
        }
        col.addView(box)
        Ui.button(col, "Use this link") {
            val sc = Tools.parseLink(this, box.text.toString())
            if (sc == null) Tools.toast(this, "That is not a link I can run.")
            else Tools.openMake(this, sc.first, sc.second, null)
        }
    }

    override fun onResume() {
        super.onResume()
        fillList()
    }

    private fun fillList() {
        val box = fileList ?: return
        box.removeAllViews()
        val items = Lib.list(this)
        if (items.isEmpty()) { Ui.text(box, "No files yet.", 14f); return }
        for (it in items) {
            val kb = (it.size + 1023) / 1024
            Ui.button(box, it.name + "\n" + (if (kb >= 1024) "%.1f MB".format(kb / 1024f) else "$kb KB")) { fileMenu(it) }
        }
    }

    private fun fileMenu(item: Lib.Item) {
        val opts = arrayOf(
            "Open",
            "Make an APK app for this file",
            "Put a shortcut on the home screen",
            "Share",
            "Save a copy…",
            "Remove from this app",
        )
        AlertDialog.Builder(this).setTitle(item.name).setItems(opts) { _, i ->
            when (i) {
                0 -> Lib.open(this, item)
                1 -> askAppName(item)
                2 -> Lib.pin(this, item)
                3 -> Lib.external(this, item.file, share = true)
                4 -> {
                    copyFrom = item
                    @Suppress("DEPRECATION")
                    startActivityForResult(
                        Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(Lib.mime(item.name)).putExtra(Intent.EXTRA_TITLE, item.name),
                        REQ_COPY,
                    )
                }
                else -> AlertDialog.Builder(this).setTitle("Remove " + item.name + "?")
                    .setMessage("Only the copy kept in this app is removed. Apps and shortcuts already made from it keep working.")
                    .setPositiveButton("Remove") { _, _ -> Lib.remove(this, item); fillList() }
                    .setNegativeButton("Cancel", null).show()
            }
        }.setNegativeButton("Close", null).show()
    }

    /** The name under the made app's icon, then the app is built. */
    private fun askAppName(item: Lib.Item) {
        if (item.size > ApkMaker.MAX_EMBED) {
            Tools.toast(this, "This file is too big to build into an app (the limit is ${ApkMaker.MAX_EMBED / 1024 / 1024} MB).")
            return
        }
        val name = EditText(this).apply {
            setText(item.name.substringBeforeLast('.').ifBlank { item.name })
            isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(30))
        }
        val holder = LinearLayout(this).apply { setPadding(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 20), 0); addView(name, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle("Name of the app")
            .setMessage("Shown under its icon after it is installed. The file is built into the app.")
            .setView(holder)
            .setPositiveButton("Build the app") { _, _ ->
                if (name.text.isBlank()) Tools.toast(this, "Type a name first.") else Tools.buildFileApp(this, item, name.text.toString())
            }
            .setNegativeButton("Cancel", null).show()
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val app = applicationContext
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        if (requestCode == REQ_ADD) {
            val uris = ArrayList<Uri>()
            data.clipData?.let { cd -> for (k in 0 until cd.itemCount) cd.getItemAt(k).uri?.let { uris.add(it) } }
            if (uris.isEmpty()) data.data?.let { uris.add(it) }
            Thread {
                val n = uris.count { Lib.add(app, it) != null }
                main.post {
                    fillList()
                    Tools.toast(app, if (n == uris.size) "Added $n file(s)." else "Added $n of ${uris.size}; the others could not be read.")
                }
            }.start()
        } else if (requestCode == REQ_COPY) {
            val from = copyFrom; val to = data.data
            copyFrom = null
            if (from == null || to == null) return
            Thread {
                val ok = runCatching { contentResolver.openOutputStream(to)?.use { o -> from.file.inputStream().use { it.copyTo(o) } } != null }.getOrDefault(false)
                main.post { Tools.toast(app, if (ok) "Saved." else "Could not save.") }
            }.start()
        }
    }
}

/** A list to search and pick from: the apps on the phone, or the apps that offer shortcuts. */
class PickActivity : Activity() {
    private class Row(val label: String, val sub: String, val cn: ComponentName) {
        override fun toString() = "$label\n$sub"
    }

    private var picked: Row? = null
    private val offers get() = intent.getStringExtra("mode") == "offers"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager
        val q = if (offers) Intent(Intent.ACTION_CREATE_SHORTCUT)
        else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val rows = pm.queryIntentActivities(q, 0).map {
            val ai = it.activityInfo
            Row(
                it.loadLabel(pm).toString(),
                if (offers) ai.applicationInfo.loadLabel(pm).toString() else ai.packageName,
                ComponentName(ai.packageName, ai.name),
            )
        }.sortedBy { it.label.lowercase() }

        val root = Ui.column(this).apply { fitsSystemWindows = true }
        Ui.text(root, if (offers) "Shortcuts apps offer" else "Apps on this phone", 22f, bold = true)
        val search = EditText(this).apply { hint = "Search"; isSingleLine = true }
        root.addView(search)
        val list = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> adapter.getItem(pos)?.let { pick(it) } }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { adapter.filter.filter(s) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        setContentView(root)
        if (rows.isEmpty()) Tools.toast(this, "Nothing found.")
    }

    private fun pick(r: Row) {
        if (offers) {
            picked = r
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(r.cn), 1)
            } catch (e: Throwable) {
                Tools.toast(this, "Could not open it: ${e.javaClass.simpleName}")
            }
        } else {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(r.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val icon = runCatching { Tools.bitmapOf(packageManager.getActivityIcon(r.cn)) }.getOrNull()
            Tools.openMake(this, r.label, i.toUri(Intent.URI_INTENT_SCHEME), icon)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val r = picked ?: return
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        val sc = data.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (sc == null) { Tools.toast(this, "That app gave no shortcut."); return }
        val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: r.label
        Tools.openMake(this, name, sc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).toUri(Intent.URI_INTENT_SCHEME), Tools.iconOf(this, data))
    }
}

/** The picked shortcut: name it, try it, and make it an app (ready slot, or a new APK). */
class MakeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.getStringExtra("u").orEmpty()
        val col = Ui.page(this, "Make an app")
        Ui.text(col, "Name of the app (shown on the phone after it is installed)")
        val name = EditText(this).apply {
            setText(intent.getStringExtra("n").orEmpty())
            isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(30))
        }
        col.addView(name)
        Ui.text(col, "Runs: " + uri.take(160))
        Ui.button(col, "Test (run now)") { Tools.run(this, uri) }
        Ui.text(col, "Make it an app, two ways:")
        val slots = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.button(col, "A: one of the ready app slots (A 1 … A ${Tools.SLOTS}). Install once, change its shortcut any time.") {
            slots.removeAllViews()
            for (n in 1..Tools.SLOTS) {
                val pkg = Tools.STUB_PREFIX + "s$n"
                val e = Tools.stubEntry(this, pkg)
                val line = "A $n  -  " + (if (Tools.isInstalled(this, pkg)) "installed" else "not installed") +
                    "  -  " + (e?.let { "runs: " + it.name } ?: "free")
                Ui.button(slots, line) { Tools.useSlot(this, n, uri, name.text.toString()) }
            }
        }
        col.addView(slots)
        Ui.button(col, "B: build a new APK app for this shortcut, with its own name and icon.") {
            if (name.text.isBlank()) Tools.toast(this, "Type a name first.")
            else Tools.buildOwnApp(this, uri, name.text.toString())
        }
    }
}
