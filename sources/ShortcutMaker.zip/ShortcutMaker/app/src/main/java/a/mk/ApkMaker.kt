package a.mk

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * Makes a small app of its own for one shortcut. An APK is a zip: the helper template (assets/stub/tpl.apk or a
 * ready slot s1..s10) is copied entry by entry (stored entries kept stored and aligned, as Android requires), its
 * package name and name are replaced inside the compiled manifest, its one picture is replaced, and the copy is
 * signed with the key kept in assets. Runs only when asked; nothing here is loaded otherwise.
 */
object ApkMaker {

    /**
     * What the system's installer insists on and a plain signature check does not: resources.arsc
     * stored and 4-byte aligned, stored native libraries page aligned, no duplicate names. Returns
     * the first problem as text, or null when the layout is fine.
     */
    private fun checkLayout(file: File): String? = runCatching {
        java.io.RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            val tailLen = minOf(len, 70000L).toInt()
            val tail = ByteArray(tailLen)
            raf.seek(len - tailLen); raf.readFully(tail)
            fun i32(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)
            fun i16(b: ByteArray, o: Int) = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
            var eocd = -1
            for (p in tailLen - 22 downTo 0) if (i32(tail, p) == 0x06054b50) { eocd = p; break }
            if (eocd < 0) return@use "no zip directory at the end of the new file"
            val count = i16(tail, eocd + 10)
            val cdSize = i32(tail, eocd + 12)
            val cdOff = i32(tail, eocd + 16).toLong() and 0xFFFFFFFFL
            val cd = ByteArray(cdSize); raf.seek(cdOff); raf.readFully(cd)
            val seen = HashSet<String>()
            var p = 0
            repeat(count) {
                if (i32(cd, p) != 0x02014b50) return@use "zip directory is damaged"
                val method = i16(cd, p + 10)
                val nameLen = i16(cd, p + 28); val extraLen = i16(cd, p + 30); val commentLen = i16(cd, p + 32)
                val lho = i32(cd, p + 42).toLong() and 0xFFFFFFFFL
                val name = String(cd, p + 46, nameLen, Charsets.UTF_8)
                if (!seen.add(name)) return@use "duplicate entry $name"
                val lh = ByteArray(30); raf.seek(lho); raf.readFully(lh)
                val dataOff = lho + 30 + i16(lh, 26) + i16(lh, 28)
                if (name == "resources.arsc" && (method != 0 || dataOff % 4 != 0L)) return@use "resources.arsc is compressed or misaligned (method $method, offset ${dataOff % 4})"
                if (name.endsWith(".so") && method == 0 && dataOff % 4096 != 0L) return@use "$name is stored but not page-aligned"
                p += 46 + nameLen + extraLen + commentLen
            }
            null
        }
    }.getOrElse { "layout check failed: ${it.message}" }

    /** Our own zip writer, so every byte offset is known and alignment cannot drift. */
    private class ZipOut(file: File) : AutoCloseable {
        private val out = java.io.BufferedOutputStream(file.outputStream(), 1 shl 16)
        var pos = 0L
            private set
        private class Rec(val name: ByteArray, val method: Int, val crc: Long, val csize: Long, val usize: Long, val offset: Long)
        private val recs = ArrayList<Rec>()

        private fun w(b: ByteArray) { out.write(b); pos += b.size }
        private fun le16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
        private fun le32(v: Long) = byteArrayOf(v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())

        /** [align] > 0: the data starts at a multiple of it (stored entries only). */
        fun add(name: String, data: ByteArray, stored: Boolean, align: Int) {
            val nameBytes = name.toByteArray(Charsets.UTF_8)
            val crc = java.util.zip.CRC32().apply { update(data) }.value
            val body: ByteArray = if (stored) data else {
                val d = java.util.zip.Deflater(6, true)
                val bos = java.io.ByteArrayOutputStream(data.size / 2 + 64)
                java.util.zip.DeflaterOutputStream(bos, d).use { it.write(data) }
                d.end(); bos.toByteArray()
            }
            // A stored entry that would not shrink is kept stored; a deflated one that grew is too.
            val useStored = stored || body.size >= data.size
            val payload = if (useStored) data else body
            // A deflated entry that fell back to stored (small, incompressible) still needs its alignment.
            val al = if (align > 0) align else if (name.endsWith(".so")) 16384 else if (name == "resources.arsc") 4 else 0
            var extra = ByteArray(0)
            if (useStored && al > 0) {
                val base = pos + 30 + nameBytes.size
                var need = ((al - base % al) % al).toInt()
                if (need in 1..3) need += al
                if (need > 0) {
                    extra = ByteArray(need)
                    extra[0] = 0x35; extra[1] = 0xD9.toByte()
                    extra[2] = ((need - 4) and 0xFF).toByte(); extra[3] = (((need - 4) shr 8) and 0xFF).toByte()
                }
            }
            val method = if (useStored) 0 else 8
            val offset = pos
            w(le32(0x04034b50L)); w(le16(20)); w(le16(0x0800)); w(le16(method))
            w(le16(0)); w(le16(0x2821))                 // a fixed time and date
            w(le32(crc)); w(le32(payload.size.toLong())); w(le32(data.size.toLong()))
            w(le16(nameBytes.size)); w(le16(extra.size)); w(nameBytes); w(extra)
            w(payload)
            recs += Rec(nameBytes, method, crc, payload.size.toLong(), data.size.toLong(), offset)
        }

        override fun close() {
            val cdStart = pos
            for (r in recs) {
                w(le32(0x02014b50L)); w(le16(20)); w(le16(20)); w(le16(0x0800)); w(le16(r.method))
                w(le16(0)); w(le16(0x2821))
                w(le32(r.crc)); w(le32(r.csize)); w(le32(r.usize))
                w(le16(r.name.size)); w(le16(0)); w(le16(0)); w(le16(0)); w(le16(0)); w(le32(0)); w(le32(r.offset))
                w(r.name)
            }
            val cdSize = pos - cdStart
            w(le32(0x06054b50L)); w(le16(0)); w(le16(0)); w(le16(recs.size)); w(le16(recs.size))
            w(le32(cdSize)); w(le32(cdStart)); w(le16(0))
            out.flush(); out.close()
        }
    }

    /**
     * Option B for a shortcut: a small app of its own. The helper template (assets/stub/tpl.apk, built with this app) is copied,
     * its package name and name are replaced inside the compiled manifest, its one picture is replaced by [iconPng],
     * and the copy is signed with this app's key. Returns the signed file (in the share cache folder).
     */
    fun makeShortcutApp(
        context: Context, pkg: String, label: String, iconPng: ByteArray?,
        asset: String = "stub/tpl.apk", oldPkg: String = "a.mk.sc.tpl", oldLabel: String = "TPLLABEL",
    ): File {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val tpl = File(dir, "tpl.apk")
        context.assets.open(asset).use { i -> tpl.outputStream().use { o -> i.copyTo(o) } }
        val unsigned = File(dir, "shortcut-unsigned.apk")
        val signed = File(dir, "A-$pkg.apk")
        signed.delete()
        ZipFile(tpl).use { zip ->
            ZipOut(unsigned).use { out ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    val name = e.name
                    if (e.isDirectory || isSignatureFile(name)) continue
                    var data = zip.getInputStream(e).use { it.readBytes() }
                    if (name == "AndroidManifest.xml") {
                        data = Axml.replaceStrings(data, mapOf(oldPkg to pkg, oldLabel to label))
                    } else if (iconPng != null && name.startsWith("res/") && name.endsWith(".png")) {
                        data = iconPng
                    }
                    val stored = e.method == ZipEntry.STORED || name == "resources.arsc"
                    val align = when { !stored -> 0; name.endsWith(".so") -> 16384; else -> 4 }
                    out.add(name, data, stored, align)
                }
            }
        }
        checkLayout(unsigned)?.let { error("before signing: $it") }
        sign(context, unsigned, signed)
        val check = com.android.apksig.ApkVerifier.Builder(signed).build().verify()
        if (!check.isVerified) error("signature check failed: " + check.errors.joinToString { it.toString() }.take(300))
        val info = context.packageManager.getPackageArchiveInfo(signed.absolutePath, 0)
            ?: error("Android cannot read the new app (it parses as an invalid package)")
        if (info.packageName != pkg) error("the new app has the package ${info.packageName}, not $pkg")
        unsigned.delete(); tpl.delete()
        return signed
    }

    /** A copy of [file] in the Downloads folder; false when it could not be made (the file itself is still fine). */
    fun copyToDownloads(context: Context, file: File, name: String): Boolean = runCatching {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        true
    }.getOrDefault(false)

    private fun isSignatureFile(name: String): Boolean {
        if (!name.startsWith("META-INF/")) return false
        val n = name.uppercase()
        return n == "META-INF/MANIFEST.MF" || n.endsWith(".SF") || n.endsWith(".RSA") ||
            n.endsWith(".DSA") || n.endsWith(".EC")
    }

    private fun sign(context: Context, input: File, output: File) {
        val keyBytes = context.assets.open("signer_key.der").use { it.readBytes() }
        val certBytes = context.assets.open("signer_cert.der").use { it.readBytes() }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(keyBytes))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(certBytes.inputStream()) as X509Certificate
        val signer = ApkSigner.SignerConfig.Builder("debug", key, listOf(cert)).build()
        val builder = ApkSigner.Builder(listOf(signer))
            .setInputApk(input)
            .setOutputApk(output)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(true)
            .setV4SigningEnabled(false)
        // The signer must keep the page alignment this file was written with, and align libraries to
        // 16 KB itself. Called by name so an older signer library without them still compiles.
        runCatching { builder.javaClass.getMethod("setAlignmentPreserved", java.lang.Boolean.TYPE).invoke(builder, true) }
        runCatching { builder.javaClass.getMethod("setLibraryPageAlignmentBytes", Integer.TYPE).invoke(builder, 16384) }
        builder.build().sign()
    }
}
