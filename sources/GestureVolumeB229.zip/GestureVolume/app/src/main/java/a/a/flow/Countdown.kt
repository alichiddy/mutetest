package a.a.flow

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * A countdown shown over every app (a small dark pill at the top that cannot be touched), for the
 * "Countdown" and "Limit how often" script blocks. It exists only while it counts: nothing stays
 * in memory afterwards.
 */
object Countdown {
    /** Shows [label] and the time left until [ms] have passed, or until [stop] says so. Blocking. */
    fun show(app: Context, label: String, ms: Long, stop: () -> Boolean) {
        val main = Handler(Looper.getMainLooper())
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        var view: TextView? = null
        if (Settings.canDrawOverlays(app)) {
            val latch = CountDownLatch(1)
            main.post {
                runCatching {
                    val d = app.resources.displayMetrics.density
                    val tv = TextView(app)
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 20f
                    tv.gravity = Gravity.CENTER
                    tv.setPadding((16 * d).toInt(), (10 * d).toInt(), (16 * d).toInt(), (10 * d).toInt())
                    tv.background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 24 * d }
                    val p = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT,
                    )
                    p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                    p.y = (80 * d).toInt()
                    wm.addView(tv, p)
                    view = tv
                }
                latch.countDown()
            }
            latch.await(2, TimeUnit.SECONDS)
        } else {
            main.post { Toast.makeText(app.applicationContext, label + " " + (ms / 1000) + " s", Toast.LENGTH_LONG).show() }
        }
        val end = System.currentTimeMillis() + ms
        try {
            while (!stop()) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                val sec = (left + 999) / 1000
                val text = label + "  " + (sec / 60) + ":" + (sec % 60).toString().padStart(2, '0')
                main.post { view?.text = text }
                Thread.sleep(minOf(left, 250L))
            }
        } catch (_: InterruptedException) {
        } finally {
            main.post { view?.let { runCatching { wm.removeView(it) } } }
        }
    }
}
