package a.a.strip

import android.content.Context
import android.content.SharedPreferences
import a.a.sides.SideConfig
import a.a.sides.Seg

/**
 * Which cells window a piece of code works on. The main slider's window is scope "" and uses the names it
 * always had. A side segment with its own window ("Cells window: same as the main slider" off) has a scope
 * equal to its id: the same settings, with "_<id>" added to every name that starts with "strip", and its own
 * cells list under `stripConfigV1_<id>`. Names that do not start with "strip" (the shared tools: click circle,
 * previous app, launcher mode...) are the same for every scope.
 */
object StripScope {
    const val MAIN = ""
    private const val PREFS = "MyPrefs"
    private const val CONFIG = "stripConfigV1"

    private fun base(context: Context): SharedPreferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The preferences of a window: the real ones for the main slider, a name-adding wrapper for a segment's own. */
    fun prefs(context: Context, id: String): SharedPreferences =
        if (id.isEmpty()) base(context) else ScopedPrefs(base(context), id)

    fun configKey(id: String) = if (id.isEmpty()) CONFIG else CONFIG + "_" + id

    /** The window's cells. A segment's own window starts empty (never the built-in list). */
    fun load(context: Context, id: String): StripConfig {
        val json = base(context).getString(configKey(id), null)
        if (id.isEmpty()) return StripConfig.load(context, json)
        return if (json.isNullOrBlank()) StripConfig(items = emptyList()) else StripConfig.fromJson(json)
    }

    fun save(context: Context, id: String, cfg: StripConfig) {
        base(context).edit().putString(configKey(id), cfg.toJson()).apply()
    }

    /** Removes every setting and the cells of a segment's own window. The main slider and other windows are not touched. */
    fun deleteWindow(context: Context, id: String) {
        if (id.isEmpty()) return
        val b = base(context)
        val e = b.edit()
        for (k in b.all.keys) if (k.startsWith("strip") && k.endsWith("_$id")) e.remove(k)
        e.apply()
    }

    fun exists(context: Context, id: String): Boolean = id.isNotEmpty() && base(context).contains(configKey(id))

    /**
     * Once, when a segment gets its own window: the gap and the outside actions it had under the old rows go into the new
     * window, so nothing already set is lost. Old actions kept their sides (left stays left); the new window is mirrored
     * like the main slider's (left and right swap, fields above/below run the other way), so with [mirrored] they are written swapped.
     */
    fun migrateLegacy(context: Context, seg: Seg, mirrored: Boolean) {
        if (seg.id.isEmpty()) return
        val e = prefs(context, seg.id).edit()
        if (seg.gapDp >= 0) e.putInt("stripGapDp", seg.gapDp)
        if (!seg.edgeFollow) {
            e.putBoolean("stripEdgeOn", seg.edgeOn)
            for (side in EdgeFields.SIDES) {
                val target = if (!mirrored) side else when (side) { "Left" -> "Right"; "Right" -> "Left"; else -> side }
                val n = seg.edgeCount(side)
                e.putInt("stripEdgeCnt$target", n)
                for (z in 0 until n) {
                    val tz = if (mirrored && (side == "Top" || side == "Bottom")) n - 1 - z else z
                    e.putString(EdgeFields.key(target, tz), seg.edgeAct(side, z))
                }
            }
        }
        e.apply()
    }

    /** (id, name) of every segment that has its own window, like ("k3x9a1", "Left 1"). */
    fun ownWindowIds(context: Context): List<Pair<String, String>> {
        val c = SideConfig.load(context)
        val out = ArrayList<Pair<String, String>>()
        c.left.segs.forEachIndexed { i, g -> if (g.ownWindow) out += g.id to "Left ${i + 1}" }
        c.right.segs.forEachIndexed { i, g -> if (g.ownWindow) out += g.id to "Right ${i + 1}" }
        return out
    }
}

/**
 * Preferences seen by one segment's own cells window: every name that starts with "strip" is kept under
 * "<name>_<id>" in the real preferences; any other name goes straight through.
 */
class ScopedPrefs(private val base: SharedPreferences, private val id: String) : SharedPreferences {
    private val suffix = "_$id"

    private fun k(key: String?): String? = if (key != null && key.startsWith("strip")) key + suffix else key

    override fun getAll(): MutableMap<String, *> {
        val out = HashMap<String, Any?>()
        for ((key, v) in base.all) {
            if (key.startsWith("strip")) { if (key.endsWith(suffix)) out[key.removeSuffix(suffix)] = v } else out[key] = v
        }
        return out
    }

    override fun getString(key: String?, defValue: String?): String? = base.getString(k(key), defValue)
    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? = base.getStringSet(k(key), defValues)
    override fun getInt(key: String?, defValue: Int): Int = base.getInt(k(key), defValue)
    override fun getLong(key: String?, defValue: Long): Long = base.getLong(k(key), defValue)
    override fun getFloat(key: String?, defValue: Float): Float = base.getFloat(k(key), defValue)
    override fun getBoolean(key: String?, defValue: Boolean): Boolean = base.getBoolean(k(key), defValue)
    override fun contains(key: String?): Boolean = base.contains(k(key))

    override fun edit(): SharedPreferences.Editor = Ed(base.edit())

    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        base.registerOnSharedPreferenceChangeListener(listener)
    }

    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {
        base.unregisterOnSharedPreferenceChangeListener(listener)
    }

    private inner class Ed(private val e: SharedPreferences.Editor) : SharedPreferences.Editor {
        override fun putString(key: String?, value: String?): SharedPreferences.Editor { e.putString(k(key), value); return this }
        override fun putStringSet(key: String?, values: MutableSet<String>?): SharedPreferences.Editor { e.putStringSet(k(key), values); return this }
        override fun putInt(key: String?, value: Int): SharedPreferences.Editor { e.putInt(k(key), value); return this }
        override fun putLong(key: String?, value: Long): SharedPreferences.Editor { e.putLong(k(key), value); return this }
        override fun putFloat(key: String?, value: Float): SharedPreferences.Editor { e.putFloat(k(key), value); return this }
        override fun putBoolean(key: String?, value: Boolean): SharedPreferences.Editor { e.putBoolean(k(key), value); return this }
        override fun remove(key: String?): SharedPreferences.Editor { e.remove(k(key)); return this }
        /** Clears only this window's own names, never the real preferences. */
        override fun clear(): SharedPreferences.Editor {
            for (key in base.all.keys) if (key.startsWith("strip") && key.endsWith(suffix)) e.remove(key)
            return this
        }
        override fun commit(): Boolean = e.commit()
        override fun apply() = e.apply()
    }
}
