# HANDOFF (newest first)

## B229 - B228 fixed: layout logic is B227's again; add cell / folder take the first blank
- B228 added a padding rule to settlePins that made blank rows undeletable and put added folders on the right; it is gone. settlePins is exactly B227's, plus two optional params (keepPath, keep) that keep the last `keep` cells of one folder level from the trailing-blank trim.
- strip/StripConfig.kt: firstBlank(list) = first unpinned blank cell; withNewCell(list, fresh) = fresh replaces the first blank, else goes at the end (settlePins then gives it its own row above the pinned bottom row, blank cells fill the row); a blank fresh cell returns keep = 1 so it is not trimmed.
- ui/screens/strip/StripEditorScreen.kt: "+ Add a cell" selects the first blank, or adds one; "+ Add a folder" uses withNewCell; commit/commitItems take keep. strip/LauncherCatcher.kt ActionSaver.saveToCells uses withNewCell (built-in shortcuts, widgets, Grab it).
- strip/SettingsBackup.kt (from B228, unchanged): widgetTiles + widgetTilesGone in the scripts part of the backup, merged by tile id on restore.
- Not compiled. Brackets of the changed files match the B227 originals.

## B227 - running scripts: notifications with Stop, Always On, stop one / stop all, running on top
- Ali's request (step 1 of 2; sorting options are NOT built yet, asked for the next step): each running script shows a notification with a Stop button; scripts with the "Always On" box ticked share ONE notification; every running script can be stopped separately in the Scripts window (also Always On ones); running scripts sorted to the top; a "Stop all running scripts" button.
- flow/FlowRunner.kt: the single global stopAll flag is gone. Run(id, name, since, alwaysOn) with @Volatile stopped and the run's thread; registry runs (ConcurrentHashMap). run() makes a Run at depth 0 (own = true), registers it, and removes it in finally (Thread.interrupted() clears a late interrupt). Nested and "at the same time" scripts get the same token (new param token). API: running(): List<RunInfo>, isRunning(id), stop(id), stopByName(name), stopAllRuns(alwaysOnOnly), stop() = all. halt() sets the flag and interrupts the run's thread so a Wait block ends at once; failed() says "Stopped" instead of an error when the run was stopped. Every old `{ stopAll }` lambda now reads tk.stopped (OCR wait, countdown, field wait, rate limit).
- New flow/RunningNotes.kt: channel "scripts_running" (low). started() posts nothing for the first 1000 ms (quick cell presses stay silent), then refresh(): own notification per non-Always-On run (title = script, chronometer, Stop action, tap opens Scripts), one shared notification for Always On runs (InboxStyle with names, action "Stop all of them"); ended() refreshes, so notifications vanish when the run ends. FlowStopReceiver (manifest receiver, exported=false) handles the Stop buttons; if the run is no longer known (process was killed) it removes the stale notification. ids: 7390 shared, 7500 + runId % 900.
- flow/FlowHelpers.kt FlowPrefs: isAlwaysOn / setAlwaysOn (string set "alwaysOn" in prefs FlowPrefs, keyed by the script id so renames keep it; not in the settings backup).
- flow/FlowCanvasEditor.kt: "Always On" checkbox in the top bar of the script editor; the editor's Stop button now stops only this script (stopByName).
- flow/FlowActivity.kt: runningNow polled once a second only while the list is open; "Stop all running scripts (N)" button; running scripts sorted first (stable) with "running" / "Always On, running" and a Stop button on the row.
- AndroidManifest.xml: receiver .flow.FlowStopReceiver.
- Not compiled. Brackets of the changed files balance like the B226 originals; manifest parses. Android 13+ needs the notification permission to be granted for the notifications to show.
- Next (asked, not built): sort options in the Scripts list (name, last used, last opened, created, last modified, type with its branches Cell/Automate/Script/Widget/Imported/Restored), as checkboxes with a priority order; this needs "last used / opened / created / modified" times, which are not stored yet.

## B226 - OCR wait skips wrong readings; new countdown (movable, opacity, minimize, bar/notification, one shared countdown)
- Ali's report (installed b218): the widget shows the bank's error word (khata, Persian) first; the OCR reads it as digits (00040, or 90400900) and OCR wait took it, so the real code (e.g. 02827, in the same candidate list, the Persian zero is a small dot) was lost; the countdown also restarted on every rerun and the pill could not be moved.
- flow/Step.kt: two new optional fields e and f (JSON "e", "f", written only when not empty; old flows load as before). OCRWAIT: e = exactly this many digits ("" any), f = readings to ignore, comma separated. COUNTDOWN: c = bar | notice | both | none, d = opacity 10..100, e = name (same name = one countdown), f = join | stop | restart. RATELIMIT: e = show as, f = opacity.
- strip/ScreenOcr.kt waitRead(..., digitCount, ignore, stop): acceptable(v) rejects an ignored reading (Persian digits and spaces normalised) and an all-digit reading of the wrong length; used for the widget path and the box path; a rejected reading is skipped and the wait goes on until the time is up (then ocr_found = no). DiagLog line "OCR wait: ... digits=N ignore=..." shows the settings.
- strip/WidgetFloat.kt readNow(app, id, timeoutMs, accept): picks the first candidate that passes accept (length 4..12 first), no fallback to a rejected one. Default accepts everything (NativeActions caller unchanged).
- flow/Countdown.kt rewritten: Opts(show, opacity, name, again); sessions map by name (users counted, the last one out removes the bar and the notification). Bar: touchable, drag anywhere (position kept in prefs file "countdown_pos"), "-" shrinks it to the time only ("+" restores), opacity = view alpha. Notification: channel "countdown" (low importance), chronometer counting down by itself (no updates), ongoing, auto-removed. A rerun with again = join continues the same countdown; stop = returns false and FlowRunner stops that run; restart = new one. RATELIMIT joins "limit:<name>".
- flow/FlowRunner.kt, flow/FlowCanvasEditor.kt (forms: digits count pick, ignore field, countdown show-as / opacity / name / when-already pick; BlockForm keeps e and f), Step.describe.
- Script guide (A_script_guide_for_AI.txt) updated: e and f fields, countdown options, and a rule that the AI should describe a missing block for the code AI instead of only refusing.
- RsaltMe_Bank_widget_code_fixed.afl uses e="5", f="00040,90400900", countdown name "bank code wait" (same id #q4w8e2r6: importing replaces the earlier copy).
- Not compiled. Brackets of the 6 changed .kt files balance like the originals. Not done yet (asked, waiting): notifications with a Stop button per running script, "Always On" shared notification, Stop all running scripts button, sort options in the Scripts list.

## B225 - pinned cells really stay; pin dot corner and distance
- Ali's request: a pinned cell stays where it is when cells are deleted or added; the bottom-right pin stays bottom-right when a row is added (blank cells fill the new row); pin dot corner + distance; make the follow-the-bottom behaviour an option (pinned folders in the corner opened while passing), also "only folders".
- strip/StripConfig.kt: StripItem.pinBottom + pinCol (JSON "pb" = column, only when pinned and in the bottom row). settlePins(list, columns, follow): grid of `columns` (folders use their own cols), rows = ceil(size/columns). A pin that is pinBottom and allowed by `follow` (PIN_ALL 0 / PIN_FOLDERS 1 / PIN_NONE 2) goes to the last row, its column (next free if taken); other pins keep pinSlot (next free down, else up); other cells fill the free slots in order; free slots that end up below a pin become blank cells; the list ends at the last pin or cell. Blank cells at the very end of the non-pin cells are dropped first when a following pin exists (they are only padding), so deleting the cell in front of the pin lets the row go. After placing, every pin's pinSlot/pinBottom/pinCol is rewritten to where it landed (so the stored place always matches). anchorPin(l, at, columns) = a pin moved on purpose. deleteCells(list, ids): a deleted cell with a pin after it (a pin not deleted) becomes a blank; no pin after = removed; a blank is always removed.
- ui/screens/strip/StripEditorScreen.kt: commit settles with next.columns and pref "stripPinFollow" (default 0); anchor/applyDrop/Pin button use anchorPin with viewCols; Delete (single and multi) uses deleteCells. Add/Copy/Blank/Make folder need no change: settlePins does the work after them.
- strip/LauncherCatcher.kt saveToCells: settles after appending.
- strip/StripView.kt + ui/screens/strip/LookDialog.kt ("Pinned cells"): prefs stripPinFollow (0 all, 1 only folders, 2 never), stripPinDotCorner (0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right), stripPinDotX / stripPinDotY (0..24 dp, gap between the dot and the cell's side / top-bottom). Until X or Y is touched the dot sits exactly as before (top-left). With mirror on the corner is the corner as drawn. New PickRow composable in LookDialog.
- Old saves have no "pb": the first change of the cells marks the pins that sit in the bottom row as followers. The option is read at the next change of the cells (not live).
- Not compiled. Logic checked by a Python port (example from the handoff, delete with/without pin after, add x3, folders-only, collapse of the extra row).

## B224 - the bubble can hide half outside the screen
- Ali's request: let the minimized bubble sit half outside the screen, so only its other half shows.
- strip/FloatBubble.kt: the position range is now -half .. screen-half on both axes (half = 23 dp), and the window has FLAG_LAYOUT_IN_SCREEN | FLAG_LAYOUT_NO_LIMITS (without NO_LIMITS Android pushes an overlay back inside). The visible half still takes the tap and the drag. Positions saved in B223 load fine; y is now measured from the very top of the screen (a few dp shift at most). No snapping: it stays where it is dropped. Not compiled.

## B223 - minimize button on floating popups (widgets, notes, gallery)
- Ali's request: a button next to the x of any floating popup, especially Notes and Gallery, to move the window away temporarily instead of closing it, easy to move and restore.
- New strip/FloatBubble.kt: a 46 dp round overlay (first letter of the window), draggable anywhere (touch slop, clamped to the screen), tap = restore; position kept per window in prefs file "float_bubbles"; a second bubble starts lower so they do not overlap; exists only while something is minimized (no idle cost). show() returns false when it cannot be added, then the window is left as it was.
- strip/WidgetFloat.kt FloatWindow: "-" button before the x in the top bar (only when the top bar is shown); minimize() = bubble + root GONE + FLAG_NOT_TOUCHABLE, auto-close timer cancelled; restore() = back as it was, auto-close rescheduled; close() removes the bubble; press() restores first (a tile cannot be pressed in a hidden window); WidgetFloat.show(toggle) restores a minimized window instead of closing it.
- strip/FloatTools.kt ToolWindow (Notes, Gallery): same "-" button, minimize()/restore(), also NOT_FOCUSABLE while hidden so no keyboard; FloatTools.toggle restores a minimized window instead of closing it; close() removes the bubble.
- Not done: no close button on the bubble itself (restore, then x); minimized windows are not remembered after A is killed. Not compiled.

## B222 - saved tiles: edit after saving, list in the widget window, live both ways
- Ali's request: edit the Grab it window after the cell is saved; also save the tile in the widget window (a widget can have several buttons, e.g. Eitaa chats); edits in either place (or in the cell's raw text) update the other. Answers: deleting the cell keeps the tile; old tiles appear too.
- New strip/WidgetTiles.kt: TileRec(id, name, wid, pkg, details, action) kept in prefs file "widget_tiles" (+ string set "removed"). The link between tile and cell is the extra "tid" inside the cell's raw "Intent:" text, so cells keep working with no other change. reconcile(): (1) a cell whose raw text or name differs from its tile wins and updates the tile; (2) tile cells without tid (saved before B222) get a tid and a tile (identical cells share one tile); (3) a tile whose cell was deleted stays; (4) a tid with no tile (restored backup) recreates the tile; tids in "removed" are ignored. update(): rewrites the tile and every cell with that tid (nested folders too). remove(): list only, cells stay, tid tombstoned.
- strip/WidgetHostActivity.kt: reconcile in onResume (so edits made in the cells window show on return); "Saved tiles" list under each widget card (Edit, Test, Add as a cell when it has no cell, Remove with a confirm); Grab it dialog has an edit mode (title "Edit this saved tile", Save changes tile and all its cells) built by loadDraft(rec) from the raw extras; new tiles go to the list and the strip, plus a "Save here only" button. A tile shows under a widget when wid matches, or when its widget id is gone and the package matches.
- Not done: tile records are not in the settings backup (a restore recreates them from cells that carry tid; tiles saved with "Save here only" are lost in a restore). Raw edited into something that is no longer a widget press stops being a tile. Not compiled.

## B221 - A opens .afl files (import by tapping the file)
- Ali's request: like Automate opens .flo files, A should recognise .afl so he can import faster.
- New flow/FlowImportActivity.kt (translucent, no history, not in recents, exported): reads the file from VIEW data or SEND EXTRA_STREAM (or EXTRA_TEXT) with FlowShare.import / importText, toasts "Imported N script(s): names" or "That is not an A scripts file (.afl).", then opens FlowActivity with extra "flow" = first imported script (editor opens at once, so he can paste the raw shortcut). Nothing runs at import; same id overwrites the same script.
- AndroidManifest.xml: three intent filters. (1) VIEW, scheme content/file, host *, mimeType */*, pathPattern ending in .afl (4 variants for names with dots). (2) VIEW with mime application/x-afl. (3) SEND with application/x-afl and application/octet-stream (chat apps often send .afl as octet-stream with no extension in the path; A then shows in the share sheet for those files and the importer rejects non-.afl content with a toast). Label "Import into A".
- Not compiled. If a file manager does not offer A for the file, "Import shared flows" in Scripts still works.

## B220 - example scripts for the widget code (editable blocks)
- Ali asked for the actual scripts, built from the new blocks, editable in the canvas editor.
- flow/SeedFlows.kt: `examples` + installExamples(context) (adds only missing ones). Script 1 "Example: widget button missing": If widget button NOT found -> Shizuku `am force-stop mob.banking.android.resalat` -> wait 500 -> Open app (go back after 1500 ms) -> note about adding Run raw shortcut -> End -> Stop. Script 2 "Example: read code and paste": 2-minute rule (countdown, 120000 ms) -> If widget button found -> Read with OCR and wait (widgetnow, digits, 40000 ms, variable ocr) -> If ocr_found = yes: Copy text {ocr}, Wait for a field with the cursor (30000), Paste; Else: Countdown 120000 with a note to add the widget run again + another OCR wait. Package, times and source are values to edit in the blocks.
- flow/FlowActivity.kt: button "Add example scripts" in the Scripts list. The raw shortcut block is not pre-filled (it would fail empty): the note says where to add it. Not compiled.

## B219 - Previous app: killed-in-background tasks count, App Clone tasks count, report line
- Ali's report (installed build was b211, so B212-B218 were not on the phone yet): after leaving Eitaa with Back, Previous app said "nothing found" although Recents holds many apps.
- Likely cause (a fact from the code, not yet confirmed by a report): PreviousApp.parse() marked every task with "sz=0" as hiddenFromRecents. sz=0 is a task whose process was killed in the background; Recents still lists it and startActivityFromRecents restores it. On his RAM-starved phone most older tasks are like that, so only the live one (Eitaa) counted, and as the current app it was skipped. Now only FLAG_EXCLUDE_FROM_RECENTS and isAvailable=false mean hidden.
- counts(): a task of another user (user != 0, e.g. the vivo App Clone) skips isUsableApp (package list is per user).
- go(): one DiagLog.note line "Previous app: pkg#taskId uN vis hidden home skipped NO ... -> chosen" for the first 10 tasks, so the next report shows why an app was skipped ("NO" = does not count). Not compiled.

## B218 - Previous app: no launcher-icon steps, quick-switch without Shizuku
- Ali's request: return to the previous app exactly as left, only apps still in recents, nothing when none; Swiftly-Switch-style last-used list (already: Shizuku `dumpsys activity recents`, skips A, launcher, systemui, pickers, hidden-from-recents, frozen/suspended apps).
- utils/PreviousApp.kt resume(): removed step "replay the task's start intent" and step "launcher icon" (both land on the main screen). Order now: startActivityFromRecents -> moveTaskToFront(WITH_HOME) -> `am task lock` / `lock stop`; each checked with isFront().
- go(): the old fallback that started the app's launcher intent from the usage/tracked history is gone. With no readable Shizuku recents: if pickFromHistory (usage events / tracked) finds a valid previous app, quickSwitch() = accessibility GLOBAL_ACTION_RECENTS twice 170 ms apart (via OverlayRuntime.accessibilityService.performSystemAction(RECENTS)), lastHow = "accessibility quick-switch (Recents twice)" (shown by the Test button); else the existing "nothing found" message (bar or toast option). Vivo (Funtouch) may treat double Recents differently: unverified, ask Ali for the Test text if it fails. Not compiled.

## B217 - OCR boxes are in the backup
- strip/SettingsBackup.kt: the scripts part ("A only scripts" and "A all settings") now carries "ocrBoxes" (prefs file ocr_boxes) and "ocrBoxAliases" (ocr_box_aliases) as name -> text; restoreOcr() writes them back when scripts are restored (same names replaced, other boxes stay; undo-last-restore does not remove boxes a restore added). Older backups without these keys restore as before. Needs SettingsBackup.init (already called from the Application). Not compiled.

## B216 - renamed OCR boxes keep working
- Ali picked option 3 (boxes follow renames). Done without turning boxes into flows: strip/ScreenOcr.kt keeps a second prefs file "ocr_box_aliases" (old name -> new name, like FlowStore aliases). renameBox records it, saveBox clears an alias of the same name, new currentName(app, name) follows the chain (max 8 hops) and box() uses it, so the OCR shortcut, OCR wait block and old cells that still say the old name find the renamed box. Delete does not clear aliases (harmless).
- Rename dialog in the Scripts list now says so. Not done: boxes as real flows (id, in the flow backup) - ocr_boxes prefs may not be in the settings backup; check SettingsBackup if Ali wants boxes backed up. Also verified: clip_set substitutes {variables} (FlowRunner sub(s.b)), no change needed. Not compiled.

## B215 - Save-tile dialog: "Open an app first" hidden unless used
- strip/WidgetHostActivity.kt StepsBlock: the "Open an app first" chooser is gone for new cells (a Scripts block does it); a cell that already has one still shows it with Clear and its wait box, so old cells keep working. A hint says to add a script as a shortcut.
- Kept on purpose: the "+ Add a shortcut" lists (they are the only way to attach a My Script to a widget cell); removing them would lose that. Ask Ali only if he still wants them removed. stepPick 3 is now unused code. Not compiled.

## B214 - OCR boxes in the Scripts list
- Ali's answers: boxes appear BOTH in the normal Scripts list (marked "OCR box: name") AND in an "OCR boxes only" view; old boxes are not important; OCR pickers keep boxes plus widget / USSD choices (unchanged, ActionArgs "ocr_area" and the OCRWAIT form already do that).
- Storage unchanged: boxes stay in prefs file "ocr_boxes" (ScreenOcr.boxNames/saveBox/renameBox/deleteBox); the Scripts list shows them as virtual rows, so every old box appears at once and nothing is migrated. They are not real flows (no id, not in backups of flows, not selectable with the flow checkboxes).
- flow/FlowActivity.kt: resumeTick (refresh on onResume), buttons "Show OCR boxes only" and "New OCR box", box rows first in the list (search also matches "ocr"), tap a row -> dialog: Draw it again on the screen / Rename / Delete. Renaming does not update shortcuts that already use the old name (stated in the dialog).
- strip/OcrActivity.kt: extras "boxnew" (true) and "boxredo" (box name) start boxPick at once; fromScripts makes bringBack() return to FlowActivity (REORDER_TO_FRONT) and finish.
- Not done: the old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (ask Ali). Not compiled.

## B213 - built-in "Open an app" can go back after a time
- utils/HandlerActions.kt: launchApp(pkg, backMs = -1) stores "Launch app:<pkg>|back=<ms>"; launchedPackage() ignores the suffix (so every old caller, name and icon still works); new launchedBackMs(action) (null = stay open).
- service/OverlayController.kt: the Launch-app action with a back time runs WidgetFloat.openThenBack(context, pkg, ms) on a thread (same logic as the script block and Grab it).
- ui/screens/strip/ActionPages.kt (BuiltInPage): after picking an app a dialog asks "Stay open" / "Go back after a time" (ms box, default 1500). onPickApp is now (InstalledApp, backMs) -> Unit; the 4 callers updated (StripEditorScreen, SegmentPickerUi, ShortcutActivities, WidgetHostActivity). The older ActionPicker.kt app path is unchanged (stay open only).
- Not done: old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (ask Ali), B214 OCR boxes as Scripts items (design still to be agreed with Ali). Not compiled.

## B212 - universal script blocks (part 2): OCR wait, countdown, wait for a field, rate limit
- New block types in flow/Step.kt (all are plain linear blocks, run in FlowRunner.exec): OCRWAIT (a = source "box:<name>" | "widget" | "widgetnow", b = digits | text | both | word:<w>, c = ms, d = variable; also sets ocr_found yes/no), COUNTDOWN (a = ms, b = text), FIELDWAIT (a = ms; sets field_found yes/no), RATELIMIT (a = name, b = ms between runs, c = countdown | wait | stop, d = text; last run time kept in prefs file "flow_limits").
- strip/ScreenOcr.kt: waitRead() (written text first through the text reader, picture only for digits, same value twice in a row, one DiagLog line "OCR wait: ..." per run, returns "" on timeout, no error) and waitField(). Widgets are digits only (WidgetFloat.readNow got a timeoutMs parameter). strip/TextReaderService.kt: hasInputFocus() (focused editable node).
- New file flow/Countdown.kt: dark pill overlay at the top, not touchable, removed when done (toast when overlay is not allowed).
- flow/FlowGraph.kt Interpreter: after a block, vars["__stop__"] makes the flow stop (used by RATELIMIT "stop").
- Editor: FlowCanvasEditor catalog entries and forms ("Read with OCR and wait", "Countdown", "Wait for a field with the cursor", "Limit how often (2-minute rule)"), BlockForm now saves d too; FlowPickers.variablesIn lists ocr, ocr_found, field_found; FlowCanvasView titles.
- Copy to clipboard and Paste already exist as "Device: Copy text to the clipboard" (argument {ocr}) and "Device: Paste into the focused field". Not changed: the old "Open an app first" / "Add a shortcut" lists in the Save-tile dialog (still there, to be removed once Ali agrees), the built-in shortcut "Open an app" go-back option. Not compiled.

## B211 - universal script blocks (part 1): widget button found, open app and go back, raw shortcut, run widget again
- Principle (Ali): anything he asks for should be buildable by the user as a Scripts (flow) block, not hard-coded, like Automate; blocks are reused so the app stays small.
- strip/WidgetFloat.kt: pressState (0 none, 1 looking, 2 pressed, 3 tile not found) set by press()/FloatWindow.press()/handleNow(); waitPress(maxMs) blocks until settled; openThenBack(app, pkg, ms) = the Grab it "open an app, wait, go back" logic (warmUp + wait + PreviousApp.go + 600 ms), now also used by handle() for the cell's warm-up app. handle(): new extras "again", "againMs", "post2", "post2Ms": after the after-shortcuts the same tile is pressed again, then post2 shortcuts run.
- flow/NativeActions.kt check(): is("widgetbutton") waits up to 60 s for the last widget press and answers found / not found.
- flow/FlowCanvasEditor.kt: Decision -> "Phone state" -> "Widget button" (was found / was not found). Open app block: "Stay open" or "Go back after a time" (ms box; stored in Step.b). New catalog entry "Run raw shortcut (paste it)" = Step.INTENT with b = "raw" (text field + paste button); FlowRunner strips a leading "Intent:" so a cell's stored action text can be pasted as it is.
- flow/FlowRunner.kt LAUNCH uses openThenBack when b is set; flow/Step.kt, flow/FlowCanvasView.kt: labels.
- strip/WidgetHostActivity.kt (Save this tile as a cell): toggle "Run the widget again after the shortcuts above", wait box, and a third list "Shortcuts after the second run" (stepPick 4; Draft.again/againMs/post2/post2Ms).
- Not done on purpose: the old "Open an app first" and the two "Add a shortcut" lists stay in the Save-tile dialog until scripts can fully replace them (B212). The built-in shortcut "Open an app" (BuiltInPage onPickApp, many callers) has no go-back option yet: only the script block has it. Not compiled.

## B210 - OCR diagnostics
- strip/ScreenOcr.kt: read(app, saved, given, boxName) now wraps readCore() and writes ONE line per run to A's report (DiagLog.note "OCR run: path=... text=... box=... top=... tries=... lastPicture=... ms=... result=..."). path says which reader gave the answer: "text", or "text ignored (no digits), then picture", "text empty, then picture", "text reader off, then picture". top = screen on top when the run started (dumpsys, through Shizuku).
- Behaviour change in readCore(): written text from the text reader that has no digit (Character.isDigit, so Persian/Arabic digits count) is ignored and the picture reader runs. Suspected cause of the bug "later runs paste the bank name": the text reader returned "Risalat Banking" before the picture was read. Still a guess until a report shows the line.
- flow/NativeActions.kt: the box name is passed to read(boxName = name) so the line shows it. Not compiled.
- Next: B211 (OTP button not found: force-stop bank app, reopen, move its window away; 2-minute OTP block with countdown; needs the bank app package name), then B212 (OCR boxes saved into Scripts as OCR items).

## B209 - bank widget return fix (ReturnGuard)
- strip/ReturnGuard.kt: topPackage() now also reads the resumed screen's class name (topAct). If the top app is A itself but the screen is not the tapped one (for example LauncherModeActivity after the bank's screen closed), it runs "am start -n a.a/<screen> -f 0x20000" and clears the "other app" mark. Before, a.a on top was always treated as fine. Nothing else changed. Not compiled.

## B208 - OCR named boxes, version code follows the build number, Home entry renamed
- app/build.gradle.kts: versionCode = buildNo (the GitHub run number) when it is a number, else 42, so every build is a real update.
- OCR shortcut (ocr_area): the argument list no longer has "choose it when it runs" or "last saved part". It lists the NAMED BOXES made in the OCR screen (section 4: New box / Rename / Drag again / Delete; prefs file "ocr_boxes", name -> l,t,r,b as screen fractions) plus selected widget, widget on screen now and USSD, each as Copy it / Copy and type it. Stored argument: "copy:box:<name>" or "type:box:<name>". Old values "copy", "copy:region", "type", "type:region" still run and show a label. ActionArgs.specFor(id, ctx) takes a context to name the boxes; ScreenOcr.read(app, given = region). Renaming a box does not update shortcuts that already use the old name.
- Manifest: LauncherHomeActivity (the temporary launcher mode HOME entry) has its own label "A Home", so launchers that list it no longer show a second "A". Nothing in .kt changed. Not compiled.

## B179 - fix B178 (duplicate manifest activities) + separate "Build errors" notification
- B178 failed lint: the widget block copied from B177 dragged the rest of the manifest with it (21 DuplicateActivity). Now only the 4 widget activities are added.
- GitHubBuild: when the watched run ends in failure, fetchFailureLog() is posted as its own notification (channel "build_error", importance HIGH, id 7315, so the user can give it a sound in Android's channel settings). Tap or "Copy error" copies the full report (saved as ghLastError) via ButtonReceiver ACTION_COPY_ERROR. The normal status notification is unchanged. Uncompiled.

## B178 - merge of B176 (cells Look dialog, name outline, folder look) and B177 (widgets)
- Base = B176. Added from B177: strip/WidgetHostActivity, WidgetFloat, WidgetFloatActivity, WidgetKit (hosts other apps' widgets, e.g. Eitaa chats, floating widget window), their 4 manifest entries, "Widgets" buttons in Launcher mode (LauncherHomeActivity + LauncherModeActivity), ActionSaver.saveToCells(icon) parameter, "Widgets/Launcher mode" name (strings + cells editor button).
- Kept from B176 (B177 was older): LookDialog/LookPrefs, HtmlViewerTools, Flow.links, "Open an app" inside the pickers, Scripts row on the main screen, stripGapPct edge gap. Uncompiled.

## B176 - "Look of the cells": name outline + size, own look for folders, live view inside
- New file ui/screens/strip/LookDialog.kt replaces the old AlertDialog in StripEditorScreen. Full-screen dialog: the same StripView as the editor stays on top (true size, shrunk only to fit, tap a cell to light it, preview background Dark/Grey/White/Both saved as `stripLookPreviewBg`), settings scroll below. Tabs: Cells window | Folders.
- New settings (cells and folders): `stripLabelPct` (names under icons, 50-200, default 100), `stripOutlineColor` (0 = none, else ARGB), `stripOutlinePct` (thickness, % of text size, default 14). StripView.drawLabel draws a stroke pass then the fill; the lit cell and the thumb popup get no outline. FitText.draw got optional strokeColor/strokePct (no-icon cells).
- Folders: strip/LookPrefs.kt. Every look key has a folder twin `stripF<Name>` (stripFLook, stripFTileColor, ...). StripView(folderLook = true) reads the folder key if it exists, else the cells key, so nothing changes until the Folders tab is used. "Folders follow the cells window again" clears all stripF* look keys. OverlayController.openFolder passes folderLook = true; the editor view uses it when inside a folder (path not empty).
- Bigger names (>100%) move the icon up a little and the name down a little; long names still shrink to the cell width (+30% of the extra). Uncompiled.

## B174 - HTML viewer controls: position, line, hide time
- Settings (HtmlViewerUi.showSettings): side (right/left) for bar + buttons, buttons at top / middle / bottom (bar keeps clear of them; in the middle they sit beside the bar), switch for the faint line along the whole bar (`showTrack`), hide delay in milliseconds (`hideMs`, default 3000, min 200). Uncompiled.

## B173 - separate windows in Recent apps, HTML viewer controls, cells "Look"
- Manifest: documentLaunchMode="intoExisting" on GitHubSettings, Shell, Sides (segments), Flow (scripts), Downloads, AllApps, LauncherMode and the HTML viewer, so each is its own entry in Recent apps. Not changed: WifiShare (singleTask + share target), Cells/Appearance/Backups (inside MainActivity's Compose screens).
- HTML viewer: share/HtmlViewerUi.kt (plain views): blue quick-scroll bar on the right + three round buttons above it (screen mode cycling both bars / status only / nav only / full screen; stay awake; settings), all shown by scrolling or touching and hidden after 3 s idle; floating clock when the status bar is hidden (4 corners or dragged, saved); settings dialog (show bar / mode button / awake button / clock / corner / own Recent-apps window). Prefs file "html_viewer". The own-window option swaps two manifest entries: HtmlViewerActivity (document task, enabled by default) and HtmlViewerSameTaskActivity (disabled by default) via share/HtmlViewerSwitch.kt; Appearance "Show A HTML Viewer" switch and the "Open a file" action use it.
- StripView look (prefs stripLook 0/1/2, stripBackdropPct, stripHalo): 1 = icons only with no tiles/panel and bigger icons, 2 = icons only on a very faint dark panel (slider), halo = blurred dark outline behind icons and names. Editor: "Look of the cells" button. Uncompiled.

## B172 - fix B171 compile error
- B171 failed: maxWidth (BoxWithConstraints) was used inside a Column lambda (DSL_SCOPE_VIOLATION); it is now copied to availW before the Column.

## B171 - cells window true size, outside fields drawn as they really work
- Editor (StripEditorScreen): the cells window is no longer shrunk by the fields; it is the same size as on screen. The fields take the space left around it (thickness 22-56 dp).
- Switch off = only the fields fade (alpha 0.4); the cells window stays clear.
- Fields are drawn with the real geometry of OverlayController.outsideAt: side furthest past wins (corners cut at 45 degrees), equal parts along the window, end fields reach past the window corners. Tap hit-test uses the same rule. Only a strip of the fields can be shown (on screen they go to the screen edge).
- The −/+ per side moved from the corners to a row above the grid (EdgeCounts). Old EdgeCorner/EdgeSideFields removed. Uncompiled.

## B170 - fix B169 compile error + build notification opens the runs window
- B169 failed: actionDisplayName is @Composable and was called from a plain function/remember; edgeActionName(context, action) is now plain Kotlin.
- The build notification (id 7311, also the "A build FAILED" one) opens GitHubSettingsActivity with extra openRuns=true; GitHubSettingsDialog(openRuns) then loads and shows the workflow runs window by itself (Error report / copy there).

## B169 - base = B168-icons (B168 fields + the other account's icons-in-backup)
- Fresh install now starts from his own settings: assets/settings_default.json = his "A all settings" backup minus GitHub/auto-backup/personal run state (gh*, autoBackup*, isRunning, shellHistoryV1, ...). SettingsBackup.applyBaked applies settings AND scripts (strip + flows + sides); firstLaunch=false in it, so the tutorial walkthrough is skipped. Cells with an `img:` icon in that backup have no picture (the backup had no "icons" part): re-export with a build that has icons, then re-bake.
- Outside fields are drawn on the cells grid in the editor (EdgeFrame in StripEditorScreen): −/+ in the four corners cut each side into 1-6 equal fields at real length, tap a field = same ItemEditor as a cell (shows current action/name/icon, icon undo/redo). The old "Action outside of cells window" button/dialog is gone; the On switch is above the grid. Storage/helpers: strip/EdgeFields.kt (field meta = name+icon in `<key>Meta`). Segments keep their own dialog (SidesActivity).
- Device actions are now inside the built-in shortcuts list (BuiltInPage onPickAction, NativePicker.groups()/choose(), utils/DeviceActionIcons.kt); the separate "Device actions" buttons are removed from the cell editor, segment picker and the other-apps picker. The main Actions screen picker (ActionPicker) still has its own Device actions button.
- Click circle icon = utils/ClickCircleIcon.kt (ring + dot, like the circle drawn on screen).
- Uncompiled.

## B168 - more fields per outside side
- "Action outside of cells window": each side (Top/Left/Bottom/Right) can be cut into 1-6 equal fields, each with its own action (+/- stepper above that side's rows). 1 = old behaviour. Main: prefs `stripEdgeCnt<Side>`, field i>=1 = `stripEdge<Side>_<i>` (field 0 is the old `stripEdge<Side>`). Segments: `Seg.edgeMore` JSON (key "em"), helpers edgeCount/edgeAct/withEdgeAct/withEdgeCount.
- Fields are measured along the main cells window (left to right above/below, top to bottom beside), end fields reach past its corners. Zone = where the thumb is. Corner rule unchanged (furthest-past side wins).
- Segments that "follow main" use the main's fields; when mirrored, Left/Right swap as before and above/below fields run reversed. Own segment actions are never mirrored.
- Code: OverlayController.outsideAt / edgeCountFor / edgeActionFor; StripEditorScreen edge dialog; SidesActivity edge dialog. Uncompiled.

## B167 - everything is just "A"
- Source package is now `a.a` (was com.newagedevs.gesturevolume): folders under app/src/main/java/a/a and app/src/test/java/a/a, namespace "a.a", rootProject.name "A", themes `ATheme` / `Theme.A`.
- Shared flow files are `.afl` (marker "afl" inside, flow ids travel with the flows).
- Left on purpose: GitHubBuild.kt and SharedPref (they find the repo workflow `gesturevolume.yml`, release tag `gv`, and his zip names), assets/automate_flows.json (names of his GitHub release assets), LEGACY_CHANNEL_ID (it deletes an old notification channel), external URLs (privacy, terms, upstream source).
- Earlier in B162-B166: flow ids and rename-safe links (FlowStore: "#id" refs + aliases), flow list with multi-select (delete / duplicate / share / rename), tap-to-choose canvas forms (flow/ActionArgs.kt, flow/FlowPickers.kt), Volume boost as its own screen with stream and output scope (utils/VolumeBoost.kt, ui/screens/boost), Previous app resumes the task (utils/PreviousApp.kt).

## Accessibility service gets dropped (open)
- Report shows A's entry missing from enabled_accessibility_services at every disconnect; the list holds Undo, Automate (two services) and Universal Copy.
- Found in assets/automate_flows.json: several of his Automate flows run `settings put secure enabled_accessibility_services <whole list>` ("Toggles - Accessibility Services Enable", "Re-enable Accessibility Service", "Auto Enable Accessibility"). Any of them overwrites the list and drops A. Not proven to be the cause.
- B167 added to the report: pid on service CONNECTED / UNBOUND / DESTROYED / INTERRUPTED, a verdict on every list change ("A removed ALONE" vs "LIST REPLACED"), and at each disconnect: the raw list, `dumpsys accessibility`, install/update times and pid. Command labels are no longer cut.

## How to work with him
Ali, Persian/English, voice dictation ("ID" = "idea"). Lean replies, accuracy over speed, talk first for big things. NOT a developer: Automate-style boxes and forms, pick from lists, no formulas or code. Zero idle RAM. Never wait for a double tap. Deliver the zip only (no YML), name the build number, bracket-check changed .kt against the originals. Claude cannot compile Android: he builds on GitHub Actions (repo alichiddy/mutetest) and pastes errors.

## Still to do (his list)
Ask block; Show message "notification" target; Wait until (conditions from lists, timeout); Screen block via Shizuku; Accessibility "Interact" block; FIUSR asks which user; USSD flows.

---- Older notes below ----

# HANDOFF: native replacement for the Automate cells

Base: GestureVolume B56 (with the VolumeUp import fix and the "Resume build status" action).
This change adds an in-app action engine and built-in flows so the strip's cells no longer need Automate.
It could not be compiled where it was written: if GitHub reports `e:` lines, they point at the files below.

## New files (all in `flow/`, so merges stay easy)
- `NativeActions.kt`: every built-in action (id, label, what it needs). Ids starting with `A:` run one of A's own actions (Screenshot, Power menu, Shell runner...).
- `SeedFlows.kt`: the built-in flows (one per old Automate cell) and the table that maps old `Flow:468/233`-style cells to them. "Install my cells and flows" in the Flows screen runs it.
- `FlowHelpers.kt`: `PrivateValues` (keys/codes, stored in the separate `PrivateValues` prefs file, never in the settings backup or a cloned APK), plus two see-through helper activities (clipboard read, file pick).
- `assets/scripts/*.sh`: shell scripts copied exactly from the old Automate flows (`@PKG@`, `@MASK@`, `@TARGET_USER@` are filled in at run time).

## Changed files
- `flow/Flow.kt`: three new step types (`act`, `psh`, `bcast`).
- `flow/FlowRunner.kt`: runs them; fills `{name}` from PrivateValues; a missing-Shizuku step shows a message and opens Shizuku instead of failing.
- `flow/FlowActivity.kt`: action picker, "My values", "Install my cells and flows", "Allow usage access".
- `ui/screens/shell/ShizukuGrantRow.kt`: button label is now "Load My Automate".
- `AndroidManifest.xml`: 2 helper activities, PACKAGE_USAGE_STATS, WRITE_SECURE_SETTINGS, READ_PHONE_STATE, ACCESS_WIFI_STATE.
- `assets/grant.sh`: also grants usage access, secure settings, phone state, call phone, mock location (for the map in the next step).
- `utils/GitHubBuild.kt`, `HandlerActions.kt`, `HandlerActionCatalog.kt`, `OverlayController.kt`, `strings.xml`: "Resume build status" action (watch a build already started, no re-upload).
- `utils/HandlerActionCatalog.kt`: VolumeUp import fix.

## Rules of the engine
- NONE: works with the permissions A already has. ONCE: needs the one-time secure-settings grant (Grant button via Shizuku), else falls back to Shizuku. BETTER: opens the system panel without Shizuku. SHIZUKU: needs Shizuku every time.
- Steps can be marked "skips quietly without Shizuku" (`c = "optional"`).
- Never put real keys in source: use `{name}` and a slot in `PrivateValues.slots`.

## Not done yet
Fake-GPS map screen, Google Drive upload with sign-in, QR generator, the accessibility tap in WShr, Lens sharing step in LNS.
Five cells (2GOnly, WShr, DSave, PWR, WG Tunnel All) point at statement ids that are newer than the Automate backup this was built from: they were mapped by label. Verify them.

## B59 (on top of B58): messages, windows, wireless fixes
Touches only my files plus one line in `OverlayController.kt` (the "last result" bar in the `MyFlow:` branch).
- `FlowHelpers.kt`: `FlowPrefs` (message-bar mode: always / messages and failures [default] / only failures; button in the Flows screen) and `ResultActivity` (a window that stays until closed, with Copy).
- `FlowRunner.kt`: Message steps with `c = "window"` open the window; action results that should stay (uploads, grant/revoke, diagnostics) open it automatically (`NativeActions.staysOnScreen`).
- `NativeActions.kt`: Bluetooth tries `svc bluetooth` then `cmd bluetooth_manager` and checks the result; hotspot tries each stop/start command, checks the result and shows what the phone answered; new `wireless_diag` action; `bgshell` output is now `$ command` then the output (and `[exit N]` on failure), and `plain` copies nothing and uploads nothing.
- `SeedFlows.kt`: WifiOn and ALOF use the hotspot action. Existing installed flows are not overwritten: delete them in the Flows screen and press "Install my cells and flows" again to get the new versions.

## B60: Lens OCR ("NOW ON TAP") as one native action
- `NativeActions.kt`: new `lens_ocr`: runs `lensnet.sh prep` (stop VPNs, cut Wi-Fi/data, screenshot to /Documents/screenshot.png), opens it in Google Lens through A's FileProvider, waits until Lens/Google is left (max 3 min), then always runs `lensnet.sh on` (restores Wi-Fi and data, also when something fails).
- `AndroidManifest.xml`: FileProvider `${applicationId}.files`; new `res/xml/file_paths.xml`.
- `SeedFlows.kt`: LNS is now just `lens_ocr`. Delete the old LNS flow and press "Install my cells and flows" to get it.
- Needs "All files access" (the Grant button) so A can read the screenshot Shizuku's shell wrote.
- Not done: always-on automations (copy OTP, actions when apps open, unlock/charger/Wi-Fi triggers). They need a trigger engine; it touches `OverlayService` (start line), `GestureAccessibilityService` (app-in-front event) and the manifest (SMS receiver).

## B61: "Save to Downloads" in the share sheet
- New `share/SaveToDownloadsActivity.kt` + manifest entry: A appears in every app's share sheet as "Save to Downloads" and writes files (or shared text) into Download through MediaStore (no storage permission on Android 10+; `WRITE_EXTERNAL_STORAGE` maxSdk 28 for older phones).
- In a second profile (dual apps) with Shizuku ready it also copies the file to the main profile's Download folder (`/data/media/0/Download`). That copy is best effort and untested.

## B62 – Automations (always-on rules)
New package `app/src/main/java/com/newagedevs/gesturevolume/auto/` (Automations.kt, AutomationsScreen.kt). Rules (trigger, arg, flow) live in prefs "AutoRules". Triggers: SMS received (flow vars {otp},{message},{sender}), app opened (UsageStats poll, 2 s, screen on only), unlock, charger on/off, Wi-Fi connected, app installed. Seed flow "CopyOTP" (added from the screen's "Copy OTP from texts" button).
Existing files touched (one small edit each):
- AndroidManifest.xml: permissions ACCESS_NETWORK_STATE, RECEIVE_SMS; receiver `.auto.SmsRuleReceiver` (BROADCAST_SMS).
- service/OverlayService.kt: one line in onCreate: `Automations.start(this)`.
- flow/FlowActivity.kt: `autos` state, branch to `AutomationsScreen`, "Automations" button.
- assets/grant.sh: `pm grant … RECEIVE_SMS`.
Untested/uncompiled.

## B63 – merge of the other Claude's B59 (Automate-flow converter) + my B62
Three-way merge (base B58). Taken from the other Claude: Expr.kt, AutomateFlows.kt, assets/automate_flows.json, Flow.kt, FlowRunner.kt (goto-run, expr conditions, for-each), importedSlots in FlowHelpers.kt, NativeActions additions, "Add my Automate flows" button.
Kept from mine: FlowPrefs/ResultActivity, MESSAGE "window", Save to Downloads, Automations (auto/), Lens etc.
Only two hand-resolved spots: FlowRunner (WAIT = his expr version; MESSAGE = my FlowPrefs/window version) and FlowActivity (both buttons kept). Uncompiled.
