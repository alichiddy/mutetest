# HANDOFF - B316 (from B315), not compiled. Next build: B317

## Working with Ali
- Not a developer; Persian/English; voice dictation ("ID" = idea). Calls Claude "Habibi". App = "A" (package a.a, repo alichiddy/mutetest), built on GitHub Actions; he pastes build errors.
- Lean replies, accuracy over speed, talk first before big changes. He hits his usage limit if he talks too much: do ONE step, then ask him to say "continue".
- Everything in the app = boxes, forms, lists (no code/formulas). Zero idle RAM. Never wait for a double tap.
- Deliver the zip only (no YML), name the build number, bracket-check changed .kt files against the originals. Claude cannot compile.
- Terms: "Cells window", "Segments", "Scripts" (not "flows"), "buttons" for widget buttons, "tile" only for Quick Settings tiles, no "strip" in texts.

## Goal (his words)
Make every window feel like the original main app: same design, buttons and better wording as the Cells window (B305). One window group per zip.

## Done
- B305: Cells window rebuilt in card design.
- B307: Widgets host + both Launcher windows.
- B310 = B309 + fix (ChoiceChip: pass onClick = named, trailing lambda goes to `modifier`). B309/B310 (step 1 of the script block editor): top bar of flow/FlowCanvasEditor.kt now AWindowPage (back arrow = save & close, script name, Add + Run icons); Stop/Undo/Redo/Fit/Always On/Delete script in a row under it. AWindowPage got an optional `actions` param.
- B311: script block editor step 2: Add-a-block dialog and long-press menu now in card rows (flow/FlowCanvasEditor.kt: Blocks / Device actions groups, SettingRow + cardShape, MenuEntry list). Begin block title now "Start of the script" (flow/FlowCanvasView.kt).
- B312: script block editor step 3(b): block edit form BlockForm now in cards (flow/FlowCanvasEditor.kt: FormCard / FormHint / ChooserRow helpers, each option group in its own card, chooser rows for app/shortcut/script/action); ChoiceRow in flow/FlowPickers.kt now draws the app's ChoiceChip. Logic unchanged.
- B313: script block editor step 3(c), which finishes the block editor: new flow/DeviceActionPicker.kt (Compose cards: searchable list of device actions with icons, then On / Off / Toggle rows, then the argument: choice rows, or Which sound + How loud, or a text box). Same action strings and names as NativePicker.pick, so nothing stored changes. The block form's Action row opens it. flow/FlowPickers.kt: NumberPick uses the round - / + (StepButton, now internal in ui/screens/strip/StripRows.kt) and disables them at min / max; "Another name..." / "Another word..." are now chips at the end of the same row (new ChoiceRowWith); a hand-typed variable name shows as chosen. FormCard / FormHint in FlowCanvasEditor.kt are now internal so the picker reuses them.
- B314: Cell Settings step 2(a): the last two old plain-Android device-action dialogs now use the Compose DeviceActionPicker. DeviceActionPicker got an optional `startGroup` (opens straight at On / Off / Toggle or the argument, no list). ui/screens/strip/ActionPages.kt BuiltInPage: state `pickingDevice` + `DeviceActionPicker(startGroup = group)`; ui/screens/handler_action/ActionPicker.kt: "Device actions" button sets `pickingDevice`. NativePicker.pick / choose / withArg deleted (NativePicker keeps groups, label, run, isNative, isValid).
- B315: Cell Settings step 2(b): "Look of the cells" (ui/screens/strip/LookDialog.kt) now in the card design: AWindowPage top bar inside the full-screen Dialog (back arrow = Done), Cells window / Folders as chips, live view in a rounded box with "Behind it" chips, then CardGroups: How the cells look, Names under the icons, Size and colour, Pinned cells, Folder cells. New private rows SliderRow / PickCardRow / ColorCardRow (each wrapped in key(id) so conditional rows do not shift remembered state); conditional rows follow hoisted state (look, outline, pinDot, pinText, foldPrev, foldArrow). Same pref keys and values, logic unchanged. search_index.json re-made.
- B316: Cell Settings step 2(c): "Gap, popup and effects" now in the card design: new ui/screens/strip/GapPopupDialog.kt (full-screen Dialog + AWindowPage, CardGroups Gap / Popup under the thumb / Outside the cells window; own state, reads and writes the same keys stripGapDp, stripTipOn, stripTipPct, stripTipGapDp, stripEdgeFx, stripEdgeTick). StripEditorScreen.kt: old AlertDialog replaced by one call, the six unused state vars removed. SliderRow and PickCardRow in LookDialog.kt are now internal (reused). search_index.json re-made.
- B308: Scripts list (flow/FlowActivity.kt), My values (now reachable from Options), Automations (auto/AutomationsScreen.kt).

## Plan (in order)
1. Script block editor: DONE (top bar B309, menus B311, block form B312, pickers B313).
2. Cell Settings submenus: (a) device-action pickers DONE (B314). (b) Look of the cells DONE (B315). Gap/popup/effects DONE (B316). Still to do, one per zip: Previous app, Click circle, Folders and touch dialogs (all in ui/screens/strip/StripEditorScreen.kt and ActionPages.kt), the Widgets/Launcher dialogs again if any left.
3. Shell runner (ui/screens/shell: ShellActivity.kt, OtgDialogs.kt, ShellHistoryDialog.kt).
4. The buttons at the top of A's main window (Copy report, Backup, ...: ui/screens/main/MainScreen.kt, ReportDialog.kt, BackupDialog.kt, LanguageDialog.kt, ThemeDialog.kt, SearchDialog.kt) and the window inside each.
5. Then Sides, All apps, GitHub settings, OCR, HTML viewer.

## How to restyle (reuse, do not invent)
- ui/components/AWindow.kt: AWindow {} (A's theme + light/dark choice) wraps an activity; AWindowPage(title, onBack) {pad->} = top bar like the Cells window. Separate activities were drawn in plain Material colours until wrapped.
- ui/screens/strip/StripRows.kt: CardGroup{row{sh->}}, SettingRow, SwitchRow, StepRow, ChipsCardRow, ChipsRow, LinkRow, ToggleRow/StepperRow (dialogs), InfoArrow. Long text goes behind the "Info" arrow. GroupHeading, cardShape, rowColor in ui/components/RowKit.kt; ChoiceChip.
- Buttons: use a.a.ui.motion Button/OutlinedButton/TextButton/IconButton (press bounce), not material3.
- Icons.Filled.X needs its own import each (only icons already imported elsewhere are known to exist: Add, Apps, Check, Checklist, Close, ContentCopy, Delete, Download, Edit, Home, Info, Lock, Notifications, PlayArrow, Search, Share, Star, Terminal, Tune, Visibility, Widgets).
- Change UI only; keep logic. Lambdas of CardGroup/row have a receiver: write this@Activity, not this.
- If screens/labels change, re-run: python3 tool/make_search_index.py

## Kept on purpose
- Old names GitHubBuild.kt/SharedPref (workflow gesturevolume.yml, release tag gv), assets/automate_flows.json.
- Never put real keys in source (PrivateValues slots).
- When adding a feature, say if it is a user-buildable script block or a built-in.
