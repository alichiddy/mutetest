package a.a.service

import android.view.Surface
import org.junit.Assert.assertEquals
import org.junit.Test

class HandlerGeometryLandscapeScaleTest {

    private fun frame(width: Int, height: Int, rotation: Int) =
        HandlerGeometry.Frame(width, height, 0, 0, 0, 0, 1f, rotation)

    @Test
    fun `portrait is not scaled`() {
        assertEquals(1f, HandlerGeometry.landscapeHeightScale(frame(1080, 2400, Surface.ROTATION_0)), 0.001f)
    }

    @Test
    fun `landscape scales by height over width`() {
        assertEquals(1080f / 2400f, HandlerGeometry.landscapeHeightScale(frame(2400, 1080, Surface.ROTATION_90)), 0.001f)
    }
}
