package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import a.a.utils.DiagLog
import a.a.utils.ShizukuShell
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Reads digits from any part of the screen (a widget, a USSD window, any app). The person drags a
 * box over what to read; A then takes screenshots through Shizuku, cuts out that box and reads it
 * with [OtpOcr] until the same digits show up twice in a row. Nothing stays in memory afterwards.
 */
object ScreenOcr {
    class Region(val rect: Rect, val screenW: Int, val screenH: Int)

    private fun pos(app: Context) = app.getSharedPreferences("otp_ocr_pos", Context.MODE_PRIVATE)

    /** Remembers a box as fractions of the screen, so the shortcut can read the same place again by itself. */
    fun saveRegion(app: Context, r: Region) {
        val w = r.screenW.coerceAtLeast(1).toFloat()
        val h = r.screenH.coerceAtLeast(1).toFloat()
        pos(app).edit().putFloat("l", r.rect.left / w).putFloat("t", r.rect.top / h)
            .putFloat("r", r.rect.right / w).putFloat("b", r.rect.bottom / h).apply()
    }

    fun savedRegion(app: Context): Region? {
        val p = pos(app)
        if (!p.contains("l")) return null
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val box = Rect((p.getFloat("l", 0f) * w).toInt(), (p.getFloat("t", 0f) * h).toInt(), (p.getFloat("r", 1f) * w).toInt(), (p.getFloat("b", 1f) * h).toInt())
        return if (box.width() < 10 || box.height() < 10) null else Region(box, w, h)
    }

    // ---- Named boxes ("Box 1", "156"...): each is a part of the screen kept as fractions of it.
    // The OCR shortcut picks one by name and reads it by itself.
    private fun boxes(app: Context) = app.getSharedPreferences("ocr_boxes", Context.MODE_PRIVATE)

    fun cleanName(s: String): String = s.replace(Regex("[:|\\n\\r]"), "").trim().take(40)

    fun boxNames(app: Context): List<String> =
        boxes(app).all.keys.sortedWith(compareBy<String>({ it.toIntOrNull() ?: Int.MAX_VALUE }, { it.lowercase() }))

    fun nextName(app: Context): String {
        val have = boxNames(app).toSet()
        var n = 1
        while ("Box $n" in have) n++
        return "Box $n"
    }

    fun saveBox(app: Context, name: String, r: Region) {
        val w = r.screenW.coerceAtLeast(1).toFloat()
        val h = r.screenH.coerceAtLeast(1).toFloat()
        val v = "${r.rect.left / w},${r.rect.top / h},${r.rect.right / w},${r.rect.bottom / h}"
        boxes(app).edit().putString(cleanName(name), v).apply()
    }

    fun box(app: Context, name: String): Region? {
        val p = boxes(app).getString(name, null)?.split(',')?.mapNotNull { it.toFloatOrNull() } ?: return null
        if (p.size != 4) return null
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val rect = Rect((p[0] * w).toInt(), (p[1] * h).toInt(), (p[2] * w).toInt(), (p[3] * h).toInt())
        return if (rect.width() < 10 || rect.height() < 10) null else Region(rect, w, h)
    }

    fun deleteBox(app: Context, name: String) { boxes(app).edit().remove(name).apply() }

    /** False when the new name is empty or already used. */
    fun renameBox(app: Context, old: String, newName: String): Boolean {
        val n = cleanName(newName)
        val sp = boxes(app)
        val v = sp.getString(old, null) ?: return false
        if (n.isEmpty() || (n != old && sp.contains(n))) return false
        sp.edit().remove(old).putString(n, v).apply()
        return true
    }

    fun saveWidget(app: Context, id: Int) { pos(app).edit().putInt("wid", id).apply() }

    /** The widget the shortcut reads: the one floating on the screen now, or the chosen one, or the first saved. */
    fun widgetFor(app: Context, now: Boolean): Int {
        if (now) { val open = WidgetFloat.firstOpenId(); if (open >= 0) return open }
        val saved = WidgetKit.savedIds(app)
        val chosen = pos(app).getInt("wid", -1)
        return if (chosen in saved) chosen else (saved.firstOrNull() ?: -1)
    }

    /** The message of a USSD window (not its buttons), read through the text reader. Blocking. */
    fun readUssd(app: Context): String {
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        if (!TextReaderControl.ensureOnBlocking(app, 3000)) throw IllegalStateException("The text reader could not be switched on")
        val limit = System.currentTimeMillis() + 12000
        try {
            while (System.currentTimeMillis() < limit) {
                val t = runCatching { TextReaderService.instance?.ussdText() }.getOrNull().orEmpty()
                if (t.isNotBlank()) return ScreenCopy.normalize(t)
                pause(400)
            }
        } finally {
            TextReaderControl.offLater(app, 1500)
        }
        throw IllegalStateException("No USSD screen was found")
    }

    private fun toast(app: Context, text: String) {
        Handler(Looper.getMainLooper()).post { WidgetFloat.toast(app, text) }
    }

    /** A screenshot through Shizuku. Blocking; null when it fails. */
    fun capture(): Bitmap? {
        if (!ShizukuShell.isReady()) return null
        val sb = StringBuilder()
        ShizukuShell.run("screencap -p | base64") { sb.append(it) }
        if (sb.isEmpty()) return null
        val bytes = runCatching { Base64.decode(sb.toString(), Base64.DEFAULT) }.getOrNull() ?: return null
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /** The chosen box cut out of a screenshot; the screenshot is recycled. */
    fun crop(full: Bitmap, r: Region): Bitmap? {
        val kx = full.width.toFloat() / r.screenW.coerceAtLeast(1)
        val ky = full.height.toFloat() / r.screenH.coerceAtLeast(1)
        val l = (r.rect.left * kx).toInt().coerceIn(0, full.width - 1)
        val t = (r.rect.top * ky).toInt().coerceIn(0, full.height - 1)
        val w = ((r.rect.right * kx).toInt() - l).coerceIn(1, full.width - l)
        val h = ((r.rect.bottom * ky).toInt() - t).coerceIn(1, full.height - t)
        val out = runCatching { Bitmap.createBitmap(full, l, t, w, h) }.getOrNull()
        if (out !== full) full.recycle()
        return out
    }

    /** Lets the person drag a box over the screen. Blocking; null when cancelled or when it cannot be shown. */
    fun pick(app: Context): Region? {
        val main = Handler(Looper.getMainLooper())
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val latch = CountDownLatch(1)
        var result: Region? = null
        var view: PickView? = null
        main.post {
            val v = PickView(app) { r -> result = r; latch.countDown() }
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            if (runCatching { wm.addView(v, p) }.isSuccess) view = v else latch.countDown()
        }
        latch.await(90, TimeUnit.SECONDS)
        main.post { view?.let { runCatching { wm.removeView(it) } } }
        pause(350)
        return result
    }

    /** Picks a box, then takes one picture of it (used to teach the digits from any screen). */
    fun snap(app: Context): Bitmap? {
        if (!WidgetFloat.allowed(app) || !ShizukuShell.isReady()) return null
        val region = pick(app) ?: return null
        val full = capture() ?: return null
        return crop(full, region)
    }

    /** What one OCR run did, for the report. */
    private class Trace {
        var box = ""
        var path = "-"
        var text = ""
        var tries = 0
        var lastRaw = ""
    }

    private fun flat(s: String) = s.replace(Regex("\\s+"), " ").trim().take(80)

    /** The screen on top right now, for the report. Blocking and short; "?" when it cannot be read. */
    private fun topNow(): String {
        var out = ""
        runCatching {
            ShizukuShell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'") { line ->
                if (out.isEmpty()) {
                    val m = Regex("u\\d+ ([\\w.]+/[\\w.$]+)").find(line)
                    if (m != null) out = m.groupValues[1]
                }
            }
        }
        return out.ifEmpty { "?" }
    }

    /**
     * Picks a box and reads the digits in it, up to about 15 seconds, until the same digits are seen
     * twice in a row. Blocking. Throws a short message when nothing could be read.
     * Every run writes one line to A's report: path, text found, box, app on top, result.
     */
    fun read(app: Context, saved: Boolean = false, given: Region? = null, boxName: String = ""): String {
        val tr = Trace()
        val top = if (ShizukuShell.isReady()) topNow() else "?"
        val t0 = System.currentTimeMillis()
        fun log(result: String) {
            DiagLog.note("OCR run: path=" + tr.path + " text=\"" + tr.text + "\" box=" + tr.box +
                " top=" + top + " tries=" + tr.tries + (if (tr.lastRaw.isNotEmpty()) " lastPicture=\"" + tr.lastRaw + "\"" else "") +
                " ms=" + (System.currentTimeMillis() - t0) + " result=" + result)
        }
        try {
            val r = readCore(app, saved, given, boxName, tr)
            log("\"" + r + "\"")
            return r
        } catch (e: Exception) {
            log("FAILED " + (e.message ?: e.javaClass.simpleName))
            throw e
        }
    }

    private fun readCore(app: Context, saved: Boolean, given: Region?, boxName: String, tr: Trace): String {
        if (!WidgetFloat.allowed(app)) throw IllegalStateException("Allow Display over other apps for A, then try again")
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        // The text reader (switched on through Shizuku for these moments) reads written text at once.
        val readerOn = TextReaderControl.ensureOnBlocking(app, 3000)
        // The saved box is read by itself; with none saved (or "choose it now") the box is dragged and kept for next time.
        val region: Region = given ?: (if (saved) savedRegion(app) else null) ?: run {
            toast(app, "Drag a box over what to read")
            val p = pick(app)
            if (p == null) { TextReaderControl.offLater(app, 500); throw IllegalStateException("Cancelled") }
            saveRegion(app, p)
            tr.box = "dragged now"
            p
        }
        if (tr.box.isEmpty()) tr.box = if (boxName.isNotEmpty()) "\"" + boxName + "\"" else if (given != null) "given" else "saved region"
        tr.box += "(" + region.rect.left + "," + region.rect.top + "," + region.rect.right + "," + region.rect.bottom + ")"
        if (readerOn) {
            val written = runCatching { TextReaderService.instance?.textIn(region.rect) }.getOrNull().orEmpty()
            TextReaderControl.offLater(app, 1500)
            tr.text = flat(written)
            // Written text with no digits (a bank name, a label) is not the code: read the picture instead.
            if (written.isNotBlank()) {
                val norm = ScreenCopy.normalize(written)
                if (norm.any { Character.isDigit(it) }) { tr.path = "text"; return norm }
                tr.path = "text ignored (no digits), then picture"
            } else tr.path = "text empty, then picture"
        } else tr.path = "text reader off, then picture"
        val limit = System.currentTimeMillis() + 15000
        var last = ""
        try {
            while (System.currentTimeMillis() < limit) {
                val full = capture() ?: throw IllegalStateException("The screenshot failed")
                val pic = crop(full, region)
                val r = if (pic == null) "" else runCatching { OtpOcr.read(app, pic) }.getOrDefault("")
                pic?.recycle()
                tr.tries++
                tr.lastRaw = flat(r)
                if (r.isNotEmpty() && !r.contains('?')) {
                    if (r == last) return r
                    last = r
                } else last = ""
                pause(300)
            }
        } finally {
            OtpOcr.release()
        }
        throw IllegalStateException("No digits were found in that box")
    }

    private fun pause(ms: Int) {
        try { Thread.sleep(ms.toLong()) } catch (_: InterruptedException) { }
    }

    /** The full-screen layer where the box is dragged. Tap "Cancel" (top right) to give up. */
    private class PickView(ctx: Context, private val onDone: (Region?) -> Unit) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private val dim = Paint().apply { color = 0x88000000.toInt() }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 16f * d }
        private var x0 = 0f
        private var y0 = 0f
        private var x1 = 0f
        private var y1 = 0f
        private var has = false
        private var cancelDown = false
        private var finished = false

        private fun box() = Rect(minOf(x0, x1).toInt(), minOf(y0, y1).toInt(), maxOf(x0, x1).toInt(), maxOf(y0, y1).toInt())
        private fun inCancel(x: Float, y: Float) = x > width - 130f * d && y < 110f * d

        override fun onDraw(c: Canvas) {
            if (has) {
                val b = box()
                c.save()
                c.clipOutRect(b)
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
                c.restore()
                c.drawRect(b, edge)
            } else {
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
            }
            c.drawText("Drag a box over what to read", 16f * d, 70f * d, text)
            c.drawText("Cancel", width - 100f * d, 70f * d, text)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (finished) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    cancelDown = inCancel(e.x, e.y)
                    if (!cancelDown) { x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y; has = true }
                }
                MotionEvent.ACTION_MOVE -> if (!cancelDown) { x1 = e.x; y1 = e.y; invalidate() }
                MotionEvent.ACTION_UP -> {
                    if (cancelDown) {
                        if (inCancel(e.x, e.y)) { finished = true; onDone(null) }
                    } else {
                        x1 = e.x; y1 = e.y
                        val b = box()
                        if (b.width() >= 20 && b.height() >= 12) {
                            val at = IntArray(2)
                            getLocationOnScreen(at)
                            b.offset(at[0], at[1])
                            finished = true
                            onDone(Region(b, width, height))
                        } else { has = false; invalidate() }
                    }
                }
                MotionEvent.ACTION_CANCEL -> { has = false; invalidate() }
            }
            return true
        }
    }
}
