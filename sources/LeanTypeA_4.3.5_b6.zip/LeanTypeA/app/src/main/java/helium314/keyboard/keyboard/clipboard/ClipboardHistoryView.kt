// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.keyboard.clipboard

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.text.method.ScrollingMovementMethod
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import kotlin.math.abs
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import helium314.keyboard.event.HapticEvent
import helium314.keyboard.keyboard.InlineCursorTextView
import helium314.keyboard.keyboard.KeyboardActionListener
import helium314.keyboard.keyboard.KeyboardId
import helium314.keyboard.keyboard.KeyboardLayoutSet
import helium314.keyboard.keyboard.KeyboardSwitcher
import helium314.keyboard.keyboard.MainKeyboardView
import helium314.keyboard.keyboard.PointerTracker
import helium314.keyboard.keyboard.internal.KeyDrawParams
import helium314.keyboard.keyboard.internal.KeyVisualAttributes
import helium314.keyboard.keyboard.internal.keyboard_parser.floris.KeyCode
import helium314.keyboard.latin.AudioAndHapticFeedbackManager
import helium314.keyboard.latin.ClipboardHistoryManager
import helium314.keyboard.latin.ClipboardHistoryEntry
import helium314.keyboard.latin.RichInputMethodManager
import helium314.keyboard.latin.R
import helium314.keyboard.latin.common.ColorType
import helium314.keyboard.latin.common.Constants
import helium314.keyboard.latin.database.ClipboardDao
import helium314.keyboard.latin.settings.Settings
import helium314.keyboard.latin.utils.ResourceUtils
import helium314.keyboard.latin.utils.ToolbarKey
import helium314.keyboard.latin.utils.createToolbarKey
import helium314.keyboard.latin.utils.isRepeatableToolbarKey
import helium314.keyboard.latin.utils.RepeatableKeyTouchListener
import helium314.keyboard.latin.utils.getCodeForToolbarKey
import helium314.keyboard.latin.utils.getCodeForToolbarKeyLongClick
import helium314.keyboard.latin.utils.getEnabledClipboardToolbarKeys
import helium314.keyboard.latin.utils.dpToPx
import helium314.keyboard.latin.ClipboardSections
import helium314.keyboard.latin.ClipboardOptions
import helium314.keyboard.latin.utils.isDarkColor
import helium314.keyboard.latin.utils.prefs
import helium314.keyboard.latin.utils.setToolbarButtonsActivatedStateOnPrefChange

@SuppressLint("CustomViewStyleable")
class ClipboardHistoryView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyle: Int = R.attr.clipboardHistoryViewStyle
) : LinearLayout(context, attrs, defStyle), View.OnClickListener,
    ClipboardDao.Listener, OnKeyEventListener, KeyboardActionListener,
    View.OnLongClickListener, SharedPreferences.OnSharedPreferenceChangeListener {

    private val clipboardLayoutParams = ClipboardLayoutParams(context)
    private val pinIconId: Int
    private val keyBackgroundId: Int

    private lateinit var clipboardRecyclerView: ClipboardHistoryRecyclerView
    private lateinit var placeholderView: TextView
    private val toolbarKeys = mutableListOf<ImageButton>()
    private lateinit var clipboardAdapter: ClipboardAdapter

    lateinit var keyboardActionListener: KeyboardActionListener
    private lateinit var clipboardHistoryManager: ClipboardHistoryManager

    init {
        val clipboardViewAttr = context.obtainStyledAttributes(attrs,
                R.styleable.ClipboardHistoryView, defStyle, R.style.ClipboardHistoryView)
        pinIconId = clipboardViewAttr.getResourceId(R.styleable.ClipboardHistoryView_iconPinnedClip, 0)
        clipboardViewAttr.recycle()
        @SuppressLint("UseKtx") // suggestion does not work
        val keyboardViewAttr = context.obtainStyledAttributes(attrs, R.styleable.KeyboardView, defStyle, R.style.KeyboardView)
        keyBackgroundId = keyboardViewAttr.getResourceId(R.styleable.KeyboardView_keyBackground, 0)
        keyboardViewAttr.recycle()
        if (Settings.getValues().mSecondaryStripVisible) {
            getEnabledClipboardToolbarKeys(context.prefs())
                .forEach { toolbarKeys.add(createToolbarKey(context, it)) }
        }
        fitsSystemWindows = true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val inSearchOrEdit = inSearchMode || inEditMode
        val container = findViewById<View>(R.id.clipboard_content_container)
        if (!inSearchOrEdit && container != null) {
            clipboardLayoutParams.updateDimensions(context)
            val targetHeight = clipboardLayoutParams.listHeight
            if (container.layoutParams.height != targetHeight) {
                container.layoutParams.height = targetHeight
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val res = context.resources
        val isFloating = helium314.keyboard.latin.FloatingKeyboardManager.isFloatingMode(context)
        val padH = if (isFloating) 0 else (paddingLeft + paddingRight)
        val padV = if (isFloating) 0 else (paddingTop + paddingBottom)
        // The main keyboard expands to the entire this {@link KeyboardView}.
        val width = ResourceUtils.getKeyboardWidth(context, Settings.getValues()) + padH
        val height = ResourceUtils.getSecondaryKeyboardHeight(res, Settings.getValues()) + padV
        setMeasuredDimension(width, height)
    }

    private lateinit var emptyViewIcon: android.widget.ImageView
    private lateinit var emptyViewText: android.widget.TextView
    private lateinit var emptyViewContainer: View

    private var actionPillOverlay: View? = null
    private var actionPill: View? = null
    private var actionPinButton: ImageButton? = null
    private var actionEditButton: ImageButton? = null
    private var actionDeleteButton: ImageButton? = null
    private var actionSelectButton: ImageButton? = null
    private var activeAnchorView: View? = null

    private var confirmationBar: View? = null
    private val confirmationDismissRunnable = Runnable { dismissConfirmationBar() }
    private val confirmationHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private var editorInfo: EditorInfo? = null
    // We already have keyboardActionListener property

    @SuppressLint("ClickableViewAccessibility")
    private fun initialize() { // needs to be delayed for access to ClipboardStrip, which is not a child of this view
        iconBar = findViewById(R.id.clipboard_icon_bar)
        iconBarScroll = findViewById(R.id.clipboard_icon_bar_scroll)
        clipboardLayoutParams.updateDimensions(context)
        findViewById<View>(R.id.clipboard_content_container)?.let { container ->
            val lp = container.layoutParams
            if (lp != null && lp.height != clipboardLayoutParams.listHeight) {
                lp.height = clipboardLayoutParams.listHeight
                container.layoutParams = lp
            }
        }
        if (this::clipboardAdapter.isInitialized) return
        val colors = Settings.getValues().mColors
        clipboardAdapter = ClipboardAdapter(clipboardLayoutParams, this).apply {
            itemBackgroundId = keyBackgroundId
            pinnedIconResId = pinIconId
            onClipLongClickListener = { entry, anchor -> showClipActionPill(entry, anchor) }
            onSelectionChangedListener = { selectedCount, totalCount ->
                updateSelectionDisplay(selectedCount, totalCount)
            }
        }
        
        emptyViewContainer = findViewById(R.id.clipboard_empty_view)
        emptyViewIcon = findViewById(R.id.clipboard_empty_icon)
        emptyViewText = findViewById(R.id.clipboard_empty_text)
        val iconColor = colors.get(ColorType.KEY_ICON)
        emptyViewIcon.setColorFilter(iconColor)
        emptyViewText.setTextColor(iconColor)

        // removed placeholderView logic as it was unused/confusing

        clipboardRecyclerView = findViewById<ClipboardHistoryRecyclerView>(R.id.clipboard_list).apply {
            val colCount = resources.getInteger(R.integer.config_clipboard_keyboard_col_count)
            layoutManager = StaggeredGridLayoutManager(colCount, StaggeredGridLayoutManager.VERTICAL)
            @Suppress("deprecation") // "no cache" should be fine according to warning in https://developer.android.com/reference/android/view/ViewGroup#setPersistentDrawingCache(int)
            persistentDrawingCache = PERSISTENT_NO_CACHE
            clipboardLayoutParams.setListProperties(this)
            applyClipboardOptions(this)
            addOnScrollListener(object : androidx.recyclerview.widget.RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(recyclerView: androidx.recyclerview.widget.RecyclerView, newState: Int) {
                    if (newState != androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_IDLE) {
                        dismissActionPill()
                    }
                }
            })
        }

        confirmationBar = findViewById(R.id.clipboard_confirmation_bar)
        confirmationBar?.let { bar ->
            try {
                colors.setBackground(bar, ColorType.CLIPBOARD_SUGGESTION_BACKGROUND)
                bar.findViewById<TextView>(R.id.clipboard_confirmation_text)?.setTextColor(colors.get(ColorType.KEY_TEXT))
                bar.findViewById<TextView>(R.id.clipboard_confirmation_button)?.setTextColor(colors.get(ColorType.ACTION_KEY_BACKGROUND))
            } catch (_: Exception) {}
            bar.findViewById<View>(R.id.clipboard_confirmation_button)?.setOnClickListener {
                clipboardHistoryManager.clearHistory()
                dismissConfirmationBar()
            }
        }

        actionPillOverlay = findViewById(R.id.clipboard_action_pill_overlay)
        actionPill = findViewById(R.id.clipboard_action_pill)
        actionPinButton = findViewById(R.id.clip_action_pin)
        actionEditButton = findViewById(R.id.clip_action_edit)
        actionDeleteButton = findViewById(R.id.clip_action_delete)
        actionSelectButton = findViewById(R.id.clip_action_select)
        actionPillOverlay?.setOnClickListener { dismissActionPill() }

        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip ?: return
        val clipboardStripScrollView = KeyboardSwitcher.getInstance().clipboardStripScrollView
        if (clipboardStripScrollView != null) {
            colors.setBackground(clipboardStripScrollView, ColorType.STRIP_BACKGROUND)
        }
        clipboardStrip.removeAllViews()
        toolbarKeys.forEach {
            clipboardStrip.addView(it)
            val tag = it.tag
            if (tag is ToolbarKey && isRepeatableToolbarKey(tag)) {
                it.setOnTouchListener(RepeatableKeyTouchListener { repeatCount ->
                    if (repeatCount == 0 || repeatCount % 4 == 0) {
                        AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_PRESS)
                    }
                    val code = getCodeForToolbarKey(tag)
                    if (code != KeyCode.UNSPECIFIED) {
                        keyboardActionListener.onCodeInput(code, Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, repeatCount > 0)
                    }
                })
            } else {
                it.setOnClickListener(this@ClipboardHistoryView)
                it.setOnLongClickListener(this@ClipboardHistoryView)
            }
            colors.setColor(it, ColorType.TOOL_BAR_KEY)
            it.setBackgroundResource(R.drawable.toolbar_key_background)
            colors.setColor(it.background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
        }
        applyClipboardToolbarKeyLayoutParams()
        clipboardStrip.post { applyClipboardToolbarKeyLayoutParams() }
    }

    private enum class SearchPurpose { SEARCH, NEW_SECTION, RENAME_SECTION, SET_SHORTCUT }
    private var shortcutEntryId: Long? = null
    private var searchPurpose = SearchPurpose.SEARCH
    private var renameSectionId: String? = null

    private var isSearchModeActive = false
    val inSearchMode: Boolean
        get() = isSearchModeActive

    private lateinit var searchBarTextView: InlineCursorTextView
    private var searchQuery = StringBuilder()
    private var backButton: ImageButton? = null
    
    // We reuse searchWatcher logic but applied manually or to a hidden text view if needed.
    // Actually we just filter manually now.
    private var searchCursorPos = 0

    private fun configureInlineTextView(textView: TextView) {
        textView.maxLines = 1
        textView.setHorizontallyScrolling(true)
        textView.isHorizontalScrollBarEnabled = false
        textView.overScrollMode = View.OVER_SCROLL_ALWAYS
    }

    @SuppressLint("WrongConstant")
    private fun configureEditTextView(textView: TextView) {
        // LeanType A: a real multi-line editing area
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        textView.minLines = if (landscape) 2 else 5
        textView.maxLines = if (landscape) 3 else 9
        textView.setHorizontallyScrolling(false)
        textView.isVerticalScrollBarEnabled = true
        textView.movementMethod = ScrollingMovementMethod.getInstance()
        textView.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        textView.isFocusable = false
        textView.isFocusableInTouchMode = false
        textView.breakStrategy = android.text.Layout.BREAK_STRATEGY_SIMPLE
        textView.hyphenationFrequency = android.text.Layout.HYPHENATION_FREQUENCY_NONE
    }

    private var pendingCursorListener: Pair<TextView, View.OnLayoutChangeListener>? = null

    private fun clearPendingCursorVisibility() {
        pendingCursorListener?.let { (tv, listener) ->
            tv.removeOnLayoutChangeListener(listener)
        }
        pendingCursorListener = null
    }

    private fun ensureCursorVisible(textView: TextView, cursorPos: Int) {
        clearPendingCursorVisibility()
        val layout = textView.layout
        if (layout == null) {
            if (!textView.isAttachedToWindow || !textView.isShown || textView.windowVisibility != VISIBLE) return
            val listener = object : View.OnLayoutChangeListener {
                override fun onLayoutChange(
                    v: View,
                    left: Int,
                    top: Int,
                    right: Int,
                    bottom: Int,
                    oldLeft: Int,
                    oldTop: Int,
                    oldRight: Int,
                    oldBottom: Int
                ) {
                    textView.removeOnLayoutChangeListener(this)
                    if (pendingCursorListener?.second === this) {
                        pendingCursorListener = null
                    }
                    if (!textView.isAttachedToWindow || !textView.isShown || textView.windowVisibility != VISIBLE) return
                    if (textView.layout != null) {
                        ensureCursorVisible(textView, cursorPos)
                    }
                }
            }
            pendingCursorListener = textView to listener
            textView.addOnLayoutChangeListener(listener)
            return
        }
        val safePos = cursorPos.coerceIn(0, layout.text.length)
        val density = textView.resources.displayMetrics.density
        val padH = (32 * density).toInt()
        val availableWidth = textView.width - textView.totalPaddingLeft - textView.totalPaddingRight
        if (availableWidth > 0 && layout.lineCount > 0) {
            val x = layout.getPrimaryHorizontal(safePos).toInt()
            val scrollX = textView.scrollX
            if (x - scrollX < padH) {
                textView.scrollTo((x - padH).coerceAtLeast(0), textView.scrollY)
            } else if (x - scrollX > availableWidth - padH) {
                textView.scrollTo(x - availableWidth + padH, textView.scrollY)
            }
        }
        val availableHeight = textView.height - textView.totalPaddingTop - textView.totalPaddingBottom
        if (availableHeight > 0 && layout.lineCount > 0) {
            val line = layout.getLineForOffset(safePos)
            val lineTop = layout.getLineTop(line)
            val lineBottom = layout.getLineBottom(line)
            val scrollY = textView.scrollY
            if (lineTop < scrollY) {
                textView.scrollTo(textView.scrollX, lineTop)
            } else if (lineBottom > scrollY + availableHeight) {
                textView.scrollTo(textView.scrollX, lineBottom - availableHeight)
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            try {
                textView.bringPointIntoView(safePos)
            } catch (_: Throwable) {}
        }
    }
    
    @SuppressLint("ClickableViewAccessibility") // touch listeners handle caret placement, not clicks
    private fun startSearchMode(purpose: SearchPurpose = SearchPurpose.SEARCH, initialText: String = "") {
        hideOptionsPanel()
        if (inEditMode) {
            stopEditMode(save = false)
        }
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip ?: return
        clipboardStrip.removeAllViews()
        isSearchModeActive = true
        
        searchBarTextView = InlineCursorTextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            textSize = 16f
            val textColor = Settings.getValues().mColors.get(ColorType.KEY_TEXT)
            setTextColor(textColor)
            cursorColor = textColor
            isCursorVisible = false
            hint = context.getString(when (purpose) {
                SearchPurpose.SEARCH -> R.string.clipboard_search_hint_advanced
                SearchPurpose.NEW_SECTION -> R.string.clipboard_section_new_hint
                SearchPurpose.RENAME_SECTION -> R.string.clipboard_section_rename_hint
                SearchPurpose.SET_SHORTCUT -> R.string.clipboard_shortcut_hint
            })
            setHintTextColor(textColor and 0x00FFFFFF or 0x80000000.toInt())
            val density = resources.displayMetrics.density
            setPadding((12 * density).toInt(), 0, 0, 0)
            setOnTouchListener { _, event ->
                if (event.action == android.view.MotionEvent.ACTION_UP) {
                    val l = layout
                    if (l != null) {
                        val x = event.x - totalPaddingLeft + scrollX
                        val y = event.y - totalPaddingTop + scrollY
                        val line = l.getLineForVertical(y.toInt().coerceIn(0, (l.height - 1).coerceAtLeast(0)))
                        val offset = l.getOffsetForHorizontal(line, x)
                        searchCursorPos = offset.coerceIn(0, searchQuery.length)
                        updateSearchDisplay()
                    }
                }
                true
            }
        }
        configureInlineTextView(searchBarTextView)
        clipboardStrip.addView(searchBarTextView)
        
        backButton = ImageButton(context).apply {
             layoutParams = LinearLayout.LayoutParams(
                 resources.getDimensionPixelSize(R.dimen.config_suggestions_strip_edge_key_width), 
                 LinearLayout.LayoutParams.MATCH_PARENT
             )
             setImageResource(R.drawable.ic_close)
             setBackgroundResource(R.drawable.toolbar_key_background)
             setColorFilter(Settings.getValues().mColors.get(ColorType.KEY_ICON))
             Settings.getValues().mColors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
             setOnClickListener {
                 searchQuery.clear()
                 stopSearchMode()
             }
        }
        clipboardStrip.addView(backButton)
        
        searchQuery.clear()
        searchPurpose = purpose
        searchQuery.append(initialText)
        searchCursorPos = searchQuery.length
        updateSearchDisplay()
        resetCursorBlink()

        setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
        
        findViewById<View>(R.id.clipboard_content_container)?.visibility = View.GONE
        clipboardRecyclerView.visibility = View.GONE
        emptyViewContainer.visibility = View.GONE
        updateClipboardGestureSuppression()
    }

    private fun stopSearchMode() {
        removeCallbacks(cursorBlinkRunnable)
        isSearchModeActive = false
        val purpose = searchPurpose
        searchPurpose = SearchPurpose.SEARCH
        renameSectionId = null
        shortcutEntryId = null
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip
        if (clipboardStrip != null) {
            clipboardStrip.removeAllViews()
            toolbarKeys.forEach { clipboardStrip.addView(it) }
            applyClipboardToolbarKeyLayoutParams()
            clipboardStrip.post { applyClipboardToolbarKeyLayoutParams() }
        }
        
        if (purpose == SearchPurpose.SEARCH) {
            if (searchQuery.isNotEmpty()) {
                clipboardAdapter.filter(searchQuery.toString())
            } else {
                clipboardAdapter.filter("")
            }
        } else {
            searchQuery.clear()
        }

        setBottomRowLayout(KeyboardId.ELEMENT_CLIPBOARD_BOTTOM_ROW)
        
        clipboardLayoutParams.updateDimensions(context)
        findViewById<View>(R.id.clipboard_content_container)?.let { container ->
            container.visibility = View.VISIBLE
            val lp = container.layoutParams
            if (lp != null && lp.height != clipboardLayoutParams.listHeight) {
                lp.height = clipboardLayoutParams.listHeight
                container.layoutParams = lp
            }
        }
        clipboardRecyclerView.visibility = View.VISIBLE
        updateEmptyView(clipboardAdapter.isFiltering)
        updateClipboardGestureSuppression()
        rebuildIconBar()
    }

    private fun updateEmptyView(isSearch: Boolean) {
        val isEmpty = clipboardAdapter.itemCount == 0
        emptyViewContainer.visibility = if (isEmpty) View.VISIBLE else View.GONE
        if (isEmpty) {
            emptyViewText.setText(when {
                isSearch -> R.string.clipboard_no_search_results
                activeSectionId != null -> R.string.clipboard_section_empty
                else -> R.string.clipboard_empty_text
            })
        }
    }

    // ------------------------------------------------------------------------------------
    // LeanType A: icon bar (pinned list, search, new clip, user sections)

    private var iconBar: LinearLayout? = null
    private var iconBarScroll: View? = null
    private var activeSectionId: String? = null
    private var pendingMoveIds: List<Long>? = null
    private var optionsSectionId: String? = null
    private var newNoteId = -1L

    private fun makeBarButton(
        active: Boolean, desc: String?, onClick: () -> Unit, onLong: (() -> Unit)? = null
    ): LinearLayout {
        val colors = Settings.getValues().mColors
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, 34.dpToPx(resources))
        lp.setMargins(2.dpToPx(resources), 0, 2.dpToPx(resources), 0)
        val button = LinearLayout(context)
        button.layoutParams = lp
        button.orientation = LinearLayout.HORIZONTAL
        button.gravity = android.view.Gravity.CENTER
        button.minimumWidth = 38.dpToPx(resources)
        button.setPadding(8.dpToPx(resources), 0, 8.dpToPx(resources), 0)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.RECTANGLE
        bg.cornerRadius = 17.dpToPx(resources).toFloat()
        bg.setColor(
            if (active) ColorUtils.setAlphaComponent(colors.get(ColorType.ACTION_KEY_BACKGROUND), 0x66)
            else ColorUtils.setAlphaComponent(colors.get(ColorType.KEY_ICON), 0x1A)
        )
        button.background = bg
        if (desc != null) button.contentDescription = desc
        button.isClickable = true
        button.setOnClickListener {
            AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_PRESS)
            onClick()
        }
        if (onLong != null) {
            button.setOnLongClickListener {
                AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_LONG_PRESS)
                onLong()
                true
            }
        }
        return button
    }

    private fun barIcon(resId: Int, tint: Int, rotationDeg: Float = 0f): ImageView {
        val icon = ImageView(context)
        icon.layoutParams = LinearLayout.LayoutParams(20.dpToPx(resources), 20.dpToPx(resources))
        icon.setImageResource(resId)
        icon.setColorFilter(tint)
        icon.rotation = rotationDeg
        return icon
    }

    private fun barLabel(label: String, sizeSp: Float, color: Int): TextView {
        val tv = TextView(context)
        tv.text = label
        tv.textSize = sizeSp
        tv.setTextColor(color)
        tv.gravity = android.view.Gravity.CENTER
        tv.includeFontPadding = false
        return tv
    }

    private fun iconBarButton(
        resId: Int, desc: String?, active: Boolean = false, rotationDeg: Float = 0f,
        onClick: () -> Unit, onLong: (() -> Unit)? = null
    ): View {
        val b = makeBarButton(active, desc, onClick, onLong)
        b.addView(barIcon(resId, Settings.getValues().mColors.get(ColorType.KEY_ICON), rotationDeg))
        return b
    }

    private fun labelBarButton(
        label: String, desc: String?, active: Boolean = false, extra: String? = null,
        onClick: () -> Unit, onLong: (() -> Unit)? = null
    ): View {
        val colors = Settings.getValues().mColors
        val b = makeBarButton(active, desc, onClick, onLong)
        b.addView(barLabel(label, 18f, colors.get(ColorType.KEY_TEXT)))
        if (extra != null) b.addView(barLabel(" $extra", 13f, colors.get(ColorType.KEY_TEXT)))
        return b
    }

    private fun rebuildIconBar() {
        val bar = iconBar ?: return
        if (!this::clipboardAdapter.isInitialized || !this::clipboardHistoryManager.isInitialized) return
        bar.removeAllViews()
        val colors = Settings.getValues().mColors
        val prefs = context.prefs()
        val sections = ClipboardSections.load(prefs)
        clipboardAdapter.sectionIcons = sections.associate { it.id to it.icon }
        val options = optionsSectionId?.let { id -> sections.firstOrNull { it.id == id } }
        if (options == null) optionsSectionId = null

        if (pendingMoveIds != null) {
            // choose where the clip goes
            bar.addView(iconBarButton(R.drawable.ic_close, null, onClick = { pendingMoveIds = null; rebuildIconBar() }))
            bar.addView(labelBarButton("📋", null, onClick = { finishMove(null) }))
            sections.forEach { s ->
                bar.addView(labelBarButton(s.icon, s.name, extra = s.name, onClick = { finishMove(s.id) }))
            }
            return
        }

        if (options != null) {
            // edit one section: rename, order, delete, icon
            bar.addView(iconBarButton(R.drawable.ic_arrow_back, null, onClick = { optionsSectionId = null; rebuildIconBar() }))
            bar.addView(labelBarButton(options.icon, options.name, active = true, extra = options.name, onClick = {}))
            bar.addView(iconBarButton(R.drawable.ic_edit, null, onClick = {
                renameSectionId = options.id
                optionsSectionId = null
                clipboardAdapter.filter("")
                startSearchMode(SearchPurpose.RENAME_SECTION, options.name)
                renameSectionId = options.id
            }))
            bar.addView(iconBarButton(R.drawable.ic_arrow_left, null, onClick = {
                ClipboardSections.move(prefs, options.id, -1); rebuildIconBar()
            }))
            bar.addView(iconBarButton(R.drawable.ic_arrow_right, null, onClick = {
                ClipboardSections.move(prefs, options.id, 1); rebuildIconBar()
            }))
            bar.addView(iconBarButton(R.drawable.ic_bin_rounded, context.getString(R.string.delete), onClick = {
                // its clips are not deleted, they go back to the normal history
                ClipboardSections.remove(prefs, options.id)
                clipboardHistoryManager.clearSection(options.id)
                optionsSectionId = null
                if (activeSectionId == options.id) selectSection(null) else { clipboardAdapter.refresh(); rebuildIconBar() }
            }))
            ClipboardSections.ICON_CHOICES.forEach { choice ->
                bar.addView(labelBarButton(choice, null, active = choice == options.icon, onClick = {
                    ClipboardSections.update(prefs, options.id, icon = choice); rebuildIconBar()
                }))
            }
            return
        }

        // normal bar
        val pinnedCount = clipboardHistoryManager.getClips().count { it.isPinned && it.section == null }
        val pinBtn = makeBarButton(
            clipboardAdapter.isPinnedExpanded && activeSectionId == null,
            context.getString(R.string.clipboard_pinned), onClick = { onPinBarClick() }
        )
        pinBtn.addView(barIcon(if (pinIconId != 0) pinIconId else R.drawable.ic_clipboard_pin_rounded, colors.get(ColorType.CLIPBOARD_PIN)))
        if (pinnedCount > 0) pinBtn.addView(barLabel(" $pinnedCount", 13f, colors.get(ColorType.KEY_TEXT)))
        bar.addView(pinBtn)

        bar.addView(iconBarButton(R.drawable.sym_keyboard_search_rounded, context.getString(R.string.clipboard_search_hint),
            active = clipboardAdapter.isFiltering, onClick = { toggleSearch() }))
        bar.addView(iconBarButton(R.drawable.ic_clip_gear, context.getString(R.string.clipboard_options_title),
            active = optionsPanel?.visibility == View.VISIBLE, onClick = { toggleOptionsPanel() }))
        bar.addView(iconBarButton(R.drawable.ic_edit, context.getString(R.string.clipboard_new_clip), onClick = { startNewClip() }))
        sections.forEach { s ->
            val isActive = activeSectionId == s.id
            bar.addView(labelBarButton(s.icon, s.name, active = isActive, extra = if (isActive) s.name else null,
                onClick = { selectSection(if (isActive) null else s.id) },
                onLong = { optionsSectionId = s.id; rebuildIconBar(); iconBarScroll?.scrollTo(0, 0) }))
        }
        bar.addView(iconBarButton(R.drawable.ic_plus, context.getString(R.string.clipboard_add_section), onClick = {
            clipboardAdapter.filter("")
            startSearchMode(SearchPurpose.NEW_SECTION)
        }))
    }

    // ------------------------------------------------------------------------------------
    // LeanType A: clipboard options window (gear icon in the icon bar)

    private var optionsPanel: View? = null

    private fun applyClipboardOptions(rv: androidx.recyclerview.widget.RecyclerView = clipboardRecyclerView) {
        val prefs = context.prefs()
        clipboardAdapter.maxLinesOption = ClipboardOptions.lines(prefs)
        clipboardAdapter.middleEllipsisOption = ClipboardOptions.middleEllipsis(prefs)
        clipboardAdapter.dotsOption = ClipboardOptions.dots(prefs)
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val columns = ClipboardOptions.columns(prefs, landscape).takeIf { it > 0 }
            ?: resources.getInteger(R.integer.config_clipboard_keyboard_col_count)
        (rv.layoutManager as? StaggeredGridLayoutManager)?.let { if (it.spanCount != columns) it.spanCount = columns }
    }

    private fun optionChanged() {
        applyClipboardOptions()
        clipboardAdapter.refresh(refilter = false)
    }

    private fun toggleOptionsPanel() {
        if (optionsPanel?.visibility == View.VISIBLE) hideOptionsPanel(rebuild = true) else showOptionsPanel()
    }

    private fun hideOptionsPanel(rebuild: Boolean = false) {
        val panel = optionsPanel ?: return
        if (panel.visibility != View.VISIBLE) return
        panel.visibility = View.GONE
        if (rebuild) {
            updateEmptyView(clipboardAdapter.isFiltering)
            rebuildIconBar()
        }
    }

    private fun showOptionsPanel() {
        dismissActionPill()
        val host = clipboardRecyclerView.parent as? android.widget.FrameLayout ?: return
        optionsPanel?.let { host.removeView(it) }
        val panel = buildOptionsPanel()
        host.addView(panel, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.MATCH_PARENT))
        optionsPanel = panel
        emptyViewContainer.visibility = View.GONE
        rebuildIconBar()
    }

    private fun buildOptionsPanel(): View {
        val colors = Settings.getValues().mColors
        val prefs = context.prefs()
        val textColor = colors.get(ColorType.KEY_TEXT)
        val accent = colors.get(ColorType.ACTION_KEY_BACKGROUND)
        val dp = { v: Int -> v.dpToPx(resources) }

        fun chipBackground(active: Boolean) = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(if (active) ColorUtils.setAlphaComponent(accent, 0xCC) else ColorUtils.setAlphaComponent(textColor, 0x22))
        }

        fun label(title: String, hint: String?): LinearLayout {
            val box = LinearLayout(context)
            box.orientation = LinearLayout.VERTICAL
            box.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            val t = TextView(context)
            t.text = title
            t.setTextColor(textColor)
            t.textSize = 15f
            box.addView(t)
            if (hint != null) {
                val h = TextView(context)
                h.text = hint
                h.setTextColor(ColorUtils.setAlphaComponent(textColor, 0x99))
                h.textSize = 12f
                box.addView(h)
            }
            return box
        }

        fun row(title: String, hint: String?, control: View): LinearLayout {
            val r = LinearLayout(context)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = android.view.Gravity.CENTER_VERTICAL
            r.setPadding(dp(14), dp(8), dp(10), dp(8))
            r.addView(label(title, hint))
            r.addView(control)
            return r
        }

        fun toggle(key: String, default: Boolean): TextView {
            val chip = TextView(context)
            chip.gravity = android.view.Gravity.CENTER
            chip.minWidth = dp(56)
            chip.setPadding(dp(14), dp(7), dp(14), dp(7))
            chip.textSize = 14f
            chip.setTextColor(textColor)
            fun update() {
                val on = prefs.getBoolean(key, default)
                chip.text = if (on) "ON" else "OFF"
                chip.background = chipBackground(on)
            }
            update()
            chip.setOnClickListener {
                prefs.edit().putBoolean(key, !prefs.getBoolean(key, default)).apply()
                update()
                optionChanged()
            }
            return chip
        }

        fun stepper(valueText: () -> String, onChange: (Int) -> Unit): LinearLayout {
            val box = LinearLayout(context)
            box.orientation = LinearLayout.HORIZONTAL
            box.gravity = android.view.Gravity.CENTER_VERTICAL
            val value = TextView(context)
            value.setTextColor(textColor)
            value.textSize = 15f
            value.gravity = android.view.Gravity.CENTER
            value.minWidth = dp(52)
            fun update() { value.text = valueText() }
            fun button(sign: String, delta: Int): TextView {
                val b = TextView(context)
                b.text = sign
                b.textSize = 20f
                b.gravity = android.view.Gravity.CENTER
                b.setTextColor(textColor)
                b.layoutParams = LinearLayout.LayoutParams(dp(40), dp(36))
                b.background = chipBackground(false)
                b.setOnClickListener { onChange(delta); update(); optionChanged() }
                return b
            }
            box.addView(button("−", -1))
            box.addView(value)
            box.addView(button("+", 1))
            update()
            return box
        }

        val content = LinearLayout(context)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, dp(6), 0, dp(10))

        val title = TextView(context)
        title.text = context.getString(R.string.clipboard_options_title)
        title.setTextColor(textColor)
        title.textSize = 17f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        title.setPadding(dp(14), dp(4), dp(14), dp(4))
        content.addView(title)

        content.addView(row(
            context.getString(R.string.clipboard_opt_middle),
            context.getString(R.string.clipboard_opt_middle_hint),
            toggle(ClipboardOptions.KEY_MIDDLE_ELLIPSIS, false)))

        content.addView(row(
            context.getString(R.string.clipboard_opt_dots),
            context.getString(R.string.clipboard_opt_dots_hint),
            stepper({ "${ClipboardOptions.dots(prefs)}" }, { delta ->
                prefs.edit().putInt(ClipboardOptions.KEY_DOTS, (ClipboardOptions.dots(prefs) + delta).coerceIn(1, 30)).apply()
            })))

        val defaultCols = resources.getInteger(R.integer.config_clipboard_keyboard_col_count)
        fun columnsRow(title: String, key: String, landscape: Boolean) = row(title, null, stepper(
            { ClipboardOptions.columns(prefs, landscape).let { if (it == 0) "auto ($defaultCols)" else "$it" } },
            { delta ->
                val cur = ClipboardOptions.columns(prefs, landscape).let { if (it == 0) defaultCols else it }
                prefs.edit().putInt(key, (cur + delta).coerceIn(1, 8)).apply()
            }))
        content.addView(columnsRow(context.getString(R.string.clipboard_opt_columns_portrait), ClipboardOptions.KEY_COLS_PORTRAIT, false))
        content.addView(columnsRow(context.getString(R.string.clipboard_opt_columns_landscape), ClipboardOptions.KEY_COLS_LANDSCAPE, true))

        content.addView(row(
            context.getString(R.string.clipboard_opt_lines),
            context.getString(R.string.clipboard_opt_lines_hint),
            stepper({ "${ClipboardOptions.lines(prefs)}" }, { delta ->
                prefs.edit().putInt(ClipboardOptions.KEY_LINES, (ClipboardOptions.lines(prefs) + delta).coerceIn(1, 20)).apply()
            })))

        content.addView(row(
            context.getString(R.string.clipboard_opt_shortcuts),
            context.getString(R.string.clipboard_opt_shortcuts_hint),
            toggle(ClipboardOptions.KEY_SHORTCUTS_ON, true)))

        val more = TextView(context)
        more.text = context.getString(R.string.clipboard_opt_more)
        more.setTextColor(ColorUtils.setAlphaComponent(textColor, 0x77))
        more.textSize = 12f
        more.setPadding(dp(14), dp(10), dp(14), dp(4))
        content.addView(more)

        val scroll = android.widget.ScrollView(content.context)
        scroll.setBackgroundColor(colors.get(ColorType.MAIN_BACKGROUND))
        scroll.isClickable = true
        scroll.addView(content)
        return scroll
    }

    private fun onPinBarClick() {
        hideOptionsPanel()
        if (activeSectionId != null) {
            // back from a section: show the normal history with the pinned clips open
            selectSection(null)
            if (!clipboardAdapter.isPinnedExpanded) clipboardAdapter.togglePinnedExpanded()
            clipboardAdapter.refreshAndScrollToTop(clipboardRecyclerView)
            rebuildIconBar()
            updateEmptyView(false)
            return
        }
        if (clipboardAdapter.isFiltering) clearSearchFilter()
        clipboardAdapter.togglePinnedExpanded()
        clipboardAdapter.refreshAndScrollToTop(clipboardRecyclerView)
        rebuildIconBar()
        updateEmptyView(false)
    }

    private fun clearSearchFilter() {
        searchQuery.clear()
        clipboardAdapter.filter("")
    }

    private fun toggleSearch() {
        hideOptionsPanel()
        if (clipboardAdapter.isFiltering) {
            clearSearchFilter()
            updateEmptyView(false)
            rebuildIconBar()
        } else {
            startSearchMode()
        }
    }

    private fun selectSection(id: String?) {
        hideOptionsPanel()
        activeSectionId = id
        pendingMoveIds = null
        optionsSectionId = null
        clearSearchFilter()
        clipboardAdapter.activeSection = id
        clipboardAdapter.refreshAndScrollToTop(clipboardRecyclerView)
        rebuildIconBar()
        updateEmptyView(false)
    }

    private fun startNewClip() {
        hideOptionsPanel()
        if (clipboardAdapter.isFiltering) clearSearchFilter()
        val entry = clipboardHistoryManager.addNote(activeSectionId) ?: return
        newNoteId = entry.id
        startEditMode(entry)
    }

    fun startMoveToSection(ids: List<Long>) {
        if (ids.isEmpty()) return
        hideOptionsPanel()
        if (ClipboardSections.load(context.prefs()).isEmpty()) {
            KeyboardSwitcher.getInstance().showToast(context.getString(R.string.clipboard_section_none), true)
            return
        }
        pendingMoveIds = ids
        optionsSectionId = null
        rebuildIconBar()
        iconBarScroll?.scrollTo(0, 0)
        KeyboardSwitcher.getInstance().showToast(context.getString(R.string.clipboard_section_pick), true)
    }

    private fun finishMove(section: String?) {
        val ids = pendingMoveIds ?: return
        pendingMoveIds = null
        clipboardHistoryManager.setClipsSection(ids, section)
        if (inSelectionMode) stopSelectionMode()
        clipboardAdapter.refresh()
        rebuildIconBar()
        updateEmptyView(clipboardAdapter.isFiltering)
    }

    /** Enter pressed in the text field of search mode while it is used to type a section name. */
    private fun commitSectionInput(): String? {
        if (searchPurpose == SearchPurpose.SET_SHORTCUT) {
            val id = shortcutEntryId
            val word = searchQuery.toString().filter { !it.isWhitespace() }
            val clip = if (id == null) null else try { clipboardHistoryManager.getHistoryEntryContent(id) } catch (_: Exception) { null }
            if (clip != null) {
                ClipboardOptions.setShortcut(context.prefs(), clip.id, clip.text, word)
                KeyboardSwitcher.getInstance().showToast(
                    if (word.isEmpty()) context.getString(R.string.clipboard_shortcut_removed)
                    else context.getString(R.string.clipboard_shortcut_saved, word), true)
            }
            return null
        }
        val name = searchQuery.toString().trim()
        if (name.isEmpty()) return null
        val prefs = context.prefs()
        return when (searchPurpose) {
            SearchPurpose.NEW_SECTION -> ClipboardSections.add(prefs, name).id
            SearchPurpose.RENAME_SECTION -> renameSectionId?.also { ClipboardSections.update(prefs, it, name = name) }
            SearchPurpose.SEARCH, SearchPurpose.SET_SHORTCUT -> null
        }
    }

    private fun onSearchQueryChanged() {
        if (searchPurpose == SearchPurpose.SEARCH) clipboardAdapter.filter(searchQuery.toString(), background = true)
    }

    private var editEntry: ClipboardHistoryEntry? = null
    private val editUndoStack = ArrayDeque<Pair<String, Int>>()
    private val editRedoStack = ArrayDeque<Pair<String, Int>>()
    private var editText = StringBuilder()
    private var editCursorPos = 0
    private var editSelectionStart = -1
    private var editSelectionEnd = -1
    private var editCharCountView: TextView? = null
    private var deleteSwipeStartPos = -1
    private var currentDeleteSwipePos = -1
    private lateinit var editTextView: InlineCursorTextView
    private var lastShiftPressTime = 0L
    private var isCursorBlinkVisible = true
    private val cursorBlinkRunnable = object : Runnable {
        override fun run() {
            if ((!inEditMode && !inSearchMode) || !isAttachedToWindow || windowVisibility != VISIBLE || !isShown) return
            isCursorBlinkVisible = !isCursorBlinkVisible
            if (inEditMode && this@ClipboardHistoryView::editTextView.isInitialized) {
                editTextView.showInlineCursor = isCursorBlinkVisible
            } else if (inSearchMode && this@ClipboardHistoryView::searchBarTextView.isInitialized) {
                searchBarTextView.showInlineCursor = isCursorBlinkVisible
            }
            postDelayed(this, 500)
        }
    }

    private fun resetCursorBlink() {
        isCursorBlinkVisible = true
        if (inEditMode && this::editTextView.isInitialized) {
            editTextView.showInlineCursor = true
        } else if (inSearchMode && this::searchBarTextView.isInitialized) {
            searchBarTextView.showInlineCursor = true
        }
        removeCallbacks(cursorBlinkRunnable)
        postDelayed(cursorBlinkRunnable, 500)
    }

    val inEditMode: Boolean
        get() = editEntry != null

    @SuppressLint("ClickableViewAccessibility") // touch listeners handle caret placement, not clicks
    fun startEditMode(entry: ClipboardHistoryEntry) {
        hideOptionsPanel()
        customizingEditActions = false
        clipboardRecyclerView.dismissUndoBar()
        dismissConfirmationBar()
        val clipboardStripScrollView = KeyboardSwitcher.getInstance().clipboardStripScrollView
        val editStrip = KeyboardSwitcher.getInstance().clipboardEditStrip ?: return
        if (inSearchMode) {
            stopSearchMode()
        }

        editEntry = entry
        editUndoStack.clear()
        editRedoStack.clear()
        editText = StringBuilder(entry.text)
        editCursorPos = editText.length
        editSelectionStart = -1
        editSelectionEnd = -1

        val colors = Settings.getValues().mColors
        clipboardStripScrollView?.visibility = View.GONE
        editStrip.visibility = View.VISIBLE
        colors.setBackground(editStrip, ColorType.STRIP_BACKGROUND)

        editTextView = editStrip.findViewById(R.id.clipboard_edit_text)
        editCharCountView = editStrip.findViewById(R.id.clipboard_edit_char_count)
        val saveButton = editStrip.findViewById<ImageButton>(R.id.clipboard_edit_save)
        val cancelButton = editStrip.findViewById<ImageButton>(R.id.clipboard_edit_cancel)

        colors.setColor(saveButton, ColorType.KEY_ICON)
        colors.setColor(saveButton.background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
        saveButton.setOnClickListener { stopEditMode(save = true) }

        colors.setColor(cancelButton, ColorType.KEY_ICON)
        colors.setColor(cancelButton.background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
        cancelButton.setOnClickListener { stopEditMode(save = false) }

        val textColor = colors.get(ColorType.KEY_TEXT)
        editTextView.setTextColor(textColor)
        editTextView.cursorColor = textColor
        editTextView.isCursorVisible = false

        editCharCountView?.apply {
            visibility = View.VISIBLE
            setTextColor((textColor and 0x00FFFFFF) or 0x80000000.toInt())
        }

        installEditTouchHandling()
        configureEditTextView(editTextView)
        buildEditActions(editStrip)

        findViewById<View>(R.id.clipboard_content_container)?.visibility = View.GONE
        clipboardRecyclerView.visibility = View.GONE
        emptyViewContainer.visibility = View.GONE

        updateEditDisplay()
        resetCursorBlink()

        setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
        updateClipboardGestureSuppression()
    }

    // ------------------------------------------------------------------------------------
    // LeanType A: selecting text in the clip editor like in a note app:
    // tap = cursor, double tap = word, long press = word then drag to extend, drag the two handles to adjust.

    private var editDragMode = 0 // 0 none, 1 extending from a word, 2 start handle, 3 end handle
    private var editDragAnchorA = 0
    private var editDragAnchorB = 0
    private var editLastTouchX = 0f
    private var editLastTouchY = 0f
    private var editLastTapTime = 0L
    private var editLongPressFired = false

    private val editLongPressRunnable = Runnable {
        if (!inEditMode || !this::editTextView.isInitialized) return@Runnable
        val off = editOffsetAt(editLastTouchX, editLastTouchY)
        val range = editWordRangeAt(off)
        editLongPressFired = true
        if (range == null) {
            editCursorPos = off
            editSelectionStart = -1
            editSelectionEnd = -1
            updateEditDisplay()
            return@Runnable
        }
        editDragMode = 1
        editDragAnchorA = range.first
        editDragAnchorB = range.second
        editTextView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        editApplyLiveSelection(range.first, range.second)
    }

    private val editAutoScrollRunnable = object : Runnable {
        override fun run() {
            if (editDragMode == 0 || !inEditMode) return
            if (editAutoScrollStep()) {
                editDragTo(editLastTouchX, editLastTouchY)
                postDelayed(this, 40)
            }
        }
    }

    private fun editOffsetAt(x: Float, y: Float): Int {
        val tv = editTextView
        val l = tv.layout ?: return editCursorPos
        val cx = x - tv.totalPaddingLeft + tv.scrollX
        val cy = y - tv.totalPaddingTop + tv.scrollY
        val line = l.getLineForVertical(cy.toInt().coerceIn(0, (l.height - 1).coerceAtLeast(0)))
        return l.getOffsetForHorizontal(line, cx).coerceIn(0, editText.length)
    }

    /** start (inclusive) and end (exclusive) of the word at [off], or null when there is none. */
    private fun editWordRangeAt(off: Int): Pair<Int, Int>? {
        val t = editText
        if (t.isEmpty()) return null
        fun isWord(c: Char) = c.isLetterOrDigit() || c == '_' || c == '\''
        var i = off.coerceIn(0, t.length)
        if (i >= t.length || !isWord(t[i])) {
            if (i > 0 && isWord(t[i - 1])) {
                i--
            } else {
                return if (i < t.length && !t[i].isWhitespace()) i to (i + 1) else null
            }
        }
        var a = i
        var b = i + 1
        while (a > 0 && isWord(t[a - 1])) a--
        while (b < t.length && isWord(t[b])) b++
        return a to b
    }

    /** Selection changes while the finger is down: no text rebuild, so the scroll position stays. */
    private fun editApplyLiveSelection(a: Int, b: Int) {
        val tv = editTextView
        editSelectionStart = a
        editSelectionEnd = b
        editCursorPos = b
        val t = tv.text
        if (t.length == editText.length) {
            t.getSpans(0, t.length, android.text.style.BackgroundColorSpan::class.java).forEach { t.removeSpan(it) }
            if (b > a && b <= t.length) {
                val textColor = Settings.getValues().mColors.get(ColorType.KEY_TEXT)
                t.setSpan(android.text.style.BackgroundColorSpan((textColor and 0x00FFFFFF) or 0x50000000), a, b,
                    android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        tv.showInlineCursor = false
        tv.handleStart = a
        tv.handleEnd = b
        editCharCountView?.text = "${b - a}/${editText.length}"
        removeCallbacks(cursorBlinkRunnable)
        tv.invalidate()
    }

    private fun editDragTo(x: Float, y: Float) {
        val handleLift = if (editDragMode >= 2) 16.dpToPx(resources).toFloat() else 0f
        val off = editOffsetAt(x, y - handleLift)
        when (editDragMode) {
            1 -> {
                val w = editWordRangeAt(off)
                val a = if (off < editDragAnchorA) (w?.first ?: off) else editDragAnchorA
                val b = if (off > editDragAnchorB) (w?.second ?: off) else editDragAnchorB
                editApplyLiveSelection(a, b)
            }
            2 -> editApplyLiveSelection(off.coerceAtMost(editSelectionEnd - 1).coerceAtLeast(0), editSelectionEnd)
            3 -> editApplyLiveSelection(editSelectionStart, off.coerceAtLeast(editSelectionStart + 1))
        }
    }

    /** Scrolls the editor while a finger is held near its top or bottom edge. Returns true when it scrolled. */
    private fun editAutoScrollStep(): Boolean {
        val tv = editTextView
        val l = tv.layout ?: return false
        val zone = 26.dpToPx(resources)
        val step = 14.dpToPx(resources)
        val maxScroll = (l.height + tv.totalPaddingTop + tv.totalPaddingBottom - tv.height).coerceAtLeast(0)
        val target = when {
            editLastTouchY < zone -> (tv.scrollY - step).coerceAtLeast(0)
            editLastTouchY > tv.height - zone -> (tv.scrollY + step).coerceAtMost(maxScroll)
            else -> return false
        }
        if (target == tv.scrollY) return false
        tv.scrollTo(tv.scrollX, target)
        return true
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun installEditTouchHandling() {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        editTextView.setOnTouchListener { _, event ->
            editLastTouchX = event.x
            editLastTouchY = event.y
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                    editLongPressFired = false
                    parent?.requestDisallowInterceptTouchEvent(true)
                    val handle = editTextView.hitHandle(event.x, event.y)
                    if (handle != 0) {
                        editDragMode = if (handle == 1) 2 else 3
                        true
                    } else {
                        editDragMode = 0
                        editTextView.removeCallbacks(editLongPressRunnable)
                        editTextView.postDelayed(editLongPressRunnable, ViewConfiguration.getLongPressTimeout().toLong())
                        false
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (editDragMode == 0 && !editLongPressFired &&
                        (abs(event.x - downX) > slop || abs(event.y - downY) > slop)) {
                        editTextView.removeCallbacks(editLongPressRunnable)
                    }
                    if (editDragMode != 0) {
                        editDragTo(event.x, event.y)
                        removeCallbacks(editAutoScrollRunnable)
                        if (editAutoScrollStep()) {
                            editDragTo(event.x, event.y)
                            postDelayed(editAutoScrollRunnable, 40)
                        }
                        true
                    } else {
                        editLongPressFired
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    editTextView.removeCallbacks(editLongPressRunnable)
                    removeCallbacks(editAutoScrollRunnable)
                    val wasDragging = editDragMode != 0
                    editDragMode = 0
                    if (wasDragging || editLongPressFired) {
                        true
                    } else {
                        if (event.actionMasked == MotionEvent.ACTION_UP &&
                            abs(event.x - downX) < slop && abs(event.y - downY) < slop) {
                            val off = editOffsetAt(event.x, event.y)
                            val now = android.os.SystemClock.uptimeMillis()
                            val doubleTap = now - editLastTapTime < ViewConfiguration.getDoubleTapTimeout()
                            val range = if (doubleTap) editWordRangeAt(off) else null
                            if (range != null) {
                                editLastTapTime = 0L
                                editSelectionStart = range.first
                                editSelectionEnd = range.second
                                editCursorPos = range.second
                                updateEditDisplayWithSelection(range.first, range.second)
                            } else {
                                editLastTapTime = now
                                editCursorPos = off
                                editSelectionStart = -1
                                editSelectionEnd = -1
                                updateEditDisplay()
                            }
                        }
                        false
                    }
                }
                else -> false
            }
        }
    }

    private var customizingEditActions = false

    private val editActionList by lazy {
        listOf(
            ToolbarKey.FULL_LEFT to KeyCode.MOVE_START_OF_LINE,
            ToolbarKey.WORD_LEFT to KeyCode.WORD_LEFT,
            ToolbarKey.LEFT to KeyCode.ARROW_LEFT,
            ToolbarKey.RIGHT to KeyCode.ARROW_RIGHT,
            ToolbarKey.WORD_RIGHT to KeyCode.WORD_RIGHT,
            ToolbarKey.FULL_RIGHT to KeyCode.MOVE_END_OF_LINE,
            ToolbarKey.UP to KeyCode.ARROW_UP,
            ToolbarKey.DOWN to KeyCode.ARROW_DOWN,
            ToolbarKey.PAGE_START to KeyCode.MOVE_START_OF_PAGE,
            ToolbarKey.PAGE_END to KeyCode.MOVE_END_OF_PAGE,
            ToolbarKey.SELECT_WORD to KeyCode.CLIPBOARD_SELECT_WORD,
            ToolbarKey.SELECT_ALL to KeyCode.CLIPBOARD_SELECT_ALL,
            ToolbarKey.COPY to KeyCode.CLIPBOARD_COPY,
            ToolbarKey.CUT to KeyCode.CLIPBOARD_CUT,
            ToolbarKey.PASTE to KeyCode.CLIPBOARD_PASTE,
            ToolbarKey.UNDO to KeyCode.UNDO,
            ToolbarKey.REDO to KeyCode.REDO,
        )
    }

    /**
     * LeanType A: cursor / selection / clipboard buttons of the clip editor, so nothing is lost when editing.
     * The icon under the X button switches to a mode where every button can be turned on or off.
     */
    private fun buildEditActions(editStrip: View) {
        val row = editStrip.findViewById<LinearLayout>(R.id.clipboard_edit_actions) ?: return
        row.removeAllViews()
        val colors = Settings.getValues().mColors
        val prefs = context.prefs()
        val enabled = ClipboardOptions.editActions(prefs) ?: editActionList.map { it.first.name }.toSet()

        editStrip.findViewById<ImageButton>(R.id.clipboard_edit_customize)?.let { customize ->
            colors.setColor(customize.background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            colors.setColor(customize, if (customizingEditActions) ColorType.ACTION_KEY_BACKGROUND else ColorType.KEY_ICON)
            customize.setOnClickListener {
                AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_PRESS)
                customizingEditActions = !customizingEditActions
                buildEditActions(editStrip)
            }
        }

        for ((key, code) in editActionList) {
            val isOn = key.name in enabled
            if (!isOn && !customizingEditActions) continue
            val btn = createToolbarKey(context, key)
            btn.layoutParams = LinearLayout.LayoutParams(40.dpToPx(resources), LinearLayout.LayoutParams.MATCH_PARENT)
            btn.setBackgroundResource(R.drawable.toolbar_key_background)
            colors.setColor(btn.background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            colors.setColor(btn, ColorType.TOOL_BAR_KEY)
            if (customizingEditActions) {
                btn.alpha = if (isOn) 1f else 0.3f
                btn.setOnClickListener {
                    AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_PRESS)
                    val now = (ClipboardOptions.editActions(prefs) ?: editActionList.map { a -> a.first.name }.toSet()).toMutableSet()
                    if (!now.add(key.name)) now.remove(key.name)
                    ClipboardOptions.setEditActions(prefs, editActionList.map { a -> a.first.name }.filter { it in now })
                    buildEditActions(editStrip)
                }
            } else if (isRepeatableToolbarKey(key)) {
                btn.setOnTouchListener(RepeatableKeyTouchListener { repeatCount ->
                    if (repeatCount <= 1) {
                        AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, btn, HapticEvent.KEY_PRESS)
                    }
                    onCodeInput(code, Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, repeatCount > 1)
                })
            } else {
                btn.setOnClickListener {
                    AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, it, HapticEvent.KEY_PRESS)
                    onCodeInput(code, Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, false)
                }
            }
            row.addView(btn)
        }
    }

    private fun stopEditMode(save: Boolean) {
        removeCallbacks(cursorBlinkRunnable)
        val entry = editEntry ?: return

        val isNewNote = entry.id == newNoteId
        newNoteId = -1L
        if (isNewNote && (!save || editText.toString().trim().isEmpty())) {
            // an empty new clip is not kept
            clipboardHistoryManager.deleteEntryById(entry.id)
        } else if (save) {
            val newText = editText.toString().trim()
            if (newText.isNotEmpty() && newText != entry.text) {
                clipboardHistoryManager.updateClipText(entry.id, newText)
                ClipboardOptions.updateShortcutText(context.prefs(), entry.id, newText)
            }
        }

        editEntry = null
        deleteSwipeStartPos = -1
        currentDeleteSwipePos = -1
        editSelectionStart = -1
        editSelectionEnd = -1
        editCharCountView?.visibility = View.GONE
        editCharCountView = null

        val editStrip = KeyboardSwitcher.getInstance().clipboardEditStrip
        editStrip?.visibility = View.GONE

        val clipboardStripScrollView = KeyboardSwitcher.getInstance().clipboardStripScrollView
        clipboardStripScrollView?.visibility = View.VISIBLE

        setBottomRowLayout(KeyboardId.ELEMENT_CLIPBOARD_BOTTOM_ROW)

        clipboardLayoutParams.updateDimensions(context)
        findViewById<View>(R.id.clipboard_content_container)?.let { container ->
            container.visibility = View.VISIBLE
            val lp = container.layoutParams
            if (lp != null && lp.height != clipboardLayoutParams.listHeight) {
                lp.height = clipboardLayoutParams.listHeight
                container.layoutParams = lp
            }
        }
        clipboardRecyclerView.visibility = View.VISIBLE
        clipboardAdapter.refresh()
        updateEmptyView(clipboardAdapter.isFiltering)
        updateClipboardGestureSuppression()
        rebuildIconBar()
    }

    private fun updateEditDisplay() {
        resetCursorBlink()
        updateEditDisplayWithSelection(-1, -1)
    }

    private fun updateEditDisplayWithSelection(selStart: Int, selEnd: Int) {
        if (!this::editTextView.isInitialized) return
        val colors = Settings.getValues().mColors
        val textColor = colors.get(ColorType.KEY_TEXT)
        editTextView.cursorColor = textColor

        val charCount = editText.length
        val charCountText = if (selStart >= 0 && selEnd > selStart && selEnd <= charCount) {
            "${selEnd - selStart}/$charCount"
        } else {
            "$charCount"
        }
        editCharCountView?.text = charCountText

        if (selStart >= 0 && selEnd > selStart && selEnd <= editText.length) {
            val sb = android.text.SpannableStringBuilder(editText)
            val highlightColor = (textColor and 0x00FFFFFF) or 0x50000000
            sb.setSpan(
                android.text.style.BackgroundColorSpan(highlightColor),
                selStart,
                selEnd,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            editTextView.setText(sb)
            editTextView.showInlineCursor = false
            editTextView.handleStart = selStart
            editTextView.handleEnd = selEnd
            removeCallbacks(cursorBlinkRunnable)
            ensureCursorVisible(editTextView, selEnd)
        } else {
            editTextView.setText(editText.toString())
            editTextView.handleStart = -1
            editTextView.handleEnd = -1
            editTextView.cursorPos = editCursorPos
            editTextView.showInlineCursor = true
            ensureCursorVisible(editTextView, editCursorPos)
        }
    }

    private fun updateSearchDisplay() {
        resetCursorBlink()
        updateSearchDisplayWithSelection(-1, -1)
    }

    private fun updateSearchDisplayWithSelection(selStart: Int, selEnd: Int) {
        if (!this::searchBarTextView.isInitialized) return
        val colors = Settings.getValues().mColors
        val textColor = colors.get(ColorType.KEY_TEXT)
        searchBarTextView.cursorColor = textColor

        if (selStart >= 0 && selEnd > selStart && selEnd <= searchQuery.length) {
            val sb = android.text.SpannableStringBuilder(searchQuery)
            val highlightColor = (textColor and 0x00FFFFFF) or 0x50000000
            sb.setSpan(
                android.text.style.BackgroundColorSpan(highlightColor),
                selStart,
                selEnd,
                android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            searchBarTextView.setText(sb)
            searchBarTextView.showInlineCursor = false
            removeCallbacks(cursorBlinkRunnable)
            ensureCursorVisible(searchBarTextView, selEnd)
        } else {
            searchBarTextView.setText(searchQuery.toString())
            searchBarTextView.cursorPos = searchCursorPos
            searchBarTextView.showInlineCursor = true
            ensureCursorVisible(searchBarTextView, searchCursorPos)
        }
    }

    private var selectionCountTextView: TextView? = null
    private var selectionSelectAllButton: ImageButton? = null
    private var selectionPinButton: ImageButton? = null
    private var selectionDeleteButton: ImageButton? = null

    val inSelectionMode: Boolean
        get() = this::clipboardAdapter.isInitialized && clipboardAdapter.isSelectionMode

    fun startSelectionMode(initialSelectedId: Long? = null) {
        hideOptionsPanel()
        if (!this::clipboardAdapter.isInitialized) return
        clipboardRecyclerView.dismissUndoBar()
        dismissConfirmationBar()
        dismissActionPill()
        if (inEditMode) {
            stopEditMode(save = false)
        }
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip ?: return
        val inSearch = inSearchMode
        if (inSearch) {
            stopSearchMode()
        }

        clipboardStrip.removeAllViews()

        val colors = Settings.getValues().mColors
        val btnWidth = resources.getDimensionPixelSize(R.dimen.config_suggestions_strip_edge_key_width)

        val closeButton = ImageButton(context).apply {
            layoutParams = LinearLayout.LayoutParams(btnWidth, LinearLayout.LayoutParams.MATCH_PARENT)
            setImageResource(R.drawable.ic_close)
            setBackgroundResource(R.drawable.toolbar_key_background)
            setColorFilter(colors.get(ColorType.KEY_ICON))
            colors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            contentDescription = context.getString(android.R.string.cancel)
            setOnClickListener { stopSelectionMode() }
        }
        clipboardStrip.addView(closeButton)

        val countTextView = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textSize = 16f
            setTextColor(colors.get(ColorType.KEY_TEXT))
            setPadding(16.dpToPx(resources), 0, 0, 0)
        }
        configureInlineTextView(countTextView)
        selectionCountTextView = countTextView
        clipboardStrip.addView(countTextView)

        val selectAllButton = ImageButton(context).apply {
            layoutParams = LinearLayout.LayoutParams(btnWidth, LinearLayout.LayoutParams.MATCH_PARENT)
            setImageResource(R.drawable.ic_select_all_rounded)
            setBackgroundResource(R.drawable.toolbar_key_background)
            setColorFilter(colors.get(ColorType.KEY_ICON))
            colors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            contentDescription = context.getString(R.string.clipboard_action_select_all)
            setOnClickListener {
                val total = clipboardAdapter.getAllClipEntries().size
                if (clipboardAdapter.selectedEntryIds.size == total && total > 0) {
                    clipboardAdapter.deselectAll()
                } else {
                    clipboardAdapter.selectAll()
                }
            }
        }
        selectionSelectAllButton = selectAllButton
        clipboardStrip.addView(selectAllButton)

        val pinButton = ImageButton(context).apply {
            layoutParams = LinearLayout.LayoutParams(btnWidth, LinearLayout.LayoutParams.MATCH_PARENT)
            setImageResource(R.drawable.ic_clipboard_pin_rounded)
            setBackgroundResource(R.drawable.toolbar_key_background)
            setColorFilter(colors.get(ColorType.KEY_ICON))
            colors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            contentDescription = context.getString(R.string.clipboard_action_pin)
            setOnClickListener {
                val selected = clipboardAdapter.getSelectedEntries()
                if (selected.isNotEmpty()) {
                    val allPinned = selected.all { it.isPinned }
                    clipboardHistoryManager.setClipsPinned(selected.map { it.id }, !allPinned)
                    clipboardAdapter.refresh()
                    updateSelectionDisplay()
                }
            }
        }
        selectionPinButton = pinButton
        clipboardStrip.addView(pinButton)

        val deleteButton = ImageButton(context).apply {
            layoutParams = LinearLayout.LayoutParams(btnWidth, LinearLayout.LayoutParams.MATCH_PARENT)
            setImageResource(R.drawable.ic_bin_rounded)
            setBackgroundResource(R.drawable.toolbar_key_background)
            setColorFilter(colors.get(ColorType.KEY_ICON))
            colors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            contentDescription = context.getString(R.string.delete)
            setOnClickListener {
                val selected = clipboardAdapter.getSelectedEntries()
                if (selected.isNotEmpty()) {
                    val deletedList = clipboardHistoryManager.deleteEntries(selected.map { it.id })
                    stopSelectionMode()
                    if (deletedList.isNotEmpty()) {
                        clipboardAdapter.refresh()
                        clipboardRecyclerView.showUndoBar(deletedList)
                    }
                }
            }
        }
        selectionDeleteButton = deleteButton
        clipboardStrip.addView(deleteButton)

        val moveButton = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(btnWidth, LinearLayout.LayoutParams.MATCH_PARENT)
            text = "📁"
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.toolbar_key_background)
            colors.setColor(background, ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
            contentDescription = context.getString(R.string.clipboard_section_move)
            setOnClickListener {
                val selected = clipboardAdapter.getSelectedEntries()
                if (selected.isNotEmpty()) startMoveToSection(selected.map { it.id })
            }
        }
        clipboardStrip.addView(moveButton)

        clipboardAdapter.setSelectionMode(true)
        if (initialSelectedId != null) {
            clipboardAdapter.toggleSelection(initialSelectedId)
        } else {
            updateSelectionDisplay()
        }
    }

    fun stopSelectionMode() {
        if (!this::clipboardAdapter.isInitialized) return
        dismissActionPill()
        clipboardAdapter.setSelectionMode(false)
        selectionCountTextView = null
        selectionSelectAllButton = null
        selectionPinButton = null
        selectionDeleteButton = null

        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip ?: return
        clipboardStrip.removeAllViews()
        toolbarKeys.forEach { clipboardStrip.addView(it) }
        applyClipboardToolbarKeyLayoutParams()
        clipboardStrip.post { applyClipboardToolbarKeyLayoutParams() }
        updateEmptyView(clipboardAdapter.isFiltering)
    }

    fun updateSelectionDisplay(
        selectedCount: Int = if (this::clipboardAdapter.isInitialized) clipboardAdapter.selectedEntryIds.size else 0,
        totalCount: Int = if (this::clipboardAdapter.isInitialized) clipboardAdapter.getAllClipEntries().size else 0
    ) {
        val countView = selectionCountTextView ?: return
        countView.text = if (selectedCount == 0) {
            context.getString(R.string.clipboard_select_items)
        } else {
            context.getString(R.string.clipboard_selected_count, selectedCount)
        }

        val colors = Settings.getValues().mColors

        selectionSelectAllButton?.let { btn ->
            val allSelected = selectedCount == totalCount && totalCount > 0
            btn.contentDescription = context.getString(
                if (allSelected) R.string.clipboard_action_deselect_all else R.string.clipboard_action_select_all
            )
            btn.setColorFilter(if (allSelected) colors.get(ColorType.ACTION_KEY_BACKGROUND) else colors.get(ColorType.KEY_ICON))
        }

        val hasSelection = selectedCount > 0
        selectionPinButton?.let { btn ->
            btn.isEnabled = hasSelection
            btn.alpha = if (hasSelection) 1.0f else 0.4f
            val selected = clipboardAdapter.getSelectedEntries()
            val allPinned = selected.isNotEmpty() && selected.all { it.isPinned }
            btn.contentDescription = context.getString(
                if (allPinned) R.string.clipboard_action_unpin else R.string.clipboard_action_pin
            )
            btn.setColorFilter(if (allPinned) colors.get(ColorType.CLIPBOARD_PIN) else colors.get(ColorType.KEY_ICON))
        }

        selectionDeleteButton?.let { btn ->
            btn.isEnabled = hasSelection
            btn.alpha = if (hasSelection) 1.0f else 0.4f
        }
    }

    fun dismissActionPill(): Boolean {
        val overlay = actionPillOverlay ?: return false
        val pill = actionPill
        if (overlay.visibility == View.VISIBLE) {
            val anchor = activeAnchorView
            activeAnchorView = null
            if (anchor != null) {
                anchor.animate()
                    ?.scaleX(1.0f)
                    ?.scaleY(1.0f)
                    ?.setDuration(140)
                    ?.setInterpolator(android.view.animation.DecelerateInterpolator())
                    ?.withEndAction {
                        anchor.translationZ = 0f
                    }
                    ?.start()
            }

            if (pill != null) {
                pill.animate()
                    ?.alpha(0f)
                    ?.scaleX(0.85f)
                    ?.scaleY(0.85f)
                    ?.setDuration(100)
                    ?.setInterpolator(android.view.animation.AccelerateInterpolator())
                    ?.withEndAction {
                        overlay.visibility = View.GONE
                        overlay.background = null
                        pill.alpha = 1f
                        pill.scaleX = 1f
                        pill.scaleY = 1f
                    }
                    ?.start()
            } else {
                overlay.visibility = View.GONE
                overlay.background = null
            }
            return true
        }
        return false
    }

    private fun showClipActionPill(entry: ClipboardHistoryEntry, anchorView: View): Boolean {
        val overlay = actionPillOverlay ?: return false
        val pill = actionPill ?: return false
        val pinBtn = actionPinButton ?: return false
        val editBtn = actionEditButton ?: return false
        val deleteBtn = actionDeleteButton ?: return false
        val selectBtn = actionSelectButton ?: return false
        findViewById<View>(R.id.clip_action_section)?.setOnClickListener {
            dismissActionPill()
            startMoveToSection(listOf(entry.id))
        }

        // Dismiss any existing pill and reset prior anchor view
        dismissActionPill()
        activeAnchorView = anchorView

        // Animate anchor view lift
        anchorView.translationZ = 4.dpToPx(resources).toFloat()
        anchorView.animate()
            ?.scaleX(1.025f)
            ?.scaleY(1.025f)
            ?.setDuration(180)
            ?.setInterpolator(android.view.animation.OvershootInterpolator(1.2f))
            ?.start()

        val colors = Settings.getValues().mColors
        val cardBg = colors.get(ColorType.POPUP_KEYS_BACKGROUND)
        val mainBg = colors.get(ColorType.MAIN_BACKGROUND)
        val isDark = isDarkColor(mainBg) || isDarkColor(cardBg)

        // isDarkColor is only true for near-black colors, so a mid-tone theme with light icons must not get a white pill
        val iconsAreLight = ColorUtils.calculateLuminance(colors.get(ColorType.KEY_ICON)) > 0.5
        val pillFillColor = if (isDark || iconsAreLight) {
            colors.get(ColorType.TOOL_BAR_EXPAND_KEY_BACKGROUND)
        } else {
            Color.WHITE
        }

        val pillRadius = 24.dpToPx(resources).toFloat()
        val pillDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = pillRadius
            setColor(pillFillColor)
        }
        pill.background = pillDrawable
        pill.clipToOutline = true
        pill.elevation = 8.dpToPx(resources).toFloat()

        overlay.setBackgroundColor(if (isDark) 0x44000000.toInt() else 0x22000000)

        // Configure Pin button
        val pinIconRes = if (pinIconId != 0) pinIconId else R.drawable.ic_clipboard_pin_rounded
        pinBtn.setImageResource(pinIconRes)
        if (entry.isPinned) {
            pinBtn.contentDescription = context.getString(R.string.clipboard_action_unpin)
            colors.setColor(pinBtn, ColorType.CLIPBOARD_PIN)
        } else {
            pinBtn.contentDescription = context.getString(R.string.clipboard_action_pin)
            colors.setColor(pinBtn, ColorType.KEY_ICON)
        }
        pinBtn.setOnClickListener {
            dismissActionPill()
            clipboardHistoryManager.toggleClipPinned(entry.id)
        }

        // Configure Edit button
        if (entry.imageUri == null && !entry.text.isNullOrEmpty()) {
            editBtn.visibility = View.VISIBLE
            colors.setColor(editBtn, ColorType.KEY_ICON)
            editBtn.setOnClickListener {
                dismissActionPill()
                startEditMode(entry)
            }
        } else {
            editBtn.visibility = View.GONE
        }

        // Configure Delete button
        colors.setColor(deleteBtn, ColorType.KEY_ICON)
        deleteBtn.setOnClickListener {
            dismissActionPill()
            deleteSingleEntry(entry)
        }

        // Configure Select button
        colors.setColor(selectBtn, ColorType.KEY_ICON)
        selectBtn.setOnClickListener {
            dismissActionPill()
            startSelectionMode(initialSelectedId = entry.id)
        }

        // LeanType A: shortcut word that offers this clip in the suggestion strip
        findViewById<View>(R.id.clip_action_shortcut)?.let { sc ->
            if (entry.imageUri == null && entry.text.isNotEmpty() && ClipboardOptions.shortcutsOn(context.prefs())) {
                sc.visibility = View.VISIBLE
                sc.setOnClickListener {
                    dismissActionPill()
                    shortcutEntryId = entry.id
                    startSearchMode(SearchPurpose.SET_SHORTCUT, ClipboardOptions.shortcutOfClip(context.prefs(), entry.id) ?: "")
                }
            } else {
                sc.visibility = View.GONE
            }
        }

        overlay.visibility = View.VISIBLE

        // Measure pill to calculate target position
        pill.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val pillWidth = pill.measuredWidth
        val pillHeight = pill.measuredHeight

        val anchorLoc = IntArray(2)
        anchorView.getLocationInWindow(anchorLoc)
        val overlayLoc = IntArray(2)
        overlay.getLocationInWindow(overlayLoc)

        val relX = anchorLoc[0] - overlayLoc[0]
        val relY = anchorLoc[1] - overlayLoc[1]

        val containerWidth = overlay.width.takeIf { it > 0 } ?: measuredWidth
        val containerHeight = overlay.height.takeIf { it > 0 } ?: measuredHeight

        val margin = 8.dpToPx(resources)
        val targetX = (relX + (anchorView.width - pillWidth) / 2).coerceIn(margin, (containerWidth - pillWidth - margin).coerceAtLeast(0))

        val gap = 6.dpToPx(resources)
        val preferredY = relY - pillHeight - gap
        val targetY = if (preferredY >= 4.dpToPx(resources)) {
            preferredY
        } else {
            (relY + anchorView.height + gap).coerceAtMost(containerHeight - pillHeight - 4.dpToPx(resources))
        }

        val startY = targetY.toFloat() + (if (preferredY >= 4.dpToPx(resources)) 6.dpToPx(resources) else -6.dpToPx(resources))
        pill.translationX = targetX.toFloat()
        pill.translationY = startY

        pill.alpha = 0f
        pill.scaleX = 0.82f
        pill.scaleY = 0.82f
        pill.animate()
            ?.alpha(1f)
            ?.scaleX(1f)
            ?.scaleY(1f)
            ?.translationY(targetY.toFloat())
            ?.setDuration(180)
            ?.setInterpolator(android.view.animation.OvershootInterpolator(1.15f))
            ?.start()

        return true
    }

    private fun deleteSingleEntry(entry: ClipboardHistoryEntry) {
        clipboardRecyclerView.dismissUndoBar()
        dismissConfirmationBar()
        val deleted = clipboardHistoryManager.deleteEntryById(entry.id)
        if (deleted != null) {
            clipboardAdapter.refresh()
            clipboardRecyclerView.showUndoBar(listOf(deleted))
        }
    }

    private val currentBottomRowLayout: Int
        get() {
            val keyboardView = findViewById<MainKeyboardView>(R.id.bottom_row_keyboard) ?: return KeyboardId.ELEMENT_ALPHABET
            return keyboardView.keyboard?.mId?.mElementId ?: KeyboardId.ELEMENT_ALPHABET
        }

    private fun isLayoutSwitchCode(code: Int): Boolean {
        return code == KeyCode.SYMBOL || code == KeyCode.SYMBOL_ALPHA || code == KeyCode.ALPHA
                || code == KeyCode.SHIFT || code == KeyCode.CAPS_LOCK || code == KeyCode.NUMPAD
    }

    private fun handleLayoutSwitchInEditOrSearch(primaryCode: Int): Boolean {
        if (primaryCode == KeyCode.NUMPAD) {
            val isOnNumpad = currentBottomRowLayout == KeyboardId.ELEMENT_NUMPAD
            val targetId = if (isOnNumpad) KeyboardId.ELEMENT_ALPHABET else KeyboardId.ELEMENT_NUMPAD
            setBottomRowLayout(targetId)
            return true
        }
        if (primaryCode == KeyCode.ALPHA) {
            setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
            return true
        }
        if (primaryCode == KeyCode.SYMBOL || primaryCode == KeyCode.SYMBOL_ALPHA) {
            val isOnSymbols = currentBottomRowLayout == KeyboardId.ELEMENT_SYMBOLS
                    || currentBottomRowLayout == KeyboardId.ELEMENT_SYMBOLS_SHIFTED
            val targetId = if (isOnSymbols) KeyboardId.ELEMENT_ALPHABET else KeyboardId.ELEMENT_SYMBOLS
            setBottomRowLayout(targetId)
            return true
        }
        if (primaryCode == KeyCode.SHIFT || primaryCode == KeyCode.CAPS_LOCK) {
            val now = android.os.SystemClock.uptimeMillis()
            val isDoubleTap = primaryCode == KeyCode.SHIFT && (now - lastShiftPressTime < android.view.ViewConfiguration.getDoubleTapTimeout())
            lastShiftPressTime = if (primaryCode == KeyCode.SHIFT) now else 0L

            val targetId = when (currentBottomRowLayout) {
                KeyboardId.ELEMENT_SYMBOLS -> KeyboardId.ELEMENT_SYMBOLS_SHIFTED
                KeyboardId.ELEMENT_SYMBOLS_SHIFTED -> KeyboardId.ELEMENT_SYMBOLS
                KeyboardId.ELEMENT_ALPHABET -> {
                    if (primaryCode == KeyCode.CAPS_LOCK) KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED
                    else KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED
                }
                KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED -> {
                    if (primaryCode == KeyCode.CAPS_LOCK || isDoubleTap) KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED
                    else KeyboardId.ELEMENT_ALPHABET
                }
                KeyboardId.ELEMENT_ALPHABET_AUTOMATIC_SHIFTED,
                KeyboardId.ELEMENT_ALPHABET_SHIFT_LOCKED -> KeyboardId.ELEMENT_ALPHABET
                else -> KeyboardId.ELEMENT_ALPHABET
            }
            setBottomRowLayout(targetId)
            return true
        }
        return false
    }

    override fun onCodeInput(primaryCode: Int, x: Int, y: Int, isKeyRepeat: Boolean) {
        val inSearchMode = inSearchMode

        if (inSelectionMode && primaryCode == KeyCode.DELETE) {
            val selected = clipboardAdapter.getSelectedEntries()
            if (selected.isNotEmpty()) {
                val deletedList = clipboardHistoryManager.deleteEntries(selected.map { it.id })
                stopSelectionMode()
                if (deletedList.isNotEmpty()) {
                    clipboardAdapter.refresh()
                    clipboardRecyclerView.showUndoBar(deletedList)
                }
                return
            }
        }
        
        if (inEditMode) {
            if (handleLayoutSwitchInEditOrSearch(primaryCode)) {
                return
            }

            val hasSelection = editSelectionStart >= 0 && editSelectionEnd > editSelectionStart && editSelectionEnd <= editText.length

            fun clearSelection() {
                editSelectionStart = -1
                editSelectionEnd = -1
            }

            fun deleteSelection() {
                if (hasSelection) {
                    editText.delete(editSelectionStart, editSelectionEnd)
                    editCursorPos = editSelectionStart
                    clearSelection()
                }
            }

            val char = if (primaryCode > 0) primaryCode.toChar() else null
            val textBefore = editText.toString()
            val cursorBefore = editCursorPos
            var undoRedoDone = false

            when (primaryCode) {
                KeyCode.UNDO, KeyCode.REDO -> {
                    val from = if (primaryCode == KeyCode.UNDO) editUndoStack else editRedoStack
                    val to = if (primaryCode == KeyCode.UNDO) editRedoStack else editUndoStack
                    if (from.isNotEmpty()) {
                        val (t, c) = from.removeLast()
                        to.addLast(textBefore to cursorBefore)
                        editText.setLength(0)
                        editText.append(t)
                        editCursorPos = c.coerceIn(0, t.length)
                        clearSelection()
                        updateEditDisplay()
                    }
                    undoRedoDone = true
                }
                KeyCode.CLIPBOARD_SELECT_WORD -> {
                    if (editText.isNotEmpty()) {
                        var a = editCursorPos.coerceIn(0, editText.length)
                        var b = a
                        while (a > 0 && !editText[a - 1].isWhitespace()) a--
                        while (b < editText.length && !editText[b].isWhitespace()) b++
                        if (b > a) {
                            editSelectionStart = a
                            editSelectionEnd = b
                            editCursorPos = b
                            updateEditDisplayWithSelection(a, b)
                        }
                    }
                }
                KeyCode.DELETE -> {
                    if (hasSelection) {
                        deleteSelection()
                        updateEditDisplay()
                    } else if (editCursorPos > 0) {
                        editText.deleteCharAt(editCursorPos - 1)
                        editCursorPos--
                        updateEditDisplay()
                    }
                }
                KeyCode.FORWARD_DELETE -> {
                    if (hasSelection) {
                        deleteSelection()
                        updateEditDisplay()
                    } else if (editCursorPos < editText.length) {
                        editText.deleteCharAt(editCursorPos)
                        updateEditDisplay()
                    }
                }
                KeyCode.DELETE_WORD -> {
                    if (hasSelection) {
                        deleteSelection()
                        updateEditDisplay()
                    } else if (editCursorPos > 0) {
                        var i = editCursorPos - 1
                        while (i > 0 && editText[i].isWhitespace()) i--
                        while (i > 0 && !editText[i - 1].isWhitespace()) i--
                        editText.delete(i, editCursorPos)
                        editCursorPos = i
                        updateEditDisplay()
                    }
                }
                KeyCode.FORWARD_DELETE_WORD -> {
                    if (hasSelection) {
                        deleteSelection()
                        updateEditDisplay()
                    } else if (editCursorPos < editText.length) {
                        var i = editCursorPos
                        while (i < editText.length && !editText[i].isWhitespace()) i++
                        while (i < editText.length && editText[i].isWhitespace()) i++
                        editText.delete(editCursorPos, i)
                        updateEditDisplay()
                    }
                }
                Constants.CODE_ENTER -> {
                    deleteSelection()
                    editText.insert(editCursorPos, "\n")
                    editCursorPos++
                    updateEditDisplay()
                }
                Constants.CODE_SPACE -> {
                    deleteSelection()
                    editText.insert(editCursorPos, " ")
                    editCursorPos++
                    updateEditDisplay()
                }
                KeyCode.ARROW_LEFT -> {
                    clearSelection()
                    if (editCursorPos > 0) {
                        editCursorPos--
                        updateEditDisplay()
                    }
                }
                KeyCode.ARROW_RIGHT -> {
                    clearSelection()
                    if (editCursorPos < editText.length) {
                        editCursorPos++
                        updateEditDisplay()
                    }
                }
                KeyCode.ARROW_UP -> {
                    clearSelection()
                    val l = editTextView.layout
                    if (l != null) {
                        val line = l.getLineForOffset(editCursorPos)
                        if (line > 0) {
                            val x = l.getPrimaryHorizontal(editCursorPos)
                            editCursorPos = l.getOffsetForHorizontal(line - 1, x).coerceIn(0, editText.length)
                            updateEditDisplay()
                        }
                    }
                }
                KeyCode.ARROW_DOWN -> {
                    clearSelection()
                    val l = editTextView.layout
                    if (l != null) {
                        val line = l.getLineForOffset(editCursorPos)
                        if (line < l.lineCount - 1) {
                            val x = l.getPrimaryHorizontal(editCursorPos)
                            editCursorPos = l.getOffsetForHorizontal(line + 1, x).coerceIn(0, editText.length)
                            updateEditDisplay()
                        }
                    }
                }
                KeyCode.WORD_LEFT -> {
                    clearSelection()
                    if (editCursorPos > 0) {
                        var i = editCursorPos - 1
                        while (i > 0 && editText[i].isWhitespace()) i--
                        while (i > 0 && !editText[i - 1].isWhitespace()) i--
                        editCursorPos = i
                        updateEditDisplay()
                    }
                }
                KeyCode.WORD_RIGHT -> {
                    clearSelection()
                    if (editCursorPos < editText.length) {
                        var i = editCursorPos
                        while (i < editText.length && !editText[i].isWhitespace()) i++
                        while (i < editText.length && editText[i].isWhitespace()) i++
                        editCursorPos = i
                        updateEditDisplay()
                    }
                }
                KeyCode.MOVE_START_OF_LINE, KeyCode.MOVE_START_OF_PAGE -> {
                    clearSelection()
                    val l = editTextView.layout
                    if (l != null && primaryCode == KeyCode.MOVE_START_OF_LINE) {
                        val line = l.getLineForOffset(editCursorPos)
                        editCursorPos = l.getLineStart(line).coerceIn(0, editText.length)
                    } else {
                        editCursorPos = 0
                    }
                    updateEditDisplay()
                }
                KeyCode.MOVE_END_OF_LINE, KeyCode.MOVE_END_OF_PAGE -> {
                    clearSelection()
                    val l = editTextView.layout
                    if (l != null && primaryCode == KeyCode.MOVE_END_OF_LINE) {
                        val line = l.getLineForOffset(editCursorPos)
                        editCursorPos = l.getLineEnd(line).coerceIn(0, editText.length)
                    } else {
                        editCursorPos = editText.length
                    }
                    updateEditDisplay()
                }
                KeyCode.CLIPBOARD_SELECT_ALL -> {
                    editSelectionStart = 0
                    editSelectionEnd = editText.length
                    editCursorPos = editText.length
                    updateEditDisplayWithSelection(0, editText.length)
                }
                KeyCode.CLIPBOARD_COPY -> {
                    val textToCopy = if (hasSelection) {
                        editText.substring(editSelectionStart, editSelectionEnd)
                    } else {
                        editText.toString()
                    }
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("LeanType", textToCopy))
                }
                KeyCode.CLIPBOARD_CUT -> {
                    val textToCopy = if (hasSelection) {
                        val sub = editText.substring(editSelectionStart, editSelectionEnd)
                        deleteSelection()
                        updateEditDisplay()
                        sub
                    } else {
                        val all = editText.toString()
                        editText.setLength(0)
                        editCursorPos = 0
                        clearSelection()
                        updateEditDisplay()
                        all
                    }
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    cm?.setPrimaryClip(ClipData.newPlainText("LeanType", textToCopy))
                }
                KeyCode.CLIPBOARD_PASTE -> {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val pasteText = cm?.primaryClip?.getItemAt(0)?.text?.toString()
                    if (!pasteText.isNullOrEmpty()) {
                        deleteSelection()
                        editText.insert(editCursorPos, pasteText)
                        editCursorPos += pasteText.length
                        updateEditDisplay()
                    }
                }
                KeyCode.ESCAPE -> {
                    stopEditMode(save = false)
                }
                else -> {
                    if (char != null) {
                        deleteSelection()
                        editText.insert(editCursorPos, char.toString())
                        editCursorPos++
                        updateEditDisplay()
                        if (currentBottomRowLayout == KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED) {
                            setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
                        }
                    }
                }
            }
            if (!undoRedoDone && editText.toString() != textBefore) {
                editUndoStack.addLast(textBefore to cursorBefore)
                if (editUndoStack.size > 200) editUndoStack.removeFirst()
                editRedoStack.clear()
            }
            return
        }

        if (inSearchMode) {
            if (handleLayoutSwitchInEditOrSearch(primaryCode)) {
                return
            }

            val char = if (primaryCode > 0) primaryCode.toChar() else null
            
            if (primaryCode == KeyCode.DELETE) {
                if (searchCursorPos > 0) {
                    searchQuery.deleteCharAt(searchCursorPos - 1)
                    searchCursorPos--
                    updateSearchDisplay()
                    onSearchQueryChanged()
                }
            } else if (primaryCode == Constants.CODE_ENTER) {
                val committedId = if (searchPurpose != SearchPurpose.SEARCH) commitSectionInput() else null
                val wasNew = searchPurpose == SearchPurpose.NEW_SECTION
                stopSearchMode()
                if (committedId != null && wasNew) selectSection(committedId)
            } else if (primaryCode == Constants.CODE_SPACE) {
                searchQuery.insert(searchCursorPos, " ")
                searchCursorPos++
                updateSearchDisplay()
                onSearchQueryChanged()
            } else if (primaryCode == KeyCode.ARROW_LEFT) {
                if (searchCursorPos > 0) {
                    searchCursorPos--
                    updateSearchDisplay()
                }
            } else if (primaryCode == KeyCode.ARROW_RIGHT) {
                if (searchCursorPos < searchQuery.length) {
                    searchCursorPos++
                    updateSearchDisplay()
                }
            } else if (char != null) {
                searchQuery.insert(searchCursorPos, char.toString())
                searchCursorPos++
                updateSearchDisplay()
                onSearchQueryChanged()
                if (currentBottomRowLayout == KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED) {
                    setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
                }
            } else {
                 stopSearchMode()
                 keyboardActionListener.onCodeInput(primaryCode, x, y, isKeyRepeat)
            }
            return 
        }
        
        keyboardActionListener.onCodeInput(primaryCode, x, y, isKeyRepeat)
    }
    
    override fun onTextInput(text: String?) {
         if (text == null) return
         if (inEditMode) {
              editUndoStack.addLast(editText.toString() to editCursorPos)
              if (editUndoStack.size > 200) editUndoStack.removeFirst()
              editRedoStack.clear()
              if (editSelectionStart >= 0 && editSelectionEnd > editSelectionStart && editSelectionEnd <= editText.length) {
                  editText.delete(editSelectionStart, editSelectionEnd)
                  editCursorPos = editSelectionStart
                  editSelectionStart = -1
                  editSelectionEnd = -1
              }
              editText.insert(editCursorPos, text)
              editCursorPos += text.length
              updateEditDisplay()
              if (currentBottomRowLayout == KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED) {
                  setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
              }
              return
         }

         if (inSearchMode) {
              searchQuery.insert(searchCursorPos, text)
              searchCursorPos += text.length
              updateSearchDisplay()
              onSearchQueryChanged()
              updateEmptyView(true)
              if (currentBottomRowLayout == KeyboardId.ELEMENT_ALPHABET_MANUAL_SHIFTED) {
                  setBottomRowLayout(KeyboardId.ELEMENT_ALPHABET)
              }
              return
         }
         
         keyboardActionListener.onTextInput(text)
    }

    override fun onImageSelected(imageUri: String) {
         keyboardActionListener.onImageSelected(imageUri)
    }

    override fun onPressKey(primaryCode: Int, repeatCount: Int, isSinglePointer: Boolean, hapticEvent: HapticEvent) {
        if ((inEditMode || inSearchMode) && isLayoutSwitchCode(primaryCode)) return
        keyboardActionListener.onPressKey(primaryCode, repeatCount, isSinglePointer, hapticEvent)
    }
    override fun onReleaseKey(primaryCode: Int, withSliding: Boolean) {
        if ((inEditMode || inSearchMode) && isLayoutSwitchCode(primaryCode)) return
        keyboardActionListener.onReleaseKey(primaryCode, withSliding)
    }
    override fun onLongPressKey(primaryCode: Int) {
        keyboardActionListener.onLongPressKey(primaryCode)
    }
    override fun onKeyDown(keyCode: Int, keyEvent: android.view.KeyEvent): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (dismissActionPill()) return true
            if (optionsPanel?.visibility == View.VISIBLE) {
                hideOptionsPanel()
                return true
            }
            if (inEditMode) {
                stopEditMode(save = false)
                return true
            }
            if (inSearchMode) {
                searchQuery.clear()
                stopSearchMode()
                return true
            }
            if (inSelectionMode) {
                stopSelectionMode()
                return true
            }
        }
        return keyboardActionListener.onKeyDown(keyCode, keyEvent)
    }
    override fun onKeyUp(keyCode: Int, keyEvent: android.view.KeyEvent): Boolean {
        return keyboardActionListener.onKeyUp(keyCode, keyEvent)
    }
    override fun onStartBatchInput() { keyboardActionListener.onStartBatchInput() }
    override fun onUpdateBatchInput(p: helium314.keyboard.latin.common.InputPointers) { keyboardActionListener.onUpdateBatchInput(p) }
    override fun onEndBatchInput(p: helium314.keyboard.latin.common.InputPointers) { keyboardActionListener.onEndBatchInput(p) }
    override fun onCancelBatchInput() { keyboardActionListener.onCancelBatchInput() }
    override fun onCancelInput() { keyboardActionListener.onCancelInput() }
    override fun onFinishSlidingInput() { keyboardActionListener.onFinishSlidingInput() }
    override fun onCustomRequest(requestCode: Int): Boolean { return keyboardActionListener.onCustomRequest(requestCode) }
    override fun onHorizontalSpaceSwipe(steps: Int): Boolean {
        if (inEditMode) {
            editSelectionStart = -1
            editSelectionEnd = -1
            val newPos = (editCursorPos + steps).coerceIn(0, editText.length)
            if (newPos != editCursorPos) {
                editCursorPos = newPos
                updateEditDisplay()
            }
            return true
        }
        if (inSearchMode) {
            val newPos = (searchCursorPos + steps).coerceIn(0, searchQuery.length)
            if (newPos != searchCursorPos) {
                searchCursorPos = newPos
                updateSearchDisplay()
            }
            return true
        }
        return keyboardActionListener.onHorizontalSpaceSwipe(steps)
    }
    override fun onVerticalSpaceSwipe(steps: Int, action: Int): Boolean {
        if (inEditMode || inSearchMode) {
            if (action == KeyboardActionListener.SWIPE_TOGGLE_NUMPAD) {
                return toggleNumpad(false, false)
            }
            return true
        }
        return keyboardActionListener.onVerticalSpaceSwipe(steps, action)
    }
    override fun onEndSpaceSwipe() { keyboardActionListener.onEndSpaceSwipe() }
    override fun toggleNumpad(w: Boolean, f: Boolean): Boolean {
        if (inEditMode || inSearchMode) {
            val isOnNumpad = currentBottomRowLayout == KeyboardId.ELEMENT_NUMPAD
            val targetId = if (isOnNumpad) KeyboardId.ELEMENT_ALPHABET else KeyboardId.ELEMENT_NUMPAD
            setBottomRowLayout(targetId)
            return true
        }
        return keyboardActionListener.toggleNumpad(w, f)
    }
    override fun onMoveDeletePointer(steps: Int) {
        if (inEditMode) {
            if (deleteSwipeStartPos == -1) {
                deleteSwipeStartPos = editCursorPos
                currentDeleteSwipePos = editCursorPos
            }
            currentDeleteSwipePos = (currentDeleteSwipePos + steps).coerceIn(0, editText.length)
            editSelectionStart = minOf(deleteSwipeStartPos, currentDeleteSwipePos)
            editSelectionEnd = maxOf(deleteSwipeStartPos, currentDeleteSwipePos)
            updateEditDisplayWithSelection(
                editSelectionStart,
                editSelectionEnd
            )
            return
        }
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip
        val inSearch = inSearchMode
        if (inSearch) {
            if (deleteSwipeStartPos == -1) {
                deleteSwipeStartPos = searchCursorPos
                currentDeleteSwipePos = searchCursorPos
            }
            currentDeleteSwipePos = (currentDeleteSwipePos + steps).coerceIn(0, searchQuery.length)
            updateSearchDisplayWithSelection(
                minOf(deleteSwipeStartPos, currentDeleteSwipePos),
                maxOf(deleteSwipeStartPos, currentDeleteSwipePos)
            )
            return
        }
        keyboardActionListener.onMoveDeletePointer(steps)
    }
    override fun onUpWithDeletePointerActive() {
        if (inEditMode) {
            if (deleteSwipeStartPos != -1 && currentDeleteSwipePos != -1) {
                val start = minOf(deleteSwipeStartPos, currentDeleteSwipePos)
                val end = maxOf(deleteSwipeStartPos, currentDeleteSwipePos)
                if (start < end) {
                    editText.delete(start, end)
                    editCursorPos = start
                }
            }
            deleteSwipeStartPos = -1
            currentDeleteSwipePos = -1
            editSelectionStart = -1
            editSelectionEnd = -1
            updateEditDisplay()
            return
        }
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip
        val inSearch = inSearchMode
        if (inSearch) {
            if (deleteSwipeStartPos != -1 && currentDeleteSwipePos != -1) {
                val start = minOf(deleteSwipeStartPos, currentDeleteSwipePos)
                val end = maxOf(deleteSwipeStartPos, currentDeleteSwipePos)
                if (start < end) {
                    searchQuery.delete(start, end)
                    searchCursorPos = start
                }
            }
            deleteSwipeStartPos = -1
            currentDeleteSwipePos = -1
            updateSearchDisplay()
            onSearchQueryChanged()
            return
        }
        keyboardActionListener.onUpWithDeletePointerActive()
    }
    override fun resetMetaState() { keyboardActionListener.resetMetaState() }
    
    private fun setupClipKey(params: KeyDrawParams) {
        val fontMultiplier = Settings.getValues().mFontSizeMultiplier
        val clipFontScale = Settings.getValues().mClipboardFontScale
        val baseTextSize = 15.5f * resources.displayMetrics.scaledDensity
        clipboardAdapter.apply {
            itemBackgroundId = keyBackgroundId
            itemTypeFace = params.mTypeface
            itemTextColor = params.mTextColor
            itemTextSize = baseTextSize * fontMultiplier * clipFontScale
        }
    }

    private fun setupToolbarKeys() {
        applyClipboardToolbarKeyLayoutParams()
        KeyboardSwitcher.getInstance().clipboardStrip?.post { applyClipboardToolbarKeyLayoutParams() }
    }

    private fun setupBottomRowKeyboard(editorInfo: EditorInfo, listener: KeyboardActionListener) {
        // Initial setup only
        this.editorInfo = editorInfo
        this.keyboardActionListener = listener
        setBottomRowLayout(KeyboardId.ELEMENT_CLIPBOARD_BOTTOM_ROW)
    }

    private fun setBottomRowLayout(elementId: Int) {
        val editorInfo = this.editorInfo ?: return
        val keyboardView = findViewById<MainKeyboardView>(R.id.bottom_row_keyboard)
        keyboardView.setKeyPreviewPopupEnabled(Settings.getValues().mKeyPreviewPopupOn)
        keyboardView.setKeyboardActionListener(this)  // Set 'this' as listener to intercept
        PointerTracker.switchTo(keyboardView)
        val kls = KeyboardLayoutSet.Builder.buildEmojiClipBottomRow(context, if (inEditMode || inSearchMode) null else editorInfo)
        val keyboard = kls.getKeyboard(elementId)
        keyboardView.setKeyboard(keyboard)
    }

    fun setHardwareAcceleratedDrawingEnabled(enabled: Boolean) {
        if (!enabled) return
        // TODO: Should use LAYER_TYPE_SOFTWARE when hardware acceleration is off?
        setLayerType(LAYER_TYPE_HARDWARE, null)
        findViewById<MainKeyboardView>(R.id.bottom_row_keyboard)?.setHardwareAcceleratedDrawingEnabled(enabled)
    }

    fun startClipboardHistory(
            historyManager: ClipboardHistoryManager,
            keyVisualAttr: KeyVisualAttributes?,
            editorInfo: EditorInfo,
            keyboardActionListener: KeyboardActionListener
    ) {
        clipboardHistoryManager = historyManager
        initialize()
        setupToolbarKeys()
        historyManager.prepareClipboardHistory()
        historyManager.sortHistoryEntries()
        historyManager.setHistoryChangeListener(this)
        clipboardAdapter.clipboardHistoryManager = historyManager
        hideOptionsPanel()
        applyClipboardOptions()
        activeSectionId = null
        pendingMoveIds = null
        optionsSectionId = null
        clipboardAdapter.activeSection = null

        // Stop edit mode or selection mode if left active
        if (inEditMode) {
            stopEditMode(save = false)
        }
        if (inSelectionMode) {
            stopSelectionMode()
        }

        // Clear search on start
        searchQuery.clear()
        clipboardAdapter.filter("")
        stopSearchMode()

        clipboardLayoutParams.updateDimensions(context)
        findViewById<View>(R.id.clipboard_content_container)?.let { container ->
            container.visibility = View.VISIBLE
            val lp = container.layoutParams
            if (lp != null && lp.height != clipboardLayoutParams.listHeight) {
                lp.height = clipboardLayoutParams.listHeight
                container.layoutParams = lp
            }
        }
        clipboardRecyclerView.visibility = View.VISIBLE
        updateEmptyView(false)
        rebuildIconBar()

        val params = KeyDrawParams()
        params.updateParams(clipboardLayoutParams.bottomRowKeyHeight, keyVisualAttr)
        val settings = Settings.getInstance()
        settings.getCustomTypeface()?.let { params.mTypeface = it }
        setupClipKey(params)
        // LeanType A: the colours chosen for the clipboard (Colors > Quick colors) win over the theme.
        run {
            val bg = helium314.keyboard.latin.AClipColors.get(context, helium314.keyboard.latin.AClipColors.CLIP_BACKGROUND)
            val card = helium314.keyboard.latin.AClipColors.get(context, helium314.keyboard.latin.AClipColors.CLIP_CARDS)
            val themeColors = Settings.getValues().mColors
            // No chosen colour: follow the theme (background, keys, key text), never a fixed dark.
            setBackgroundColor(bg ?: themeColors.get(ColorType.MAIN_BACKGROUND))
            clipboardAdapter.cardColor = card ?: themeColors.get(ColorType.KEY_BACKGROUND)
            clipboardAdapter.itemTextColor = if (card != null)
                (if (helium314.keyboard.latin.utils.isDarkColor(card)) android.graphics.Color.WHITE else android.graphics.Color.BLACK)
            else themeColors.get(ColorType.KEY_TEXT)
            clipboardAdapter.notifyDataSetChanged()
        }
        setupBottomRowKeyboard(editorInfo, keyboardActionListener)

        // Typeface for empty text
        params.mTypeface?.let { tf ->
            emptyViewText.typeface = tf
        }

        val keyboardWidth = ResourceUtils.getKeyboardWidth(context, settings.current)
        val keyboardAttr = context.obtainStyledAttributes(
            null, R.styleable.Keyboard, R.attr.keyboardStyle, R.style.Keyboard)
        val leftPadding = (keyboardAttr.getFraction(R.styleable.Keyboard_keyboardLeftPadding,
            keyboardWidth, keyboardWidth, 0f)
                * settings.current.mSidePaddingScale).toInt()
        val rightPadding =  (keyboardAttr.getFraction(R.styleable.Keyboard_keyboardRightPadding,
            keyboardWidth, keyboardWidth, 0f)
                * settings.current.mSidePaddingScale).toInt()
        keyboardAttr.recycle()

        clipboardRecyclerView.apply {
            adapter = clipboardAdapter
            layoutParams.width = keyboardWidth
            setPadding(leftPadding, paddingTop, rightPadding, paddingBottom)
        }
        
        // absurd workaround so Android sets the correct color from stateList (depending on "activated")
        toolbarKeys.forEach { it.isEnabled = false; it.isEnabled = true }
    }

    override fun onKeyDown(clipId: Long) {
        keyboardActionListener.onPressKey(KeyCode.NOT_SPECIFIED, 0, true, HapticEvent.KEY_PRESS)
    }

    override fun onKeyUp(clipId: Long) {
        val clipContent = clipboardHistoryManager.getHistoryEntryContent(clipId) ?: return
        if (clipContent.imageUri != null) {
            keyboardActionListener.onImageSelected(clipContent.imageUri)
        } else {
            keyboardActionListener.onTextInput(clipContent.text)
        }
        keyboardActionListener.onReleaseKey(KeyCode.NOT_SPECIFIED, false)
        // LeanType A: a pasted entry moves to the top, as if it had just been copied.
        runCatching { clipboardHistoryManager.moveToTop(clipContent.text, clipContent.imageUri) }
        if (Settings.getValues().mAlphaAfterClipHistoryEntry)
            keyboardActionListener.onCodeInput(KeyCode.ALPHA, Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, false)
    }
 


    fun stopClipboardHistory(force: Boolean = false) {
        removeCallbacks(cursorBlinkRunnable)
        if (!this::clipboardAdapter.isInitialized) return

        if (!force && (isShown || visibility == View.VISIBLE)) {
            return
        }

        // Stop edit mode if active
        if (inEditMode) {
            stopEditMode(save = false)
        }
        
        // Also ensure search mode is stopped if we explicitly leave clipboard history
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip
        val inSearch = inSearchMode
        if (inSearch) {
            stopSearchMode()
        }

        if (inSelectionMode) {
            stopSelectionMode()
        }

        // Dismiss any active undo bar
        clipboardRecyclerView.dismissUndoBar()
        dismissConfirmationBar()
        
        clipboardRecyclerView.adapter = null
        clipboardHistoryManager.setHistoryChangeListener(null)
        clipboardAdapter.clipboardHistoryManager = null

        PointerTracker.setClipboardInlineInputActive(false)
    }

    fun showClearAllConfirmationBar() {
        clipboardRecyclerView.dismissUndoBar()
        val bar = confirmationBar ?: return
        confirmationHandler.removeCallbacks(confirmationDismissRunnable)
        bar.visibility = View.VISIBLE
        confirmationHandler.postDelayed(confirmationDismissRunnable, 5000)
    }

    fun dismissConfirmationBar() {
        confirmationHandler.removeCallbacks(confirmationDismissRunnable)
        confirmationBar?.visibility = View.GONE
    }

    override fun onClick(view: View) {
        val tag = view.tag
        if (tag is ToolbarKey) {
            AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, this, HapticEvent.KEY_PRESS)
            val code = getCodeForToolbarKey(tag)
            if (code == KeyCode.CLIPBOARD_SEARCH) {
                 toggleSearch()
                 return
            }
            if (code == KeyCode.CLIPBOARD_CLEAR_HISTORY) {
                showClearAllConfirmationBar()
                return
            }
            if (code != KeyCode.UNSPECIFIED) {
                keyboardActionListener.onCodeInput(code, Constants.NOT_A_COORDINATE, Constants.NOT_A_COORDINATE, false)
                return
            }
        }
    }

    override fun onLongClick(view: View): Boolean {
        val tag = view.tag
        if (tag is ToolbarKey) {
            AudioAndHapticFeedbackManager.getInstance().performHapticAndAudioFeedback(KeyCode.NOT_SPECIFIED, this, HapticEvent.KEY_LONG_PRESS)
            val code = getCodeForToolbarKey(tag)
            if (code == KeyCode.CLIPBOARD_CLEAR_HISTORY) {
                dismissConfirmationBar()
                clipboardHistoryManager.clearHistory()
                return true
            }
            val longClickCode = getCodeForToolbarKeyLongClick(tag)
            if (longClickCode != KeyCode.UNSPECIFIED) {
                keyboardActionListener.onCodeInput(
                    longClickCode,
                    Constants.NOT_A_COORDINATE,
                    Constants.NOT_A_COORDINATE,
                    false
                )
            }
            return true
        }
        return false
    }



    override fun onClipInserted(position: Int) {
        confirmationHandler.post {
            clipboardAdapter.refresh()
            if (!clipboardAdapter.isFiltering) {
                 clipboardRecyclerView.smoothScrollToPosition(0)
            }
            updateEmptyView(clipboardAdapter.isFiltering)
        }
    }

    override fun onClipsRemoved(position: Int, count: Int) {
        confirmationHandler.post {
            clipboardAdapter.refresh()
            rebuildIconBar()
            updateEmptyView(clipboardAdapter.isFiltering)
        }
    }

    override fun onClipMoved(oldPosition: Int, newPosition: Int) {
        confirmationHandler.post {
            clipboardAdapter.refresh()
            rebuildIconBar()
        }
    }

    override fun onClipChanged(position: Int) {
        confirmationHandler.post {
            clipboardAdapter.refresh()
        }
    }

    override fun onSharedPreferenceChanged(prefs: SharedPreferences?, key: String?) {
        setToolbarButtonsActivatedStateOnPrefChange(KeyboardSwitcher.getInstance().clipboardStrip ?: return, key)

        if (key == Settings.PREF_AUTO_SPAN_TOOLBAR_KEYS || key == Settings.PREF_TOOLBAR_KEYS_ALIGNMENT || key == Settings.PREF_CLIPBOARD_KEYS_ALIGNMENT || key == Settings.PREF_CLIPBOARD_TOOLBAR_KEYS) {
            applyClipboardToolbarKeyLayoutParams()
            KeyboardSwitcher.getInstance().clipboardStrip?.post { applyClipboardToolbarKeyLayoutParams() }
        }

        if (::clipboardHistoryManager.isInitialized && 
            (key == Settings.PREF_CLIPBOARD_HISTORY_PINNED_FIRST || key == Settings.PREF_CLIPBOARD_FOLD_PINNED)) {
            // Ensure settings are reloaded first
            Settings.getInstance().onSharedPreferenceChanged(prefs, key)
            clipboardHistoryManager.sortHistoryEntries()
            confirmationHandler.post {
                clipboardAdapter.refresh()
            }
        }
    }

    private fun applyClipboardToolbarKeyLayoutParams() {
        val clipboardStrip = KeyboardSwitcher.getInstance().clipboardStrip ?: return
        val count = clipboardStrip.childCount
        if (count == 0) return

        val inSearchMode = inSearchMode
        if (inEditMode || inSearchMode || inSelectionMode) return

        val singleKeyWidth = kotlin.math.min(
            context.resources.getDimensionPixelSize(R.dimen.config_suggestions_strip_edge_key_width),
            context.resources.getDimensionPixelSize(R.dimen.config_suggestions_strip_height)
        )

        val visibleCount = (0 until count).count {
            val child = clipboardStrip.getChildAt(it)
            child != null && child.visibility != View.GONE
        }
        if (visibleCount == 0) return

        val keyboardWidth = ResourceUtils.getKeyboardWidth(context, Settings.getValues())
        val parentView = (clipboardStrip.parent as? View)
        val containerWidth = parentView?.width?.takeIf { it > 0 }
            ?: parentView?.measuredWidth?.takeIf { it > 0 }
            ?: keyboardWidth

        val isAutoSpan = Settings.getValues().mAutoSpanToolbarKeys
        val canSpan = containerWidth > 0 && (containerWidth >= visibleCount * singleKeyWidth)
        val useEqualSpacing = isAutoSpan && canSpan

        val alignmentGravity = when (Settings.getValues().mClipboardKeysAlignment) {
            "left" -> Gravity.START or Gravity.CENTER_VERTICAL
            "center" -> Gravity.CENTER
            else -> Gravity.END or Gravity.CENTER_VERTICAL
        }
        clipboardStrip.gravity = if (useEqualSpacing) Gravity.NO_GRAVITY else alignmentGravity

        val toolbarKeyLayoutParams = LinearLayout.LayoutParams(
            singleKeyWidth,
            singleKeyWidth
        ).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val spannedLayoutParams = LinearLayout.LayoutParams(0, singleKeyWidth, 1f).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val toolbarContainer = clipboardStrip.parent as? HorizontalScrollView
        toolbarContainer?.let { hsv ->
            hsv.overScrollMode = if (useEqualSpacing) View.OVER_SCROLL_NEVER else View.OVER_SCROLL_IF_CONTENT_SCROLLS
            if (useEqualSpacing) hsv.scrollTo(0, 0)
        }

        for (i in 0 until count) {
            val child = clipboardStrip.getChildAt(i) ?: continue
            if (child.visibility == View.GONE) continue
            child.minimumWidth = 0
            child.minimumHeight = 0
            child.layoutParams = if (useEqualSpacing) {
                spannedLayoutParams
            } else {
                toolbarKeyLayoutParams
            }
        }
    }

    private fun updateClipboardGestureSuppression() {
        PointerTracker.setClipboardInlineInputActive(false)
    }

    private fun stopActiveCursorAndOverlayOnHide() {
        removeCallbacks(cursorBlinkRunnable)
        clearPendingCursorVisibility()
        dismissActionPill()
        PointerTracker.setClipboardInlineInputActive(false)
    }

    override fun onDetachedFromWindow() {
        if (inEditMode) {
            stopEditMode(save = false)
        } else if (inSearchMode) {
            stopSearchMode()
        }
        clearPendingCursorVisibility()
        dismissActionPill()
        PointerTracker.setClipboardInlineInputActive(false)
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (!isShown) {
            stopActiveCursorAndOverlayOnHide()
        } else {
            updateClipboardGestureSuppression()
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != VISIBLE) {
            stopActiveCursorAndOverlayOnHide()
        } else if ((inEditMode || inSearchMode) && isShown && isAttachedToWindow) {
            resetCursorBlink()
        }
    }
}
