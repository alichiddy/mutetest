package a.a.flow

import android.content.Context
import org.json.JSONObject

/**
 * How the Scripts window orders its list. Everything is worked out only when the window sorts and
 * is dropped again afterwards. Scripts without a date ("unknown") always go to the end.
 */
object FlowSort {
    /** key to the words shown in the Sort box, in the order they are listed. */
    val MODES: List<Pair<String, String>> = listOf(
        "running" to "Running now first",
        "name_asc" to "Name (A-Z)",
        "name_desc" to "Name (Z-A)",
        "size_asc" to "Size (Smaller)",
        "size_desc" to "Size (Larger)",
        "date_asc" to "Date (Older)",
        "date_desc" to "Date (Newer)",
        "type_asc" to "Type (Ascending)",
        "type_desc" to "Type (Descending)",
        "opened" to "Last Opened",
        "edited" to "Last Edited",
        "added" to "Last Added",
        "created" to "Last Created",
        "lastrun" to "Last Run",
        "mostrun" to "Most Run",
    )

    fun label(key: String): String = MODES.firstOrNull { it.first == key }?.second ?: MODES[0].second

    /** What is known about one script for sorting and for the line under its name. */
    class Info(val blocks: Int, val bytes: Int, val type: String, val m: LongArray)

    private val NONE = LongArray(6)

    private fun needsSize(key: String) = key.startsWith("size")
    private fun needsType(key: String) = key.startsWith("type")

    /** The facts for [names]. Scripts are read only for the modes that need their blocks. */
    fun info(context: Context, names: List<String>, key: String): Map<String, Info> {
        val meta = FlowMeta.all(context)
        val idOfName = HashMap<String, String>()
        FlowStore.links(context).forEach { (n, link) -> idOfName[n] = link }
        val root = if (needsSize(key) || needsType(key)) {
            runCatching { JSONObject(FlowStore.rawJson(context) ?: "{}") }.getOrDefault(JSONObject())
        } else null
        val out = HashMap<String, Info>()
        for (n in names) {
            var blocks = 0
            var bytes = 0
            var type = typeByName(n)
            if (root != null) {
                val arr = root.optJSONArray(n)
                if (arr != null) {
                    var only = ""
                    for (i in 0 until arr.length()) {
                        val t = arr.optJSONObject(i)?.optString("t").orEmpty()
                        if (t != Step.BEGIN) { blocks++; only = t }
                    }
                    if (needsSize(key)) bytes = arr.toString().length
                    if (type == "Script" && blocks == 1 && only == Step.INTENT) type = "Shortcut"
                }
            }
            out[n] = Info(blocks, bytes, type, meta[idOfName[n] ?: ""] ?: NONE)
        }
        return out
    }

    /** The kind of script, from its name (a one-block shortcut script is told apart by [info]). */
    fun typeByName(name: String): String = when {
        name.startsWith("Automate:") -> "Automate"
        name.startsWith("Example:") -> "Example"
        AutomateFlows.isPart(name) -> "Part"
        else -> "Script"
    }

    private fun time(i: Info, key: String): Long = when (key) {
        "date_asc", "date_desc" -> i.m[FlowMeta.BORN]
        "opened" -> i.m[FlowMeta.OPENED]
        "edited" -> if (i.m[FlowMeta.EDITED] > 0) i.m[FlowMeta.EDITED] else i.m[FlowMeta.BORN]
        "added" -> i.m[FlowMeta.ADDED]
        "created" -> if (i.m[FlowMeta.ADDED] == 0L) i.m[FlowMeta.BORN] else 0L
        "lastrun" -> i.m[FlowMeta.RAN]
        "mostrun" -> i.m[FlowMeta.RUNS]
        else -> 0L
    }

    /** [running] holds the names of scripts that run right now. */
    fun sort(names: List<String>, key: String, info: Map<String, Info>, running: Set<String>): List<String> {
        val byName = Comparator<String> { a, b -> String.CASE_INSENSITIVE_ORDER.compare(a, b) }
        return when (key) {
            "name_asc" -> names.sortedWith(byName)
            "name_desc" -> names.sortedWith(byName.reversed())
            "size_asc", "size_desc" -> {
                val c = Comparator<String> { a, b ->
                    val x = info[a]; val y = info[b]
                    val r = (x?.blocks ?: 0).compareTo(y?.blocks ?: 0)
                    if (r != 0) r else (x?.bytes ?: 0).compareTo(y?.bytes ?: 0)
                }
                names.sortedWith((if (key == "size_asc") c else c.reversed()).thenComparing(byName))
            }
            "type_asc", "type_desc" -> {
                val c = Comparator<String> { a, b -> (info[a]?.type ?: "").compareTo(info[b]?.type ?: "") }
                names.sortedWith((if (key == "type_asc") c else c.reversed()).thenComparing(byName))
            }
            "date_asc", "date_desc", "opened", "edited", "added", "created", "lastrun", "mostrun" -> {
                val older = key == "date_asc"
                val c = Comparator<String> { a, b ->
                    val x = info[a]?.let { time(it, key) } ?: 0L
                    val y = info[b]?.let { time(it, key) } ?: 0L
                    when {
                        x == 0L && y == 0L -> 0
                        x == 0L -> 1          // unknown goes last, both ways
                        y == 0L -> -1
                        older -> x.compareTo(y)
                        else -> y.compareTo(x)
                    }
                }
                names.sortedWith(c.thenComparing(byName))
            }
            else -> names.sortedByDescending { it in running } // the old order: running first, the rest as the list comes
        }
    }

    private fun ago(t: Long): String =
        android.text.format.DateUtils.getRelativeTimeSpanString(
            t, System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS,
        ).toString()

    /** The small line under a script's name that tells why it is where it is (null = nothing to say). */
    fun note(key: String, i: Info?): String? {
        if (i == null) return null
        fun dated(prefix: String, t: Long) = if (t > 0) "$prefix ${ago(t)}" else "$prefix: no date yet"
        return when (key) {
            "size_asc", "size_desc" -> "${i.blocks} block(s) · " + (if (i.bytes >= 1024) "%.1f KB".format(i.bytes / 1024.0) else "${i.bytes} B")
            "type_asc", "type_desc" -> i.type
            "date_asc", "date_desc" -> dated("Made", time(i, key))
            "opened" -> dated("Opened", time(i, key))
            "edited" -> dated("Edited", time(i, key))
            "added" -> dated("Added", time(i, key))
            "created" -> dated("Created", time(i, key))
            "lastrun" -> dated("Ran", time(i, key))
            "mostrun" -> if (i.m[FlowMeta.RUNS] > 0) "Ran ${i.m[FlowMeta.RUNS]} time(s)" else "Never ran"
            else -> null
        }
    }
}
