plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildNo = (project.findProperty("buildNo") as String?) ?: "1"

android {
    namespace = "a.auth"
    compileSdk = 34
    defaultConfig {
        applicationId = "a.auth"
        minSdk = 26
        targetSdk = 34
        versionCode = buildNo.toIntOrNull() ?: 1
        versionName = "B$buildNo"
    }
    signingConfigs {
        create("r") {
            storeFile = file("k.jks")
            storePassword = "android"
            keyAlias = "k"
            keyPassword = "android"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.getByName("r")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
