package a.auth

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle
import android.widget.Toast

object Copy {
    const val ACTION = "a.auth.COPY"

    fun intent(c: Context, name: String): Intent =
        Intent(c, CopyActivity::class.java).setAction(ACTION).putExtra("n", name)

    fun run(c: Context, name: String) {
        val code = Store.get(c, name)?.let { Totp.code(it) }
        if (code == null) {
            Toast.makeText(c.applicationContext, "Not found: $name", Toast.LENGTH_SHORT).show()
            return
        }
        val clip = ClipData.newPlainText("code", code)
        val ex = PersistableBundle()
        ex.putBoolean("android.content.extra.IS_SENSITIVE", true)
        clip.description.extras = ex
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
        Toast.makeText(c.applicationContext, "Copied · $name", Toast.LENGTH_SHORT).show()
    }
}
