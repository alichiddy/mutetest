package a.auth

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("a", 0)

    fun all(c: Context): List<Pair<String, String>> =
        p(c).all.map { it.key to (it.value as String) }.sortedBy { it.first.lowercase() }

    fun get(c: Context, n: String): String? = p(c).getString(n, null)

    fun put(c: Context, n: String, s: String) {
        p(c).edit().putString(n, s).apply()
    }

    fun del(c: Context, n: String) {
        p(c).edit().remove(n).apply()
    }
}
