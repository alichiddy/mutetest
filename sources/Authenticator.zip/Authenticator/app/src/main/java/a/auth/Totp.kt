package a.auth

import java.io.ByteArrayOutputStream
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object Totp {
    private const val ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    fun code(secret: String): String? {
        val key = b32(secret) ?: return null
        if (key.isEmpty()) return null
        var c = System.currentTimeMillis() / 1000 / 30
        val msg = ByteArray(8)
        for (i in 7 downTo 0) {
            msg[i] = (c and 0xff).toByte()
            c = c shr 8
        }
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(key, "HmacSHA1"))
        val h = mac.doFinal(msg)
        val o = h[h.size - 1].toInt() and 0xf
        val bin = ((h[o].toInt() and 0x7f) shl 24) or
            ((h[o + 1].toInt() and 0xff) shl 16) or
            ((h[o + 2].toInt() and 0xff) shl 8) or
            (h[o + 3].toInt() and 0xff)
        return (bin % 1000000).toString().padStart(6, '0')
    }

    private fun b32(s: String): ByteArray? {
        val t = s.uppercase().filter { it != ' ' && it != '-' && it != '=' }
        if (t.isEmpty()) return null
        val out = ByteArrayOutputStream()
        var buf = 0
        var bits = 0
        for (ch in t) {
            val i = ABC.indexOf(ch)
            if (i < 0) return null
            buf = ((buf shl 5) or i) and 0xfff
            bits += 5
            if (bits >= 8) {
                bits -= 8
                out.write((buf shr bits) and 0xff)
            }
        }
        return out.toByteArray()
    }
}
