package a.auth

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

class PickActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val names = Store.all(this).map { it.first }
        if (names.isEmpty()) {
            Toast.makeText(this, "Open Auth and add an account first", Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED)
            finish()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Pick account")
            .setItems(names.toTypedArray()) { _, i ->
                val n = names[i]
                val r = Intent()
                    .putExtra(Intent.EXTRA_SHORTCUT_INTENT, Copy.intent(this, n))
                    .putExtra(Intent.EXTRA_SHORTCUT_NAME, n)
                    .putExtra(
                        Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                        Intent.ShortcutIconResource.fromContext(this, R.drawable.ic)
                    )
                setResult(RESULT_OK, r)
                finish()
            }
            .setOnCancelListener {
                setResult(RESULT_CANCELED)
                finish()
            }
            .show()
    }
}
