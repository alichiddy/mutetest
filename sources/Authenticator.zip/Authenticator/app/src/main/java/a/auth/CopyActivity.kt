package a.auth

import android.app.Activity
import android.os.Bundle

class CopyActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val n = intent.getStringExtra("n")
        if (n != null) Copy.run(this, n)
        finish()
    }
}
