package a.auth

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private val codes = ArrayList<Pair<String, TextView>>()

    private val tick = object : Runnable {
        override fun run() {
            update()
            h.postDelayed(this, 1000)
        }
    }

    private fun d(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(d(16), d(16), d(16), d(16))

        val name = EditText(this)
        name.hint = "Name (GitHub, ChatGPT)"
        name.inputType = InputType.TYPE_CLASS_TEXT
        val key = EditText(this)
        key.hint = "Secret key"
        key.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val add = Button(this)
        add.text = "Add"
        add.setOnClickListener {
            val n = name.text.toString().trim()
            val k = key.text.toString().trim()
            if (n.isEmpty() || Totp.code(k) == null) {
                Toast.makeText(this, "Need a name and a valid key", Toast.LENGTH_SHORT).show()
            } else {
                Store.put(this, n, k)
                name.setText("")
                key.setText("")
                reload()
            }
        }
        root.addView(name)
        root.addView(key)
        root.addView(add)

        val imp = Button(this)
        imp.text = "Import Aegis file"
        imp.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, 1)
        }
        root.addView(imp)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(list)
        root.addView(sv)
        setContentView(root)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc != 1 || res != RESULT_OK) return
        val u = data?.data ?: return
        var ok = 0
        val bad = ArrayList<String>()
        try {
            val text = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
            for (line in text.lines()) {
                val l = line.trim()
                if (!l.startsWith("otpauth://totp/")) continue
                val p = Uri.parse(l)
                var n = (p.path ?: "").removePrefix("/")
                val iss = p.getQueryParameter("issuer")
                if (n.contains(":")) {
                    n = n.replaceFirst(":", " · ")
                } else if (iss != null && !n.startsWith(iss)) {
                    n = iss + " · " + n
                }
                if (n.isBlank()) continue
                val algo = p.getQueryParameter("algorithm") ?: "SHA1"
                val digits = p.getQueryParameter("digits") ?: "6"
                val period = p.getQueryParameter("period") ?: "30"
                val secret = p.getQueryParameter("secret") ?: ""
                if (algo.uppercase() != "SHA1" || digits != "6" || period != "30" || Totp.code(secret) == null) {
                    bad.add(n)
                } else {
                    Store.put(this, n, secret)
                    ok++
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read the file", Toast.LENGTH_LONG).show()
            return
        }
        var m = "Imported $ok"
        if (bad.isNotEmpty()) m += " · skipped: " + bad.joinToString()
        Toast.makeText(this, m, Toast.LENGTH_LONG).show()
        reload()
    }

    override fun onResume() {
        super.onResume()
        reload()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun reload() {
        list.removeAllViews()
        codes.clear()
        for ((n, _) in Store.all(this)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(d(8), d(12), d(8), d(12))
            row.setBackgroundResource(android.R.drawable.list_selector_background)
            val t = TextView(this)
            t.text = n
            t.textSize = 14f
            val c = TextView(this)
            c.textSize = 32f
            c.typeface = Typeface.MONOSPACE
            row.addView(t)
            row.addView(c)
            row.setOnClickListener { Copy.run(this, n) }
            row.setOnLongClickListener {
                menu(n)
                true
            }
            list.addView(row)
            codes.add(n to c)
        }
        update()
    }

    private fun update() {
        val left = 30 - (System.currentTimeMillis() / 1000 % 30)
        for ((n, tv) in codes) {
            val c = Store.get(this, n)?.let { Totp.code(it) }
            tv.text = if (c == null) "bad key" else c.substring(0, 3) + " " + c.substring(3) + "   " + left + "s"
        }
    }

    private fun menu(n: String) {
        AlertDialog.Builder(this)
            .setTitle(n)
            .setItems(arrayOf("Add shortcut to home screen", "Delete")) { _, i ->
                if (i == 0) pin(n) else {
                    Store.del(this, n)
                    reload()
                }
            }
            .show()
    }

    private fun pin(n: String) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (sm.isRequestPinShortcutSupported) {
            val info = ShortcutInfo.Builder(this, "c_$n")
                .setShortLabel(n)
                .setIcon(Icon.createWithResource(this, R.drawable.ic))
                .setIntent(Copy.intent(this, n))
                .build()
            sm.requestPinShortcut(info, null)
        } else {
            Toast.makeText(this, "Use your launcher or shortcut app instead", Toast.LENGTH_LONG).show()
        }
    }
}
