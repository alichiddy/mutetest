package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.Bitmap
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import a.a.ui.components.MsBox
import a.a.ui.components.MsFields
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.BuiltInPage
import a.a.ui.screens.strip.MyScriptsPage
import a.a.utils.HandlerActions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The Widgets window. Widgets of other apps (Eitaa's chats, Hotspot Shield's VPN switch...) are
 * added here once; each one then becomes cells that:
 *
 * - float it over whatever app is in front ([WidgetFloat]): one widget, draggable and resizable,
 *   remembering where you left it, with settings for size, opacity, auto-close and more,
 * - or press one tile of it (a chat, the VPN switch), hidden or shown for a few seconds. The tile
 *   is chosen with "Grab a tile": the widget floats, you tap the tile, and A notes which one it
 *   is. Android hides the intent behind a tile, so the cell presses that tile in the widget.
 *
 * It works whether or not A is the default launcher.
 */
class WidgetHostActivity : ComponentActivity() {
    private class GrabResult(val wid: Int, val name: String, val pos: Int, val pkg: String, val details: String)

    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val prefs by lazy { WidgetKit.prefs(this) }
    private val ids = mutableStateListOf<Int>()
    private val frames = HashMap<Int, AppWidgetHostView>()
    private var picking by mutableStateOf(false)
    private var grabResult by mutableStateOf<GrabResult?>(null)
    private var settingsFor by mutableStateOf(-1)
    private var ocrTick by mutableStateOf(0)
    private var inspectText by mutableStateOf<String?>(null)
    private var cfgTick by mutableStateOf(0)
    private var pendingId = -1

    /** What the cell being saved will do: kept here so it survives the shortcut picker taking the screen. */
    private class Draft {
        var label by mutableStateOf("")
        var mode by mutableStateOf(1)        // 0 hidden, 1 show for [showMs], 2 never close
        var showMs by mutableStateOf(3000)
        var warm by mutableStateOf("")
        var warmLabel by mutableStateOf("")
        var warmMs by mutableStateOf(3000)
        var postMs by mutableStateOf(2000)
        val pre = mutableStateListOf<WStep>()
        val post = mutableStateListOf<WStep>()
        var ocr by mutableStateOf(false)
        var ocrMs by mutableStateOf(40000)
        var ocrType by mutableStateOf(true)
        var ocrClose by mutableStateOf(true)
    }

    private val draft = Draft()
    private var stepPick by mutableStateOf(0)   // 1 = before the widget, 2 = after it, 3 = the app to open first
    private var floatCell by mutableStateOf<Triple<Int, String, String>?>(null)
    private var toolCell by mutableStateOf<String?>(null)   // "notes" or "gallery"

    private fun resetDraft(label: String) {
        draft.label = label; draft.mode = 1; draft.showMs = 3000
        draft.warm = ""; draft.warmLabel = ""; draft.warmMs = 3000; draft.postMs = 2000
        draft.pre.clear(); draft.post.clear()
        draft.ocr = false; draft.ocrMs = 40000; draft.ocrType = true; draft.ocrClose = true
    }

    private fun showValue(): Int = when (draft.mode) { 0 -> 0; 1 -> draft.showMs.coerceAtLeast(1); else -> -1 }

    private fun withSteps(i: Intent): Intent {
        if (draft.warm.isNotEmpty()) i.putExtra("warm", draft.warm).putExtra("warmMs", draft.warmMs)
        if (draft.pre.isNotEmpty()) i.putExtra("pre", WSteps.toJson(draft.pre.toList()))
        if (draft.post.isNotEmpty()) i.putExtra("post", WSteps.toJson(draft.post.toList())).putExtra("postMs", draft.postMs)
        if (draft.ocr) i.putExtra("ocr", true).putExtra("ocrMs", draft.ocrMs).putExtra("ocrType", draft.ocrType).putExtra("ocrClose", draft.ocrClose)
        return i
    }

    private fun pressIntent(g: GrabResult, show: Int /* milliseconds */): Intent =
        Intent(this, WidgetFloatActivity::class.java)
            .putExtra("mode", "press").putExtra("wid", g.wid).putExtra("pkg", g.pkg)
            .putExtra("tap", g.name).putExtra("pos", g.pos).putExtra("showMs", show)

    private fun floatIntent(id: Int, pkg: String): Intent =
        Intent(this, WidgetFloatActivity::class.java).putExtra("mode", "show").putExtra("wid", id).putExtra("pkg", pkg)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingId = savedInstanceState?.getInt("pending", -1) ?: -1
        ids.addAll(WidgetKit.savedIds(this))
        save()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (picking) Picker() else if (stepPick != 0) StepPicker() else Main()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pending", pendingId)
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    // A tap on a shown widget may end on the home screen: bring this screen back (see ReturnGuard).
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val hit = frames.values.any { ReturnGuard.hit(it, ev) }
        val r = super.dispatchTouchEvent(ev)
        if (hit) ReturnGuard.after(this, WidgetHostActivity::class.java)
        return r
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun save() = WidgetKit.saveIds(this, ids.toList())

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    /** True (and the permission screen opens) when A may not draw over other apps yet. */
    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        toast("Allow \"Display over other apps\" for A, then try again")
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun appLabel(info: AppWidgetProviderInfo): String =
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(info.provider.packageName, 0)).toString() }
            .getOrDefault(info.provider.packageName)

    // ---- adding a widget: bind (Android asks once), set up (the widget's own screen), keep ----

    private fun begin(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, p.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun afterBind(id: Int) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) {
            val ok = runCatching { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }.isSuccess
            if (!ok) {
                toast("The widget's setup screen would not open; added without it")
                finishAdd(id)
            }
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        if (id !in ids) ids.add(id)
        pendingId = -1
        save()
    }

    private fun cancelAdd() {
        if (pendingId != -1) runCatching { host.deleteAppWidgetId(pendingId) }
        pendingId = -1
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBind(id) else cancelAdd()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishAdd(id) else cancelAdd()
        }
    }

    // ---- the cells ----

    private fun saveWindowCell() {
        val i = Intent(this, WidgetHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, "Widgets", "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME))
        toast("Saved to cells")
    }

    private fun saveFloatCell(id: Int, pkg: String) {
        val i = withSteps(floatIntent(id, pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, draft.label.ifBlank { "Widget" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:$pkg")
        toast("Saved to cells")
    }

    private fun saveToolCell(kind: String) {
        val i = withSteps(Intent(this, WidgetFloatActivity::class.java).putExtra("mode", kind)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, draft.label.ifBlank { if (kind == "notes") "Notes" else "Gallery" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:" + packageName)
        toast("Saved to cells")
    }

    private fun savePressCell(g: GrabResult) {
        val i = withSteps(pressIntent(g, showValue())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, draft.label.ifBlank { "Tile" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:" + g.pkg)
        toast("Saved to cells")
    }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("A widget", text))
        toast("Copied")
    }

    // ---- screens ----

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Main() {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Widgets", fontSize = 18.sp)
            Text(
                "1. Add a widget.  2. Tap \"Show floating\" to try it: drag it by its top bar, resize it from the corner.  " +
                    "3. \"Cell: floating\" puts it on your strip.  4. For a widget's button or chat, tap \"Grab a tile\", tap the button, and save the cell.",
                fontSize = 12.sp,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { picking = true }) { Text("Add widget") }
                OutlinedButton(onClick = { WidgetFloat.closeAll() }) { Text("Close all floating") }
                OutlinedButton(onClick = { saveWindowCell() }) { Text("Cell: this window") }
                OutlinedButton(onClick = { startActivity(Intent(this@WidgetHostActivity, OcrActivity::class.java)) }) { Text("OCR") }
                OutlinedButton(onClick = { FloatTools.toggle(this@WidgetHostActivity, "notes") }) { Text("Floating notes") }
                OutlinedButton(onClick = { resetDraft("Notes"); toolCell = "notes" }) { Text("Cell: notes") }
                OutlinedButton(onClick = { FloatTools.toggle(this@WidgetHostActivity, "gallery") }) { Text("Floating gallery") }
                OutlinedButton(onClick = { resetDraft("Gallery"); toolCell = "gallery" }) { Text("Cell: gallery") }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(ids.toList(), key = { it }) { id -> WidgetCard(id) }
            }
        }
        grabResult?.let { GrabDialog(it) }
        floatCell?.let { FloatCellDialog(it) }
        toolCell?.let { ToolCellDialog(it) }
        if (settingsFor != -1) SettingsDialog(settingsFor)
        inspectText?.let { InspectDialog(it) }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun WidgetCard(id: Int) {
        val info = remember(id) { mgr.getAppWidgetInfo(id) }
        if (info == null) return
        val cfg = remember(id, cfgTick) { WidgetKit.loadCfg(this@WidgetHostActivity, id) }
        val title = cfg.name.ifBlank { appLabel(info) }
        val density = LocalDensity.current
        val startH = with(density) { info.minHeight.toDp().value.toInt() }.coerceAtLeast(110)
        var h by remember(id) { mutableStateOf(prefs.getInt("h$id", startH)) }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 15.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { if (!needOverlay()) WidgetFloat.show(this@WidgetHostActivity, id) }) { Text("Show floating") }
                OutlinedButton(onClick = { settingsFor = id }) { Text("Settings") }
                OutlinedButton(onClick = { resetDraft(title); floatCell = Triple(id, title, info.provider.packageName) }) { Text("Cell: floating") }
                OutlinedButton(onClick = {
                    if (!needOverlay()) {
                        WidgetFloat.grab(this@WidgetHostActivity, id) { name, pos, details ->
                            resetDraft(name.ifBlank { "Tile" })
                            grabResult = GrabResult(id, name, pos, info.provider.packageName, details)
                        }
                    }
                }) { Text("Grab a tile") }
                OutlinedButton(onClick = { inspectText = frames[id]?.let { WidgetKit.dump(it) } ?: "The widget has not loaded yet." }) { Text("Inspect") }
                OutlinedButton(onClick = {
                    WidgetFloat.close(id)
                    runCatching { host.deleteAppWidgetId(id) }
                    frames.remove(id)
                    ids.remove(id)
                    WidgetKit.forget(this@WidgetHostActivity, id)
                    save()
                }) { Text("Remove") }
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val w = maxWidth.value.toInt()
                AndroidView(
                    factory = { ctx -> host.createView(ctx, id, info).also { frames[id] = it } },
                    update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                    modifier = Modifier.fillMaxWidth().height(h.dp),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { h = (h - 60).coerceAtLeast(60); prefs.edit().putInt("h$id", h).apply() }) { Text("Shorter preview") }
                TextButton(onClick = { h += 60; prefs.edit().putInt("h$id", h).apply() }) { Text("Taller preview") }
            }
        }
    }

    // ---- small building blocks for the settings ----

    @Composable
    private fun Opts(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        Column {
            Text(title, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                labels.forEachIndexed { i, l ->
                    OutlinedButton(onClick = { onPick(i) }) { Text(if (i == selected) "● $l" else l, fontSize = 12.sp) }
                }
            }
        }
    }

    @Composable
    private fun Toggle(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = value, onCheckedChange = onChange)
        }
    }

    @Composable
    private fun Slide(title: String, value: Int, from: Int, to: Int, unit: String, onChange: (Int) -> Unit) {
        Column {
            Text("$title: $value$unit", fontSize = 12.sp)
            Slider(value = value.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = from.toFloat()..to.toFloat())
        }
    }

    // ---- floating settings of one widget ----

    @Composable
    private fun SettingsDialog(id: Int) {
        var c by remember(id) { mutableStateOf(WidgetKit.loadCfg(this@WidgetHostActivity, id)) }
        var resetPos by remember(id) { mutableStateOf(false) }
        fun commit() {
            val cur = WidgetKit.loadCfg(this@WidgetHostActivity, id)
            WidgetKit.saveCfg(
                this@WidgetHostActivity, id,
                c.copy(x = if (resetPos) Int.MIN_VALUE else cur.x, y = if (resetPos) Int.MIN_VALUE else cur.y),
            )
            cfgTick++
        }
        AlertDialog(
            onDismissRequest = { settingsFor = -1 },
            title = { Text("Floating widget settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = c.name, onValueChange = { c = c.copy(name = it) }, singleLine = true,
                        label = { Text("Name (shown on the bar and the cell)") }, modifier = Modifier.fillMaxWidth(),
                    )
                    val sizeSel = when {
                        c.wDp == 0 -> 0
                        c.wDp <= 170 -> 1
                        c.wDp <= 280 -> 2
                        else -> 3
                    }
                    Opts("Size (you can also drag the corner when it floats)", listOf("Auto", "Small", "Medium", "Large"), sizeSel) {
                        c = when (it) {
                            0 -> c.copy(wDp = 0, hDp = 0)
                            1 -> c.copy(wDp = 150, hDp = 100)
                            2 -> c.copy(wDp = 260, hDp = 180)
                            else -> c.copy(wDp = 340, hDp = 300)
                        }
                    }
                    if (c.wDp > 0) {
                        Slide("Width", c.wDp, 96, 420, " dp") { c = c.copy(wDp = it) }
                        Slide("Height", c.hDp.coerceAtLeast(64), 64, 700, " dp") { c = c.copy(hDp = it) }
                    }
                    Slide("Opacity", c.opacity, 20, 100, "%") { c = c.copy(opacity = it) }
                    Slide("Rounded corners", c.radius, 0, 32, " dp") { c = c.copy(radius = it) }
                    Opts("Background behind the widget", listOf("None", "Dark", "Light"), c.bg) { c = c.copy(bg = it) }
                    Opts("First position", listOf("Centre", "Top", "Bottom", "Left", "Right"), c.startAt) { c = c.copy(startAt = it) }
                    Toggle("Show the top bar (drag, close, resize)", c.handle) { c = c.copy(handle = it) }
                    Toggle("Lock position and size", c.lock) { c = c.copy(lock = it) }
                    Toggle("Remember where I leave it", c.remember) { c = c.copy(remember = it) }
                    Toggle("Snap to the screen edges", c.snap) { c = c.copy(snap = it) }
                    Toggle("Close when I tap outside it", c.outside) { c = c.copy(outside = it) }
                    SecRow("Close after no touch for", c.autoClose, "Never close (stay until I close it)", 120000) { c = c.copy(autoClose = it) }
                    SecRow("Close after I tap something in it", c.afterTap, "Off", 60000) { c = c.copy(afterTap = it) }
                    OcrTeach(id)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { resetPos = true }) { Text(if (resetPos) "Position will reset" else "Reset position") }
                        TextButton(onClick = {
                            if (!needOverlay()) {
                                commit()
                                WidgetFloat.reopen(this@WidgetHostActivity, id)
                            }
                        }) { Text("Try it now") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { commit(); settingsFor = -1 }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { settingsFor = -1 }) { Text("Cancel") } },
        )
    }

    // ---- save a grabbed tile ----

    @Composable
    private fun GrabDialog(g: GrabResult) {
        AlertDialog(
            onDismissRequest = { grabResult = null },
            title = { Text("Save this tile as a cell") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(g.details, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    OutlinedTextField(
                        value = draft.label, onValueChange = { draft.label = it }, singleLine = true,
                        label = { Text("Cell name") }, modifier = Modifier.fillMaxWidth(),
                    )
                    Opts("After pressing it", listOf("Keep it hidden", "Show for some seconds", "Never close it"), draft.mode) { draft.mode = it }
                    if (draft.mode == 1) MsBox("Show for", draft.showMs, 3600000, 60000) { draft.showMs = it }
                    OcrBlock()
                    StepsBlock()
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            if (!needOverlay()) {
                                val show = if (draft.mode == 0) 3000 else showValue()
                                WidgetFloat.handle(this@WidgetHostActivity, "press", withSteps(pressIntent(g, show)))
                            }
                        }) { Text("Test") }
                        TextButton(onClick = { copy(g.details) }) { Text("Copy details") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { savePressCell(g); grabResult = null }) { Text("Save as a cell") } },
            dismissButton = { TextButton(onClick = { grabResult = null }) { Text("Cancel") } },
        )
    }

    @Composable
    private fun ToolCellDialog(kind: String) {
        AlertDialog(
            onDismissRequest = { toolCell = null },
            title = { Text(if (kind == "notes") "Save floating notes as a cell" else "Save floating gallery as a cell") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = draft.label, onValueChange = { draft.label = it }, singleLine = true,
                        label = { Text("Cell name") }, modifier = Modifier.fillMaxWidth(),
                    )
                    Text("The cell opens it, and closes it when it is already open.", fontSize = 11.sp)
                    StepsBlock()
                    TextButton(onClick = {
                        WidgetFloat.handle(this@WidgetHostActivity, kind, withSteps(Intent(this@WidgetHostActivity, WidgetFloatActivity::class.java).putExtra("mode", kind)))
                    }) { Text("Test") }
                }
            },
            confirmButton = { TextButton(onClick = { saveToolCell(kind); toolCell = null }) { Text("Save as a cell") } },
            dismissButton = { TextButton(onClick = { toolCell = null }) { Text("Cancel") } },
        )
    }

    @Composable
    private fun FloatCellDialog(t: Triple<Int, String, String>) {
        AlertDialog(
            onDismissRequest = { floatCell = null },
            title = { Text("Save this widget as a cell") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = draft.label, onValueChange = { draft.label = it }, singleLine = true,
                        label = { Text("Cell name") }, modifier = Modifier.fillMaxWidth(),
                    )
                    StepsBlock()
                    TextButton(onClick = {
                        if (!needOverlay()) WidgetFloat.handle(this@WidgetHostActivity, "show", withSteps(floatIntent(t.first, t.third)))
                    }) { Text("Test") }
                }
            },
            confirmButton = { TextButton(onClick = { saveFloatCell(t.first, t.third); floatCell = null }) { Text("Save as a cell") } },
            dismissButton = { TextButton(onClick = { floatCell = null }) { Text("Cancel") } },
        )
    }

    // ---- reading a code from the widget ----

    @Composable
    private fun OcrBlock() {
        Toggle("Read the code with OCR and type it for me", draft.ocr) { draft.ocr = it }
        if (draft.ocr) {
            MsBox("Look for the code for up to", draft.ocrMs, 3600000, 120000) { draft.ocrMs = it }
            Toggle("Type it into the field that has the cursor (needs Shizuku)", draft.ocrType) { draft.ocrType = it }
            Toggle("Close the widget once it is read", draft.ocrClose) { draft.ocrClose = it }
            Text("The code is always copied too. Teach A the digits once in the OCR screen (Widgets window, OCR button).", fontSize = 11.sp)
        }
    }

    @Composable
    private fun OcrTeach(id: Int) {
        val known = remember(ocrTick) { OtpOcr.learnedCount(this@WidgetHostActivity) }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Reading the code (OCR)", fontSize = 13.sp)
            Text("Digits taught: $known of 10. English digits need no teaching. The teaching is shared by every widget and shortcut.", fontSize = 11.sp)
            TextButton(onClick = { startActivity(Intent(this@WidgetHostActivity, OcrActivity::class.java)) }) { Text("Open the OCR screen") }
        }
    }

    // ---- times: a bar in milliseconds and a seconds box + a milliseconds box (MsBox) ----

    /** A time with a switch for "no time" ([zeroLabel], saved as 0) and, when off, the bar and the two boxes. [max] is the end of the bar, in milliseconds. */
    @Composable
    private fun SecRow(title: String, value: Int, zeroLabel: String, max: Int, onChange: (Int) -> Unit) {
        var last by remember { mutableStateOf(if (value > 0) value else 5000) }
        Column {
            Text(title, fontSize = 12.sp)
            Toggle(zeroLabel, value == 0) { on ->
                if (on) { if (value > 0) last = value; onChange(0) } else onChange(last)
            }
            if (value > 0) MsBox("Time", value, 3600000, max) { last = it.coerceAtLeast(1); onChange(it.coerceAtLeast(1)) }
        }
    }

    // ---- shortcuts before and after the widget ----

    @Composable
    private fun StepList(title: String, list: MutableList<WStep>, which: Int) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 12.sp)
            list.forEachIndexed { n, s ->
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.label.ifBlank { s.action.take(24) }, Modifier.weight(1f), fontSize = 13.sp)
                        TextButton(onClick = { list.removeAt(n) }) { Text("✕") }
                    }
                    Text("then wait", fontSize = 11.sp)
                    MsFields(s.waitMs, 3600000, { v -> list[n] = s.copy(waitMs = v) })
                }
            }
            TextButton(onClick = { stepPick = which }) { Text("+ Add a shortcut") }
        }
    }

    @Composable
    private fun StepsBlock() {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Before and after the widget", fontSize = 13.sp)
            Text("Open an app first: " + draft.warmLabel.ifBlank { "none" }, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { stepPick = 3 }) { Text("Choose app") }
                if (draft.warm.isNotEmpty()) TextButton(onClick = { draft.warm = ""; draft.warmLabel = "" }) { Text("Clear") }
            }
            if (draft.warm.isNotEmpty()) {
                MsBox("Wait after opening it", draft.warmMs, 3600000, 30000) { draft.warmMs = it }
                Text("It opens without an animation, then you are taken back to where you were. With Shizuku it is quicker.", fontSize = 11.sp)
            }
            StepList("Shortcuts before the widget", draft.pre, 1)
            if (draft.post.isNotEmpty()) MsBox("Start the after-shortcuts this long after the widget", draft.postMs, 3600000, 60000) { draft.postMs = it }
            StepList("Shortcuts after the widget", draft.post, 2)
        }
    }

    @Composable
    private fun StepPicker() {
        var page by remember { mutableStateOf(if (stepPick == 3) 2 else 0) }   // 0 menu, 1 built-in, 2 apps, 3 scripts
        BackHandler { if (page != 0 && stepPick != 3) page = 0 else stepPick = 0 }
        fun add(label: String, action: String) {
            if (action.isNotEmpty()) (if (stepPick == 2) draft.post else draft.pre).add(WStep(label, action, 1000))
            stepPick = 0
        }
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
            when (page) {
                0 -> {
                    Text("Add a shortcut", fontSize = 18.sp)
                    listOf("Built-in shortcuts (with device actions)" to 1, "Open an app" to 2, "My Scripts" to 3).forEach { (name, go) ->
                        Text(name, Modifier.fillMaxWidth().clickable { page = go }.padding(vertical = 14.dp, horizontal = 6.dp))
                    }
                    TextButton(onClick = { stepPick = 0 }) { Text("Cancel") }
                }
                1 -> BuiltInPage(
                    onPick = { entry, name -> add(name, entry.action) },
                    onBack = { page = 0 },
                    onPickAction = { a, n, _ -> add(n, a) },
                    onPickApp = { app -> add(app.label, HandlerActions.launchApp(app.packageName)) },
                )
                2 -> AppList(
                    onPick = { app ->
                        if (stepPick == 3) { draft.warm = app.packageName; draft.warmLabel = app.label; stepPick = 0 }
                        else add(app.label, HandlerActions.launchApp(app.packageName))
                    },
                    onBack = { if (stepPick == 3) stepPick = 0 else page = 0 },
                )
                else -> MyScriptsPage(onPick = { label, action, _ -> add(label, action) }, onBack = { page = 0 })
            }
        }
    }

    @Composable
    private fun InspectDialog(text: String) {
        AlertDialog(
            onDismissRequest = { inspectText = null },
            title = { Text("What the widget is made of") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("[TAP] marks the tiles that can be pressed.", fontSize = 11.sp)
                    Text(text, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = { TextButton(onClick = { copy(text) }) { Text("Copy") } },
            dismissButton = { TextButton(onClick = { inspectText = null }) { Text("Close") } },
        )
    }

    // ---- picking a widget to add ----

    @Composable
    private fun Picker() {
        BackHandler { picking = false }
        var q by remember { mutableStateOf("") }
        val all = remember {
            val pm = packageManager
            mgr.installedProviders.map { p ->
                val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() }.getOrDefault(p.provider.packageName)
                val name = runCatching { p.loadLabel(pm).toString() }.getOrDefault("")
                Triple(p, app, name)
            }.sortedBy { it.second.lowercase() }
        }
        val shown = all.filter { q.isBlank() || it.second.contains(q, true) || it.third.contains(q, true) || it.first.provider.packageName.contains(q, true) }
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Pick a widget", fontSize = 18.sp)
            OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Search (for example eitaa)") }, modifier = Modifier.fillMaxWidth())
            if (shown.isEmpty()) Text("No widgets found.", fontSize = 13.sp)
            LazyColumn(Modifier.weight(1f)) {
                items(shown) { (p, app, name) ->
                    Text(
                        "$app: $name",
                        Modifier.fillMaxWidth().clickable { picking = false; begin(p) }.padding(vertical = 12.dp),
                    )
                }
            }
        }
    }

    private companion object {
        const val REQ_BIND = 7101
        const val REQ_CONFIG = 7102
    }
}
