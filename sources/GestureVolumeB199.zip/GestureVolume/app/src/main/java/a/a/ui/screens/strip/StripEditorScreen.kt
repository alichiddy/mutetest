package a.a.ui.screens.strip

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.gestures.detectTapGestures
import a.a.ui.screens.deck.loadEveryApp
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.toSize
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import a.a.strip.StripConfig
import a.a.strip.EdgeFields
import a.a.utils.ActionIcon
import a.a.utils.DeviceActionIcons
import a.a.strip.StripItem
import a.a.strip.StripView
import a.a.ui.components.ActionIconImage
import a.a.ui.components.actionDisplayName
import a.a.ui.screens.deck.InstalledApp
import a.a.ui.screens.deck.loadLaunchableApps
import a.a.ui.viewmodels.MainViewModel
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import a.a.utils.PreviousApp
import a.a.strip.SettingsBackup
import a.a.strip.LauncherModeActivity
import a.a.service.OverlayRuntime
import a.a.strip.FitText
import a.a.share.FilePaths
import a.a.utils.DiagLog
import a.a.strip.IconExport
import a.a.flow.FlowActivity
import a.a.flow.FlowStore
import a.a.strip.ActionSaver
import a.a.flow.NativePicker
import a.a.flow.Step

/**
 * Edits the shortcut strip: the grid itself (tap a cell to select it, then move, copy, blank,
 * delete or edit it), the columns, the cell size, the labels, the position.
 *
 * Every change is saved at once, as one small JSON string, so the settings backup that already
 * copies the preferences file carries the strip too.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StripEditorScreen(viewModel: MainViewModel, onNavigateBack: () -> Unit) {
    val pref = viewModel.preference
    val appContext = LocalContext.current
    var cfg by remember { mutableStateOf(StripConfig.load(appContext, pref.getStripConfigJson())) }
    // The folders being edited, from the top: empty = the main strip.
    var path by remember { mutableStateOf(listOf<Int>()) }
    var movingTo by remember { mutableStateOf(false) }
    // Several cells at once: Select mode, the cells ticked, and a cell being dragged.
    var multi by remember { mutableStateOf(false) }
    var lastTapIdx by remember { mutableIntStateOf(-1) }
    var lastTapAt by remember { mutableStateOf(0L) }
    var doubleMsText by remember { mutableStateOf(pref.sharedPreferences.getInt("stripDoubleTapMs", 400).toString()) }
    val doubleMs = doubleMsText.toLongOrNull() ?: 400L
    val picked = remember { androidx.compose.runtime.mutableStateListOf<Int>() }
    var drag by remember { mutableStateOf<DragInfo?>(null) }
    var viewRoot by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var upZone by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    // Earlier versions of the strip, for Undo.
    val history = remember { ArrayList<List<StripItem>>() }
    var undoCount by remember { mutableIntStateOf(0) }
    var folderCorner by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripFolderCorner", false)) }
    var folderCornerNested by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripFolderCornerNested", true)) }
    var folderCenterMode by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripFolderCenterMode", 0)) }
    var folderHideMain by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripFolderHideMain", false)) }
    var folderDelay by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripFolderDelayMs", 200)) }
    // "Action outside of cells window": what a release above, left of, below or right of the window does.
    var edgeOn by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripEdgeOn", false)) }
    var edgeEditKey by remember { mutableStateOf<String?>(null) }
    // Gap to the screen's side, the thumb popup and the effects outside the window.
    var tipDlg by remember { mutableStateOf(false) }
    var lookDlg by remember { mutableStateOf(false) }
    var lookTick by remember { mutableIntStateOf(0) }
    var gapDp by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripGapDp", 4)) }
    var tipOn by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripTipOn", false)) }
    var tipGap by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripTipGapDp", 4)) }
    var tipPct by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripTipPct", 140)) }
    var edgeFx by remember { mutableIntStateOf(pref.sharedPreferences.getInt("stripEdgeFx", 1)) }
    var edgeTickOn by remember { mutableStateOf(pref.sharedPreferences.getBoolean("stripEdgeTick", false)) }
    var edgeTick by remember { mutableIntStateOf(0) }
    // "Previous app" built-in: apps to skip, tracking without Shizuku, and a Test button.
    var prevDlg by remember { mutableStateOf(false) }
    var prevExclude by remember { mutableStateOf(pref.sharedPreferences.getString(PreviousApp.PREF_EXCLUDE, "").orEmpty()) }
    var prevToast by remember { mutableStateOf(pref.sharedPreferences.getBoolean(PreviousApp.PREF_TOAST, false)) }
    var prevTrack by remember { mutableStateOf(PreviousApp.tracking(pref.sharedPreferences)) }
    var prevResult by remember { mutableStateOf("") }
    var prevFound by remember { mutableStateOf<List<String>?>(null) }
    val prevSel = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    var prevPick by remember { mutableStateOf(false) }
    val prevContext = LocalContext.current
    // "Click circle" built-in settings.
    var ccDlg by remember { mutableStateOf(false) }
    var ccSpeed by remember { mutableIntStateOf(pref.sharedPreferences.getInt("clickCircleSpeed", 150)) }
    var ccLong by remember { mutableIntStateOf(pref.sharedPreferences.getInt("clickCircleLongMs", 200)) }
    var ccDouble by remember { mutableIntStateOf(pref.sharedPreferences.getInt("clickCircleDoubleMs", 400)) }
    var ccShell by remember { mutableStateOf(pref.sharedPreferences.getBoolean("clickCircleShizuku", false)) }
    var ccKeep by remember { mutableStateOf(pref.sharedPreferences.getBoolean("clickCircleKeep", false)) }
    var ccCopy by remember { mutableStateOf(pref.sharedPreferences.getBoolean("clickCircleCopy", true)) }
    var ccOcr by remember { mutableStateOf(pref.sharedPreferences.getBoolean("clickCircleOcr", false)) }
    val cur: List<StripItem> = itemsAt(cfg.items, path)
    val viewCols = if (path.isEmpty()) cfg.columns.coerceIn(1, 16)
        else (itemsAt(cfg.items, path.dropLast(1)).getOrNull(path.last())?.cols ?: 3).coerceIn(1, 8)
    var enabled by remember { mutableStateOf(pref.getStripEnabled()) }
    var selected by remember { mutableIntStateOf(-1) }
    var swapMode by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    // Save the strip being shown, so a backup has it even when it is still the built-in default.
    LaunchedEffect(Unit) { if (pref.getStripConfigJson() == null) pref.setStripConfigJson(cfg.toJson()) }
    // A cell saved from another screen (Widgets, the script window) is already in the preferences but not in
    // this screen: read it again every time the screen comes back.
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                val fresh = StripConfig.load(appContext, pref.getStripConfigJson())
                if (fresh.toJson() != cfg.toJson()) cfg = fresh
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    val sb = SettingsBackup
    fun reload() {
        cfg = StripConfig.load(appContext, pref.getStripConfigJson())
        enabled = pref.getStripEnabled()
        selected = -1
    }
    fun commit(next: StripConfig) {
        if (next.items != cfg.items) {
            history.add(cfg.items); if (history.size > 40) history.removeAt(0); undoCount = history.size
        }
        val settled = next.copy(items = StripConfig.settlePins(next.items))
        cfg = settled
        pref.setStripConfigJson(settled.toJson())
    }

    /** A pinned cell that was moved on purpose now wants the slot it is in. */
    fun anchor(l: MutableList<StripItem>, vararg at: Int) {
        for (a in at) if (a in l.indices && l[a].pinned) l[a] = l[a].copy(pinSlot = a)
    }

    fun commitItems(list: List<StripItem>) = commit(cfg.copy(items = setItemsAt(cfg.items, path, list)))

    fun undo() {
        if (history.isEmpty()) return
        val prev = history.removeAt(history.size - 1)
        undoCount = history.size
        cfg = cfg.copy(items = prev)
        pref.setStripConfigJson(cfg.toJson())
        selected = -1; picked.clear(); swapMode = false
        // Keep only the part of the folder path that still exists.
        var p = listOf<Int>(); var l = prev
        for (i in path) { val k = l.getOrNull(i)?.children ?: break; p = p + i; l = k }
        path = p
    }

    /** Moves cells of the folder being shown into the folder above it. */
    fun moveUp(ids: Set<Int>) {
        if (path.isEmpty()) return
        val moved = cur.filterIndexed { n, _ -> n in ids }.map { if (it.pinned) it.copy(pinned = false) else it }
        val without = setItemsAt(cfg.items, path, cur.filterIndexed { n, _ -> n !in ids })
        commit(cfg.copy(items = setItemsAt(without, path.dropLast(1), itemsAt(without, path.dropLast(1)) + moved)))
    }

    fun applyDrop(d: DragInfo) {
        val ids = d.ids.toSet()
        when {
            d.up && path.isNotEmpty() -> moveUp(ids)
            d.target >= 0 && d.target !in ids && cur[d.target].isFolder -> commitItems(moveIntoFolder(cur, ids, d.target))
            d.target >= 0 && d.target !in ids -> {
                val movedRefs = ids.map { cur[it] }
                val l = moveToSlot(cur, ids, d.target).toMutableList()
                for (n in l.indices) if (l[n].pinned && movedRefs.any { m -> m === l[n] }) l[n] = l[n].copy(pinSlot = n)
                commitItems(l)
            }
            else -> return
        }
        // The move is finished: nothing stays selected and Select mode ends, so no "move" options linger.
        selected = -1; picked.clear(); multi = false; movingTo = false; swapMode = false
    }

    // Back goes up one folder first, and leaves the editor only from the top level.
    val goBack: () -> Unit = {
        if (path.isNotEmpty()) { path = path.dropLast(1); selected = -1; swapMode = false; picked.clear(); movingTo = false; drag = null } else onNavigateBack()
    }
    androidx.activity.compose.BackHandler(enabled = true) { goBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cells") },
                navigationIcon = {
                    IconButton(onClick = goBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        bottomBar = {
            val i = selected
            if (multi && picked.isNotEmpty()) {
                Surface(tonalElevation = 6.dp) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text("${picked.size} selected", Modifier.padding(8.dp), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                        TextButton(onClick = { movingTo = true }) { Text("Move to…") }
                        TextButton(onClick = {
                            val ids = picked.sorted()
                            val kids = ids.map { cur[it] }.map { if (it.pinned) it.copy(pinned = false) else it }
                            val l = cur.filterIndexed { n, _ -> n !in ids }.toMutableList()
                            l.add(ids.first().coerceAtMost(l.size), StripItem(uniqueFolderName(cur), "📁", "", children = kids))
                            commitItems(l); picked.clear()
                        }) { Text("Make folder of them") }
                        TextButton(onClick = {
                            val ids = picked.toSet()
                            commitItems(cur.filterIndexed { n, _ -> n !in ids }); picked.clear()
                        }) { Text("Delete") }
                        TextButton(onClick = { picked.clear() }) { Text("Clear") }
                    }
                }
            } else if (i in cur.indices) {
                Surface(tonalElevation = 6.dp) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        TextButton(onClick = { editing = i }) { Text("Edit") }
                        if (cur[i].isFolder) TextButton(onClick = { path = path + i; selected = -1; swapMode = false }) { Text("Open ▸") }
                        // A new folder goes in before this cell, which moves one place on, like Blank.
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i, StripItem(uniqueFolderName(cur), "📁", "", children = emptyList())); commitItems(l)
                        }) { Text("Make folder") }
                        TextButton(onClick = { movingTo = true }) { Text("Move to…") }
                        TextButton(onClick = {
                            if (i > 0) {
                                val l = cur.toMutableList()
                                l.add(i - 1, l.removeAt(i)); anchor(l, i - 1, i); commitItems(l); selected = i - 1
                            }
                        }) { Text("◀") }
                        TextButton(onClick = {
                            if (i < cur.size - 1) {
                                val l = cur.toMutableList()
                                l.add(i + 1, l.removeAt(i)); anchor(l, i, i + 1); commitItems(l); selected = i + 1
                            }
                        }) { Text("▶") }
                        TextButton(onClick = { swapMode = !swapMode }) {
                            Text(if (swapMode) "Swap: tap a cell" else "Swap…")
                        }
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i + 1, cur[i].copy(pinned = false)); commitItems(l); selected = i + 1
                        }) { Text("Copy") }
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i, StripItem("", "", "")); commitItems(l)
                        }) { Text("Blank") }
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.removeAt(i); commitItems(l); selected = -1; swapMode = false
                        }) { Text("Delete") }
                        TextButton(onClick = { selected = -1; swapMode = false }) { Text("✕") }
                    }
                }
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        ) {
            if (path.isNotEmpty()) item {
                val names = path.indices.map { n -> itemsAt(cfg.items, path.take(n)).getOrNull(path[n])?.label?.ifBlank { "Folder" } ?: "Folder" }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                    OutlinedButton(onClick = { path = path.dropLast(1); selected = -1; swapMode = false }) { Text("↑ Up") }
                    Text("  📁 " + names.joinToString(" › "), Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                }
                StepperRow("Folder columns", "$viewCols", {
                    val parent = itemsAt(cfg.items, path.dropLast(1))
                    val np = parent.mapIndexed { n, it -> if (n == path.last()) it.copy(cols = (it.cols - 1).coerceAtLeast(1)) else it }
                    commit(cfg.copy(items = setItemsAt(cfg.items, path.dropLast(1), np)))
                }, {
                    val parent = itemsAt(cfg.items, path.dropLast(1))
                    val np = parent.mapIndexed { n, it -> if (n == path.last()) it.copy(cols = (it.cols + 1).coerceAtMost(8)) else it }
                    commit(cfg.copy(items = setItemsAt(cfg.items, path.dropLast(1), np)))
                })
            }
            item {
                Text(
                    status.takeIf { it.isNotEmpty() } ?: drag?.let { "Moving ${it.ids.size} cell(s): let go on a folder to put them inside, or on a cell to place them there." }
                        ?: if (multi) "Select mode: tap the cells you want, then hold the last one to drag them all."
                        else "Tap a cell to select it. Hold and drag a cell to move it. Same order as the cells window on screen.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            if (path.isEmpty()) item {
                ToggleRow("Actions outside of the cells window (the fields around the grid)", edgeOn) {
                    edgeOn = it; pref.sharedPreferences.edit().putBoolean("stripEdgeOn", it).apply()
                }
                Text(
                    "Slide in, move the thumb out of the cells window and let go over a field: its action runs. Use − and + above the grid to cut a side into 2-6 equal fields. The cells window is shown at its true size; the fields are drawn with the real shape (corners cut at 45°, end fields reaching past the window corners), but only a strip of them is shown; on screen they go on to the edge. Tap a field to set its shortcut, name and icon.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            item {
                // The cells are drawn by the strip's own view, so they look exactly as they do
                // when the strip slides in, at the size they will have on this screen.
                if (path.isNotEmpty()) Box(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        .border(1.dp, if (drag?.up == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .onGloballyPositioned { upZone = androidx.compose.ui.geometry.Rect(it.positionInRoot(), it.size.toSize()) }
                        .padding(10.dp),
                ) { Text("⬆ Drag cells here to move them out, into the folder above", fontSize = 12.sp) }
                androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = androidx.compose.ui.platform.LocalDensity.current
                    val ctx = LocalContext.current
                    // Sized from the screen, exactly as the strip is when it slides in.
                    val dm = ctx.resources.displayMetrics
                    val screenW = minOf(dm.widthPixels, dm.heightPixels).toFloat()
                    val screenH = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
                    // Folder cells are the same size as the main strip's.
                    val rootCols = cfg.columns.coerceIn(1, 16)
                    val rowsN = ((cfg.items.size + rootCols - 1) / rootCols).coerceAtLeast(1)
                    // The outside fields frame the grid on the main window (not inside folders). The cells window keeps
                    // its true size; the fields take what is left around it.
                    val frame = path.isEmpty()
                    val edgeGapF = pref.sharedPreferences.getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                    val fitW = (screenW * 0.94f) / (rootCols * (1f + edgeGapF) + edgeGapF)
                    val fitH = screenH * 0.88f / (rowsN * (1f + edgeGapF) + edgeGapF)
                    val cell = (minOf(fitW, fitH) * cfg.sizePct / 100f).toInt().coerceAtLeast(24)
                    val view = remember(cur, cell, viewCols, cfg.showLabels, lookTick, path.isNotEmpty()) {
                        StripView(ctx, cur, cell, viewCols, cfg.showLabels, folderLook = path.isNotEmpty()).apply { setScreenOrigin(0f, 0f); editorMode = true }
                    }
                    val panel: @Composable () -> Unit = {
                        // Keyed on the view, so a new one (more cells, another size) replaces the old at once.
                        androidx.compose.runtime.key(view) {
                            androidx.compose.ui.viewinterop.AndroidView(
                                factory = { view },
                                update = {
                                    it.setMarked(drag?.ids?.toSet() ?: if (multi) picked.toSet() else emptySet())
                                    it.highlight(if (drag != null) drag!!.target else if (multi) -1 else selected)
                                },
                                modifier = Modifier.requiredSize(
                                    with(density) { view.panelWidthPx.toDp() },
                                    with(density) { view.panelHeightPx.toDp() },
                                ).onGloballyPositioned { viewRoot = it.positionInRoot() }
                                .pointerInput(view) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { off ->
                                            val idx = view.cellAt(off.x, off.y)
                                            if (idx >= 0) drag = DragInfo(if (multi && idx in picked) picked.sorted() else listOf(idx), idx, false)
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            drag?.let { d ->
                                                val p = change.position
                                                drag = d.copy(target = view.cellAt(p.x, p.y), up = upZone?.contains(viewRoot + p) == true)
                                            }
                                        },
                                        onDragEnd = { val d = drag; drag = null; if (d != null) applyDrop(d) },
                                        onDragCancel = { drag = null },
                                    )
                                }.pointerInput(view, swapMode, selected, multi) {
                                    detectTapGestures { off ->
                                val idx = view.cellAt(off.x, off.y)
                                // The tap always selects at once; a second tap on the same folder within the
                                // chosen time opens it (nothing waits for a double tap).
                                val nowMs = android.os.SystemClock.uptimeMillis()
                                if (!multi && idx in cur.indices && cur[idx].isFolder && idx == lastTapIdx && nowMs - lastTapAt <= doubleMs) {
                                    lastTapIdx = -1; path = path + idx; selected = -1; swapMode = false
                                    return@detectTapGestures
                                }
                                // Same for a cell: a quick second tap opens its editing window.
                                if (!multi && idx in cur.indices && !cur[idx].isFolder && idx == lastTapIdx && nowMs - lastTapAt <= doubleMs) {
                                    lastTapIdx = -1; selected = idx; swapMode = false; editing = idx
                                    return@detectTapGestures
                                }
                                lastTapIdx = idx; lastTapAt = nowMs
                                if (idx >= 0) {
                                    val s0 = selected
                                    if (multi) {
                                        if (idx in picked) picked.remove(idx) else picked.add(idx)
                                    } else if (swapMode && s0 in cur.indices && s0 != idx) {
                                        val l = cur.toMutableList()
                                        val t = l[s0]; l[s0] = l[idx]; l[idx] = t
                                        anchor(l, s0, idx)
                                        commitItems(l); selected = idx; swapMode = false
                                    } else {
                                        selected = idx
                                    }
                                }
                            }
                                },
                            )
                        }
                    }
                    val availW = maxWidth
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (frame) {
                            val pw = with(density) { view.panelWidthPx.toDp() }
                            val ph = with(density) { view.panelHeightPx.toDp() }
                            EdgeCounts(pref.sharedPreferences, edgeTick) { edgeTick++ }
                            EdgeFrame(
                                sp = pref.sharedPreferences, tick = edgeTick, enabled = edgeOn,
                                panelW = pw, panelH = ph, bar = ((availW - pw) / 2f).coerceIn(EDGE_MIN, EDGE_BAR),
                                onEdit = { edgeEditKey = it },
                                content = panel,
                            )
                        } else panel()
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    OutlinedButton(onClick = {
                        val fresh = StripItem("", "", "")
                        commitItems(cur + fresh)
                        val at = itemsAt(cfg.items, path).indexOfFirst { it === fresh }
                        selected = at; editing = at
                    }) { Text("+ Add a cell") }
                    OutlinedButton(onClick = {
                        val fresh = StripItem(uniqueFolderName(cur), "📁", "", children = emptyList())
                        commitItems(cur + fresh)
                        selected = itemsAt(cfg.items, path).indexOfFirst { it === fresh }
                    }) { Text("+ Add a folder") }
                    // Pin: the picked cells (Select mode) or the selected cell keep their own slot. All pinned already = unpin.
                    val pinTargets: Set<Int> = if (multi) picked.toSet() else if (selected in cur.indices) setOf(selected) else emptySet()
                    val allPinned = pinTargets.isNotEmpty() && pinTargets.all { cur.getOrNull(it)?.pinned == true }
                    OutlinedButton(onClick = {
                        if (pinTargets.isEmpty()) {
                            status = if (multi) "Tap the cells you want to pin first." else "Tap a cell first, then Pin."
                        } else {
                            val l = cur.toMutableList()
                            for (n in pinTargets) if (n in l.indices) l[n] = if (allPinned) l[n].copy(pinned = false) else l[n].copy(pinned = true, pinSlot = n)
                            commitItems(l)
                            status = ""
                        }
                    }) { Text(if (allPinned) "📌 Unpin" else "📌 Pin") }
                    OutlinedButton(onClick = { multi = !multi; picked.clear(); selected = -1; swapMode = false }) {
                        Text(if (multi) "Select ✓" else "Select")
                    }
                    OutlinedButton(enabled = undoCount > 0, onClick = { undo() }) { Text("↶ Undo") }
                    OutlinedButton(onClick = { tipDlg = true }) { Text("Gap, popup and effects") }
                    OutlinedButton(onClick = { lookDlg = true }) { Text("Look of the cells") }
                    OutlinedButton(onClick = { prevDlg = true }) { Text("Previous app settings") }
                    OutlinedButton(onClick = { ccDlg = true }) { Text("Click circle settings") }
                    OutlinedButton(onClick = { prevContext.startActivity(android.content.Intent(prevContext, LauncherModeActivity::class.java)) }) { Text("Widgets/Launcher mode") }
                    androidx.compose.material3.OutlinedTextField(
                        value = doubleMsText, singleLine = true,
                        label = { Text("Double tap (ms)") },
                        modifier = Modifier.width(150.dp),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        onValueChange = { v ->
                            doubleMsText = v.filter { it.isDigit() }.take(4)
                            doubleMsText.toIntOrNull()?.let { pref.sharedPreferences.edit().putInt("stripDoubleTapMs", it).apply() }
                        },
                    )
                }
            }
            item {
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                ToggleRow("Cells enabled", enabled) { enabled = it; pref.setStripEnabled(it) }
                StepperRow("Columns", "${cfg.columns}", { commit(cfg.copy(columns = (cfg.columns - 1).coerceAtLeast(1))) },
                    { commit(cfg.copy(columns = (cfg.columns + 1).coerceAtMost(16))) })
                StepperRow("Cell size", "${cfg.sizePct}%", { commit(cfg.copy(sizePct = (cfg.sizePct - 4).coerceAtLeast(30))) },
                    { commit(cfg.copy(sizePct = (cfg.sizePct + 4).coerceAtMost(100))) })
                ToggleRow("Show names under icons", cfg.showLabels) { commit(cfg.copy(showLabels = it)) }
                ToggleRow("Centered (off = beside the bar)", cfg.centered) { commit(cfg.copy(centered = it)) }
                ToggleRow("Folders in a corner open inside the cells window, sharing that corner", folderCorner) {
                    folderCorner = it; pref.sharedPreferences.edit().putBoolean("stripFolderCorner", it).apply()
                }
                if (folderCorner) {
                    ToggleRow("Also for folders inside folders", folderCornerNested) {
                        folderCornerNested = it; pref.sharedPreferences.edit().putBoolean("stripFolderCornerNested", it).apply()
                    }
                    ToggleRow("Folders not in a corner: centred on their cell (off = thumb in the middle of the folder)", folderCenterMode == 1) {
                        folderCenterMode = if (it) 1 else 0; pref.sharedPreferences.edit().putInt("stripFolderCenterMode", folderCenterMode).apply()
                    }
                }
                ToggleRow("Opening a folder hides the cells window (it comes back when the thumb leaves the folder)", folderHideMain) {
                    folderHideMain = it; pref.sharedPreferences.edit().putBoolean("stripFolderHideMain", it).apply()
                }
                StepperRow("Folder opens after", if (folderDelay == 0) "at once" else "$folderDelay ms", {
                    folderDelay = (folderDelay - 50).coerceAtLeast(0); pref.sharedPreferences.edit().putInt("stripFolderDelayMs", folderDelay).apply()
                }, {
                    folderDelay = (folderDelay + 50).coerceAtMost(1000); pref.sharedPreferences.edit().putInt("stripFolderDelayMs", folderDelay).apply()
                })
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text("After a shortcut runs (all cells; a cell can override)", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                StepperRow("Stay on screen", if (cfg.stay == 0) "off" else "${cfg.stay} s", { commit(cfg.copy(stay = (cfg.stay - 1).coerceAtLeast(0))) },
                    { commit(cfg.copy(stay = (cfg.stay + 1).coerceAtMost(60))) })
                StepperRow("Toast", toastName(cfg.toast), { commit(cfg.copy(toast = (cfg.toast - 1).coerceAtLeast(0))) },
                    { commit(cfg.copy(toast = (cfg.toast + 1).coerceAtMost(2))) })
                StepperRow("Notification", if (cfg.notify == 0) "off" else "${cfg.notify} s", { commit(cfg.copy(notify = (cfg.notify - 1).coerceAtLeast(0))) },
                    { commit(cfg.copy(notify = (cfg.notify + 1).coerceAtMost(120))) })
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }

    val movers: Set<Int> = if (multi && picked.isNotEmpty()) picked.toSet() else if (selected in cur.indices) setOf(selected) else emptySet()
    if (movingTo && movers.isNotEmpty()) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { movingTo = false },
            title = { Text("Move ${movers.size} to") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (path.isNotEmpty()) TextButton(onClick = {
                        moveUp(movers); selected = -1; picked.clear(); multi = false; movingTo = false
                    }) { Text("⬆ The folder above") }
                    cur.forEachIndexed { t, it ->
                        if (it.isFolder && t !in movers) TextButton(onClick = {
                            commitItems(moveIntoFolder(cur, movers, t)); selected = -1; picked.clear(); multi = false; movingTo = false
                        }) { Text("📁 " + it.label.ifBlank { "Folder" }) }
                    }
                    if (path.isEmpty() && cur.none { it.isFolder }) Text("There is no folder yet. Use Make folder or + Add a folder.", fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { movingTo = false }) { Text("Cancel") } },
        )
    }
    if (ccDlg) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { ccDlg = false },
            title = { Text("Click circle") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("Run the built-in 'Click circle' (for example as an outside action). A circle appears mid-screen: touch anywhere and move to move it, lift to tap there. Hold still before lifting: long press, then double tap. If you do not touch it, it goes away after 10 seconds.", fontSize = 12.sp)
                    Text("Circle speed: $ccSpeed% of your movement", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    androidx.compose.material3.Slider(
                        value = ccSpeed.toFloat(), valueRange = 50f..400f,
                        onValueChange = { ccSpeed = it.toInt(); pref.sharedPreferences.edit().putInt("clickCircleSpeed", ccSpeed).apply() },
                    )
                    Text("Still for $ccLong ms = long press", fontSize = 13.sp)
                    androidx.compose.material3.Slider(
                        value = ccLong.toFloat(), valueRange = 100f..1000f,
                        onValueChange = { ccLong = it.toInt(); if (ccDouble <= ccLong + 100) ccDouble = ccLong + 100; pref.sharedPreferences.edit().putInt("clickCircleLongMs", ccLong).putInt("clickCircleDoubleMs", ccDouble).apply() },
                    )
                    Text("Still for $ccDouble ms = double tap", fontSize = 13.sp)
                    androidx.compose.material3.Slider(
                        value = ccDouble.toFloat(), valueRange = 200f..2000f,
                        onValueChange = { ccDouble = it.toInt().coerceAtLeast(ccLong + 100); pref.sharedPreferences.edit().putInt("clickCircleDoubleMs", ccDouble).apply() },
                    )
                    ToggleRow("Tap with Shizuku instead of accessibility (for apps that block accessibility taps)", ccShell) {
                        ccShell = it; pref.sharedPreferences.edit().putBoolean("clickCircleShizuku", it).apply()
                    }
                    ToggleRow("Also copy the text under the circle (A switches the \"A text reader\" on through Shizuku for a moment)", ccCopy) {
                        ccCopy = it; pref.sharedPreferences.edit().putBoolean("clickCircleCopy", it).apply()
                    }
                    ToggleRow("When no text is found, also read digits drawn as a picture (the tap waits a moment; needs Shizuku)", ccOcr) {
                        ccOcr = it; pref.sharedPreferences.edit().putBoolean("clickCircleOcr", it).apply()
                    }
                    Row {
                        OutlinedButton(onClick = { Thread { a.a.strip.TextReaderControl.ensureOnBlocking(prevContext, 3000) }.start() }) { Text("Text reader on") }
                        OutlinedButton(onClick = { a.a.strip.TextReaderControl.offNow(prevContext) }, modifier = Modifier.padding(start = 8.dp)) { Text("Text reader off") }
                    }
                    Text("Where the circle starts", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    CircleStartAxis("Horizontal", pref.sharedPreferences, "clickCircleXMode", "clickCircleXOffDp", "clickCircleXPct", 0, 0, "left", "right")
                    CircleStartAxis("Vertical", pref.sharedPreferences, "clickCircleYMode", "clickCircleYOffDp", "clickCircleYPct", 1, -150, "above", "below")
                    ToggleRow("Start where the last tap was", ccKeep) {
                        ccKeep = it; pref.sharedPreferences.edit().putBoolean("clickCircleKeep", it).apply()
                    }
                }
            },
            confirmButton = { TextButton(onClick = { ccDlg = false }) { Text("Done") } },
        )
    }
    if (prevDlg) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { prevDlg = false },
            title = { Text("Previous app") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val pm = prevContext.packageManager
                    fun nameOf(pkg: String): String = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
                    fun skipList(): List<String> = prevExclude.split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                    fun saveSkip(l: List<String>) {
                        prevExclude = l.joinToString("\n")
                        pref.sharedPreferences.edit().putString(PreviousApp.PREF_EXCLUDE, prevExclude).apply()
                    }
                    fun copyText(t: String) {
                        val cm = prevContext.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("apps", t))
                        android.widget.Toast.makeText(prevContext, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    Text("Apps to skip (for example apps that only forward a link to another app):", fontSize = 13.sp)
                    skipList().forEach { pkg ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(nameOf(pkg), fontSize = 13.sp, maxLines = 1)
                                Text(pkg, fontSize = 11.sp, maxLines = 1)
                            }
                            TextButton(onClick = { saveSkip(skipList() - pkg) }) { Text("×") }
                        }
                    }
                    if (skipList().isEmpty()) Text("(none)", fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { prevPick = true }) { Text("Add from all apps…") }
                        OutlinedButton(onClick = {
                            prevFound = emptyList(); prevSel.clear()
                            Thread { prevFound = PreviousApp.detected() }.start()
                        }) { Text("Find recent apps") }
                    }
                    prevFound?.let { found ->
                        Text(
                            if (found.isEmpty()) "Nothing found yet (Shizuku must run, or turn on tracking below)." else "Recent apps, newest first. Tap a name to copy its package; tick the ones to select:",
                            fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                        )
                        found.forEach { pkg ->
                            Row(Modifier.fillMaxWidth().clickable { copyText(pkg) }, verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.Checkbox(checked = pkg in prevSel, onCheckedChange = { if (it) prevSel.add(pkg) else prevSel.remove(pkg) })
                                Column(Modifier.weight(1f)) {
                                    Text(nameOf(pkg) + if (pkg in skipList()) "  (skipped)" else "", fontSize = 13.sp, maxLines = 1)
                                    Text(pkg, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                        if (found.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(onClick = { prevSel.clear(); prevSel.addAll(found) }) { Text("All") }
                            TextButton(onClick = { saveSkip((skipList() + prevSel).distinct()); prevSel.clear() }, enabled = prevSel.isNotEmpty()) { Text("Skip selected") }
                            TextButton(onClick = { copyText(prevSel.joinToString("\n")) }, enabled = prevSel.isNotEmpty()) { Text("Copy selected") }
                        }
                    }
                    ToggleRow("Show its messages as Android's own toast (not on the bar)", prevToast) {
                        prevToast = it
                        pref.sharedPreferences.edit().putBoolean(PreviousApp.PREF_TOAST, it).apply()
                    }
                    ToggleRow("Track apps without Shizuku (accessibility window changes; a little work on each app change)", prevTrack) {
                        prevTrack = it
                        pref.sharedPreferences.edit().putBoolean(PreviousApp.PREF_TRACK, it).apply()
                        OverlayRuntime.accessibilityService?.applyEventSubscription()
                    }
                    Text("With Shizuku running, the real recents list is read only when the action runs; nothing is kept in memory.", fontSize = 12.sp)
                    OutlinedButton(onClick = {
                        prevResult = "Reading..."
                        Thread { prevResult = PreviousApp.test(prevContext, pref.sharedPreferences) }.start()
                    }) { Text("Test: what does it find?") }
                    if (prevResult.isNotEmpty()) {
                        androidx.compose.foundation.text.selection.SelectionContainer { Text(prevResult, fontSize = 12.sp) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { prevDlg = false }) { Text("Done") } },
        )
    }
    if (prevPick) {
        Dialog(onDismissRequest = { prevPick = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                AppList(
                    onPick = { app ->
                        val l = prevExclude.split(',', '\n', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }
                        prevExclude = (l + app.packageName).distinct().joinToString("\n")
                        pref.sharedPreferences.edit().putString(PreviousApp.PREF_EXCLUDE, prevExclude).apply()
                        prevPick = false
                    },
                    onBack = { prevPick = false },
                    everything = true,
                )
            }
        }
    }
    if (lookDlg) {
        LookDialog(
            sp = pref.sharedPreferences,
            rootItems = cfg.items, rootCols = cfg.columns, sizePct = cfg.sizePct, showLabels = cfg.showLabels,
            startOnFolders = path.isNotEmpty(),
            onChange = { lookTick++ },
            onDismiss = { lookDlg = false },
        )
    }
    if (tipDlg) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { tipDlg = false },
            title = { Text("Gap, popup and effects") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    NumberBox("Gap between the screen's side and the cells window (dp)", gapDp) {
                        gapDp = it; pref.sharedPreferences.edit().putInt("stripGapDp", it).apply()
                    }
                    Text("Each side bar segment can have its own gap (in its settings).", fontSize = 12.sp)
                    ToggleRow("Popup: the cell under the thumb, a bit bigger, just above it", tipOn) {
                        tipOn = it; pref.sharedPreferences.edit().putBoolean("stripTipOn", it).apply()
                    }
                    if (tipOn) {
                        Text("Popup size: $tipPct% of a cell", fontSize = 13.sp)
                        androidx.compose.material3.Slider(
                            value = tipPct.toFloat(), valueRange = 100f..300f,
                            onValueChange = { tipPct = it.toInt(); pref.sharedPreferences.edit().putInt("stripTipPct", tipPct).apply() },
                        )
                    }
                    if (tipOn) {
                        Text("Gap between the cell and the popup: $tipGap dp", fontSize = 13.sp)
                        androidx.compose.material3.Slider(
                            value = tipGap.toFloat(), valueRange = 0f..120f,
                            onValueChange = { tipGap = it.toInt(); pref.sharedPreferences.edit().putInt("stripTipGapDp", tipGap).apply() },
                        )
                    }
                    Text("When the thumb is outside the cells window over a side that has an action:", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    listOf(0 to "Nothing shown", 1 to "Its name above the thumb", 2 to "Name + that side of the window glows", 3 to "Name + the whole window glows").forEach { (v, name) ->
                        TextButton(onClick = { edgeFx = v; pref.sharedPreferences.edit().putInt("stripEdgeFx", v).apply() }) {
                            Text((if (edgeFx == v) "●  " else "○  ") + name)
                        }
                    }
                    ToggleRow("A tick when the thumb enters such a side", edgeTickOn) {
                        edgeTickOn = it; pref.sharedPreferences.edit().putBoolean("stripEdgeTick", it).apply()
                    }
                }
            },
            confirmButton = { TextButton(onClick = { tipDlg = false }) { Text("Done") } },
        )
    }
    edgeEditKey?.let { key ->
        val ctx = LocalContext.current
        // The field's current shortcut, name and icon come up in the editor, ready to change one at a time.
        val start = remember(key) {
            val raw = pref.sharedPreferences.getString(key, "").orEmpty()
            val bare = StripConfig.bare(raw)
            val (ml, mi) = EdgeFields.meta(pref.sharedPreferences, key)
            val entry = HandlerActionCatalog.entryFor(bare)
            val icon = mi.ifEmpty {
                when {
                    bare.isEmpty() -> ""
                    entry != null -> BuiltInIcons.save(ctx, entry.icon, bare) ?: EMOJI_FOR_ACTION[bare].orEmpty()
                    NativePicker.isNative(bare) -> BuiltInIcons.save(ctx, ActionIcon.Vector(DeviceActionIcons.forTitle(NativePicker.label(bare))), bare).orEmpty()
                    else -> ""
                }
            }
            StripItem(ml.ifEmpty { if (bare.isEmpty()) "" else edgeActionName(ctx, bare) }, icon, bare, touch = StripConfig.isTouch(raw))
        }
        ItemEditor(
            item = start,
            onSave = { updated ->
                EdgeFields.save(pref.sharedPreferences, key, StripConfig.withTouch(updated.action, updated.touch), updated.label, updated.icon)
                edgeTick++; edgeEditKey = null
            },
            onCancel = { edgeEditKey = null },
        )
    }
    val e = editing
    if (e in cur.indices) {
        ItemEditor(
            item = cur[e],
            onSave = { updated ->
                val l = cur.toMutableList(); l[e] = updated; commitItems(l); editing = -1
            },
            onCancel = { editing = -1 },
        )
    }
}

internal data class DragInfo(val ids: List<Int>, val target: Int, val up: Boolean)

/** Puts the cells [ids] at the end of the folder cell [target]. */
internal fun moveIntoFolder(list: List<StripItem>, ids: Set<Int>, target: Int): List<StripItem> {
    val moved = list.filterIndexed { n, _ -> n in ids }
    val l = list.toMutableList()
    l[target] = l[target].copy(children = l[target].children.orEmpty() + moved)
    return l.filterIndexed { n, _ -> n !in ids }
}

/** Moves the cells [ids] to the place of cell [t]; the cell there makes room. */
internal fun moveToSlot(list: List<StripItem>, ids: Set<Int>, t: Int): List<StripItem> {
    val first = ids.minOrNull() ?: return list
    val moved = list.filterIndexed { n, _ -> n in ids }
    val rest = list.filterIndexed { n, _ -> n !in ids }
    val at = if (t > first) (0..t).count { it !in ids } else (0 until t).count { it !in ids }
    return rest.take(at) + moved + rest.drop(at)
}

/** "Folder1", "Folder2"… the first not used by a cell of the same folder, so a new one is easy to tell apart. */
internal fun uniqueFolderName(list: List<StripItem>): String {
    val used = list.map { it.label }.toSet()
    var n = 1
    while ("Folder$n" in used) n++
    return "Folder$n"
}

/** The cells of the folder reached by [path] (empty path = the main strip). */
internal fun itemsAt(root: List<StripItem>, path: List<Int>): List<StripItem> {
    var l = root
    for (i in path) l = l.getOrNull(i)?.children ?: return emptyList()
    return l
}

internal fun setItemsAt(root: List<StripItem>, path: List<Int>, new: List<StripItem>): List<StripItem> =
    if (path.isEmpty()) new
    else root.mapIndexed { i, it -> if (i == path[0]) it.copy(children = setItemsAt(it.children.orEmpty(), path.drop(1), new)) else it }

@Composable
internal fun backupLauncher(
    prefs: android.content.SharedPreferences, settings: Boolean, scripts: Boolean, done: String,
    report: (String) -> Unit,
): androidx.activity.result.ActivityResultLauncher<String> {
    val context = LocalContext.current
    return androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            report(runCatching {
                val text = SettingsBackup.toJson(prefs, settings, scripts)
                context.contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
                done
            }.getOrElse { "Backup failed: ${it.message}" })
        }
    }
}

@Composable
internal fun restoreLauncher(
    prefs: android.content.SharedPreferences, settings: Boolean, scripts: Boolean, what: String,
    reload: () -> Unit, report: (String) -> Unit,
): androidx.activity.result.ActivityResultLauncher<Array<String>> {
    val context = LocalContext.current
    return androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            report(runCatching {
                val text = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                SettingsBackup.saveUndo(context, prefs)
                val n = SettingsBackup.apply(prefs, text, settings, scripts)
                when {
                    n < 0 -> "Not a backup file"
                    n == 0 -> "That file has no $what"
                    else -> { reload(); "Restored $what. Close and reopen the app to apply them everywhere." }
                }
            }.getOrElse { "Restore failed: ${it.message}" })
        }
    }
}

private fun toastName(v: Int) = when (v) { 0 -> "off"; 1 -> "short"; else -> "long" }

@Composable
private fun ToggleRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun StepperRow(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        OutlinedButton(onClick = onMinus) { Text("−") }
        Text(value, Modifier.width(72.dp), textAlign = TextAlign.Center)
        OutlinedButton(onClick = onPlus) { Text("+") }
    }
}

@Composable
private fun AddCell(onClick: () -> Unit) {
    Box(
        Modifier.padding(2.dp).aspectRatio(1f).clip(RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", fontSize = 18.sp) }
}

@Composable
private fun ItemCell(item: StripItem, selected: Boolean, onClick: () -> Unit) {
    val colours = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(8.dp)
    androidx.compose.foundation.layout.BoxWithConstraints(
        Modifier.padding(2.dp).aspectRatio(1f).clip(shape)
            .background(if (item.action.isNotEmpty()) colours.primaryContainer else colours.surfaceVariant)
            .then(if (selected) Modifier.border(BorderStroke(2.dp, colours.primary), shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // Drawn as the strip draws a cell: the icon takes the upper part, the name sits under it,
        // both sized from the cell so nothing is cut off.
        val side = maxWidth.value
        val hasIcon = item.appIconPackage != null || (item.icon.isNotEmpty() && item.icon != FitText.NONE)
        val showName = hasIcon && item.label.isNotEmpty()
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxSize().padding((side * 0.06f).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                IconOrLabel(item, Modifier.fillMaxSize().padding((side * 0.04f).dp), (side * 0.38f).toInt().coerceAtLeast(10))
            }
            if (showName) {
                Text(item.label, fontSize = (side * 0.17f).coerceIn(6f, 11f).sp, maxLines = 1, overflow = TextOverflow.Clip, textAlign = TextAlign.Center)
            }
        }
    }
}

/** An item as the strip shows it: its icon (emoji or the app's own), else its name. */
@Composable
private fun IconOrLabel(item: StripItem, modifier: Modifier, emojiSp: Int) {
    val context = LocalContext.current
    val pkg = item.appIconPackage
    val bitmap = remember(pkg) {
        pkg?.let { p ->
            runCatching { context.packageManager.getApplicationIcon(p).toBitmap(64, 64).asImageBitmap() }.getOrNull()
        }
    }
    val img = remember(item.icon) {
        item.iconFile?.let { f ->
            runCatching { android.graphics.BitmapFactory.decodeFile(java.io.File(context.filesDir, "sicons/$f").path)?.asImageBitmap() }.getOrNull()
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            img != null -> Image(bitmap = img, contentDescription = item.label, modifier = Modifier.fillMaxSize())
            bitmap != null -> Image(bitmap = bitmap, contentDescription = item.label, modifier = Modifier.fillMaxSize())
            item.icon == FitText.NONE -> {
                val ink = MaterialTheme.colorScheme.onSurface.toArgb()
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        FitText.draw(
                            c.nativeCanvas, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG),
                            item.label, android.graphics.RectF(0f, 0f, size.width, size.height), ink,
                        )
                    }
                }
            }
            item.icon.isNotEmpty() && pkg == null && item.iconFile == null -> Text(item.icon, fontSize = emojiSp.sp)
            else -> Text(item.label, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
    }
}

/** An installed app's own icon. */
@Composable
internal fun PackageIcon(pkg: String, modifier: Modifier) {
    val context = LocalContext.current
    val bitmap = remember(pkg) {
        runCatching { context.packageManager.getApplicationIcon(pkg).toBitmap(64, 64).asImageBitmap() }.getOrNull()
    }
    if (bitmap != null) Image(bitmap = bitmap, contentDescription = null, modifier = modifier) else Spacer(modifier)
}

private enum class Page { MAIN, EMOJI, ICON_APP, ACTION_APP, ACTION, FLOW, SHORTCUTS, SCRIPTS, HAIL }

@Composable
private fun ItemEditor(item: StripItem, onSave: (StripItem) -> Unit, onCancel: () -> Unit) {
    var label by remember { mutableStateOf(item.label) }
    var icon by remember { mutableStateOf(item.icon) }
    var action by remember { mutableStateOf(item.action) }
    var stay by remember { mutableStateOf(item.stay?.toString() ?: "") }
    var notify by remember { mutableStateOf(item.notify?.toString() ?: "") }
    var toast by remember { mutableStateOf(item.toast) }
    var touch by remember { mutableStateOf(item.touch) }
    var page by remember { mutableStateOf(Page.MAIN) }
    var shellDialog by remember { mutableStateOf(false) }
    var shellText by remember { mutableStateOf(item.action.removePrefix("Shell:").takeIf { item.action.startsWith("Shell:") } ?: "") }
    val context = LocalContext.current
    // Icon history: whatever changes the icon (a picked shortcut, a built-in, an emoji) can be undone and redone.
    val iconUndo = remember { ArrayList<String>() }
    val iconRedo = remember { ArrayList<String>() }
    var iconPrev by remember { mutableStateOf(icon) }
    var iconSkip by remember { mutableStateOf(false) }
    var iconRev by remember { mutableIntStateOf(0) }
    LaunchedEffect(icon) {
        if (iconSkip) iconSkip = false
        else if (icon != iconPrev) { iconUndo.add(iconPrev); iconRedo.clear() }
        iconPrev = icon
        iconRev++
    }
    // The colour behind the icon preview, chosen by the user (white built-in icons need a dark one, a dark icon a light one).
    val tilePrefs = remember { context.getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE) }
    var tileColor by remember { mutableIntStateOf(tilePrefs.getInt("iconTileColor", 0xFF37474F.toInt())) }
    var tileHex by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }
    var rawDialog by remember { mutableStateOf(false) }
    var rawText by remember { mutableStateOf("") }
    var creatorPkg by remember { mutableStateOf("") }
    val fileLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            action = "File:$uri"
            label = FilePaths.displayName(context, uri) ?: label
            if (icon.isEmpty()) icon = "📄"
            page = Page.MAIN
        }
    }
    val creatorLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        @Suppress("DEPRECATION")
        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
            action = INTENT_ACTION_PREFIX + picked.toUri(android.content.Intent.URI_INTENT_SCHEME)
            val name = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME)
            if (label.isBlank() && !name.isNullOrBlank()) label = name
            // The icon chosen in the shortcut maker (Automate's own picker) wins over an older one.
            val own = saveShortcutIcon(context, data)
            DiagLog.note("shortcut maker icon: ${own ?: "none"}; extras=${data?.extras?.keySet()?.joinToString()}")
            if (own != null) icon = own
            if (icon.isEmpty()) {
                val pkg = picked.component?.packageName ?: picked.`package` ?: creatorPkg
                if (pkg.isNotEmpty()) icon = "app:$pkg"
            }
            page = Page.MAIN
        }
    }

    // Back inside a sub-page (apps, shortcuts, built-in, scripts...) returns to the editor first.
    Dialog(onDismissRequest = { if (page != Page.MAIN) page = Page.MAIN else onCancel() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
            when (page) {
                Page.MAIN -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    val textMode = icon == FitText.NONE
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = if (textMode) it.split('\n').take(3).joinToString("\n") else it },
                        singleLine = !textMode, maxLines = if (textMode) 3 else 1,
                        label = { Text(if (textMode) "Text in the cell (up to 3 lines, Enter = new line)" else "Name") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Icon", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Built-in icons are white: shown on a tile whose colour is chosen below, so they can be seen the moment they are chosen.
                        Box(
                            Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(androidx.compose.ui.graphics.Color(tileColor))
                                .pointerInput(icon, label) {
                                    detectTapGestures(
                                        onTap = { IconExport.copy(context, StripItem(label, icon, action)) },
                                        onLongPress = { IconExport.saveToDownloads(context, StripItem(label, icon, action)) },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            IconOrLabel(StripItem(label, icon, action), Modifier.fillMaxSize().padding(6.dp), 32)
                        }
                        // Undo and redo of the icon, to the right of the preview.
                        val canUndo = iconRev >= 0 && iconUndo.isNotEmpty()
                        val canRedo = iconRev >= 0 && iconRedo.isNotEmpty()
                        TextButton(enabled = canUndo, onClick = {
                            if (iconUndo.isNotEmpty()) { iconSkip = true; iconRedo.add(icon); icon = iconUndo.removeAt(iconUndo.lastIndex) }
                        }) { Text("↶") }
                        TextButton(enabled = canRedo, onClick = {
                            if (iconRedo.isNotEmpty()) { iconSkip = true; iconUndo.add(icon); icon = iconRedo.removeAt(iconRedo.lastIndex) }
                        }) { Text("↷") }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(onClick = { page = Page.EMOJI }) { Text("Emoji") }
                            OutlinedButton(onClick = { page = Page.ICON_APP }) { Text("App icon") }
                            OutlinedButton(onClick = { icon = FitText.NONE }) { Text("None") }
                        }
                    }
                    // Preview colour: any colour the user likes.
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Preview colour", fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        listOf(0xFF37474F, 0xFF000000, 0xFF212121, 0xFF757575, 0xFFFFFFFF, 0xFFFFF59D, 0xFF81D4FA, 0xFF2196F3, 0xFF1F8A8A, 0xFF4CAF50, 0xFFFF9800, 0xFFE53935, 0xFF8E24AA).forEach { c ->
                            val argb = c.toInt()
                            Box(
                                Modifier.padding(horizontal = 3.dp).size(28.dp).clip(RoundedCornerShape(14.dp))
                                    .background(androidx.compose.ui.graphics.Color(argb))
                                    .border(if (tileColor == argb) 3.dp else 1.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (tileColor == argb) 1f else 0.35f), RoundedCornerShape(14.dp))
                                    .clickable { tileColor = argb; tilePrefs.edit().putInt("iconTileColor", argb).apply() },
                            )
                        }
                        OutlinedTextField(
                            value = tileHex,
                            onValueChange = { v ->
                                tileHex = v.filter { it.isLetterOrDigit() }.take(6)
                                if (tileHex.length == 6) tileHex.toLongOrNull(16)?.let {
                                    tileColor = (0xFF000000 or it).toInt(); tilePrefs.edit().putInt("iconTileColor", tileColor).apply()
                                }
                            },
                            singleLine = true, label = { Text("#RRGGBB") }, modifier = Modifier.width(110.dp).padding(start = 6.dp),
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Action", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text(
                        when {
                            action.isEmpty() -> "Nothing"
                            action.startsWith(StripConfig.FLOW_PREFIX) -> "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
                            action.startsWith(INTENT_ACTION_PREFIX) -> "App shortcut"
                            action.startsWith("File:") -> "Open file: " + FilePaths.nameOf(action)
                            else -> actionDisplayName(action)
                        },
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                    if (action.isNotEmpty()) {
                        TextButton(onClick = { showInfo = !showInfo }) { Text(if (showInfo) "Hide details" else "Details of this shortcut") }
                        if (showInfo) {
                            val details = remember(action) { describeAction(context, action) }
                            androidx.compose.foundation.text.selection.SelectionContainer {
                                Text(details, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", action))
                                    android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                                }) { Text("Copy raw") }
                                OutlinedButton(onClick = { rawText = action; rawDialog = true }) { Text("Edit raw") }
                                if (action.startsWith("MyFlow:")) {
                                    OutlinedButton(onClick = {
                                        context.startActivity(
                                            android.content.Intent(context, FlowActivity::class.java)
                                                .putExtra("flow", FlowStore.resolve(context, action.removePrefix("MyFlow:")) ?: action.removePrefix("MyFlow:"))
                                        )
                                    }) { Text("Edit this script") }
                                }
                                if (action.startsWith(INTENT_ACTION_PREFIX) || action.startsWith("Shell:")) {
                                    OutlinedButton(onClick = {
                                        val ok = ActionSaver.saveToScripts(context, label, action)
                                        android.widget.Toast.makeText(context, if (ok) "Saved to My Scripts" else "Cannot save this kind", android.widget.Toast.LENGTH_SHORT).show()
                                    }) { Text("Save to My Scripts") }
                                }
                            }
                        }
                    }
                    if (rawDialog) {
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { rawDialog = false },
                            title = { Text("Edit the raw action") },
                            text = { OutlinedTextField(value = rawText, onValueChange = { rawText = it }, modifier = Modifier.fillMaxWidth()) },
                            confirmButton = { TextButton(onClick = { action = rawText.trim(); rawDialog = false }) { Text("Use") } },
                            dismissButton = { TextButton(onClick = { rawDialog = false }) { Text("Cancel") } },
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(onClick = { page = Page.HAIL }) { Text("Open with Hail (any app, even hidden)") }
                        OutlinedButton(onClick = { page = Page.SHORTCUTS }) { Text("App shortcuts") }
                        OutlinedButton(onClick = {
                            // Automate's own "pick a flow" screen, straight from here.
                            val cr = runCatching { loadCreators(context) }.getOrDefault(emptyList())
                                .firstOrNull { it.packageName == "com.llamalab.automate" }
                            if (cr == null) page = Page.SHORTCUTS else {
                                creatorPkg = cr.packageName
                                runCatching {
                                    creatorLauncher.launch(
                                        android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT)
                                            .setClassName(cr.packageName, cr.className)
                                    )
                                }
                            }
                        }) { Text("Automate flow") }
                        OutlinedButton(onClick = { shellDialog = true }) { Text("Shell command") }
                        OutlinedButton(onClick = { page = Page.ACTION }) { Text("Built-in shortcuts (with device actions)") }
                        OutlinedButton(onClick = { page = Page.SCRIPTS }) { Text("My Scripts") }
                        OutlinedButton(onClick = { fileLauncher.launch(arrayOf("*/*")) }) { Text("Open a file") }
                        OutlinedButton(onClick = { action = "" }) { Text("Nothing") }
                    }
                    if (shellDialog) {
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { shellDialog = false },
                            title = { Text("Shell command") },
                            text = {
                                androidx.compose.material3.OutlinedTextField(
                                    value = shellText, onValueChange = { shellText = it },
                                    label = { Text("Runs with Shizuku when allowed") },
                                )
                            },
                            confirmButton = {
                                TextButton(onClick = {
                                    if (shellText.isNotBlank()) {
                                        action = "Shell:" + shellText.trim()
                                        if (label.isBlank()) label = "Shell"
                                    }
                                    shellDialog = false
                                }) { Text("Use") }
                            },
                            dismissButton = { TextButton(onClick = { shellDialog = false }) { Text("Cancel") } },
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    ToggleRow("Run as soon as the thumb is on it (no release needed)", touch) { touch = it }
                    Text("After it runs (empty = follow the cells' setting)", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = stay, onValueChange = { stay = it.filter(Char::isDigit).take(2) }, singleLine = true,
                            label = { Text("Stay (s)") }, modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = notify, onValueChange = { notify = it.filter(Char::isDigit).take(3) }, singleLine = true,
                            label = { Text("Notification (s)") }, modifier = Modifier.weight(1f),
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Toast", Modifier.weight(1f))
                        OutlinedButton(onClick = { toast = when (toast) { null -> 0; 0 -> 1; 1 -> 2; else -> null } }) {
                            Text(toast?.let { toastName(it) } ?: "follow")
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSave(item.copy(label = label.trim(), icon = icon, action = action, stay = stay.toIntOrNull(), toast = toast, notify = notify.toIntOrNull(), touch = touch)) }) { Text("Save") }
                        TextButton(onClick = onCancel) { Text("Cancel") }
                    }
                }

                Page.EMOJI -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    var typed by remember { mutableStateOf("") }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = typed, onValueChange = { typed = it }, singleLine = true,
                            label = { Text("Type or paste any emoji") }, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { if (typed.isNotBlank()) { icon = typed.trim(); page = Page.MAIN } }) { Text("Use") }
                    }
                    Spacer(Modifier.height(8.dp))
                    var query by remember { mutableStateOf("") }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        label = { Text("Search by name (power, wifi, lock, battery…)") }, modifier = Modifier.fillMaxWidth(),
                    )
                    val everything = remember { drawableEmoji() }
                    val shown = remember(query) {
                        val words = query.lowercase().split(' ').filter { it.isNotBlank() }
                        everything.filter { e -> words.all { e.words.contains(it) } }.map { it.emoji }
                    }
                    androidx.compose.ui.viewinterop.AndroidView(
                        factory = { c ->
                            android.widget.GridView(c).apply {
                                numColumns = android.widget.GridView.AUTO_FIT
                                columnWidth = (52 * c.resources.displayMetrics.density).toInt()
                                stretchMode = android.widget.GridView.STRETCH_COLUMN_WIDTH
                            }
                        },
                        update = { gv ->
                            gv.adapter = EmojiAdapter(shown)
                            gv.setOnItemClickListener { _, _, pos, _ -> icon = shown[pos]; page = Page.MAIN }
                        },
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                    )
                    TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                }

                Page.ICON_APP -> AppList(onPick = { app -> icon = appIconRef(context, app); page = Page.MAIN }, onBack = { page = Page.MAIN }, everything = true)

                Page.ACTION_APP -> AppList(
                    onPick = { app ->
                        action = HandlerActions.launchApp(app.packageName)
                        if (label.isBlank()) label = plainAppLabel(app.label)
                        if (icon.isEmpty()) icon = appIconRef(context, app)
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.HAIL -> AppList(
                    onPick = { app ->
                        action = ActionSaver.hailAction(app.packageName)
                        label = plainAppLabel(app.label)
                        icon = appIconRef(context, app)
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                    everything = true,
                )

                Page.ACTION -> Column(Modifier.fillMaxSize()) {
                    TextButton(
                        onClick = { fileLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    ) { Text("Open a file… (a web page opens in A's HTML viewer)") }
                    BuiltInPage(
                        modifier = Modifier.weight(1f),
                        onPick = { entry, name ->
                            action = entry.action
                            // The chosen built-in shortcut brings its own name and icon at once.
                            label = name
                            icon = BuiltInIcons.save(context, entry.icon, entry.action) ?: EMOJI_FOR_ACTION[entry.action].orEmpty()
                            page = Page.MAIN
                        },
                        onBack = { page = Page.MAIN },
                        // Device actions (Wi-Fi, flashlight, lock…) are in the same list and bring their own name and icon.
                        onPickAction = { a, n, ic ->
                            action = a
                            label = n
                            icon = BuiltInIcons.save(context, ic, a).orEmpty()
                            page = Page.MAIN
                        },
                        // "Open an app" lives in this list too.
                        onPickApp = { app ->
                            action = HandlerActions.launchApp(app.packageName)
                            if (label.isBlank()) label = plainAppLabel(app.label)
                            if (icon.isEmpty()) icon = appIconRef(context, app)
                            page = Page.MAIN
                        },
                    )
                }

                Page.SCRIPTS -> MyScriptsPage(
                    onPick = { name, act, cell ->
                        action = act
                        label = name.removePrefix("Script: ")
                        if (cell != null && cell.icon.isNotEmpty()) icon = cell.icon
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.SHORTCUTS -> AppShortcutsPage(
                    onCreator = { cr ->
                        creatorPkg = cr.packageName
                        runCatching {
                            creatorLauncher.launch(
                                android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT)
                                    .setClassName(cr.packageName, cr.className)
                            )
                        }
                    },
                    onShortcut = { sc ->
                        action = INTENT_ACTION_PREFIX + sc.intentUri
                        label = sc.label
                        icon = "app:${sc.packageName}"
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.FLOW -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    var text by remember { mutableStateOf(action.removePrefix(StripConfig.FLOW_PREFIX).takeIf { action.startsWith(StripConfig.FLOW_PREFIX) }.orEmpty()) }
                    Text("Paste the shortcut's Automate address (content://com.llamalab.automate.provider/flows/…/statements/…) or type flow/statement, for example 468/233.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            StripConfig.parseFlow(text)?.let { action = it; page = Page.MAIN }
                        }) { Text("Use") }
                        TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                    }
                }
            }
        }
    }
}

/** A script's steps as indented text, with the scripts it runs shown under their step. */
private fun flowText(context: android.content.Context, name: String, depth: Int, seen: MutableSet<String>): String {
    val pad = "      ".repeat(depth)
    if (!seen.add(name)) return pad + "(\"$name\" is shown above)\n"
    if (depth > 4) return pad + "(deeper scripts not shown)\n"
    val steps = FlowStore.load(context, name)
    if (steps.isEmpty()) return pad + "(no steps found for \"$name\")\n"
    val sb = StringBuilder()
    var ind = 0
    for (s in steps) {
        if (s.type == Step.END || s.type == Step.ELSE) ind = (ind - 1).coerceAtLeast(0)
        sb.append(pad).append("  ".repeat(ind)).append(s.describe()).append('\n')
        if (s.id == 0 && (s.type == Step.IF || s.type == Step.REPEAT || s.type == Step.ELSE)) ind++
        if (s.type == Step.RUN && s.a.isNotBlank()) sb.append(flowText(context, s.a, depth + 1, seen))
    }
    return sb.toString()
}

/** Everything the cell's action holds, in words, so a shortcut can be read, copied or rebuilt. */
private fun describeAction(context: android.content.Context, action: String): String {
    val sb = StringBuilder()
    when {
        action.startsWith(INTENT_ACTION_PREFIX) -> {
            sb.append("Type: app shortcut (an intent)\n")
            val uri = action.removePrefix(INTENT_ACTION_PREFIX)
            val i = runCatching { android.content.Intent.parseUri(uri, android.content.Intent.URI_INTENT_SCHEME) }.getOrNull()
            if (i != null) {
                i.action?.let { sb.append("Action: $it\n") }
                i.dataString?.let { sb.append("Data: $it\n") }
                i.type?.let { sb.append("MIME type: $it\n") }
                i.`package`?.let { sb.append("Package: $it\n") }
                i.component?.let { sb.append("Component: ${it.flattenToString()}\n") }
                i.categories?.let { sb.append("Categories: ${it.joinToString()}\n") }
                @Suppress("DEPRECATION")
                i.extras?.let { ex -> for (k in ex.keySet()) sb.append("Extra $k = ${ex.get(k)}\n") }
                sb.append("Flags: 0x${Integer.toHexString(i.flags)}\n")
            }
            sb.append("\nRaw: $uri")
        }
        action.startsWith(StripConfig.FLOW_PREFIX) -> sb.append("Type: Automate flow\nAddress: ${action.removePrefix(StripConfig.FLOW_PREFIX)}")
        action.startsWith("Shell:") -> sb.append("Type: shell command\nCommand: ${action.removePrefix("Shell:")}")
        action.startsWith("MyFlow:") -> {
            val name = FlowStore.resolve(context, action.removePrefix("MyFlow:")) ?: action.removePrefix("MyFlow:")
            sb.append("Type: My Script\nName: $name\n\nSteps (scripts it runs are shown indented under their step):\n")
            sb.append(flowText(context, name, 0, HashSet()))
        }
        action.startsWith("N:") -> sb.append("Type: device action\nName: ${NativePicker.label(action)}\nId: $action")
        action.startsWith("File:") -> sb.append("Type: open a file\nName: ${FilePaths.nameOf(action)}\nUri: ${action.removePrefix("File:")}")
        else -> sb.append("Type: built-in, device action or app\nAction: $action")
    }
    return sb.toString()
}

@Composable
internal fun AppList(onPick: (InstalledApp) -> Unit, onBack: () -> Unit, everything: Boolean = false) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<InstalledApp>?>(null) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { if (everything) loadEveryApp(context) else loadLaunchableApps(context, includeSelf = true) } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth(),
        )
        val loaded = apps
        if (loaded == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val q = query.trim()
            val shown = if (q.isEmpty()) loaded else loaded.filter { it.label.contains(q, ignoreCase = true) }
            LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.packageName }) { app ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(app) }.padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        app.icon?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(40.dp)) }
                            ?: Spacer(Modifier.size(40.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}

/** A first emoji for the actions that have an obvious one; the rest keep their name until chosen. */
private val EMOJI_FOR_ACTION: Map<String, String> = mapOf(
    HandlerActions.SCAN_QR to "🔳",
    HandlerActions.TOGGLE_FLASHLIGHT to "🔦",
    HandlerActions.OPEN_CAMERA to "📷",
    HandlerActions.OPEN_CALCULATOR to "🧮",
    HandlerActions.OPEN_NOTES to "📝",
    HandlerActions.OPEN_TIMER to "⏱️",
    HandlerActions.OPEN_SEARCH to "🔍",
    HandlerActions.COIN_TOSS to "🪙",
    HandlerActions.DICE_ROLL to "🎲",
    HandlerActions.MUTE to "🔇",
    HandlerActions.MUTE_OR_UNMUTE to "🔇",
    HandlerActions.VOLUME_BOOST to "📢",
    HandlerActions.VOLUME_BOOST_ALLOW to "📣",
    HandlerActions.VOLUME_BOOST_OFF to "🔇",
    HandlerActions.MEDIA_PLAY_PAUSE to "⏯️",
    HandlerActions.MEDIA_NEXT to "⏭️",
    HandlerActions.MEDIA_PREVIOUS to "⏮️",
    HandlerActions.SCREENSHOT to "📸",
    HandlerActions.LOCK to "🔒",
    HandlerActions.HOME to "🏠",
    HandlerActions.BACK to "⬅️",
    HandlerActions.WIFI_PANEL to "📶",
    HandlerActions.BLUETOOTH_SETTINGS to "🔵",
    HandlerActions.VOICE_ASSISTANT to "🎤",
    HandlerActions.OPEN_DECK to "🗂️",
    HandlerActions.OPEN_MENU to "☰",
)


/** One axis of "where the Click circle starts": the screen's middle, relative to the thumb that ran the action, or a percentage. */
@Composable
private fun CircleStartAxis(
    title: String, sp: android.content.SharedPreferences, modeKey: String, offKey: String, pctKey: String,
    defMode: Int, defOff: Int, negWord: String, posWord: String,
) {
    var mode by remember { mutableIntStateOf(sp.getInt(modeKey, defMode)) }
    Text(title, fontSize = 12.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf(0 to "Middle", 1 to "From thumb", 2 to "% of screen").forEach { (v, name) ->
            OutlinedButton(
                onClick = { mode = v; sp.edit().putInt(modeKey, v).apply() },
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
            ) { Text((if (mode == v) "● " else "") + name, fontSize = 12.sp) }
        }
    }
    if (mode == 1) NumberBox("Distance from the thumb in dp (minus = $negWord, plus = $posWord)", sp.getInt(offKey, defOff), min = -3000) { sp.edit().putInt(offKey, it).apply() }
    if (mode == 2) NumberBox("Percent of the screen (0-100)", sp.getInt(pctKey, 50), max = 100) { sp.edit().putInt(pctKey, it).apply() }
}


private val EDGE_BAR = 56.dp
private val EDGE_MIN = 22.dp

/** What a field is called when its owner has not named it: the action's own name. */
private fun edgeActionName(context: android.content.Context, b: String): String = when {
    b.isEmpty() -> "Nothing"
    b.startsWith(StripConfig.FLOW_PREFIX) -> "Automate flow " + b.removePrefix(StripConfig.FLOW_PREFIX)
    b.startsWith(INTENT_ACTION_PREFIX) -> "App shortcut"
    b.startsWith("File:") -> "Open file: " + FilePaths.nameOf(b)
    NativePicker.isNative(b) -> NativePicker.label(b)
    else -> {
        val pkg = HandlerActions.launchedPackage(b)
        if (pkg != null) runCatching {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        }.getOrDefault(pkg)
        else HandlerActionCatalog.displayEntryFor(b)?.let { context.getString(it.labelRes) } ?: b
    }
}

/** The number of fields of each outside side: − and + beside the side's name. */
@Composable
private fun EdgeCounts(sp: android.content.SharedPreferences, tick: Int, onChanged: () -> Unit) {
    @Composable
    fun one(side: String, m: Modifier) {
        val n = remember(tick) { EdgeFields.count(sp, side) }
        Row(m, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("$side $n", fontSize = 12.sp)
            listOf("−" to -1, "+" to 1).forEach { (sym, d) ->
                val can = if (d < 0) n > 1 else n < EdgeFields.MAX
                val c = MaterialTheme.colorScheme.primary.copy(alpha = if (can) 1f else 0.3f)
                Box(
                    Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
                        .border(1.dp, c, RoundedCornerShape(14.dp))
                        .clickable(enabled = can) { EdgeFields.setCount(sp, side, n + d); onChanged() },
                    contentAlignment = Alignment.Center,
                ) { Text(sym, fontSize = 15.sp, color = c) }
            }
        }
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) { one("Top", Modifier.weight(1f)); one("Bottom", Modifier.weight(1f)) }
        Row(Modifier.fillMaxWidth()) { one("Left", Modifier.weight(1f)); one("Right", Modifier.weight(1f)) }
    }
}

/**
 * The cells window at its true size with the outside fields drawn around it exactly as they work on
 * screen: the side the thumb is furthest past wins, so the corners are cut at 45 degrees, the fields of a
 * side are equal parts of the window's length, and the end fields reach on past the window's corners.
 * (On screen the fields go on to the edge of the screen; here only [bar] of them is drawn.)
 * Only the fields fade when the outside actions are off; the cells window stays clear.
 */
@Composable
private fun EdgeFrame(
    sp: android.content.SharedPreferences, tick: Int, enabled: Boolean,
    panelW: androidx.compose.ui.unit.Dp, panelH: androidx.compose.ui.unit.Dp, bar: androidx.compose.ui.unit.Dp,
    onEdit: (String) -> Unit,
    content: @Composable () -> Unit,
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val t = with(density) { bar.toPx() }
    val w = with(density) { panelW.toPx() }
    val h = with(density) { panelH.toPx() }
    val fctx = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    val emptyFill = MaterialTheme.colorScheme.surfaceVariant
    val setFill = androidx.compose.ui.graphics.Color(0xFF37474F)

    /** One field: its key, the corners of its shape, and the straight part where its label goes (x0, y0, x1, y1). */
    class Fld(val side: String, val zone: Int, val n: Int, val pts: List<androidx.compose.ui.geometry.Offset>, val box: FloatArray)
    val fields = remember(tick, t, w, h) {
        val list = ArrayList<Fld>()
        for (side in EdgeFields.SIDES) {
            val n = EdgeFields.count(sp, side)
            for (i in 0 until n) {
                val first = i == 0; val last = i == n - 1
                val a = i.toFloat() / n; val b = (i + 1).toFloat() / n
                val pts: List<androidx.compose.ui.geometry.Offset>
                val box: FloatArray
                if (side == "Top" || side == "Bottom") {
                    val xa = t + w * a; val xb = t + w * b
                    val yIn = if (side == "Top") t else t + h
                    val yOut = if (side == "Top") 0f else 2f * t + h
                    val xaOut = if (first) xa - t else xa; val xbOut = if (last) xb + t else xb
                    pts = listOf(
                        androidx.compose.ui.geometry.Offset(xa, yIn), androidx.compose.ui.geometry.Offset(xb, yIn),
                        androidx.compose.ui.geometry.Offset(xbOut, yOut), androidx.compose.ui.geometry.Offset(xaOut, yOut),
                    )
                    box = floatArrayOf(xa, minOf(yIn, yOut), xb, maxOf(yIn, yOut))
                } else {
                    val ya = t + h * a; val yb = t + h * b
                    val xIn = if (side == "Left") t else t + w
                    val xOut = if (side == "Left") 0f else 2f * t + w
                    val yaOut = if (first) ya - t else ya; val ybOut = if (last) yb + t else yb
                    pts = listOf(
                        androidx.compose.ui.geometry.Offset(xIn, ya), androidx.compose.ui.geometry.Offset(xIn, yb),
                        androidx.compose.ui.geometry.Offset(xOut, ybOut), androidx.compose.ui.geometry.Offset(xOut, yaOut),
                    )
                    box = floatArrayOf(minOf(xIn, xOut), ya, maxOf(xIn, xOut), yb)
                }
                list.add(Fld(side, i, n, pts, box))
            }
        }
        list
    }
    // The same rule the strip uses on screen: the side the thumb is furthest past, then the equal part along it.
    fun hit(x: Float, y: Float): String? {
        val dTop = t - y; val dBottom = y - (t + h); val dLeft = t - x; val dRight = x - (t + w)
        val best = maxOf(maxOf(dTop, dBottom), maxOf(dLeft, dRight))
        if (best <= 0f) return null
        val side: String; val frac: Float
        when (best) {
            dTop -> { side = "Top"; frac = (x - t) / maxOf(1f, w) }
            dBottom -> { side = "Bottom"; frac = (x - t) / maxOf(1f, w) }
            dLeft -> { side = "Left"; frac = (y - t) / maxOf(1f, h) }
            else -> { side = "Right"; frac = (y - t) / maxOf(1f, h) }
        }
        val n = EdgeFields.count(sp, side)
        return EdgeFields.key(side, (frac * n).toInt().coerceIn(0, n - 1))
    }
    Box(
        Modifier.requiredSize(panelW + bar * 2f, panelH + bar * 2f)
            .pointerInput(tick, t, w, h) { detectTapGestures { off -> hit(off.x, off.y)?.let(onEdit) } },
    ) {
        Box(Modifier.matchParentSize().alpha(if (enabled) 1f else 0.4f)) {
            androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                for (f in fields) {
                    val key = EdgeFields.key(f.side, f.zone)
                    val set = StripConfig.bare(sp.getString(key, "").orEmpty()).isNotEmpty()
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(f.pts[0].x, f.pts[0].y)
                        for (k in 1 until f.pts.size) lineTo(f.pts[k].x, f.pts[k].y)
                        close()
                    }
                    drawPath(path, if (set) setFill else emptyFill)
                    drawPath(path, primary.copy(alpha = 0.7f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
                }
            }
            for (f in fields) {
                val key = EdgeFields.key(f.side, f.zone)
                val raw = sp.getString(key, "").orEmpty()
                val (ml, mi) = EdgeFields.meta(sp, key)
                val bare = StripConfig.bare(raw)
                val set = bare.isNotEmpty()
                val entry = HandlerActionCatalog.entryFor(bare)
                val name = ml.ifEmpty { if (set) edgeActionName(fctx, bare) else "" }
                val tint = if (set) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                val bw = with(density) { (f.box[2] - f.box[0]).toDp() }
                val bh = with(density) { (f.box[3] - f.box[1]).toDp() }
                Box(
                    Modifier.offset { androidx.compose.ui.unit.IntOffset(f.box[0].toInt(), f.box[1].toInt()) }
                        .requiredSize(bw, bh).clip(RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        val room = minOf(bw, bh)
                        if (set && room >= 28.dp) {
                            val isz = (room * 0.45f).coerceIn(12.dp, 20.dp)
                            if (mi.isNotEmpty()) IconOrLabel(StripItem("", mi, ""), Modifier.size(isz), 14)
                            else if (entry != null) ActionIconImage(entry.icon, null, Modifier.size(isz), tint)
                        }
                        val label = (if (f.n > 1) "${f.zone + 1}" else "") +
                            (if (set && room >= 44.dp && name.isNotEmpty()) (if (f.n > 1) " " else "") + name else if (!set && f.n == 1) "—" else "")
                        if (label.isNotEmpty()) Text(
                            label, fontSize = 9.sp, color = tint, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 2.dp),
                        )
                    }
                }
            }
        }
        Box(Modifier.offset(bar, bar).size(panelW, panelH)) { content() }
    }
}
