package a.a.flow

/**
 * What a device action wants as its argument, as choices to tap instead of text to type.
 * The stored argument stays the same short text it always was ("4g5g", "music:50"), so existing
 * cells and flows keep working.
 */
object ActionArgs {
    sealed class Spec
    /** One of a few fixed values: (label, stored value). */
    class Choices(val options: List<Pair<String, String>>, val default: String = "") : Spec()
    /** A stream and a percent, stored as "stream:percent". */
    object StreamPercent : Spec()

    val STREAMS = listOf("Media" to "music", "Ringtone" to "ring", "Alarm" to "alarm", "Notifications" to "notification")
    val PERCENTS = (0..100 step 10).map { "$it%" to "$it" }

    fun specFor(id: String): Spec? = when (id) {
        "netmode" -> Choices(
            listOf(
                "2G only" to "2g", "2G + 3G" to "2g3g", "4G (LTE)" to "4g",
                "4G + 5G" to "4g5g", "5G only" to "5g", "All networks (auto)" to "all",
            ), default = "all",
        )
        "brightness_toggle" -> Choices(listOf("25%" to "64", "50%" to "128", "75%" to "192", "100%" to "255"), default = "255")
        "volume_max" -> Choices(STREAMS, default = "music")
        "volume_set" -> StreamPercent
        "install_existing" -> Choices(
            listOf("Second space (999)" to "999", "Work profile (10)" to "10", "User 11" to "11", "Owner (0)" to "0"), default = "999",
        )
        "ocr_area" -> Choices(
            listOf(
                "Copy it: part of the screen, choose it now" to "copy",
                "Copy it: saved part of the screen" to "copy:region",
                "Copy it: selected widget" to "copy:widget",
                "Copy it: widget on screen now" to "copy:widgetnow",
                "Copy it: USSD screen" to "copy:ussd",
                "Copy it and type it into the field with the cursor: part of the screen, choose it now" to "type",
                "Copy it and type it into the field with the cursor: saved part of the screen" to "type:region",
                "Copy it and type it into the field with the cursor: selected widget" to "type:widget",
                "Copy it and type it into the field with the cursor: widget on screen now" to "type:widgetnow",
                "Copy it and type it into the field with the cursor: USSD screen" to "type:ussd",
            ), default = "copy",
        )
        "lensnet" -> Choices(listOf("Prepare" to "prep", "Turn on" to "on"), default = "on")
        "bgshell" -> Choices(listOf("Copy and upload" to "upload", "Run only" to "plain"), default = "upload")
        else -> null
    }

    /** The argument in words, for lists and block titles. */
    fun label(id: String, arg: String): String {
        if (arg.isEmpty()) return ""
        return when (val s = specFor(id)) {
            is Choices -> s.options.firstOrNull { it.second == arg }?.first ?: arg
            StreamPercent -> {
                val st = arg.substringBefore(':', "music")
                val pct = arg.substringAfter(':', "")
                (STREAMS.firstOrNull { it.second == st }?.first ?: st) + if (pct.isNotEmpty()) " $pct%" else ""
            }
            null -> arg
        }
    }
}
