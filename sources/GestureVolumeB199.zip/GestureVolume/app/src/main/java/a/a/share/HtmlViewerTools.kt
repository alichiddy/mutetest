package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener

/**
 * The HTML viewer's advanced tools, in plain views (nothing exists until one is opened):
 *
 *  - a find bar (matches counted, next / previous) with find and replace on the page, with its options;
 *  - Style: text size, themes (dark, sepia, high contrast, grey), font, line spacing, hiding images, stopping
 *    animations, highlighting links, wrapping code, a reader width, and the viewer's own CSS;
 *  - View: desktop site, JavaScript and images on or off, remembering the place in each page, screen rotation,
 *    automatic scrolling, jumps and reload;
 *  - Source: the page's source, the live page after its scripts ran, editing, find and replace in the source,
 *    copy, save and share;
 *  - Tools: print or save as PDF, copy the text, lists of the links and images, a JavaScript console, clearing
 *    the viewer's saved site data;
 *  - Info: what the page holds.
 *
 * The page is still served from memory and every request to the internet is still blocked; nothing here
 * opens a way out.
 */
class HtmlViewerTools(
    private val act: Activity,
    private val web: ScrollWebView,
    private val frame: FrameLayout,
    private val prefs: SharedPreferences,
) {
    private val handler = Handler(Looper.getMainLooper())
    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private val owner: HtmlViewerActivity? get() = act as? HtmlViewerActivity

    private companion object {
        const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        const val SHOW_LIMIT = 300_000
        const val CLIP_LIMIT = 900_000
    }

    // ---- life ------------------------------------------------------------------------------------

    fun start() {
        val s = web.settings
        s.textZoom = prefs.getInt("textZoom", 100).coerceIn(30, 400)
        if (prefs.getBoolean("desktop", false)) s.userAgentString = DESKTOP_UA
        if (!prefs.getBoolean("jsOn", true)) s.javaScriptEnabled = false
        if (!prefs.getBoolean("imagesOn", true)) s.loadsImagesAutomatically = false
        applyOrientation()
        web.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && autoOn) stopAuto()
            false
        }
    }

    fun stop() {
        saveScroll()
        stopAuto()
        handler.removeCallbacksAndMessages(null)
        closeFind()
        web.setOnTouchListener(null)
    }

    /** The page finished loading: its style, and the place it was left at, are applied. */
    fun onPageFinished() {
        applyStyle()
        if (prefs.getBoolean("rememberScroll", false)) {
            val y = prefs.getInt(scrollKey(), 0)
            if (y > 0) web.postDelayed({ web.scrollTo(0, y) }, 250)
        }
    }

    private fun scrollKey() = "scroll_" + (owner?.pageFileName() ?: "page")

    private fun saveScroll() {
        if (prefs.getBoolean("rememberScroll", false)) prefs.edit().putInt(scrollKey(), web.scrollY).apply()
    }

    private fun toast(m: String) = Toast.makeText(act, m, Toast.LENGTH_SHORT).show()

    private fun copy(text: String) {
        if (text.length > CLIP_LIMIT) { toast("Too big to copy: save it as a file instead."); return }
        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("A", text))
        toast("Copied")
    }

    private fun unq(r: String?): String =
        if (r == null || r == "null") "" else try { JSONTokener(r).nextValue().toString() } catch (e: Exception) { r }

    private fun js(code: String, then: (String) -> Unit = {}) = web.evaluateJavascript(code) { then(unq(it)) }

    // ---- page style --------------------------------------------------------------------------------

    private fun buildCss(): String {
        val sb = StringBuilder()
        when (prefs.getInt("theme", 0)) {
            1 -> sb.append("html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}img,video,picture,canvas,svg,iframe{filter:invert(1) hue-rotate(180deg)!important}")
            2 -> sb.append("html{filter:sepia(.55) brightness(.96)!important}")
            3 -> sb.append("html{filter:contrast(1.45)!important}")
            4 -> sb.append("html{filter:grayscale(1)!important}")
        }
        when (prefs.getInt("font", 0)) {
            1 -> sb.append("body,body *{font-family:Georgia,'Times New Roman',serif!important}")
            2 -> sb.append("body,body *{font-family:Roboto,Arial,sans-serif!important}")
            3 -> sb.append("body,body *{font-family:'Courier New',monospace!important}")
        }
        val lh = prefs.getInt("lineH", 0)
        if (lh > 0) sb.append("body,body *{line-height:").append(lh / 100f).append("!important}")
        if (prefs.getBoolean("hideImg", false)) sb.append("img,picture,video{visibility:hidden!important}")
        if (prefs.getBoolean("noAnim", false)) sb.append("*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}")
        if (prefs.getBoolean("hiLinks", false)) sb.append("a,a *{background:#ffeb3b!important;color:#0d47a1!important;text-decoration:underline!important}")
        if (prefs.getBoolean("wrapCode", false)) sb.append("pre,code,td,th{white-space:pre-wrap!important;word-break:break-word!important}")
        if (prefs.getBoolean("reader", false)) sb.append("body{max-width:40em!important;margin:0 auto!important;padding:0 .8em!important}")
        sb.append(prefs.getString("userCss", "").orEmpty())
        return sb.toString()
    }

    fun applyStyle() {
        val code = "(function(){var e=document.getElementById('__a_style');if(!e){e=document.createElement('style');e.id='__a_style';" +
            "(document.head||document.documentElement).appendChild(e);}e.textContent=" + JSONObject.quote(buildCss()) + ";})()"
        web.evaluateJavascript(code, null)
    }

    private fun applyOrientation() {
        act.requestedOrientation = when (prefs.getInt("orient", 0)) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // ---- small view helpers --------------------------------------------------------------------------

    private fun column() = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }

    private fun LinearLayout.label(text: String, bold: Boolean = false) {
        addView(TextView(act).apply {
            this.text = text; setPadding(0, dp(8), 0, dp(2))
            if (bold) setTypeface(typeface, Typeface.BOLD)
        })
    }

    private fun LinearLayout.check(text: String, key: String, def: Boolean, after: (Boolean) -> Unit = {}) {
        addView(CheckBox(act).apply {
            this.text = text; isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after(on) }
        })
    }

    private fun LinearLayout.button(text: String, onClick: () -> Unit) {
        addView(Button(act).apply { this.text = text; isAllCaps = false; setOnClickListener { onClick() } })
    }

    private fun LinearLayout.seek(label: (Int) -> String, key: String, lo: Int, hi: Int, def: Int, after: (Int) -> Unit) {
        val cur = prefs.getInt(key, def).coerceIn(lo, hi)
        val t = TextView(act).apply { text = label(cur); setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(act)
        sb.max = hi - lo
        sb.progress = cur - lo
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                val v = p + lo
                t.text = label(v)
                if (user) { prefs.edit().putInt(key, v).apply(); after(v) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        addView(t); addView(sb)
    }

    private fun LinearLayout.radios(title: String, key: String, options: List<String>, def: Int, after: (Int) -> Unit) {
        label(title, true)
        val g = RadioGroup(act)
        options.forEachIndexed { i, n -> g.addView(RadioButton(act).apply { text = n; id = 7000 + i; isChecked = prefs.getInt(key, def) == i }) }
        g.setOnCheckedChangeListener { _, id -> val v = id - 7000; prefs.edit().putInt(key, v).apply(); after(v) }
        addView(g)
    }

    private fun showText(title: String, text: String, extra: Pair<String, () -> Unit>? = null) {
        val shown = if (text.length > SHOW_LIMIT) text.substring(0, SHOW_LIMIT) + "\n\n… (the rest is not shown; copy or save to get all of it)" else text
        val tv = TextView(act).apply {
            this.text = shown; setTextIsSelectable(true); typeface = Typeface.MONOSPACE; textSize = 12f
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val b = AlertDialog.Builder(act).setTitle(title).setView(ScrollView(act).apply { addView(tv) })
            .setPositiveButton("Close", null)
            .setNeutralButton("Copy") { _, _ -> copy(text) }
        if (extra != null) b.setNegativeButton(extra.first) { _, _ -> extra.second() }
        b.show()
    }

    // ---- the tabbed window -----------------------------------------------------------------------------

    fun openMenu(tab: Int) {
        val names = listOf("Style", "View", "Source", "Tools", "Info")
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val tabRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val body = FrameLayout(act)
        var dlg: AlertDialog? = null
        val labels = ArrayList<TextView>()
        fun select(i: Int) {
            body.removeAllViews()
            val page = when (i) {
                0 -> styleTab()
                1 -> viewTab { dlg?.dismiss() }
                2 -> sourceTab { dlg?.dismiss() }
                3 -> toolsTab { dlg?.dismiss() }
                else -> infoTab()
            }
            body.addView(ScrollView(act).apply { addView(page) })
            labels.forEachIndexed { k, t ->
                t.setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL)
                t.setBackgroundColor(if (k == i) 0x331E88E5 else Color.TRANSPARENT)
            }
        }
        names.forEachIndexed { i, n ->
            val t = TextView(act).apply { text = n; setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { select(i) } }
            labels.add(t); tabRow.addView(t)
        }
        root.addView(HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(tabRow) })
        root.addView(body, LinearLayout.LayoutParams(-1, (act.resources.displayMetrics.heightPixels * 0.62).toInt()))
        select(tab.coerceIn(0, names.size - 1))
        dlg = AlertDialog.Builder(act).setTitle("HTML viewer tools").setView(root).setPositiveButton("Close", null).show()
    }

    private fun styleTab(): View = column().apply {
        seek({ "Text size: $it%" }, "textZoom", 30, 400, 100) { web.settings.textZoom = it }
        radios("Theme", "theme", listOf("Page's own colours", "Dark (inverted)", "Sepia", "High contrast", "Grey"), 0) { applyStyle() }
        radios("Font", "font", listOf("Page's own", "Serif", "Sans-serif", "Monospace"), 0) { applyStyle() }
        seek({ if (it == 0) "Line spacing: page's own" else "Line spacing: ${it / 100f}" }, "lineH", 0, 300, 0) { applyStyle() }
        label("Page", true)
        check("Hide images", "hideImg", false) { applyStyle() }
        check("Stop animations and transitions", "noAnim", false) { applyStyle() }
        check("Highlight links", "hiLinks", false) { applyStyle() }
        check("Wrap long lines in code and tables", "wrapCode", false) { applyStyle() }
        check("Reader width (a narrow column in the middle)", "reader", false) { applyStyle() }
        label("Your own CSS (added to every page this viewer opens)", true)
        val css = EditText(act).apply {
            setText(prefs.getString("userCss", "").orEmpty())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE; minLines = 3; gravity = Gravity.TOP or Gravity.START
            hint = "body { background: #111; }"
        }
        addView(css)
        button("Apply my CSS") { prefs.edit().putString("userCss", css.text.toString()).apply(); applyStyle(); toast("Applied") }
        button("Reset all of the style settings") {
            prefs.edit().remove("textZoom").remove("theme").remove("font").remove("lineH").remove("hideImg").remove("noAnim")
                .remove("hiLinks").remove("wrapCode").remove("reader").remove("userCss").apply()
            web.settings.textZoom = 100; applyStyle(); toast("Reset: reopen this window to see it")
        }
    }

    private fun viewTab(close: () -> Unit): View = column().apply {
        check("Desktop site (the page sees a desktop browser; reloads)", "desktop", false) {
            web.settings.userAgentString = if (it) DESKTOP_UA else null
            web.reload()
        }
        check("Allow JavaScript (reloads; the tools that read the page need it)", "jsOn", true) { web.settings.javaScriptEnabled = it; web.reload() }
        check("Load images (reloads)", "imagesOn", true) { web.settings.loadsImagesAutomatically = it; web.reload() }
        check("Remember where I was in each page", "rememberScroll", false)
        radios("Screen rotation", "orient", listOf("Automatic", "Portrait", "Landscape", "Landscape, either way up"), 0) { applyOrientation() }
        label("Scroll by itself", true)
        seek({ "Speed: $it" }, "autoSpeed", 1, 40, 8) {}
        button("Start scrolling (touch the page to stop)") { close(); startAuto() }
        label("Go to", true)
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        fun small(t: String, f: () -> Unit) = row.addView(Button(act).apply { text = t; isAllCaps = false; setOnClickListener { f() } }, LinearLayout.LayoutParams(0, -2, 1f))
        small("Top") { close(); web.scrollTo(0, 0) }
        small("Bottom") { close(); web.scrollTo(0, (web.range() - web.extent()).coerceAtLeast(0)) }
        small("Back") { close(); if (web.canGoBack()) web.goBack() }
        small("Reload") { close(); web.reload() }
        addView(row)
    }

    private fun sourceTab(close: () -> Unit): View = column().apply {
        val o = owner
        if (o == null) { label("The source is not available here."); return@apply }
        button("View the page source") { close(); showText("Page source", o.sourceText(), "Edit…" to { editSource(o) }) }
        button("View the live page (after its scripts ran)") {
            close(); js("document.documentElement.outerHTML") { showText("Live page", it) }
        }
        button("Edit the source and reload") { close(); editSource(o) }
        button("Find and replace in the source") { close(); sourceReplace(o) }
        button("Copy the source") { copy(o.sourceText()) }
        button("Copy the live page") { js("document.documentElement.outerHTML") { copy(it) } }
        button("Save the source as a file…") { close(); o.saveText(o.pageFileName(), "text/html", o.sourceText()) }
        button("Save the live page as a file…") {
            close(); js("document.documentElement.outerHTML") { o.saveText("live-" + o.pageFileName(), "text/html", it) }
        }
        button("Share the source as text") {
            val t = o.sourceText()
            if (t.length > 200_000) toast("Too big to share as text: save it as a file.")
            else act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share"))
        }
        label("Changes to the source stay in this window only; the original file is not touched. Save to keep them.")
    }

    private fun editSource(o: HtmlViewerActivity) {
        val et = EditText(act).apply {
            setText(o.sourceText())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE; textSize = 12f; gravity = Gravity.TOP or Gravity.START
        }
        AlertDialog.Builder(act).setTitle("Edit the source").setView(et)
            .setPositiveButton("Reload with it") { _, _ -> o.setSource(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun sourceReplace(o: HtmlViewerActivity) {
        val col = column()
        val f = EditText(act).apply { hint = "Find"; isSingleLine = true }
        val r = EditText(act).apply { hint = "Replace with"; isSingleLine = true }
        col.addView(f); col.addView(r)
        val cs = CheckBox(act).apply { text = "Match case" }
        val rx = CheckBox(act).apply { text = "Regular expression" }
        col.addView(cs); col.addView(rx)
        AlertDialog.Builder(act).setTitle("Find and replace in the source").setView(col)
            .setPositiveButton("Replace all") { _, _ ->
                val q = f.text.toString()
                if (q.isEmpty()) return@setPositiveButton
                val opts = if (cs.isChecked) emptySet() else setOf(RegexOption.IGNORE_CASE)
                try {
                    val re = Regex(if (rx.isChecked) q else Regex.escape(q), opts)
                    val src = o.sourceText()
                    val n = re.findAll(src).count()
                    if (n == 0) { toast("Nothing found"); return@setPositiveButton }
                    o.setSource(re.replace(src, if (rx.isChecked) r.text.toString() else Regex.escapeReplacement(r.text.toString())))
                    toast("Replaced $n")
                } catch (e: Exception) { toast("That pattern is not valid") }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toolsTab(close: () -> Unit): View = column().apply {
        button("Print, or save the page as a PDF") {
            close()
            runCatching {
                val pm = act.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                val name = act.title?.toString().orEmpty().ifBlank { "page" }
                pm.print(name, web.createPrintDocumentAdapter(name), android.print.PrintAttributes.Builder().build())
            }.onFailure { toast("Printing is not available") }
        }
        button("Copy all the text of the page") { js("document.body?document.body.innerText:''") { copy(it) } }
        button("Share the text of the page") {
            js("document.body?document.body.innerText:''") {
                if (it.length > 200_000) toast("Too big to share: copy it instead.")
                else act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it), "Share"))
            }
        }
        button("List the links") {
            close()
            js("JSON.stringify(Array.prototype.map.call(document.links,function(a){return (a.innerText||a.title||'').trim().slice(0,60)+'  →  '+a.href}))") { showList("Links", it) }
        }
        button("List the images") {
            close()
            js("JSON.stringify(Array.prototype.map.call(document.images,function(i){return (i.alt||'').slice(0,40)+'  →  '+(i.currentSrc||i.src).slice(0,200)}))") { showList("Images", it) }
        }
        button("Run JavaScript on the page") { close(); console() }
        button("Clear the saved site data of this viewer") {
            android.webkit.WebStorage.getInstance().deleteAllData()
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            web.clearCache(true)
            toast("Cleared")
        }
        label("Everything here works on the page in this window only. The viewer stays offline.")
    }

    private fun showList(title: String, json: String) {
        val items = runCatching { org.json.JSONArray(json).let { a -> (0 until a.length()).map { a.getString(it) } } }.getOrDefault(emptyList())
        if (items.isEmpty()) { toast("None found"); return }
        AlertDialog.Builder(act).setTitle("$title (${items.size})")
            .setItems(items.toTypedArray()) { _, i -> copy(items[i].substringAfter("  →  ")) }
            .setNeutralButton("Copy all") { _, _ -> copy(items.joinToString("\n")) }
            .setPositiveButton("Close", null).show()
    }

    private fun console() {
        val col = column()
        val code = EditText(act).apply {
            hint = "document.title"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            typeface = Typeface.MONOSPACE; minLines = 3; gravity = Gravity.TOP or Gravity.START
        }
        val out = TextView(act).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true); setPadding(0, dp(8), 0, 0) }
        col.addView(code); col.addView(out)
        val d = AlertDialog.Builder(act).setTitle("JavaScript").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Run", null).setNegativeButton("Close", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val src = code.text.toString()
            js("(function(){try{var r=eval(" + JSONObject.quote(src) + ");return String(r);}catch(e){return 'Error: '+e;}})()") { out.text = it }
        }
    }

    private fun infoTab(): View = column().apply {
        val tv = TextView(act).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true); text = "Reading the page…" }
        addView(tv)
        val o = owner
        val head = StringBuilder()
        if (o != null) {
            val src = o.sourceText()
            head.append("File: ").append(o.pageFileName()).append('\n')
            head.append("Source size: ").append(src.toByteArray(Charsets.UTF_8).size / 1024).append(" KB, ").append(src.count { it == '\n' } + 1).append(" lines\n")
        }
        head.append("Text size: ").append(web.settings.textZoom).append("%\n")
        js("JSON.stringify({t:document.title,l:document.documentElement.lang,e:document.getElementsByTagName('*').length," +
            "a:document.links.length,i:document.images.length,s:document.scripts.length,f:document.forms.length," +
            "w:(document.body?document.body.innerText.trim().split(/\\s+/).length:0),cs:document.characterSet})") {
            val j = runCatching { JSONObject(it) }.getOrNull()
            if (j != null) {
                head.append("Title: ").append(j.optString("t")).append('\n')
                    .append("Language: ").append(j.optString("l").ifBlank { "not set" }).append('\n')
                    .append("Encoding: ").append(j.optString("cs")).append('\n')
                    .append("Elements: ").append(j.optInt("e")).append('\n')
                    .append("Words: ").append(j.optInt("w")).append('\n')
                    .append("Links: ").append(j.optInt("a")).append("   Images: ").append(j.optInt("i")).append('\n')
                    .append("Scripts: ").append(j.optInt("s")).append("   Forms: ").append(j.optInt("f")).append('\n')
            } else head.append("(JavaScript is off, so the page cannot be read.)\n")
            tv.text = head.toString()
        }
    }

    // ---- automatic scrolling ---------------------------------------------------------------------------

    private var autoOn = false
    private var autoCarry = 0f
    private val autoRun = object : Runnable {
        override fun run() {
            if (!autoOn) return
            autoCarry += prefs.getInt("autoSpeed", 8) * density / 6f
            val whole = autoCarry.toInt()
            if (whole > 0) { web.scrollBy(0, whole); autoCarry -= whole }
            if (web.offset() >= web.range() - web.extent() - 1) { stopAuto(); return }
            handler.postDelayed(this, 16)
        }
    }

    private fun startAuto() { autoOn = true; autoCarry = 0f; handler.post(autoRun) }
    private fun stopAuto() { autoOn = false; handler.removeCallbacks(autoRun) }

    // ---- the find bar ----------------------------------------------------------------------------------

    private var findBar: LinearLayout? = null

    fun closeFind() {
        findBar?.let { frame.removeView(it) }
        findBar = null
        web.clearMatches()
        web.setFindListener(null)
    }

    /** The find bar at the top: matches counted, next and previous; [withReplace] shows the replace row too. */
    fun openFind(withReplace: Boolean) {
        if (findBar != null) closeFind()
        val bar = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xF2202124.toInt()); setPadding(dp(6), dp(6), dp(6), dp(6)) }
        val count = TextView(act).apply { setTextColor(Color.WHITE); setPadding(dp(6), 0, dp(6), 0); text = "" }
        val find = EditText(act).apply {
            hint = "Find"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); isSingleLine = true
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        fun tiny(t: String, f: () -> Unit) = Button(act).apply { text = t; isAllCaps = false; minWidth = dp(40); minimumWidth = dp(40); setOnClickListener { f() } }
        val rep = EditText(act).apply { hint = "Replace with"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); isSingleLine = true }
        val repRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; visibility = if (withReplace) View.VISIBLE else View.GONE }
        val optRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; visibility = if (withReplace) View.VISIBLE else View.GONE }
        val cs = CheckBox(act).apply { text = "Aa"; setTextColor(Color.WHITE) }
        val wh = CheckBox(act).apply { text = "Word"; setTextColor(Color.WHITE) }
        val rx = CheckBox(act).apply { text = ".*"; setTextColor(Color.WHITE) }

        web.setFindListener { active, total, _ -> count.text = if (total == 0) "0" else "${active + 1}/$total" }
        find.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val q = e?.toString().orEmpty()
                if (q.isEmpty()) { web.clearMatches(); count.text = "" } else web.findAllAsync(q)
            }
        })
        find.setOnEditorActionListener { _, _, _ -> web.findNext(true); true }

        fun replace(all: Boolean) {
            val q = find.text.toString()
            if (q.isEmpty()) return
            val call = "(function(q,r,cs,wh,rx,all){" +
                "var p;try{if(rx){p=q;}else{var sp='.*+?^'+String.fromCharCode(36)+'{}()|[]\\\\/';var o='';" +
                "for(var k=0;k<q.length;k++){var c=q.charAt(k);o+=(sp.indexOf(c)>=0?'\\\\':'')+c;}p=o;}" +
                "if(wh){p='\\\\b'+p+'\\\\b';}var re=new RegExp(p,cs?'g':'gi');}catch(e){return -1;}" +
                "var w=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT,null);var nodes=[],t;" +
                "while(t=w.nextNode()){var pn=t.parentNode&&t.parentNode.nodeName;if(pn==='SCRIPT'||pn==='STYLE'||pn==='NOSCRIPT')continue;nodes.push(t);}" +
                "var n=0;for(var i=0;i<nodes.length;i++){var s=nodes[i].nodeValue;re.lastIndex=0;if(!re.test(s))continue;re.lastIndex=0;" +
                "if(all){var cnt=0;nodes[i].nodeValue=s.replace(re,function(){cnt++;return r;});n+=cnt;}" +
                "else{nodes[i].nodeValue=s.replace(new RegExp(re.source,cs?'':'i'),function(){return r;});n=1;break;}}" +
                "return n;})(" + JSONObject.quote(q) + "," + JSONObject.quote(rep.text.toString()) + "," + cs.isChecked + "," + wh.isChecked + "," + rx.isChecked + "," + all + ")"
            web.evaluateJavascript(call) { r ->
                val n = r?.toIntOrNull() ?: 0
                toast(if (n < 0) "That pattern is not valid" else if (n == 0) "Nothing found" else "Replaced $n (on the page; use the Source tab to change the file)")
                if (n > 0) web.findAllAsync(q)
            }
        }

        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(find, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(count)
        top.addView(tiny("▲") { web.findNext(false) })
        top.addView(tiny("▼") { web.findNext(true) })
        top.addView(tiny("⇄") {
            val show = repRow.visibility != View.VISIBLE
            repRow.visibility = if (show) View.VISIBLE else View.GONE
            optRow.visibility = repRow.visibility
        })
        top.addView(tiny("✕") { closeFind() })
        repRow.addView(rep, LinearLayout.LayoutParams(0, -2, 1f))
        repRow.addView(tiny("Replace") { replace(false) })
        repRow.addView(tiny("All") { replace(true) })
        optRow.addView(cs); optRow.addView(wh); optRow.addView(rx)
        bar.addView(top); bar.addView(repRow); bar.addView(optRow)
        frame.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        findBar = bar
        find.requestFocus()
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showSoftInput(find, 0)
    }
}
