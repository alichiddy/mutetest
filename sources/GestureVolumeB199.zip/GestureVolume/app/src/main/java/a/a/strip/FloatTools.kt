package a.a.strip

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.animation.ValueAnimator
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * The floating notes and the floating gallery. Each is one overlay window that exists only while it
 * is open: closing it drops every view, picture and thread, so nothing stays in memory.
 */
object FloatTools {
    private val open = HashMap<String, ToolWindow>()

    fun isOpen(kind: String) = open.containsKey(kind)

    /** Opens the tool, or closes it when it is already open. */
    fun toggle(ctx: Context, kind: String): Boolean {
        val app = ctx.applicationContext
        val existing = open[kind]
        if (existing != null) {
            existing.close()
            return true
        }
        if (!WidgetFloat.allowed(app)) return false
        if (kind == "gallery" && !canReadPhotos(app)) {
            WidgetFloat.toast(app, "Give A access to photos (or All files access), then try again")
            runCatching {
                app.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
            return false
        }
        val w: ToolWindow = if (kind == "notes") NotesWindow(app) { open.remove(kind) } else GalleryWindow(app) { open.remove(kind) }
        if (!w.show()) {
            WidgetFloat.toast(app, "It could not be shown")
            return false
        }
        open[kind] = w
        return true
    }

    fun closeAll() {
        open.values.toList().forEach { it.close() }
    }

    private fun canReadPhotos(app: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true
        val perm = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_IMAGES" else "android.permission.READ_EXTERNAL_STORAGE"
        return app.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

/** A draggable, resizable window with a title bar, the content of the tool, and a corner handle. */
abstract class ToolWindow(protected val app: Context, private val kind: String, private val onClosed: () -> Unit) {
    protected val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    protected val d = app.resources.displayMetrics.density
    protected val handler = Handler(Looper.getMainLooper())
    protected val prefs = app.getSharedPreferences("float_tools", Context.MODE_PRIVATE)
    protected var root: LinearLayout? = null
    protected var lp: WindowManager.LayoutParams? = null
    protected var bar: LinearLayout? = null
    protected var foot: LinearLayout? = null
    protected var titleView: TextView? = null
    protected var closed = false

    protected fun dp(v: Int) = (v * d).toInt()

    protected abstract val defaultW: Int
    protected abstract val defaultH: Int
    protected abstract fun title(): String
    protected abstract fun content(): View
    protected open fun barButtons(): List<TextView> = emptyList()
    protected open fun footButtons(): List<TextView> = emptyList()
    protected open fun onBarTouched() {}
    protected open fun onClose() {}

    protected fun button(label: String, onClick: () -> Unit): TextView {
        val t = TextView(app)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.minWidth = dp(34)
        t.setPadding(dp(4), 0, dp(4), 0)
        t.setOnClickListener { onClick() }
        return t
    }

    fun show(): Boolean {
        val dm = app.resources.displayMetrics
        val w = prefs.getInt(kind + "_w", dp(defaultW)).coerceIn(dp(160), dm.widthPixels)
        val h = prefs.getInt(kind + "_h", dp(defaultH)).coerceIn(dp(120), dm.heightPixels)
        val r = LinearLayout(app)
        r.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xF2202124.toInt())
        bg.cornerRadius = dp(12).toFloat()
        r.background = bg
        r.clipToOutline = true

        val b = LinearLayout(app)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.setBackgroundColor(0x33FFFFFF)
        val tv = TextView(app)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.textSize = 13f
        tv.setPadding(dp(10), 0, dp(4), 0)
        tv.maxLines = 1
        titleView = tv
        tv.text = title()
        b.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        for (x in barButtons()) b.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.addView(button("✕") { close() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bar = b
        r.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        r.addView(content(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val f = LinearLayout(app)
        f.orientation = LinearLayout.HORIZONTAL
        f.gravity = Gravity.CENTER_VERTICAL
        for (x in footButtons()) f.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Opacity bar: drag left to see through the window (20% to 100%), remembered for next time.
        val alphaNow = prefs.getInt(kind + "_alpha", 100).coerceIn(20, 100)
        val sb = SeekBar(app)
        sb.max = 80
        sb.progress = alphaNow - 20
        sb.setPadding(dp(10), 0, dp(10), 0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                lp?.alpha = (v + 20) / 100f
                update()
            }
            override fun onStartTrackingTouch(s: SeekBar?) { onBarTouched() }
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt(kind + "_alpha", (s?.progress ?: 80) + 20).apply()
            }
        })
        f.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val grip = TextView(app)
        grip.text = "◢"
        grip.setTextColor(0xAAFFFFFF.toInt())
        grip.gravity = Gravity.CENTER
        f.addView(grip, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))
        foot = f
        r.addView(f, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)))

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt(kind + "_x", (dm.widthPixels - w) / 2).coerceIn(0, maxOf(0, dm.widthPixels - w))
        p.y = prefs.getInt(kind + "_y", dp(90)).coerceIn(0, maxOf(0, dm.heightPixels - h))
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        p.alpha = alphaNow / 100f
        lp = p
        root = r

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    onBarTouched()
                    sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (ev.rawX - sx)).toInt().coerceIn(0, maxOf(0, dm.widthPixels - p.width))
                    p.y = (oy + (ev.rawY - sy)).toInt().coerceIn(0, maxOf(0, dm.heightPixels - p.height))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        var gw = 0
        var gh = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; gw = p.width; gh = p.height }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (gw + (ev.rawX - sx)).toInt().coerceIn(dp(160), maxOf(dp(160), dm.widthPixels - p.x))
                    p.height = (gh + (ev.rawY - sy)).toInt().coerceIn(dp(120), maxOf(dp(120), dm.heightPixels - p.y))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        return runCatching { wm.addView(r, p) }.isSuccess
    }

    protected fun update() {
        val r = root ?: return
        val p = lp ?: return
        runCatching { wm.updateViewLayout(r, p) }
    }

    private fun remember() {
        val p = lp ?: return
        prefs.edit().putInt(kind + "_x", p.x).putInt(kind + "_y", p.y).putInt(kind + "_w", p.width).putInt(kind + "_h", p.height).apply()
    }

    /** Lets the keyboard type into this window (on), or hands the screen back to the app underneath (off). */
    protected fun setTyping(on: Boolean) {
        val p = lp ?: return
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        update()
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching { onClose() }
        remember()
        root?.let { v -> runCatching { wm.removeView(v) } }
        root = null
        onClosed()
    }
}

class NotesWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "notes", onClosed) {
    override val defaultW = 290
    override val defaultH = 300

    private val notes = ArrayList<String>()
    private var idx = 0
    private var size = 16f
    private var edit: EditText? = null
    private var sure = false
    private var delBtn: TextView? = null
    private val saveRun = Runnable { save() }

    init {
        runCatching {
            val a = JSONArray(prefs.getString("notes_list", "[]"))
            for (n in 0 until a.length()) notes.add(a.getString(n))
        }
        if (notes.isEmpty()) notes.add("")
        idx = prefs.getInt("notes_idx", 0).coerceIn(0, notes.size - 1)
        size = prefs.getFloat("notes_size", 16f)
    }

    override fun title() = "Note ${idx + 1} of ${notes.size}"

    private fun save() {
        val a = JSONArray()
        for (t in notes) a.put(t)
        prefs.edit().putString("notes_list", a.toString()).putInt("notes_idx", idx).putFloat("notes_size", size).apply()
    }

    private fun showNote() {
        edit?.setText(notes[idx])
        edit?.setSelection(edit?.text?.length ?: 0)
        titleView?.text = title()
        sure = false
        delBtn?.setTextColor(0xFFFFFFFF.toInt())
    }

    private fun keep() {
        notes[idx] = edit?.text?.toString().orEmpty()
    }

    private fun typingOff() {
        val e = edit ?: return
        e.clearFocus()
        (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(e.windowToken, 0)
        setTyping(false)
    }

    override fun onBarTouched() = typingOff()

    override fun content(): View {
        val e = EditText(app)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setHintTextColor(0x88FFFFFF.toInt())
        e.hint = "Type a note"
        e.textSize = size
        e.gravity = Gravity.TOP or Gravity.START
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        e.background = null
        e.setPadding(dp(10), dp(8), dp(10), dp(8))
        e.setText(notes[idx])
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                notes[idx] = s?.toString().orEmpty()
                handler.removeCallbacks(saveRun)
                handler.postDelayed(saveRun, 500)
            }
        })
        e.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                setTyping(true)
                v.postDelayed({
                    v.requestFocus()
                    (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, 0)
                }, 150)
            }
            false
        }
        edit = e
        return e
    }

    override fun barButtons(): List<TextView> {
        val del = button("🗑") {
            if (!sure) {
                sure = true
                delBtn?.setTextColor(0xFFFF6666.toInt())
                handler.postDelayed({ sure = false; delBtn?.setTextColor(0xFFFFFFFF.toInt()) }, 2500)
            } else {
                if (notes.size > 1) { notes.removeAt(idx); idx = idx.coerceAtMost(notes.size - 1) } else notes[0] = ""
                showNote(); save()
            }
        }
        delBtn = del
        return listOf(
            button("◀") { if (idx > 0) { keep(); idx--; showNote(); save() } },
            button("▶") { if (idx < notes.size - 1) { keep(); idx++; showNote(); save() } },
            button("＋") { keep(); notes.add(idx + 1, ""); idx++; showNote(); save() },
            del,
            button("✓") { typingOff() },
        )
    }

    override fun footButtons(): List<TextView> = listOf(
        button("A−") { size = (size - 2f).coerceAtLeast(10f); edit?.textSize = size; save() },
        button("A＋") { size = (size + 2f).coerceAtMost(40f); edit?.textSize = size; save() },
    )

    override fun onClose() {
        handler.removeCallbacks(saveRun)
        typingOff()
        keep()
        save()
    }
}

class GalleryWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "gallery", onClosed) {
    override val defaultW = 320
    override val defaultH = 440

    private var ids = LongArray(0)
    private var grid: GridView? = null
    private var viewer: FrameLayout? = null
    private var big: ImageView? = null
    private var counter: TextView? = null
    private var pos = 0
    private var pool: ExecutorService? = null
    private val thumbs = LruCache<Long, Bitmap>(60)
    private var sc = 1f
    private var tx = 0f
    private var ty = 0f
    private var anim: ValueAnimator? = null

    override fun title() = "Gallery"

    private fun uri(id: Long): Uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())

    private fun loadList() {
        pool?.execute {
            val out = ArrayList<Long>()
            runCatching {
                app.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    null, null, MediaStore.Images.Media.DATE_ADDED + " DESC",
                )?.use { c ->
                    while (c.moveToNext() && out.size < 300) out.add(c.getLong(0))
                }
            }
            handler.post {
                if (closed) return@post
                ids = out.toLongArray()
                (grid?.adapter as? BaseAdapter)?.notifyDataSetChanged()
                titleView?.text = if (ids.isEmpty()) "Gallery (no photos found)" else "Gallery"
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun thumb(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 29) app.contentResolver.loadThumbnail(uri(id), Size(240, 240), null)
        else MediaStore.Images.Thumbnails.getThumbnail(app.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
    }.getOrNull()

    private fun full(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(app.contentResolver, uri(id))) { dec, info, _ ->
                val m = maxOf(info.size.width, info.size.height)
                if (m > 1600) dec.setTargetSampleSize(m / 1600 + 1)
            }
        } else {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o) }
            val m = maxOf(o.outWidth, o.outHeight)
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = if (m > 1600) m / 1600 + 1 else 1
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o2) }
        }
    }.getOrNull()

    private fun applyZoom() {
        val v = big ?: return
        v.scaleX = sc; v.scaleY = sc; v.translationX = tx; v.translationY = ty
    }

    /** Keeps the picture from being dragged away from the window. */
    private fun clampPan() {
        val w = viewer?.width ?: return
        val h = viewer?.height ?: return
        val mx = (sc - 1f) * w / 2f
        val my = (sc - 1f) * h / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
    }

    /** Zooms to [target] while the picture point under (fx, fy) stays under the fingers. */
    private fun zoomAbout(fx: Float, fy: Float, target: Float) {
        val v = viewer ?: return
        val cx = v.width / 2f
        val cy = v.height / 2f
        val s1 = sc
        val s2 = target.coerceIn(1f, 6f)
        tx = fx - cx - (fx - cx - tx) * s2 / s1
        ty = fy - cy - (fy - cy - ty) * s2 / s1
        sc = s2
        if (sc <= 1.001f) { sc = 1f; tx = 0f; ty = 0f }
        clampPan()
        applyZoom()
    }

    /** Double tap: zoom in on the tapped spot, or back out when already zoomed. */
    private fun doubleTapZoom(fx: Float, fy: Float) {
        val v = viewer ?: return
        anim?.cancel()
        val s0 = sc; val x0 = tx; val y0 = ty
        val s1: Float; val x1: Float; val y1: Float
        if (sc > 1.05f) {
            s1 = 1f; x1 = 0f; y1 = 0f
        } else {
            s1 = 2.5f
            val mx = (s1 - 1f) * v.width / 2f
            val my = (s1 - 1f) * v.height / 2f
            x1 = (-(fx - v.width / 2f) * (s1 - 1f)).coerceIn(-mx, mx)
            y1 = (-(fy - v.height / 2f) * (s1 - 1f)).coerceIn(-my, my)
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 200
        a.addUpdateListener {
            val t = it.animatedValue as Float
            sc = s0 + (s1 - s0) * t
            tx = x0 + (x1 - x0) * t
            ty = y0 + (y1 - y0) * t
            applyZoom()
        }
        anim = a
        a.start()
    }

    private fun openAt(n: Int) {
        if (ids.isEmpty()) return
        anim?.cancel()
        pos = (n + ids.size) % ids.size
        sc = 1f; tx = 0f; ty = 0f
        applyZoom()
        big?.setImageDrawable(null)
        counter?.text = "${pos + 1} / ${ids.size}"
        viewer?.visibility = View.VISIBLE
        val id = ids[pos]
        val want = pos
        pool?.execute {
            val b = full(id)
            handler.post { if (!closed && pos == want) big?.setImageBitmap(b) }
        }
    }

    private fun backToGrid() {
        viewer?.visibility = View.GONE
        big?.setImageDrawable(null)
    }

    override fun content(): View {
        pool = Executors.newFixedThreadPool(2)
        val frame = FrameLayout(app)

        val g = GridView(app)
        g.numColumns = GridView.AUTO_FIT
        g.columnWidth = dp(92)
        g.horizontalSpacing = dp(2)
        g.verticalSpacing = dp(2)
        g.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        g.adapter = object : BaseAdapter() {
            override fun getCount() = ids.size
            override fun getItem(p: Int) = ids[p]
            override fun getItemId(p: Int) = ids[p]
            override fun getView(p: Int, old: View?, parent: ViewGroup?): View {
                val iv = (old as? ImageView) ?: ImageView(app).also {
                    it.scaleType = ImageView.ScaleType.CENTER_CROP
                    it.layoutParams = AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, dp(92))
                    it.setBackgroundColor(0x22FFFFFF)
                }
                val id = ids[p]
                iv.tag = id
                val cached = thumbs.get(id)
                if (cached != null) {
                    iv.setImageBitmap(cached)
                } else {
                    iv.setImageDrawable(null)
                    pool?.execute {
                        val b = thumb(id)
                        if (b != null) handler.post {
                            if (!closed) { thumbs.put(id, b); if (iv.tag == id) iv.setImageBitmap(b) }
                        }
                    }
                }
                return iv
            }
        }
        g.setOnItemClickListener { _, _, p, _ -> openAt(p) }
        grid = g
        frame.addView(g, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val vw = FrameLayout(app)
        vw.setBackgroundColor(0xFF000000.toInt())
        vw.visibility = View.GONE
        val iv = ImageView(app)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        big = iv
        // The touches are read on the fixed frame, not on the picture that is being scaled and moved.
        // (Reading them on the picture itself made the coordinates shift while zooming: that was the jump.)
        val sgd = ScaleGestureDetector(
            app,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(det: ScaleGestureDetector): Boolean {
                    zoomAbout(det.focusX, det.focusY, sc * det.scaleFactor)
                    return true
                }
            },
        )
        sgd.isQuickScaleEnabled = false
        val gd = GestureDetector(
            app,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent): Boolean = true
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    doubleTapZoom(e.x, e.y)
                    return true
                }
            },
        )
        var lcx = 0f
        var lcy = 0f
        fun centre(ev: MotionEvent, skip: Int) {
            var sx = 0f; var sy = 0f; var n = 0
            for (i in 0 until ev.pointerCount) {
                if (i == skip) continue
                sx += ev.getX(i); sy += ev.getY(i); n++
            }
            if (n > 0) { lcx = sx / n; lcy = sy / n }
        }
        vw.setOnTouchListener { _, ev ->
            // A running zoom animation stops first. (Stopping it after the detectors ran cancelled the
            // animation that the double tap had just started, so a double tap never zoomed.)
            if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN) anim?.cancel()
            gd.onTouchEvent(ev)
            sgd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_UP -> centre(ev, ev.actionIndex)
                MotionEvent.ACTION_MOVE -> {
                    val ox = lcx; val oy = lcy
                    centre(ev, -1)
                    if (sc > 1f) {
                        tx += lcx - ox; ty += lcy - oy
                        clampPan()
                        applyZoom()
                    }
                }
            }
            true
        }
        vw.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val ctl = LinearLayout(app)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        ctl.setBackgroundColor(0x88000000.toInt())
        val cnt = TextView(app)
        cnt.setTextColor(0xFFFFFFFF.toInt())
        cnt.textSize = 12f
        cnt.gravity = Gravity.CENTER
        counter = cnt
        ctl.addView(button("◀") { openAt(pos - 1) }, LinearLayout.LayoutParams(dp(48), dp(34)))
        ctl.addView(button("▦") { backToGrid() }, LinearLayout.LayoutParams(dp(48), dp(34)))
        ctl.addView(cnt, LinearLayout.LayoutParams(dp(70), dp(34)))
        ctl.addView(button("▶") { openAt(pos + 1) }, LinearLayout.LayoutParams(dp(48), dp(34)))
        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.BOTTOM
        vw.addView(ctl, cl)
        viewer = vw
        frame.addView(vw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loadList()
        return frame
    }

    override fun onClose() {
        anim?.cancel()
        anim = null
        pool?.shutdownNow()
        pool = null
        thumbs.evictAll()
        grid?.adapter = null
        big?.setImageDrawable(null)
        ids = LongArray(0)
    }
}
