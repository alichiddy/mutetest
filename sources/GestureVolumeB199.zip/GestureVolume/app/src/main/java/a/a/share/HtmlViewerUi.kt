package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebView
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView

/** A web view that tells its owner how far it is scrolled, for the quick scroll bar. */
class ScrollWebView(context: Context) : WebView(context) {
    var onScrolled: (() -> Unit)? = null
    fun range() = computeVerticalScrollRange()
    fun offset() = computeVerticalScrollOffset()
    fun extent() = computeVerticalScrollExtent()
    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrolled?.invoke()
    }
}

/**
 * The HTML viewer's own controls, drawn over the page only while they are used: a blue bar to scroll
 * quickly and, above it, up to three round buttons (screen mode, stay awake, settings). Scrolling or
 * touching shows them; a set time (3 seconds by default) without touching the bar or a button hides them again.
 *
 * Screen mode cycles: both system bars, status bar only, navigation bar only, full screen.
 * Everything is plain views and nothing runs while the controls are hidden.
 */
class HtmlViewerUi(private val act: Activity, private val web: ScrollWebView, private val frame: FrameLayout) {
    private val prefs = act.getSharedPreferences("html_viewer", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private val blue = 0xFF1E88E5.toInt()

    private val layer = FrameLayout(act)
    private val buttons = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val bar = Bar(act)
    private var clock: TextClock? = null
    private var mode = 0 // 0 both bars, 1 status bar only, 2 navigation bar only, 3 full screen
    private var awake = false
    private var holding = false
    private val hideRun = Runnable { if (!holding) layer.visibility = View.GONE }

    private val tools = HtmlViewerTools(act, web, frame, prefs)
    private val modeBtn = IconBtn(act, 0)
    private val awakeBtn = IconBtn(act, 1)
    private val setBtn = IconBtn(act, 2)

    fun start() {
        mode = prefs.getInt("mode", 0).coerceIn(0, 3)
        layer.visibility = View.GONE
        frame.addView(layer, FrameLayout.LayoutParams(-1, -1))
        layer.addView(bar, FrameLayout.LayoutParams(dp(44), -1, Gravity.END or Gravity.TOP))
        layer.addView(buttons, FrameLayout.LayoutParams(dp(52), -2, Gravity.END or Gravity.TOP))
        modeBtn.setOnClickListener { mode = (mode + 1) % 4; prefs.edit().putInt("mode", mode).apply(); applyMode(); show() }
        awakeBtn.setOnClickListener { awake = !awake; applyAwake(); show() }
        setBtn.setOnClickListener { holding = true; showSettings() }
        layoutButtons()
        web.onScrolled = { show() }
        applyMode()
        tools.start()
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        web.onScrolled = null
        tools.stop()
    }

    /** The page has loaded: the page style, remembered scroll place and so on are applied to it. */
    fun onPageFinished() = tools.onPageFinished()

    fun reapply() = applyMode()

    private fun showBtn(key: String) = prefs.getBoolean(key, true)

    /** Where the scroll bar is: 0 right, 1 left, 2 not shown. Its own setting; older installs follow the two older ones until it is set. */
    private fun barSide(): Int =
        if (prefs.contains("barSide")) prefs.getInt("barSide", 0).coerceIn(0, 2)
        else if (!prefs.getBoolean("showBar", true)) 2 else prefs.getInt("side", 0).coerceIn(0, 1)

    private var movingBtn = false

    private fun layoutButtons() {
        val list = ArrayList<IconBtn>()
        if (showBtn("showModeBtn")) list.add(modeBtn)
        if (showBtn("showAwakeBtn")) list.add(awakeBtn)
        list.add(setBtn)
        val landscape = prefs.getBoolean("btnLandscape", false)
        val free = prefs.getBoolean("btnFree", false)
        val separate = free && prefs.getBoolean("btnSeparate", false)
        buttons.removeAllViews()
        for (x in listOf(modeBtn, awakeBtn, setBtn)) (x.parent as? ViewGroup)?.removeView(x)
        buttons.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0
        val bs = barSide()
        bar.visibility = if (bs == 2) View.GONE else View.VISIBLE
        val barEdge = if (bs == 1) Gravity.START else Gravity.END
        val barLp = bar.layoutParams as FrameLayout.LayoutParams
        barLp.gravity = barEdge or Gravity.TOP; barLp.topMargin = 0; barLp.bottomMargin = 0
        fun childLp() = LinearLayout.LayoutParams(dp(44), dp(44)).apply { if (landscape) leftMargin = dp(6) else topMargin = dp(6) }
        buttons.visibility = View.VISIBLE
        val lp = buttons.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = 0; lp.rightMargin = 0; lp.topMargin = 0; lp.bottomMargin = 0
        if (!free) {
            // As before: the buttons sit on one edge (the older side setting) at the top, middle or bottom of it.
            val left = prefs.getInt("side", 0) == 1
            val pos = prefs.getInt("btnPos", 0).coerceIn(0, 2)
            val edge = if (left) Gravity.START else Gravity.END
            val blockH = if (landscape) dp(56) else dp(6) + list.size * dp(50)
            val sameEdge = bs != 2 && (bs == 1) == left
            // The bar keeps clear of the buttons when they sit at its top or bottom; in the middle they sit beside it.
            if (sameEdge) { barLp.topMargin = if (pos == 0) blockH else 0; barLp.bottomMargin = if (pos == 2) blockH else 0 }
            lp.width = if (landscape) -2 else dp(52); lp.height = -2
            lp.gravity = edge or (when (pos) { 0 -> Gravity.TOP; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.BOTTOM })
            val beside = if (pos == 1 && sameEdge) dp(40) else 0
            lp.leftMargin = if (left) beside else 0
            lp.rightMargin = if (left) 0 else beside
            for (x in list) { buttons.addView(x, childLp()); x.setOnTouchListener(null) }
            buttons.translationX = 0f; buttons.translationY = 0f
        } else if (!separate) {
            // Free: all together, dropped wherever they are dragged (like the clock), else in the chosen corner.
            lp.width = -2; lp.height = -2
            lp.gravity = cornerOf(prefs.getInt("btnCorner", 2))
            lp.setMargins(dp(8), dp(8), dp(8), dp(8))
            for (x in list) { buttons.addView(x, childLp()); makeDraggable(x, buttons, "btnX", "btnY") }
            buttons.translationX = 0f; buttons.translationY = 0f
        } else {
            // Free and separate: every button has its own corner spot and its own dropped place.
            buttons.visibility = View.GONE
            val corner = prefs.getInt("btnCorner", 2)
            list.forEachIndexed { i, x ->
                val keyN = when (x) { modeBtn -> "0"; awakeBtn -> "1"; else -> "2" }
                val l = FrameLayout.LayoutParams(dp(44), dp(44), cornerOf(corner))
                val step = dp(8) + i * dp(50)
                val right = corner == 1 || corner == 3
                val bottom = corner == 2 || corner == 3
                if (landscape) { if (right) l.rightMargin = step else l.leftMargin = step; if (bottom) l.bottomMargin = dp(8) else l.topMargin = dp(8) }
                else { if (right) l.rightMargin = dp(8) else l.leftMargin = dp(8); if (bottom) l.bottomMargin = step else l.topMargin = step }
                x.translationX = 0f; x.translationY = 0f
                layer.addView(x, l)
                makeDraggable(x, x, "btnX$keyN", "btnY$keyN")
            }
        }
        buttons.layoutParams = lp
        bar.layoutParams = barLp
        bar.invalidate()
        layer.post { placeStored() }
    }

    private fun cornerOf(c: Int) = when (c) {
        0 -> Gravity.TOP or Gravity.START
        1 -> Gravity.TOP or Gravity.END
        3 -> Gravity.BOTTOM or Gravity.END
        else -> Gravity.BOTTOM or Gravity.START
    }

    /** Puts the buttons where they were last dropped (their layout place is the corner; this moves them from there). */
    private fun placeStored() {
        if (movingBtn || layer.width <= 0 || !prefs.getBoolean("btnFree", false)) return
        fun place(t: View, kx: String, ky: String) {
            if (!prefs.contains(kx)) return
            t.x = prefs.getFloat(kx, 0f) * (layer.width - t.width).coerceAtLeast(1)
            t.y = prefs.getFloat(ky, 0f) * (layer.height - t.height).coerceAtLeast(1)
        }
        if (!prefs.getBoolean("btnSeparate", false)) place(buttons, "btnX", "btnY")
        else for ((x, n) in listOf(modeBtn to "0", awakeBtn to "1", setBtn to "2")) if (x.parent === layer) place(x, "btnX$n", "btnY$n")
    }

    /** A touch on [v] either clicks it or, once the finger has gone past the touch slop, drags [target] (the clock's way). */
    private fun makeDraggable(v: View, target: View, kx: String, ky: String) {
        var downX = 0f; var downY = 0f; var tx0 = 0f; var ty0 = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; tx0 = target.x; ty0 = target.y; moved = false
                    holding = true; handler.removeCallbacks(hideRun)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > dp(8)) { moved = true; movingBtn = true }
                    if (moved) {
                        target.x = (tx0 + e.rawX - downX).coerceIn(0f, (layer.width - target.width).toFloat().coerceAtLeast(0f))
                        target.y = (ty0 + e.rawY - downY).coerceIn(0f, (layer.height - target.height).toFloat().coerceAtLeast(0f))
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit()
                            .putFloat(kx, target.x / (layer.width - target.width).coerceAtLeast(1))
                            .putFloat(ky, target.y / (layer.height - target.height).coerceAtLeast(1)).apply()
                        movingBtn = false; release()
                    } else { holding = false; v.performClick() }
                }
                MotionEvent.ACTION_CANCEL -> { movingBtn = false; release() }
            }
            true
        }
    }

    /** Shows the controls and starts the 3 second countdown to hide them. */
    private fun show() {
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0
        modeBtn.invalidate(); awakeBtn.invalidate()
        bar.invalidate()
        val wasHidden = layer.visibility != View.VISIBLE
        layer.visibility = View.VISIBLE
        if (wasHidden) layer.post { placeStored() }
        handler.removeCallbacks(hideRun)
        if (!holding) handler.postDelayed(hideRun, prefs.getInt("hideMs", 3000).toLong().coerceAtLeast(200L))
    }

    private fun release() { holding = false; show() }

    @Suppress("DEPRECATION")
    private fun applyMode() {
        val hideStatus = mode == 2 || mode == 3
        val hideNav = mode == 1 || mode == 3
        val w = act.window
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = w.insetsController
            if (c != null) {
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (hideStatus) c.hide(WindowInsets.Type.statusBars()) else c.show(WindowInsets.Type.statusBars())
                if (hideNav) c.hide(WindowInsets.Type.navigationBars()) else c.show(WindowInsets.Type.navigationBars())
            }
        } else {
            var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            if (hideStatus) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN
            if (hideNav) f = f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            w.decorView.systemUiVisibility = f
        }
        modeBtn.state = mode; modeBtn.invalidate()
        updateClock()
    }

    private fun applyAwake() {
        if (awake) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        awakeBtn.state = if (awake) 1 else 0; awakeBtn.invalidate()
    }

    /** The floating clock: only while the status bar is hidden (its own clock is gone then) and when switched on. */
    private fun updateClock() {
        val want = prefs.getBoolean("showClock", false) && (mode == 2 || mode == 3)
        if (!want) { clock?.let { frame.removeView(it) }; clock = null; return }
        if (clock != null) return
        val c = TextClock(act).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0x99000000.toInt()) }
        }
        clock = c
        frame.addView(c, FrameLayout.LayoutParams(-2, -2, cornerGravity()).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        // Wherever it was dropped, when it has been moved by hand.
        if (prefs.contains("clockX")) c.post {
            c.x = prefs.getFloat("clockX", 0f) * (frame.width - c.width).coerceAtLeast(1)
            c.y = prefs.getFloat("clockY", 0f) * (frame.height - c.height).coerceAtLeast(1)
        }
        var dx = 0f; var dy = 0f
        c.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = v.x - e.rawX; dy = v.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    v.x = (e.rawX + dx).coerceIn(0f, (frame.width - v.width).toFloat().coerceAtLeast(0f))
                    v.y = (e.rawY + dy).coerceIn(0f, (frame.height - v.height).toFloat().coerceAtLeast(0f))
                }
                MotionEvent.ACTION_UP -> prefs.edit()
                    .putFloat("clockX", v.x / (frame.width - v.width).coerceAtLeast(1))
                    .putFloat("clockY", v.y / (frame.height - v.height).coerceAtLeast(1)).apply()
            }
            true
        }
    }

    private fun cornerGravity() = when (prefs.getInt("clockCorner", 2)) {
        0 -> Gravity.TOP or Gravity.START
        1 -> Gravity.TOP or Gravity.END
        3 -> Gravity.BOTTOM or Gravity.END
        else -> Gravity.BOTTOM or Gravity.START
    }

    private fun showSettings() {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        fun check(text: String, key: String, def: Boolean, after: (Boolean) -> Unit = {}) {
            col.addView(CheckBox(act).apply {
                this.text = text; isChecked = prefs.getBoolean(key, def)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after(on) }
            })
        }
        // The advanced tools (find and replace, page style, source, tools, info) open from here.
        var dlg: AlertDialog? = null
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(android.widget.Button(act).apply { text = "Find / replace"; setOnClickListener { dlg?.dismiss(); tools.openFind(true) } }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(android.widget.Button(act).apply { text = "Advanced tools"; setOnClickListener { dlg?.dismiss(); tools.openMenu(0) } }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        check("Show the quick scroll bar", "showBar", true) { prefs.edit().remove("barSide").apply(); layoutButtons() }
        check("Show the screen mode button (both bars / status bar / navigation bar / full screen)", "showModeBtn", true) { layoutButtons() }
        check("Show the stay awake button", "showAwakeBtn", true) { layoutButtons() }
        check("Show a floating clock when the status bar is hidden", "showClock", false) { clock?.let { frame.removeView(it) }; clock = null; updateClock() }
        check("Show the faint line along the whole scroll bar (off: only the blue handle)", "showTrack", true) { bar.invalidate() }
        // The scroll bar and the buttons, each with its own settings.
        col.addView(TextView(act).apply { text = "Scroll bar (its own setting):"; setPadding(0, dp(10), 0, 0); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        val gb = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Right", "Left", "Not shown").forEachIndexed { i, n ->
            gb.addView(RadioButton(act).apply { text = n; id = 500 + i; isChecked = barSide() == i })
        }
        gb.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("barSide", id - 500).apply(); layoutButtons(); show() }
        col.addView(gb)
        col.addView(TextView(act).apply { text = "Buttons (their own settings):"; setPadding(0, dp(10), 0, 0); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        check("Free position: drag the buttons where you want them, like the clock", "btnFree", false) { layoutButtons(); show() }
        check("Landscape: the buttons in a row instead of one above the other", "btnLandscape", false) { layoutButtons(); show() }
        check("Each button moves on its own (off: they move together)", "btnSeparate", false) { layoutButtons(); show() }
        col.addView(TextView(act).apply { text = "Corner the free buttons start in (then drag them anywhere):"; setPadding(0, dp(4), 0, 0) })
        val gc = RadioGroup(act)
        listOf("Top left", "Top right", "Bottom left", "Bottom right").forEachIndexed { i, n ->
            gc.addView(RadioButton(act).apply { text = n; id = 600 + i; isChecked = prefs.getInt("btnCorner", 2) == i })
        }
        gc.setOnCheckedChangeListener { _, id ->
            val e = prefs.edit().putInt("btnCorner", id - 600)
            for (k in listOf("btnX", "btnY", "btnX0", "btnY0", "btnX1", "btnY1", "btnX2", "btnY2")) e.remove(k)
            e.apply(); layoutButtons(); show()
        }
        col.addView(gc)
        col.addView(android.widget.Button(act).apply {
            text = "Put the buttons back in their corner"
            setOnClickListener {
                val e = prefs.edit()
                for (k in listOf("btnX", "btnY", "btnX0", "btnY0", "btnX1", "btnY1", "btnX2", "btnY2")) e.remove(k)
                e.apply(); layoutButtons(); show()
            }
        })
        col.addView(TextView(act).apply { text = "Position of the scroll bar and buttons (the older setting; the scroll bar's own setting above wins once you set it):"; setPadding(0, dp(10), 0, 0) })
        val gs = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Right side", "Left side").forEachIndexed { i, n ->
            gs.addView(RadioButton(act).apply { text = n; id = 300 + i; isChecked = prefs.getInt("side", 0) == i })
        }
        gs.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("side", id - 300).remove("barSide").apply(); layoutButtons() }
        col.addView(gs)
        val gp = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Buttons top", "middle", "bottom").forEachIndexed { i, n ->
            gp.addView(RadioButton(act).apply { text = n; id = 400 + i; isChecked = prefs.getInt("btnPos", 0) == i })
        }
        gp.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("btnPos", id - 400).apply(); layoutButtons() }
        col.addView(gp)
        col.addView(TextView(act).apply { text = "Hide the controls after this many milliseconds without touching them (1000 = 1 second):"; setPadding(0, dp(6), 0, 0) })
        col.addView(android.widget.EditText(act).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("hideMs", 3000).toString())
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: android.text.Editable?) {
                    val v = e?.toString()?.toIntOrNull() ?: return
                    prefs.edit().putInt("hideMs", v.coerceIn(200, 600000)).apply()
                }
            })
        })
        col.addView(TextView(act).apply { text = "Clock corner (or just drag the clock where you want it):"; setPadding(0, dp(6), 0, 0) })
        val g = RadioGroup(act)
        listOf("Top left", "Top right", "Bottom left", "Bottom right").forEachIndexed { i, n ->
            g.addView(RadioButton(act).apply { text = n; id = 100 + i; isChecked = prefs.getInt("clockCorner", 2) == i })
        }
        g.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("clockCorner", id - 100).remove("clockX").remove("clockY").apply()
            clock?.let { frame.removeView(it) }; clock = null; updateClock()
        }
        col.addView(g)
        col.addView(CheckBox(act).apply {
            text = "Its own window in Recent apps (separate from A), from the next time a page is opened"
            isChecked = HtmlViewerSwitch.separate(act)
            setOnCheckedChangeListener { _, on -> HtmlViewerSwitch.setSeparate(act, on) }
        })
        AlertDialog.Builder(act).setTitle("HTML viewer settings").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Close", null).setOnDismissListener { release() }.show().also { dlg = it }
    }

    /** The blue quick scroll bar: touch or drag anywhere on it and the page follows. */
    private inner class Bar(ctx: Context) : View(ctx) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x331E88E5 }
        private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = blue }
        private var dragging = false
        private val r = RectF()

        private fun geometry(): FloatArray? {
            val range = web.range(); val ext = web.extent()
            if (range <= ext || height <= 0) return null
            val h = height.toFloat()
            val th = (h * ext / range).coerceIn(dp(56).toFloat(), h)
            val top = (h - th) * web.offset() / (range - ext)
            return floatArrayOf(th, top)
        }

        override fun onDraw(c: Canvas) {
            val g = geometry() ?: return
            val cx = if (barSide() == 1) dp(16).toFloat() else width - dp(16).toFloat()
            val tw = dp(4) / 2f
            // The faint line along the whole bar can be switched off; the blue handle stays.
            if (prefs.getBoolean("showTrack", true)) { r.set(cx - tw, 0f, cx + tw, height.toFloat()); c.drawRoundRect(r, tw, tw, track) }
            val w = (if (dragging) dp(14) else dp(8)) / 2f
            r.set(cx - w, g[1], cx + w, g[1] + g[0]); c.drawRoundRect(r, w, w, thumb)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val g = geometry() ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    parent.requestDisallowInterceptTouchEvent(true)
                    dragging = true; holding = true
                    val frac = ((e.y - g[0] / 2) / (height - g[0]).coerceAtLeast(1f)).coerceIn(0f, 1f)
                    web.scrollTo(web.scrollX, (frac * (web.range() - web.extent())).toInt())
                    invalidate(); show()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; release() }
            }
            return true
        }
    }

    /** A round button drawn in code: 0 = screen mode (phone with its two bars), 1 = stay awake (sun), 2 = settings (sliders). */
    private inner class IconBtn(ctx: Context, private val kind: Int) : View(ctx) {
        var state = 0
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
            bg.color = if (kind == 1 && state == 1) 0xFFFFA000.toInt() else 0xE61E88E5.toInt()
            c.drawCircle(cx, cy, w / 2, bg)
            when (kind) {
                0 -> {
                    val pw = dp(9).toFloat(); val ph = dp(13).toFloat()
                    r.set(cx - pw, cy - ph, cx + pw, cy + ph); c.drawRoundRect(r, dp(3).toFloat(), dp(3).toFloat(), ink)
                    val statusOn = state == 0 || state == 1
                    val navOn = state == 0 || state == 2
                    if (statusOn) { r.set(cx - pw, cy - ph, cx + pw, cy - ph + dp(5)); c.drawRect(r, fill) }
                    if (navOn) { r.set(cx - pw, cy + ph - dp(5), cx + pw, cy + ph); c.drawRect(r, fill) }
                }
                1 -> {
                    c.drawCircle(cx, cy, dp(5).toFloat(), if (state == 1) fill else ink)
                    for (i in 0 until 8) {
                        val a = Math.toRadians(i * 45.0)
                        val x1 = cx + Math.cos(a).toFloat() * dp(8); val y1 = cy + Math.sin(a).toFloat() * dp(8)
                        val x2 = cx + Math.cos(a).toFloat() * dp(12); val y2 = cy + Math.sin(a).toFloat() * dp(12)
                        c.drawLine(x1, y1, x2, y2, ink)
                    }
                }
                else -> {
                    val xs = floatArrayOf(0.3f, 0.65f, 0.45f)
                    for (i in 0 until 3) {
                        val y = cy + (i - 1) * dp(8)
                        c.drawLine(cx - dp(11), y, cx + dp(11), y, ink)
                        c.drawCircle(cx - dp(11) + dp(22) * xs[i], y, dp(3).toFloat(), fill)
                    }
                }
            }
        }
    }
}
