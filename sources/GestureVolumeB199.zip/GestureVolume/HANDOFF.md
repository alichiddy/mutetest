# HANDOFF (newest first)

## B179 - fix B178 (duplicate manifest activities) + separate "Build errors" notification
- B178 failed lint: the widget block copied from B177 dragged the rest of the manifest with it (21 DuplicateActivity). Now only the 4 widget activities are added.
- GitHubBuild: when the watched run ends in failure, fetchFailureLog() is posted as its own notification (channel "build_error", importance HIGH, id 7315, so the user can give it a sound in Android's channel settings). Tap or "Copy error" copies the full report (saved as ghLastError) via ButtonReceiver ACTION_COPY_ERROR. The normal status notification is unchanged. Uncompiled.

## B178 - merge of B176 (cells Look dialog, name outline, folder look) and B177 (widgets)
- Base = B176. Added from B177: strip/WidgetHostActivity, WidgetFloat, WidgetFloatActivity, WidgetKit (hosts other apps' widgets, e.g. Eitaa chats, floating widget window), their 4 manifest entries, "Widgets" buttons in Launcher mode (LauncherHomeActivity + LauncherModeActivity), ActionSaver.saveToCells(icon) parameter, "Widgets/Launcher mode" name (strings + cells editor button).
- Kept from B176 (B177 was older): LookDialog/LookPrefs, HtmlViewerTools, Flow.links, "Open an app" inside the pickers, Scripts row on the main screen, stripGapPct edge gap. Uncompiled.

## B176 - "Look of the cells": name outline + size, own look for folders, live view inside
- New file ui/screens/strip/LookDialog.kt replaces the old AlertDialog in StripEditorScreen. Full-screen dialog: the same StripView as the editor stays on top (true size, shrunk only to fit, tap a cell to light it, preview background Dark/Grey/White/Both saved as `stripLookPreviewBg`), settings scroll below. Tabs: Cells window | Folders.
- New settings (cells and folders): `stripLabelPct` (names under icons, 50-200, default 100), `stripOutlineColor` (0 = none, else ARGB), `stripOutlinePct` (thickness, % of text size, default 14). StripView.drawLabel draws a stroke pass then the fill; the lit cell and the thumb popup get no outline. FitText.draw got optional strokeColor/strokePct (no-icon cells).
- Folders: strip/LookPrefs.kt. Every look key has a folder twin `stripF<Name>` (stripFLook, stripFTileColor, ...). StripView(folderLook = true) reads the folder key if it exists, else the cells key, so nothing changes until the Folders tab is used. "Folders follow the cells window again" clears all stripF* look keys. OverlayController.openFolder passes folderLook = true; the editor view uses it when inside a folder (path not empty).
- Bigger names (>100%) move the icon up a little and the name down a little; long names still shrink to the cell width (+30% of the extra). Uncompiled.

## B174 - HTML viewer controls: position, line, hide time
- Settings (HtmlViewerUi.showSettings): side (right/left) for bar + buttons, buttons at top / middle / bottom (bar keeps clear of them; in the middle they sit beside the bar), switch for the faint line along the whole bar (`showTrack`), hide delay in milliseconds (`hideMs`, default 3000, min 200). Uncompiled.

## B173 - separate windows in Recent apps, HTML viewer controls, cells "Look"
- Manifest: documentLaunchMode="intoExisting" on GitHubSettings, Shell, Sides (segments), Flow (scripts), Downloads, AllApps, LauncherMode and the HTML viewer, so each is its own entry in Recent apps. Not changed: WifiShare (singleTask + share target), Cells/Appearance/Backups (inside MainActivity's Compose screens).
- HTML viewer: share/HtmlViewerUi.kt (plain views): blue quick-scroll bar on the right + three round buttons above it (screen mode cycling both bars / status only / nav only / full screen; stay awake; settings), all shown by scrolling or touching and hidden after 3 s idle; floating clock when the status bar is hidden (4 corners or dragged, saved); settings dialog (show bar / mode button / awake button / clock / corner / own Recent-apps window). Prefs file "html_viewer". The own-window option swaps two manifest entries: HtmlViewerActivity (document task, enabled by default) and HtmlViewerSameTaskActivity (disabled by default) via share/HtmlViewerSwitch.kt; Appearance "Show A HTML Viewer" switch and the "Open a file" action use it.
- StripView look (prefs stripLook 0/1/2, stripBackdropPct, stripHalo): 1 = icons only with no tiles/panel and bigger icons, 2 = icons only on a very faint dark panel (slider), halo = blurred dark outline behind icons and names. Editor: "Look of the cells" button. Uncompiled.

## B172 - fix B171 compile error
- B171 failed: maxWidth (BoxWithConstraints) was used inside a Column lambda (DSL_SCOPE_VIOLATION); it is now copied to availW before the Column.

## B171 - cells window true size, outside fields drawn as they really work
- Editor (StripEditorScreen): the cells window is no longer shrunk by the fields; it is the same size as on screen. The fields take the space left around it (thickness 22-56 dp).
- Switch off = only the fields fade (alpha 0.4); the cells window stays clear.
- Fields are drawn with the real geometry of OverlayController.outsideAt: side furthest past wins (corners cut at 45 degrees), equal parts along the window, end fields reach past the window corners. Tap hit-test uses the same rule. Only a strip of the fields can be shown (on screen they go to the screen edge).
- The −/+ per side moved from the corners to a row above the grid (EdgeCounts). Old EdgeCorner/EdgeSideFields removed. Uncompiled.

## B170 - fix B169 compile error + build notification opens the runs window
- B169 failed: actionDisplayName is @Composable and was called from a plain function/remember; edgeActionName(context, action) is now plain Kotlin.
- The build notification (id 7311, also the "A build FAILED" one) opens GitHubSettingsActivity with extra openRuns=true; GitHubSettingsDialog(openRuns) then loads and shows the workflow runs window by itself (Error report / copy there).

## B169 - base = B168-icons (B168 fields + the other account's icons-in-backup)
- Fresh install now starts from his own settings: assets/settings_default.json = his "A all settings" backup minus GitHub/auto-backup/personal run state (gh*, autoBackup*, isRunning, shellHistoryV1, ...). SettingsBackup.applyBaked applies settings AND scripts (strip + flows + sides); firstLaunch=false in it, so the tutorial walkthrough is skipped. Cells with an `img:` icon in that backup have no picture (the backup had no "icons" part): re-export with a build that has icons, then re-bake.
- Outside fields are drawn on the cells grid in the editor (EdgeFrame in StripEditorScreen): −/+ in the four corners cut each side into 1-6 equal fields at real length, tap a field = same ItemEditor as a cell (shows current action/name/icon, icon undo/redo). The old "Action outside of cells window" button/dialog is gone; the On switch is above the grid. Storage/helpers: strip/EdgeFields.kt (field meta = name+icon in `<key>Meta`). Segments keep their own dialog (SidesActivity).
- Device actions are now inside the built-in shortcuts list (BuiltInPage onPickAction, NativePicker.groups()/choose(), utils/DeviceActionIcons.kt); the separate "Device actions" buttons are removed from the cell editor, segment picker and the other-apps picker. The main Actions screen picker (ActionPicker) still has its own Device actions button.
- Click circle icon = utils/ClickCircleIcon.kt (ring + dot, like the circle drawn on screen).
- Uncompiled.

## B168 - more fields per outside side
- "Action outside of cells window": each side (Top/Left/Bottom/Right) can be cut into 1-6 equal fields, each with its own action (+/- stepper above that side's rows). 1 = old behaviour. Main: prefs `stripEdgeCnt<Side>`, field i>=1 = `stripEdge<Side>_<i>` (field 0 is the old `stripEdge<Side>`). Segments: `Seg.edgeMore` JSON (key "em"), helpers edgeCount/edgeAct/withEdgeAct/withEdgeCount.
- Fields are measured along the main cells window (left to right above/below, top to bottom beside), end fields reach past its corners. Zone = where the thumb is. Corner rule unchanged (furthest-past side wins).
- Segments that "follow main" use the main's fields; when mirrored, Left/Right swap as before and above/below fields run reversed. Own segment actions are never mirrored.
- Code: OverlayController.outsideAt / edgeCountFor / edgeActionFor; StripEditorScreen edge dialog; SidesActivity edge dialog. Uncompiled.

## B167 - everything is just "A"
- Source package is now `a.a` (was com.newagedevs.gesturevolume): folders under app/src/main/java/a/a and app/src/test/java/a/a, namespace "a.a", rootProject.name "A", themes `ATheme` / `Theme.A`.
- Shared flow files are `.afl` (marker "afl" inside, flow ids travel with the flows).
- Left on purpose: GitHubBuild.kt and SharedPref (they find the repo workflow `gesturevolume.yml`, release tag `gv`, and his zip names), assets/automate_flows.json (names of his GitHub release assets), LEGACY_CHANNEL_ID (it deletes an old notification channel), external URLs (privacy, terms, upstream source).
- Earlier in B162-B166: flow ids and rename-safe links (FlowStore: "#id" refs + aliases), flow list with multi-select (delete / duplicate / share / rename), tap-to-choose canvas forms (flow/ActionArgs.kt, flow/FlowPickers.kt), Volume boost as its own screen with stream and output scope (utils/VolumeBoost.kt, ui/screens/boost), Previous app resumes the task (utils/PreviousApp.kt).

## Accessibility service gets dropped (open)
- Report shows A's entry missing from enabled_accessibility_services at every disconnect; the list holds Undo, Automate (two services) and Universal Copy.
- Found in assets/automate_flows.json: several of his Automate flows run `settings put secure enabled_accessibility_services <whole list>` ("Toggles - Accessibility Services Enable", "Re-enable Accessibility Service", "Auto Enable Accessibility"). Any of them overwrites the list and drops A. Not proven to be the cause.
- B167 added to the report: pid on service CONNECTED / UNBOUND / DESTROYED / INTERRUPTED, a verdict on every list change ("A removed ALONE" vs "LIST REPLACED"), and at each disconnect: the raw list, `dumpsys accessibility`, install/update times and pid. Command labels are no longer cut.

## How to work with him
Ali, Persian/English, voice dictation ("ID" = "idea"). Lean replies, accuracy over speed, talk first for big things. NOT a developer: Automate-style boxes and forms, pick from lists, no formulas or code. Zero idle RAM. Never wait for a double tap. Deliver the zip only (no YML), name the build number, bracket-check changed .kt against the originals. Claude cannot compile Android: he builds on GitHub Actions (repo alichiddy/mutetest) and pastes errors.

## Still to do (his list)
Ask block; Show message "notification" target; Wait until (conditions from lists, timeout); Screen block via Shizuku; Accessibility "Interact" block; FIUSR asks which user; USSD flows.

---- Older notes below ----

# HANDOFF: native replacement for the Automate cells

Base: GestureVolume B56 (with the VolumeUp import fix and the "Resume build status" action).
This change adds an in-app action engine and built-in flows so the strip's cells no longer need Automate.
It could not be compiled where it was written: if GitHub reports `e:` lines, they point at the files below.

## New files (all in `flow/`, so merges stay easy)
- `NativeActions.kt`: every built-in action (id, label, what it needs). Ids starting with `A:` run one of A's own actions (Screenshot, Power menu, Shell runner...).
- `SeedFlows.kt`: the built-in flows (one per old Automate cell) and the table that maps old `Flow:468/233`-style cells to them. "Install my cells and flows" in the Flows screen runs it.
- `FlowHelpers.kt`: `PrivateValues` (keys/codes, stored in the separate `PrivateValues` prefs file, never in the settings backup or a cloned APK), plus two see-through helper activities (clipboard read, file pick).
- `assets/scripts/*.sh`: shell scripts copied exactly from the old Automate flows (`@PKG@`, `@MASK@`, `@TARGET_USER@` are filled in at run time).

## Changed files
- `flow/Flow.kt`: three new step types (`act`, `psh`, `bcast`).
- `flow/FlowRunner.kt`: runs them; fills `{name}` from PrivateValues; a missing-Shizuku step shows a message and opens Shizuku instead of failing.
- `flow/FlowActivity.kt`: action picker, "My values", "Install my cells and flows", "Allow usage access".
- `ui/screens/shell/ShizukuGrantRow.kt`: button label is now "Load My Automate".
- `AndroidManifest.xml`: 2 helper activities, PACKAGE_USAGE_STATS, WRITE_SECURE_SETTINGS, READ_PHONE_STATE, ACCESS_WIFI_STATE.
- `assets/grant.sh`: also grants usage access, secure settings, phone state, call phone, mock location (for the map in the next step).
- `utils/GitHubBuild.kt`, `HandlerActions.kt`, `HandlerActionCatalog.kt`, `OverlayController.kt`, `strings.xml`: "Resume build status" action (watch a build already started, no re-upload).
- `utils/HandlerActionCatalog.kt`: VolumeUp import fix.

## Rules of the engine
- NONE: works with the permissions A already has. ONCE: needs the one-time secure-settings grant (Grant button via Shizuku), else falls back to Shizuku. BETTER: opens the system panel without Shizuku. SHIZUKU: needs Shizuku every time.
- Steps can be marked "skips quietly without Shizuku" (`c = "optional"`).
- Never put real keys in source: use `{name}` and a slot in `PrivateValues.slots`.

## Not done yet
Fake-GPS map screen, Google Drive upload with sign-in, QR generator, the accessibility tap in WShr, Lens sharing step in LNS.
Five cells (2GOnly, WShr, DSave, PWR, WG Tunnel All) point at statement ids that are newer than the Automate backup this was built from: they were mapped by label. Verify them.

## B59 (on top of B58): messages, windows, wireless fixes
Touches only my files plus one line in `OverlayController.kt` (the "last result" bar in the `MyFlow:` branch).
- `FlowHelpers.kt`: `FlowPrefs` (message-bar mode: always / messages and failures [default] / only failures; button in the Flows screen) and `ResultActivity` (a window that stays until closed, with Copy).
- `FlowRunner.kt`: Message steps with `c = "window"` open the window; action results that should stay (uploads, grant/revoke, diagnostics) open it automatically (`NativeActions.staysOnScreen`).
- `NativeActions.kt`: Bluetooth tries `svc bluetooth` then `cmd bluetooth_manager` and checks the result; hotspot tries each stop/start command, checks the result and shows what the phone answered; new `wireless_diag` action; `bgshell` output is now `$ command` then the output (and `[exit N]` on failure), and `plain` copies nothing and uploads nothing.
- `SeedFlows.kt`: WifiOn and ALOF use the hotspot action. Existing installed flows are not overwritten: delete them in the Flows screen and press "Install my cells and flows" again to get the new versions.

## B60: Lens OCR ("NOW ON TAP") as one native action
- `NativeActions.kt`: new `lens_ocr`: runs `lensnet.sh prep` (stop VPNs, cut Wi-Fi/data, screenshot to /Documents/screenshot.png), opens it in Google Lens through A's FileProvider, waits until Lens/Google is left (max 3 min), then always runs `lensnet.sh on` (restores Wi-Fi and data, also when something fails).
- `AndroidManifest.xml`: FileProvider `${applicationId}.files`; new `res/xml/file_paths.xml`.
- `SeedFlows.kt`: LNS is now just `lens_ocr`. Delete the old LNS flow and press "Install my cells and flows" to get it.
- Needs "All files access" (the Grant button) so A can read the screenshot Shizuku's shell wrote.
- Not done: always-on automations (copy OTP, actions when apps open, unlock/charger/Wi-Fi triggers). They need a trigger engine; it touches `OverlayService` (start line), `GestureAccessibilityService` (app-in-front event) and the manifest (SMS receiver).

## B61: "Save to Downloads" in the share sheet
- New `share/SaveToDownloadsActivity.kt` + manifest entry: A appears in every app's share sheet as "Save to Downloads" and writes files (or shared text) into Download through MediaStore (no storage permission on Android 10+; `WRITE_EXTERNAL_STORAGE` maxSdk 28 for older phones).
- In a second profile (dual apps) with Shizuku ready it also copies the file to the main profile's Download folder (`/data/media/0/Download`). That copy is best effort and untested.

## B62 – Automations (always-on rules)
New package `app/src/main/java/com/newagedevs/gesturevolume/auto/` (Automations.kt, AutomationsScreen.kt). Rules (trigger, arg, flow) live in prefs "AutoRules". Triggers: SMS received (flow vars {otp},{message},{sender}), app opened (UsageStats poll, 2 s, screen on only), unlock, charger on/off, Wi-Fi connected, app installed. Seed flow "CopyOTP" (added from the screen's "Copy OTP from texts" button).
Existing files touched (one small edit each):
- AndroidManifest.xml: permissions ACCESS_NETWORK_STATE, RECEIVE_SMS; receiver `.auto.SmsRuleReceiver` (BROADCAST_SMS).
- service/OverlayService.kt: one line in onCreate: `Automations.start(this)`.
- flow/FlowActivity.kt: `autos` state, branch to `AutomationsScreen`, "Automations" button.
- assets/grant.sh: `pm grant … RECEIVE_SMS`.
Untested/uncompiled.

## B63 – merge of the other Claude's B59 (Automate-flow converter) + my B62
Three-way merge (base B58). Taken from the other Claude: Expr.kt, AutomateFlows.kt, assets/automate_flows.json, Flow.kt, FlowRunner.kt (goto-run, expr conditions, for-each), importedSlots in FlowHelpers.kt, NativeActions additions, "Add my Automate flows" button.
Kept from mine: FlowPrefs/ResultActivity, MESSAGE "window", Save to Downloads, Automations (auto/), Lens etc.
Only two hand-resolved spots: FlowRunner (WAIT = his expr version; MESSAGE = my FlowPrefs/window version) and FlowActivity (both buttons kept). Uncompiled.
