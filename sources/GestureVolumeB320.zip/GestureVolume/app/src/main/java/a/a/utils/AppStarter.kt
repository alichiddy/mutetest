package a.a.utils

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.Process
import a.a.service.OverlayRuntime

/**
 * Starts an activity so that it really opens. Android silently drops an activity started from the
 * background (no error, nothing happens) unless the app counts as visible at that moment, and it
 * refuses an activity that its app has not exported. An app's own shortcuts (the kind a launcher
 * shows on a long press) very often point at such an activity, because launchers reach them through
 * a privileged path that other apps do not have. The shell (Shizuku) is exempt from both rules, so
 * when Shizuku is ready every start of another app's activity goes through `am start`; otherwise
 * through the accessibility service, then A itself. Nothing runs or stays in memory until an
 * activity is launched.
 */
object AppStarter {
    private val main = Handler(Looper.getMainLooper())

    /** The repaired form of the shortcut the last start used, when it had to be repaired (see StripHeal). */
    @Volatile var lastHealed: Intent? = null
        private set

    fun clearHealed() { lastHealed = null }

    /**
     * Reads a saved shortcut ("Intent:" text) back into an Intent. A plain parse silently drops the
     * permission-grant flags the shortcut was saved with, which is what a folder shortcut (an address
     * of the folder plus a grant to read it) needs to open; URI_ALLOW_UNSAFE keeps them. Only text that
     * A itself saved is read this way.
     */
    fun parse(text: String): Intent =
        Intent.parseUri(text.trim().removePrefix("Intent:"), Intent.URI_INTENT_SCHEME or Intent.URI_ALLOW_UNSAFE)

    /** Why the last plain start failed, in words for the screen (null after a success). */
    @Volatile var lastFailure: String? = null
        private set

    /** True for the intent a launcher icon sends: MAIN + LAUNCHER, which is what getLaunchIntentForPackage builds. */
    fun isAppLaunch(i: Intent): Boolean =
        i.action == Intent.ACTION_MAIN && i.categories?.contains(Intent.CATEGORY_LAUNCHER) == true

    /**
     * Whether the shell may start this intent for us. The shell sees the intent only as text, so it
     * must survive being written as an `intent:` URI: only plain extras, no clip, no permission
     * grants (the shell does not hold A's URI permissions), and nothing aimed at A's own screens.
     */
    fun shellCanStart(context: Context, i: Intent): Boolean {
        if (i.clipData != null) return false
        val grants = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        if (i.flags and grants != 0) return false
        val scheme = i.data?.scheme
        // A folder shortcut is often a file: address; the shell can open that one (it is not A's to grant).
        if (scheme == "content") return false
        val target = i.component?.packageName ?: i.`package`
        if (target == context.packageName) return false
        val extras = i.extras ?: return true
        @Suppress("DEPRECATION")
        return extras.keySet().all { k ->
            when (extras.get(k)) {
                is String, is Boolean, is Byte, is Char, is Double, is Float, is Int, is Long, is Short -> true
                else -> false
            }
        }
    }

    /** Returns true when a start was attempted; failures of the shell route fall back to a normal start. */
    fun start(context: Context, intent: Intent): Boolean {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        lastFailure = null
        lastHealed = null
        if (!isAppLaunch(intent) && (intent.component?.packageName ?: intent.`package`) != context.packageName) {
            DiagLog.note("shortcut run: ${describe(context, intent)}; shizuku=${ShizukuShell.isReady()}")
        }
        if ((isAppLaunch(intent) || shellCanStart(context, intent)) && ShizukuShell.isReady()) {
            val uri = runCatching { intent.toUri(Intent.URI_INTENT_SCHEME) }.getOrNull()
            if (uri != null) {
                val cmd = "am start '" + uri.replace("'", "'\\''") + "'"
                Thread {
                    var out = ""
                    val code = runCatching { ShizukuShell.run(cmd) { out += it + "\n" } }.getOrDefault(-1)
                    DiagLog.note("am start exit=$code out=${out.trim().take(200)}")
                    if (code != 0 || out.contains("Error", ignoreCase = true)) main.post { plain(context, intent) }
                }.start()
                return true
            }
        }
        return plain(context, intent)
    }

    /**
     * Why Android will refuse this intent for any app that is not its owner, or null when it may
     * work. Decided from the target's own manifest, so it needs no Shizuku and is the same on every
     * phone. A target that cannot be looked up is not judged: it is simply tried.
     */
    fun closedReason(context: Context, i: Intent): String? {
        val cn = i.component ?: return null
        val ai = runCatching { context.packageManager.getActivityInfo(cn, 0) }.getOrNull() ?: return null
        if (ai.applicationInfo.uid == Process.myUid()) return null
        if (!ai.exported) return "not exported"
        val perm = ai.permission
        if (perm != null && context.checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) return "needs the permission $perm"
        return null
    }

    /** Opens the app the intent belongs to by its launcher icon, which every app allows. */
    private fun openOwnerApp(context: Context, intent: Intent): Boolean {
        val pkg = intent.component?.packageName ?: intent.`package` ?: return false
        val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            (OverlayRuntime.accessibilityService ?: context).startActivity(launch); true
        } catch (_: Exception) { false }
    }

    private val stamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)

    /** What is true right now about the app and screen an intent aims at, in one line for the report. */
    fun describe(context: Context, i: Intent): String {
        val cn = i.component
        val pkg = cn?.packageName ?: i.`package` ?: "(no package)"
        val pm = context.packageManager
        val info = runCatching { pm.getPackageInfo(pkg, 0) }.getOrNull()
        val ver = if (info == null) "app not installed or not visible"
        else "v${info.versionName} updated ${stamp.format(java.util.Date(info.lastUpdateTime))}"
        val screen = when {
            cn == null -> "no screen named"
            else -> {
                val ai = runCatching { pm.getActivityInfo(cn, 0) }.getOrNull()
                when {
                    ai == null -> "its screen is NOT in the installed app"
                    ai.exported -> "screen is open to other apps"
                    else -> "screen is CLOSED to other apps"
                }
            }
        }
        val grants = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        val temp = if (i.data?.scheme == "content" || i.flags and grants != 0 || i.clipData != null)
            "; USES a content address or permission grant that may not survive an update of A" else ""
        return "$pkg $ver; $screen$temp; ${runCatching { i.toUri(0) }.getOrDefault("?").take(220)}"
    }

    /** True when the app is installed but the screen the intent names no longer exists in it. */
    private fun componentMissing(context: Context, i: Intent): Boolean {
        val cn = i.component ?: return false
        val pm = context.packageManager
        if (runCatching { pm.getActivityInfo(cn, 0) }.isSuccess) return false
        return runCatching { pm.getPackageInfo(cn.packageName, 0) }.isSuccess
    }

    @Suppress("DEPRECATION")
    private fun sig(i: Intent): String {
        val ex = i.extras
        val e = if (ex == null) "" else ex.keySet().sorted().joinToString(",") { k -> "$k=${ex.get(k)}" }
        return "${i.action}|${i.dataString}|$e"
    }

    /**
     * A shortcut saved in A is a frozen copy of the other app's intent; a launcher's shortcut is
     * kept current by that app. When the app is updated and moves or closes the screen, the copy
     * goes stale (re-adding it made a fresh copy). This finds the current form without asking the
     * person: first the same shortcut in the app's present manifest (same action, data and extras,
     * on whatever screen carries it now), then the same action with no screen named, so Android
     * picks the app's current one. Returns null when neither exists.
     */
    private fun healed(context: Context, intent: Intent): Intent? {
        val pkg = intent.component?.packageName ?: intent.`package` ?: return null
        val want = sig(intent)
        val now = runCatching {
            a.a.ui.screens.strip.loadStaticShortcuts(context, pkg)
                .mapNotNull { runCatching { Intent.parseUri(it.intentUri, Intent.URI_INTENT_SCHEME) }.getOrNull() }
                .firstOrNull { sig(it) == want && it.component != intent.component && closedReason(context, it) == null }
        }.getOrNull()
        if (now != null) return now.addFlags(intent.flags or Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.component != null && intent.action != null) {
            val loose = Intent(intent).setComponent(null).setPackage(pkg)
            if (context.packageManager.resolveActivity(loose, 0) != null) return loose
        }
        return null
    }

    /** One start from the best context; null when it worked, else what went wrong. */
    private fun attempt(svc: Context, context: Context, i: Intent): Exception? = try {
        relaxedFileUri { svc.startActivity(i) }; null
    } catch (first: Exception) {
        try { relaxedFileUri { context.startActivity(i) }; null } catch (e: Exception) { e }
    }

    /**
     * Android refuses to hand a file: address to another app (FileUriExposedException) unless the app
     * switches that check off. A folder shortcut made by a file manager is exactly such an address; the
     * app it goes to opens it with its own storage access. The check is switched off only for this one
     * start and put back straight after.
     */
    private fun <T> relaxedFileUri(block: () -> T): T {
        val old = runCatching { android.os.StrictMode.getVmPolicy() }.getOrNull()
        runCatching { android.os.StrictMode.setVmPolicy(android.os.StrictMode.VmPolicy.Builder().build()) }
        return try { block() } finally { if (old != null) runCatching { android.os.StrictMode.setVmPolicy(old) } }
    }

    /** The same shortcut with permission to read its address handed on, for a folder or file the owner app keeps private. */
    private fun withGrant(i: Intent): Intent? {
        val scheme = i.data?.scheme ?: return null
        if (scheme != "content") return null
        val g = Intent.FLAG_GRANT_READ_URI_PERMISSION
        if (i.flags and g != 0) return null
        return Intent(i).addFlags(g)
    }

    private fun plain(context: Context, intent: Intent): Boolean {
        // From a screen of A that is showing, Android always allows the start; otherwise from the
        // accessibility service (A's windows count as visible), then A itself.
        val svc: Context = if (context is Activity) context else OverlayRuntime.accessibilityService ?: context
        val gone = componentMissing(context, intent)
        val closed = if (gone) null else closedReason(context, intent)
        var error: Exception? = null
        if (!gone && closed == null) {
            error = attempt(svc, context, intent)
            if (error == null) return true
        }
        // A folder or file address that the owner app keeps private: hand over the right to read it.
        if (!gone && closed == null) withGrant(intent)?.let { granted ->
            if (attempt(svc, context, granted) == null) {
                DiagLog.persist(context, "shortcut opened after handing on read permission: ${describe(context, granted)}")
                return true
            }
        }
        // The saved copy no longer fits the installed app: use its current form.
        healed(context, intent)?.let { fix ->
            if (attempt(svc, context, fix) == null) {
                lastHealed = fix
                DiagLog.persist(context, "shortcut healed (the app changed it): now ${runCatching { fix.toUri(0) }.getOrDefault("?").take(200)}")
                return true
            }
        }
        DiagLog.persist(
            context,
            "shortcut FAILED (${if (gone) "screen gone after an update" else closed ?: error?.javaClass?.simpleName}): ${describe(context, intent)}"
        )
        if (gone) {
            lastFailure = "The app was updated and this shortcut no longer exists in it. Pick the shortcut again."
            return false
        }
        if (closed != null) {
            // Only the app itself (or the shell) may start a screen it keeps closed; open the app instead of nothing.
            val opened = openOwnerApp(context, intent)
            lastFailure = "That app keeps this shortcut closed to other apps. " +
                (if (opened) "Its app was opened instead. " else "") + "Shizuku opens it directly."
            return false
        }
        lastFailure = when (error) {
            is SecurityException -> "That app does not let other apps open this shortcut. Shizuku opens it directly."
            is android.content.ActivityNotFoundException -> "The app or screen of this shortcut is not installed. Pick the shortcut again."
            else -> null
        }
        return false
    }
}
