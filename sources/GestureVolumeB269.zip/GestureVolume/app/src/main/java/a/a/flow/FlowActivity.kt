package a.a.flow

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.strip.ActionSaver
import a.a.auto.AutomationsScreen
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.AppShortcutsPage
import a.a.ui.screens.strip.plainAppLabel

/** The flow list and the step editor. Nothing from here stays in memory once it is closed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
class FlowActivity : ComponentActivity() {
    /** Goes up each time this screen comes back, so OCR boxes drawn in the OCR flow show up in the list. */
    private var resumeTick by mutableStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var names by remember { mutableStateOf(FlowStore.names(this)) }
                    var open by remember { mutableStateOf<String?>(intent.getStringExtra("flow")?.takeIf { it in names }) }
                    var newName by remember { mutableStateOf(false) }
                    var info by remember { mutableStateOf("") }
                    // Selecting flows: delete, duplicate, share many at once; rename one.
                    var selected by remember { mutableStateOf(setOf<String>()) }
                    var confirmDel by remember { mutableStateOf(false) }
                    var renameOf by remember { mutableStateOf<String?>(null) }
                    // OCR boxes (made on the screen, kept by name) are listed here beside the flows.
                    var ocrOnly by remember { mutableStateOf(false) }
                    var ocrDlg by remember { mutableStateOf<String?>(null) }
                    var ocrRename by remember { mutableStateOf<String?>(null) }
                    var boxTick by remember { mutableStateOf(0) }
                    val sharedPicker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            val got = FlowShare.import(this@FlowActivity, uri)
                            names = FlowStore.names(this@FlowActivity)
                            info = if (got == null) "That file is not a shared flows file." else "Imported ${got.size} flow(s): " + got.joinToString(", ")
                        }
                    }
                    var runningNow by remember { mutableStateOf(FlowRunner.running()) }
                    var values by remember { mutableStateOf(false) }
                    var autos by remember { mutableStateOf(false) }
                    // "Add a shortcut": 0 closed, 1 menu, 2 open an app with Hail, 3 app shortcuts / Shortcut Maker.
                    var addSc by remember { mutableStateOf(0) }
                    val scCreator = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
                    ) { result ->
                        val data = result.data
                        @Suppress("DEPRECATION")
                        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
                        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
                            val nm = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME) ?: "Shortcut"
                            ActionSaver.saveToScripts(this@FlowActivity, nm, "Intent:" + picked.toUri(android.content.Intent.URI_INTENT_SCHEME))
                            names = FlowStore.names(this@FlowActivity); info = "Saved script: $nm"; addSc = 0
                        }
                    }
                    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            info = "Importing…"
                            Thread {
                                info = try {
                                    val n = AutomateImporter.import(this@FlowActivity, uri)
                                    names = FlowStore.names(this@FlowActivity)
                                    "Imported $n flows. Texts that are not commands are kept as Notes."
                                } catch (e: Throwable) { "Import failed: ${e.message}" }
                            }.start()
                        }
                    }
                    if (autos) {
                        AutomationsScreen { autos = false }
                    } else if (values) {
                        ValuesScreen { values = false }
                    } else if (open == null) {
                        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Flows (${names.size})", fontSize = 20.sp)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { newName = true }) { Text("New flow") }
                                Button(onClick = { addSc = 1 }) { Text("Add a shortcut") }
                                OutlinedButton(onClick = {
                                    val next = (FlowPrefs.mode(this@FlowActivity) + 1) % 3
                                    FlowPrefs.setMode(this@FlowActivity, next)
                                    info = "Message bar after a cell: " + FlowPrefs.modeName(next)
                                }) { Text("Message bar: " + FlowPrefs.modeName(FlowPrefs.mode(this@FlowActivity))) }
                                OutlinedButton(onClick = {
                                    info = "Adding…"
                                    Thread {
                                        info = try {
                                            val n = AutomateFlows.install(this@FlowActivity)
                                            names = FlowStore.names(this@FlowActivity)
                                            "Added $n converted Automate flows (named Automate: …). Numbers and codes are left as {blanks} in the steps."
                                        } catch (e: Throwable) { "Could not add: ${e.message}" }
                                    }.start()
                                }) { Text("Add my Automate flows") }
                                OutlinedButton(onClick = {
                                    val n = SeedFlows.installExamples(this@FlowActivity)
                                    names = FlowStore.names(this@FlowActivity)
                                    info = if (n > 0) "Added $n example script(s): Example: …  Open one to edit its blocks." else "The example scripts are already here."
                                }) { Text("Add example scripts") }
                                OutlinedButton(onClick = { autos = true }) { Text("Automations") }
                                OutlinedButton(onClick = {
                                    runCatching { startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                                }) { Text("Allow usage access") }
                                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import Automate backup") }
                                OutlinedButton(onClick = { sharedPicker.launch(arrayOf("*/*")) }) { Text("Import shared flows") }
                            }
                            if (info.isNotEmpty()) Text(info, fontSize = 12.sp)
                            // Which scripts run right now: asked once a second, only while this window is open.
                            androidx.compose.runtime.LaunchedEffect(Unit) {
                                while (true) { runningNow = FlowRunner.running(); kotlinx.coroutines.delay(1000) }
                            }
                            Button(enabled = runningNow.isNotEmpty(), onClick = {
                                FlowRunner.stopAllRuns(); runningNow = FlowRunner.running(); info = "Stopping all running scripts…"
                            }) { Text("Stop all running scripts" + if (runningNow.isNotEmpty()) " (${runningNow.size})" else "") }
                            var query by remember { mutableStateOf("") }
                            var showParts by remember { mutableStateOf(false) }
                            OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search flows") }, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(onClick = { showParts = !showParts }) { Text(if (showParts) "Hiding nothing" else "Parts of flows are hidden - show") }
                            val shown = if (ocrOnly) emptyList() else
                                names.filter { (showParts || !AutomateFlows.isPart(it)) && (query.isBlank() || it.contains(query, true)) }
                                    .sortedByDescending { n -> runningNow.any { it.name == n } }
                            val boxes = remember(boxTick, resumeTick, query) {
                                a.a.strip.ScreenOcr.boxNames(this@FlowActivity).filter { query.isBlank() || it.contains(query, true) || "ocr".contains(query, true) }
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { ocrOnly = !ocrOnly }) { Text(if (ocrOnly) "Showing OCR boxes only - show all" else "Show OCR boxes only") }
                                Button(onClick = {
                                    startActivity(android.content.Intent(this@FlowActivity, a.a.strip.OcrActivity::class.java).putExtra("boxnew", true))
                                }) { Text("New OCR box") }
                            }
                            // The bar of what can be done with the ticked flows.
                            if (selected.isNotEmpty()) {
                                Text("${selected.size} selected", fontSize = 14.sp)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { selected = shown.toSet() }) { Text("All") }
                                    OutlinedButton(onClick = { selected = emptySet() }) { Text("None") }
                                    Button(onClick = {
                                        var n = 0
                                        selected.forEach { if (FlowStore.duplicate(this@FlowActivity, it) != null) n++ }
                                        names = FlowStore.names(this@FlowActivity); selected = emptySet(); info = "Duplicated $n flow(s)."
                                    }) { Text("Duplicate") }
                                    Button(onClick = { FlowShare.share(this@FlowActivity, selected.toList()) }) { Text("Share") }
                                    if (selected.size == 1) OutlinedButton(onClick = { renameOf = selected.first() }) { Text("Rename") }
                                    OutlinedButton(onClick = { confirmDel = true }) { Text("Delete") }
                                }
                            } else Text("Tap a flow to open it. Press and hold to select flows.", fontSize = 12.sp)
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemsIndexed(boxes) { _, bn ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable { ocrDlg = bn }.padding(vertical = 10.dp),
                                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                    ) {
                                        Text("OCR box: $bn", Modifier.weight(1f))
                                    }
                                }
                                itemsIndexed(shown) { _, n ->
                                    val on = n in selected
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .combinedClickable(
                                                onClick = { if (selected.isNotEmpty()) selected = if (on) selected - n else selected + n else open = n },
                                                onLongClick = { selected = if (on) selected - n else selected + n },
                                            )
                                            .padding(vertical = 10.dp),
                                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                    ) {
                                        if (selected.isNotEmpty()) androidx.compose.material3.Checkbox(checked = on, onCheckedChange = { selected = if (on) selected - n else selected + n })
                                        Text(n, Modifier.weight(1f))
                                        val runs = runningNow.filter { it.name == n }
                                        if (runs.isNotEmpty()) {
                                            Text(if (runs.any { it.alwaysOn }) "Always On, running" else "running", fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
                                            OutlinedButton(onClick = { FlowRunner.stopByName(n); runningNow = FlowRunner.running() }) { Text("Stop") }
                                        }
                                    }
                                }
                            }
                        }
                        if (confirmDel) AlertDialog(
                            onDismissRequest = { confirmDel = false },
                            title = { Text("Delete ${selected.size} flow(s)?") },
                            text = { Text(selected.sorted().joinToString(", ") + "\n\nCells that run them will do nothing until you pick another flow.") },
                            confirmButton = { TextButton(onClick = {
                                FlowStore.deleteMany(this@FlowActivity, selected)
                                names = FlowStore.names(this@FlowActivity); info = "Deleted ${selected.size} flow(s)."; selected = emptySet(); confirmDel = false
                            }) { Text("Delete") } },
                            dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Cancel") } },
                        )
                        renameOf?.let { old ->
                            var t by remember(old) { mutableStateOf(old) }
                            AlertDialog(
                                onDismissRequest = { renameOf = null },
                                title = { Text("Rename flow") },
                                text = {
                                    Column {
                                        OutlinedTextField(t, { t = it }, singleLine = true)
                                        Text("Cells and flows that run it keep working.", fontSize = 12.sp)
                                    }
                                },
                                confirmButton = { TextButton(onClick = {
                                    val ok = FlowStore.rename(this@FlowActivity, old, t)
                                    names = FlowStore.names(this@FlowActivity)
                                    info = if (ok) "Renamed to ${t.trim()}." else "Not renamed: the name is empty or already used."
                                    if (ok) selected = emptySet()
                                    renameOf = null
                                }) { Text("OK") } },
                                dismissButton = { TextButton(onClick = { renameOf = null }) { Text("Cancel") } },
                            )
                        }
                        ocrDlg?.let { bn ->
                            AlertDialog(
                                onDismissRequest = { ocrDlg = null },
                                title = { Text("OCR box: $bn") },
                                text = {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("A part of the screen that the OCR shortcut and the \"Read with OCR and wait\" block read by this name.", fontSize = 12.sp)
                                        TextButton(onClick = {
                                            startActivity(
                                                android.content.Intent(this@FlowActivity, a.a.strip.OcrActivity::class.java)
                                                    .putExtra("boxredo", bn)
                                            )
                                            ocrDlg = null
                                        }) { Text("Draw it again on the screen") }
                                        TextButton(onClick = { ocrRename = bn; ocrDlg = null }) { Text("Rename") }
                                        TextButton(onClick = {
                                            a.a.strip.ScreenOcr.deleteBox(this@FlowActivity, bn)
                                            boxTick++; info = "Deleted OCR box $bn."; ocrDlg = null
                                        }) { Text("Delete") }
                                    }
                                },
                                confirmButton = { TextButton(onClick = { ocrDlg = null }) { Text("Close") } },
                            )
                        }
                        ocrRename?.let { old ->
                            var t by remember(old) { mutableStateOf(old) }
                            AlertDialog(
                                onDismissRequest = { ocrRename = null },
                                title = { Text("Rename OCR box") },
                                text = {
                                    Column {
                                        OutlinedTextField(t, { t = it }, singleLine = true)
                                        Text("Shortcuts and flows that still say the old name keep finding this box.", fontSize = 12.sp)
                                    }
                                },
                                confirmButton = { TextButton(onClick = {
                                    val ok = a.a.strip.ScreenOcr.renameBox(this@FlowActivity, old, t)
                                    boxTick++
                                    info = if (ok) "Renamed to ${t.trim()}." else "Not renamed: the name is empty or already used."
                                    ocrRename = null
                                }) { Text("OK") } },
                                dismissButton = { TextButton(onClick = { ocrRename = null }) { Text("Cancel") } },
                            )
                        }
                        if (addSc != 0) androidx.compose.ui.window.Dialog(
                            onDismissRequest = { addSc = if (addSc == 1) 0 else 1 },
                            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                        ) {
                            Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                                fun saveSc(name: String, action: String) {
                                    ActionSaver.saveToScripts(this@FlowActivity, name, action)
                                    names = FlowStore.names(this@FlowActivity); info = "Saved script: $name"; addSc = 0
                                }
                                when (addSc) {
                                    2 -> AppList(
                                        onPick = { app -> saveSc(plainAppLabel(app.label), ActionSaver.hailAction(app.packageName)) },
                                        onBack = { addSc = 1 },
                                        everything = true,
                                        kindFilter = true,
                                    )
                                    3 -> AppShortcutsPage(
                                        onCreator = { cr ->
                                            runCatching {
                                                scCreator.launch(
                                                    android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT).setClassName(cr.packageName, cr.className)
                                                )
                                            }
                                        },
                                        onShortcut = { sc -> saveSc(sc.label, "Intent:" + sc.intentUri) },
                                        onBack = { addSc = 1 },
                                    )
                                    else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Add a shortcut as a script", fontSize = 18.sp)
                                        Button(onClick = { addSc = 2 }) { Text("Open an app with Hail (any app, even hidden)") }
                                        Button(onClick = { addSc = 3 }) { Text("App shortcuts and Shortcut Maker") }
                                        TextButton(onClick = { addSc = 0 }) { Text("Cancel") }
                                    }
                                }
                            }
                        }
                        if (newName) {
                            var t by remember { mutableStateOf("") }
                            AlertDialog(
                                onDismissRequest = { newName = false },
                                title = { Text("Flow name") },
                                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                                confirmButton = { TextButton(onClick = {
                                    if (t.isNotBlank()) { val nm = FlowStore.freeName(this, t); FlowStore.save(this, nm, emptyList()); names = FlowStore.names(this); open = nm }
                                    newName = false
                                }) { Text("OK") } },
                            )
                        }
                    } else {
                        CanvasEditor(this, open!!) { names = FlowStore.names(this); open = null }
                    }
                }
            }
        }
    }

    @Composable
    private fun ValuesScreen(close: () -> Unit) {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("My values", fontSize = 20.sp)
            Text(
                "Keys, codes and names that flows use as {name}. They stay only on this phone: they are not in the settings backup and not in copies of the app.",
                fontSize = 12.sp,
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(PrivateValues.allSlots(this@FlowActivity)) { _, slot ->
                    var v by remember { mutableStateOf(PrivateValues.get(this@FlowActivity, slot.name)) }
                    OutlinedTextField(
                        v, { v = it; PrivateValues.set(this@FlowActivity, slot.name, it) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(slot.label + "   {" + slot.name + "}") },
                        supportingText = { if (slot.hint.isNotEmpty()) Text(slot.hint) },
                    )
                }
            }
            Button(onClick = close) { Text("Done") }
        }
    }
}
