package a.a.ui.components

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.motion.TextButton

/**
 * What the user did to each card of every window: folded it (its rows are hidden, the heading stays) or archived it
 * (it leaves the window and waits in that window's "Archived" card). Kept in its own small preferences file, by the
 * window's title and the card's title, so it survives restarts and never touches the app's real settings.
 *
 * Nothing here changes a setting: a folded or archived card keeps every value it had.
 */
object CardState {
    private const val FILE = "card_state"
    private const val COLLAPSED = "collapsed"
    private const val ARCHIVED = "archived"
    private const val SEP = '\u001F'

    /** Read by the cards while they draw, so they redraw the moment something here changes. */
    var version by mutableIntStateOf(0)
        private set

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private fun set(c: Context, name: String): Set<String> = sp(c).getStringSet(name, emptySet()) ?: emptySet()

    fun key(window: String, title: String) = window + SEP + title
    fun titleOf(key: String) = key.substringAfter(SEP)

    fun isCollapsed(c: Context, key: String): Boolean { version; return key in set(c, COLLAPSED) }
    fun isArchived(c: Context, key: String): Boolean { version; return key in set(c, ARCHIVED) }

    fun setCollapsed(c: Context, key: String, on: Boolean) = change(c, COLLAPSED, key, on)
    fun setArchived(c: Context, key: String, on: Boolean) {
        change(c, ARCHIVED, key, on)
        // A card that comes back is open again.
        if (!on) change(c, COLLAPSED, key, false)
    }

    private fun change(c: Context, name: String, key: String, on: Boolean) {
        val now = HashSet(set(c, name))
        if (if (on) now.add(key) else now.remove(key)) {
            sp(c).edit().putStringSet(name, now).apply()
            version++
        }
    }

    /** The archived cards of one window, by card title. */
    fun archivedIn(c: Context, window: String): List<String> {
        version
        val prefix = window + SEP
        return set(c, ARCHIVED).filter { it.startsWith(prefix) }.map { titleOf(it) }.sorted()
    }
}

/** The title of the window the cards are in: part of every card's key. Set by [AWindowPage]. */
val LocalCardWindow = compositionLocalOf { "" }

/** The small arrow that folds or opens a card, in the card's heading line. */
@Composable
fun CardFoldArrow(collapsed: Boolean, onClick: () -> Unit) {
    Text(
        if (collapsed) "▾" else "▴", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 2.dp),
    )
}

/** The small archive icon next to the arrow: sends the card to the window's Archived card. */
@Composable
fun CardArchiveIcon(onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Archive, contentDescription = "Archive", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
    }
}

/**
 * The "Archived" card: a row that shows how many cards were archived in this window and, opened, each of them with a
 * button to bring it back. It is only drawn while at least one card is archived, and [ArchivePullHost] only shows it
 * after the window was pulled down past its top, like the archive of a chat list.
 */
@Composable
fun ArchivedCard(window: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val titles = CardState.archivedIn(context, window)
    if (titles.isEmpty()) return
    var open by remember { mutableStateOf(false) }
    val colours = MaterialTheme.colorScheme
    Column(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(rowColor())) {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconTile(Icons.Filled.Archive, lit = open, size = 40.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Archived", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = colours.onSurface)
                    Text(
                        "${titles.size} card" + (if (titles.size == 1) "" else "s") + " put away in this window",
                        style = MaterialTheme.typography.bodySmall, color = colours.onSurfaceVariant,
                    )
                }
                CardFoldArrow(collapsed = !open, onClick = { open = !open })
            }
            if (open) titles.forEach { t ->
                Row(
                    Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(t, Modifier.weight(1f), fontSize = 14.sp, color = colours.onSurface)
                    TextButton(onClick = { CardState.setArchived(context, CardState.key(window, t), false) }) {
                        Icon(Icons.Filled.Unarchive, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Restore")
                    }
                }
            }
            Spacer(Modifier.size(4.dp))
        }
    }
}

/**
 * Puts [content] under the window's top bar and lets the user pull the window down, once it is at its top, to show the
 * Archived card above it (when something is archived). Scrolling the window back down puts it away again.
 * [pad] is the padding the window's scaffold gave; the top is used here, the rest goes to [content].
 */
@Composable
fun ArchivePullHost(window: String, pad: PaddingValues, content: @Composable (PaddingValues) -> Unit) {
    val context = LocalContext.current
    var shown by remember { mutableStateOf(false) }
    val pullPx = with(LocalDensity.current) { 72.dp.toPx() }
    val hidePx = with(LocalDensity.current) { 40.dp.toPx() }
    val connection = remember(pullPx, hidePx) {
        object : NestedScrollConnection {
            var pulled = 0f
            var pushed = 0f
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < 0f) {
                    pulled = 0f
                    if (shown) { pushed -= available.y; if (pushed > hidePx) { shown = false; pushed = 0f } }
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Still pulling down after the content has no more room to move: the window is at its top.
                if (source == NestedScrollSource.UserInput && available.y > 0f && consumed.y == 0f) {
                    pulled += available.y
                    if (pulled > pullPx) { shown = true; pulled = 0f }
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: androidx.compose.ui.unit.Velocity, available: androidx.compose.ui.unit.Velocity): androidx.compose.ui.unit.Velocity {
                pulled = 0f; pushed = 0f
                return androidx.compose.ui.unit.Velocity.Zero
            }
        }
    }
    CompositionLocalProvider(LocalCardWindow provides window) {
        Column(Modifier.fillMaxSize().padding(top = pad.calculateTopPadding()).nestedScroll(connection)) {
            val any = CardState.archivedIn(context, window).isNotEmpty()
            AnimatedVisibility(
                visible = shown && any,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) { ArchivedCard(window) }
            Box(Modifier.weight(1f, fill = true)) {
                content(PaddingValues(bottom = pad.calculateBottomPadding()))
            }
        }
    }
}

/**
 * Wraps a card that is not built with CardGroup (a card with its own layout, like "Field strip size") so it can be folded
 * and archived like every other: a heading line with the fold arrow and the archive icon, and [content] under it. While it
 * is archived nothing is drawn; while it is folded only the heading is.
 */
@Composable
fun FoldableCard(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val key = CardState.key(LocalCardWindow.current, title)
    if (CardState.isArchived(context, key)) return
    val folded = CardState.isCollapsed(context, key)
    Column(modifier.fillMaxWidth()) {
        GroupHeading(
            title,
            trailing = {
                CardFoldArrow(folded) { CardState.setCollapsed(context, key, !folded) }
                CardArchiveIcon { CardState.setArchived(context, key, true) }
            },
        )
        if (!folded) content()
    }
}
