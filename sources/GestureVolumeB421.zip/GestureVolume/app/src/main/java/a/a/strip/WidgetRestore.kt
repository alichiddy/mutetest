package a.a.strip

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** One widget of a backup that still has to be added again on this phone. */
data class PendingWidget(
    val oldId: Int,
    val provider: ComponentName,
    val label: String,
    /** Everything the floating settings hold (size, position, bar side, opacity, close rules...), as FloatCfg's JSON. */
    val cfg: String,
    val previewH: Int,
    val order: Int,
)

/**
 * A full backup of the widgets: which widget each one is (its provider, not the phone's own number for it),
 * how it acts when it floats (every field of [FloatCfg]: the last position the user left it at, the bar on top
 * or at the bottom, opacity, lock, auto close...), and the preview height in the widget window.
 *
 * Android gives every added widget a number that only exists on this phone, so a restore cannot put the old
 * number back. Instead each widget is bound again from its provider. When Android lets A do that quietly the
 * widget is back at once; when it needs a tap (the "Allow A to add this widget" question, or the widget's own
 * setup screen) it waits in the Widgets window under "Widgets from your backup" and keeps its saved settings.
 * Cells and tiles that pointed at the old number are pointed at the new one.
 */
object WidgetRestore {
    private const val PENDING = "pending"

    fun backupOf(c: Context): JSONArray {
        val out = JSONArray()
        val mgr = AppWidgetManager.getInstance(c)
        val wp = WidgetKit.prefs(c)
        val ids = wp.getString("ids", "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }
        ids.forEachIndexed { order, id ->
            val info = mgr.getAppWidgetInfo(id) ?: return@forEachIndexed
            out.put(
                JSONObject()
                    .put("oldId", id).put("order", order)
                    .put("provider", info.provider.flattenToString())
                    .put("label", labelOf(c, info.provider))
                    .put("cfg", wp.getString("fl$id", null).orEmpty())
                    .put("h", wp.getInt("h$id", -1)),
            )
        }
        // Widgets that were waiting from an earlier restore are part of the backup too: nothing is lost by backing up twice.
        for (p in pending(c)) {
            if (ids.contains(p.oldId)) continue
            out.put(
                JSONObject()
                    .put("oldId", p.oldId).put("order", p.order).put("provider", p.provider.flattenToString())
                    .put("label", p.label).put("cfg", p.cfg).put("h", p.previewH),
            )
        }
        return out
    }

    private fun labelOf(c: Context, provider: ComponentName): String = runCatching {
        val pm = c.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(provider.packageName, 0)).toString()
    }.getOrDefault(provider.packageName)

    private fun installed(c: Context, pkg: String): Boolean =
        runCatching { c.packageManager.getApplicationInfo(pkg, 0); true }.getOrDefault(false)

    fun pending(c: Context): List<PendingWidget> = runCatching {
        val a = JSONArray(WidgetKit.prefs(c).getString(PENDING, "[]") ?: "[]")
        (0 until a.length()).mapNotNull { fromJson(a.optJSONObject(it)) }
    }.getOrDefault(emptyList())

    private fun fromJson(o: JSONObject?): PendingWidget? {
        o ?: return null
        val cn = ComponentName.unflattenFromString(o.optString("provider")) ?: return null
        return PendingWidget(o.optInt("oldId", -1), cn, o.optString("label", cn.packageName), o.optString("cfg"), o.optInt("h", -1), o.optInt("order", 0))
    }

    private fun savePending(c: Context, list: List<JSONObject>) {
        val a = JSONArray()
        list.forEach { a.put(it) }
        WidgetKit.prefs(c).edit().putString(PENDING, a.toString()).apply()
    }

    private fun toJson(p: PendingWidget) = JSONObject()
        .put("oldId", p.oldId).put("order", p.order).put("provider", p.provider.flattenToString())
        .put("label", p.label).put("cfg", p.cfg).put("h", p.previewH)

    /** Takes one widget off the waiting list (it was added, or the user does not want it). */
    fun dropPending(c: Context, oldId: Int) {
        savePending(c, pending(c).filter { it.oldId != oldId }.map { toJson(it) })
    }

    /** Writes a widget's saved floating settings and preview height to the id it has on this phone. */
    fun applySettings(c: Context, newId: Int, p: PendingWidget) {
        val e = WidgetKit.prefs(c).edit()
        if (p.cfg.isNotBlank()) e.putString("fl$newId", p.cfg)
        if (p.previewH > 0) e.putInt("h$newId", p.previewH)
        e.apply()
    }

    /**
     * Brings back the widgets of a backup. Same phone and the widget is still there: its settings are put back.
     * Otherwise it is bound again when Android allows that without asking; the rest wait in [pending].
     */
    fun restore(c: Context, json: String) {
        val arr = runCatching { JSONObject(json).optJSONArray("widgets") }.getOrNull() ?: return
        if (arr.length() == 0) return
        val mgr = AppWidgetManager.getInstance(c)
        val host = WidgetKit.host(c)
        val alive = WidgetKit.savedIds(c).toMutableList()
        val waiting = LinkedHashMap<Int, JSONObject>()
        pending(c).forEach { waiting[it.oldId] = toJson(it) }
        val remap = HashMap<Int, Int>()
        val entries = (0 until arr.length()).mapNotNull { fromJson(arr.optJSONObject(it)) }.sortedBy { it.order }
        for (p in entries) {
            val here = alive.firstOrNull { it == p.oldId && mgr.getAppWidgetInfo(it)?.provider == p.provider }
            if (here != null) {
                applySettings(c, here, p); waiting.remove(p.oldId); continue
            }
            if (!installed(c, p.provider.packageName)) { waiting[p.oldId] = toJson(p); continue }
            val nid = runCatching { host.allocateAppWidgetId() }.getOrNull()
            if (nid == null) { waiting[p.oldId] = toJson(p); continue }
            val bound = runCatching { mgr.bindAppWidgetIdIfAllowed(nid, p.provider) }.getOrDefault(false)
            val needsSetup = bound && mgr.getAppWidgetInfo(nid)?.configure != null
            if (bound && !needsSetup) {
                alive += nid
                applySettings(c, nid, p)
                remap[p.oldId] = nid
                waiting.remove(p.oldId)
            } else {
                runCatching { host.deleteAppWidgetId(nid) }
                waiting[p.oldId] = toJson(p)
            }
        }
        WidgetKit.saveIds(c, alive)
        savePending(c, waiting.values.toList())
        for ((old, new) in remap) repoint(c, old, new)
    }

    // ---- cells and tiles that name a widget by its number ----

    private fun swap(action: String, old: Int, new: Int): String? {
        val i = WidgetTiles.parse(action) ?: return null
        if (i.component?.className?.endsWith("Activity") != true) return null
        if (i.component?.className?.contains("Widget") != true) return null
        if (i.getIntExtra("wid", -1) != old) return null
        return "Intent:" + i.putExtra("wid", new).toUri(Intent.URI_INTENT_SCHEME)
    }

    private fun mapAll(items: List<StripItem>, old: Int, new: Int, hit: BooleanArray): List<StripItem> = items.map { x ->
        val a = swap(x.action, old, new)
        var m = x
        if (a != null) { hit[0] = true; m = m.copy(action = a) }
        val ch = m.children
        if (ch != null) m = m.copy(children = mapAll(ch, old, new, hit))
        m
    }

    /** Every cell and saved tile that pointed at widget [old] now points at [new]. */
    fun repoint(c: Context, old: Int, new: Int) {
        if (old == new) return
        for (rec in WidgetTiles.load(c)) {
            val a = swap(rec.action, old, new) ?: continue
            WidgetTiles.update(c, rec.copy(wid = new, action = a))
        }
        val windows = listOf(StripScope.MAIN) + StripScope.ownWindowIds(c).map { it.first }
        for (w in windows) {
            val cfg = StripScope.load(c, w)
            val hit = BooleanArray(1)
            val items = mapAll(cfg.items, old, new, hit)
            if (hit[0]) StripScope.save(c, w, cfg.copy(items = items))
        }
    }
}
