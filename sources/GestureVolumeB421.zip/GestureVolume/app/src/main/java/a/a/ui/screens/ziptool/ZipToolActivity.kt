package a.a.ui.screens.ziptool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import a.a.ui.screens.shell.ShellActivity

/**
 * Zip/Patch Tools and Terminal are now tabs of the Shell runner window. This activity is only a forwarder:
 * whatever still opens the old Zip tools window by its extras lands on the right tab of the Shell runner window,
 * and this one closes at once.
 */
class ZipToolActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val key = intent?.getStringExtra(EXTRA_MODE)
        val out = Intent(this, ShellActivity::class.java)
        if (key == "terminal") {
            out.putExtra(ShellActivity.EXTRA_TAB, ShellActivity.TAB_TERMINAL)
        } else {
            val tick = when (key) {
                "one" -> intent?.getStringExtra(EXTRA_TICK)
                "replace", "patch" -> "replace"
                "rename" -> "rename"
                "extract" -> "extract"
                "folder" -> "asis"
                "merge" -> "compare"
                else -> null
            }
            out.putExtra(ShellActivity.EXTRA_TAB, ShellActivity.TAB_ZIP)
            if (tick != null) out.putExtra(ShellActivity.EXTRA_TICK, tick)
        }
        startActivity(out)
        finish()
    }

    companion object {
        /** "terminal" opens the Terminal tab. "one" opens Zip/Patch Tools (with EXTRA_TICK ticked). The old keys replace, patch, rename, extract, folder and merge tick the matching action. */
        const val EXTRA_MODE = "zipToolMode"

        /** With EXTRA_MODE "one": the action to tick (replace, rename, asis, delete, compare or extract). */
        const val EXTRA_TICK = "zipToolTick"
    }
}
