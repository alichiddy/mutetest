package a.a.ui.screens.strip

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage
import a.a.ui.motion.Button

/**
 * One text box in a card, in a full-screen window with the back arrow (back = Cancel), like the other Cell Settings
 * windows. The window keeps its own copy of the text; [onUse] gets it when the button is pressed, and the caller
 * decides what to do with it (and closes the window).
 */
@Composable
internal fun TextEntryDialog(
    title: String,
    group: String,
    hint: String?,
    rowTitle: String,
    rowSummary: String?,
    icon: ImageVector,
    initial: String,
    button: String,
    onUse: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AWindowPage(title, onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup(group, hint = hint, foldable = false) {
                        row { sh ->
                            SettingRow(
                                rowTitle, sh, icon = icon, summary = rowSummary,
                                footer = {
                                    OutlinedTextField(
                                        value = text, onValueChange = { text = it },
                                        modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                                    )
                                },
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { onUse(text) }, modifier = Modifier.fillMaxWidth()) { Text(button) }
                }
            }
        }
    }
}

/** "Edit raw" of a cell's shortcut: the text the shortcut is saved as. */
@Composable
internal fun RawActionDialog(initial: String, onUse: (String) -> Unit, onDismiss: () -> Unit) {
    TextEntryDialog(
        title = "Edit the raw action",
        group = "The saved text",
        hint = "This is exactly how the shortcut is saved. Change it only if you know what the text means.",
        rowTitle = "Raw action",
        rowSummary = "Empty means Nothing.",
        icon = Icons.Filled.Edit,
        initial = initial,
        button = "Use",
        onUse = onUse,
        onDismiss = onDismiss,
    )
}

/** "Shell command" of a cell's shortcut. */
@Composable
internal fun ShellCommandDialog(initial: String, onUse: (String) -> Unit, onDismiss: () -> Unit) {
    TextEntryDialog(
        title = "Shell command",
        group = "Command",
        hint = "Runs with Shizuku when it is allowed.",
        rowTitle = "What to run",
        rowSummary = null,
        icon = Icons.Filled.Terminal,
        initial = initial,
        button = "Use",
        onUse = onUse,
        onDismiss = onDismiss,
    )
}
