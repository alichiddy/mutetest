package a.a.ui.screens.strip

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.ChoiceChip
import a.a.ui.components.FoldableCard
import a.a.ui.components.RepeatingIconButton
import kotlin.math.roundToInt

private const val BAR_MIN = 16
private const val BAR_MAX = 120
private const val BAR_START = 40
private const val BAR_STEP = 4

// A step this soon after the one before it is the button being held, not a new tap.
private const val HOLD_MS = 600L

/**
 * The size of the field strips drawn around the cells window in the editor: 0 is Auto, otherwise [BAR_MIN] to
 * [BAR_MAX] dp. A bar, - and + buttons (a press steps once, holding keeps stepping) and an Auto button.
 * A fresh tap on + at the top goes to Auto; while held it stops at the top. Same for - at the bottom.
 */
@Composable
internal fun EdgeBarSizeRow(value: Int, onChange: (Int) -> Unit) {
    val colours = MaterialTheme.colorScheme
    // The newest value, kept here so a held button keeps stepping from what it set a moment ago.
    val cur = remember { IntArray(1) }
    cur[0] = value
    val last = remember { LongArray(1) }
    fun step(dir: Int) {
        val t = android.os.SystemClock.uptimeMillis()
        val held = t - last[0] < HOLD_MS
        last[0] = t
        val v = cur[0]
        val n = if (v == 0) {
            BAR_START
        } else if (dir > 0) {
            if (v >= BAR_MAX) (if (held) BAR_MAX else 0) else (v + BAR_STEP).coerceAtMost(BAR_MAX)
        } else {
            if (v <= BAR_MIN) (if (held) BAR_MIN else 0) else (v - BAR_STEP).coerceAtLeast(BAR_MIN)
        }
        cur[0] = n
        onChange(n)
    }
    // The card can be folded and archived like every other card; its heading is the card's title.
    FoldableCard("Field strip size") {
    SettingRow(
        "Thickness", RoundedCornerShape(16.dp), Modifier.padding(vertical = 2.dp), compact = true,
        info = "Auto shows the cells window at its true size: the same size as when it slides in, with the strips taking " +
            "the room left around it. With a size you choose, the strips keep that thickness, so when the picture gets " +
            "too wide for the screen everything shrinks together and the cells window is no longer at its true size. " +
            "Only a strip of each field is drawn here; on screen the fields go on to the edge. Hold - or + to keep " +
            "stepping; + past 120 dp (or - below 16 dp) goes to Auto, or press Auto.",
        trailing = {
            RepeatingIconButton(
                onClick = { step(-1) }, contentDescription = "Smaller strips",
                tint = colours.primary, modifier = Modifier.size(36.dp),
            ) { Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp)) }
            Text(
                if (value > 0) "$value dp" else "Auto", Modifier.width(64.dp), textAlign = TextAlign.Center,
                fontSize = 14.sp, fontWeight = FontWeight.Medium, color = colours.primary,
            )
            RepeatingIconButton(
                onClick = { step(1) }, contentDescription = "Bigger strips",
                tint = colours.primary, modifier = Modifier.size(36.dp),
            ) { Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp)) }
        },
        footer = {
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Slider(
                    value = (if (value > 0) value else BAR_START).toFloat(),
                    onValueChange = { onChange(it.roundToInt().coerceIn(BAR_MIN, BAR_MAX)) },
                    valueRange = BAR_MIN.toFloat()..BAR_MAX.toFloat(),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                ChoiceChip("Auto", value == 0, onClick = { onChange(0) })
            }
        },
    )
    }
}
