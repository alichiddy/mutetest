package a.a.strip

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.animation.ValueAnimator
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * The floating notes and the floating gallery. Each is one overlay window that exists only while it
 * is open: closing it drops every view, picture and thread, so nothing stays in memory.
 */
object FloatTools {
    private val open = HashMap<String, ToolWindow>()

    fun isOpen(kind: String) = open.containsKey(kind)

    fun passThrough(on: Boolean) { open.values.toList().forEach { it.passThrough(on) } }

    /** The tools open now (a copy). */
    fun openKinds(): Set<String> = open.keys.toSet()

    fun close(kind: String) {
        open[kind]?.close()
    }

    /** Opens the tool, or closes it when it is already open. */
    fun toggle(ctx: Context, kind: String): Boolean {
        val app = ctx.applicationContext
        val existing = open[kind]
        if (existing != null) {
            if (existing.isMinimized()) existing.restore() else existing.close()
            return true
        }
        if (!FloatHost.allowed(app)) return false
        if (kind == "gallery" && !canReadPhotos(app)) {
            WidgetFloat.toast(app, "Give A access to photos (or All files access), then try again")
            val pkgUri = Uri.parse("package:" + app.packageName)
            val allFiles = Build.VERSION.SDK_INT >= 30 &&
                runCatching { a.a.utils.AppStarter.start(ctx, Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri)) }.getOrDefault(false)
            if (!allFiles) {
                runCatching { a.a.utils.AppStarter.start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)) }
            }
            return false
        }
        val w: ToolWindow = if (kind == "notes") NotesWindow(app) { open.remove(kind) } else GalleryWindow(app) { open.remove(kind) }
        if (!w.show()) {
            WidgetFloat.toast(app, "It could not be shown")
            return false
        }
        open[kind] = w
        return true
    }

    fun closeAll() {
        open.values.toList().forEach { it.close() }
    }

    private fun canReadPhotos(app: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true
        val perm = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_IMAGES" else "android.permission.READ_EXTERNAL_STORAGE"
        return app.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

/** A draggable, resizable window with a title bar, the content of the tool, and a corner handle. */
abstract class ToolWindow(protected val app: Context, private val kind: String, private val onClosed: () -> Unit) {
    protected val host = FloatHost.resolve(app)
    protected val wm = host.wm
    protected val d = app.resources.displayMetrics.density
    protected val handler = Handler(Looper.getMainLooper())
    protected val prefs = app.getSharedPreferences("float_tools", Context.MODE_PRIVATE)
    protected var root: LinearLayout? = null
    protected var lp: WindowManager.LayoutParams? = null
    protected var bar: LinearLayout? = null
    protected var foot: LinearLayout? = null
    protected var titleView: TextView? = null
    protected var closed = false
    private var bubble: FloatBubble? = null
    private var mini = false

    protected fun dp(v: Int) = (v * d).toInt()

    fun isMinimized() = mini

    /** Hides the window and leaves a bubble: drag it anywhere, tap it to bring the window back as it was. */
    fun minimize() {
        val r = root ?: return
        val p = lp ?: return
        if (mini || closed) return
        val b = FloatBubble(app, kind, kind.take(1), host) { restore() }
        if (!b.show()) return
        bubble = b
        mini = true
        // Not touchable and no keyboard while hidden; typing is switched on again by tapping in the text.
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        r.visibility = View.GONE
        update()
    }

    /** No touches while the click circle is moving; touchable again after (unless tucked away). */
    fun passThrough(on: Boolean) {
        val p = lp ?: return
        if (root == null) return
        if (on) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else if (!mini) p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        update()
    }

    fun restore() {
        val r = root ?: return
        val p = lp ?: return
        if (!mini) return
        mini = false
        bubble?.hide()
        bubble = null
        p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        if (WidgetFloat.throughNow) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        r.visibility = View.VISIBLE
        update()
    }

    protected abstract val defaultW: Int
    protected abstract val defaultH: Int
    protected abstract fun title(): String
    protected abstract fun content(): View
    protected open fun barButtons(): List<TextView> = emptyList()
    protected open fun footButtons(): List<TextView> = emptyList()
    protected open fun onBarTouched() {}
    protected open fun onClose() {}

    protected fun button(label: String, onClick: () -> Unit): TextView {
        val t = TextView(app)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.minWidth = dp(34)
        t.setPadding(dp(4), 0, dp(4), 0)
        t.setOnClickListener { onClick() }
        return t
    }

    fun show(): Boolean {
        val dm = app.resources.displayMetrics
        val w = prefs.getInt(kind + "_w", dp(defaultW)).coerceIn(dp(160), dm.widthPixels)
        val h = prefs.getInt(kind + "_h", dp(defaultH)).coerceIn(dp(120), dm.heightPixels)
        val r = LinearLayout(app)
        r.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xF2202124.toInt())
        bg.cornerRadius = dp(12).toFloat()
        r.background = bg
        r.clipToOutline = true

        val b = LinearLayout(app)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.setBackgroundColor(0x33FFFFFF)
        val tv = TextView(app)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.textSize = 13f
        tv.setPadding(dp(10), 0, dp(4), 0)
        tv.maxLines = 1
        titleView = tv
        tv.text = title()
        b.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        for (x in barButtons()) b.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.addView(button("–") { minimize() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.addView(button("✕") { close() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bar = b
        r.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        r.addView(content(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val f = LinearLayout(app)
        f.orientation = LinearLayout.HORIZONTAL
        f.gravity = Gravity.CENTER_VERTICAL
        for (x in footButtons()) f.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Opacity bar: drag left to see through the window (20% to 100%), remembered for next time.
        val alphaNow = prefs.getInt(kind + "_alpha", 100).coerceIn(20, 100)
        val sb = SeekBar(app)
        sb.max = 80
        sb.progress = alphaNow - 20
        sb.setPadding(dp(10), 0, dp(10), 0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                lp?.alpha = (v + 20) / 100f
                update()
            }
            override fun onStartTrackingTouch(s: SeekBar?) { onBarTouched() }
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt(kind + "_alpha", (s?.progress ?: 80) + 20).apply()
            }
        })
        f.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val grip = TextView(app)
        grip.text = "◢"
        grip.setTextColor(0xAAFFFFFF.toInt())
        grip.gravity = Gravity.CENTER
        f.addView(grip, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))
        foot = f
        r.addView(f, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)))

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val p = WindowManager.LayoutParams(w, h, host.type, flags, PixelFormat.TRANSLUCENT)
        if (WidgetFloat.throughNow) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt(kind + "_x", (dm.widthPixels - w) / 2).coerceIn(0, maxOf(0, dm.widthPixels - w))
        p.y = prefs.getInt(kind + "_y", dp(90)).coerceIn(0, maxOf(0, dm.heightPixels - h))
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        p.alpha = alphaNow / 100f
        lp = p
        root = r

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    onBarTouched()
                    sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (ev.rawX - sx)).toInt().coerceIn(0, maxOf(0, dm.widthPixels - p.width))
                    p.y = (oy + (ev.rawY - sy)).toInt().coerceIn(0, maxOf(0, dm.heightPixels - p.height))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        var gw = 0
        var gh = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; gw = p.width; gh = p.height }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (gw + (ev.rawX - sx)).toInt().coerceIn(dp(160), maxOf(dp(160), dm.widthPixels - p.x))
                    p.height = (gh + (ev.rawY - sy)).toInt().coerceIn(dp(120), maxOf(dp(120), dm.heightPixels - p.y))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        return runCatching { wm.addView(r, p) }.onFailure { a.a.utils.DiagLog.e("float tool $kind addView", it) }.isSuccess
    }

    protected fun update() {
        val r = root ?: return
        val p = lp ?: return
        runCatching { wm.updateViewLayout(r, p) }
    }

    private fun remember() {
        val p = lp ?: return
        prefs.edit().putInt(kind + "_x", p.x).putInt(kind + "_y", p.y).putInt(kind + "_w", p.width).putInt(kind + "_h", p.height).apply()
    }

    /** Lets the keyboard type into this window (on), or hands the screen back to the app underneath (off). */
    protected fun setTyping(on: Boolean) {
        val p = lp ?: return
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        update()
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching { onClose() }
        remember()
        bubble?.hide()
        bubble = null
        root?.let { v -> runCatching { wm.removeView(v) } }
        root = null
        onClosed()
    }
}

class NotesWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "notes", onClosed) {
    override val defaultW = 290
    override val defaultH = 300

    private val notes = ArrayList<String>()
    private var idx = 0
    private var size = 16f
    private var edit: EditText? = null
    private var sure = false
    private var delBtn: TextView? = null
    private val saveRun = Runnable { save() }

    /** The list of all notes with a box on each, to share, copy, export or delete several at once. */
    private var listPanel: FrameLayout? = null
    private var listRows: LinearLayout? = null
    private var listDel: TextView? = null
    private var listDelArmed = false
    private val ticked = HashSet<Int>()

    init {
        runCatching {
            val a = JSONArray(prefs.getString("notes_list", "[]"))
            for (n in 0 until a.length()) notes.add(a.getString(n))
        }
        if (notes.isEmpty()) notes.add("")
        idx = prefs.getInt("notes_idx", 0).coerceIn(0, notes.size - 1)
        size = prefs.getFloat("notes_size", 16f)
    }

    override fun title() = "Note ${idx + 1} of ${notes.size}"

    private fun save() {
        val a = JSONArray()
        for (t in notes) a.put(t)
        prefs.edit().putString("notes_list", a.toString()).putInt("notes_idx", idx).putFloat("notes_size", size).apply()
    }

    private fun showNote() {
        edit?.setText(notes[idx])
        edit?.setSelection(edit?.text?.length ?: 0)
        titleView?.text = title()
        sure = false
        delBtn?.setTextColor(0xFFFFFFFF.toInt())
    }

    private fun keep() {
        notes[idx] = edit?.text?.toString().orEmpty()
    }

    private fun typingOff() {
        hideLinkBar()
        val e = edit ?: return
        e.clearFocus()
        (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(e.windowToken, 0)
        setTyping(false)
    }

    override fun onBarTouched() = typingOff()

    override fun content(): View {
        val e = EditText(app)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setHintTextColor(0x88FFFFFF.toInt())
        e.hint = "Type a note"
        e.textSize = size
        e.gravity = Gravity.TOP or Gravity.START
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        e.background = null
        e.setPadding(dp(10), dp(8), dp(10), dp(8))
        e.setText(notes[idx])
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                notes[idx] = s?.toString().orEmpty()
                handler.removeCallbacks(saveRun)
                handler.postDelayed(saveRun, 500)
            }
        })
        // A finger going down used to switch the window to "typing" (a new window layout) every time, even to scroll,
        // which is what made scrolling jerky. Now only a real tap, or a long press (to select text), does that.
        val tap = GestureDetector(app, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(ev: MotionEvent): Boolean {
                val off = e.getOffsetForPosition(ev.x, ev.y)
                val link = linkAt(e.text, off)
                setTyping(true)
                e.postDelayed({
                    e.requestFocus()
                    (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(e, 0)
                    if (link != null) e.setSelection(link.first, link.last + 1)
                }, 150)
                if (link != null) showLinkBar(e.text.substring(link.first, link.last + 1)) else hideLinkBar()
                return false
            }

            override fun onLongPress(ev: MotionEvent) { setTyping(true) }
        })
        e.setOnTouchListener { _, ev -> tap.onTouchEvent(ev); false }
        // Selecting text adds the tools of a notes app to the usual Cut / Copy / Paste: open a link, call, e-mail, share, search.
        e.customSelectionActionModeCallback = object : android.view.ActionMode.Callback {
            override fun onCreateActionMode(mode: android.view.ActionMode, menu: android.view.Menu): Boolean {
                val t = selectedText()
                if (firstLink(t) != null) menu.add(0, MENU_OPEN, 0, "Open link")
                if (android.util.Patterns.EMAIL_ADDRESS.matcher(t.trim()).matches()) menu.add(0, MENU_MAIL, 0, "Send e-mail")
                if (android.util.Patterns.PHONE.matcher(t.trim()).matches() && t.count { it.isDigit() } >= 5) menu.add(0, MENU_CALL, 0, "Call")
                if (t.isNotBlank()) {
                    menu.add(0, MENU_SHARE, 1, "Share")
                    menu.add(0, MENU_SEARCH, 2, "Search the web")
                }
                return true
            }

            override fun onPrepareActionMode(mode: android.view.ActionMode, menu: android.view.Menu) = false

            override fun onActionItemClicked(mode: android.view.ActionMode, item: android.view.MenuItem): Boolean {
                val t = selectedText()
                val ok = when (item.itemId) {
                    MENU_OPEN -> firstLink(t)?.let { openLink(it) } ?: false
                    MENU_MAIL -> openUri("mailto:" + t.trim())
                    MENU_CALL -> openUri("tel:" + t.trim().filter { it.isDigit() || it == '+' })
                    MENU_SHARE -> FloatActions.shareText(app, t)
                    MENU_SEARCH -> openUri("https://www.google.com/search?q=" + Uri.encode(t.trim()))
                    else -> return false
                }
                if (!ok) WidgetFloat.toast(app, "Could not open it")
                mode.finish()
                return true
            }

            override fun onDestroyActionMode(mode: android.view.ActionMode) {}
        }
        // The text scrolls inside a ScrollView (it flings and glides) instead of the EditText's own stiff scrolling.
        e.isVerticalScrollBarEnabled = false
        e.setHorizontallyScrolling(false)
        edit = e

        val frame = FrameLayout(app)
        val glide = ScrollView(app)
        glide.isFillViewport = true
        glide.isVerticalScrollBarEnabled = true
        glide.overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        glide.addView(e, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        frame.addView(glide, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // What a tap on a web address offers: open it, copy it, share it.
        val lb = LinearLayout(app)
        lb.orientation = LinearLayout.HORIZONTAL
        lb.gravity = Gravity.CENTER_VERTICAL
        lb.setBackgroundColor(0xF21B3A57.toInt())
        lb.visibility = View.GONE
        fun lbButton(label: String, onClick: () -> Unit): TextView = button(label, onClick).also { it.textSize = 13f; it.setPadding(dp(12), 0, dp(12), 0) }
        lb.addView(lbButton("Open") { if (!openLink(linkText)) WidgetFloat.toast(app, "Could not open it"); hideLinkBar() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        lb.addView(lbButton("Copy") { FloatActions.copy(app, linkText, "Link copied"); hideLinkBar() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        lb.addView(lbButton("Share") { FloatActions.shareText(app, linkText); hideLinkBar() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        lb.addView(lbButton("✕") { hideLinkBar() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)))
        linkBar = lb
        frame.addView(lb, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38), Gravity.BOTTOM))

        val lp0 = FrameLayout(app)
        lp0.setBackgroundColor(0xF2202124.toInt())
        lp0.visibility = View.GONE
        lp0.setOnTouchListener { _, _ -> true }
        val col = LinearLayout(app)
        col.orientation = LinearLayout.VERTICAL
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(0xFF1B3A57.toInt())
        val tb = LinearLayout(app)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.gravity = Gravity.CENTER_VERTICAL
        fun nb(label: String, onClick: () -> Unit): TextView = button(label, onClick).also { it.textSize = 12f; it.setPadding(dp(8), 0, dp(8), 0) }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        tb.addView(nb("◀ Note") { closeList() }, LinearLayout.LayoutParams(wrap, dp(34)))
        tb.addView(nb("All") { ticked.clear(); for (n in notes.indices) ticked.add(n); fillList() }, LinearLayout.LayoutParams(wrap, dp(34)))
        tb.addView(nb("None") { ticked.clear(); fillList() }, LinearLayout.LayoutParams(wrap, dp(34)))
        tb.addView(nb("Share") { if (ticked.isNotEmpty()) FloatActions.shareText(app, joined()) }, LinearLayout.LayoutParams(wrap, dp(34)))
        tb.addView(nb("Copy") { if (ticked.isNotEmpty()) FloatActions.copy(app, joined(), "Copied") }, LinearLayout.LayoutParams(wrap, dp(34)))
        tb.addView(nb(".txt") { exportTicked() }, LinearLayout.LayoutParams(wrap, dp(34)))
        val ld = nb("Delete") { deleteTicked() }
        listDel = ld
        tb.addView(ld, LinearLayout.LayoutParams(wrap, dp(34)))
        hs.addView(tb)
        col.addView(hs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
        val sv = ScrollView(app)
        val rows = LinearLayout(app)
        rows.orientation = LinearLayout.VERTICAL
        listRows = rows
        sv.addView(rows, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        lp0.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        listPanel = lp0
        frame.addView(lp0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return frame
    }

    // ---- links and the selection's tools -----------------------------------------------------------

    private companion object {
        const val MENU_OPEN = 9101
        const val MENU_MAIL = 9102
        const val MENU_CALL = 9103
        const val MENU_SHARE = 9104
        const val MENU_SEARCH = 9105
    }

    private var linkBar: LinearLayout? = null
    private var linkText = ""

    private fun showLinkBar(url: String) { linkText = url; linkBar?.visibility = View.VISIBLE }
    private fun hideLinkBar() { linkBar?.visibility = View.GONE }

    private fun selectedText(): String {
        val e = edit ?: return ""
        val a = e.selectionStart; val b = e.selectionEnd
        val t = e.text?.toString().orEmpty()
        return if (a >= 0 && b >= 0 && a != b) t.substring(minOf(a, b).coerceIn(0, t.length), maxOf(a, b).coerceIn(0, t.length)) else ""
    }

    /** The web address that covers character [off] of [text], as the range of its characters, or null. */
    private fun linkAt(text: CharSequence, off: Int): IntRange? {
        val m = android.util.Patterns.WEB_URL.matcher(text)
        while (m.find()) if (off >= m.start() && off <= m.end()) return m.start() until m.end()
        return null
    }

    private fun firstLink(t: String): String? {
        val m = android.util.Patterns.WEB_URL.matcher(t)
        return if (m.find()) m.group() else null
    }

    private fun openUri(uri: String): Boolean =
        runCatching { a.a.utils.AppStarter.start(app, Intent(Intent.ACTION_VIEW, Uri.parse(uri))) }.getOrDefault(false)

    private fun openLink(raw: String): Boolean {
        val u = raw.trim()
        if (u.isEmpty()) return false
        return openUri(if (u.contains("://") || u.startsWith("mailto:")) u else "https://$u")
    }

    // ---- the text to act on ----------------------------------------------------------------------

    /** The selected text of the open note, or the whole note when nothing is selected. */
    private fun selectionOrAll(): String {
        val e = edit ?: return notes[idx]
        val a = e.selectionStart; val b = e.selectionEnd
        val t = e.text?.toString().orEmpty()
        return if (a >= 0 && b >= 0 && a != b) t.substring(minOf(a, b).coerceIn(0, t.length), maxOf(a, b).coerceIn(0, t.length)) else t
    }

    private fun shareNow() {
        val t = selectionOrAll()
        if (t.isBlank()) { WidgetFloat.toast(app, "The note is empty"); return }
        if (!FloatActions.shareText(app, t)) WidgetFloat.toast(app, "Could not open the share list")
    }

    private fun copyNow() {
        val t = selectionOrAll()
        if (t.isBlank()) { WidgetFloat.toast(app, "The note is empty"); return }
        val part = (edit?.selectionStart ?: -1) != (edit?.selectionEnd ?: -1)
        FloatActions.copy(app, t, if (part) "Selected text copied" else "Note copied")
    }

    // ---- several notes at once -----------------------------------------------------------------

    private fun joined(): String =
        ticked.sorted().joinToString("\n\n-----\n\n") { notes[it] }

    private fun openList() {
        keep()
        ticked.clear()
        listDelArmed = false
        listDel?.setTextColor(0xFFFFFFFF.toInt())
        listDel?.text = "Delete"
        typingOff()
        fillList()
        listPanel?.visibility = View.VISIBLE
    }

    private fun closeList() {
        listPanel?.visibility = View.GONE
        listRows?.removeAllViews()
        showNote()
    }

    private fun fillList() {
        val rows = listRows ?: return
        rows.removeAllViews()
        for (n in notes.indices) {
            val r = LinearLayout(app)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val box = TextView(app)
            box.text = if (n in ticked) "☑" else "☐"
            box.setTextColor(0xFFFFFFFF.toInt())
            box.textSize = 20f
            box.gravity = Gravity.CENTER
            box.setOnClickListener { if (!ticked.remove(n)) ticked.add(n); listDelArmed = false; listDel?.text = "Delete"; listDel?.setTextColor(0xFFFFFFFF.toInt()); fillList() }
            r.addView(box, LinearLayout.LayoutParams(dp(44), dp(44)))
            val t = TextView(app)
            val first = notes[n].lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
            t.text = "${n + 1}. " + first.ifEmpty { "(empty)" }
            t.setTextColor(if (n == idx) 0xFF80D8FF.toInt() else 0xFFFFFFFF.toInt())
            t.textSize = 13f
            t.maxLines = 2
            t.ellipsize = android.text.TextUtils.TruncateAt.END
            // Tap the words to open that note.
            t.setOnClickListener { keep(); idx = n; save(); closeList() }
            r.addView(t, LinearLayout.LayoutParams(0, dp(44), 1f))
            rows.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun deleteTicked() {
        if (ticked.isEmpty()) return
        if (!listDelArmed) {
            listDelArmed = true
            listDel?.setTextColor(0xFFFF6666.toInt())
            listDel?.text = "Sure? (${ticked.size})"
            handler.postDelayed({ if (listDelArmed) { listDelArmed = false; listDel?.setTextColor(0xFFFFFFFF.toInt()); listDel?.text = "Delete" } }, 2500)
            return
        }
        listDelArmed = false
        val remove = ticked.sortedDescending()
        val before = remove.count { it < idx }
        val openGone = idx in remove
        for (n in remove) notes.removeAt(n)
        if (notes.isEmpty()) notes.add("")
        idx = (if (openGone) idx - before else idx - before).coerceIn(0, notes.size - 1)
        ticked.clear()
        listDel?.setTextColor(0xFFFFFFFF.toInt())
        listDel?.text = "Delete"
        save()
        fillList()
    }

    private fun exportTicked() {
        if (ticked.isEmpty()) { WidgetFloat.toast(app, "Tick the notes first"); return }
        val one = ticked.size == 1
        val name = if (one) "Note ${ticked.first() + 1}" else "Notes (${ticked.size})"
        val saved = FloatActions.saveTxt(app, name, joined())
        WidgetFloat.toast(app, if (saved != null) "Saved in Downloads: $saved" else "Could not save the file")
    }

    override fun barButtons(): List<TextView> {
        val del = button("🗑") {
            if (!sure) {
                sure = true
                delBtn?.setTextColor(0xFFFF6666.toInt())
                handler.postDelayed({ sure = false; delBtn?.setTextColor(0xFFFFFFFF.toInt()) }, 2500)
            } else {
                if (notes.size > 1) { notes.removeAt(idx); idx = idx.coerceAtMost(notes.size - 1) } else notes[0] = ""
                showNote(); save()
            }
        }
        delBtn = del
        return listOf(
            button("◀") { if (idx > 0) { keep(); idx--; showNote(); save() } },
            button("▶") { if (idx < notes.size - 1) { keep(); idx++; showNote(); save() } },
            button("＋") { keep(); notes.add(idx + 1, ""); idx++; showNote(); save() },
            del,
            button("✓") { typingOff() },
        )
    }

    override fun footButtons(): List<TextView> = listOf(
        button("A−") { size = (size - 2f).coerceAtLeast(10f); edit?.textSize = size; save() },
        button("A＋") { size = (size + 2f).coerceAtMost(40f); edit?.textSize = size; save() },
        button("☰") { openList() },
        button("↗") { shareNow() },
        button("⧉") { copyNow() },
    )

    override fun onClose() {
        handler.removeCallbacks(saveRun)
        typingOff()
        keep()
        save()
        listRows?.removeAllViews()
        ticked.clear()
    }
}

class GalleryWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "gallery", onClosed) {
    override val defaultW = 320
    override val defaultH = 440

    private var ids = LongArray(0)
    private var grid: GridView? = null
    private var viewer: FrameLayout? = null
    private var big: ImageView? = null
    private var counter: TextView? = null
    private var pos = 0
    private var pool: ExecutorService? = null
    private val thumbs = LruCache<Long, Bitmap>(60)
    private var sc = 1f
    private var tx = 0f
    private var ty = 0f
    private var anim: ValueAnimator? = null

    /** The photos ticked in selection mode (long press starts it), in the order they were ticked. */
    private val sel = LinkedHashSet<Long>()
    private var selBar: HorizontalScrollView? = null
    private var selCount: TextView? = null
    private var delBtn: TextView? = null
    private var delArmed = false
    private var infoPanel: FrameLayout? = null
    private var infoText: TextView? = null

    override fun title() = "Gallery"

    private fun uri(id: Long): Uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())

    private fun loadList() {
        pool?.execute {
            val out = ArrayList<Long>()
            runCatching {
                app.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    null, null, MediaStore.Images.Media.DATE_ADDED + " DESC",
                )?.use { c ->
                    while (c.moveToNext() && out.size < 300) out.add(c.getLong(0))
                }
            }
            handler.post {
                if (closed) return@post
                ids = out.toLongArray()
                (grid?.adapter as? BaseAdapter)?.notifyDataSetChanged()
                titleView?.text = if (ids.isEmpty()) "Gallery (no photos found)" else "Gallery"
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun thumb(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 29) app.contentResolver.loadThumbnail(uri(id), Size(240, 240), null)
        else MediaStore.Images.Thumbnails.getThumbnail(app.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
    }.getOrNull()

    private fun full(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(app.contentResolver, uri(id))) { dec, info, _ ->
                val m = maxOf(info.size.width, info.size.height)
                if (m > 1600) dec.setTargetSampleSize(m / 1600 + 1)
            }
        } else {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o) }
            val m = maxOf(o.outWidth, o.outHeight)
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = if (m > 1600) m / 1600 + 1 else 1
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o2) }
        }
    }.getOrNull()

    private fun applyZoom() {
        val v = big ?: return
        v.scaleX = sc; v.scaleY = sc; v.translationX = tx; v.translationY = ty
    }

    /** Keeps the picture from being dragged away from the window. */
    private fun clampPan() {
        val w = viewer?.width ?: return
        val h = viewer?.height ?: return
        val mx = (sc - 1f) * w / 2f
        val my = (sc - 1f) * h / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
    }

    /** Zooms to [target] while the picture point under (fx, fy) stays under the fingers. */
    private fun zoomAbout(fx: Float, fy: Float, target: Float) {
        val v = viewer ?: return
        val cx = v.width / 2f
        val cy = v.height / 2f
        val s1 = sc
        val s2 = target.coerceIn(1f, 6f)
        tx = fx - cx - (fx - cx - tx) * s2 / s1
        ty = fy - cy - (fy - cy - ty) * s2 / s1
        sc = s2
        if (sc <= 1.001f) { sc = 1f; tx = 0f; ty = 0f }
        clampPan()
        applyZoom()
    }

    /** Double tap: zoom in on the tapped spot, or back out when already zoomed. */
    private fun doubleTapZoom(fx: Float, fy: Float) {
        val v = viewer ?: return
        anim?.cancel()
        val s0 = sc; val x0 = tx; val y0 = ty
        val s1: Float; val x1: Float; val y1: Float
        if (sc > 1.05f) {
            s1 = 1f; x1 = 0f; y1 = 0f
        } else {
            s1 = 2.5f
            val mx = (s1 - 1f) * v.width / 2f
            val my = (s1 - 1f) * v.height / 2f
            x1 = (-(fx - v.width / 2f) * (s1 - 1f)).coerceIn(-mx, mx)
            y1 = (-(fy - v.height / 2f) * (s1 - 1f)).coerceIn(-my, my)
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 200
        a.addUpdateListener {
            val t = it.animatedValue as Float
            sc = s0 + (s1 - s0) * t
            tx = x0 + (x1 - x0) * t
            ty = y0 + (y1 - y0) * t
            applyZoom()
        }
        anim = a
        a.start()
    }

    private fun openAt(n: Int) {
        if (ids.isEmpty()) return
        anim?.cancel()
        pos = (n + ids.size) % ids.size
        sc = 1f; tx = 0f; ty = 0f
        applyZoom()
        big?.setImageDrawable(null)
        counter?.text = "${pos + 1} / ${ids.size}"
        viewer?.visibility = View.VISIBLE
        val id = ids[pos]
        val want = pos
        pool?.execute {
            val b = full(id)
            handler.post { if (!closed && pos == want) big?.setImageBitmap(b) }
        }
    }

    private fun backToGrid() {
        viewer?.visibility = View.GONE
        big?.setImageDrawable(null)
    }

    override fun content(): View {
        pool = Executors.newFixedThreadPool(2)
        val frame = FrameLayout(app)

        val g = GridView(app)
        g.numColumns = GridView.AUTO_FIT
        g.columnWidth = dp(92)
        g.horizontalSpacing = dp(2)
        g.verticalSpacing = dp(2)
        g.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        g.adapter = object : BaseAdapter() {
            override fun getCount() = ids.size
            override fun getItem(p: Int) = ids[p]
            override fun getItemId(p: Int) = ids[p]
            override fun getView(p: Int, old: View?, parent: ViewGroup?): View {
                val cell = (old as? FrameLayout) ?: FrameLayout(app).also { f ->
                    f.layoutParams = AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, dp(92))
                    f.setBackgroundColor(0x22FFFFFF)
                    val pic = ImageView(app)
                    pic.scaleType = ImageView.ScaleType.CENTER_CROP
                    f.addView(pic, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    val tick = TextView(app)
                    tick.text = "✓"
                    tick.setTextColor(0xFFFFFFFF.toInt())
                    tick.textSize = 14f
                    tick.gravity = Gravity.CENTER
                    val dot = GradientDrawable()
                    dot.shape = GradientDrawable.OVAL
                    dot.setColor(0xFF1E88E5.toInt())
                    tick.background = dot
                    val tl = FrameLayout.LayoutParams(dp(22), dp(22))
                    tl.gravity = Gravity.TOP or Gravity.END
                    tl.setMargins(0, dp(3), dp(3), 0)
                    f.addView(tick, tl)
                }
                val iv = cell.getChildAt(0) as ImageView
                val tick = cell.getChildAt(1)
                val id = ids[p]
                cell.tag = id
                val on = id in sel
                tick.visibility = if (on) View.VISIBLE else View.GONE
                iv.alpha = if (on) 0.55f else 1f
                val cached = thumbs.get(id)
                if (cached != null) {
                    iv.setImageBitmap(cached)
                } else {
                    iv.setImageDrawable(null)
                    pool?.execute {
                        val b = thumb(id)
                        if (b != null) handler.post {
                            if (!closed) { thumbs.put(id, b); if (cell.tag == id) iv.setImageBitmap(b) }
                        }
                    }
                }
                return cell
            }
        }
        g.setOnItemClickListener { _, _, p, _ -> if (sel.isNotEmpty()) toggle(ids[p]) else openAt(p) }
        // Long press starts the selection (that photo is ticked first); then a tap ticks or unticks more.
        g.setOnItemLongClickListener { _, _, p, _ -> toggle(ids[p]); true }
        grid = g
        frame.addView(g, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val vw = FrameLayout(app)
        vw.setBackgroundColor(0xFF000000.toInt())
        vw.visibility = View.GONE
        val iv = ImageView(app)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        big = iv
        // The touches are read on the fixed frame, not on the picture that is being scaled and moved.
        // (Reading them on the picture itself made the coordinates shift while zooming: that was the jump.)
        val sgd = ScaleGestureDetector(
            app,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(det: ScaleGestureDetector): Boolean {
                    zoomAbout(det.focusX, det.focusY, sc * det.scaleFactor)
                    return true
                }
            },
        )
        sgd.isQuickScaleEnabled = false
        val gd = GestureDetector(
            app,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent): Boolean = true
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    doubleTapZoom(e.x, e.y)
                    return true
                }
            },
        )
        var lcx = 0f
        var lcy = 0f
        fun centre(ev: MotionEvent, skip: Int) {
            var sx = 0f; var sy = 0f; var n = 0
            for (i in 0 until ev.pointerCount) {
                if (i == skip) continue
                sx += ev.getX(i); sy += ev.getY(i); n++
            }
            if (n > 0) { lcx = sx / n; lcy = sy / n }
        }
        vw.setOnTouchListener { _, ev ->
            // A running zoom animation stops first. (Stopping it after the detectors ran cancelled the
            // animation that the double tap had just started, so a double tap never zoomed.)
            if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN) anim?.cancel()
            gd.onTouchEvent(ev)
            sgd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_UP -> centre(ev, ev.actionIndex)
                MotionEvent.ACTION_MOVE -> {
                    val ox = lcx; val oy = lcy
                    centre(ev, -1)
                    if (sc > 1f) {
                        tx += lcx - ox; ty += lcy - oy
                        clampPan()
                        applyZoom()
                    }
                }
            }
            true
        }
        vw.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val ctl = LinearLayout(app)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        ctl.setBackgroundColor(0x88000000.toInt())
        val cnt = TextView(app)
        cnt.setTextColor(0xFFFFFFFF.toInt())
        cnt.textSize = 12f
        cnt.gravity = Gravity.CENTER
        counter = cnt
        ctl.addView(button("◀") { openAt(pos - 1) }, LinearLayout.LayoutParams(0, dp(34), 1f))
        ctl.addView(button("▦") { backToGrid() }, LinearLayout.LayoutParams(0, dp(34), 1f))
        ctl.addView(cnt, LinearLayout.LayoutParams(0, dp(34), 1.5f))
        ctl.addView(button("↗") { if (ids.isNotEmpty()) shareIds(listOf(ids[pos])) }, LinearLayout.LayoutParams(0, dp(34), 1f))
        ctl.addView(button("🗑") { if (ids.isNotEmpty()) deleteIds(listOf(ids[pos])) }, LinearLayout.LayoutParams(0, dp(34), 1f))
        ctl.addView(button("▶") { openAt(pos + 1) }, LinearLayout.LayoutParams(0, dp(34), 1f))
        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.BOTTOM
        vw.addView(ctl, cl)
        viewer = vw
        frame.addView(vw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // The selection bar: shown over the top of the grid while photos are ticked.
        val hs = HorizontalScrollView(app)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(0xEE1B3A57.toInt())
        hs.visibility = View.GONE
        val row = LinearLayout(app)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val count = TextView(app)
        count.setTextColor(0xFFFFFFFF.toInt())
        count.textSize = 12f
        count.setPadding(dp(8), 0, dp(6), 0)
        selCount = count
        fun sb(label: String, onClick: () -> Unit): TextView = button(label, onClick).also { it.textSize = 12f; it.setPadding(dp(8), 0, dp(8), 0) }
        row.addView(sb("✕") { clearSel() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(count, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("All") { sel.addAll(ids.toList()); selChanged() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("None") { clearSel() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("Share") { shareIds(sel.toList()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        val del = sb("Delete") { deleteIds(sel.toList()) }
        delBtn = del
        row.addView(del, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("Copy path") { copyPaths(sel.toList()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("Details") { showDetails(sel.toList()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        row.addView(sb("Open in…") { openWith(sel.toList()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
        hs.addView(row)
        selBar = hs
        val hl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34))
        hl.gravity = Gravity.TOP
        frame.addView(hs, hl)

        // The details panel: text over everything, closed with its button.
        val ip = FrameLayout(app)
        ip.setBackgroundColor(0xF0202124.toInt())
        ip.visibility = View.GONE
        ip.setOnTouchListener { _, _ -> true }
        val sv = ScrollView(app)
        val infoTv = TextView(app)
        infoTv.setTextColor(0xFFFFFFFF.toInt())
        infoTv.textSize = 12f
        infoTv.setPadding(dp(12), dp(10), dp(12), dp(46))
        infoTv.setTextIsSelectable(false)
        infoText = infoTv
        sv.addView(infoTv)
        ip.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val close = button("Close") { ip.visibility = View.GONE }
        val cl2 = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
        cl2.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ip.addView(close, cl2)
        infoPanel = ip
        frame.addView(ip, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loadList()
        return frame
    }

    override fun onClose() {
        anim?.cancel()
        anim = null
        pool?.shutdownNow()
        pool = null
        thumbs.evictAll()
        grid?.adapter = null
        big?.setImageDrawable(null)
        ids = LongArray(0)
        sel.clear()
        GalleryBridge.onDeleted = null
    }

    // ---- selection ----------------------------------------------------------------------------

    private fun toggle(id: Long) {
        if (!sel.remove(id)) sel.add(id)
        selChanged()
    }

    private fun clearSel() {
        sel.clear()
        selChanged()
    }

    private fun selChanged() {
        delArmed = false
        delBtn?.setTextColor(0xFFFFFFFF.toInt())
        delBtn?.text = "Delete"
        selBar?.visibility = if (sel.isEmpty()) View.GONE else View.VISIBLE
        selCount?.text = "${sel.size} selected"
        (grid?.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    // ---- what can be done with the ticked photos ---------------------------------------------

    private fun urisOf(list: List<Long>): ArrayList<Uri> = ArrayList(list.map { uri(it) })

    /** Share: one photo as ACTION_SEND, several as ACTION_SEND_MULTIPLE, always through content addresses. */
    private fun shareIds(list: List<Long>) {
        if (list.isEmpty()) return
        val uris = urisOf(list)
        val i = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris[0])
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        i.type = "image/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = android.content.ClipData.newUri(app.contentResolver, "photos", uris[0]).also { c ->
            for (n in 1 until uris.size) c.addItem(android.content.ClipData.Item(uris[n]))
        }
        if (!FloatActions.chooser(app, i)) WidgetFloat.toast(app, "Could not open the share list")
    }

    /** Open in another app: the first ticked photo (the other app sees one picture). */
    private fun openWith(list: List<Long>) {
        val id = list.firstOrNull() ?: return
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri(id), "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = android.content.ClipData.newUri(app.contentResolver, "photo", uri(id))
        if (!FloatActions.chooser(app, i)) WidgetFloat.toast(app, "Could not open the list of apps")
    }

    /** Name, path, size, picture size and date of one photo from the media store, as lines of text. */
    private fun infoOf(id: Long): Array<String?> {
        var r: Array<String?> = arrayOf(null, null, null, null, null)
        runCatching {
            @Suppress("DEPRECATION")
            val cols = arrayOf(
                MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATA, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.DATE_ADDED,
            )
            app.contentResolver.query(uri(id), cols, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val w = c.getInt(3); val h = c.getInt(4)
                    r = arrayOf(
                        c.getString(0), c.getString(1), android.text.format.Formatter.formatShortFileSize(app, c.getLong(2)),
                        if (w > 0 && h > 0) "$w × $h" else null,
                        java.text.DateFormat.getDateTimeInstance().format(java.util.Date(c.getLong(5) * 1000L)),
                    )
                }
            }
        }
        return r
    }

    private fun copyPaths(list: List<Long>) {
        if (list.isEmpty()) return
        val lines = list.mapNotNull { infoOf(it)[1] ?: uri(it).toString() }
        FloatActions.copy(app, lines.joinToString("\n"), if (lines.size == 1) "Path copied" else "${lines.size} paths copied")
    }

    private fun showDetails(list: List<Long>) {
        if (list.isEmpty()) return
        val t = StringBuilder()
        if (list.size == 1) {
            val r = infoOf(list[0])
            t.append("Name: ").append(r[0] ?: "?").append("\n")
            t.append("Path: ").append(r[1] ?: "(not shown by this phone)").append("\n")
            t.append("Size: ").append(r[2] ?: "?").append("\n")
            r[3]?.let { t.append("Picture: ").append(it).append("\n") }
            t.append("Added: ").append(r[4] ?: "?")
        } else {
            var total = 0L
            for (id in list) runCatching {
                app.contentResolver.query(uri(id), arrayOf(MediaStore.Images.Media.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) total += c.getLong(0) }
            }
            t.append("${list.size} photos\nTogether: ").append(android.text.format.Formatter.formatShortFileSize(app, total)).append("\n\n")
            for (id in list.take(40)) t.append("• ").append(infoOf(id)[0] ?: id.toString()).append("\n")
            if (list.size > 40) t.append("… and ${list.size - 40} more")
        }
        infoText?.text = t.toString()
        infoPanel?.visibility = View.VISIBLE
    }

    /**
     * Delete. Android 11 and later: the system's own delete question (MediaStore.createDeleteRequest), asked from a see-through
     * screen. With All files access: a plain delete, after a second tap on the button (it turns red and says Sure?).
     */
    private fun deleteIds(list: List<Long>) {
        if (list.isEmpty()) return
        val plain = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
        if (plain || Build.VERSION.SDK_INT < 30) {
            if (!delArmed) {
                delArmed = true
                delBtn?.setTextColor(0xFFFF6666.toInt())
                delBtn?.text = "Sure?"
                handler.postDelayed({ if (delArmed) { delArmed = false; delBtn?.setTextColor(0xFFFFFFFF.toInt()); delBtn?.text = "Delete" } }, 2500)
                if (viewer?.visibility == View.VISIBLE) WidgetFloat.toast(app, "Tap the bin again to delete this photo")
                return
            }
            delArmed = false
        }
        GalleryBridge.onDeleted = { gone ->
            handler.post {
                if (!closed) {
                    sel.removeAll(gone.toSet())
                    thumbs.evictAll()
                    backToGrid()
                    selChanged()
                    loadList()
                }
            }
        }
        val i = Intent(app, GalleryDeleteActivity::class.java).putExtra("ids", list.toLongArray())
        if (!a.a.utils.AppStarter.start(app, i)) WidgetFloat.toast(app, "Could not start the delete")
    }
}

/** Tells the open gallery which photos the delete screen removed (set only while a gallery window is open). */
object GalleryBridge {
    @Volatile var onDeleted: ((List<Long>) -> Unit)? = null
}

/** Small things the floating tools share: the clipboard, a text file in Downloads, the share list. */
internal object FloatActions {
    fun copy(app: Context, text: String, done: String) {
        runCatching {
            val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("A", text))
            WidgetFloat.toast(app, done)
        }.onFailure { WidgetFloat.toast(app, "Could not copy") }
    }

    fun chooser(app: Context, i: Intent): Boolean =
        runCatching { a.a.utils.AppStarter.start(app, Intent.createChooser(i, null)) }.getOrDefault(false)

    fun shareText(app: Context, text: String): Boolean =
        chooser(app, Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text))

    /** Writes [text] as a .txt file into the Downloads folder; returns the file name, or null when the phone refused. */
    fun saveTxt(app: Context, name: String, text: String): String? = runCatching {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "Note" }.let { if (it.endsWith(".txt")) it else "$it.txt" }
        if (Build.VERSION.SDK_INT >= 29) {
            val v = android.content.ContentValues()
            v.put(MediaStore.Downloads.DISPLAY_NAME, safe)
            v.put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            val u = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return@runCatching null
            app.contentResolver.openOutputStream(u)?.use { it.write(text.toByteArray()) } ?: return@runCatching null
            safe
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            java.io.File(dir, safe).writeText(text)
            safe
        }
    }.getOrNull()
}

/**
 * Where a floating window is drawn. While A's accessibility service is running the window goes through it
 * (TYPE_ACCESSIBILITY_OVERLAY, which needs no "Display over other apps" and which vivo does not close);
 * otherwise it is a normal overlay of the app.
 */
class FloatHost(val context: Context, val type: Int) {
    val wm: WindowManager get() = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    companion object {
        fun resolve(app: Context): FloatHost {
            val svc = a.a.service.OverlayRuntime.accessibilityService
            return if (svc != null) FloatHost(svc, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
            else FloatHost(app.applicationContext, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        }

        /** True when a floating window may be shown: the accessibility service is running, or A may draw over other apps. */
        fun allowed(app: Context): Boolean = a.a.service.OverlayRuntime.accessibilityService != null || WidgetFloat.allowed(app)
    }
}
