package a.a.sides

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow

/**
 * The small questions of the Sides window in the card design: a full-screen card window (back arrow = cancel).
 * [PickWindow] = one row per choice, tapping a row picks it. [ConfirmWindow] = the question in an info row,
 * Cancel and the confirming button under it.
 */
@Composable
internal fun PickWindow(
    title: String,
    hint: String? = null,
    onBack: () -> Unit,
    choices: List<Pair<String, () -> Unit>>,
) {
    CardWindow(title = title, onBack = onBack) {
        CardGroup(title = "Pick one", hint = hint, foldable = false) {
            choices.forEach { (name, go) ->
                row { sh -> SettingRow(title = name, shape = sh, onClick = go) }
            }
        }
    }
}

@Composable
internal fun ConfirmWindow(
    title: String,
    text: String,
    confirm: String,
    onBack: () -> Unit,
    onConfirm: () -> Unit,
) {
    CardWindow(title = title, onBack = onBack) {
        CardGroup(title = title, foldable = false) {
            row { sh -> SettingRow(title = text, shape = sh, icon = Icons.Filled.Info) }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Cancel") }
            Button(onClick = onConfirm, modifier = Modifier.weight(1f)) { Text(confirm) }
        }
    }
}
