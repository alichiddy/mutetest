package a.a.sides

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.data.local.SharedPref

/**
 * Where a segment sits on the screen, drawn as a small window with the phone's own screen ratio: the segment's strip on
 * its edge at its real top and height, and its number in the middle. Left segments are 1, 2, 3 and right segments 4, 5, 6.
 * So which toggle belongs to which strip can be read from the picture, without switching a segment off to see it.
 */
@Composable
internal fun SegmentPhone(
    number: Int, left: Boolean, topPct: Int, heightPct: Int,
    on: Boolean, selected: Boolean = false,
    width: Dp = 34.dp, onClick: (() -> Unit)? = null,
) {
    val metrics = LocalContext.current.resources.displayMetrics
    val w = metrics.widthPixels.toFloat(); val h = metrics.heightPixels.toFloat()
    // Always the upright shape, whichever way the phone is held while this window is open.
    val ratio = (minOf(w, h) / maxOf(w, h)).coerceIn(0.3f, 0.9f)
    val colours = MaterialTheme.colorScheme
    val line = if (selected) colours.primary else colours.outline.copy(alpha = if (on) 0.9f else 0.45f)
    val bar = when {
        !on -> colours.outline.copy(alpha = 0.35f)
        selected -> colours.primary
        else -> colours.primary.copy(alpha = 0.6f)
    }
    Box(
        Modifier.width(width).aspectRatio(ratio).clip(RoundedCornerShape(6.dp))
            .border(if (selected) 2.dp else 1.dp, line, RoundedCornerShape(6.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            val barW = size.width * 0.12f
            val top = size.height * (topPct.coerceIn(0, 100) / 100f)
            val bh = (size.height * (heightPct.coerceIn(3, 100) / 100f)).coerceAtMost(size.height - top)
            drawRoundRect(
                color = bar,
                topLeft = Offset(if (left) 0f else size.width - barW, top),
                size = Size(barW, bh.coerceAtLeast(2f)),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
        Text(
            "$number", fontSize = (width.value * 0.42f).sp, fontWeight = FontWeight.Bold,
            color = if (on) colours.onSurface else colours.onSurfaceVariant.copy(alpha = 0.6f),
        )
    }
}

/** The strip's top and height in percent of the screen's height, as it sits now: following the main slider or another segment included. */
internal fun placeOfSeg(context: android.content.Context, cfg: SideConfig, left: Boolean, index: Int): Pair<Int, Int> {
    val dm = context.resources.displayMetrics
    val screenDp = dm.heightPixels / dm.density
    val pref = SharedPref(context)
    val portrait = dm.heightPixels >= dm.widthPixels
    val mainH = pref.getHandlerHeightDp()
    val mainHeightPct = (mainH / screenDp * 100f).toInt().coerceIn(3, 100)
    val mainTopPct = (pref.getHandlerPosYFraction(portrait) * 100f - mainHeightPct / 2f).toInt().coerceIn(0, 97)
    fun find(code: String): Seg? {
        if (code.length < 2) return null
        val side = if (code[0] == 'L') cfg.left else if (code[0] == 'R') cfg.right else return null
        return side.segs.getOrNull((code.substring(1).toIntOrNull() ?: return null) - 1)
    }
    var seg = (if (left) cfg.left else cfg.right).segs.getOrNull(index) ?: return 20 to 20
    var hops = 0
    // A segment linked to another one sits exactly where that one does.
    while (seg.linkTo.isNotEmpty() && hops < 4) { seg = find(seg.linkTo) ?: break; hops++ }
    val top = if (seg.posMain) (mainTopPct + seg.shiftPct).coerceIn(0, 97) else seg.topPct
    val height = if (seg.hMain) mainHeightPct else seg.heightPct
    return top to height
}
