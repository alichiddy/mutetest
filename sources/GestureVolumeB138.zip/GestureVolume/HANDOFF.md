# HANDOFF: native replacement for the Automate cells

Base: GestureVolume B56 (with the VolumeUp import fix and the "Resume build status" action).
This change adds an in-app action engine and built-in flows so the strip's cells no longer need Automate.
It could not be compiled where it was written: if GitHub reports `e:` lines, they point at the files below.

## New files (all in `flow/`, so merges stay easy)
- `NativeActions.kt`: every built-in action (id, label, what it needs). Ids starting with `A:` run one of A's own actions (Screenshot, Power menu, Shell runner...).
- `SeedFlows.kt`: the built-in flows (one per old Automate cell) and the table that maps old `Flow:468/233`-style cells to them. "Install my cells and flows" in the Flows screen runs it.
- `FlowHelpers.kt`: `PrivateValues` (keys/codes, stored in the separate `PrivateValues` prefs file, never in the settings backup or a cloned APK), plus two see-through helper activities (clipboard read, file pick).
- `assets/scripts/*.sh`: shell scripts copied exactly from the old Automate flows (`@PKG@`, `@MASK@`, `@TARGET_USER@` are filled in at run time).

## Changed files
- `flow/Flow.kt`: three new step types (`act`, `psh`, `bcast`).
- `flow/FlowRunner.kt`: runs them; fills `{name}` from PrivateValues; a missing-Shizuku step shows a message and opens Shizuku instead of failing.
- `flow/FlowActivity.kt`: action picker, "My values", "Install my cells and flows", "Allow usage access".
- `ui/screens/shell/ShizukuGrantRow.kt`: button label is now "Load My Automate".
- `AndroidManifest.xml`: 2 helper activities, PACKAGE_USAGE_STATS, WRITE_SECURE_SETTINGS, READ_PHONE_STATE, ACCESS_WIFI_STATE.
- `assets/grant.sh`: also grants usage access, secure settings, phone state, call phone, mock location (for the map in the next step).
- `utils/GitHubBuild.kt`, `HandlerActions.kt`, `HandlerActionCatalog.kt`, `OverlayController.kt`, `strings.xml`: "Resume build status" action (watch a build already started, no re-upload).
- `utils/HandlerActionCatalog.kt`: VolumeUp import fix.

## Rules of the engine
- NONE: works with the permissions A already has. ONCE: needs the one-time secure-settings grant (Grant button via Shizuku), else falls back to Shizuku. BETTER: opens the system panel without Shizuku. SHIZUKU: needs Shizuku every time.
- Steps can be marked "skips quietly without Shizuku" (`c = "optional"`).
- Never put real keys in source: use `{name}` and a slot in `PrivateValues.slots`.

## Not done yet
Fake-GPS map screen, Google Drive upload with sign-in, QR generator, the accessibility tap in WShr, Lens sharing step in LNS.
Five cells (2GOnly, WShr, DSave, PWR, WG Tunnel All) point at statement ids that are newer than the Automate backup this was built from: they were mapped by label. Verify them.

## B59 (on top of B58): messages, windows, wireless fixes
Touches only my files plus one line in `OverlayController.kt` (the "last result" bar in the `MyFlow:` branch).
- `FlowHelpers.kt`: `FlowPrefs` (message-bar mode: always / messages and failures [default] / only failures; button in the Flows screen) and `ResultActivity` (a window that stays until closed, with Copy).
- `FlowRunner.kt`: Message steps with `c = "window"` open the window; action results that should stay (uploads, grant/revoke, diagnostics) open it automatically (`NativeActions.staysOnScreen`).
- `NativeActions.kt`: Bluetooth tries `svc bluetooth` then `cmd bluetooth_manager` and checks the result; hotspot tries each stop/start command, checks the result and shows what the phone answered; new `wireless_diag` action; `bgshell` output is now `$ command` then the output (and `[exit N]` on failure), and `plain` copies nothing and uploads nothing.
- `SeedFlows.kt`: WifiOn and ALOF use the hotspot action. Existing installed flows are not overwritten: delete them in the Flows screen and press "Install my cells and flows" again to get the new versions.

## B60: Lens OCR ("NOW ON TAP") as one native action
- `NativeActions.kt`: new `lens_ocr`: runs `lensnet.sh prep` (stop VPNs, cut Wi-Fi/data, screenshot to /Documents/screenshot.png), opens it in Google Lens through A's FileProvider, waits until Lens/Google is left (max 3 min), then always runs `lensnet.sh on` (restores Wi-Fi and data, also when something fails).
- `AndroidManifest.xml`: FileProvider `${applicationId}.files`; new `res/xml/file_paths.xml`.
- `SeedFlows.kt`: LNS is now just `lens_ocr`. Delete the old LNS flow and press "Install my cells and flows" to get it.
- Needs "All files access" (the Grant button) so A can read the screenshot Shizuku's shell wrote.
- Not done: always-on automations (copy OTP, actions when apps open, unlock/charger/Wi-Fi triggers). They need a trigger engine; it touches `OverlayService` (start line), `GestureAccessibilityService` (app-in-front event) and the manifest (SMS receiver).

## B61: "Save to Downloads" in the share sheet
- New `share/SaveToDownloadsActivity.kt` + manifest entry: A appears in every app's share sheet as "Save to Downloads" and writes files (or shared text) into Download through MediaStore (no storage permission on Android 10+; `WRITE_EXTERNAL_STORAGE` maxSdk 28 for older phones).
- In a second profile (dual apps) with Shizuku ready it also copies the file to the main profile's Download folder (`/data/media/0/Download`). That copy is best effort and untested.

## B62 – Automations (always-on rules)
New package `app/src/main/java/com/newagedevs/gesturevolume/auto/` (Automations.kt, AutomationsScreen.kt). Rules (trigger, arg, flow) live in prefs "AutoRules". Triggers: SMS received (flow vars {otp},{message},{sender}), app opened (UsageStats poll, 2 s, screen on only), unlock, charger on/off, Wi-Fi connected, app installed. Seed flow "CopyOTP" (added from the screen's "Copy OTP from texts" button).
Existing files touched (one small edit each):
- AndroidManifest.xml: permissions ACCESS_NETWORK_STATE, RECEIVE_SMS; receiver `.auto.SmsRuleReceiver` (BROADCAST_SMS).
- service/OverlayService.kt: one line in onCreate: `Automations.start(this)`.
- flow/FlowActivity.kt: `autos` state, branch to `AutomationsScreen`, "Automations" button.
- assets/grant.sh: `pm grant … RECEIVE_SMS`.
Untested/uncompiled.

## B63 – merge of the other Claude's B59 (Automate-flow converter) + my B62
Three-way merge (base B58). Taken from the other Claude: Expr.kt, AutomateFlows.kt, assets/automate_flows.json, Flow.kt, FlowRunner.kt (goto-run, expr conditions, for-each), importedSlots in FlowHelpers.kt, NativeActions additions, "Add my Automate flows" button.
Kept from mine: FlowPrefs/ResultActivity, MESSAGE "window", Save to Downloads, Automations (auto/), Lens etc.
Only two hand-resolved spots: FlowRunner (WAIT = his expr version; MESSAGE = my FlowPrefs/window version) and FlowActivity (both buttons kept). Uncompiled.
