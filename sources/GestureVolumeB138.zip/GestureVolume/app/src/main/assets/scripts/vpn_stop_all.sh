for p in $(cmd package query-services -a android.net.VpnService | grep -oE 'packageName=[^ ]+' | cut -d= -f2 | sort -u); do echo stopping $p; am force-stop $p; done
