p='@PKG@'
echo "===== $p ====="

echo "===== REVOKING DECLARED PERMISSIONS ====="
dumpsys package "$p" 2>/dev/null|sed -n '/requested permissions:/,/install permissions:/p'|grep -oE 'android\.permission\.[A-Z0-9_]+'|sort -u|while read x;do pm revoke "$p" "$x" 2>/dev/null&&echo "REVOKED $x";done

echo "===== RESETTING APPOPS ====="
for x in android:system_alert_window android:write_settings android:write_secure_settings android:get_usage_stats android:picture_in_picture android:manage_external_storage android:request_install_packages android:request_delete_packages android:schedule_exact_alarm android:use_full_screen_intent android:run_in_background android:run_any_in_background android:start_foreground android:turn_screen_on android:activity_recognition android:camera android:record_audio android:read_clipboard android:write_clipboard android:bluetooth_scan android:bluetooth_connect android:bluetooth_advertise android:coarse_location android:fine_location android:phone android:read_phone_state android:read_call_log android:write_call_log android:read_contacts android:write_contacts android:read_sms android:write_sms android:receive_sms android:send_sms android:read_media_images android:read_media_video android:read_media_audio android:post_notification android:nearby_wifi_devices android:body_sensors android:access_accessibility;do appops set "$p" "$x" default 2>/dev/null&&echo "RESET $x";done

echo "===== BATTERY ====="
cmd deviceidle whitelist -"${p}" 2>/dev/null&&echo "REMOVED FROM WHITELIST"

echo "===== ACCESSIBILITY ====="
a="$(settings get secure enabled_accessibility_services 2>/dev/null)"
[ "$a" = "null" ]&&a=""
for s in $(dumpsys package "$p" 2>/dev/null|sed -n '/android.accessibilityservice.AccessibilityService:/,/^[^ ]/p'|grep -oE "$p/[A-Za-z0-9_.$]+"|sort -u);do
case ":$a:" in
*:"$s":*)
a="$(echo "$a"|tr ':' '\n'|grep -Fv -x "$s"|paste -sd:)"
echo "DISABLED: $s"
;;
esac
done
settings put secure enabled_accessibility_services "$a"
[ -n "$a" ]&&settings put secure accessibility_enabled 1||settings put secure accessibility_enabled 0

echo "===== NOTIFICATION LISTENER ====="
n="$(settings get secure enabled_notification_listeners 2>/dev/null)"
[ "$n" = "null" ]&&n=""
for s in $(dumpsys package "$p" 2>/dev/null|sed -n '/android.service.notification.NotificationListenerService:/,/^[^ ]/p'|grep -oE "$p/[A-Za-z0-9_.$]+"|sort -u);do
case ":$n:" in
*:"$s":*)
n="$(echo "$n"|tr ':' '\n'|grep -Fv -x "$s"|paste -sd:)"
echo "DISABLED: $s"
;;
esac
done
settings put secure enabled_notification_listeners "$n"

echo "===== FINAL APPOPS ====="
appops get "$p" 2>/dev/null

echo "===== BATTERY STATUS ====="
if cmd deviceidle whitelist 2>/dev/null|grep -Fq "$p";then echo "STILL WHITELISTED";else echo "NOT WHITELISTED";fi

echo "===== ACCESSIBILITY STATUS ====="
settings get secure enabled_accessibility_services

echo "===== NOTIFICATION STATUS ====="
settings get secure enabled_notification_listeners

echo "===== DONE ====="
