sh -c 'for i in $(seq 40); do input swipe 270 700 270 500 20; done'
