dumpsys telephony.registry | grep -o 'mServiceState=.*' | head -n 2 | awk '{
d="Unknown"; n="Unknown";
if($0~/getRilDataRadioTechnology=[0-9_]*\(GPRS\)|getRilDataRadioTechnology=[0-9_]*\(EDGE\)|getRilDataRadioTechnology=[0-9_]*\(GSM\)/)d="2G";
else if($0~/getRilDataRadioTechnology=[0-9_]*\(UMTS\)|getRilDataRadioTechnology=[0-9_]*\(HSPA\)|getRilDataRadioTechnology=[0-9_]*\(HSDPA\)|getRilDataRadioTechnology=[0-9_]*\(HSUPA\)|getRilDataRadioTechnology=[0-9_]*\(HSPAP\)/)d="3G";
else if($0~/getRilDataRadioTechnology=[0-9_]*\(LTE\)/)d="4G";
else if($0~/getRilDataRadioTechnology=[0-9_]*\(NR\)/)d="5G";
if($0~/getRilVoiceRadioTechnology=[0-9_]*\(GSM\)/)n="2G (GSM)";
else if($0~/getRilVoiceRadioTechnology=[0-9_]*\(UMTS\)/)n="3G (UMTS)";
else if($0~/getRilVoiceRadioTechnology=[0-9_]*\(LTE\)/)n="4G (LTE)";
else if($0~/getRilVoiceRadioTechnology=[0-9_]*\(NR\)/)n="5G (NR)";
if(d=="Unknown")d="No Active Data";
print "SIM " NR ": Data = " d " | Network = " n
}'
