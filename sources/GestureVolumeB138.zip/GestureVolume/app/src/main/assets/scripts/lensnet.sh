#!/system/bin/sh
# lensnet.sh prep|on
# prep: stop every VPN app (force-stop), cut Wi-Fi + mobile data, take the screenshot - all at once
#       the VPN stop runs detached and is never waited for
# on  : restore Wi-Fi and mobile data exactly as they were before "prep"

if [ -w /data/local/tmp ]; then DIR=/data/local/tmp; else DIR=/sdcard/Download; fi
S="${LENSNET_STATE:-$DIR/lensnet.state}"
SHOT="${LENSNET_SHOT:-/sdcard/Documents/screenshot.png}"

killvpn() {
  for p in $(cmd package query-services -a android.net.VpnService | grep -oE 'packageName=[^ ]+' | cut -d= -f2 | sort -u); do
    am force-stop "$p" &
  done
  wait
}

do_prep() {
  # VPN apps: detached, fully in the background, never waited for
  if command -v setsid >/dev/null 2>&1; then
    setsid sh "$0" killvpn >/dev/null 2>&1 &
  else
    killvpn >/dev/null 2>&1 &
  fi

  W=0; D=0
  case "$(settings get global wifi_on)" in 1|2) W=1;; esac
  [ "$(settings get global mobile_data)" = "1" ] && D=1

  # Already offline from an earlier run (double tap): keep the first saved state
  if [ "$W$D" != "00" ] || [ ! -f "$S" ]; then
    echo "$W $D" > "$S"
  fi

  P=""
  if [ "$W" = 1 ]; then svc wifi disable 2>/dev/null & P="$P $!"; fi
  if [ "$D" = 1 ]; then svc data disable 2>/dev/null & P="$P $!"; fi

  mkdir -p "$(dirname "$SHOT")"
  screencap -p "$SHOT"

  # only wait for Wi-Fi/data switches (they finish while the screenshot is taken)
  [ -n "$P" ] && wait $P
}

do_on() {
  [ -f "$S" ] || return 0
  read -r W D < "$S"
  [ "$W" = 1 ] && svc wifi enable 2>/dev/null
  [ "$D" = 1 ] && svc data enable 2>/dev/null
  rm -f "$S"
}

case "$1" in
prep) do_prep ;;
killvpn) killvpn ;;
on) do_on ;;
*) echo "usage: lensnet.sh prep|on"; exit 1 ;;
esac
