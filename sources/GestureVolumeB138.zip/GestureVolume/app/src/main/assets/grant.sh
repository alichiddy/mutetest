PKG=@PKG@
appops set $PKG SYSTEM_ALERT_WINDOW allow
appops set $PKG WRITE_SETTINGS allow
appops set $PKG MANAGE_EXTERNAL_STORAGE allow
appops set $PKG REQUEST_INSTALL_PACKAGES allow
pm grant $PKG android.permission.POST_NOTIFICATIONS 2>/dev/null
cmd notification allow_dnd $PKG 2>/dev/null
appops set $PKG GET_USAGE_STATS allow 2>/dev/null
appops set $PKG android:mock_location allow 2>/dev/null
pm grant $PKG android.permission.WRITE_SECURE_SETTINGS 2>/dev/null
pm grant $PKG android.permission.READ_PHONE_STATE 2>/dev/null
pm grant $PKG android.permission.CALL_PHONE 2>/dev/null
pm grant $PKG android.permission.RECEIVE_SMS 2>/dev/null
dumpsys deviceidle whitelist +$PKG 2>/dev/null
SVC=$(cmd package query-services --brief --components -a android.accessibilityservice.AccessibilityService 2>/dev/null | grep "^$PKG/" | head -n 1)
if [ -n "$SVC" ]; then
  OLD=$(settings get secure enabled_accessibility_services)
  CLEAN=$(echo "$OLD" | tr ':' '\n' | grep -v "^$PKG/" | grep -v '^null$' | grep -v '^$' | paste -sd: -)
  case ":$OLD:" in
    *":$SVC:"*) ;;
    *) if [ -z "$CLEAN" ]; then settings put secure enabled_accessibility_services "$SVC"; else settings put secure enabled_accessibility_services "$CLEAN:$SVC"; fi ;;
  esac
  settings put secure accessibility_enabled 1
  echo "Accessibility: on"
else
  echo "Accessibility service not found"
fi
echo "Draw over apps: $(appops get $PKG SYSTEM_ALERT_WINDOW)"
echo "Modify settings: $(appops get $PKG WRITE_SETTINGS)"
echo "All files: $(appops get $PKG MANAGE_EXTERNAL_STORAGE)"
echo "Usage access: $(appops get $PKG GET_USAGE_STATS)"
echo "Done"
