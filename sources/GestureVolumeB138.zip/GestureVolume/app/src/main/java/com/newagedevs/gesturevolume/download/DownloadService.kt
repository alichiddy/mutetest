package com.newagedevs.gesturevolume.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.webkit.URLUtil
import com.newagedevs.gesturevolume.download.DownloadStore.DONE
import com.newagedevs.gesturevolume.download.DownloadStore.FAILED
import com.newagedevs.gesturevolume.download.DownloadStore.Job
import com.newagedevs.gesturevolume.download.DownloadStore.NORMAL
import com.newagedevs.gesturevolume.download.DownloadStore.PAUSED
import com.newagedevs.gesturevolume.download.DownloadStore.QUEUED
import com.newagedevs.gesturevolume.download.DownloadStore.RUNNING
import com.newagedevs.gesturevolume.download.DownloadStore.STOPPED
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * The download manager's engine. It exists only while something is downloading (zero cost when idle).
 *
 * Resume: every download is written to a partial file in A's private storage; a new request for the
 * same file asks the server for "bytes=<have>-" (with If-Range when the server gave an ETag), so a
 * broken or stopped download continues instead of restarting. When a NEW link for a file that has an
 * unfinished partial arrives (same name, same size), the partial is taken over and continued with
 * the new link, which is what makes expired links resumable.
 */
class DownloadService : Service() {
    private class Stop : RuntimeException()
    private class LinkDead(msg: String) : RuntimeException(msg)
    private class Merge(val into: Job) : RuntimeException()
    private class Run(val job: Job) {
        @Volatile var cancelled = false
        @Volatile var conn: HttpURLConnection? = null
        @Volatile var progressed = false
    }

    private val runs = HashMap<Int, Run>()
    private lateinit var nm: NotificationManager
    @Volatile private var lastStartId = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DownloadStore.init(this)
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SVC, "Download service", NotificationManager.IMPORTANCE_MIN))
        val n = summary(0)
        if (Build.VERSION.SDK_INT >= 34) startForeground(SUMMARY, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(SUMMARY, n)
        // A download that was running when the process was killed has no worker any more.
        for (j in DownloadStore.all()) if (j.state == RUNNING) {
            j.state = PAUSED; j.message = "Interrupted"; notifyJob(j)
        }
        DownloadStore.save()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        val id = intent?.getIntExtra("id", -1) ?: -1
        val job = DownloadStore.get(id)
        when (intent?.action) {
            ACT_START, ACT_RESUME -> if (job != null && job.state != DONE) {
                job.message = ""; job.state = QUEUED; DownloadStore.save(); notifyJob(job)
            }
            ACT_PAUSE -> signal(job, PAUSED, "Paused")
            ACT_STOP -> signal(job, STOPPED, "")
            ACT_RESTART -> if (job != null && job.state != DONE) {
                signal(job, STOPPED, "")
                DownloadStore.partFile(this, job).delete()
                job.done = 0; job.total = -1; job.etag = null; job.lastMod = null; job.fresh = false
                job.message = ""; job.state = QUEUED; DownloadStore.save(); notifyJob(job)
            }
            ACT_REMOVE -> if (job != null) {
                if (job.state != DONE) { signal(job, STOPPED, ""); DownloadStore.partFile(this, job).delete() }
                DownloadStore.remove(job.id); nm.cancel(NOTIF + job.id)
            }
        }
        pump()
        return START_NOT_STICKY
    }

    /** Pause / Stop: remember the state first, then break the connection so the worker unwinds at once. */
    private fun signal(job: Job?, state: Int, msg: String) {
        job ?: return
        val r = synchronized(this) { runs[job.id] }
        job.state = state; job.message = msg; job.speed = 0
        if (r != null) {
            r.cancelled = true
            Thread { runCatching { r.conn?.disconnect() } }.start()
        }
        DownloadStore.save(); notifyJob(job)
    }

    /** Starts waiting downloads (three at a time) and stops the service when nothing is left to do. */
    private fun pump() {
        var active: Int
        synchronized(this) {
            for (j in DownloadStore.all()) {
                if (runs.size >= MAX) break
                if (j.state == QUEUED && !runs.containsKey(j.id)) {
                    val r = Run(j); runs[j.id] = r
                    j.state = RUNNING; j.message = ""
                    Thread({ work(r) }, "dl-${j.id}").start()
                }
            }
            active = runs.size
        }
        if (active == 0) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(lastStartId)
        } else nm.notify(SUMMARY, summary(active))
    }

    private fun work(run: Run) {
        val job = run.job
        try {
            notifyJob(job)
            download(run)
        } catch (_: Stop) {
        } catch (m: Merge) {
            takeOver(job, m.into)
        } catch (e: LinkDead) {
            park(job, PAUSED, e.message ?: "The link was refused.")
        } catch (t: Throwable) {
            park(job, FAILED, t.message ?: t.javaClass.simpleName)
        } finally {
            synchronized(this) { runs.remove(job.id) }
            pump()
        }
    }

    private fun park(job: Job, state: Int, msg: String) {
        if (job.state != RUNNING) return
        job.state = state; job.message = msg; job.speed = 0
        DownloadStore.save(); notifyJob(job)
    }

    /** A new link for a file that has an unfinished partial: the partial continues with the new link. */
    private fun takeOver(fresh: Job, old: Job) {
        old.url = fresh.url; old.referer = fresh.referer; old.cookie = fresh.cookie; old.ua = fresh.ua
        old.mode = fresh.mode
        if (fresh.nameEdited) { old.name = fresh.name; old.nameEdited = true }
        old.etag = fresh.etag; old.lastMod = fresh.lastMod
        if (fresh.total > 0) old.total = fresh.total
        old.message = "Resumed with the new link"; old.state = QUEUED
        DownloadStore.remove(fresh.id); nm.cancel(NOTIF + fresh.id)
        DownloadStore.save(); notifyJob(old)
    }

    private fun sameName(a: String, b: String): Boolean {
        fun n(s: String) = s.replace(Regex("\\s*\\(\\d+\\)(?=\\.[^.]*$|$)"), "").lowercase()
        return n(a) == n(b)
    }

    private fun findSibling(job: Job): Job? = DownloadStore.all().firstOrNull { o ->
        o.id != job.id && o.state != DONE && o.state != RUNNING && o.done > 0 &&
            synchronized(this) { !runs.containsKey(o.id) } &&
            sameName(o.name, job.name) && (o.total <= 0 || job.total <= 0 || o.total == job.total)
    }

    private fun download(run: Run) {
        val job = run.job
        val part = DownloadStore.partFile(this, job)
        part.parentFile?.mkdirs()
        var attempt = 0
        while (true) {
            if (run.cancelled) throw Stop()
            try {
                run.progressed = false
                if (fetch(run, part)) break
            } catch (e: IOException) {
                if (run.cancelled) throw Stop()
                if (run.progressed) attempt = 0
                attempt++
                if (attempt > 40) throw LinkDead("Connection lost. Tap Resume when the network is back.")
                job.message = "Connection lost, retrying ($attempt)"; job.speed = 0
                notifyJob(job)
                val wait = minOf(30, 2 shl minOf(attempt, 4)) * 1000L
                val until = SystemClock.elapsedRealtime() + wait
                while (SystemClock.elapsedRealtime() < until) {
                    if (run.cancelled) throw Stop()
                    Thread.sleep(250)
                }
            }
        }
        finish(job, part)
    }

    /** One connection. True when the file is complete; false when the partial was thrown away and it must be asked again. */
    private fun fetch(run: Run, part: File): Boolean {
        val job = run.job
        var have = if (part.exists()) part.length() else 0L
        job.done = have
        var url = job.url
        var c: HttpURLConnection
        var hops = 0
        while (true) {
            c = URL(url).openConnection() as HttpURLConnection
            run.conn = c
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", job.ua ?: UA)
            c.setRequestProperty("Accept-Encoding", "identity")
            job.referer?.let { c.setRequestProperty("Referer", it) }
            job.cookie?.let { c.setRequestProperty("Cookie", it) }
            if (have > 0) {
                c.setRequestProperty("Range", "bytes=$have-")
                (job.etag ?: job.lastMod)?.let { c.setRequestProperty("If-Range", it) }
            }
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location") ?: throw LinkDead("The link redirects nowhere.")
                c.disconnect()
                if (++hops > 8) throw LinkDead("Too many redirects.")
                url = URL(URL(url), loc).toString()
                continue
            }
            break
        }
        try {
            val code = c.responseCode
            if (code == 416) {
                if (job.total > 0 && have >= job.total) return true
                part.delete(); job.done = 0; job.etag = null; job.lastMod = null
                return false
            }
            if (code == 401 || code == 403 || code == 404 || code == 410)
                throw LinkDead("The link no longer works (HTTP $code). Open the page again and send the new link to A; it resumes this file.")
            if (code == 429 || code >= 500) throw IOException("HTTP $code")
            if (code != 200 && code != 206) throw LinkDead("The server answered HTTP $code.")

            var append = true
            if (code == 200) {
                // Not a partial answer: the server ignored the range, or the file changed. Start over.
                if (have > 0) { part.delete(); have = 0; job.done = 0 }
                append = false
                job.total = c.contentLengthLong
                job.etag = c.getHeaderField("ETag")?.takeIf { !it.startsWith("W/") }
                job.lastMod = c.getHeaderField("Last-Modified")
            } else {
                c.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull()?.let { job.total = it }
            }
            if (have == 0L) {
                val ct = c.contentType
                if (job.mime.isEmpty()) job.mime = ct?.substringBefore(';')?.trim() ?: ""
                if (!job.nameEdited) {
                    job.name = URLUtil.guessFileName(job.url, c.getHeaderField("Content-Disposition"), ct).replace('/', '_')
                }
                // A new link for a file that already has an unfinished partial continues that partial.
                if (job.fresh) {
                    job.fresh = false
                    val sib = findSibling(job)
                    if (sib != null) throw Merge(sib)
                }
                DownloadStore.save()
            }
            job.state = RUNNING; job.message = ""
            notifyJob(job)

            val buf = ByteArray(64 * 1024)
            var lastT = SystemClock.elapsedRealtime()
            var lastBytes = job.done
            FileOutputStream(part, append).use { out ->
                c.inputStream.use { input ->
                    while (true) {
                        if (run.cancelled) throw Stop()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        job.done += n
                        run.progressed = true
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastT >= 1000) {
                            job.speed = (job.done - lastBytes) * 1000 / (now - lastT)
                            lastBytes = job.done; lastT = now
                            if (job.message.startsWith("Connection lost")) job.message = ""
                            notifyJob(job)
                        }
                    }
                }
            }
            if (job.total > 0 && job.done < job.total) throw IOException("Connection closed early")
            if (job.total <= 0) job.total = job.done
            return true
        } finally {
            runCatching { c.disconnect() }
        }
    }

    private fun finish(job: Job, part: File) {
        job.speed = 0; job.message = "Saving to Downloads"
        notifyJob(job)
        val mime = DownloadSaver.mimeFor(job.name, job.mime)
        val saved = FileInputStream(part).use { DownloadSaver.write(this, it, job.name, mime, job.mode != NORMAL) }
        part.delete()
        job.savedName = saved.name; job.savedUri = saved.uri?.toString()
        var msg = if (job.mode != NORMAL && saved.name != job.name)
            "${job.name} could not be replaced (it belongs to another app), so it was saved as ${saved.name}" else ""
        if (DownloadSaver.copyToMainProfile(listOf(saved.name)) > 0) msg += " Also copied to the main profile's Download folder."
        job.message = msg.trim()
        job.state = DONE
        DownloadStore.save(); notifyJob(job)
    }

    // ---- notifications ----

    private fun act(action: String, id: Int, k: Int): PendingIntent =
        PendingIntent.getForegroundService(
            this, id * 8 + k,
            Intent(this, DownloadService::class.java).setAction(action).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun button(title: String, pi: PendingIntent) =
        Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_info_details), title, pi).build()

    private fun openList(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, DownloadsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun summary(active: Int): Notification =
        Notification.Builder(this, CH_SVC)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("A downloads")
            .setContentText(if (active > 0) "$active active" else "Starting")
            .setOngoing(true).setContentIntent(openList()).build()

    private fun fileIntentPi(j: Job, install: Boolean, k: Int): PendingIntent? {
        val i = fileIntent(j, install) ?: return null
        return PendingIntent.getActivity(this, j.id * 8 + k, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun notifyJob(j: Job) {
        runCatching {
            val b = Notification.Builder(this, CH)
                .setContentTitle(j.name)
                .setContentText(DownloadStore.statusText(this, j).lineSequence().first())
                .setStyle(Notification.BigTextStyle().bigText(DownloadStore.statusText(this, j)))
                .setOnlyAlertOnce(true)
                .setContentIntent(openList())
            val pct = if (j.total > 0) (j.done * 1000 / j.total).toInt() else 0
            when (j.state) {
                RUNNING -> {
                    b.setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true)
                    if (j.total > 0) b.setProgress(1000, pct, false) else b.setProgress(0, 0, true)
                    b.addAction(button("Pause", act(ACT_PAUSE, j.id, 0)))
                    b.addAction(button("Stop", act(ACT_STOP, j.id, 1)))
                }
                QUEUED -> {
                    b.setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setProgress(0, 0, true)
                    b.addAction(button("Stop", act(ACT_STOP, j.id, 1)))
                }
                PAUSED -> {
                    b.setSmallIcon(android.R.drawable.ic_media_pause).setOngoing(false)
                    if (j.total > 0) b.setProgress(1000, pct, false)
                    b.addAction(button("Resume", act(ACT_RESUME, j.id, 2)))
                }
                STOPPED, FAILED -> {
                    b.setSmallIcon(android.R.drawable.ic_delete).setOngoing(false)
                    if (j.total > 0) b.setProgress(1000, pct, false)
                    b.addAction(button("Restart", act(ACT_RESTART, j.id, 3)))
                    b.addAction(button("Resume", act(ACT_RESUME, j.id, 2)))
                }
                DONE -> {
                    b.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).setOngoing(false)
                    b.setContentTitle("Downloaded: ${j.savedName ?: j.name}")
                    fileIntentPi(j, false, 5)?.let { b.setContentIntent(it) }
                    if (j.isApk) fileIntentPi(j, true, 4)?.let { b.addAction(button("Install", it)) }
                    fileIntentPi(j, false, 5)?.let { b.addAction(button("View", it)) }
                }
            }
            nm.notify(NOTIF + j.id, b.build())
        }
    }

    companion object {
        const val ACT_START = "a.a.DL_START"
        const val ACT_PAUSE = "a.a.DL_PAUSE"
        const val ACT_STOP = "a.a.DL_STOP"
        const val ACT_RESUME = "a.a.DL_RESUME"
        const val ACT_RESTART = "a.a.DL_RESTART"
        const val ACT_REMOVE = "a.a.DL_REMOVE"
        private const val CH = "dl"
        private const val CH_SVC = "dl_svc"
        private const val SUMMARY = 7400
        private const val NOTIF = 7500
        private const val MAX = 3
        private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

        fun send(context: Context, action: String, id: Int) {
            context.startForegroundService(Intent(context, DownloadService::class.java).setAction(action).putExtra("id", id))
        }

        /** Opens the saved file; Install gives the APK to the system installer. */
        fun fileIntent(j: Job, install: Boolean): Intent? {
            val u = j.savedUri?.let { Uri.parse(it) } ?: return null
            val mime = if (install || j.isApk) "application/vnd.android.package-archive"
            else DownloadSaver.mimeFor(j.savedName ?: j.name, j.mime)
            return Intent(Intent.ACTION_VIEW).setDataAndType(u, mime)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
