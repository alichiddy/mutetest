package com.newagedevs.gesturevolume.utils

import android.media.audiofx.LoudnessEnhancer

/**
 * Louder than the system's maximum: a loudness effect on the global audio output, stepped
 * off, +8, +16, +24, +32 dB-hundredths (800 to 3200 millibels) with each trigger and back to off.
 *
 * The effect is a few kilobytes and lives only while a boost is on; at "off" it is released and
 * nothing is kept. It is attached to the global output mix (session 0), which not every phone
 * allows — when it is refused the action says so instead of pretending.
 *
 * A boost can distort and, at the top levels, hurt hearing and speakers: the steps are deliberately
 * small, and the last one is the limit.
 */
object VolumeBoost {
    private val LEVELS_MB = intArrayOf(0, 800, 1600, 2400, 3200)
    private var level = 0
    private var effect: LoudnessEnhancer? = null

    const val MAX_MB = 3200

    /** The gain now, in millibels (0 = off). */
    @get:Synchronized
    val mb: Int get() = if (effect == null) 0 else currentMb

    private var currentMb = 0

    /**
     * Sets the gain exactly (the sliders use this), 0 turning the boost off. False when the phone
     * refuses the effect.
     */
    @Synchronized
    fun setMb(target: Int): Boolean {
        val mb = target.coerceIn(0, MAX_MB)
        if (mb == 0) { release(); return true }
        return try {
            val e = effect ?: LoudnessEnhancer(0).also { effect = it }
            e.setTargetGain(mb)
            e.enabled = true
            currentMb = mb
            true
        } catch (t: Throwable) {
            DiagLog.note("volume boost failed: $t")
            release()
            false
        }
    }

    /** Moves to the next level and returns what to tell the user. */
    @Synchronized
    fun step(): String {
        level = (level + 1) % LEVELS_MB.size
        if (level == 0) {
            release()
            return "Volume boost off"
        }
        return try {
            val e = effect ?: LoudnessEnhancer(0).also { effect = it }
            e.setTargetGain(LEVELS_MB[level])
            e.enabled = true
            currentMb = LEVELS_MB[level]
            "Volume boost +${LEVELS_MB[level] / 100} dB"
        } catch (t: Throwable) {
            DiagLog.note("volume boost failed: $t")
            release()
            level = 0
            "Volume boost is not supported on this phone"
        }
    }

    /** What A holds right now, for the report. */
    @Synchronized
    fun status(): String {
        val e = effect ?: return "A holds no boost effect (gain 0 dB)"
        return "A holds an effect: gain ${currentMb / 100} dB, enabled=${runCatching { e.enabled }.getOrNull()}, control=${runCatching { e.hasControl() }.getOrNull()}"
    }

    /**
     * Asks the audio system itself (needs Shizuku) whether any loudness effect is still active.
     * Blocking: call from a background thread. Null when it cannot be checked.
     */
    fun verifyOff(): String? {
        if (!ShizukuShell.isReady()) return null
        var found = 0
        val code = ShizukuShell.run("dumpsys media.audio_flinger") { line ->
            if (line.contains("loudness", true) || line.contains("fa415329-2034-4bea-b5dc-5b381c8d1e2c")) found++
        }
        if (code != 0) return null
        return if (found == 0) "checked with the system: no loudness effect is active"
        else "the system still lists a loudness effect ($found lines) - it is not held by A; restart the phone's audio (stop/start the player) or reboot"
    }

    @Synchronized
    fun release() {
        // Gain first: even if the phone leaves the effect object alive, it adds nothing.
        runCatching { effect?.setTargetGain(0) }
        runCatching { effect?.enabled = false }
        runCatching { effect?.release() }
        effect = null
        level = 0
        currentMb = 0
    }
}
