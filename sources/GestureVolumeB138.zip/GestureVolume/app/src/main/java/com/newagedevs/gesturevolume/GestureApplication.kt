package com.newagedevs.gesturevolume

import android.app.Application
import com.newagedevs.gesturevolume.utils.DiagLog
import dagger.hilt.android.HiltAndroidApp

/** The application class. Ads, billing and the Play Store prompts are gone from this build. */
@HiltAndroidApp
class GestureApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DiagLog.processStarted(this)
        com.newagedevs.gesturevolume.strip.AutoBackup.refresh(this)
    }
}
