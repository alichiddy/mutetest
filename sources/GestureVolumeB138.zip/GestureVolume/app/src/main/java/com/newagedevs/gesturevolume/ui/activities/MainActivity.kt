package com.newagedevs.gesturevolume.ui.activities

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.newagedevs.gesturevolume.service.OverlayRuntime
import com.newagedevs.gesturevolume.ui.theme.GestureVolumeTheme
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    companion object {
        /** A navigation route to open on arrival, from the Deck's "manage" buttons. */
        const val EXTRA_ROUTE = "route"
    }

    /**
     * The route the Deck asked for, consumed once by the navigation graph.
     *
     * State rather than an argument to the graph, because the Activity is `singleTop` in spirit:
     * the Deck reuses a running instance, and the route then arrives through [onNewIntent] with
     * the composition already up.
     */
    val pendingRoute = mutableStateOf<String?>(null)

    private val viewModel: MainViewModel by viewModels()

    // Bumped in onConfigurationChanged to trigger recomposition with new locale strings
    private val configVersion = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            // Read configVersion so Compose recomposes when locale changes
            val version = configVersion.intValue
            val state by viewModel.state.collectAsState()
            val isDarkTheme = when (state.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }

            GestureVolumeTheme(darkTheme = isDarkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainNavigation()
                }
            }
        }

        // Observe LiveData communicator
        viewModel.observeCommunicator(this)

        // Clips saved by the retired clipboard history are deleted rather than left behind.
        viewModel.preference.removeRetiredClipboardHistory()

        pendingRoute.value = intent?.getStringExtra(EXTRA_ROUTE)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(EXTRA_ROUTE)?.let { pendingRoute.value = it }
    }

    override fun onStart() {
        super.onStart()
        // Before the service is started, not after. `onResume` writes this too, but the service is
        // launched from here — one callback earlier — so a service that comes up promptly draws
        // the bar in the gap between the two and the flag it consults is still false. Setting it
        // first closes that gap: whenever the bar is created from here on, the answer is already
        // recorded. See SharedPref.isAppInForeground.
        // The bar stays visible and working inside this app too, so the foreground flag is never
        // raised and no "hide" is sent.
        viewModel.preference.setAppInForeground(false)
        // Restart the service if the system killed it while the user still wants it running.
        // Doing this from the foreground sidesteps the Android 12+ background-start restrictions.
        viewModel.repairServiceIfNeeded(this)
        // Re-bind to running service if it exists (handles recents-clear scenario)
        viewModel.rebindToServiceIfRunning(this)
    }

    override fun onResume() {
        super.onResume()
        // Written here as well as sent, and before the send. The command only reaches a service
        // that is already up; the flag is what a service starting *after* this point reads, and a
        // cold start is exactly when the bar used to appear on top of the app.
        viewModel.preference.setAppInForeground(false)
        sendServiceCommand("show")
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Bump version to force Compose to recompose with updated locale resources
        configVersion.intValue++
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.removeObserver()
    }

    private fun sendServiceCommand(action: String) {
        // Routed through the runtime, which sends it only while the foreground service is up.
        if (viewModel.preference.isRunning()) {
            OverlayRuntime.sendCommand(this, action)
        }
    }
}
