package com.newagedevs.gesturevolume.clip

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.service.OverlayRuntime

/** Copy options. Nothing listens to the clipboard unless one of them is on. */
class ClipActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var fix by remember { mutableStateOf(prefs.getBoolean(ClipTools.FIX, false)) }
                    var bar by remember { mutableStateOf(prefs.getBoolean(ClipTools.BAR, false)) }
                    var toast by remember { mutableStateOf(prefs.getBoolean(ClipTools.TOAST, false)) }
                    var notice by remember { mutableStateOf(prefs.getBoolean(ClipTools.NOTICE, false)) }
                    var text by remember { mutableStateOf(prefs.getBoolean(ClipTools.SHOW_TEXT, false)) }
                    var toastLong by remember { mutableStateOf(prefs.getBoolean(ClipTools.TOAST_LONG, false)) }
                    var barMs by remember { mutableStateOf(prefs.getInt(ClipTools.BAR_MS, 1500).toString()) }
                    var noticeMs by remember { mutableStateOf(prefs.getInt(ClipTools.NOTICE_MS, 4000).toString()) }
                    fun apply() {
                        prefs.edit().putBoolean(ClipTools.FIX, fix).putBoolean(ClipTools.BAR, bar).putBoolean(ClipTools.TOAST, toast).putBoolean(ClipTools.NOTICE, notice).putBoolean(ClipTools.SHOW_TEXT, text)
                            .putBoolean(ClipTools.TOAST_LONG, toastLong)
                            .putInt(ClipTools.BAR_MS, barMs.toIntOrNull() ?: 1500).putInt(ClipTools.NOTICE_MS, noticeMs.toIntOrNull() ?: 4000).apply()
                        OverlayRuntime.activeController?.refreshClipboard()
                    }
                    Column(
                        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text("Copy options", style = MaterialTheme.typography.titleLarge)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Turn Persian and Arabic digits into 1 2 3 4 5 6 7 8 9 0 when I copy", Modifier.weight(1f))
                            Switch(checked = fix, onCheckedChange = { fix = it; apply() })
                        }
                        Text("۱۲۳ and ١٢٣ become 123 in the copied text, so every app can read the number.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("When I copy, show (any mix, or none):")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(bar, { bar = !bar; apply() }, { Text("On the bar", fontSize = 12.sp) })
                            FilterChip(toast, { toast = !toast; apply() }, { Text("Toast", fontSize = 12.sp) })
                            FilterChip(notice, { notice = !notice; apply() }, { Text("Notification", fontSize = 12.sp) })
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Toast:", fontSize = 13.sp)
                            FilterChip(!toastLong, { toastLong = false; apply() }, { Text("Short", fontSize = 12.sp) })
                            FilterChip(toastLong, { toastLong = true; apply() }, { Text("Long", fontSize = 12.sp) })
                        }
                        androidx.compose.material3.OutlinedTextField(
                            value = barMs, onValueChange = { barMs = it.filter(Char::isDigit).take(6); apply() },
                            label = { Text("Bar message stays (milliseconds)") }, singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        androidx.compose.material3.OutlinedTextField(
                            value = noticeMs, onValueChange = { noticeMs = it.filter(Char::isDigit).take(6); apply() },
                            label = { Text("Notification stays (milliseconds)") }, singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Show the copied text (otherwise just \"Copied\")", Modifier.weight(1f))
                            Switch(checked = text, onCheckedChange = { text = it; apply() })
                        }
                        Text(
                            "Copies made in other apps: Android hides the clipboard from background apps, so A cannot see them by itself. Use the LeanType A keyboard: it reports every copy to A, converts the digits itself, and these options then decide what A shows. Without that keyboard, put the action \"Clipboard: convert digits and show what is copied, now\" on a cell, tile or gesture.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            "Passwords copied from a password manager are never touched or shown. ",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}
