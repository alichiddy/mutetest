package com.newagedevs.gesturevolume.utils

import android.content.Context

/**
 * Where the result of a shell command run from a shortcut is shown: bar, toast, notification, any mix.
 * Set in the Shell runner window. Nothing is kept in memory; it reads the saved choice when a command ends.
 */
object ShellFeedback {
    private const val PREFS = "shellFeedback"
    fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun show(c: Context, text: String) {
        val p = prefs(c)
        val bar = p.getBoolean("bar", true); val toast = p.getBoolean("toast", false); val notice = p.getBoolean("notice", false)
        if (bar) com.newagedevs.gesturevolume.service.OverlayRuntime.activeController
            ?.showIndicatorMessage(text, p.getInt("barMs", 3000).toLong().coerceIn(200L, 60000L))
        if (toast) runCatching {
            android.widget.Toast.makeText(c, text, if (p.getBoolean("toastLong", false)) android.widget.Toast.LENGTH_LONG else android.widget.Toast.LENGTH_SHORT).show()
        }
        if (notice) runCatching {
            val nm = c.getSystemService(android.app.NotificationManager::class.java)
            nm.createNotificationChannel(android.app.NotificationChannel("shellout", "Shell results", android.app.NotificationManager.IMPORTANCE_LOW))
            nm.notify(7315, android.app.Notification.Builder(c, "shellout")
                .setSmallIcon(android.R.drawable.ic_menu_info_details).setContentTitle("Shell").setContentText(text.take(300))
                .setStyle(android.app.Notification.BigTextStyle().bigText(text.take(600)))
                .setTimeoutAfter(p.getInt("noticeMs", 4000).toLong().coerceIn(500L, 600000L)).setAutoCancel(true).build())
        }
    }
}
