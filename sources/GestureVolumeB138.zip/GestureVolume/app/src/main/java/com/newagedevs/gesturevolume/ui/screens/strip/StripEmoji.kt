package com.newagedevs.gesturevolume.ui.screens.strip

/**
 * The picker's emoji (tools, devices, symbols; no faces or hands) with the words they are found
 * by. Drawn by the system font, so they take no storage of their own. Only the ones this phone's
 * font can draw are shown.
 */
private const val RAW = """
⏻|power on off button
⭘|power off circle ring
⏼|power sleep
⏽|power on
⭕|circle ring off red
🔌|plug electric power cable charge
🔋|battery full charge power
🪫|battery low empty
⚡|lightning bolt electric power fast
🔦|flashlight torch light
💡|bulb idea light lamp
🔆|bright brightness high sun
🔅|dim brightness low
☀️|sun day light
🌙|moon night dark sleep
⭐|star favorite
✨|sparkle clean new
🔥|fire hot burn
💧|drop water wet
❄️|snow cold freeze ice
🌡️|thermometer temperature
📶|signal bars network cellular wifi
📡|antenna satellite signal dish
🛜|wifi wireless network
📍|pin location place map
🧭|compass direction qibla
🗺️|map world route
✈️|airplane flight mode plane airport
🚗|car drive
🚀|rocket launch boost fast
🛡️|shield security protect vpn
🔒|lock locked secure
🔓|unlock unlocked open
🔐|lock key secure
🔑|key password
🗝️|old key
🚫|prohibited forbidden block no
⛔|no entry stop block
🛑|stop sign octagon
✅|check done ok yes
❌|cross no cancel close x
✔️|check mark ok
✖️|multiply close x
❗|exclamation alert important
❓|question help
ℹ️|info information
⚠️|warning caution
🔔|bell notification ring
🔕|bell off silent mute notification
🔊|speaker loud volume high sound
🔉|speaker medium volume
🔈|speaker low volume
🔇|mute silent speaker off
📢|loudspeaker announce boost
📣|megaphone cheer boost
🎵|music note song
🎶|music notes song
🎤|microphone mic voice record
🎧|headphones earphones audio
📻|radio
📺|tv television
🎬|clapper movie film
🎮|game controller play
🕹️|joystick game
📷|camera photo
📸|camera flash photo screenshot
📹|video camera record
🎥|movie camera film
🖼️|picture frame image
🔍|search magnifier find zoom
🔎|search magnifier right find
🔬|microscope science
🔭|telescope
🧪|test tube lab
🧰|toolbox tools
🔧|wrench tool fix settings
🔨|hammer tool build
🪛|screwdriver tool
🪚|saw tool
⚙️|gear settings cog options
🛠️|tools hammer wrench settings build
⛏️|pick tool
🧲|magnet
🧮|abacus calculator math
🔢|numbers digits
🔤|abc letters text
🔠|capital letters text
🔡|small letters text
📝|memo note write edit
✏️|pencil edit write
🖊️|pen write
🖋️|fountain pen write
📋|clipboard paste copy list
📄|page document file
📃|page curl document
📑|pages bookmark tabs
📁|folder files
📂|open folder files
🗂️|dividers folders index
🗃️|card file box archive
🗑️|trash bin delete rubbish
📥|inbox download receive
📤|outbox upload send
📦|package box parcel
📬|mailbox mail
✉️|envelope mail message
📧|email mail
💬|speech chat message sms
🗨️|speech bubble chat
📞|phone call receiver
☎️|telephone call
📱|mobile phone smartphone
💻|laptop computer
🖥️|desktop computer screen monitor
⌨️|keyboard type
🖱️|mouse computer click
🖨️|printer print
💾|floppy save disk
💿|cd disc
📀|dvd disc
☁️|cloud online drive
⬆️|up arrow
⬇️|down arrow
⬅️|left arrow back
➡️|right arrow next
↩️|return back undo
↪️|forward redo
🔄|refresh reload sync arrows
🔃|refresh clockwise sync
🔁|repeat loop
🔂|repeat once
🔀|shuffle random mix
▶️|play start
⏸️|pause
⏹️|stop
⏯️|play pause
⏺️|record
⏭️|next track skip
⏮️|previous track
⏩|fast forward
⏪|rewind
⏏️|eject
🔼|up
🔽|down
➕|plus add
➖|minus remove
➗|divide
💲|dollar money price
💰|money bag
💵|cash dollar
🏦|bank
💳|credit card pay
🧾|receipt bill
🪙|coin toss
🕐|clock time one
⏰|alarm clock wake
⏱️|stopwatch timer
⏲️|timer clock
⌛|hourglass wait time
⏳|hourglass flowing wait
📅|calendar date
📆|calendar tear date
🗓️|calendar spiral date
🏠|home house
🏢|office building
🏪|shop store
🛒|cart shopping
🛍️|shopping bags
🎁|gift present
🎯|target aim dart
🎲|dice game random
🃏|joker card game
🧩|puzzle piece
♟️|chess pawn
🎨|palette art colors theme
🖌️|paintbrush paint
📚|books library read
📖|book open read quran
🎓|graduation study
🌍|earth globe world europe
🌎|earth americas world
🌏|earth asia world
🌐|globe internet web network
🌈|rainbow
☔|rain umbrella weather
⛅|cloud sun weather
🌊|wave sea water
🔴|red circle record
🟠|orange circle
🟡|yellow circle
🟢|green circle on
🔵|blue circle
🟣|purple circle
⚫|black circle
⚪|white circle
🔘|radio button toggle switch
🟥|red square
🟧|orange square
🟨|yellow square
🟩|green square
🟦|blue square
🟪|purple square
⬛|black square
⬜|white square
🔳|qr code square scan
🔲|black square button
♻️|recycle
🆘|sos help emergency
🆗|ok
🆒|cool
🆕|new
🔛|on arrow
🔙|back arrow
🔝|top arrow
🔚|end arrow
🔜|soon arrow
🔰|beginner
☑️|checked box
🏁|finish flag race
🚩|flag red
🏳️|white flag
📌|pushpin pin
📎|paperclip attach
🖇️|linked paperclips attach
🔗|link chain url
⛓️|chains link
🧷|safety pin
🪄|magic wand
🔮|crystal ball
🎭|masks theater
🧿|nazar amulet
🕌|mosque prayer islam
🕋|kaaba mecca qibla
📿|prayer beads tasbih
🕯️|candle light
🪔|lamp diya
🔏|lock pen sign
🧯|extinguisher fire
🪜|ladder
🧱|brick wall firewall
⛽|fuel pump gas
🚦|traffic light
🚥|traffic light horizontal
🔱|trident
⚓|anchor
🪝|hook
🧵|thread
🧶|yarn
📐|ruler triangle measure
📏|ruler straight measure
✂️|scissors cut
📊|chart bar stats
📈|chart up growth
📉|chart down
🧬|dna
⚖️|scale balance law
🔖|bookmark save
🏷️|label tag
💎|gem diamond
🎙️|studio microphone podcast
🎚️|slider level volume
🎛️|control knobs mixer
📲|phone arrow receive call
📳|vibration mode
📴|mobile phone off
🪟|window
🚪|door
🪑|chair
🛏️|bed sleep
🛋️|couch
🚿|shower
🧹|broom clean sweep
🧼|soap clean
🧽|sponge clean
🪥|toothbrush
🖲️|trackball
🕰️|mantelpiece clock
📟|pager
📠|fax
🛰️|satellite gps
🛸|saucer ufo
🪐|planet
☄️|comet
🌠|shooting star
🌀|cyclone swirl
💤|zzz sleep
💢|anger
💥|collision boom
💫|dizzy
"""

internal class EmojiEntry(val emoji: String, val words: String)

internal val StripEmojiEntries: List<EmojiEntry> = RAW.trim().lines().mapNotNull {
    val i = it.indexOf('|')
    if (i <= 0) null else EmojiEntry(it.substring(0, i), it.substring(i + 1).lowercase())
}

/** Kept for places that only need the characters. */
internal val StripEmoji: List<String> = StripEmojiEntries.map { it.emoji }

/** The ones this phone's font can really draw (checked once). */
internal fun drawableEmoji(): List<EmojiEntry> {
    val p = android.graphics.Paint()
    return StripEmojiEntries.filter { p.hasGlyph(it.emoji) }
}

/** A plain recycling grid of emoji: much lighter than hundreds of Compose cells. */
internal class EmojiAdapter(private val items: List<String>) : android.widget.BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
        val tv = (convertView as? android.widget.TextView) ?: android.widget.TextView(parent.context).apply {
            textSize = 28f
            gravity = android.view.Gravity.CENTER
            layoutParams = android.widget.AbsListView.LayoutParams(-1, (52 * resources.displayMetrics.density).toInt())
            includeFontPadding = false
        }
        tv.text = items[position]
        return tv
    }
}
