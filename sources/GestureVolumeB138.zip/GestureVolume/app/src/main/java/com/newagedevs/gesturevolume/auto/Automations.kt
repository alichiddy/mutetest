package com.newagedevs.gesturevolume.auto

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import com.newagedevs.gesturevolume.flow.FlowRunner
import com.newagedevs.gesturevolume.flow.FlowStore
import com.newagedevs.gesturevolume.flow.Step
import org.json.JSONArray
import org.json.JSONObject

/** One rule: when [trigger] happens (and [arg] matches), run the flow called [flow]. */
data class AutoRule(val trigger: String, val arg: String, val flow: String, val enabled: Boolean = true)

object AutoTriggers {
    const val SMS = "sms"            // arg: only texts whose sender contains this (empty = all)
    const val APP_OPEN = "app_open"  // arg: package name
    const val UNLOCK = "unlock"
    const val CHARGER_ON = "charger_on"
    const val CHARGER_OFF = "charger_off"
    const val WIFI = "wifi"          // connected to Wi-Fi
    const val PKG_ADDED = "pkg_added"
    val all = listOf(SMS, APP_OPEN, UNLOCK, CHARGER_ON, CHARGER_OFF, WIFI, PKG_ADDED)
    fun label(t: String) = when (t) {
        SMS -> "Text message arrives"
        APP_OPEN -> "App is opened"
        UNLOCK -> "Phone unlocked"
        CHARGER_ON -> "Charger plugged in"
        CHARGER_OFF -> "Charger unplugged"
        WIFI -> "Connected to Wi-Fi"
        PKG_ADDED -> "App installed"
        else -> t
    }
    fun argHint(t: String) = when (t) {
        SMS -> "Sender contains (empty = any)"
        APP_OPEN -> "Package name, e.g. ir.nasim"
        else -> ""
    }
}

object AutoStore {
    private fun prefs(c: Context) = c.getSharedPreferences("AutoRules", Context.MODE_PRIVATE)

    fun load(c: Context): List<AutoRule> = runCatching {
        val arr = JSONArray(prefs(c).getString("rules", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            AutoRule(o.getString("t"), o.optString("a"), o.getString("f"), o.optBoolean("e", true))
        }
    }.getOrDefault(emptyList())

    fun save(c: Context, rules: List<AutoRule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(JSONObject().put("t", it.trigger).put("a", it.arg).put("f", it.flow).put("e", it.enabled)) }
        prefs(c).edit().putString("rules", arr.toString()).apply()
    }

    /** The flow the "Copy OTP" quick rule runs. Only added when missing, so the user's edits stay. */
    fun ensureFlows(c: Context) {
        if (FlowStore.names(c).contains("CopyOTP")) return
        FlowStore.save(c, "CopyOTP", listOf(
            Step(Step.NOTE, "Runs when a text arrives. {otp} is the first 4–8 digit code in it, {message} is the whole text, {sender} who sent it."),
            Step(Step.IF, "{otp}", "!=", ""),
            Step(Step.ACTION, "clip_set", "{otp}"),
            Step(Step.MESSAGE, "Code {otp} copied"),
            Step(Step.END),
        ))
    }
}

object Automations {
    private var started = false
    private val main = Handler(Looper.getMainLooper())

    fun start(context: Context) {
        val app = context.applicationContext
        synchronized(this) { if (started) return; started = true }
        runCatching {
            // PACKAGE_ADDED needs the "package" data scheme, the others have none: two filters.
            val plain = IntentFilter().apply {
                addAction(Intent.ACTION_USER_PRESENT)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }
            val pkg = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
            val rx = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    when (i.action) {
                        Intent.ACTION_USER_PRESENT -> fire(app, AutoTriggers.UNLOCK, "", mapOf())
                        Intent.ACTION_POWER_CONNECTED -> fire(app, AutoTriggers.CHARGER_ON, "", mapOf())
                        Intent.ACTION_POWER_DISCONNECTED -> fire(app, AutoTriggers.CHARGER_OFF, "", mapOf())
                        Intent.ACTION_PACKAGE_ADDED -> {
                            if (i.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
                            val p = i.data?.schemeSpecificPart ?: return
                            fire(app, AutoTriggers.PKG_ADDED, p, mapOf("package" to p))
                        }
                    }
                }
            }
            androidx.core.content.ContextCompat.registerReceiver(app, rx, plain, androidx.core.content.ContextCompat.RECEIVER_EXPORTED)
            androidx.core.content.ContextCompat.registerReceiver(app, rx, pkg, androidx.core.content.ContextCompat.RECEIVER_EXPORTED)
        }
        runCatching {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
            cm.registerNetworkCallback(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { fire(app, AutoTriggers.WIFI, "", mapOf()) }
            })
        }
        Thread { pollForegroundApp(app) }.apply { isDaemon = true; name = "auto-poll" }.start()
    }

    /** Foreground app by usage stats, checked every 2 s while the screen is on and an app rule exists. */
    private fun pollForegroundApp(app: Context) {
        val usm = app.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        var last = ""
        var since = System.currentTimeMillis()
        while (true) {
            try {
                val wanted = AutoStore.load(app).filter { it.enabled && it.trigger == AutoTriggers.APP_OPEN }
                if (wanted.isEmpty() || !pm.isInteractive) { Thread.sleep(4000); since = System.currentTimeMillis(); continue }
                val now = System.currentTimeMillis()
                val ev = usm.queryEvents(since - 1000, now)
                val e = UsageEvents.Event()
                while (ev.hasNextEvent()) {
                    ev.getNextEvent(e)
                    if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != last) {
                        last = e.packageName
                        if (wanted.any { it.arg == last }) fire(app, AutoTriggers.APP_OPEN, last, mapOf("package" to last))
                    }
                }
                since = now
                Thread.sleep(2000)
            } catch (_: InterruptedException) { return } catch (_: Throwable) { try { Thread.sleep(5000) } catch (_: InterruptedException) { return } }
        }
    }

    /** Finds the first 4–8 digit code in [text], or "". */
    fun otpOf(text: String): String = Regex("(?<![0-9])[0-9]{4,8}(?![0-9])").find(text)?.value ?: ""

    fun fire(context: Context, trigger: String, value: String, extra: Map<String, String>) {
        val app = context.applicationContext
        val rules = AutoStore.load(app).filter { r ->
            r.enabled && r.trigger == trigger && when (trigger) {
                AutoTriggers.SMS -> r.arg.isBlank() || (extra["sender"] ?: "").contains(r.arg, ignoreCase = true)
                AutoTriggers.APP_OPEN -> r.arg == value
                else -> true
            }
        }
        rules.forEach { r ->
            Thread {
                val vars = HashMap<String, String>(extra)
                vars["trigger"] = trigger
                if (trigger == AutoTriggers.SMS) vars["otp"] = otpOf(extra["message"] ?: "")
                FlowRunner.run(app, r.flow, log = {}, message = { t ->
                    main.post { Toast.makeText(app, t, Toast.LENGTH_SHORT).show() }
                }, vars = vars)
            }.start()
        }
    }
}

/** Receives texts even when the app is closed. Needs the RECEIVE_SMS permission (granted by "Grant permissions" or the Automations screen). */
class SmsRuleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED") return
        val msgs = android.provider.Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val sender = msgs[0].originatingAddress ?: ""
        val body = msgs.joinToString("") { it.messageBody ?: "" }
        val pending = goAsync()
        Thread {
            try { Automations.fire(context, AutoTriggers.SMS, sender, mapOf("sender" to sender, "message" to body)) }
            finally { Thread.sleep(3000); pending.finish() }
        }.start()
    }
}
