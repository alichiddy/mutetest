package com.newagedevs.gesturevolume.ui.screens.menu

import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.automirrored.filled.List
import com.newagedevs.gesturevolume.ui.components.ChoiceChip
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import com.newagedevs.gesturevolume.ui.components.Tutorial
import com.newagedevs.gesturevolume.ui.components.TutorialAction
import com.newagedevs.gesturevolume.ui.motion.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.newagedevs.gesturevolume.R
import com.newagedevs.gesturevolume.overlay.ContextMenuCard
import com.newagedevs.gesturevolume.overlay.panelFrame
import com.newagedevs.gesturevolume.overlay.rememberPanelEntrance
import com.newagedevs.gesturevolume.ui.components.HandleLook
import com.newagedevs.gesturevolume.ui.components.ActionIconImage
import com.newagedevs.gesturevolume.ui.components.DemoGesture
import com.newagedevs.gesturevolume.ui.components.GestureDemoOverlay
import com.newagedevs.gesturevolume.ui.components.HowItWorksAction
import com.newagedevs.gesturevolume.ui.components.scaleToFit
import com.newagedevs.gesturevolume.ui.components.rememberGestureDemoState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.graphics.graphicsLayer
import com.newagedevs.gesturevolume.ui.components.PanelAnimationSelector
import com.newagedevs.gesturevolume.ui.components.PanelThemeSelector
import com.newagedevs.gesturevolume.ui.components.PermissionNote
import com.newagedevs.gesturevolume.ui.components.PreviewSettingsLayout
import com.newagedevs.gesturevolume.ui.components.PreviewStage
import com.newagedevs.gesturevolume.ui.components.panelAnimationLabel
import com.newagedevs.gesturevolume.ui.components.panelAnimationSpeedLabel
import com.newagedevs.gesturevolume.ui.components.panelThemeLabel
import com.newagedevs.gesturevolume.ui.screens.handler_action.SettingSwitchItem
import com.newagedevs.gesturevolume.ui.screens.handler_appearance.AppearanceSection
import com.newagedevs.gesturevolume.ui.screens.handler_appearance.ColorPickerControl
import com.newagedevs.gesturevolume.ui.screens.handler_appearance.SliderControl
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import com.newagedevs.gesturevolume.utils.ContextMenuLayout
import com.newagedevs.gesturevolume.utils.ContextMenuStyle
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions
import com.newagedevs.gesturevolume.utils.PanelTheme
import com.newagedevs.gesturevolume.utils.PermissionNeeds

/**
 * Builds the long-press menu: what is in it, what order it is in, and how it is drawn.
 *
 * **Why a screen and not a dialog.** It was a dialog, and it had outgrown one twice over. Its
 * lower half is a list of roughly thirty available actions, which in a dialog means a scrolling
 * region inside a scrolling region inside a bounded box — and the box has to be bounded, or an
 * `AlertDialog` asked for its intrinsic height is taller than the screen. The upper half is a list
 * the user *arranges*, which wants room to see several rows at once while moving one. Neither
 * survives being squeezed into the middle of the screen with a scrim around it.
 *
 * **Why there is no Apply.** Everything here is written straight through, like the Quick panel's
 * settings screen, and the menu is rebuilt from preferences the next time it opens. There is
 * nothing that can be half applied, so there is nothing to confirm.
 *
 * **Why it opens with a preview.** Everything below it is a list of names, and a name is a poor
 * description of a menu — the questions people actually have are "how big is it?", "does the last
 * row look odd?", "can I read that label?". The preview is the real
 * [com.newagedevs.gesturevolume.overlay.ContextMenuCard], not a drawing of one, so it answers
 * them by construction and cannot drift from the thing it depicts.
 *
 * **Why these groups.** Items, size and shape, colours, animation: the order every panel screen
 * shares, so a setting sits in the same place on each. Collapsible, like the Appearance screen, and
 * the items open, because what is in the menu is the thing most people came to change.
 *
 * One entry cannot be removed: "Hide handler". This menu is the only way to put the bar away from
 * the bar itself, and a picker that let the user delete their last route out would be a trap.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LongPressMenuScreen(
    viewModel: MainViewModel = hiltViewModel(),
    onNavigateBack: () -> Unit,
    onOpenPermissions: (PermissionNeeds.Permission?) -> Unit = {},
) {
    val preference = remember { viewModel.preference }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val shown = remember {
        val placed = preference.getContextMenuOrder()
            .filter { HandlerActionCatalog.entryFor(it) != null }
        // The pinned entries are seeded in if the stored order does not name them. The menu adds
        // them anyway when it is drawn — see HandlerActionCatalog.contextMenuEntries — so without
        // this the screen would list "Hide handler" as available while the menu already shows it.
        val missing = HandlerActions.ALWAYS_IN_CONTEXT_MENU.filterNot { it in placed }
        (placed + missing).toMutableStateList()
    }
    var layout by remember { mutableStateOf(preference.getContextMenuLayout()) }
    var menuWidth by remember { mutableFloatStateOf(preference.getContextMenuWidthDp()) }
    var menuHeight by remember { mutableFloatStateOf(preference.getContextMenuHeightDp()) }
    var menuLines by remember { mutableStateOf(preference.getContextMenuLines()) }
    var perPage by remember { mutableIntStateOf(preference.getContextMenuPerPage()) }
    val menuStyle = ContextMenuStyle(menuWidth, menuHeight, menuLines, perPage)
    var panelTheme by remember { mutableStateOf(preference.getPanelTheme()) }
    var panelAnimation by remember { mutableStateOf(preference.getPanelAnimation()) }
    var animationSpeed by remember { mutableFloatStateOf(preference.getPanelAnimationSpeed()) }
    var menuColor by remember { mutableStateOf(preference.getMenuColor()?.let { Color(it) }) }
    var menuAlpha by remember { mutableIntStateOf(preference.getMenuAlpha()) }
    val menuSurface = remember(menuColor, menuAlpha) {
        menuColor?.let { ((menuAlpha.toLong() and 0xFF) shl 24) or (it.toArgb().toLong() and 0xFFFFFF) }
    }

    // Re-read on return, for the notes beside entries that need a permission granted elsewhere.
    var permissionTick by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) permissionTick++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Bumped whenever the entrance is picked, which is what makes the preview play it again.
    var replay by remember { mutableIntStateOf(0) }
    val entrance = rememberPanelEntrance(
        animation = panelAnimation,
        towardLeft = preference.getHandlerPosition() == "Left",
        replayKey = replay,
        speed = animationSpeed,
    )


    // A finger pressing and holding the bar until the menu pops up, twice on arrival and on request
    // after that. The menu waits for the ring to close rather than following it in, because that
    // is how the real one behaves: nothing, and then the menu.
    val handlerOnLeft = remember { preference.getHandlerPosition() == "Left" }
    val gestureDemo = rememberGestureDemoState(MENU_DEMO_STEPS)
    val menuUp by remember { derivedStateOf { gestureDemo.progressOf(DemoGesture.HOLD) >= 1f } }
    val menuPop by animateFloatAsState(
        targetValue = if (menuUp) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 480f),
        label = "demoMenuPop",
    )

    fun persist() = preference.setContextMenuOrder(shown.toList())

    val available = HandlerActionCatalog.CONTEXT_MENU_CANDIDATES.filterNot { it.action in shown }

    Scaffold(
        // The top bar is clear, on the plain page as the preview under it is.
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.context_menu_title)) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, tooltip = stringResource(R.string.back)) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back)
                        )
                    }
                },
                actions = {
                    TutorialAction(Tutorial.MENU)
                    HowItWorksAction(gestureDemo)
                },
                // Transparent, as every other screen's: a surface-coloured bar stood out as a band
                // against the page in the dark theme.
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { padding ->
        // Preview pinned, controls scrolling beside or beneath it. The menu is the one panel whose
        // settings all change how it *looks*, so losing sight of it while you change them is the
        // worst possible arrangement.
        PreviewSettingsLayout(
            contentPadding = padding,
            hint = stringResource(R.string.context_menu_desc),
            preview = { modifier, fillHeight ->
                // As a list, at its own size and from under the status bar down, running off the
                // bottom of the phone as a long one does on the real screen: fitted to the glass, a
                // list of many actions was too small to read.
                val list = layout != ContextMenuLayout.GRID
                PreviewStage(
                    fillHeight = fillHeight,
                    naturalSize = list,
                    contentAlignment = if (list) Alignment.TopCenter else Alignment.Center,
                    modifier = modifier,
                    // The hand reaches in over the frame, as the walkthrough's does.
                    overGlass = {
                        GestureDemoOverlay(
                            state = gestureDemo,
                            barAtStart = handlerOnLeft,
                            barInset = 12.dp,
                            showBar = true,
                            handle = remember { HandleLook.from(preference) },
                            modifier = Modifier.matchParentSize(),
                        )
                    },
                    // What the finger is doing, on the stage while the demo plays.
                    demo = gestureDemo,
                ) {
                    ContextMenuCard(
                        entries = HandlerActionCatalog.contextMenuEntries(shown.toList()),
                        grid = layout == ContextMenuLayout.GRID,
                        // Inert. This is a picture of the menu, and a tile that ran its action
                        // from the settings screen would be a trap rather than a convenience.
                        onSelect = {},
                        // Measured at its own size, as the real one is, and drawn as large as fits
                        // the phone's glass, both ways, under the status bar: the card lays its tiles
                        // out from its own width, and a menu of many actions is taller than the part
                        // of the phone that shows. Its top clear of the status bar and the camera,
                        // which on the glass come down about 36dp of the phone's own.
                        modifier = Modifier
                            .scaleToFit(
                                if (list) 1f else PREVIEW_SCALE,
                                horizontal = 12.dp,
                                top = if (list) 30.dp else 44.dp,
                                bottom = 12.dp,
                                fitHeight = !list,
                            )
                            .panelFrame { entrance.value }
                            // Popped in by the demo's long press; read in the layer so the spring
                            // redraws the card without recomposing the screen.
                            .graphicsLayer {
                                alpha = menuPop.coerceIn(0f, 1f)
                                val grow = 0.82f + 0.18f * menuPop
                                scaleX = grow
                                scaleY = grow
                            },
                        theme = panelTheme,
                        surfaceOverride = menuSurface,
                        style = menuStyle,
                    )
                }
            },
        ) {
            val grid = layout == ContextMenuLayout.GRID

            // ---- size & shape: its layout, its size, and how it is divided ----------------------
            AppearanceSection(
                title = stringResource(R.string.section_size_shape),
                icon = Icons.Filled.AspectRatio,
                summary = "${menuWidth.toInt()} × ${menuHeight.toInt()}dp",
                initiallyExpanded = true,
            ) {
                SectionLabel(stringResource(R.string.context_menu_layout))
                LayoutSelector(
                    layout = layout,
                    onLayoutChange = {
                        layout = it
                        preference.setContextMenuLayout(it)
                    },
                )

                Sep()
                SliderControl(
                    label = stringResource(R.string.context_menu_width),
                    value = menuWidth,
                    valueRange = ContextMenuLayout.WIDTH_RANGE,
                    valueDisplay = "${menuWidth.toInt()}dp",
                    borderColor = MaterialTheme.colorScheme.primary,
                    onValueChange = { menuWidth = it },
                    onValueChangeFinished = { preference.setContextMenuWidthDp(menuWidth) },
                    step = 2f,
                )
                if (grid) {
                    Text(
                        text = stringResource(R.string.context_menu_columns, ContextMenuLayout.columnsFor(menuWidth)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                Spacer(Modifier.height(12.dp))
                SliderControl(
                    label = stringResource(R.string.context_menu_height),
                    value = menuHeight,
                    valueRange = ContextMenuLayout.HEIGHT_RANGE,
                    valueDisplay = "${menuHeight.toInt()}dp",
                    borderColor = MaterialTheme.colorScheme.primary,
                    onValueChange = { menuHeight = it },
                    onValueChangeFinished = { preference.setContextMenuHeightDp(menuHeight) },
                    step = 4f,
                )
                Text(
                    text = stringResource(R.string.context_menu_height_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )

                Sep()
                SectionLabel(stringResource(R.string.context_menu_lines))
                ChoiceChips(
                    options = if (grid) ContextMenuLayout.GRID_LINES else ContextMenuLayout.LIST_LINES,
                    selected = ContextMenuLayout.linesFor(menuLines, grid),
                    label = { stringResource(linesLabel(it)) },
                    onSelect = { menuLines = it; preference.setContextMenuLines(it) },
                )

                if (grid) {
                    Sep()
                    SectionLabel(stringResource(R.string.context_menu_per_page))
                    ChoiceChips(
                        options = ContextMenuLayout.PER_PAGE_CHOICES,
                        selected = perPage,
                        label = {
                            if (it == ContextMenuLayout.PER_PAGE_ALL) {
                                stringResource(R.string.context_menu_per_page_all)
                            } else {
                                it.toString()
                            }
                        },
                        onSelect = { perPage = it; preference.setContextMenuPerPage(it) },
                    )
                    Text(
                        text = stringResource(R.string.context_menu_per_page_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---- what is in it ------------------------------------------------------------------
            AppearanceSection(
                title = stringResource(R.string.section_items),
                icon = Icons.AutoMirrored.Filled.List,
                summary = stringResource(R.string.context_menu_count, HandlerActionCatalog.contextMenuEntries(shown.toList()).size),
            ) {
                SectionLabel(stringResource(R.string.context_menu_shown))
                if (shown.isEmpty()) {
                    Text(
                        text = stringResource(R.string.context_menu_empty),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                shown.forEachIndexed { index, action ->
                    val entry = HandlerActionCatalog.entryFor(action) ?: return@forEachIndexed
                    ShownRow(
                        entry = entry,
                        position = index + 1,
                        pinned = action in HandlerActions.ALWAYS_IN_CONTEXT_MENU,
                        canMoveUp = index > 0,
                        canMoveDown = index < shown.lastIndex,
                        onMoveUp = { shown.move(index, index - 1); persist() },
                        onMoveDown = { shown.move(index, index + 1); persist() },
                        onRemove = { shown.removeAt(index); persist() },
                    )
                    @Suppress("UNUSED_VARIABLE") val tick = permissionTick
                    PermissionNeeds.missingFor(context, preference, action)?.let {
                        PermissionNote(missing = it, onOpenPermissions = onOpenPermissions)
                        Spacer(Modifier.height(4.dp))
                    }
                }

                if (available.isNotEmpty()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                    )
                    SectionLabel(stringResource(R.string.context_menu_hidden))
                    available.forEach { entry ->
                        HiddenRow(
                            entry = entry,
                            onAdd = { shown.add(entry.action); persist() },
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---- colours ------------------------------------------------------------------------
            // The opacity joins the summary only while the menu has a colour of its own; without
            // one the material decides, and a number would describe nothing on screen.
            val themeName = stringResource(panelThemeLabel(panelTheme))
            AppearanceSection(
                title = stringResource(R.string.section_colours),
                icon = Icons.Filled.Palette,
                summary = if (menuColor != null) {
                    "$themeName · ${(menuAlpha / 255f * 100).toInt()}%"
                } else {
                    themeName
                },
            ) {
                PanelThemeSelector(
                    theme = panelTheme,
                    onThemeChange = {
                        panelTheme = it
                        preference.setPanelTheme(it)
                    },
                )

                Sep()
                SettingSwitchItem(
                    title = stringResource(R.string.context_menu_own_colour),
                    description = stringResource(R.string.context_menu_own_colour_desc),
                    checked = menuColor != null,
                    onCheckedChange = { on ->
                        // Seeded from the material's own surface, so turning it on is a starting
                        // point rather than a blank. Turning it off forgets the colour entirely —
                        // see SharedPref.getMenuColor on why absent and default are not the same.
                        val seed = Color((PanelTheme.menuPalette(panelTheme).surface and 0xFFFFFF).toInt() or (0xFF shl 24))
                        menuColor = if (on) seed else null
                        preference.setMenuColor(if (on) seed.toArgb() else null)
                    },
                )
                if (menuColor != null) {
                    Spacer(Modifier.height(12.dp))
                    ColorPickerControl(
                        label = stringResource(R.string.color),
                        color = menuColor ?: Color.Black,
                        borderColor = MaterialTheme.colorScheme.primary,
                        onColorChange = { menuColor = it; preference.setMenuColor(it.toArgb()) },
                    )
                    Spacer(Modifier.height(12.dp))
                    SliderControl(
                        label = stringResource(R.string.opacity),
                        value = menuAlpha.toFloat(),
                        valueRange = 40f..255f,
                        valueDisplay = "${(menuAlpha / 255f * 100).toInt()}%",
                        borderColor = MaterialTheme.colorScheme.primary,
                        onValueChange = { menuAlpha = it.toInt() },
                        onValueChangeFinished = { preference.setMenuAlpha(menuAlpha) },
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            // ---- animation ----------------------------------------------------------------------
            AppearanceSection(
                title = stringResource(R.string.section_animation),
                icon = Icons.Filled.Animation,
                summary = "${stringResource(panelAnimationLabel(panelAnimation))} · ${panelAnimationSpeedLabel(animationSpeed)}",
            ) {
                PanelAnimationSelector(
                    animation = panelAnimation,
                    onAnimationChange = {
                        panelAnimation = it
                        preference.setPanelAnimation(it)
                        // Replays it on the preview above. Picking an entrance from a list of words
                        // is picking blind; the point of the preview is that the word is followed by
                        // the thing it names.
                        replay++
                    },
                    speed = animationSpeed,
                    onSpeedChange = {
                        animationSpeed = it
                        replay++
                    },
                    onSpeedChangeFinished = { preference.setPanelAnimationSpeed(animationSpeed) },
                )
            }

            Spacer(Modifier.height(28.dp))
        }
    }
}

/**
 * How much the preview is shrunk.
 *
 * The menu is drawn at full size and scaled down, rather than given smaller tiles, because the
 * point of showing the real card is that it is the real card — a preview with its own dimensions
 * would be the second implementation this refactor exists to avoid. Eight-tenths keeps a
 * three-row grid inside the stage.
 */
private const val PREVIEW_SCALE = 0.8f


/** A wrapping row of choices, one of them picked. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChoiceChips(
    options: List<T>,
    selected: T,
    label: @Composable (T) -> String,
    onSelect: (T) -> Unit,
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            ChoiceChip(label = label(option), selected = option == selected, onClick = { onSelect(option) })
        }
    }
}

private fun linesLabel(lines: String): Int = when (lines) {
    ContextMenuLayout.LINES_HORIZONTAL -> R.string.context_menu_lines_horizontal
    ContextMenuLayout.LINES_VERTICAL -> R.string.context_menu_lines_vertical
    ContextMenuLayout.LINES_GRID -> R.string.context_menu_lines_grid
    else -> R.string.context_menu_lines_none
}

/** Moves one item without disturbing the rest. */
private fun SnapshotStateList<String>.move(from: Int, to: Int) {
    if (to !in indices) return
    add(to, removeAt(from))
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

@Composable
private fun Sep() {
    HorizontalDivider(
        modifier = Modifier.padding(vertical = 12.dp),
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
    )
}

/** Grid or list, as two halves of one pill. Mirrors the side picker on the Appearance screen. */
@Composable
private fun LayoutSelector(layout: String, onLayoutChange: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
            .padding(3.dp)
            .selectableGroup(),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        LayoutSelectorHalf(
            label = stringResource(R.string.context_menu_layout_grid),
            selected = layout == ContextMenuLayout.GRID,
            onClick = { onLayoutChange(ContextMenuLayout.GRID) },
            modifier = Modifier.weight(1f),
        )
        LayoutSelectorHalf(
            label = stringResource(R.string.context_menu_layout_list),
            selected = layout == ContextMenuLayout.LIST,
            onClick = { onLayoutChange(ContextMenuLayout.LIST) },
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun LayoutSelectorHalf(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Text(
        text = label,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
            .padding(vertical = 10.dp),
        textAlign = TextAlign.Center,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = if (selected) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
    )
}

@Composable
private fun ShownRow(
    entry: HandlerActionCatalog.Entry,
    position: Int,
    pinned: Boolean,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onRemove: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The position, because the order is the point of this list and a row that has just been
        // moved should be able to say where it landed without the user counting.
        Text(
            text = "$position",
            modifier = Modifier.width(20.dp),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
        )
        // The same chip the menu itself puts behind every icon, in this screen's colours. It is
        // what stops a list of settings rows from looking unrelated to the thing it configures.
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center,
        ) {
            ActionIconImage(
                icon = entry.icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(entry.labelRes),
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
            )
            if (pinned) {
                Text(
                    text = stringResource(R.string.context_menu_always),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        IconButton(onClick = onMoveUp, enabled = canMoveUp, modifier = Modifier.size(36.dp), tooltip = stringResource(R.string.context_menu_move_up)) {
            Icon(
                Icons.Default.KeyboardArrowUp,
                contentDescription = stringResource(R.string.context_menu_move_up),
                modifier = Modifier.size(22.dp),
            )
        }
        IconButton(onClick = onMoveDown, enabled = canMoveDown, modifier = Modifier.size(36.dp), tooltip = stringResource(R.string.context_menu_move_down)) {
            Icon(
                Icons.Default.KeyboardArrowDown,
                contentDescription = stringResource(R.string.context_menu_move_down),
                modifier = Modifier.size(22.dp),
            )
        }
        IconButton(onClick = onRemove, enabled = !pinned, modifier = Modifier.size(36.dp), tooltip = stringResource(R.string.context_menu_hide_item)) {
            Icon(
                Icons.Default.Close,
                contentDescription = stringResource(R.string.context_menu_hide_item),
                modifier = Modifier.size(18.dp),
                tint = if (pinned) {
                    MaterialTheme.colorScheme.outlineVariant
                } else {
                    MaterialTheme.colorScheme.error
                },
            )
        }
    }
}

@Composable
private fun HiddenRow(
    entry: HandlerActionCatalog.Entry,
    onAdd: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onAdd)
            .padding(vertical = 10.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center,
        ) {
            ActionIconImage(
                icon = entry.icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = stringResource(entry.labelRes),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
            maxLines = 1,
        )
        Icon(
            Icons.Default.Add,
            contentDescription = stringResource(R.string.context_menu_show_item),
            modifier = Modifier.size(18.dp),
            tint = MaterialTheme.colorScheme.primary,
        )
    }
}

/** The menu's demo: a long press on the bar, which is what opens it. */
private val MENU_DEMO_STEPS = listOf(DemoGesture.HOLD)
