package com.newagedevs.gesturevolume.flow

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Reads an Automate backup (.bak is a zip holding automate.db) and turns every flow into an
 * editable flow here. Automate keeps a flow's blocks in a private binary form, so this reads
 * out what each flow says: its shell commands, web addresses and texts, in the order they
 * appear. Commands become Shell steps, addresses Web steps, everything else Notes you can read
 * and turn into steps. Nothing is kept in memory afterwards.
 */
object AutomateImporter {
    private val commandWords = Regex(
        "^(sh|su|am|pm|cmd|settings|appops|dumpsys|input|svc|wm|getprop|setprop|content|monkey|rish|nohup|" +
            "pgrep|pkill|kill|ls|cat|echo|cp|mv|rm|mkdir|chmod|service|ip|ifconfig|iptables|logcat|" +
            "/system/bin/sh|/system/bin/\\S+|curl|wget|date|sleep|touch|top|ps|df|id|whoami|reboot|dpm|appwidget|locksettings|telephony|bmgr|ndc)(\\s|$)"
    )

    /** Returns how many flows were imported, or throws with a readable message. */
    fun import(context: Context, uri: Uri, onProgress: (String) -> Unit = {}): Int {
        val dir = File(context.cacheDir, "bakimport").apply { deleteRecursively(); mkdirs() }
        val dbFile = File(dir, "automate.db")
        try {
            context.contentResolver.openInputStream(uri)!!.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var found = false
                    while (true) {
                        val e = zip.nextEntry ?: break
                        if (e.name == "automate.db") {
                            dbFile.outputStream().use { zip.copyTo(it) }
                            found = true
                            break
                        }
                    }
                    if (!found) error("This file has no automate.db inside. Is it an Automate backup?")
                }
            }
            val db = SQLiteDatabase.openDatabase(dbFile.path, null, SQLiteDatabase.OPEN_READONLY)
            var count = 0
            db.use {
                val c = it.rawQuery("SELECT title, description, data FROM flows ORDER BY title", null)
                c.use { cur ->
                    while (cur.moveToNext()) {
                        val title = cur.getString(0)?.trim().orEmpty().ifEmpty { "Flow ${count + 1}" }
                        val desc = cur.getString(1).orEmpty()
                        val data = cur.getBlob(2) ?: ByteArray(0)
                        var name = title
                        var n = 2
                        val have = FlowStore.names(context).toSet()
                        while (name in have) name = "$title ($n)".also { n++ }
                        FlowStore.save(context, name, convert(desc, data))
                        onProgress(name)
                        count++
                    }
                }
            }
            return count
        } finally {
            dir.deleteRecursively()
        }
    }

    fun convert(description: String, data: ByteArray): List<Step> {
        val steps = ArrayList<Step>()
        if (description.isNotBlank()) steps.add(Step(Step.NOTE, description.trim()))
        val seen = HashSet<String>()
        val vars = LinkedHashSet<String>()
        for ((kind, text) in scan(data)) {
            when (kind) {
                'v' -> vars.add(text)
                else -> {
                    val t = text.trim()
                    if (t.isEmpty() || t.length < 2 || !seen.add(t)) continue
                    when {
                        t.startsWith("content://com.llamalab") -> {}
                        t.startsWith("http://") || t.startsWith("https://") -> steps.add(Step(Step.HTTP, t, "GET", "answer"))
                        commandWords.containsMatchIn(t) -> steps.add(Step(Step.SHELL, t, "", ""))
                        else -> steps.add(Step(Step.NOTE, t))
                    }
                }
            }
        }
        if (vars.isNotEmpty()) steps.add(Step(Step.NOTE, "Variables used: " + vars.joinToString(", ")))
        return steps
    }

    private fun varint(b: ByteArray, start: Int): Pair<Int, Int>? {
        var r = 0; var s = 0; var i = start
        while (i < b.size && s < 35) {
            val c = b[i++].toInt() and 0xff
            r = r or ((c and 0x7f) shl s); s += 7
            if (c < 0x80) return r to i
        }
        return null
    }

    private fun str(b: ByteArray, at: Int): Pair<String, Int>? {
        val (n, j) = varint(b, at) ?: return null
        if (n < 0 || n > 4000 || n > b.size - j) return null
        val dec = Charsets.UTF_8.newDecoder()
        return try { dec.decode(java.nio.ByteBuffer.wrap(b, j, n)).toString() to (j + n) } catch (e: Exception) { null }
    }

    /** 'l' = text, 'v' = variable name. Tag 212 is a text, 204 a name, 210 a joined text. */
    private fun scan(b: ByteArray): List<Pair<Char, String>> {
        val out = ArrayList<Pair<Char, String>>()
        var i = 5
        while (i < b.size - 1) {
            val x = b[i].toInt() and 0xff
            val y = b[i + 1].toInt() and 0xff
            if (x == 0xd4 && y == 1) {
                str(b, i + 2)?.let { out.add('l' to it.first); i = it.second; continue }
            } else if (x == 0xcc && y == 1) {
                str(b, i + 2)?.let { (s, e) ->
                    if (s.isNotEmpty() && s.all { it.isLetterOrDigit() || it == '_' || it == '.' }) { out.add('v' to s); i = e; continue }
                }
            } else if (x == 0xd2 && y == 1) {
                val (n, j) = varint(b, i + 2) ?: (0 to i + 2)
                if (n in 1..29) {
                    val sb = StringBuilder(); var k = j; var ok = true
                    for (q in 0 until n) {
                        if (k + 1 < b.size && (b[k].toInt() and 0xff) == 0xcc && (b[k + 1].toInt() and 0xff) == 1) {
                            val r = str(b, k + 2); if (r == null) { ok = false; break }
                            sb.append('{').append(r.first).append('}'); k = r.second
                        } else {
                            val r = str(b, k); if (r == null) { ok = false; break }
                            sb.append(r.first); k = r.second
                        }
                    }
                    if (ok) { out.add('l' to sb.toString()); i = k; continue }
                }
            }
            i++
        }
        return out
    }
}
