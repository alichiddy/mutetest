package com.newagedevs.gesturevolume.flow

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File

/**
 * Personal values (tunnel keys, account names, codes) that flows use as {name}. They are kept in a
 * preferences file of their own, so they are NOT part of the settings backup and are never baked
 * into a copy of the app made for someone else.
 */
object PrivateValues {
    /** The blanks the built-in flows expect. The user fills them in once. */
    class Slot(val name: String, val label: String, val hint: String)

    val slots = listOf(
        Slot("wg_tunnel", "WireGuard Tunnel: tunnel name", "Used by the WG cell"),
        Slot("wg_key", "WireGuard Tunnel: key", "The key the tunnel app asks for"),
        Slot("kb_ussd", "Kalabarg: USSD code", "For example *500*1463#"),
        Slot("kb_id1", "Kalabarg: code for the first cell", "Typed after the USSD menu opens"),
        Slot("kb_id2", "Kalabarg: code for the second cell", ""),
        Slot("drive_folder", "Drive upload: folder name", "For example ToShare"),
    )

    private fun prefs(context: Context) = context.getSharedPreferences("PrivateValues", Context.MODE_PRIVATE)

    /** Blanks that came with the imported Automate flows (numbers and codes taken out of them). */
    fun importedSlots(context: Context): List<Slot> = runCatching {
        val arr = org.json.JSONArray(context.getSharedPreferences("AutomateSlots", Context.MODE_PRIVATE).getString("slots", "[]"))
        (0 until arr.length()).map { val o = arr.getJSONObject(it); Slot(o.getString("name"), o.optString("label"), o.optString("hint")) }
    }.getOrDefault(emptyList())

    fun allSlots(context: Context): List<Slot> = slots + importedSlots(context)

    fun all(context: Context): Map<String, String> =
        prefs(context).all.mapNotNull { (k, v) -> (v as? String)?.let { k to it } }.toMap()

    fun get(context: Context, name: String): String = prefs(context).getString(name, "") ?: ""

    fun set(context: Context, name: String, value: String) {
        prefs(context).edit().putString(name, value).apply()
    }

    /** Names the flow uses as {name} that have no value yet. */
    fun missing(context: Context, steps: List<Step>): List<String> {
        val known = allSlots(context).map { it.name }
        val text = steps.joinToString(" ") { it.a + " " + it.b + " " + it.c }
        return known.filter { text.contains("{$it}") && get(context, it).isEmpty() }
    }
}

/** A see-through activity that reads the clipboard (Android hides it from apps in the background). */
class ClipboardProbeActivity : Activity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        NativeActions.clipText = runCatching { cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() }.getOrNull().orEmpty()
        NativeActions.clipLatch?.countDown()
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}

/** Lets the user pick a file, copies it to A's cache and hands back the path. */
class FilePickActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        @Suppress("DEPRECATION")
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) {
            NativeActions.pickLatch?.countDown()
            finish()
            return
        }
        Thread {
            var path = ""
            runCatching {
                var name = "picked_file"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0) ?: name
                }
                val dir = File(cacheDir, "up").also { it.mkdirs() }
                val f = File(dir, name)
                contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
                path = f.path
            }
            NativeActions.pickedPath = path
            NativeActions.pickLatch?.countDown()
            runOnUiThread { finish() }
        }.start()
    }
}

/** How much a running cell talks. Kept in a small file of its own. */
object FlowPrefs {
    const val ALWAYS = 0
    const val PROBLEMS = 1
    const val NEVER = 2

    private fun prefs(context: Context) = context.getSharedPreferences("FlowPrefs", Context.MODE_PRIVATE)

    /** ALWAYS: every result as a bar. PROBLEMS (default): only Message steps and failures. NEVER: only failures. */
    fun mode(context: Context): Int = prefs(context).getInt("barMode", PROBLEMS)
    fun setMode(context: Context, value: Int) { prefs(context).edit().putInt("barMode", value).apply() }
    fun modeName(value: Int) = when (value) { ALWAYS -> "Always"; NEVER -> "Only failures"; else -> "Messages and failures" }
}

/** A message that stays until it is closed, with a Copy button (uploads, long outputs). */
class ResultActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shown = intent.getStringExtra("text").orEmpty()
        title = intent.getStringExtra("title").orEmpty().ifBlank { "Result" }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val body = android.widget.TextView(this).apply {
            this.text = shown
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
            textSize = 14f
        }
        val scroll = android.widget.ScrollView(this).apply { addView(body) }
        val copy = android.widget.Button(this).apply {
            this.text = "Copy"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("A", shown))
                android.widget.Toast.makeText(this@ResultActivity, "Copied", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        val close = android.widget.Button(this).apply { this.text = "Close"; setOnClickListener { finish() } }
        val row = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            addView(copy, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
            addView(close, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
        }
        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(scroll, android.widget.LinearLayout.LayoutParams(-1, 0, 1f))
            addView(row)
        }
        setContentView(col)
    }

    companion object {
        fun show(context: Context, title: String, text: String) {
            context.startActivity(
                Intent(context, ResultActivity::class.java)
                    .putExtra("title", title).putExtra("text", text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
