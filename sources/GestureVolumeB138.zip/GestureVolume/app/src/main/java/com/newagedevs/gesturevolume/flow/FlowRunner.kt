package com.newagedevs.gesturevolume.flow

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.net.HttpURLConnection
import java.net.URL

/**
 * Runs a flow on its own thread and is gone when it ends. [log] gets one line per thing that
 * happens, [message] is where a Message step shows its text.
 */
object FlowRunner {
    @Volatile private var stopAll = false

    fun stop() { stopAll = true }

    fun run(
        context: Context, name: String, log: (String) -> Unit,
        message: (String) -> Unit = {}, vars: MutableMap<String, String> = HashMap(), depth: Int = 0,
    ) {
        if (depth == 0) {
            stopAll = false
            // Personal values (keys, codes) are filled in as {name}; flow variables of the same name win.
            PrivateValues.all(context).forEach { (k, v) -> vars.putIfAbsent(k, v) }
        }
        // A "goto" Run step hands over to another flow without growing the stack (loops, joins).
        var cur = name
        var hops = 0
        while (true) {
            val next = runOnce(context, cur, log, message, vars, depth) ?: return
            if (stopAll || ++hops > 20_000) return
            cur = next
        }
    }

    private fun runOnce(
        context: Context, name: String, log: (String) -> Unit,
        message: (String) -> Unit, vars: MutableMap<String, String>, depth: Int,
    ): String? {
        if (depth > 8) { log("Too many flows inside flows."); return null }
        val steps = FlowStore.load(context, name)
        if (steps.isEmpty()) { log("Flow '$name' is empty or missing."); return null }
        // For each if/else/repeat, where its else and its end are.
        val end = IntArray(steps.size) { -1 }
        val els = IntArray(steps.size) { -1 }
        val open = ArrayDeque<Int>()
        steps.forEachIndexed { i, s ->
            when (s.type) {
                Step.IF, Step.REPEAT -> open.addLast(i)
                Step.ELSE -> open.lastOrNull()?.let { els[it] = i }
                Step.END -> open.removeLastOrNull()?.let { end[it] = i; end[i] = it }
            }
        }
        val counters = HashMap<Int, Int>()
        val lists = HashMap<Int, List<Any?>>()
        fun sub(t: String): String {
            var r = t
            vars.forEach { (k, v) -> r = r.replace("{$k}", v) }
            return r
        }
        var i = 0
        var guard = 0
        while (i < steps.size && !stopAll) {
            if (++guard > 100_000) { log("Stopped: too many steps."); return null }
            val s = steps[i]
            try {
                when (s.type) {
                    Step.SHELL -> {
                        val out = StringBuilder()
                        val code = ShizukuShell.run(sub(s.a)) { line -> out.append(line).append('\n'); log(line) }
                        vars["code"] = code.toString()
                        vars[s.b.ifEmpty { "out" }] = out.toString().trim()
                    }
                    Step.WAIT -> Thread.sleep((if (s.c == "expr") Expr.num(evalExpr(context, s.a, vars)).toLong() else sub(s.a).toDoubleOrNull()?.toLong() ?: 0L).coerceAtLeast(0L))
                    Step.MESSAGE -> {
                        val text = sub(s.a)
                        log(text)
                        if (s.c == "window") ResultActivity.show(context, name, text)
                        else if (FlowPrefs.mode(context) != FlowPrefs.NEVER) message(text)
                    }
                    Step.LAUNCH -> context.packageManager.getLaunchIntentForPackage(sub(s.a))
                        ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { context.startActivity(it) }
                        ?: log("App not found: ${s.a}")
                    Step.INTENT -> context.startActivity(
                        Intent.parseUri(sub(s.a), Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    Step.SET -> vars[s.a] = if (s.c == "expr") Expr.text(evalExpr(context, s.b, vars)) else sub(s.b)
                    Step.IF -> if (!(if (s.b == "expr") Expr.truth(evalExpr(context, s.a, vars)) else test(sub(s.a), s.b, sub(s.c)))) {
                        // Jump to the else branch, or past the end.
                        i = if (els[i] >= 0) els[i] else end[i]
                    }
                    Step.ELSE -> i = findEndOfElse(steps, i)
                    Step.REPEAT -> if (s.b == "each") {
                        // a = the list, c = variable for the element ("item" if empty); also {index}
                        val list = lists.getOrPut(i) { Expr.asList(evalExpr(context, s.a, vars)) ?: emptyList() }
                        val k = counters.getOrPut(i) { 0 }
                        if (k >= list.size) { counters.remove(i); lists.remove(i); i = end[i] }
                        else { vars[s.c.ifEmpty { "item" }] = Expr.text(list[k]); vars["index"] = (k + 1).toString(); counters[i] = k + 1 }
                    } else {
                        val n = counters.getOrPut(i) { sub(s.a).toIntOrNull() ?: 1 }
                        if (n <= 0) { counters.remove(i); i = end[i] } else counters[i] = n - 1
                    }
                    Step.END -> {
                        val head = end[i]
                        if (head >= 0 && steps[head].type == Step.REPEAT && steps[head].b == "each") i = head - 1
                        else if (head >= 0 && steps[head].type == Step.REPEAT && (counters[head] ?: 0) > 0) i = head - 1
                        else if (head >= 0 && steps[head].type == Step.REPEAT) counters.remove(head)
                    }
                    Step.HTTP -> {
                        val c = URL(sub(s.a)).openConnection() as HttpURLConnection
                        c.requestMethod = s.b.ifEmpty { "GET" }
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        val text = (if (c.responseCode < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                        vars["status"] = c.responseCode.toString()
                        vars[s.c.ifEmpty { "answer" }] = text
                        c.disconnect()
                    }
                    Step.RUN -> if (s.b == "goto") return sub(s.a)
                    else if (s.b == "async") {
                        val copy = HashMap(vars); val target = sub(s.a)
                        Thread { run(context, target, log, message, copy, depth + 1) }.start()
                    } else run(context, sub(s.a), log, message, vars, depth + 1)
                    Step.STOP -> return null
                    Step.ACTION -> {
                        try {
                            val result = NativeActions.run(context, s.a, sub(s.b), vars)
                            if (result.isNotBlank()) {
                                log(result)
                                if (NativeActions.staysOnScreen(s.a, result)) ResultActivity.show(context, name, result)
                                else if (FlowPrefs.mode(context) == FlowPrefs.ALWAYS && (steps.size == 1 || i == steps.lastIndex)) message(result)
                            }
                        } catch (e: NativeActions.NeedsShizuku) {
                            if (s.c != "optional") throw e
                            log("Skipped (needs Shizuku): ${s.a}")
                        }
                    }
                    Step.SHIZUKU -> {
                        if (s.c == "optional" && !com.newagedevs.gesturevolume.utils.ShizukuShell.isReady()) {
                            log("Skipped (needs Shizuku): ${s.a}")
                        } else {
                            val (code, out) = NativeActions.sh(sub(s.a))
                            vars["code"] = code.toString()
                            vars[s.b.ifEmpty { "out" }] = out
                            if (out.isNotBlank()) log(out.lines().last())
                        }
                    }
                    Step.BROADCAST -> {
                        val target = sub(s.a)
                        val intent = Intent(sub(s.b))
                        if (target.contains("/")) {
                            val pkg = target.substringBefore("/")
                            val cls = target.substringAfter("/").let { if (it.startsWith(".")) pkg + it else it }
                            intent.setClassName(pkg, cls)
                        } else if (target.isNotEmpty()) intent.setPackage(target)
                        sub(s.c).split(";").filter { it.contains("=") }.forEach {
                            intent.putExtra(it.substringBefore("=").trim(), it.substringAfter("=").trim())
                        }
                        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                        context.sendBroadcast(intent)
                        log("Broadcast sent to $target")
                    }
                    Step.NOTE -> {}
                }
            } catch (e: NativeActions.NeedsShizuku) {
                // Not an error: say what is missing and take the user to Shizuku.
                message(e.message ?: "This needs Shizuku.")
                log(e.message ?: "This needs Shizuku.")
                NativeActions.openShizuku(context)
                return null
            } catch (e: Throwable) {
                val text = e.message ?: e.javaClass.simpleName
                log("Step ${i + 1} failed: $text")
                message(text)
                return null
            }
            i++
        }
            return null
    }

    /** After the "then" branch reaches an else, run on past the matching end. */
    private fun findEndOfElse(steps: List<Step>, from: Int): Int {
        var depth = 0
        for (j in from + 1 until steps.size) {
            when (steps[j].type) {
                Step.IF, Step.REPEAT -> depth++
                Step.END -> if (depth == 0) return j else depth--
            }
        }
        return steps.size
    }

    private fun test(left: String, op: String, right: String): Boolean {
        val l = left.toDoubleOrNull(); val r = right.toDoubleOrNull()
        return when (op) {
            "=" -> if (l != null && r != null) l == r else left == right
            "!=" -> if (l != null && r != null) l != r else left != right
            "contains" -> left.contains(right)
            ">" -> l != null && r != null && l > r
            "<" -> l != null && r != null && l < r
            else -> false
        }
    }

    /** Expression with {name} texts filled in first, plus checks such as is("wifi"). */
    private fun evalExpr(context: Context, text: String, vars: MutableMap<String, String>): Any? =
        Expr.eval(text, vars) { name, args -> NativeActions.check(context, name, args.map { Expr.text(it) }) }
}
