package com.newagedevs.gesturevolume.download

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.newagedevs.gesturevolume.download.DownloadStore.DONE
import com.newagedevs.gesturevolume.download.DownloadStore.FAILED
import com.newagedevs.gesturevolume.download.DownloadStore.Job
import com.newagedevs.gesturevolume.download.DownloadStore.PAUSED
import com.newagedevs.gesturevolume.download.DownloadStore.QUEUED
import com.newagedevs.gesturevolume.download.DownloadStore.RUNNING
import com.newagedevs.gesturevolume.download.DownloadStore.STOPPED

/** The download list: every download with its state and buttons. Long-press a name to copy its link. */
class DownloadsActivity : Activity() {
    private class Row(val status: TextView, val bar: ProgressBar)

    private val h = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private val rows = HashMap<Int, Row>()
    private var sig = ""
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadStore.init(this)
        title = "A Downloads"
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(list) })
    }

    override fun onResume() { super.onResume(); sig = ""; tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun refresh() {
        val jobs = DownloadStore.all().sortedByDescending { it.created }
        val now = jobs.joinToString(",") { "${it.id}:${it.state}" }
        if (now != sig) { sig = now; rebuild(jobs) }
        for (j in jobs) rows[j.id]?.let { r ->
            r.status.text = DownloadStore.statusText(this, j)
            if (j.total > 0) { r.bar.isIndeterminate = false; r.bar.progress = (j.done * 1000 / j.total).toInt() }
            else r.bar.isIndeterminate = j.state == RUNNING
        }
    }

    private fun rebuild(jobs: List<Job>) {
        list.removeAllViews(); rows.clear()
        list.addView(TextView(this).apply { text = "Downloads"; textSize = 22f; setPadding(0, 0, 0, dp(8)) })
        list.addView(TextView(this).apply {
            textSize = 12f
            text = "Send a link to A (share it, or open it with A). A asks Normal / Replace / Rename every time. " +
                "A broken or expired download continues when you send a new link to the same file."
            setPadding(0, 0, 0, dp(12))
        })
        if (jobs.any { it.state == DONE }) list.addView(Button(this).apply {
            text = "Clear finished"
            setOnClickListener { jobs.filter { it.state == DONE }.forEach { DownloadStore.remove(it.id) }; sig = ""; refresh() }
        })
        if (jobs.isEmpty()) list.addView(TextView(this).apply { text = "Nothing yet." })
        for (j in jobs) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
            card.addView(TextView(this).apply {
                text = j.savedName ?: j.name; textSize = 16f
                setOnLongClickListener {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", j.url))
                    Toast.makeText(this@DownloadsActivity, "Link copied", Toast.LENGTH_SHORT).show(); true
                }
            })
            val status = TextView(this).apply { textSize = 12f }
            val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
            card.addView(status)
            if (j.state != DONE) card.addView(bar)
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.START }
            fun btn(label: String, onClick: () -> Unit) = buttons.addView(Button(this).apply {
                text = label; isAllCaps = false; setOnClickListener { onClick() }
            })
            fun svc(action: String) = DownloadService.send(this, action, j.id)
            when (j.state) {
                RUNNING -> { btn("Pause") { svc(DownloadService.ACT_PAUSE) }; btn("Stop") { svc(DownloadService.ACT_STOP) } }
                QUEUED -> btn("Stop") { svc(DownloadService.ACT_STOP) }
                PAUSED -> { btn("Resume") { svc(DownloadService.ACT_RESUME) }; btn("Remove") { svc(DownloadService.ACT_REMOVE) } }
                STOPPED, FAILED -> {
                    btn("Resume") { svc(DownloadService.ACT_RESUME) }
                    btn("Restart") { svc(DownloadService.ACT_RESTART) }
                    btn("Remove") { svc(DownloadService.ACT_REMOVE) }
                }
                DONE -> {
                    if (j.isApk) btn("Install") { open(j, true) }
                    btn("View") { open(j, false) }
                    btn("Remove from list") { DownloadStore.remove(j.id); sig = ""; refresh() }
                }
            }
            card.addView(buttons)
            list.addView(card)
            rows[j.id] = Row(status, bar)
        }
        list.visibility = View.VISIBLE
    }

    private fun open(j: Job, install: Boolean) {
        val i = DownloadService.fileIntent(j, install)
        try {
            startActivity(i ?: android.content.Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            Toast.makeText(this, "Nothing can open this file.", Toast.LENGTH_SHORT).show()
        }
    }
}
