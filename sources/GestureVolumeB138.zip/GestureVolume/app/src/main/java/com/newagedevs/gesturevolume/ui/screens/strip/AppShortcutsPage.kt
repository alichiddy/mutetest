package com.newagedevs.gesturevolume.ui.screens.strip

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The "App shortcuts" window: other apps' "make a shortcut" screens (Automate flows, Shortcut Maker…)
 * and the shortcuts apps declare. Shared by the script cell editor and the side segment actions so
 * both look and work the same.
 */
@Composable
fun AppShortcutsPage(
    onCreator: (ShortcutCreator) -> Unit,
    onShortcut: (FoundShortcut) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var creators by remember { mutableStateOf<List<ShortcutCreator>?>(null) }
    var found by remember { mutableStateOf<List<FoundShortcut>?>(null) }
    LaunchedEffect(Unit) {
        creators = withContext(Dispatchers.IO) { loadCreators(context) }
        found = withContext(Dispatchers.IO) { loadStaticShortcuts(context) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f)) {
            item { Text("Pick from an app (Automate flows, Shortcut Maker, Settings…)", fontWeight = FontWeight.SemiBold) }
            val c = creators
            if (c == null) item { CircularProgressIndicator() }
            else items(c) { cr ->
                Row(
                    Modifier.fillMaxWidth().clickable { onCreator(cr) }.padding(vertical = 8.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PackageIcon(cr.packageName, Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(cr.label)
                }
            }
            item {
                Spacer(Modifier.height(12.dp))
                Text("Shortcuts apps declare", fontWeight = FontWeight.SemiBold)
            }
            val f = found
            if (f == null) item { CircularProgressIndicator() }
            else items(f) { sc ->
                Row(
                    Modifier.fillMaxWidth().clickable { onShortcut(sc) }.padding(vertical = 8.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PackageIcon(sc.packageName, Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(sc.label)
                        Text(sc.appLabel, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
