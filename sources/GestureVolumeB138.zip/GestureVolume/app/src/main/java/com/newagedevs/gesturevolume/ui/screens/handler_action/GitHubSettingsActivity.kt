package com.newagedevs.gesturevolume.ui.screens.handler_action

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.newagedevs.gesturevolume.data.local.SharedPref

/** The GitHub build settings window on its own, so a strip cell or a Deck shortcut can open it. */
class GitHubSettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pref = SharedPref(this)
        setContent {
            MaterialTheme {
                GitHubSettingsDialog(pref) { finish() }
            }
        }
    }
}
