package com.newagedevs.gesturevolume.strip

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.widget.Toast
import com.newagedevs.gesturevolume.flow.FlowStore
import com.newagedevs.gesturevolume.service.OverlayRuntime
import com.newagedevs.gesturevolume.utils.HandlerActionCatalog
import com.newagedevs.gesturevolume.utils.HandlerActions

/**
 * A's shortcuts for other apps (KeyMapper, launchers, Automate...): they pick one of A's strip
 * cells or scripts here, and get back a shortcut that runs it through [ShortcutRunActivity].
 *
 * Both are plain activities with no UI framework and nothing running in between, so they cost
 * nothing while idle.
 */
class ShortcutPickerActivity : Activity() {
    private class Choice(val label: String, val action: String, val item: StripItem?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Two cards: A's own built-in actions (Deck, tiles, torch, QR, open an app...), and the
        // cells and scripts the user made. Whatever is added to either later shows up here.
        AlertDialog.Builder(this)
            .setTitle("A shortcut")
            .setItems(arrayOf("Built-in shortcuts", "Device actions (Wi-Fi, flashlight, network…)", "My cells and scripts")) { _, which ->
                when (which) {
                    0 -> builtIn()
                    1 -> com.newagedevs.gesturevolume.flow.NativePicker.pick(this) { a, n -> pick(Choice(n, a, null)) }
                    else -> mine()
                }
            }
            .setOnCancelListener { setResult(RESULT_CANCELED); finish() }
            .show()
    }

    /** A list with a search box on top; [onPick] gets the tapped choice. */
    private fun searchable(title: String, choices: List<Choice>, onPick: (Choice) -> Unit) {
        val box = android.widget.EditText(this).apply { hint = "Search"; setSingleLine(true) }
        val list = android.widget.ListView(this)
        var shown = choices
        fun fill() {
            val q = box.text.toString().trim().lowercase()
            shown = choices.filter { q.isEmpty() || it.label.lowercase().contains(q) }
            list.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_list_item_1, shown.map { it.label })
        }
        fill()
        box.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { fill() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val col = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(box)
            addView(list, android.widget.LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.55).toInt()))
        }
        val d = AlertDialog.Builder(this).setTitle(title).setView(col)
            .setOnCancelListener { setResult(RESULT_CANCELED); finish() }.show()
        list.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onPick(shown[pos]) }
    }

    private fun show(title: String, choices: List<Choice>) {
        if (choices.isEmpty()) {
            Toast.makeText(this, "Nothing here yet", Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED); finish(); return
        }
        searchable(title, choices) { pick(it) }
    }

    private fun builtIn() {
        val list = ArrayList<Choice>()
        list += Choice("Open an app…", "", null)
        for (e in HandlerActionCatalog.ALL) {
            if (e.action == HandlerActions.NONE || e.action == HandlerActions.REPOSITION) continue
            list += Choice(getString(e.labelRes), e.action, null)
        }
        searchable("Built-in actions", list) { if (it.label == "Open an app…") apps() else pick(it) }
    }

    private fun apps() {
        val pm = packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launch, 0)
            .map { Choice(it.loadLabel(pm).toString(), HandlerActions.launchApp(it.activityInfo.packageName), null) }
            .sortedBy { it.label.lowercase() }
        show("Open an app", list)
    }

    private fun mine() {
        val prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val cfg = StripConfig.load(this, prefs.getString(SettingsBackup.STRIP_KEY, null))
        val choices = ArrayList<Choice>()
        for (cell in cfg.items) if (cell.action.isNotEmpty()) choices += Choice(cell.label.ifBlank { cell.action.take(24) }, cell.action, cell)
        for (name in FlowStore.names(this)) choices += Choice("Script: $name", "MyFlow:$name", null)
        show("My cells and scripts", choices)
    }

    private fun pick(c: Choice) {
        val run = Intent(this, ShortcutRunActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .putExtra("n", c.label).putExtra("a", c.action)
            .putExtra("i", c.item?.icon.orEmpty())
        val result = Intent()
            .putExtra(Intent.EXTRA_SHORTCUT_INTENT, run)
            .putExtra(Intent.EXTRA_SHORTCUT_NAME, c.label)
        iconFor(c.item)?.let { result.putExtra(Intent.EXTRA_SHORTCUT_ICON, it) }
            ?: result.putExtra(
                Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                Intent.ShortcutIconResource.fromContext(this, com.newagedevs.gesturevolume.R.mipmap.ic_launcher)
            )
        setResult(RESULT_OK, result)
        finish()
    }

    /** The cell's own picture or app icon as a bitmap; null for an emoji or none (A's icon is used). */
    private fun iconFor(item: StripItem?): Bitmap? {
        if (item == null) return null
        item.iconFile?.let { f ->
            runCatching { android.graphics.BitmapFactory.decodeFile(java.io.File(filesDir, "sicons/$f").path) }.getOrNull()?.let { return it }
        }
        val pkg = item.appIconPackage ?: return null
        return runCatching {
            val d = packageManager.getApplicationIcon(pkg)
            Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888).also { bm -> d.setBounds(0, 0, 96, 96); d.draw(Canvas(bm)) }
        }.getOrNull()
    }
}

/** Runs the action it was given (an invisible activity, gone as soon as it has handed it over). */
class ShortcutRunActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val action = intent.getStringExtra("a").orEmpty()
        val item = StripItem(intent.getStringExtra("n").orEmpty(), intent.getStringExtra("i").orEmpty(), action)
        val controller = OverlayRuntime.activeController
        // Only what A itself holds may run: any app can send this activity an intent, so an action
        // that is not one of the strip's cells or one of the scripts is ignored.
        val cfg = StripConfig.load(this, getSharedPreferences("MyPrefs", MODE_PRIVATE).getString(SettingsBackup.STRIP_KEY, null))
        val pkgOpened = HandlerActions.launchedPackage(action)
        val known = cfg.items.any { it.action == action } ||
            HandlerActionCatalog.entryFor(action) != null ||
            com.newagedevs.gesturevolume.flow.NativePicker.isValid(action) ||
            (pkgOpened != null && runCatching { packageManager.getPackageInfo(pkgOpened, 0) }.isSuccess) ||
            (action.startsWith("MyFlow:") && FlowStore.names(this).contains(action.removePrefix("MyFlow:")))
        if (action.isEmpty() || !known) {
            // nothing to run
        } else if (controller != null) {
            controller.runStripItem(item)
        } else {
            Toast.makeText(this, "Turn A on first", Toast.LENGTH_LONG).show()
        }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
