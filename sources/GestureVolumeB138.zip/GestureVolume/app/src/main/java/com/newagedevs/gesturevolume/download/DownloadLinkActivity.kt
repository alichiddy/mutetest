package com.newagedevs.gesturevolume.download

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.webkit.URLUtil
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * A link sent to A (shared, or opened through "open with") ends here. It asks, every time, how to
 * save: Normal (the system adds "(1)" if the name exists), Replace (the older file of that name is
 * removed), Rename (the name typed in the box). Then the download manager takes over.
 */
class DownloadLinkActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadStore.init(this)
        val url = intent.dataString?.takeIf { it.startsWith("http", true) }
            ?: Regex("https?://\\S+").find(intent.getStringExtra(Intent.EXTRA_TEXT) ?: "")?.value
        if (url == null) { Toast.makeText(this, "No link to download.", Toast.LENGTH_SHORT).show(); finish(); return }

        // Headers some apps pass along with the link (Android browser convention).
        var referer: String? = null; var cookie: String? = null; var ua: String? = null
        intent.getBundleExtra("com.android.browser.headers")?.let { h ->
            for (k in h.keySet()) {
                val v = h.getString(k) ?: continue
                when (k.lowercase()) {
                    "referer", "referrer" -> referer = v
                    "cookie" -> cookie = v
                    "user-agent" -> ua = v
                }
            }
        }
        if (referer == null) referer = (intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_REFERRER) ?: intent.getStringExtra(Intent.EXTRA_REFERRER_NAME)?.let { android.net.Uri.parse(it) })
            ?.toString()?.takeIf { it.startsWith("http") }

        // The very same link already in the list, not finished: just continue it.
        DownloadStore.all().firstOrNull { it.url == url && it.state != DownloadStore.DONE }?.let {
            DownloadService.send(this, DownloadService.ACT_RESUME, it.id)
            Toast.makeText(this, "Resuming ${it.name}", Toast.LENGTH_SHORT).show(); finish(); return
        }

        val guess = URLUtil.guessFileName(url, null, null)
        val unfinished = DownloadStore.all().any { it.state != DownloadStore.DONE && it.done > 0 && it.name.equals(guess, true) }
        val box = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(guess); setSingleLine(true)
            setSelection(0, guess.lastIndexOf('.').let { if (it > 0) it else guess.length })
        }
        val note = TextView(this).apply {
            textSize = 13f
            text = (if (unfinished) "An unfinished download of this file exists: this link will continue it.\n\n" else "") +
                "Normal: the system renames if the name exists.\nReplace: removes the older file of that name.\nRename: saves as the name below.\n\n" +
                url.take(120)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (16 * resources.displayMetrics.density).toInt()
            setPadding(p, p / 2, p, 0)
            addView(note); addView(box)
        }
        fun start(mode: Int) {
            val typed = box.text.toString().trim().replace('/', '_')
            val edited = typed.isNotEmpty() && (mode == DownloadStore.RENAME || typed != guess)
            val job = DownloadStore.Job(DownloadStore.nextId(), url, if (edited) typed else guess, edited, mode)
            job.referer = referer; job.cookie = cookie; job.ua = ua; job.fresh = true
            DownloadStore.add(job)
            DownloadService.send(this, DownloadService.ACT_START, job.id)
            Toast.makeText(this, "Downloading. Progress is in the notification.", Toast.LENGTH_SHORT).show()
            finish()
        }
        AlertDialog.Builder(this)
            .setTitle("Download")
            .setView(body)
            .setPositiveButton("Replace") { _, _ -> start(DownloadStore.REPLACE) }
            .setNeutralButton("Normal") { _, _ -> start(DownloadStore.NORMAL) }
            .setNegativeButton("Rename") { _, _ -> start(DownloadStore.RENAME) }
            .setOnCancelListener { finish() }
            .show()
    }
}
