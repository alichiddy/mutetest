package com.newagedevs.gesturevolume.ui.screens.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.VectorGroup
import androidx.compose.ui.graphics.vector.VectorNode
import androidx.compose.ui.graphics.vector.VectorPath
import androidx.compose.ui.graphics.vector.toPath
import com.newagedevs.gesturevolume.utils.ActionIcon
import com.newagedevs.gesturevolume.utils.safeDrawableIdOrDefault
import java.io.File

/**
 * A built-in shortcut's own icon, drawn white into a small picture in the app's storage so a strip
 * cell can show the same icon the picker shows. Returns "img:<name>", or null when it cannot be drawn.
 */
object BuiltInIcons {
    private const val SIZE = 96

    fun save(context: Context, icon: ActionIcon, key: String): String? = runCatching {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        when (icon) {
            is ActionIcon.Vector -> drawVector(canvas, icon.image)
            is ActionIcon.Res -> {
                val d = androidx.core.content.ContextCompat.getDrawable(context, context.safeDrawableIdOrDefault(icon.id))!!.mutate()
                d.setTint(Color.WHITE)
                d.setBounds(0, 0, SIZE, SIZE)
                d.draw(canvas)
            }
            else -> return null
        }
        val dir = File(context.filesDir, "sicons").apply { mkdirs() }
        val name = "b${key.hashCode().toUInt()}.png"
        File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        "img:$name"
    }.getOrNull()

    private fun drawVector(canvas: Canvas, v: ImageVector) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.save()
        canvas.scale(SIZE / v.viewportWidth, SIZE / v.viewportHeight)
        fun walk(n: VectorNode) {
            when (n) {
                is VectorPath -> {
                    val p = n.pathData.toPath()
                    p.fillType = n.pathFillType
                    canvas.drawPath(p.asAndroidPath(), paint)
                }
                is VectorGroup -> n.forEach { walk(it) }
            }
        }
        v.root.forEach { walk(it) }
        canvas.restore()
    }
}
