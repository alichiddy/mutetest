package com.newagedevs.gesturevolume.flow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * A flow is a flat list of steps stored as text. Blocks (if / repeat) are opened by a step and
 * closed by an "end" step, so the editor is one list and the runner finds the matching end by
 * counting. Nothing here is loaded until a flow is edited or run, so it costs no memory idle.
 */
data class Step(val type: String, val a: String = "", val b: String = "", val c: String = "") {
    fun toJson() = JSONObject().put("t", type).put("a", a).put("b", b).put("c", c)

    /** A line for the editor list. */
    fun describe(): String = when (type) {
        SHELL -> "Shell: $a" + if (b.isNotEmpty()) "   -> $b" else ""
        WAIT -> if (c == "expr") "Wait ($a) ms" else "Wait $a ms"
        MESSAGE -> "Message: $a"
        LAUNCH -> "Open app: $a"
        INTENT -> "Intent: $a"
        SET -> if (c == "expr") "Set $a to ($b)" else "Set $a = $b"
        IF -> if (b == "expr") "If ($a)" else "If $a $b $c"
        ELSE -> "Else"
        REPEAT -> if (b == "each") "For each ${c.ifEmpty { "item" }} in ($a)" else "Repeat $a times"
        END -> "End"
        HTTP -> "Web $b $a" + if (c.isNotEmpty()) "   -> $c" else ""
        RUN -> "Run flow: $a" + if (b == "async") "  (at the same time)" else ""
        STOP -> "Stop"
        NOTE -> "Note: $a"
        ACTION -> "Do: " + (NativeActions.find(a)?.label ?: a) + (if (b.isNotEmpty()) "  ($b)" else "") + (if (c == "optional") "  [skipped without Shizuku]" else "")
        SHIZUKU -> "Shizuku command: $a" + if (b.isNotEmpty()) "   -> $b" else ""
        BROADCAST -> "Send broadcast: $a  $b"
        else -> "$type $a $b $c".trim()
    }

    companion object {
        const val SHELL = "shell"      // a = command, b = variable that gets the output
        const val WAIT = "wait"        // a = milliseconds
        const val MESSAGE = "message"  // a = text
        const val LAUNCH = "launch"    // a = package
        const val INTENT = "intent"    // a = Intent.toUri string
        const val SET = "set"          // a = variable, b = value
        const val IF = "if"            // a = left, b = operator (= != contains > <), c = right
        const val ELSE = "else"
        const val REPEAT = "repeat"    // a = count
        const val END = "end"
        const val HTTP = "http"        // a = url, b = method, c = variable that gets the answer
        const val RUN = "run"          // a = another flow's name
        const val STOP = "stop"
        const val NOTE = "note"        // a = text kept from an import, never run
        const val ACTION = "act"       // a = a built-in action id (see NativeActions), b = its argument
        const val SHIZUKU = "psh"      // a = command run with Shizuku's privilege, b = variable for the output, c = "optional" to skip quietly without Shizuku
        const val BROADCAST = "bcast"  // a = package or package/.Receiver, b = action, c = extras as key=value;key=value

        val TYPES = listOf(SHELL, WAIT, MESSAGE, LAUNCH, INTENT, SET, IF, ELSE, REPEAT, END, HTTP, RUN, STOP, NOTE, ACTION, SHIZUKU, BROADCAST)

        fun fromJson(o: JSONObject) = Step(o.optString("t"), o.optString("a"), o.optString("b"), o.optString("c"))
    }
}

/** Where flows live: one text value, so the settings backup carries them too. */
object FlowStore {
    private const val KEY = "flowsV1"

    private fun prefs(context: Context) = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    private fun all(context: Context): JSONObject =
        runCatching { JSONObject(prefs(context).getString(KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())

    fun names(context: Context): List<String> = all(context).keys().asSequence().sorted().toList()

    fun load(context: Context, name: String): List<Step> {
        val arr = all(context).optJSONArray(name) ?: return emptyList()
        return (0 until arr.length()).map { Step.fromJson(arr.getJSONObject(it)) }
    }

    fun save(context: Context, name: String, steps: List<Step>) {
        val o = all(context)
        o.put(name, JSONArray().apply { steps.forEach { put(it.toJson()) } })
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }

    fun saveAll(context: Context, flows: Map<String, List<Step>>) {
        val o = all(context)
        flows.forEach { (name, steps) -> o.put(name, JSONArray().apply { steps.forEach { put(it.toJson()) } }) }
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }

    fun delete(context: Context, name: String) {
        val o = all(context)
        o.remove(name)
        prefs(context).edit().putString(KEY, o.toString()).apply()
    }
}
