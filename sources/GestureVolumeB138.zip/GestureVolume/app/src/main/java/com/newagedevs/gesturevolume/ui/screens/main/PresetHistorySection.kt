package com.newagedevs.gesturevolume.ui.screens.main

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import com.newagedevs.gesturevolume.ui.screens.handler_action.segmentShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.data.local.PresetHistory
import com.newagedevs.gesturevolume.ui.motion.IconButton
import com.newagedevs.gesturevolume.ui.viewmodels.MainViewModel
import java.text.DateFormat
import java.util.Date

/**
 * The bar's settings as they were before a preset replaced them: tap one to bring it back, pin it
 * to keep it, bin it to drop it. Newest first; only the newest few unpinned ones are kept.
 */
@Composable
fun PresetHistorySection(viewModel: MainViewModel, context: Context) {
    val prefs = viewModel.preference.sharedPreferences
    var version by remember { mutableIntStateOf(0) }
    val entries = remember(version) { PresetHistory.list(prefs) }
    if (entries.isEmpty()) return
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    Text("Your own settings", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    Text(
        "Saved automatically before a preset replaces them. Tap to bring one back.",
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(8.dp))
    HomeSegments {
        entries.forEachIndexed { i, e ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(segmentShape(i, entries.size))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f))
                    .clickable {
                        PresetHistory.restore(prefs, e)
                        viewModel.sendUpdateToService(context)
                        android.widget.Toast.makeText(context, "Settings restored", android.widget.Toast.LENGTH_SHORT).show()
                        version++
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(format.format(Date(e.time)), Modifier.weight(1f), fontSize = 15.sp)
                IconButton(
                    onClick = { PresetHistory.setPinned(prefs, e.time, !e.pinned); version++ },
                    tooltip = if (e.pinned) "Unpin" else "Pin: keep it",
                ) { Icon(if (e.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin, contentDescription = null) }
                IconButton(
                    onClick = { PresetHistory.delete(prefs, e.time); version++ },
                    tooltip = "Delete",
                ) { Icon(Icons.Filled.Delete, contentDescription = null) }
            }
        }
    }
    Spacer(Modifier.height(20.dp))
}
