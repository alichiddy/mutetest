package com.newagedevs.gesturevolume.ui.screens.shell

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * The shell runner's commands: every one that was run (the newest [MAX_HISTORY] unsaved ones), and
 * the ones kept on purpose, which stay until deleted. One small JSON string in the preferences, so
 * the settings backup carries it.
 */
object ShellHistory {
    private const val KEY = "shellHistoryV1"
    const val MAX_HISTORY = 100

    data class Entry(
        val id: Long,
        val title: String,
        val cmd: String,
        val saved: Boolean,
        val created: Long,
        val lastRan: Long,
        val runs: Int,
    )

    private fun prefs(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun load(c: Context): List<Entry> = runCatching {
        val a = JSONArray(prefs(c).getString(KEY, "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Entry(o.getLong("id"), o.optString("t"), o.getString("c"), o.optBoolean("s"), o.optLong("d"), o.optLong("r"), o.optInt("n"))
        }
    }.getOrDefault(emptyList())

    fun save(c: Context, list: List<Entry>) {
        // The unsaved ones are capped; the kept ones never are.
        var unsaved = 0
        val keep = list.sortedByDescending { it.lastRan.coerceAtLeast(it.created) }
            .filter { if (it.saved) true else { unsaved++; unsaved <= MAX_HISTORY } }
        val a = JSONArray()
        keep.forEach {
            a.put(JSONObject().put("id", it.id).put("t", it.title).put("c", it.cmd).put("s", it.saved)
                .put("d", it.created).put("r", it.lastRan).put("n", it.runs))
        }
        prefs(c).edit().putString(KEY, a.toString()).apply()
    }

    /** Notes a run: the same command moves to the top instead of repeating. */
    fun recordRun(c: Context, cmd: String): List<Entry> {
        val now = System.currentTimeMillis()
        val list = load(c).toMutableList()
        val i = list.indexOfFirst { it.cmd == cmd }
        if (i >= 0) list[i] = list[i].copy(lastRan = now, runs = list[i].runs + 1)
        else list += Entry(now, "", cmd, false, now, now, 1)
        save(c, list)
        return load(c)
    }
}
