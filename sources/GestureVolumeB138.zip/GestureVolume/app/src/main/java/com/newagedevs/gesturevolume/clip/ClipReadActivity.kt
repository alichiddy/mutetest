package com.newagedevs.gesturevolume.clip

import android.app.Activity
import android.os.Bundle

/** Invisible, for an instant: while it has focus Android lets it read the clipboard. */
class ClipReadActivity : Activity() {
    private var done = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0, 0)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            ClipTools.readAndHandle(this)
            finish()
            overridePendingTransition(0, 0)
        }
    }
}
