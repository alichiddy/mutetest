package com.newagedevs.gesturevolume.flow

import android.content.Context
import org.json.JSONObject

/**
 * The 53 Automate flows, already turned into A's own steps (assets/automate_flows.json). Numbers
 * and codes that were inside them (phone numbers, bank and coupon codes) are not in the file:
 * they are blanks {pv1}, {pv2}... that you fill in under My values. Flows are named
 * "Automate: <flow> - <entry>"; extra pieces of a flow are "... - part N".
 */
object AutomateFlows {
    /** Returns how many flows were added or replaced. */
    fun install(context: Context): Int {
        val root = JSONObject(context.assets.open("automate_flows.json").bufferedReader().use { it.readText() })
        val flows = root.getJSONObject("flows")
        var n = 0
        // One write for all flows is much faster than saving each flow on its own.
        FlowStore.saveAll(context, flows.keys().asSequence().associateWith { name ->
            val arr = flows.getJSONArray(name)
            (0 until arr.length()).map { Step.fromJson(arr.getJSONObject(it)) }.also { n++ }
        })
        context.getSharedPreferences("AutomateSlots", Context.MODE_PRIVATE).edit()
            .putString("slots", root.getJSONArray("slots").toString()).apply()
        return n
    }

    fun isPart(name: String) = name.contains(" - part ")
}
