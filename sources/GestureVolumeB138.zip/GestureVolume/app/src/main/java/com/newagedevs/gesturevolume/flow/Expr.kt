package com.newagedevs.gesturevolume.flow

/**
 * A small expression language, the same shape as Automate's: numbers, "text", variables,
 * + - * / // %, ++ (join text), = != < > <= >=, && || !, # (length), x[i], c ? a : b and a few
 * functions (Trim, Split, Contains, ReplaceAll, Substr, Join, IndexOf, Matches, CliEncode...).
 * Lists live inside variables as one text (\u0001 first, items split by \u0002).
 */
object Expr {
    private const val L0 = "\u0001"
    private const val L1 = "\u0002"

    fun encodeList(l: List<Any?>): String = L0 + l.joinToString(L1) { text(it) }
    fun asList(v: Any?): List<Any?>? = when {
        v is List<*> -> v
        v is String && v.startsWith(L0) -> if (v.length == 1) emptyList() else v.substring(1).split(L1)
        else -> null
    }

    fun text(v: Any?): String = when (v) {
        null -> ""
        is Double -> if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()
        is List<*> -> encodeList(v)
        else -> v.toString()
    }

    fun num(v: Any?): Double = when (v) {
        is Double -> v
        is String -> v.trim().toDoubleOrNull() ?: 0.0
        null -> 0.0
        else -> 0.0
    }

    fun truth(v: Any?): Boolean = when (v) {
        null -> false
        is Double -> v != 0.0
        is String -> v.isNotEmpty() && v != "0" && !v.equals("false", true)
        is List<*> -> v.isNotEmpty()
        else -> true
    }

    /** Evaluates [src] with [vars]; [fn] answers functions this file does not know (checks like wifi on). */
    fun eval(src: String, vars: Map<String, String>, fn: (String, List<Any?>) -> Any? = { _, _ -> null }): Any? {
        val p = Parser(src, vars, fn)
        val v = p.expr()
        return v
    }

    private class Parser(val s: String, val vars: Map<String, String>, val fn: (String, List<Any?>) -> Any?) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun peek(t: String): Boolean { ws(); return s.startsWith(t, i) }
        fun eat(t: String): Boolean { if (peek(t)) { i += t.length; return true }; return false }

        fun expr(): Any? {
            val c = or()
            if (eat("?")) {
                val a = expr(); eat(":"); val b = expr()
                return if (truth(c)) a else b
            }
            return c
        }
        fun or(): Any? {
            var l = and()
            while (peek("||")) { i += 2; val r = and(); l = if (truth(l) || truth(r)) 1.0 else 0.0 }
            return l
        }
        fun and(): Any? {
            var l = cmp()
            while (peek("&&")) { i += 2; val r = cmp(); l = if (truth(l) && truth(r)) 1.0 else 0.0 }
            return l
        }
        fun same(a: Any?, b: Any?): Boolean {
            val x = if (a is String) a.trim().toDoubleOrNull() else a as? Double
            val y = if (b is String) b.trim().toDoubleOrNull() else b as? Double
            return if (x != null && y != null) x == y else text(a) == text(b)
        }
        fun cmp(): Any? {
            var l = add()
            while (true) {
                ws()
                val op = listOf("!=", ">=", "<=", "=", ">", "<").firstOrNull { s.startsWith(it, i) } ?: return l
                i += op.length
                val r = add()
                l = when (op) {
                    "=" -> same(l, r)
                    "!=" -> !same(l, r)
                    ">" -> num(l) > num(r)
                    "<" -> num(l) < num(r)
                    ">=" -> num(l) >= num(r)
                    else -> num(l) <= num(r)
                }.let { if (it) 1.0 else 0.0 }
            }
        }
        fun add(): Any? {
            var l = mul()
            while (true) {
                ws()
                l = when {
                    s.startsWith("++", i) -> { i += 2; text(l) + text(mul()) }
                    s.startsWith("+", i) -> { i++; num(l) + num(mul()) }
                    s.startsWith("-", i) -> { i++; num(l) - num(mul()) }
                    else -> return l
                }
            }
        }
        fun mul(): Any? {
            var l = un()
            while (true) {
                ws()
                l = when {
                    s.startsWith("//", i) -> { i += 2; val r = num(un()); if (r == 0.0) 0.0 else Math.floor(num(l) / r) }
                    s.startsWith("*", i) -> { i++; num(l) * num(un()) }
                    s.startsWith("/", i) -> { i++; val r = num(un()); if (r == 0.0) 0.0 else num(l) / r }
                    s.startsWith("%", i) -> { i++; val r = num(un()); if (r == 0.0) 0.0 else num(l) % r }
                    else -> return l
                }
            }
        }
        fun un(): Any? {
            ws()
            return when {
                s.startsWith("!", i) && !s.startsWith("!=", i) -> { i++; if (truth(un())) 0.0 else 1.0 }
                s.startsWith("-", i) -> { i++; -num(un()) }
                s.startsWith("#", i) -> { i++; val v = un(); (asList(v)?.size ?: text(v).length).toDouble() }
                else -> post()
            }
        }
        fun post(): Any? {
            var v = prim()
            while (true) {
                ws()
                if (i < s.length && s[i] == '[') {
                    i++; val ix = expr(); eat("]")
                    val l = asList(v)
                    v = if (l != null) l.getOrNull(num(ix).toInt() - 1) else text(v).getOrNull(num(ix).toInt() - 1)?.toString()
                } else return v
            }
        }
        fun prim(): Any? {
            ws()
            if (i >= s.length) return null
            val c = s[i]
            if (c == '(') { i++; val v = expr(); eat(")"); return v }
            if (c == '"') {
                i++; val sb = StringBuilder()
                while (i < s.length && s[i] != '"') {
                    if (s[i] == '\\' && i + 1 < s.length) {
                        i++; sb.append(when (s[i]) { 'n' -> '\n'; 't' -> '\t'; else -> s[i] })
                    } else sb.append(s[i])
                    i++
                }
                i++
                return sb.toString()
            }
            if (c.isDigit()) {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                return s.substring(st, i).toDoubleOrNull() ?: 0.0
            }
            if (c.isLetter() || c == '_') {
                val st = i
                while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_' || s[i] == '.')) i++
                val name = s.substring(st, i)
                if (name == "true") return 1.0
                if (name == "false" || name == "null") return if (name == "null") null else 0.0
                if (peek("(")) {
                    i++
                    val args = ArrayList<Any?>()
                    if (!peek(")")) { do { args.add(expr()) } while (eat(",")) }
                    eat(")")
                    return call(name, args)
                }
                val raw = vars[name] ?: return null
                return if (raw.startsWith(L0)) raw else raw
            }
            i++
            return null
        }

        fun call(name: String, a: List<Any?>): Any? {
            fun t(n: Int) = text(a.getOrNull(n))
            return when (name) {
                "Trim" -> t(0).trim()
                "Contains" -> { val l = asList(a.getOrNull(0)); if (l != null) (if (l.any { text(it) == t(1) }) 1.0 else 0.0) else if (t(0).contains(t(1))) 1.0 else 0.0 }
                "ReplaceAll" -> runCatching { t(0).replace(Regex(t(1)), t(2)) }.getOrDefault(t(0))
                "Split" -> { val sep = t(1); encodeList(if (sep.isEmpty()) t(0).map { it.toString() } else runCatching { t(0).split(Regex(sep)) }.getOrDefault(listOf(t(0)))) }
                "Join" -> (asList(a.getOrNull(0)) ?: emptyList()).joinToString(t(1)) { text(it) }
                "Substr" -> { val x = t(0); val st = (num(a.getOrNull(1)).toInt() - 1).coerceIn(0, x.length); val en = if (a.size > 2 && a[2] != null) (st + num(a[2]).toInt()).coerceIn(st, x.length) else x.length; x.substring(st, en) }
                "IndexOf" -> (t(0).indexOf(t(1)) + 1).toDouble()
                "Matches" -> if (runCatching { Regex(t(1)).containsMatchIn(t(0)) }.getOrDefault(false)) 1.0 else 0.0
                "CliEncode" -> "'" + t(0).replace("'", "'\\''") + "'"
                "XPathEncode" -> "'" + t(0).replace("'", "''") + "'"
                "Char" -> num(a.getOrNull(0)).toInt().toChar().toString()
                "Round" -> Math.round(num(a.getOrNull(0))).toDouble()
                "Min" -> a.map { num(it) }.minOrNull() ?: 0.0
                "Max" -> a.map { num(it) }.maxOrNull() ?: 0.0
                "Abs" -> Math.abs(num(a.getOrNull(0)))
                "UrlEncode" -> java.net.URLEncoder.encode(t(0), "UTF-8")
                "UrlDecode" -> java.net.URLDecoder.decode(t(0), "UTF-8")
                "Base64Encode" -> android.util.Base64.encodeToString(t(0).toByteArray(), android.util.Base64.NO_WRAP)
                "Storage" -> "/sdcard" + (if (t(0).isNotEmpty()) "/" + t(0).trimStart('/') else "")
                "FileUri" -> "file://" + t(0)
                "DateFormat" -> runCatching { java.text.SimpleDateFormat(t(1).ifEmpty { "yyyy-MM-dd HH:mm:ss" }, java.util.Locale.US).format(java.util.Date(num(a.getOrNull(0)).toLong())) }.getOrDefault("")
                "List" -> encodeList(a)
                "Now" -> System.currentTimeMillis().toDouble()
                else -> fn(name, a)
            }
        }
    }
}
