package com.newagedevs.gesturevolume.flow

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import com.newagedevs.gesturevolume.service.OverlayRuntime
import com.newagedevs.gesturevolume.strip.StripItem
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Everything a cell or a flow step can do on its own, without Automate.
 *
 * Each action says what it needs ([Need]) so the editor and the report can show it:
 *  - NONE: works with nothing but the permissions A already asks for.
 *  - ONCE: works natively after a one-time grant (Grant permissions button). Until then it falls
 *    back to Shizuku, and without either it says so.
 *  - BETTER: Android only lets an app do part of it alone (it opens the right settings panel);
 *    with Shizuku it does the whole thing in one tap.
 *  - SHIZUKU: needs Shizuku every time. Without it the flow shows a message and opens Shizuku.
 */
object NativeActions {
    enum class Need { NONE, ONCE, BETTER, SHIZUKU }

    class NeedsShizuku(message: String) : Exception(message)

    class Ctx(val context: Context, val arg: String, val vars: MutableMap<String, String>)

    class Def(val id: String, val label: String, val need: Need, val help: String = "", val run: (Ctx) -> String)

    private val defs = ArrayList<Def>()
    private fun def(id: String, label: String, need: Need, help: String = "", run: (Ctx) -> String) {
        defs.add(Def(id, label, need, help, run))
    }

    val all: List<Def> get() = defs
    fun find(id: String): Def? = defs.firstOrNull { it.id == id }

    /** Results that should stay on screen in a window (uploads, long outputs) instead of a passing bar. */
    fun staysOnScreen(id: String, result: String): Boolean = when (id) {
        "upload_pick", "upload_file", "grant_app", "revoke_app", "wireless_diag", "lensnet" -> result.isNotBlank()
        "lens_ocr" -> result.startsWith("Lens closed").not() && result.isNotBlank()
        "bgshell" -> result.startsWith("Uploaded")
        else -> false
    }

    /** Runs one action. Blocking: call it from a background thread. Returns a short result line. */
    fun run(context: Context, id: String, arg: String, vars: MutableMap<String, String>): String {
        if (id.startsWith("A:")) return runAppAction(id.removePrefix("A:"))
        val d = find(id) ?: throw IllegalArgumentException("Unknown action: $id")
        return d.run(Ctx(context.applicationContext, arg, vars))
    }

    /** One of A's own actions (screenshot, power menu, back...), run by the overlay service. */
    private fun runAppAction(action: String): String {
        val controller = OverlayRuntime.activeController ?: throw IllegalStateException("Turn A on first.")
        controller.runStripItem(StripItem(action, "", action))
        return action
    }

    // ---------------------------------------------------------------- Shizuku

    fun requireShizuku() {
        if (!ShizukuShell.isReady()) {
            throw NeedsShizuku("This needs Shizuku. Start Shizuku and allow A, then try again.")
        }
    }

    /** Runs a command with Shizuku's privilege; throws [NeedsShizuku] when it is not ready. */
    fun sh(command: String): Pair<Int, String> {
        requireShizuku()
        val out = StringBuilder()
        val code = ShizukuShell.run(command) { out.append(it).append('\n') }
        return code to out.toString().trim()
    }

    /** Yes/no and number checks for flow conditions: is("wifi"), battery(), appinstalled("pkg")... */
    fun check(context: Context, name: String, args: List<String>): Any? = runCatching<Any?> {
        fun b(x: Boolean) = if (x) 1.0 else 0.0
        val a0 = args.getOrNull(0).orEmpty()
        when (name) {
            "battery" -> (context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY).toDouble()
            "appinstalled" -> b(runCatching { context.packageManager.getPackageInfo(a0, 0); true }.getOrDefault(false))
            "appfg" -> b(sh("dumpsys activity activities | grep -m1 -E 'mResumedActivity|topResumedActivity'").second.contains(a0))
            "is" -> when (a0.lowercase()) {
                "wifi" -> b((context.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled)
                "bluetooth" -> b(android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled == true)
                "airplane" -> b(android.provider.Settings.Global.getInt(context.contentResolver, "airplane_mode_on", 0) == 1)
                "location" -> b((context.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager).isLocationEnabled)
                "mobiledata" -> b(android.provider.Settings.Global.getInt(context.contentResolver, "mobile_data", 1) == 1)
                "screenon" -> b((context.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive)
                "charging" -> b((context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager).isCharging)
                "nfc" -> b(android.nfc.NfcAdapter.getDefaultAdapter(context)?.isEnabled == true)
                "hotspot" -> b(sh("dumpsys wifi | grep -m1 -i 'softap'").second.contains("ENABLED", true))
                "torch" -> b(sh("settings get secure flashlight_enabled").second.trim() == "1")
                "datasaver" -> b(sh("cmd netpolicy get restrict-background").second.contains("enabled", true))
                "locked" -> b((context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked)
                "musicplaying" -> b((context.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive)
                else -> 0.0
            }
            else -> null
        }
    }.getOrNull()

    /** Opens the Shizuku app (or its download page when it is not installed). */
    fun openShizuku(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(launch) }
    }

    private fun script(context: Context, name: String, vararg replace: Pair<String, String>): String {
        var t = context.assets.open("scripts/$name").bufferedReader().use { it.readText() }
        for ((k, v) in replace) t = t.replace(k, v)
        return t
    }

    // ---------------------------------------------------------------- settings helpers

    private fun canWriteSecure(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun gInt(c: Context, key: String, d: Int) = Settings.Global.getInt(c.contentResolver, key, d)
    private fun sInt(c: Context, key: String, d: Int) = Settings.Secure.getInt(c.contentResolver, key, d)

    /** Writes a setting: directly when the one-time grant is there, otherwise through Shizuku. */
    private fun put(c: Context, space: String, key: String, value: String) {
        if (canWriteSecure(c)) {
            val ok = runCatching {
                when (space) {
                    "global" -> Settings.Global.putString(c.contentResolver, key, value)
                    "secure" -> Settings.Secure.putString(c.contentResolver, key, value)
                    else -> Settings.System.putString(c.contentResolver, key, value)
                }
            }.getOrDefault(false)
            if (ok) return
        }
        if (space == "system" && Settings.System.canWrite(c)) {
            if (runCatching { Settings.System.putString(c.contentResolver, key, value) }.getOrDefault(false)) return
        }
        sh("settings put $space $key $value")
    }

    private fun openSettings(c: Context, action: String): String {
        runCatching { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        return "Opened settings: Android does not let apps change this alone."
    }

    // ---------------------------------------------------------------- torch

    @Volatile private var torchOn = false
    private var torchCallback: CameraManager.TorchCallback? = null

    private fun torch(ctx: Ctx, mode: Int): String {
        val cm = ctx.context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids = cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        val id = ids.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: ids.firstOrNull() ?: throw IllegalStateException("This phone has no flashlight.")
        if (torchCallback == null) {
            val latch = CountDownLatch(1)
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == id) { torchOn = enabled; latch.countDown() }
                }
                override fun onTorchModeUnavailable(cameraId: String) { latch.countDown() }
            }
            cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
            torchCallback = cb
            latch.await(600, TimeUnit.MILLISECONDS)
        }
        val want = when (mode) { 0 -> false; 1 -> true; else -> !torchOn }
        cm.setTorchMode(id, want)
        torchOn = want
        return if (want) "Flashlight on" else "Flashlight off"
    }

    // ---------------------------------------------------------------- foreground app

    @Suppress("DEPRECATION")
    private fun hasUsageAccess(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) ==
            AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    /** The app in front, from usage access (native) or, failing that, from Shizuku. */
    @Suppress("DEPRECATION")
    fun foregroundPackage(c: Context): String? {
        if (hasUsageAccess(c)) {
            val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val events = usm.queryEvents(now - 5 * 60_000L, now)
            val e = UsageEvents.Event()
            var last: String? = null
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND && e.packageName != c.packageName) last = e.packageName
            }
            if (last != null) return last
        }
        if (ShizukuShell.isReady()) {
            val r = sh("dumpsys activity activities 2>/dev/null | grep -m1 mResumedActivity: | awk '{print \$4}' | cut -d/ -f1")
            return r.second.lines().firstOrNull { it.isNotBlank() }?.trim()
        }
        return null
    }

    private fun needForeground(c: Context): String =
        foregroundPackage(c) ?: throw IllegalStateException(
            "Cannot tell which app is in front. Press Grant permissions (Usage access) or start Shizuku."
        )

    // ---------------------------------------------------------------- clipboard (set and get)

    @Volatile var clipLatch: CountDownLatch? = null
    @Volatile var clipText: String = ""

    fun clipboardSet(c: Context, text: String) {
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        Handler(Looper.getMainLooper()).post { runCatching { cm.setPrimaryClip(ClipData.newPlainText("A", text)) } }
    }

    /** Android hides the clipboard from background apps, so a see-through activity reads it for us. */
    fun clipboardGet(c: Context): String {
        val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val direct = runCatching { cm.primaryClip?.getItemAt(0)?.coerceToText(c)?.toString() }.getOrNull()
        if (!direct.isNullOrEmpty()) return direct
        val latch = CountDownLatch(1)
        clipLatch = latch
        clipText = ""
        c.startActivity(Intent(c, ClipboardProbeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION))
        latch.await(4, TimeUnit.SECONDS)
        return clipText
    }

    // ---------------------------------------------------------------- file picker and tempfile.org upload

    @Volatile var pickLatch: CountDownLatch? = null
    @Volatile var pickedPath: String = ""

    fun pickFile(c: Context): String {
        val latch = CountDownLatch(1)
        pickLatch = latch
        pickedPath = ""
        c.startActivity(Intent(c, FilePickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        latch.await(3, TimeUnit.MINUTES)
        return pickedPath
    }

    /** Uploads a file to tempfile.org (kept one hour) and returns the download link. */
    fun uploadTempfile(path: String): String {
        val f = File(path)
        if (!f.isFile) throw IllegalStateException("File not found: $path")
        val b = "BoUnDaRy"
        val head = "--$b\r\nContent-Disposition: form-data; name=\"files\"; filename=\"${f.name}\"\r\n" +
            "Content-Type: application/octet-stream\r\n\r\n"
        val tail = "\r\n--$b\r\nContent-Disposition: form-data; name=\"expiryHours\"\r\n\r\n1\r\n--$b--\r\n"
        val c = URL("https://tempfile.org/api/upload/local").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 20_000
            c.readTimeout = 120_000
            c.setRequestProperty("Content-Type", "multipart/form-data;boundary=$b")
            c.setChunkedStreamingMode(0)
            c.outputStream.use { out ->
                out.write(head.toByteArray())
                f.inputStream().use { it.copyTo(out) }
                out.write(tail.toByteArray())
            }
            val text = (if (c.responseCode < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (c.responseCode !in 200..299) throw IllegalStateException("Upload failed (${c.responseCode}): ${text.take(100)}")
            val id = org.json.JSONObject(text).getJSONArray("files").getJSONObject(0).getString("id")
            return "https://tempfile.org/$id/download"
        } finally {
            c.disconnect()
        }
    }

    // ---------------------------------------------------------------- keep awake

    private var awakeLock: PowerManager.WakeLock? = null

    // ---------------------------------------------------------------- the actions

    private fun netMask(ctx: Ctx): String {
        val mask = when (ctx.arg.lowercase()) {
            "2g3g" -> "50055"
            "4g" -> "4096"
            "5g" -> "524288"
            "4g5g" -> "528384"
            "all", "2g3g4g" -> "54151"
            else -> throw IllegalArgumentException("Network mode: use 2g, 2g3g, 4g, 4g5g, 5g or all.")
        }
        val r = sh(script(ctx.context, "net_mask.sh", "@MASK@" to mask))
        return "Network mode ${ctx.arg}: ${r.second.ifBlank { "sent" }}"
    }

    private fun hotspotUp(): Boolean =
        sh("ip -o link show up | grep -Ec '(^|[0-9]+: )(ap0|swlan0|wlan1)[:@]'").second.trim() != "0"

    /** Tries each known command, checks the result, and says what the phone answered when none works. */
    private fun hotspotSet(ctx: Ctx, on: Boolean): String {
        if (hotspotUp() == on) return "Hotspot " + if (on) "already on" else "already off"
        val tries = if (on) listOf("cmd connectivity start-tethering wifi")
        else listOf("cmd connectivity stop-tethering wifi", "cmd wifi stop-softap")
        var answer = ""
        for (c in tries) {
            val r = sh(c)
            if (answer.isEmpty()) answer = r.second.lines().firstOrNull { it.isNotBlank() }.orEmpty()
            Thread.sleep(1500)
            if (hotspotUp() == on) return "Hotspot " + if (on) "on" else "off"
        }
        openSettings(ctx.context, "android.settings.TETHER_SETTINGS")
        return "Hotspot did not change. The phone said: ${answer.ifBlank { "nothing" }.take(120)}. Opened the tethering settings."
    }

    private fun btSet(ctx: Ctx, on: Boolean): String {
        val word = if (on) "enable" else "disable"
        fun done() = (gInt(ctx.context, "bluetooth_on", 0) != 0) == on
        val first = sh("svc bluetooth $word").second
        Thread.sleep(1500)
        if (done()) return "Bluetooth " + if (on) "on" else "off"
        val second = sh("cmd bluetooth_manager $word").second
        Thread.sleep(2000)
        if (done()) return "Bluetooth " + if (on) "on" else "off"
        openSettings(ctx.context, Settings.ACTION_BLUETOOTH_SETTINGS)
        return "Bluetooth did not change (svc: ${first.take(60).ifBlank { "no answer" }}; cmd: ${second.take(60).ifBlank { "no answer" }}). Opened Bluetooth settings."
    }

    private fun toggleOnOff(
        ctx: Ctx, isOn: () -> Boolean, set: (Boolean) -> String, mode: Int,
    ): String = set(when (mode) { 0 -> false; 1 -> true; else -> !isOn() })

    init {
        // ---- flashlight
        def("torch_toggle", "Flashlight: toggle", Need.NONE) { torch(it, 2) }
        def("torch_on", "Flashlight: on", Need.NONE) { torch(it, 1) }
        def("torch_off", "Flashlight: off", Need.NONE) { torch(it, 0) }

        // ---- Wi-Fi, Bluetooth, location, airplane, data, hotspot
        for ((suffix, mode) in listOf("toggle" to 2, "on" to 1, "off" to 0)) {
            def("wifi_$suffix", "Wi-Fi: $suffix", Need.BETTER, "Without Shizuku opens the Internet panel.") { ctx ->
                toggleOnOff(ctx, { gInt(ctx.context, "wifi_on", 0) != 0 }, { on ->
                    if (ShizukuShell.isReady()) { sh("svc wifi " + if (on) "enable" else "disable"); "Wi-Fi " + if (on) "on" else "off" }
                    else {
                        val panel = if (android.os.Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
                        openSettings(ctx.context, panel)
                    }
                }, mode)
            }
            def("bt_$suffix", "Bluetooth: $suffix", Need.BETTER, "Without Shizuku opens Bluetooth settings.") { ctx ->
                toggleOnOff(ctx, { gInt(ctx.context, "bluetooth_on", 0) != 0 }, { on ->
                    if (ShizukuShell.isReady()) btSet(ctx, on)
                    else openSettings(ctx.context, Settings.ACTION_BLUETOOTH_SETTINGS)
                }, mode)
            }
            def("location_$suffix", "Location: $suffix", Need.ONCE, "Needs the one-time WRITE_SECURE_SETTINGS grant, or Shizuku.") { ctx ->
                toggleOnOff(ctx, { sInt(ctx.context, "location_mode", 0) != 0 }, { on ->
                    if (canWriteSecure(ctx.context) || ShizukuShell.isReady()) {
                        put(ctx.context, "secure", "location_mode", if (on) "3" else "0"); "Location " + if (on) "on" else "off"
                    } else openSettings(ctx.context, Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                }, mode)
            }
            def("airplane_$suffix", "Airplane mode: $suffix", Need.SHIZUKU) { ctx ->
                toggleOnOff(ctx, { gInt(ctx.context, "airplane_mode_on", 0) != 0 }, { on ->
                    sh("cmd connectivity airplane-mode " + if (on) "enable" else "disable"); "Airplane mode " + if (on) "on" else "off"
                }, mode)
            }
            def("data_$suffix", "Mobile data: $suffix", Need.SHIZUKU) { ctx ->
                toggleOnOff(ctx, { gInt(ctx.context, "mobile_data", 1) != 0 }, { on ->
                    sh("svc data " + if (on) "enable" else "disable"); "Mobile data " + if (on) "on" else "off"
                }, mode)
            }
            def("hotspot_$suffix", "Hotspot: $suffix", Need.SHIZUKU, "Best effort: some phones refuse the command; then the tethering settings open.") { ctx ->
                toggleOnOff(ctx, { hotspotUp() }, { on -> hotspotSet(ctx, on) }, mode)
            }
        }
        def("netmode", "Network mode (2g, 2g3g, 4g, 4g5g, 5g, all)", Need.SHIZUKU, "Argument: 2g | 2g3g | 4g | 4g5g | 5g | all") { ctx ->
            if (ctx.arg.lowercase() == "2g") {
                sh(script(ctx.context, "net_2g_both.sh")); "Network mode 2G on both SIMs"
            } else netMask(ctx)
        }
        def("net_info", "Show data mode (2G/3G/4G/5G)", Need.SHIZUKU) { ctx ->
            val text = sh(script(ctx.context, "check_data.sh")).second
            ctx.vars["out"] = text
            text
        }

        // ---- system settings (one-time grant, or Shizuku)
        def("dev_show", "Developer settings: show", Need.ONCE) { put(it.context, "global", "development_settings_enabled", "1"); "Developer settings shown" }
        def("dev_hide", "Developer settings: hide", Need.ONCE) { put(it.context, "global", "development_settings_enabled", "0"); "Developer settings hidden" }
        def("debug_off", "USB and Wi-Fi debugging off", Need.ONCE) {
            put(it.context, "global", "adb_enabled", "0")
            put(it.context, "global", "adb_wifi_enabled", "0")
            "Debugging off"
        }
        def("seconds_toggle", "Seconds in the status-bar clock: toggle", Need.ONCE) {
            val now = sInt(it.context, "clock_seconds", 0)
            put(it.context, "secure", "clock_seconds", if (now == 1) "0" else "1"); "Clock seconds " + if (now == 1) "off" else "on"
        }
        def("speed_toggle", "Network speed in the status bar: toggle", Need.ONCE, "The setting name works on Xiaomi/HyperOS-style ROMs.") {
            val now = Settings.System.getInt(it.context.contentResolver, "statusbar_network_speed", 0)
            put(it.context, "system", "statusbar_network_speed", if (now == 1) "0" else "1"); "Speed display " + if (now == 1) "off" else "on"
        }
        def("anim_toggle", "Animations fast / normal: toggle", Need.SHIZUKU, "Also sets the long-press time and safe-volume state.") {
            sh(script(it.context, "anim_toggle.sh")); "Animation speed switched"
        }
        def("brightness_toggle", "Brightness: automatic / maximum", Need.NONE, "Argument: the maximum brightness value (default 255).") { ctx ->
            if (!Settings.System.canWrite(ctx.context)) {
                ctx.context.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.context.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                throw IllegalStateException("Allow 'Modify system settings' for A first.")
            }
            val cr = ctx.context.contentResolver
            val auto = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            if (auto) {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, ctx.arg.toIntOrNull() ?: 255)
                "Brightness: maximum"
            } else {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                "Brightness: automatic"
            }
        }
        def("datasaver_toggle", "Data Saver: toggle", Need.SHIZUKU) {
            val on = sh("cmd netpolicy get restrict-background").second.contains("enabled", true)
            sh("cmd netpolicy set restrict-background " + if (on) "false" else "true"); "Data Saver " + if (on) "off" else "on"
        }
        def("volume_max", "Media volume to maximum", Need.NONE, "Argument: stream (music, ring, alarm, notification). Default music.") { ctx ->
            val am = ctx.context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val stream = when (ctx.arg.lowercase()) {
                "ring" -> AudioManager.STREAM_RING
                "alarm" -> AudioManager.STREAM_ALARM
                "notification" -> AudioManager.STREAM_NOTIFICATION
                else -> AudioManager.STREAM_MUSIC
            }
            am.setStreamVolume(stream, am.getStreamMaxVolume(stream), AudioManager.FLAG_SHOW_UI)
            "Volume at maximum"
        }
        def("clip_now", "Clipboard: convert digits and show what is copied, now", Need.NONE, "Reads the clipboard through a see-through window for an instant, applies the Copy options (digits, bar, toast, notification).") { ctx ->
            com.newagedevs.gesturevolume.clip.ClipTools.readViaWindow(ctx.context, force = true); ""
        }
        def("volume_set", "Volume: set a percent", Need.NONE, "Argument: stream:percent, for example music:50 or ring:100 (streams music, ring, alarm, notification).") { ctx ->
            val am = ctx.context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val name = ctx.arg.substringBefore(':', "music").lowercase().trim()
            val pct = ctx.arg.substringAfter(':', ctx.arg).trim().toIntOrNull()?.coerceIn(0, 100) ?: 100
            val stream = when (name) {
                "ring" -> AudioManager.STREAM_RING
                "alarm" -> AudioManager.STREAM_ALARM
                "notification" -> AudioManager.STREAM_NOTIFICATION
                else -> AudioManager.STREAM_MUSIC
            }
            am.setStreamVolume(stream, Math.round(am.getStreamMaxVolume(stream) * pct / 100f), 0)
            "Volume $name $pct%"
        }
        def("keep_awake_toggle", "Keep the screen awake: toggle", Need.NONE) { ctx ->
            val held = awakeLock
            if (held != null && held.isHeld) { held.release(); awakeLock = null; "Screen may sleep again" }
            else {
                val pm = ctx.context.getSystemService(Context.POWER_SERVICE) as PowerManager
                @Suppress("DEPRECATION")
                val lock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "A:awake")
                lock.acquire()
                awakeLock = lock
                "Screen stays awake (run again to stop)"
            }
        }

        // ---- the app in front
        def("copy_fg_pkg", "Copy the package name of the app in front", Need.NONE, "Needs Usage access (Grant permissions) or Shizuku.") { ctx ->
            val p = needForeground(ctx.context); clipboardSet(ctx.context, p); ctx.vars["app"] = p; p
        }
        def("app_info", "Open App info of the app in front", Need.NONE, "Needs Usage access (Grant permissions) or Shizuku.") { ctx ->
            val p = needForeground(ctx.context)
            ctx.context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "App info: $p"
        }
        def("hail_freeze_fg", "Freeze the app in front with Hail", Need.NONE, "Needs the Hail app plus Usage access or Shizuku.") { ctx ->
            val p = needForeground(ctx.context)
            val i = Intent("com.aistra.hail.action.FREEZE")
                .setComponent(ComponentName("com.aistra.hail", "com.aistra.hail.ui.api.ApiActivity"))
                .putExtra("package", p).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.context.startActivity(i)
            "Hail: freeze $p"
        }
        def("grant_app", "Grant all permissions to the app in front", Need.SHIZUKU) { ctx ->
            val p = needForeground(ctx.context)
            sh(script(ctx.context, "grant_app.sh", "@PKG@" to p)).second.takeLast(600)
        }
        def("revoke_app", "Revoke all permissions of the app in front", Need.SHIZUKU) { ctx ->
            val p = needForeground(ctx.context)
            sh(script(ctx.context, "revoke_app.sh", "@PKG@" to p)).second.takeLast(600)
        }
        def("install_existing", "Install the app in front for another user (argument: user id)", Need.SHIZUKU) { ctx ->
            sh(script(ctx.context, "install_existing.sh", "@TARGET_USER@" to ctx.arg.ifBlank { "999" })).second
        }

        // ---- shell-only things
        def("vpn_stop_all", "Stop every VPN app", Need.SHIZUKU) { sh(script(it.context, "vpn_stop_all.sh")); "VPN apps stopped" }
        def("logcat_kill", "Stop logcat", Need.SHIZUKU) { sh("pkill -f logcat"); "logcat stopped" }
        def("page_down", "Page down (40 small swipes)", Need.SHIZUKU) { sh(script(it.context, "page_down.sh")); "Scrolled" }
        def("paste", "Paste into the focused field", Need.SHIZUKU) { sh("input keyevent 279"); "Pasted" }
        def("hss_tile", "Hotspot Shield tile: click", Need.SHIZUKU) {
            sh("appops set hotspotshield.android.vpn ACTIVATE_VPN allow")
            sh("cmd statusbar click-tile hotspotshield.android.vpn/com.anchorfree.vpntileservice.VpnTileService"); "Tile clicked"
        }
        def("lensnet", "Lens helper script (argument: prep or on)", Need.SHIZUKU, "Runs the bundled lensnet.sh with the argument.") { ctx ->
            val body = script(ctx.context, "lensnet.sh")
            val f = "/data/local/tmp/lensnet.sh"
            val b64 = android.util.Base64.encodeToString(body.toByteArray(), android.util.Base64.NO_WRAP)
            sh("echo $b64 | base64 -d > $f")
            sh("sh $f ${ctx.arg.ifBlank { "on" }}").second.ifBlank { "Done" }
        }
        def("wireless_diag", "Wi-Fi / Bluetooth / hotspot diagnostics", Need.SHIZUKU, "Shows what this phone answers to each command.") { ctx ->
            val cmds = listOf(
                "getprop ro.build.version.release", "getprop ro.build.version.sdk",
                "svc 2>&1 | head -12", "cmd bluetooth_manager help 2>&1 | head -8",
                "cmd connectivity help 2>&1 | head -30", "cmd wifi help 2>&1 | grep -i -E 'softap|lohs'",
                "settings get global bluetooth_on", "settings get global wifi_on",
            )
            cmds.joinToString("\n\n") { c -> "$ " + c + "\n" + sh(c).second }
        }
        def("lens_ocr", "Lens OCR: screenshot, open Lens, then restore Wi-Fi and data", Need.SHIZUKU,
            "Stops VPN apps, cuts Wi-Fi and data, takes a screenshot, opens it in Google Lens, and brings the network back when Lens is closed.") { ctx ->
            requireShizuku()
            val c = ctx.context
            val script = "/data/local/tmp/lensnet.sh"
            val b64 = android.util.Base64.encodeToString(script(c, "lensnet.sh").toByteArray(), android.util.Base64.NO_WRAP)
            sh("echo $b64 | base64 -d > $script")
            sh("sh $script prep")
            try {
                val shot = File("/storage/emulated/0/Documents/screenshot.png")
                if (!shot.canRead()) throw IllegalStateException("A cannot read the screenshot. Allow 'All files access' with the Grant permissions button.")
                val uri = androidx.core.content.FileProvider.getUriForFile(c, c.packageName + ".files", shot)
                val intent = Intent(Intent.ACTION_SEND).setType("image/*").putExtra(Intent.EXTRA_STREAM, uri)
                    .setClassName("com.google.ar.lens", "com.google.vr.apps.ornament.app.lens.LensLauncherActivity")
                    .addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                    )
                intent.clipData = ClipData.newRawUri("", uri)
                c.startActivity(intent)
                fun lensInFront(): Boolean {
                    val p = foregroundPackage(c) ?: return false
                    return p == "com.google.android.googlequicksearchbox" || p == "com.google.ar.lens"
                }
                // Wait for Lens to come up (up to 8 s), then for it to be left (two checks in a row, up to 3 min).
                var waited = 0
                while (!lensInFront() && waited < 8) { Thread.sleep(1000); waited++ }
                var away = 0
                var total = 0
                while (away < 2 && total < 180) {
                    Thread.sleep(1000); total++
                    if (lensInFront()) away = 0 else away++
                }
            } finally {
                // Always bring the network back, even when something above failed.
                runCatching { sh("sh $script on") }
            }
            "Lens closed. Wi-Fi and data are back."
        }
        def("shizuku_open", "Open Shizuku", Need.NONE) { openShizuku(it.context); "Shizuku opened" }
        def("clip_set", "Copy text to the clipboard (argument: the text)", Need.NONE) { clipboardSet(it.context, it.arg); "Copied" }

        // ---- clipboard shell: run the copied command, put the answer on the clipboard, or upload a long one
        def("bgshell", "Run the clipboard as a shell command (argument: upload or plain)", Need.SHIZUKU,
            "Runs what you copied. Short answers are copied back and pasted; long or failed ones are uploaded to tempfile.org.") { ctx ->
            requireShizuku()
            var cmd = clipboardGet(ctx.context).trim()
            if (cmd.isEmpty()) throw IllegalStateException("The clipboard is empty.")
            cmd = cmd.replace(Regex("^\\s*adb\\s+shell\\s+"), "")
            val out = StringBuilder()
            val code = ShizukuShell.run(cmd) { out.append(it).append('\n') }
            val text = out.toString().trim()
            // The command first, behind a dollar sign, then what it printed (and the exit code if it failed).
            val report = "$ " + cmd + "\n" + text + (if (code != 0) "\n[exit $code]" else "")
            if (ctx.arg == "plain") return@def "Ran it (exit $code). Nothing copied or uploaded."
            if (code == 0 && report.length <= 43000) {
                clipboardSet(ctx.context, report)
                Thread.sleep(300)
                runCatching { sh("input keyevent 279") }
                "OK"
            } else {
                val f = File(ctx.context.cacheDir, "bgshell_output.txt")
                f.writeText(report + "\n")
                Thread.sleep(5000)
                val link = uploadTempfile(f.path)
                clipboardSet(ctx.context, link)
                "Uploaded: $link"
            }
        }

        // ---- tempfile.org upload
        def("upload_pick", "Pick a file and upload it to tempfile.org", Need.NONE, "Copies the link to the clipboard.") { ctx ->
            val path = pickFile(ctx.context)
            if (path.isEmpty()) throw IllegalStateException("No file picked.")
            val link = uploadTempfile(path)
            clipboardSet(ctx.context, link)
            ctx.vars["link"] = link
            "Link copied: $link"
        }
        def("upload_file", "Upload a file to tempfile.org (argument: path)", Need.NONE) { ctx ->
            val link = uploadTempfile(ctx.arg)
            clipboardSet(ctx.context, link)
            ctx.vars["link"] = link
            "Link copied: $link"
        }

        // ---- phone codes
        def("ussd", "Dial a USSD or phone code (argument: the code)", Need.NONE, "Without the Phone permission it opens the dialer with the code typed.") { ctx ->
            val uri = Uri.parse("tel:" + Uri.encode(ctx.arg))
            val granted = ctx.context.checkSelfPermission("android.permission.CALL_PHONE") == PackageManager.PERMISSION_GRANTED
            ctx.context.startActivity(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Dialing ${ctx.arg}"
        }
    }
}
