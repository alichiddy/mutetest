package com.newagedevs.gesturevolume.data.local

import android.content.SharedPreferences
import androidx.core.content.edit
import com.newagedevs.gesturevolume.utils.PixelFill
import com.newagedevs.gesturevolume.utils.ShaderFill
import com.newagedevs.gesturevolume.utils.EffortFill
import com.newagedevs.gesturevolume.utils.GlimmerFill
import com.newagedevs.gesturevolume.utils.SurgeFill
import com.newagedevs.gesturevolume.utils.LevelFeedback
import com.newagedevs.gesturevolume.utils.SliderFill
import com.newagedevs.gesturevolume.utils.HandlerShape

/**
 * The Quick panel: what it controls, how it looks, and how hard it buzzes.
 *
 * The panel is opened by `HandlerActions.OPEN_QUICK_SLIDER` from whichever gesture slot the user
 * put it in, and it then takes its own touches until it closes. It used to be the payload of a
 * long horizontal swipe, sharing that stroke with the Deck; the `sliderOpenWith` key that chose
 * which direction opened it is gone with the gesture, and is deliberately left unread rather than
 * migrated — there is no direction left for it to name.
 *
 * Everything else about it is a setting because the panel is worth almost nothing if it adjusts
 * the wrong quantity, and because one that buzzes at every step is delightful to some people and
 * intolerable to others.
 *
 * The identifiers are a persistence format, like [com.newagedevs.gesturevolume.utils.HandlerActions]:
 * written verbatim into preferences, never renamed.
 */
class QuickSliderStore(private val prefs: SharedPreferences) {

    companion object {
        /**
         * Which long swipe opens the panel, on top of whichever gesture slot it is bound to.
         *
         * The panel is an action first — it can go on a tap, a long press or the menu — and this
         * is the extra opener for people who want it on the stroke that made the feature. It is a
         * setting rather than a fixed behaviour because it is the one opener that shares a
         * direction with the Deck, and anyone who finds that ambiguous can switch it off here
         * without losing the panel.
         */
        const val OPEN_OFF = "off"
        const val OPEN_IN = "in"
        const val OPEN_OUT = "out"
        const val OPEN_BOTH = "both"
        val ALL_OPENERS = listOf(OPEN_IN, OPEN_OUT, OPEN_BOTH, OPEN_OFF)

        /** What the slider drives. */
        const val TARGET_BRIGHTNESS = "brightness"

        /**
         * The volume that matters right now, worked out as the panel opens: the call's during a
         * call, the ringer while it rings, otherwise whatever is playing, and media when nothing
         * is. What the rocker itself would move, so the panel never shows a level the call is not
         * at. See `OverlayController.adaptiveVolume`.
         */
        const val TARGET_ADAPTIVE = "adaptive"
        const val TARGET_MEDIA = "media"
        const val TARGET_RING = "ring"
        const val TARGET_ALARM = "alarm"
        val ALL_TARGETS = listOf(TARGET_BRIGHTNESS, TARGET_ADAPTIVE, TARGET_MEDIA, TARGET_RING, TARGET_ALARM)

        /** How hard each step buzzes. */
        const val HAPTIC_OFF = "off"
        const val HAPTIC_LIGHT = "light"
        const val HAPTIC_MEDIUM = "medium"
        const val HAPTIC_STRONG = "strong"
        val ALL_HAPTICS = listOf(HAPTIC_OFF, HAPTIC_LIGHT, HAPTIC_MEDIUM, HAPTIC_STRONG)

        /** Whether each step makes a sound, and which. See [getStepSound]. */
        const val SOUND_OFF = "off"
        const val SOUND_CLICK = "click"
        const val SOUND_ADAPTIVE = "adaptive"
        val ALL_SOUNDS = listOf(SOUND_OFF, SOUND_CLICK, SOUND_ADAPTIVE)

        /**
         * What the hardware volume keys do to the panel.
         *
         * Off leaves the keys alone. With the system opens the panel when the level changes,
         * which the app hears about half a second after the press, beside the system's own
         * slider. Instant is handed the press itself by the accessibility service, before the
         * system acts on it, and takes the system slider's place; with that service off it
         * behaves like With the system. See `OverlayController.onVolumeKey`.
         */
        const val VOLUME_KEYS_OFF = "off"
        const val VOLUME_KEYS_FOLLOW = "follow"
        const val VOLUME_KEYS_INSTANT = "instant"
        val ALL_VOLUME_KEY_MODES = listOf(VOLUME_KEYS_OFF, VOLUME_KEYS_FOLLOW, VOLUME_KEYS_INSTANT)

        /** The icon that says what the panel controls. See [getIconName]. */
        const val ICON_AUTO = "auto"

        private const val OPEN_WITH = "sliderOpenWith"
        private const val TARGET = "sliderTarget"
        private const val LENGTH = "sliderLengthDp"
        private const val THICKNESS = "sliderThicknessDp"
        private const val CORNER = "sliderCornerDp"
        private const val TRACK_COLOR = "sliderTrackColor"
        private const val FILL_COLOR = "sliderFillColor"
        private const val HAPTIC = "sliderHaptic"
        private const val STEP_SOUND = "sliderStepSound"
        private const val CONTENT_COLORS_ON = "sliderContentColorsOn"
        private const val VALUE_COLOR = "sliderValueColor"
        private const val ICON_COLOR = "sliderIconColor"
        private const val SHOW_VALUE = "sliderShowValue"
        private const val SHOW_ICON = "sliderShowIcon"
        private const val AUTO_BRIGHTNESS_OFF = "sliderDisableAutoBrightness"
        private const val FILL_STYLE = "sliderFillStyle"
        private const val PIXEL_PATTERN = "sliderPixelPattern"
        private const val PIXEL_SPEED = "sliderPixelSpeed"
        private const val PIXEL_COLUMNS = "sliderPixelColumns"
        private const val PIXEL_GAP = "sliderPixelGap"
        private const val PIXEL_ROUNDNESS = "sliderPixelRoundness"
        private const val PIXEL_GLOW = "sliderPixelGlow"
        private const val PIXEL_REST = "sliderPixelRest"
        private const val SHADER_EFFECT = "sliderShaderEffect"
        private const val SHADER_SPEED = "sliderShaderSpeed"
        private const val SHADER_SCALE = "sliderShaderScale"
        private const val SHADER_DETAIL = "sliderShaderDetail"
        private const val SHADER_BRIGHTNESS = "sliderShaderBrightness"
        private const val SHADER_GRAIN = "sliderShaderGrain"
        private const val SHADER_REST = "sliderShaderRest"
        private const val EFFORT_LOOK = "sliderEffortLook"
        private const val EFFORT_SPEED = "sliderEffortSpeed"
        private const val EFFORT_LABELS = "sliderEffortLabels"
        private const val GLIMMER_SPEED = "sliderGlimmerSpeed"
        private const val GLIMMER_HANDLE = "sliderGlimmerHandle"
        private const val GLIMMER_STOPS = "sliderGlimmerStops"
        private const val SURGE_LOOK = "sliderSurgeLook"
        private const val SURGE_SPEED = "sliderSurgeSpeed"
        private const val SURGE_SIZE = "sliderSurgeSize"
        private const val SURGE_EDGE = "sliderSurgeEdge"
        private const val SURGE_GLOW = "sliderSurgeGlow"
        private const val SURGE_TRAIL = "sliderSurgeTrail"
        private const val SURGE_REST = "sliderSurgeRest"
        private const val FEEDBACK_SPEED = "sliderFeedbackSpeed"
        private const val FEEDBACK_FOLLOW = "sliderFeedbackFollow"
        private const val FEEDBACK_LOW = "sliderFeedbackLow"
        private const val FEEDBACK_FULL = "sliderFeedbackFull"
        private const val FEEDBACK_MAX = "sliderFeedbackMax"
        private const val FOLLOW_HANDLER = "sliderFollowHandlerShape"
        private const val OPEN_ON_VOLUME_KEY = "sliderOpenOnVolumeKey"
        private const val VOLUME_KEYS = "sliderVolumeKeys"
        private const val CORNER_TL = "sliderCornerTL"
        private const val CORNER_TR = "sliderCornerTR"
        private const val CORNER_BL = "sliderCornerBL"
        private const val CORNER_BR = "sliderCornerBR"
        private const val SHAPE = "sliderShape"
        private const val SHAPE_FLARE = "sliderShapeFlare"
        private const val VALUE_MARGIN = "sliderValueMarginDp"
        private const val ICON_MARGIN = "sliderIconMarginDp"
        private const val ICON = "sliderIcon"
        private const val ICON_OPENS_VOLUME_PANEL = "sliderIconOpensVolumePanel"
        private const val FILL_COLORS_ON = "sliderFillColorsOn"
        private val FILL_COLOR_KEYS = arrayOf("sliderFillColor0", "sliderFillColor1", "sliderFillColor2")

        /** How many colours of their own a user gives the fill animations. See [getFillColors]. */
        const val FILL_COLOR_COUNT = 3

        /**
         * The animation colours until someone picks their own: cyan, violet and rose.
         *
         * Chosen to be worth seeing on the first switch-on, since that is when the user decides
         * whether the setting is any good — bright enough to glow on the dark grounds the pictures
         * paint, and far enough apart round the wheel that the blends between them are colours too.
         */
        val DEFAULT_FILL_COLORS: IntArray
            get() = intArrayOf(0xFF4FE3FF.toInt(), 0xFFA77CFF.toInt(), 0xFFFF5CA8.toInt())

        /**
         * What the panel is set to drive, read straight from [prefs].
         *
         * For the one reader with no store to hand: the icon drawn for the "Quick panel" action,
         * which is drawn in pickers and in the overlay's own menu alike.
         */
        fun targetOf(prefs: SharedPreferences): String {
            val stored = prefs.getString(TARGET, DEFAULT_TARGET) ?: DEFAULT_TARGET
            return if (stored in ALL_TARGETS) stored else DEFAULT_TARGET
        }

        /*
         * The defaults below are the Dock preset's Quick panel — see
         * `HandlerPresets.DEFAULT.behaviour.slider`, which a unit test holds these to — so a fresh
         * install opens the panel the default preset describes. An install from before they moved
         * keeps the ones it had: see [pinPreDockDefaults].
         */

        /**
         * The adaptive volume: media, which is what everyone who swipes a volume bar is usually
         * reaching for, and the call's own volume when there is a call to turn down.
         */
        const val DEFAULT_TARGET = TARGET_ADAPTIVE

        /**
         * Instant: the press itself opens the panel, in place of the system slider. Needs the
         * accessibility service; without it this behaves like With the system.
         */
        const val DEFAULT_VOLUME_KEYS = VOLUME_KEYS_INSTANT
        const val DEFAULT_EDGE_OFFSET = 0f
        const val DEFAULT_FOLLOW_HANDLER_SHAPE = true
        const val DEFAULT_SHOW_VALUE = true
        const val DEFAULT_SHOW_ICON = true

        /**
         * The defaults as they stood before the Dock preset's took over, for [pinPreDockDefaults].
         * Frozen literals on purpose: they record what an existing install was already reading.
         */
        private const val PRE_DOCK_TARGET = TARGET_BRIGHTNESS
        private const val PRE_DOCK_THICKNESS = 20f

        /**
         * Writes the pre-Dock defaults into [editor] for every key [prefs] does not hold, so an
         * install that already existed keeps the panel it had. Called once, from `SharedPref`'s
         * one-shot pin; a fresh install never reaches it.
         *
         * The volume keys are pinned only when neither their choice nor the older switch is
         * stored: an install with the switch still has its answer carried across by
         * [getVolumeKeyMode], and pinning over it would lose an Off.
         */
        fun pinPreDockDefaults(prefs: SharedPreferences, editor: SharedPreferences.Editor) {
            if (!prefs.contains(TARGET)) editor.putString(TARGET, PRE_DOCK_TARGET)
            if (!prefs.contains(THICKNESS)) editor.putFloat(THICKNESS, PRE_DOCK_THICKNESS)
            if (!prefs.contains(VOLUME_KEYS) && !prefs.contains(OPEN_ON_VOLUME_KEY)) {
                editor.putString(VOLUME_KEYS, VOLUME_KEYS_FOLLOW)
            }
        }

        const val DEFAULT_LENGTH = 220f
        /**
         * The thinnest the open panel may be.
         *
         * Ten, not the forty-eight it was. Forty-eight was a thumb target, and the reasoning was
         * sound for a panel you aim at — but the panel is not only that: it is also a readout that
         * grows out of the bar, and somebody who wants a sliver that barely widens is entitled to
         * one. The window it lives in keeps its own floor, so the thing a finger lands on has not
         * changed; only the part that is painted has. See `QuickSliderView.setDrawnThickness`.
         */
        const val MIN_THICKNESS = 10f
        const val DEFAULT_THICKNESS = 32f

        /** The furthest the open panel may stand in from the edge. See [getEdgeOffsetDp]. */
        const val MAX_EDGE_OFFSET = 48f
        private const val EDGE_OFFSET = "sliderEdgeOffsetDp"

        /** Where the number sits from the panel's top, and the icon from its bottom, until moved. */
        const val DEFAULT_VALUE_MARGIN = 35f
        const val DEFAULT_ICON_MARGIN = 35f
        const val MAX_CONTENT_PADDING = 140f
        /** Half the thickness: a track with fully round ends, matching the bar's pill shape. */
        const val DEFAULT_CORNER = 22f
        const val DEFAULT_TRACK_COLOR = 0xFF1C1C20.toInt()
        const val DEFAULT_FILL_COLOR = 0xFFFFFFFF.toInt()
    }

    /**
     * Which long swipe opens the panel, if any. **Off unless the user asks for it.**
     *
     * The horizontal swipe belongs to the Deck. Sharing it meant the two were one stroke told
     * apart by a distance, and no arrangement of thresholds makes a distance visible to a thumb —
     * so the Deck swipe kept turning into the panel and the panel kept refusing to open when it
     * was wanted. The panel's home is the vertical swipe now, where nothing else lives, plus
     * whichever other slot the user binds `OPEN_QUICK_SLIDER` to.
     *
     * The setting survives because the gesture is genuinely nice when it is the only thing on that
     * direction — a bar with the Deck unbound, say. It is simply not something to hand anyone who
     * has not asked.
     */
    fun getOpenWith(): String {
        val stored = prefs.getString(OPEN_WITH, OPEN_OFF) ?: OPEN_OFF
        return if (stored in ALL_OPENERS) stored else OPEN_OFF
    }

    fun setOpenWith(value: String) = prefs.edit { putString(OPEN_WITH, value) }

    /** Whether a long swipe in this direction opens the panel. */
    fun opensOn(inward: Boolean): Boolean = when (getOpenWith()) {
        OPEN_BOTH -> true
        OPEN_IN -> inward
        OPEN_OUT -> !inward
        else -> false
    }

    fun getTarget(): String = targetOf(prefs)

    fun setTarget(value: String) = prefs.edit { putString(TARGET, value) }

    /** How far the track reaches in from the bar. Also the travel one full sweep costs. */
    fun getLengthDp(): Float = prefs.getFloat(LENGTH, DEFAULT_LENGTH).coerceIn(120f, 320f)
    fun setLengthDp(value: Float) = prefs.edit { putFloat(LENGTH, value.coerceIn(120f, 320f)) }

    /**
     * How wide the open panel is.
     *
     * The floor is 48dp and not the 24dp it used to be, because the panel is floored at 48dp when
     * it is built — see `OverlayController.PANEL_MIN_THICKNESS_DP`, which is there because this is
     * a control a thumb aims at. The store's range and the live floor disagreeing meant the bottom
     * half of the slider moved the preview and did nothing at all to the panel.
     */
    fun getThicknessDp(): Float = prefs.getFloat(THICKNESS, DEFAULT_THICKNESS).coerceIn(MIN_THICKNESS, 72f)
    fun setThicknessDp(value: Float) = prefs.edit { putFloat(THICKNESS, value.coerceIn(MIN_THICKNESS, 72f)) }

    /**
     * How far the open panel stands in from the screen edge, in dp. Zero by default: flush, the
     * way it has always opened.
     *
     * The panel's own, rather than the bar's edge offset, because the two answer different
     * questions. The bar's keeps a thin target clear of the back gesture; the panel is a control
     * several times wider that the thumb drags along, and on a curved screen the part of it over
     * the curve is the part that is hard to read and harder to aim at. It still grows out of the
     * bar wherever the bar is; it only comes to rest this much further in.
     */
    fun getEdgeOffsetDp(): Float = prefs.getFloat(EDGE_OFFSET, DEFAULT_EDGE_OFFSET).coerceIn(0f, MAX_EDGE_OFFSET)
    fun setEdgeOffsetDp(value: Float) = prefs.edit { putFloat(EDGE_OFFSET, value.coerceIn(0f, MAX_EDGE_OFFSET)) }

    /**
     * The radius the open panel's corners settle at.
     *
     * Its own, rather than the handler's, which is what it used to borrow. The panel still *starts*
     * at the bar's corners — that is what makes the opening read as the bar growing rather than as
     * a second object appearing over it — and travels to this one on the way out. The view was
     * already interpolating each corner from its collapsed value to its expanded one, so the only
     * thing that had changed was that both ends were being handed the same number.
     */
    /**
     * How far the number sits from the top of the panel, and the icon from the bottom, in dp.
     *
     * Measured from the panel's own top and bottom edges and from nothing else. They used to be
     * measured from where a tab's sweep ended, which kept them clear of the curve — and meant that
     * dragging the sweep slider slid the number and the icon up and down the panel with it, which
     * is two things moving where the user asked for one. Now the sweep changes the outline and
     * these change the contents, and neither moves the other.
     *
     * Defaults with room to spare for the tab the default handler cuts, and a range deep enough to
     * clear the steepest sweep on the tallest panel.
     */
    fun getValueMarginDp(): Float = prefs.getFloat(VALUE_MARGIN, DEFAULT_VALUE_MARGIN).coerceIn(0f, MAX_CONTENT_PADDING)
    fun setValueMarginDp(value: Float) = prefs.edit { putFloat(VALUE_MARGIN, value.coerceIn(0f, MAX_CONTENT_PADDING)) }

    fun getIconMarginDp(): Float = prefs.getFloat(ICON_MARGIN, DEFAULT_ICON_MARGIN).coerceIn(0f, MAX_CONTENT_PADDING)
    fun setIconMarginDp(value: Float) = prefs.edit { putFloat(ICON_MARGIN, value.coerceIn(0f, MAX_CONTENT_PADDING)) }

    fun getCornerDp(): Float = prefs.getFloat(CORNER, DEFAULT_CORNER).coerceIn(0f, 40f)
    fun setCornerDp(value: Float) = prefs.edit { putFloat(CORNER, value.coerceIn(0f, 40f)) }

    /**
     * Whether the panel's outline is the handler's, scaled up, rather than its own.
     *
     * On by default, and that is the point: the panel is the bar grown, so a bar cut to a tab
     * should open into a tab and a bar with one square corner should open with one. Nobody should
     * have to set the same shape twice to get the obvious result. Turning it off hands over the
     * four radii and the shape below, which is for the person who wants a round pill out of a
     * square bar.
     */
    fun getFollowHandlerShape(): Boolean = prefs.getBoolean(FOLLOW_HANDLER, DEFAULT_FOLLOW_HANDLER_SHAPE)
    fun setFollowHandlerShape(value: Boolean) = prefs.edit { putBoolean(FOLLOW_HANDLER, value) }

    /**
     * The panel's four corner radii, clockwise from the top left, when it is not following the bar.
     *
     * Four rather than the one it had, because the bar has four and the panel is meant to be the
     * bar: a shape that is square where it meets the screen edge cannot be expressed with a single
     * number, and that is the shape the default handler wears.
     */
    fun getCornerTL(): Float = prefs.getFloat(CORNER_TL, DEFAULT_CORNER).coerceIn(0f, 60f)
    fun getCornerTR(): Float = prefs.getFloat(CORNER_TR, DEFAULT_CORNER).coerceIn(0f, 60f)
    fun getCornerBL(): Float = prefs.getFloat(CORNER_BL, DEFAULT_CORNER).coerceIn(0f, 60f)
    fun getCornerBR(): Float = prefs.getFloat(CORNER_BR, DEFAULT_CORNER).coerceIn(0f, 60f)

    fun setCorners(topLeft: Float, topRight: Float, bottomLeft: Float, bottomRight: Float) = prefs.edit {
        putFloat(CORNER_TL, topLeft.coerceIn(0f, 60f))
        putFloat(CORNER_TR, topRight.coerceIn(0f, 60f))
        putFloat(CORNER_BL, bottomLeft.coerceIn(0f, 60f))
        putFloat(CORNER_BR, bottomRight.coerceIn(0f, 60f))
    }

    /** The panel's own outline, when it is not following the bar. See [HandlerShape]. */
    fun getShape(): String = HandlerShape.sanitize(prefs.getString(SHAPE, null))
    fun setShape(value: String) = prefs.edit { putString(SHAPE, HandlerShape.sanitize(value)) }

    /** Whether the sweep has ever been set by hand, as opposed to being worked out from the bar. */
    fun hasShapeFlare(): Boolean = prefs.contains(SHAPE_FLARE)

    fun getShapeFlare(): Float =
        HandlerShape.sanitizeFlare(prefs.getFloat(SHAPE_FLARE, HandlerShape.DEFAULT_FLARE))

    fun setShapeFlare(value: Float) =
        prefs.edit { putFloat(SHAPE_FLARE, HandlerShape.sanitizeFlare(value)) }

    /**
     * The colour the open panel's track settles at.
     *
     * Like the corner radius, the panel begins at the bar's colour and blends to this one as it
     * grows — `QuickSliderView.refreshBlend` has always done that interpolation; it was simply
     * being given the bar's colour at both ends.
     */
    fun getTrackColor(): Int = prefs.getInt(TRACK_COLOR, DEFAULT_TRACK_COLOR)
    fun setTrackColor(value: Int) = prefs.edit { putInt(TRACK_COLOR, value) }

    fun getFillColor(): Int = prefs.getInt(FILL_COLOR, DEFAULT_FILL_COLOR)
    fun setFillColor(value: Int) = prefs.edit { putInt(FILL_COLOR, value) }

    fun getHaptic(): String {
        val stored = prefs.getString(HAPTIC, HAPTIC_LIGHT) ?: HAPTIC_LIGHT
        return if (stored in ALL_HAPTICS) stored else HAPTIC_LIGHT
    }

    fun setHaptic(value: String) = prefs.edit { putString(HAPTIC, value) }

    /**
     * A tick on every step a swipe or a drag moves the panel: one of [ALL_SOUNDS].
     *
     * Off by default — sound is the one kind of feedback everyone nearby gets too. Click is one
     * steady note on the system's own sounds. Adaptive follows the level: its pitch rises with the
     * value, and on a volume panel it plays on the stream being set, so it is exactly as loud as
     * the volume it has just chosen. See [com.newagedevs.gesturevolume.utils.StepSound].
     */
    fun getStepSound(): String {
        val stored = prefs.getString(STEP_SOUND, SOUND_OFF) ?: SOUND_OFF
        return if (stored in ALL_SOUNDS) stored else SOUND_OFF
    }

    fun setStepSound(value: String) = prefs.edit { putString(STEP_SOUND, value) }

    /**
     * Whether the number and the icon wear colours of the user's own.
     *
     * Off by default, which is the panel as it has always been: both are written in the fill
     * colour over the empty track and in the track colour over the fill, so they stay legible
     * wherever the fill line is. On, each keeps one colour the whole way up.
     */
    fun getContentColorsEnabled(): Boolean = prefs.getBoolean(CONTENT_COLORS_ON, false)
    fun setContentColorsEnabled(value: Boolean) = prefs.edit { putBoolean(CONTENT_COLORS_ON, value) }

    fun getValueColor(): Int = prefs.getInt(VALUE_COLOR, DEFAULT_FILL_COLOR)
    fun setValueColor(value: Int) = prefs.edit { putInt(VALUE_COLOR, value) }

    fun getIconColor(): Int = prefs.getInt(ICON_COLOR, DEFAULT_FILL_COLOR)
    fun setIconColor(value: Int) = prefs.edit { putInt(ICON_COLOR, value) }

    /** The number's colour when the user has chosen one, or null for the swapping default. */
    fun getEffectiveValueColor(): Int? = if (getContentColorsEnabled()) getValueColor() else null

    /** The icon's colour when the user has chosen one, or null for the swapping default. */
    fun getEffectiveIconColor(): Int? = if (getContentColorsEnabled()) getIconColor() else null

    /**
     * What the volume keys do to the panel: one of [ALL_VOLUME_KEY_MODES].
     *
     * Before there was a choice there was a switch, and a switch that was on meant what With the
     * system means now, so its answer is carried across until a choice is made. With neither
     * stored, [DEFAULT_VOLUME_KEYS].
     */
    fun getVolumeKeyMode(): String {
        val stored = prefs.getString(VOLUME_KEYS, null)
        if (stored in ALL_VOLUME_KEY_MODES) return stored!!
        if (!prefs.contains(OPEN_ON_VOLUME_KEY)) return DEFAULT_VOLUME_KEYS
        return if (prefs.getBoolean(OPEN_ON_VOLUME_KEY, true)) VOLUME_KEYS_FOLLOW else VOLUME_KEYS_OFF
    }

    fun setVolumeKeyMode(value: String) = prefs.edit {
        putString(VOLUME_KEYS, if (value in ALL_VOLUME_KEY_MODES) value else VOLUME_KEYS_FOLLOW)
    }

    /** Whether the volume keys open the panel at all, by either route. */
    fun getOpenOnVolumeKey(): Boolean = getVolumeKeyMode() != VOLUME_KEYS_OFF

    /** What the filled portion does while the panel is open. See [SliderFill]. */
    fun getFillStyle(): String = SliderFill.sanitize(prefs.getString(FILL_STYLE, null))
    fun setFillStyle(value: String) = prefs.edit { putString(FILL_STYLE, SliderFill.sanitize(value)) }

    /**
     * The Pixels fill's own settings: its pattern, and the six things about the grid the user
     * tunes. Only read while [getFillStyle] is [SliderFill.PIXELS], and kept when it is not, so
     * trying another fill and coming back finds the grid as it was left.
     */
    fun getPixelStyle(): PixelFill.Style {
        val d = PixelFill.Style()
        return PixelFill.Style(
            pattern = prefs.getString(PIXEL_PATTERN, d.pattern) ?: d.pattern,
            speed = prefs.getFloat(PIXEL_SPEED, d.speed),
            columns = prefs.getInt(PIXEL_COLUMNS, d.columns),
            gap = prefs.getFloat(PIXEL_GAP, d.gap),
            roundness = prefs.getFloat(PIXEL_ROUNDNESS, d.roundness),
            glow = prefs.getFloat(PIXEL_GLOW, d.glow),
            rest = prefs.getFloat(PIXEL_REST, d.rest),
        ).sanitized()
    }

    fun setPixelStyle(value: PixelFill.Style) {
        val s = value.sanitized()
        prefs.edit {
            putString(PIXEL_PATTERN, s.pattern)
            putFloat(PIXEL_SPEED, s.speed)
            putInt(PIXEL_COLUMNS, s.columns)
            putFloat(PIXEL_GAP, s.gap)
            putFloat(PIXEL_ROUNDNESS, s.roundness)
            putFloat(PIXEL_GLOW, s.glow)
            putFloat(PIXEL_REST, s.rest)
        }
    }

    /**
     * The Shaders fill's own settings: its effect, and the six things every effect answers to.
     * Kept while another fill is chosen, like the Pixels grid's.
     */
    fun getShaderStyle(): ShaderFill.Style {
        val d = ShaderFill.Style()
        return ShaderFill.Style(
            effect = prefs.getString(SHADER_EFFECT, d.effect) ?: d.effect,
            speed = prefs.getFloat(SHADER_SPEED, d.speed),
            scale = prefs.getFloat(SHADER_SCALE, d.scale),
            detail = prefs.getFloat(SHADER_DETAIL, d.detail),
            brightness = prefs.getFloat(SHADER_BRIGHTNESS, d.brightness),
            grain = prefs.getFloat(SHADER_GRAIN, d.grain),
            rest = prefs.getFloat(SHADER_REST, d.rest),
        ).sanitized()
    }

    fun setShaderStyle(value: ShaderFill.Style) {
        val s = value.sanitized()
        prefs.edit {
            putString(SHADER_EFFECT, s.effect)
            putFloat(SHADER_SPEED, s.speed)
            putFloat(SHADER_SCALE, s.scale)
            putFloat(SHADER_DETAIL, s.detail)
            putFloat(SHADER_BRIGHTNESS, s.brightness)
            putFloat(SHADER_GRAIN, s.grain)
            putFloat(SHADER_REST, s.rest)
        }
    }

    /**
     * The Effort fill's own settings: its look, how fast it moves, and whether the level is named.
     * Kept while another fill is chosen, like the Pixels grid's.
     */
    fun getEffortStyle(): EffortFill.Style {
        val d = EffortFill.Style()
        return EffortFill.Style(
            look = prefs.getString(EFFORT_LOOK, d.look) ?: d.look,
            speed = prefs.getFloat(EFFORT_SPEED, d.speed),
            labels = prefs.getBoolean(EFFORT_LABELS, d.labels),
        ).sanitized()
    }

    fun setEffortStyle(value: EffortFill.Style) {
        val s = value.sanitized()
        prefs.edit {
            putString(EFFORT_LOOK, s.look)
            putFloat(EFFORT_SPEED, s.speed)
            putBoolean(EFFORT_LABELS, s.labels)
        }
    }

    /**
     * The Glimmer fill's own settings: how fast it moves, and whether it has a handle and stops.
     * Kept while another fill is chosen, like the Pixels grid's.
     */
    fun getGlimmerStyle(): GlimmerFill.Style {
        val d = GlimmerFill.Style()
        return GlimmerFill.Style(
            speed = prefs.getFloat(GLIMMER_SPEED, d.speed),
            handle = prefs.getBoolean(GLIMMER_HANDLE, d.handle),
            stops = prefs.getBoolean(GLIMMER_STOPS, d.stops),
        ).sanitized()
    }

    fun setGlimmerStyle(value: GlimmerFill.Style) {
        val s = value.sanitized()
        prefs.edit {
            putFloat(GLIMMER_SPEED, s.speed)
            putBoolean(GLIMMER_HANDLE, s.handle)
            putBoolean(GLIMMER_STOPS, s.stops)
        }
    }

    /**
     * The Surge fill's own settings: its look, and the six things every look answers to. Kept while
     * another fill is chosen, like the shader's.
     */
    fun getSurgeStyle(): SurgeFill.Style {
        val d = SurgeFill.Style()
        return SurgeFill.Style(
            look = prefs.getString(SURGE_LOOK, d.look) ?: d.look,
            speed = prefs.getFloat(SURGE_SPEED, d.speed),
            size = prefs.getFloat(SURGE_SIZE, d.size),
            edge = prefs.getFloat(SURGE_EDGE, d.edge),
            glow = prefs.getFloat(SURGE_GLOW, d.glow),
            trail = prefs.getFloat(SURGE_TRAIL, d.trail),
            rest = prefs.getFloat(SURGE_REST, d.rest),
        ).sanitized()
    }

    fun setSurgeStyle(value: SurgeFill.Style) {
        val s = value.sanitized()
        prefs.edit {
            putString(SURGE_LOOK, s.look)
            putFloat(SURGE_SPEED, s.speed)
            putFloat(SURGE_SIZE, s.size)
            putFloat(SURGE_EDGE, s.edge)
            putFloat(SURGE_GLOW, s.glow)
            putFloat(SURGE_TRAIL, s.trail)
            putFloat(SURGE_REST, s.rest)
        }
    }

    /**
     * How every fill answers the level, and how fast the fills without a speed of their own move.
     * One setting for all of them: see [LevelFeedback].
     */
    fun getLevelFeedback(): LevelFeedback.Style {
        val d = LevelFeedback.Style()
        return LevelFeedback.Style(
            speed = prefs.getFloat(FEEDBACK_SPEED, d.speed),
            follow = prefs.getBoolean(FEEDBACK_FOLLOW, d.follow),
            low = prefs.getBoolean(FEEDBACK_LOW, d.low),
            full = prefs.getBoolean(FEEDBACK_FULL, d.full),
            max = prefs.getString(FEEDBACK_MAX, d.max) ?: d.max,
        ).sanitized()
    }

    fun setLevelFeedback(value: LevelFeedback.Style) {
        val s = value.sanitized()
        prefs.edit {
            putFloat(FEEDBACK_SPEED, s.speed)
            putBoolean(FEEDBACK_FOLLOW, s.follow)
            putBoolean(FEEDBACK_LOW, s.low)
            putBoolean(FEEDBACK_FULL, s.full)
            putString(FEEDBACK_MAX, s.max)
        }
    }

    /**
     * Whether the fill animations are painted in the user's colours rather than their own.
     *
     * Off by default: each picture's own palette is the idea of it, and a user should arrive at a
     * pink matrix rain by asking for one. Switching it off keeps the colours, so switching it back
     * on is the same choice again rather than the defaults.
     */
    fun getFillColorsEnabled(): Boolean = prefs.getBoolean(FILL_COLORS_ON, false)
    fun setFillColorsEnabled(value: Boolean) = prefs.edit { putBoolean(FILL_COLORS_ON, value) }

    /**
     * The user's animation colours, always exactly [FILL_COLOR_COUNT], first to last.
     *
     * A set of three rather than one per style: see `SliderFill.paletteWith`, which spreads them
     * over however many colours a style paints with. Not the same thing as [getFillColor], which is
     * the plain fill under every style.
     */
    fun getFillColors(): IntArray {
        val defaults = DEFAULT_FILL_COLORS
        return IntArray(FILL_COLOR_COUNT) { prefs.getInt(FILL_COLOR_KEYS[it], defaults[it]) }
    }

    /** One of the animation colours, by its place in [getFillColors]. Out-of-range places are ignored. */
    fun setFillColor(index: Int, color: Int) {
        if (index !in 0 until FILL_COLOR_COUNT) return
        prefs.edit { putInt(FILL_COLOR_KEYS[index], color) }
    }

    /** The colours to hand `QuickSliderView.setFillColors`: the user's when switched on, else null. */
    fun getEffectiveFillColors(): IntArray? = if (getFillColorsEnabled()) getFillColors() else null

    fun getShowValue(): Boolean = prefs.getBoolean(SHOW_VALUE, DEFAULT_SHOW_VALUE)
    fun setShowValue(value: Boolean) = prefs.edit { putBoolean(SHOW_VALUE, value) }

    fun getShowIcon(): Boolean = prefs.getBoolean(SHOW_ICON, DEFAULT_SHOW_ICON)
    fun setShowIcon(value: Boolean) = prefs.edit { putBoolean(SHOW_ICON, value) }

    /**
     * Which icon the panel wears: a drawable's entry name, or [ICON_AUTO] for the one that says
     * what the panel controls, a speaker for a volume and a sun for brightness.
     *
     * A name rather than a resource id, for the reason the handler's icon is stored as one: ids are
     * renumbered between builds, and a stale one draws the wrong thing or nothing at all.
     */
    fun getIconName(): String = prefs.getString(ICON, null)?.takeIf { it.isNotBlank() } ?: ICON_AUTO
    fun setIconName(value: String) = prefs.edit { putString(ICON, value.ifBlank { ICON_AUTO }) }

    /**
     * Whether a tap on the icon opens the system's full volume panel, every stream on one sheet,
     * instead of setting the level at the spot where the icon happens to be drawn.
     *
     * On unless switched off. The icon is a small target nobody lands on by accident, and the sheet
     * is everything this panel does not show: the other volumes, and where the sound is playing.
     */
    fun getIconOpensVolumePanel(): Boolean = prefs.getBoolean(ICON_OPENS_VOLUME_PANEL, true)
    fun setIconOpensVolumePanel(value: Boolean) = prefs.edit { putBoolean(ICON_OPENS_VOLUME_PANEL, value) }

    /**
     * Whether opening the brightness slider switches adaptive brightness off.
     *
     * On by default, and the app hands it back when the service stops — the light sensor would
     * otherwise overwrite whatever the user set within a second or two, which reads as the
     * slider not working at all.
     */
    fun getDisableAutoBrightness(): Boolean = prefs.getBoolean(AUTO_BRIGHTNESS_OFF, true)
    fun setDisableAutoBrightness(value: Boolean) = prefs.edit { putBoolean(AUTO_BRIGHTNESS_OFF, value) }
}
