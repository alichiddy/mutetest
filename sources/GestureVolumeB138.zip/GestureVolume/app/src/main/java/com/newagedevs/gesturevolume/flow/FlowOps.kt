package com.newagedevs.gesturevolume.flow

/** Block-aware list operations for the flow editor. Flat list, blocks opened by if/repeat and closed by end. */
object FlowOps {
    /** Steps copied in the editor; kept for the process so they can be pasted into another flow. */
    var clip: List<Step> = emptyList()

    private fun opens(s: Step) = s.type == Step.IF || s.type == Step.REPEAT

    fun matchEnd(steps: List<Step>, i: Int): Int {
        var depth = 0
        for (j in i + 1 until steps.size) {
            if (opens(steps[j])) depth++
            else if (steps[j].type == Step.END) { if (depth == 0) return j else depth-- }
        }
        return steps.size - 1
    }

    private fun matchOpen(steps: List<Step>, endIdx: Int): Int {
        var depth = 0
        for (j in endIdx - 1 downTo 0) {
            if (steps[j].type == Step.END) depth++
            else if (opens(steps[j])) { if (depth == 0) return j else depth-- }
        }
        return 0
    }

    /** The step, or for an if / repeat the whole block up to its end. */
    fun blockRange(steps: List<Step>, i: Int): IntRange =
        if (i in steps.indices && opens(steps[i])) i..matchEnd(steps, i) else i..i

    fun movable(steps: List<Step>, i: Int) = i in steps.indices && steps[i].type != Step.ELSE && steps[i].type != Step.END

    /** Moves the block up past its previous sibling. Returns the new start index or -1. */
    fun moveUp(steps: MutableList<Step>, i: Int): Int {
        if (!movable(steps, i) || i == 0) return -1
        val r = blockRange(steps, i)
        val j = i - 1
        val prevStart = when {
            steps[j].type == Step.END -> matchOpen(steps, j)
            opens(steps[j]) || steps[j].type == Step.ELSE -> return -1
            else -> j
        }
        val mine = steps.subList(r.first, r.last + 1).toList()
        repeat(mine.size) { steps.removeAt(r.first) }
        steps.addAll(prevStart, mine)
        return prevStart
    }

    /** Moves the block down past its next sibling. Returns the new start index or -1. */
    fun moveDown(steps: MutableList<Step>, i: Int): Int {
        if (!movable(steps, i)) return -1
        val r = blockRange(steps, i)
        val n = r.last + 1
        if (n >= steps.size || steps[n].type == Step.END || steps[n].type == Step.ELSE) return -1
        val next = blockRange(steps, n)
        val mine = steps.subList(r.first, r.last + 1).toList()
        val nextLen = next.last - next.first + 1
        repeat(mine.size) { steps.removeAt(r.first) }
        val at = r.first + nextLen
        steps.addAll(at, mine)
        return at
    }

    fun delete(steps: MutableList<Step>, i: Int) {
        if (!movable(steps, i)) return
        val r = blockRange(steps, i)
        repeat(r.last - r.first + 1) { steps.removeAt(r.first) }
    }

    fun copy(steps: List<Step>, i: Int) {
        if (!movable(steps, i)) return
        val r = blockRange(steps, i)
        clip = steps.subList(r.first, r.last + 1).toList()
    }

    /** Where a new or pasted step goes when card [sel] is selected: inside an open block, else after it. */
    fun insertPoint(steps: List<Step>, sel: Int): Int {
        if (sel !in steps.indices) return steps.size
        val s = steps[sel]
        return if (opens(s) || s.type == Step.ELSE) sel + 1 else if (s.type == Step.END) sel + 1 else sel + 1
    }

    /** Nesting depth of every step, for indenting. */
    fun depths(steps: List<Step>): IntArray {
        val arr = IntArray(steps.size)
        var d = 0
        steps.forEachIndexed { i, s ->
            if (s.type == Step.END || s.type == Step.ELSE) d = (d - 1).coerceAtLeast(0)
            arr[i] = d
            if (opens(s) || s.type == Step.ELSE) d++
        }
        return arr
    }

    /** What to insert for a new step: if gets an else and an end, repeat gets an end. */
    fun withClosers(s: Step): List<Step> = when (s.type) {
        Step.IF -> listOf(s, Step(Step.ELSE), Step(Step.END))
        Step.REPEAT -> listOf(s, Step(Step.END))
        else -> listOf(s)
    }
}
