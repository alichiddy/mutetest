package com.newagedevs.gesturevolume.sides

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.service.OverlayRuntime

/**
 * Side bars: a thin strip on the left and/or right edge, each with up to three segments. A segment
 * can have actions on tap, double tap, long press and four swipes, or act as a volume or brightness
 * slider. Changes apply at once.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class SidesActivity : ComponentActivity() {
    private val appShortcutsCb = mutableStateOf<((String) -> Unit)?>(null)

    /** Opens the "App shortcuts" window; [onPicked] gets the chosen action. */
    fun showAppShortcuts(onPicked: (String) -> Unit) { appShortcutsCb.value = onPicked }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val shortcutsCb = appShortcutsCb.value
                if (shortcutsCb != null) {
                    androidx.compose.ui.window.Dialog(
                        onDismissRequest = { appShortcutsCb.value = null },
                        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
                    ) {
                        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
                            com.newagedevs.gesturevolume.ui.screens.strip.AppShortcutsPage(
                                onCreator = { cr ->
                                    appShortcutsCb.value = null
                                    SidePicker.launchCreator(this@SidesActivity, cr.packageName, cr.className, shortcutsCb)
                                },
                                onShortcut = { sc ->
                                    appShortcutsCb.value = null
                                    shortcutsCb(com.newagedevs.gesturevolume.ui.screens.strip.INTENT_ACTION_PREFIX + sc.intentUri)
                                },
                                onBack = { appShortcutsCb.value = null },
                            )
                        }
                    }
                }
                Surface(Modifier.fillMaxSize()) {
                    var cfg by remember { mutableStateOf(SideConfig.load(this@SidesActivity)) }
                    fun update(new: SideConfig) {
                        val keyboardChanged = new.hideForKeyboard != cfg.hideForKeyboard
                        cfg = new
                        SideConfig.save(this@SidesActivity, new)
                        OverlayRuntime.activeController?.let { if (keyboardChanged) it.refreshAutoHide() else it.refreshSides() }
                    }
                    Column(
                        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text("Side bars", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "A thin strip on each edge. Split it into up to 3 segments; each segment has its own actions, or works as a volume or brightness slider. Swipe in/out means toward/away from the screen's middle, so both sides mirror.",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Hide the side bars while the keyboard is open", Modifier.weight(1f))
                            Switch(checked = cfg.hideForKeyboard, onCheckedChange = { update(cfg.copy(hideForKeyboard = it)) })
                        }
                        Text(
                            "For phones using Back-swipe gestures: with the keyboard open the edge strips would fight the Back swipe. You can bind \"Back\" to Swipe in on a segment instead.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Keep the main slider's bar away while a side segment changes volume or brightness", Modifier.weight(1f))
                            Switch(checked = cfg.hideMainBar, onCheckedChange = { update(cfg.copy(hideMainBar = it)) })
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Let side sliders go on into the boost bar (up to +32 dB). Off = they stop at the maximum volume", Modifier.weight(1f))
                            Switch(checked = cfg.boostBar, onCheckedChange = { update(cfg.copy(boostBar = it)) })
                        }
                        HorizontalDivider()
                        SideEditor("Left side", "L", allSegs(cfg), cfg.left) { update(cfg.copy(left = it)) }
                        HorizontalDivider()
                        SideEditor("Right side", "R", allSegs(cfg), cfg.right) { update(cfg.copy(right = it)) }
                    }
                }
            }
        }
    }

    /** Every segment that is on, as (code, name), for "same place and height as another segment". */
    private fun allSegs(cfg: SideConfig): List<Pair<String, String>> = buildList {
        cfg.left.takeIf { it.on }?.segs?.forEachIndexed { i, g -> if (g.on) add("L${i + 1}" to "Left ${i + 1}") }
        cfg.right.takeIf { it.on }?.segs?.forEachIndexed { i, g -> if (g.on) add("R${i + 1}" to "Right ${i + 1}") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        SidePicker.onResult(requestCode, resultCode, data)
    }

    @Composable
    private fun SideEditor(title: String, letter: String, all: List<Pair<String, String>>, side: Side, onChange: (Side) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Switch(checked = side.on, onCheckedChange = { onChange(side.copy(on = it)) })
        }
        if (!side.on) return
        var sel by remember { mutableStateOf(0) }
        val selected = sel.coerceIn(0, side.segs.lastIndex)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Segment")
            for (n in 1..3) FilterChip(
                selected = selected == n - 1,
                onClick = {
                    // Pressing a number turns on that many segments (settings of the others are kept,
                    // just switched off) and brings that segment's settings to the top.
                    val segs = side.segs.toMutableList()
                    while (segs.size < n) segs += Seg(topPct = (20 + 25 * segs.size).coerceAtMost(75), heightPct = 20)
                    for (k in segs.indices) segs[k] = segs[k].copy(on = k < n)
                    sel = n - 1
                    onChange(side.copy(segs = segs))
                },
                label = { Text("$n") },
            )
        }
        // The chosen segment first, the others below it.
        val order = listOf(selected) + side.segs.indices.filter { it != selected }
        order.forEach { i ->
            SegEditor(i + 1, letter + (i + 1), all, side.segs[i]) { new -> onChange(side.copy(segs = side.segs.toMutableList().also { it[i] = new })) }
        }
    }

    @Composable
    private fun SegEditor(number: Int, selfCode: String, all: List<Pair<String, String>>, seg: Seg, onChange: (Seg) -> Unit) {
        Surface(tonalElevation = 2.dp, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Segment $number", Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text(if (seg.on) "On" else "Off", fontSize = 12.sp)
                    Switch(checked = seg.on, onCheckedChange = { onChange(seg.copy(on = it)) })
                }
                if (!seg.on) return@Column
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Look: exactly like the main slider (colour, fill, outline, corners, percentage, panel)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.copyLook, onCheckedChange = { onChange(seg.copy(copyLook = it)) })
                }
                if (!seg.copyLook) Text("Look off: a faint edge line that lights up when touched.", fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(seg.mode == Seg.MODE_ACTIONS, { onChange(seg.copy(mode = Seg.MODE_ACTIONS)) }, { Text("Actions") })
                    FilterChip(seg.mode == Seg.MODE_VOLUME, { onChange(seg.copy(mode = Seg.MODE_VOLUME)) }, { Text("Volume slider") })
                    FilterChip(seg.mode == Seg.MODE_BRIGHTNESS, { onChange(seg.copy(mode = Seg.MODE_BRIGHTNESS)) }, { Text("Brightness") })
                }
                // Place and height of another segment, live: a left and a right segment linked this way sit exactly alike.
                var pickLink by remember { mutableStateOf(false) }
                val options = all.filter { it.first != selfCode }
                if (options.isNotEmpty()) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Same position and height as:", Modifier.weight(0.5f), fontSize = 13.sp)
                    OutlinedButton(onClick = { pickLink = true }, modifier = Modifier.weight(0.5f)) {
                        Text(all.firstOrNull { it.first == seg.linkTo }?.second ?: "Own (not linked)", maxLines = 1, fontSize = 13.sp)
                    }
                }
                if (pickLink) androidx.compose.material3.AlertDialog(
                    onDismissRequest = { pickLink = false },
                    title = { Text("Same position and height as") },
                    text = {
                        Column {
                            TextButton(onClick = { pickLink = false; onChange(seg.copy(linkTo = "")) }) { Text("Own (not linked)") }
                            options.forEach { (code, name) ->
                                TextButton(onClick = { pickLink = false; onChange(seg.copy(linkTo = code)) }) { Text(name) }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = { TextButton(onClick = { pickLink = false }) { Text("Cancel") } },
                )
                if (seg.linkTo.isNotEmpty() && options.any { it.first == seg.linkTo }) {
                    Text("Position and height follow ${all.first { it.first == seg.linkTo }.second}; the sliders below apply when not linked.", fontSize = 12.sp)
                }
                // Place: each segment has its own, or follows the main slider live.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Position: follow the main slider's top (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.posMain, onCheckedChange = { onChange(seg.copy(posMain = it)) })
                }
                if (seg.posMain) {
                    Text("Moved ${seg.shiftPct}% of the screen (negative = up, positive = down)", fontSize = 12.sp)
                    Slider(value = seg.shiftPct.toFloat(), onValueChange = { onChange(seg.copy(shiftPct = it.toInt())) }, valueRange = -60f..60f)
                } else {
                    Text("Starts ${seg.topPct}% from the top", fontSize = 12.sp)
                    Slider(value = seg.topPct.toFloat(), onValueChange = { onChange(seg.copy(topPct = it.toInt())) }, valueRange = 0f..95f)
                }
                // Size: one switch for height and width, or one by one.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Size (height and width): same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.sizeAll, onCheckedChange = { onChange(seg.copy(sizeAll = it)) })
                }
                if (!seg.sizeAll) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Height: same as the main slider", Modifier.weight(1f), fontSize = 12.sp)
                        Switch(checked = seg.heightMain, onCheckedChange = { onChange(seg.copy(heightMain = it)) })
                    }
                    if (!seg.heightMain) {
                        Text("Height ${seg.heightPct}% of the screen", fontSize = 12.sp)
                        Slider(value = seg.heightPct.toFloat(), onValueChange = { onChange(seg.copy(heightPct = it.toInt())) }, valueRange = 5f..100f)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Width: same as the main slider", Modifier.weight(1f), fontSize = 12.sp)
                        Switch(checked = seg.copyWidth, onCheckedChange = { onChange(seg.copy(copyWidth = it)) })
                    }
                    if (!seg.copyWidth) {
                        Text("Width ${seg.widthDp} dp", fontSize = 12.sp)
                        Slider(value = seg.widthDp.toFloat(), onValueChange = { onChange(seg.copy(widthDp = it.toInt())) }, valueRange = 8f..40f)
                    }
                }
                // Feel: what the user got used to on the main slider is the same on every segment, unless switched off here.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Gesture feel (slide-in distance, touch area, straight up/down): same as the main slider (live)", Modifier.weight(1f), fontSize = 13.sp)
                    Switch(checked = seg.feelAll, onCheckedChange = { onChange(seg.copy(feelAll = it)) })
                }
                if (!seg.feelAll) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Slide-in distance: same as the main slider", Modifier.weight(1f), fontSize = 12.sp)
                        Switch(checked = seg.inMain, onCheckedChange = { onChange(seg.copy(inMain = it)) })
                    }
                    if (!seg.inMain) {
                        Text(if (seg.inDp == 0) "Slide-in distance: automatic" else "Slide-in distance ${seg.inDp} dp", fontSize = 12.sp)
                        Slider(value = seg.inDp.toFloat(), onValueChange = { onChange(seg.copy(inDp = it.toInt())) }, valueRange = 0f..40f)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Touch area: same rule as the main slider", Modifier.weight(1f), fontSize = 12.sp)
                        Switch(checked = seg.touchMain, onCheckedChange = { onChange(seg.copy(touchMain = it)) })
                    }
                    if (!seg.touchMain) {
                        Text(if (seg.touchDp == 0) "Touch area: exactly as drawn" else "Touch area at least ${seg.touchDp} dp", fontSize = 12.sp)
                        Slider(value = seg.touchDp.toFloat(), onValueChange = { onChange(seg.copy(touchDp = it.toInt())) }, valueRange = 0f..60f)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Straight up/down needed: same as the main slider", Modifier.weight(1f), fontSize = 12.sp)
                        Switch(checked = seg.vertMain, onCheckedChange = { onChange(seg.copy(vertMain = it)) })
                    }
                    if (!seg.vertMain) {
                        Text("Level slides only within ${seg.vertDeg}° of straight up/down; a more angled slide counts as a slide in", fontSize = 12.sp)
                        Slider(value = seg.vertDeg.toFloat(), onValueChange = { onChange(seg.copy(vertDeg = it.toInt().coerceIn(5, 45))) }, valueRange = 5f..45f)
                    }
                }
                var pickFrom by remember { mutableStateOf(false) }
                val fromOptions = all.filter { it.first != selfCode }
                val fromName = all.firstOrNull { it.first == seg.actFrom }?.second
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        onChange(seg.copy(actFrom = "", tap = Seg.MAIN, double = Seg.MAIN, long = Seg.MAIN, up = Seg.MAIN, down = Seg.MAIN, inward = Seg.MAIN, outward = Seg.MAIN))
                    }) { Text("All gestures: follow main", fontSize = 12.sp) }
                    OutlinedButton(onClick = {
                        val p = com.newagedevs.gesturevolume.data.local.SharedPref(this@SidesActivity)
                        onChange(seg.copy(
                            actFrom = "",
                            tap = p.getHandlerSingleTapAction(), double = p.getHandlerDoubleTapAction(), long = p.getHandlerLongTapAction(),
                            up = p.getHandlerSwipeUpAction(), down = p.getHandlerSwipeDownAction(),
                            inward = if (p.getStripEnabled()) Seg.STRIP else p.getHandlerSwipeInAction(), outward = p.getHandlerSwipeOutAction(),
                        ))
                    }) { Text("Copy all now", fontSize = 12.sp) }
                }
                if (fromOptions.isNotEmpty()) OutlinedButton(onClick = { pickFrom = true }) {
                    Text(if (fromName != null) "All gestures follow $fromName (live) - change" else "All gestures: copy from another segment (live)", fontSize = 12.sp)
                }
                if (pickFrom) androidx.compose.material3.AlertDialog(
                    onDismissRequest = { pickFrom = false },
                    title = { Text("Copy all gestures from") },
                    text = {
                        Column {
                            Text("Tap, double tap, long press and the swipes all follow that segment, live. Later changes there apply here too.", fontSize = 12.sp)
                            if (seg.actFrom.isNotEmpty()) TextButton(onClick = { pickFrom = false; onChange(seg.copy(actFrom = "")) }) { Text("Stop following (own gestures)") }
                            fromOptions.forEach { (code, name) ->
                                TextButton(onClick = { pickFrom = false; onChange(seg.copy(actFrom = code)) }) { Text(name) }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = { TextButton(onClick = { pickFrom = false }) { Text("Cancel") } },
                )
                if (fromName != null) {
                    Text("Every gesture of this segment follows $fromName, live. Choose \"Stop following\" to set them one by one again.", fontSize = 12.sp)
                    return@Column
                }
                Text("Or choose per gesture below: each one can follow the main slider (live), copy it once, or be its own.", fontSize = 12.sp)
                if (seg.mode != Seg.MODE_ACTIONS) Text("Swipe up and down on the strip to change the level like the main slider does. Tap and the swipes in/out below still work.", fontSize = 12.sp)
                ActionRow("tap", "Tap", seg.tap) { onChange(seg.copy(tap = it)) }
                ActionRow("double", "Double tap", seg.double) { onChange(seg.copy(double = it)) }
                ActionRow("long", "Long press", seg.long) { onChange(seg.copy(long = it)) }
                if (seg.mode == Seg.MODE_ACTIONS) {
                    ActionRow("up", "Swipe up", seg.up) { onChange(seg.copy(up = it)) }
                    ActionRow("down", "Swipe down", seg.down) { onChange(seg.copy(down = it)) }
                }
                ActionRow("in", "Swipe in", seg.inward) { onChange(seg.copy(inward = it)) }
                ActionRow("out", "Swipe out", seg.outward) { onChange(seg.copy(outward = it)) }
            }
        }
    }

    @Composable
    private fun ActionRow(slot: String, name: String, action: String, onPicked: (String) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(name, Modifier.weight(0.38f), fontSize = 13.sp)
            OutlinedButton(onClick = { SidePicker.pick(this@SidesActivity, slot, onPicked) }, modifier = Modifier.weight(0.62f)) {
                Text(SidePicker.label(this@SidesActivity, action), maxLines = 1, fontSize = 13.sp)
            }
            // The × slot is always there, so a "not set" button is as wide as the others.
            Box(Modifier.width(48.dp), contentAlignment = Alignment.Center) {
                if (action.isNotEmpty()) TextButton(onClick = { onPicked("") }) { Text("×") }
            }
        }
    }
}
