package com.newagedevs.gesturevolume.strip

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * Text (an emoji, a word, up to three lines) drawn as large as the box allows without being
 * stretched. Used for a cell that has no icon: what was typed becomes the picture.
 */
object FitText {
    /** The marker stored as a cell's icon when "None" was chosen: the name is the picture. */
    const val NONE = "none"

    fun lines(text: String): List<String> = text.split('\n').take(3)

    fun draw(canvas: Canvas, paint: Paint, text: String, box: RectF, color: Int) {
        val ls = lines(text).let { l -> if (l.all { it.isEmpty() }) emptyList() else l }
        if (ls.isEmpty()) return
        val w = box.width() * 0.92f
        val h = box.height() * 0.92f
        paint.color = color
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 100f
        val fm = paint.fontMetrics
        val lh100 = fm.descent - fm.ascent
        val w100 = ls.maxOf { paint.measureText(it) }.coerceAtLeast(1f)
        val size = minOf(w / w100, h / (ls.size * lh100)) * 100f
        paint.textSize = size
        val m = paint.fontMetrics
        val lh = m.descent - m.ascent
        val top = box.centerY() - lh * ls.size / 2f
        ls.forEachIndexed { i, line -> canvas.drawText(line, box.centerX(), top + i * lh - m.ascent, paint) }
    }
}
