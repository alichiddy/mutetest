package com.newagedevs.gesturevolume.utils

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Runs shell commands: through Shizuku (the shell's own privilege) when it is running and allowed,
 * and as the app's normal shell otherwise. Output is handed over line by line as it is produced.
 */
object ShizukuShell {
    private const val REQUEST_CODE = 4242

    fun isRunning(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun hasPermission(): Boolean =
        runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)

    /** True when commands will run with Shizuku's privilege right now. */
    fun isReady(): Boolean = isRunning() && hasPermission()

    /** Asks Shizuku for permission (its own dialog) and reports the answer. */
    fun requestPermission(onResult: (Boolean) -> Unit) {
        if (!isRunning()) { onResult(false); return }
        if (hasPermission()) { onResult(true); return }
        val listener = object : Shizuku.OnRequestPermissionResultListener {
            override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                Shizuku.removeRequestPermissionResultListener(this)
                onResult(grantResult == PackageManager.PERMISSION_GRANTED)
            }
        }
        Shizuku.addRequestPermissionResultListener(listener)
        runCatching { Shizuku.requestPermission(REQUEST_CODE) }.onFailure {
            Shizuku.removeRequestPermissionResultListener(listener)
            onResult(false)
        }
    }

    /** Starts a long-running command and returns at once; call destroy() on the result to stop it. */
    fun spawn(command: String, onLine: (String) -> Unit): Process? = runCatching {
        val process: Process = if (isReady()) {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, arrayOf("sh", "-c", "$command 2>&1"), null, null) as Process
        } else return@runCatching null
        Thread { runCatching { process.inputStream.bufferedReader().forEachLine(onLine) } }.start()
        process
    }.getOrNull()

    /** Blocking: call from a background thread. Returns the exit code. */
    fun run(command: String, onLine: (String) -> Unit): Int {
        val process: Process = if (isReady()) {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, arrayOf("sh", "-c", "$command 2>&1"), null, null) as Process
        } else {
            ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        }
        process.inputStream.bufferedReader().forEachLine(onLine)
        return process.waitFor()
    }

    /** A shell snippet that switches this app's accessibility service on (needs no extra quoting). */
    fun enableAccessibilityScript(pkg: String): String =
        "SVC=\$(cmd package query-services --brief --components -a android.accessibilityservice.AccessibilityService 2>/dev/null | grep \"^$pkg/\" | head -n 1); " +
        "if [ -n \"\$SVC\" ]; then OLD=\$(settings get secure enabled_accessibility_services); " +
        "CLEAN=\$(echo \"\$OLD\" | tr ':' '\\n' | grep -v \"^$pkg/\" | grep -v '^null\$' | grep -v '^\$' | paste -sd: -); " +
        "case \":\$OLD:\" in *\":\$SVC:\"*) ;; *) if [ -z \"\$CLEAN\" ]; then settings put secure enabled_accessibility_services \"\$SVC\"; else settings put secure enabled_accessibility_services \"\$CLEAN:\$SVC\"; fi ;; esac; " +
        "settings put secure accessibility_enabled 1; fi"

    /** Gives this app every permission it can use, the same on any phone. */
    fun grantAll(context: Context, onLine: (String) -> Unit): Int {
        val script = context.assets.open("grant.sh").bufferedReader().use { it.readText() }
            .replace("@PKG@", context.packageName)
        return run(script, onLine)
    }
}
