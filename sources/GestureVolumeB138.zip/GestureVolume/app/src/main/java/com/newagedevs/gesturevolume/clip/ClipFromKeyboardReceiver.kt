package com.newagedevs.gesturevolume.clip

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * The LeanType A keyboard tells A what was copied. Only apps signed with A's own key can send this
 * (a signature permission guards the receiver). Nothing runs until a copy happens.
 */
class ClipFromKeyboardReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        com.newagedevs.gesturevolume.utils.DiagLog.note("clip from keyboard len=${text.length} converted=${intent.getBooleanExtra("changed", false)}")
        ClipTools.announce(context.applicationContext, text)
    }
}
