package com.newagedevs.gesturevolume.clip

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Any app (Automate's "Broadcast send", Tasker) can put a line on A's bar:
 * action a.a.SHOW, package a.a, extras "message" (shown as is) or "text" (shown as "Copied: text",
 * digits converted when the Copy options say so or "convert" is true), optional "ms" = how long the bar stays. Nothing runs until it is sent.
 */
class ShowTextReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val conv = if (intent.hasExtra("convert")) intent.getBooleanExtra("convert", false) else null
        // "ms" is how long the bar stays; Automate may send it as a number of any kind or as text.
        val ms = (intent.extras?.get("ms") as? Number)?.toLong() ?: intent.getStringExtra("ms")?.toDoubleOrNull()?.toLong()
        ClipTools.showFor(context.applicationContext, intent.getStringExtra("message"), intent.getStringExtra("text"), conv, ms)
    }
}
