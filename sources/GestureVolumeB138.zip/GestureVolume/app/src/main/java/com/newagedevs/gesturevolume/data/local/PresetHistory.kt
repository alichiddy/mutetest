package com.newagedevs.gesturevolume.data.local

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * The bar's own settings as they were before a preset replaced them, so a hand-tuned bar can be
 * brought back. Kept at most [MAX_UNPINNED] unpinned states, newest first, plus any pinned ones.
 *
 * A state is saved only when the settings are not simply a preset as it was applied
 * ([markPreset] remembers the settings right after a preset was saved) and not already kept.
 */
object PresetHistory {
    private const val KEY = "presetHistoryV1"
    private const val SIG_KEY = "presetHistorySig"
    const val MAX_UNPINNED = 5

    class Entry(val time: Long, val pinned: Boolean, val values: JSONObject)

    private fun wanted(key: String): Boolean =
        (key.startsWith("handler") && key != "handlerHidden" && key != "handlerHiddenApps" && !key.startsWith("handlerPreMuteLevel_")) ||
            key.startsWith("slider") || key.startsWith("panel") || key.startsWith("menuSurface") || key.startsWith("quick")

    private fun snapshot(prefs: SharedPreferences): JSONObject {
        val o = JSONObject()
        for ((k, v) in prefs.all.toSortedMap()) {
            if (!wanted(k)) continue
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                is Set<*> -> e.put("t", "S").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    fun list(prefs: SharedPreferences): List<Entry> = runCatching {
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        (0 until arr.length()).map {
            val e = arr.getJSONObject(it)
            Entry(e.getLong("t"), e.optBoolean("p"), e.getJSONObject("v"))
        }
    }.getOrDefault(emptyList())

    private fun save(prefs: SharedPreferences, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.time).put("p", it.pinned).put("v", it.values)) }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    /** Saves the current settings unless they are an applied preset, or are already kept. */
    fun recordIfCustom(prefs: SharedPreferences) {
        val now = snapshot(prefs)
        val text = now.toString()
        if (text == prefs.getString(SIG_KEY, null)) return
        val list = list(prefs)
        if (list.any { it.values.toString() == text }) return
        val next = ArrayList<Entry>()
        next += Entry(System.currentTimeMillis(), false, now)
        next += list
        // Keep every pinned one and the newest few of the rest.
        var unpinned = 0
        save(prefs, next.filter { if (it.pinned) true else { unpinned++; unpinned <= MAX_UNPINNED } })
    }

    /** Remembers the settings as a preset left them, so they are not saved as custom ones. */
    fun markPreset(prefs: SharedPreferences) {
        prefs.edit().putString(SIG_KEY, snapshot(prefs).toString()).apply()
    }

    fun setPinned(prefs: SharedPreferences, time: Long, pinned: Boolean) =
        save(prefs, list(prefs).map { if (it.time == time) Entry(it.time, pinned, it.values) else it })

    fun delete(prefs: SharedPreferences, time: Long) = save(prefs, list(prefs).filter { it.time != time })

    /** Puts a kept state back (the current one is kept first, so this can be undone). */
    fun restore(prefs: SharedPreferences, entry: Entry) {
        recordIfCustom(prefs)
        val edit = prefs.edit()
        for (k in entry.values.keys()) {
            val e = entry.values.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> edit.putBoolean(k, e.getBoolean("v"))
                "i" -> edit.putInt(k, e.getInt("v"))
                "l" -> edit.putLong(k, e.getLong("v"))
                "f" -> edit.putFloat(k, e.getDouble("v").toFloat())
                "s" -> edit.putString(k, e.getString("v"))
                "S" -> edit.putStringSet(k, e.getJSONArray("v").let { a -> (0 until a.length()).map { a.getString(it) }.toSet() })
            }
        }
        edit.apply()
        markPreset(prefs)
    }
}
