package com.newagedevs.gesturevolume.ui.screens.shell

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.newagedevs.gesturevolume.ui.motion.IconButton
import java.text.DateFormat
import java.util.Date

private enum class SortBy(val label: String) { LAST_RAN("Last ran"), NAME("Name"), DATE("Date"), LENGTH("Length") }

/**
 * The shell runner's commands. Saved ones sit in a card of their own that folds (title you can edit,
 * the first line of the command, an eye that opens all of it for editing); the history of what was
 * run is under it. Sort, select, delete, rename, edit, add, copy, run.
 */
@Composable
fun ShellHistoryDialog(
    onDismiss: () -> Unit,
    onUse: (String) -> Unit,
    onRun: (String) -> Unit,
    onCopy: (String) -> Unit,
) {
    val context = LocalContext.current
    val entries = remember { mutableStateListOf<ShellHistory.Entry>().also { it.addAll(ShellHistory.load(context)) } }
    fun persist() = ShellHistory.save(context, entries.toList())
    fun update(e: ShellHistory.Entry, n: ShellHistory.Entry) { val i = entries.indexOfFirst { it.id == e.id }; if (i >= 0) { entries[i] = n; persist() } }
    fun remove(ids: Set<Long>) { entries.removeAll { it.id in ids }; persist() }

    var sort by remember { mutableStateOf(SortBy.LAST_RAN) }
    var reverse by remember { mutableStateOf(false) }
    var savedOpen by remember { mutableStateOf(true) }
    var historyOpen by remember { mutableStateOf(true) }
    var selecting by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<Long>() }
    val format = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    fun sorted(list: List<ShellHistory.Entry>): List<ShellHistory.Entry> {
        val s = when (sort) {
            SortBy.LAST_RAN -> list.sortedByDescending { it.lastRan }
            SortBy.NAME -> list.sortedBy { (it.title.ifBlank { it.cmd }).lowercase() }
            SortBy.DATE -> list.sortedByDescending { it.created }
            SortBy.LENGTH -> list.sortedByDescending { it.cmd.length }
        }
        return if (reverse) s.reversed() else s
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Shell history", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = {
                        val now = System.currentTimeMillis()
                        entries.add(ShellHistory.Entry(now, "New command", "", true, now, now, 0)); persist()
                        savedOpen = true
                    }, tooltip = "Add a saved command") { Icon(Icons.Filled.Add, contentDescription = null) }
                    IconButton(onClick = { selecting = !selecting; selected.clear() },
                        tooltip = if (selecting) "Stop selecting" else "Select several") {
                        Icon(if (selecting) Icons.Filled.Close else Icons.Filled.Check, contentDescription = null)
                    }
                    if (selecting) IconButton(onClick = { remove(selected.toSet()); selected.clear() }, tooltip = "Delete selected") {
                        Icon(Icons.Filled.Delete, contentDescription = null)
                    }
                    IconButton(onClick = onDismiss, tooltip = "Close") { Icon(Icons.Filled.Close, contentDescription = null) }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SortBy.values().forEach { s ->
                        FilterChip(selected = sort == s, onClick = { if (sort == s) reverse = !reverse else { sort = s; reverse = false } },
                            label = { Text(s.label + if (sort == s) (if (reverse) " ↑" else " ↓") else "") })
                    }
                }
                val saved = sorted(entries.filter { it.saved })
                val history = sorted(entries.filter { !it.saved })
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(8.dp)) {
                                Row(Modifier.fillMaxWidth().clickable { savedOpen = !savedOpen }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("Saved commands (${saved.size})", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                    Icon(if (savedOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
                                }
                            }
                        }
                    }
                    if (savedOpen) {
                        if (saved.isEmpty()) item { Text("Nothing saved yet. Tap the star on a command in the history, or add one.", fontSize = 13.sp) }
                        items(saved, key = { it.id }) { e ->
                            SavedRow(e, selecting, e.id in selected,
                                onToggle = { if (e.id in selected) selected.remove(e.id) else selected.add(e.id) },
                                onChange = { update(e, it) },
                                onDelete = { remove(setOf(e.id)) },
                                onRun = { onRun(e.cmd) }, onCopy = { onCopy(e.cmd) }, onUse = { onUse(e.cmd) })
                        }
                    }
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth().clickable { historyOpen = !historyOpen }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("History (${history.size})", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Icon(if (historyOpen) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null)
                            }
                        }
                    }
                    if (historyOpen) {
                        if (history.isEmpty()) item { Text("Commands you run appear here.", fontSize = 13.sp) }
                        items(history, key = { it.id }) { e ->
                            Row(Modifier.fillMaxWidth().clickable { if (selecting) { if (e.id in selected) selected.remove(e.id) else selected.add(e.id) } else onUse(e.cmd) }.padding(horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                if (selecting) Checkbox(checked = e.id in selected, onCheckedChange = { if (e.id in selected) selected.remove(e.id) else selected.add(e.id) })
                                Column(Modifier.weight(1f)) {
                                    Text(e.cmd.lineSequence().firstOrNull().orEmpty(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, maxLines = 1)
                                    Text(format.format(Date(e.lastRan)) + "  ·  ${e.runs}×", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { update(e, e.copy(saved = true, title = e.title.ifBlank { e.cmd.lineSequence().first().take(24) })) }, tooltip = "Save it") {
                                    Icon(Icons.Filled.StarBorder, contentDescription = null)
                                }
                                IconButton(onClick = { onRun(e.cmd) }, tooltip = "Run") { Icon(Icons.Filled.PlayArrow, contentDescription = null) }
                                IconButton(onClick = { onCopy(e.cmd) }, tooltip = "Copy") { Icon(Icons.Filled.ContentCopy, contentDescription = null) }
                                IconButton(onClick = { remove(setOf(e.id)) }, tooltip = "Delete") { Icon(Icons.Filled.Delete, contentDescription = null) }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(24.dp)) }
                }
            }
        }
    }
}

@Composable
private fun SavedRow(
    e: ShellHistory.Entry,
    selecting: Boolean,
    checked: Boolean,
    onToggle: () -> Unit,
    onChange: (ShellHistory.Entry) -> Unit,
    onDelete: () -> Unit,
    onRun: () -> Unit,
    onCopy: () -> Unit,
    onUse: () -> Unit,
) {
    var full by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selecting) Checkbox(checked = checked, onCheckedChange = { onToggle() })
                OutlinedTextField(
                    value = e.title, onValueChange = { onChange(e.copy(title = it)) }, singleLine = true,
                    label = { Text("Name") }, modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { full = !full }, tooltip = if (full) "Show the first line only" else "Show and edit the whole command") {
                    Icon(if (full) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = null)
                }
            }
            if (full) {
                OutlinedTextField(
                    value = e.cmd, onValueChange = { onChange(e.copy(cmd = it)) },
                    modifier = Modifier.fillMaxWidth(), label = { Text("Command") },
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                )
            } else {
                Text(e.cmd.lineSequence().firstOrNull().orEmpty(), fontFamily = FontFamily.Monospace, fontSize = 13.sp, maxLines = 1,
                    modifier = Modifier.fillMaxWidth().clickable { onUse() }.padding(4.dp))
            }
            Row {
                IconButton(onClick = onRun, tooltip = "Run") { Icon(Icons.Filled.PlayArrow, contentDescription = null) }
                IconButton(onClick = onCopy, tooltip = "Copy") { Icon(Icons.Filled.ContentCopy, contentDescription = null) }
                IconButton(onClick = { onChange(e.copy(saved = false)) }, tooltip = "Move back to the history") { Icon(Icons.Filled.Star, contentDescription = null) }
                IconButton(onClick = onDelete, tooltip = "Delete") { Icon(Icons.Filled.Delete, contentDescription = null) }
            }
        }
    }
}
