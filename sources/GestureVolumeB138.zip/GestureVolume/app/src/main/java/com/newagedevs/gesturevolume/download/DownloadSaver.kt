package com.newagedevs.gesturevolume.download

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.io.File

/** Writes a finished file into the Download folder. Shared by the share targets and the download manager. */
object DownloadSaver {
    class Saved(val name: String, val uri: Uri?)

    /** Removes older files of this name from Download. True when none is left that we could see. */
    fun removeExisting(context: Context, name: String): Boolean {
        var gone = true
        val cr = context.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val found = ArrayList<Uri>()
            runCatching {
                cr.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
                    arrayOf(name, Environment.DIRECTORY_DOWNLOADS + "/%"), null,
                )?.use { while (it.moveToNext()) found += ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, it.getLong(0)) }
            }
            for (u in found) {
                try { if (cr.delete(u, null, null) == 0) gone = false } catch (_: SecurityException) { gone = false }
            }
        }
        // A file the system will not let us delete by its entry (another app's) can still go with
        // "all files access", which A can be given.
        @Suppress("DEPRECATION")
        val f = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name)
        if (f.exists()) {
            if (f.delete()) {
                MediaScannerConnection.scanFile(context, arrayOf(f.path), null, null)
                Thread.sleep(300)
                gone = true
            } else gone = false
        }
        return gone
    }

    /** Writes the stream into Download and returns the name it ended up with. */
    fun write(context: Context, input: java.io.InputStream, name: String, mime: String, replace: Boolean): Saved {
        val cr = context.contentResolver
        input.use { src ->
            if (replace) removeExisting(context, name)
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val out = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("the phone refused to create the file")
                (cr.openOutputStream(out) ?: throw IllegalStateException("cannot open the new file")).use { dst ->
                    src.copyTo(dst)
                }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                cr.update(out, done, null, null)
                var finalName = name
                cr.query(out, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) finalName = it.getString(0) ?: name
                }
                return Saved(finalName, out)
            }
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val target = File(dir, name)
            target.outputStream().use { src.copyTo(it) }
            return Saved(target.name, null)
        }
    }

    /** Dual-profile spaces: copies saved files to the main profile's Download folder (needs Shizuku). Returns how many. */
    fun copyToMainProfile(names: List<String>): Int {
        val user = Process.myUserHandle().hashCode()
        if (user == 0 || !ShizukuShell.isReady()) return 0
        return names.count { name ->
            ShizukuShell.run("cp -f '/data/media/$user/Download/$name' /data/media/0/Download/") { } == 0
        }
    }

    /** A usable MIME type: the server's when it is specific, otherwise a guess from the file name. */
    fun mimeFor(name: String, header: String?): String {
        val h = header?.substringBefore(';')?.trim()?.lowercase()
        if (!h.isNullOrEmpty() && h != "application/octet-stream" && h != "binary/octet-stream") return h
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return "application/vnd.android.package-archive"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}
