package com.newagedevs.gesturevolume.strip

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Optional: a copy of every setting and script saved to Download/settings after a change, the last
 * five kept. Nothing runs unless the option is on; then one preference listener waits for changes
 * and a file is written a few seconds after the last one.
 */
object AutoBackup {
    const val ON = "autoBackupOn"
    private const val LAST_HASH = "autoBackupHash"
    private const val LAST_TIME = "autoBackupTime"
    private const val PREFS = "MyPrefs"
    private const val FOLDER = "A Settings"
    private val OLD_FOLDERS = listOf(" settings", "settings")
    private const val PREFIX = "A settings "
    private const val KEEP = 5
    private const val BURST_MS = 10 * 60 * 1000L

    class Entry(val name: String, val file: File?, val uri: Uri?, val modified: Long)

    private val main = Handler(Looper.getMainLooper())
    private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private var appContext: Context? = null
    private val job = Runnable { appContext?.let { Thread { save(it) }.start() } }

    fun enabled(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ON, false)

    /** Call at app start and whenever the option changes. */
    fun refresh(c: Context) {
        val ctx = c.applicationContext
        appContext = ctx
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        listener?.let { prefs.unregisterOnSharedPreferenceChangeListener(it) }
        listener = null
        main.removeCallbacks(job)
        if (!prefs.getBoolean(ON, false)) return
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key != null && !volatile(key)) { main.removeCallbacks(job); main.postDelayed(job, 8000L) }
        }
        listener = l
        prefs.registerOnSharedPreferenceChangeListener(l)
    }

    /** Keys that change on their own (counters, timestamps) and say nothing about the user's settings. */
    private fun volatile(key: String): Boolean {
        val k = key.lowercase()
        return key == LAST_HASH || key == LAST_TIME || k.startsWith("autobackup") || k.contains("count") || k.contains("today") ||
            k.contains("lastappopen") || k.contains("lastseen") || k == "isrunning" || k.contains("timestamp") || k.startsWith("ghlast")
    }

    private fun canUseFiles() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
    private fun dir() = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)
    private fun oldDirs() = OLD_FOLDERS.map { File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), it) }

    @Synchronized
    fun save(c: Context): String? = runCatching {
        val prefs = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val body = SettingsBackup.toJson(prefs, settings = true, scripts = true)
        // The hash leaves the volatile keys out, so a counter ticking over does not make a new file.
        val stable = org.json.JSONObject(body).getJSONObject("prefs").let { p ->
            p.keys().asSequence().filter { !volatile(it) }.sorted().joinToString("|") { it + "=" + p.getJSONObject(it) }
        }.hashCode().toString()
        if (prefs.getString(LAST_HASH, null) == stable) return@runCatching null
        val now = System.currentTimeMillis()
        val existing = list(c)
        // Changes close together share one file, so five files are five different moments.
        if (existing.isNotEmpty() && now - prefs.getLong(LAST_TIME, 0L) < BURST_MS) delete(c, existing.first())
        val name = PREFIX + SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.US).format(Date(now)) + ".json"
        write(c, name, body)
        list(c).drop(KEEP).forEach { delete(c, it) }
        prefs.edit().putString(LAST_HASH, stable).putLong(LAST_TIME, now).apply()
        name
    }.getOrElse { com.newagedevs.gesturevolume.utils.DiagLog.e("auto backup", it); null }

    private fun write(c: Context, name: String, body: String) {
        if (canUseFiles()) {
            val d = dir(); d.mkdirs()
            File(d, name).writeText(body)
        } else {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/json")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
            }
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("cannot create the file")
            c.contentResolver.openOutputStream(uri)!!.use { it.write(body.toByteArray()) }
        }
    }

    /** The saved files, newest first. */
    fun list(c: Context): List<Entry> {
        val out = ArrayList<Entry>()
        if (canUseFiles()) {
            for (d in listOf(dir()) + oldDirs()) {
                d.listFiles { f -> f.isFile && f.name.startsWith(PREFIX) && f.name.endsWith(".json") }
                    ?.forEach { if (out.none { x -> x.name == it.name }) out += Entry(it.name, it, null, it.lastModified()) }
            }
        }
        if (Build.VERSION.SDK_INT >= 29) runCatching {
            c.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.DATE_MODIFIED),
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
                arrayOf("${Environment.DIRECTORY_DOWNLOADS}/%settings%", "$PREFIX%"), null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(1)
                    if (out.any { it.name == name }) continue
                    out += Entry(name, null, ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cur.getLong(0)), cur.getLong(2) * 1000L)
                }
            }
        }
        return out.sortedByDescending { it.name }
    }

    fun read(c: Context, e: Entry): String? = runCatching {
        e.file?.readText() ?: c.contentResolver.openInputStream(e.uri!!)!!.use { it.readBytes().toString(Charsets.UTF_8) }
    }.getOrNull()

    private fun delete(c: Context, e: Entry) {
        runCatching { e.file?.delete() ?: c.contentResolver.delete(e.uri!!, null, null) }
    }
}
