package com.newagedevs.gesturevolume.flow

import android.content.Context
import com.newagedevs.gesturevolume.strip.SettingsBackup
import com.newagedevs.gesturevolume.strip.StripConfig

/**
 * A's own versions of the Automate flows the strip's cells used to start. Each one is an ordinary
 * flow, so every step can be edited in the Flows screen. Nothing personal is in here: keys, codes
 * and accounts are {names} that the user fills in under "My values".
 */
object SeedFlows {
    private fun act(id: String, arg: String = "", optional: Boolean = false) =
        Step(Step.ACTION, id, arg, if (optional) "optional" else "")
    private fun sh(cmd: String, optional: Boolean = true) = Step(Step.SHIZUKU, cmd, "", if (optional) "optional" else "")
    private fun bcast(target: String, action: String, extras: String = "") = Step(Step.BROADCAST, target, action, extras)
    private fun intent(uri: String) = Step(Step.INTENT, uri)
    private fun msg(text: String) = Step(Step.MESSAGE, text)
    private fun note(text: String) = Step(Step.NOTE, text)
    private fun pause(ms: Int) = Step(Step.WAIT, ms.toString())

    private const val V2RAY_WIDGET = "com.v2ray.ang/.receiver.WidgetProvider"
    private const val V2RAY_CLICK = "com.v2ray.ang.action.widget.click"
    private const val HSS_IGNORE = "appops set hotspotshield.android.vpn ACTIVATE_VPN ignore"

    private const val NEEDS_NEXT = "Needs the next update (map / sign-in screen)."

    /** Flow name -> steps. */
    val flows: Map<String, List<Step>> = linkedMapOf(
        "QShr" to listOf(act("location_on"), act("bt_on"), act("wifi_on")),
        "GRNT" to listOf(act("grant_app")),
        "RVOK" to listOf(act("revoke_app")),
        "EsySL" to listOf(Step(Step.SHIZUKU, "bmgr backupnow com.hasmetd.easyslider", "out", ""), msg("{out}")),
        "Bhsti" to listOf(msg("Fake location: $NEEDS_NEXT")),
        "DbgOff" to listOf(act("debug_off")),
        "HdDev" to listOf(act("dev_hide")),
        "ShwDV" to listOf(act("dev_show")),
        "2GOnly" to listOf(act("netmode", "2g"), sh("svc data disable")),
        "2G/3G" to listOf(act("netmode", "2g3g")),
        "4GOnly" to listOf(act("netmode", "4g")),
        "5GOnly" to listOf(act("netmode", "5g")),
        "1.0" to listOf(act("anim_toggle")),
        "123" to listOf(act("seconds_toggle")),
        "CHKDT" to listOf(act("net_info"), Step(Step.MESSAGE, "{out}")),
        "TMP" to listOf(intent("intent:#Intent;action=android.intent.action.SEND;type=text/plain;package=com.whatsapp;S.android.intent.extra.TEXT=test;end")),
        "WShr" to listOf(
            intent("intent:#Intent;action=com.aistra.hail.action.LAUNCH;component=com.aistra.hail/.ui.api.ApiActivity;S.package=com.luckydeveloper.apkshare;end"),
            pause(900),
            intent("intent:#Intent;action=com.luckydeveloper.shareit.action.TEXT_SHARE;component=com.luckydeveloper.apkshare/com.luckydeveloper.shareit.ui.activities.MainActivity;end"),
            note("Automate also tapped the send button here with an accessibility tap. Add that later; for now tap it yourself."),
        ),
        "V2Ray" to listOf(sh(HSS_IGNORE), bcast(V2RAY_WIDGET, V2RAY_CLICK)),
        "WFV2R" to listOf(act("wifi_on"), sh(HSS_IGNORE), bcast(V2RAY_WIDGET, V2RAY_CLICK)),
        "V2Win" to listOf(sh(HSS_IGNORE), bcast(V2RAY_WIDGET, V2RAY_CLICK), act("wifi_on"), sh("svc data disable")),
        "V2+DT" to listOf(sh(HSS_IGNORE), bcast(V2RAY_WIDGET, V2RAY_CLICK), sh("svc data enable"), act("wifi_off")),
        "WifiOn" to listOf(act("wifi_on"), sh("svc data disable"), act("hotspot_off", "", true)),
        "Hotsp" to listOf(act("hotspot_toggle")),
        "4G+HS" to listOf(
            act("netmode", "4g"), sh("svc data enable"), sh("svc wifi disable"), act("hotspot_toggle"),
            note("Check this one: Automate switched SIM 2 to 4G here and decided by the current network type."),
        ),
        "Loc" to listOf(act("location_toggle")),
        "BT" to listOf(act("bt_toggle")),
        "Airpl" to listOf(act("airplane_toggle")),
        "Torch" to listOf(act("torch_toggle")),
        "MaxVol" to listOf(act("volume_max", "music")),
        "Wifi" to listOf(act("wifi_toggle")),
        "WiTgl" to listOf(act("wifi_toggle")),
        "4GS2" to listOf(act("netmode", "all"), sh("svc data enable"), sh("svc wifi disable")),
        "DSave" to listOf(act("datasaver_toggle")),
        "Awake" to listOf(act("keep_awake_toggle")),
        "Brgt" to listOf(act("brightness_toggle", "3056")),
        "TRMNL" to listOf(act("A:Shell runner")),
        "LOGKL" to listOf(act("logcat_kill")),
        "ALOF" to listOf(
            act("location_off"), act("bt_off"), act("wifi_off"),
            sh("svc data disable"), act("hotspot_off", "", true), act("vpn_stop_all", "", true),
        ),
        "BgShl" to listOf(act("bgshell", "upload")),
        "BGSh2" to listOf(act("bgshell", "upload")),
        "BGSh3" to listOf(act("bgshell", "plain")),
        "BGRsh" to listOf(act("bgshell", "upload")),
        "PGDWN" to listOf(act("page_down")),
        "FPKG" to listOf(act("copy_fg_pkg"), msg("{app}")),
        "RSLT" to listOf(
            note("Edit this flow: put the app you want to open in a floating window here (Flappsfull's launcher or any other)."),
            intent("intent:#Intent;component=com.lwi.android.flappsfull/com.lwi.android.flapps.activities.QLFALaunch;end"),
        ),
        "Power" to listOf(act("A:Power menu")),
        "ScrSh" to listOf(act("A:Screenshot")),
        "UPLD" to listOf(act("upload_pick")),
        "GUPLD" to listOf(msg("Drive upload: $NEEDS_NEXT")),
        "FHide" to listOf(act("hail_freeze_fg")),
        "FIUsr" to listOf(act("install_existing", "999")),
        "AppInf" to listOf(act("app_info")),
        "Speed" to listOf(act("speed_toggle")),
        "PSTE" to listOf(act("paste")),
        "HSSt" to listOf(act("hss_tile")),
        "LNS" to listOf(act("lens_ocr")),
        "Dua" to listOf(
            intent("intent://com.android.externalstorage.documents/document/primary%3AMusic%2F%D8%AF%D8%B9%D8%A7%DB%8C%20%D8%B5%D9%86%D9%85%DB%8C%20%D9%82%D8%B1%DB%8C%D8%B4%20%D8%A8%D8%A7%20%DA%A9%DB%8C%D9%81%DB%8C%D8%AA.mp3#Intent;scheme=content;action=android.intent.action.VIEW;package=com.mxtech.videoplayer.pro;type=audio/mpeg;end"),
        ),
        "QR" to listOf(msg("QR generator: $NEEDS_NEXT")),
        "WGT" to listOf(
            bcast("com.zaneschepke.wireguardautotunnel", "com.zaneschepke.wireguardautotunnel.TOGGLE_TUNNEL", "tunnelName={wg_tunnel};key={wg_key}"),
        ),
        "KBRG1" to listOf(act("clip_set", "{kb_id1}"), act("ussd", "{kb_ussd}"), note("The code is on the clipboard: paste it into the USSD window.")),
        "KBRG2" to listOf(act("clip_set", "{kb_id2}"), act("ussd", "{kb_ussd}"), note("The code is on the clipboard: paste it into the USSD window.")),
    )

    /** "flow/statement" of the old Automate cell -> flow name here. */
    private val byAutomate: Map<String, String> = mapOf(
        "468/233" to "QShr", "468/592" to "GRNT", "468/600" to "RVOK", "468/479" to "EsySL", "491/63" to "Bhsti",
        "468/165" to "DbgOff", "468/170" to "HdDev", "468/172" to "ShwDV", "468/495" to "2GOnly", "468/49" to "2GOnly",
        "468/145" to "2G/3G", "468/349" to "4GOnly", "468/339" to "5GOnly", "468/384" to "1.0", "468/372" to "123",
        "468/390" to "CHKDT", "609/1" to "TMP", "468/369" to "WShr", "468/36" to "WShr", "468/266" to "V2Ray",
        "468/489" to "WFV2R", "468/248" to "V2Win", "468/321" to "V2+DT", "468/520" to "WifiOn", "468/137" to "Hotsp",
        "468/43" to "4G+HS", "468/229" to "Loc", "468/64" to "BT", "468/151" to "Airpl", "2/1" to "Torch",
        "292/1" to "MaxVol", "483/5" to "Wifi", "468/5" to "WiTgl", "468/12" to "4GS2", "468/141" to "DSave",
        "468/14" to "DSave", "484/85" to "Awake", "468/214" to "Brgt", "587/1" to "TRMNL", "468/488" to "LOGKL",
        "468/236" to "ALOF", "468/362" to "BgShl", "468/740" to "BGSh2", "468/781" to "BGSh3", "468/727" to "BGRsh",
        "468/402" to "PGDWN", "468/609" to "FPKG", "483/16" to "RSLT", "468/615" to "Power", "468/61" to "Power",
        "468/680" to "ScrSh", "621/1" to "UPLD", "621/27" to "GUPLD", "468/682" to "FHide", "468/633" to "FIUsr",
        "468/687" to "AppInf", "468/685" to "Speed", "468/467" to "PSTE", "468/835" to "HSSt", "468/804" to "LNS",
        "292/14" to "Dua", "468/838" to "QR", "468/842" to "WGT", "468/84" to "WGT", "486/2" to "KBRG1", "486/18" to "KBRG2",
    )

    /** Old Automate cells that only existed to run Automate itself. They become empty cells. */
    private val dropped = setOf("138/78", "138/71", "335/53")

    /** Writes every built-in flow that does not exist yet (or all of them with [overwrite]). Returns how many. */
    fun installFlows(context: Context, overwrite: Boolean = false): Int {
        val have = FlowStore.names(context).toSet()
        var n = 0
        for ((name, steps) in flows) {
            if (overwrite || name !in have) { FlowStore.save(context, name, steps); n++ }
        }
        return n
    }

    private val uriRegex = Regex("""flows/(\d+)/statements/(\d+)""")

    /** Points each old Automate cell of the strip at the matching flow here. Returns (changed, left alone). */
    fun convertCells(context: Context): Pair<Int, Int> {
        val prefs = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val cfg = StripConfig.load(context, prefs.getString(SettingsBackup.STRIP_KEY, null))
        var changed = 0
        var other = 0
        val items = cfg.items.map { item ->
            val a = item.action
            val m = if (a.startsWith("Flow:")) Regex("""^Flow:(\d+)/(\d+)""").find(a) else if (a.startsWith("Intent:")) uriRegex.find(a) else null
            if (m == null) { other++; item } else {
                val key = m.groupValues[1] + "/" + m.groupValues[2]
                val name = byAutomate[key]
                when {
                    name != null -> { changed++; item.copy(action = "MyFlow:$name") }
                    key in dropped -> { changed++; item.copy(action = "") }
                    else -> { other++; item }
                }
            }
        }
        prefs.edit().putString(SettingsBackup.STRIP_KEY, cfg.copy(items = items).toJson()).apply()
        return changed to other
    }
}
