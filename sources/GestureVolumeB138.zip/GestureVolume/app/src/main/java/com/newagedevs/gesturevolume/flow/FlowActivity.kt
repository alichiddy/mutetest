package com.newagedevs.gesturevolume.flow

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** The flow list and the step editor. Nothing from here stays in memory once it is closed. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class FlowActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var names by remember { mutableStateOf(FlowStore.names(this)) }
                    var open by remember { mutableStateOf<String?>(null) }
                    var newName by remember { mutableStateOf(false) }
                    var info by remember { mutableStateOf("") }
                    var values by remember { mutableStateOf(false) }
                    var autos by remember { mutableStateOf(false) }
                    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
                        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
                    ) { uri ->
                        if (uri != null) {
                            info = "Importing…"
                            Thread {
                                info = try {
                                    val n = AutomateImporter.import(this@FlowActivity, uri)
                                    names = FlowStore.names(this@FlowActivity)
                                    "Imported $n flows. Texts that are not commands are kept as Notes."
                                } catch (e: Throwable) { "Import failed: ${e.message}" }
                            }.start()
                        }
                    }
                    if (autos) {
                        com.newagedevs.gesturevolume.auto.AutomationsScreen { autos = false }
                    } else if (values) {
                        ValuesScreen { values = false }
                    } else if (open == null) {
                        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Flows (${names.size})", fontSize = 20.sp)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { newName = true }) { Text("New flow") }
                                OutlinedButton(onClick = {
                                    val added = SeedFlows.installFlows(this@FlowActivity)
                                    val (changed, other) = SeedFlows.convertCells(this@FlowActivity)
                                    names = FlowStore.names(this@FlowActivity)
                                    info = "Added $added built-in flows. $changed old Automate cells now run them; $other cells were left as they were. Turn A off and on to refresh the strip."
                                }) { Text("Install my cells and flows") }
                                OutlinedButton(onClick = {
                                    val next = (FlowPrefs.mode(this@FlowActivity) + 1) % 3
                                    FlowPrefs.setMode(this@FlowActivity, next)
                                    info = "Message bar after a cell: " + FlowPrefs.modeName(next)
                                }) { Text("Message bar: " + FlowPrefs.modeName(FlowPrefs.mode(this@FlowActivity))) }
                                OutlinedButton(onClick = {
                                    info = "Adding…"
                                    Thread {
                                        info = try {
                                            val n = AutomateFlows.install(this@FlowActivity)
                                            names = FlowStore.names(this@FlowActivity)
                                            "Added $n converted Automate flows (named Automate: …). Numbers and codes are blanks: fill them under My values."
                                        } catch (e: Throwable) { "Could not add: ${e.message}" }
                                    }.start()
                                }) { Text("Add my Automate flows") }
                                OutlinedButton(onClick = { values = true }) { Text("My values (keys, codes)") }
                                OutlinedButton(onClick = { autos = true }) { Text("Automations") }
                                OutlinedButton(onClick = {
                                    runCatching { startActivity(android.content.Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
                                }) { Text("Allow usage access") }
                                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import Automate backup") }
                            }
                            if (info.isNotEmpty()) Text(info, fontSize = 12.sp)
                            var query by remember { mutableStateOf("") }
                            var showParts by remember { mutableStateOf(false) }
                            OutlinedTextField(query, { query = it }, singleLine = true, label = { Text("Search flows") }, modifier = Modifier.fillMaxWidth())
                            OutlinedButton(onClick = { showParts = !showParts }) { Text(if (showParts) "Hiding nothing" else "Parts of flows are hidden - show") }
                            val shown = names.filter { (showParts || !AutomateFlows.isPart(it)) && (query.isBlank() || it.contains(query, true)) }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemsIndexed(shown) { _, n ->
                                    Text(n, Modifier.fillMaxWidth().clickable { open = n }.padding(vertical = 10.dp))
                                }
                            }
                        }
                        if (newName) {
                            var t by remember { mutableStateOf("") }
                            AlertDialog(
                                onDismissRequest = { newName = false },
                                title = { Text("Flow name") },
                                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                                confirmButton = { TextButton(onClick = {
                                    if (t.isNotBlank()) { FlowStore.save(this, t.trim(), emptyList()); names = FlowStore.names(this); open = t.trim() }
                                    newName = false
                                }) { Text("OK") } },
                            )
                        }
                    } else {
                        Editor(open!!) { names = FlowStore.names(this); open = null }
                    }
                }
            }
        }
    }

    @Composable
    private fun Editor(name: String, close: () -> Unit) {
        val steps = remember { mutableStateListOf<Step>().also { it.addAll(FlowStore.load(this, name)) } }
        var edit by remember { mutableStateOf<Int?>(null) }   // index being edited, steps.size = new
        var insertAt by remember { mutableStateOf(0) }
        var sel by remember { mutableStateOf(-1) }
        var dragIdx by remember { mutableStateOf(-1) }
        var draft by remember { mutableStateOf(Step(Step.SHELL)) }
        var output by remember { mutableStateOf("") }
        var running by remember { mutableStateOf(false) }
        val undo = remember { ArrayList<List<Step>>() }
        var undoCount by remember { mutableStateOf(0) }
        var clipCount by remember { mutableStateOf(FlowOps.clip.size) }
        fun save() = FlowStore.save(this, name, steps.toList())
        fun snap() { undo.add(steps.toList()); if (undo.size > 50) undo.removeAt(0); undoCount = undo.size }
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name, fontSize = 20.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { draft = Step(Step.SHELL); insertAt = FlowOps.insertPoint(steps, sel); edit = steps.size }) { Text("Add step") }
                Button(enabled = !running, onClick = {
                    save(); running = true; output = ""
                    Thread {
                        FlowRunner.run(this@FlowActivity, name, { l -> output += l + "\n" }, { })
                        running = false
                    }.start()
                }) { Text("Run") }
                OutlinedButton(onClick = { FlowRunner.stop() }) { Text("Stop") }
                OutlinedButton(enabled = undoCount > 0, onClick = {
                    if (undo.isNotEmpty()) {
                        val prev = undo.removeAt(undo.size - 1)
                        steps.clear(); steps.addAll(prev); undoCount = undo.size; sel = -1; save()
                    }
                }) { Text("Undo") }
                OutlinedButton(enabled = clipCount > 0, onClick = {
                    snap()
                    val at = FlowOps.insertPoint(steps, sel).coerceAtMost(steps.size)
                    steps.addAll(at, FlowOps.clip); sel = at; save()
                }) { Text("Paste") }
                OutlinedButton(onClick = { save(); close() }) { Text("Save & close") }
                OutlinedButton(onClick = { FlowStore.delete(this@FlowActivity, name); close() }) { Text("Delete flow") }
            }
            val indent = FlowOps.depths(steps)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(steps) { i, s ->
                    val pad = indent.getOrElse(i) { 0 }
                    val isSel = i == sel
                    val tint = when (s.type) {
                        Step.IF -> androidx.compose.ui.graphics.Color(0x3343A047)
                        Step.ELSE -> androidx.compose.ui.graphics.Color(0x33E53935)
                        Step.REPEAT -> androidx.compose.ui.graphics.Color(0x331E88E5)
                        Step.END -> androidx.compose.ui.graphics.Color.Transparent
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    val title = when (s.type) {
                        Step.IF -> "If ${s.a} ${s.b} ${s.c}   (yes:)"
                        Step.ELSE -> "otherwise (no:)"
                        Step.END -> "end"
                        else -> s.describe()
                    }
                    Surface(
                        Modifier.fillMaxWidth().padding(start = (pad * 18).dp)
                            .clickable { sel = if (isSel) -1 else i },
                        color = tint,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(if (s.type == Step.END) 2.dp else 10.dp),
                        border = if (isSel || dragIdx == i) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                    ) {
                        Column(Modifier.padding(horizontal = 8.dp, vertical = if (s.type == Step.END) 0.dp else 6.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                if (FlowOps.movable(steps, i)) {
                                    Text(
                                        "\u2261", fontSize = 24.sp,
                                        modifier = Modifier.padding(end = 10.dp).pointerInput(Unit) {
                                            var acc = 0f
                                            detectDragGestures(
                                                onDragStart = { dragIdx = i; acc = 0f; snap() },
                                                onDragEnd = { dragIdx = -1; sel = -1; save() },
                                                onDragCancel = { dragIdx = -1; save() },
                                            ) { change, drag ->
                                                change.consume()
                                                acc += drag.y
                                                val step = 70.dp.toPx()
                                                if (acc > step) { val n = FlowOps.moveDown(steps, dragIdx); if (n >= 0) dragIdx = n; acc = 0f }
                                                else if (acc < -step) { val n = FlowOps.moveUp(steps, dragIdx); if (n >= 0) dragIdx = n; acc = 0f }
                                            }
                                        },
                                    )
                                }
                                Text(
                                    if (s.type == Step.END) title else "${i + 1}. $title",
                                    fontFamily = FontFamily.Monospace, fontSize = if (s.type == Step.END) 10.sp else 13.sp,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (isSel && s.type != Step.END) {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    TextButton(onClick = { draft = s; edit = i }) { Text("Edit") }
                                    TextButton(onClick = { draft = Step(Step.SHELL); insertAt = FlowOps.insertPoint(steps, i); edit = steps.size }) { Text("Add inside/after") }
                                    if (FlowOps.movable(steps, i)) {
                                        TextButton(onClick = { FlowOps.copy(steps, i); clipCount = FlowOps.clip.size }) { Text("Copy") }
                                        TextButton(onClick = { snap(); val n = FlowOps.moveUp(steps, i); if (n >= 0) sel = n else undo.removeAt(undo.size - 1); undoCount = undo.size; save() }) { Text("Up") }
                                        TextButton(onClick = { snap(); val n = FlowOps.moveDown(steps, i); if (n >= 0) sel = n else undo.removeAt(undo.size - 1); undoCount = undo.size; save() }) { Text("Down") }
                                        TextButton(onClick = { snap(); FlowOps.delete(steps, i); sel = -1; save() }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            val missing = PrivateValues.missing(this@FlowActivity, steps.toList())
            if (missing.isNotEmpty()) Text("Fill in under My values: " + missing.joinToString(", "), fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
            if (output.isNotEmpty()) Text(output.takeLast(1500), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        val idx = edit
        if (idx != null) {
            var type by remember(idx) { mutableStateOf(draft.type) }
            var a by remember(idx) { mutableStateOf(draft.a) }
            var b by remember(idx) { mutableStateOf(draft.b) }
            var c by remember(idx) { mutableStateOf(draft.c) }
            var choosing by remember(idx) { mutableStateOf(false) }
            if (choosing) {
                AlertDialog(
                    onDismissRequest = { choosing = false },
                    title = { Text("Choose what to do") },
                    text = {
                        LazyColumn {
                            itemsIndexed(NativeActions.all) { _, d ->
                                val tag = when (d.need) {
                                    NativeActions.Need.NONE -> ""
                                    NativeActions.Need.ONCE -> "  (one-time grant)"
                                    NativeActions.Need.BETTER -> "  (better with Shizuku)"
                                    NativeActions.Need.SHIZUKU -> "  (needs Shizuku)"
                                }
                                Text(d.label + tag, Modifier.fillMaxWidth().clickable { a = d.id; choosing = false }.padding(vertical = 8.dp), fontSize = 14.sp)
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { choosing = false }) { Text("Close") } },
                )
            }
            AlertDialog(
                onDismissRequest = { edit = null },
                title = { Text(if (idx < steps.size) "Edit step" else "New step") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Step.TYPES.forEach { t ->
                                if (t == type) Button(onClick = {}) { Text(t) } else OutlinedButton(onClick = { type = t }) { Text(t) }
                            }
                        }
                        val (la, lb, lc) = labels(type)
                        if (type == Step.ACTION) {
                            OutlinedButton(onClick = {
                                NativePicker.pick(this@FlowActivity) { act, _ ->
                                    val body = act.removePrefix(NativePicker.PREFIX)
                                    a = body.substringBefore('|'); b = body.substringAfter('|', "")
                                }
                            }) { Text(NativeActions.find(a)?.label ?: "Choose an action…") }
                            NativeActions.find(a)?.help?.takeIf { it.isNotEmpty() }?.let { Text(it, fontSize = 12.sp) }
                            OutlinedTextField(b, { b = it }, label = { Text(lb) })
                            OutlinedButton(onClick = { c = if (c == "optional") "" else "optional" }) {
                                Text(if (c == "optional") "Skips quietly without Shizuku: yes" else "Skips quietly without Shizuku: no")
                            }
                        } else if (type == Step.SHIZUKU) {
                            OutlinedTextField(a, { a = it }, label = { Text(la) })
                            OutlinedTextField(b, { b = it }, label = { Text(lb) })
                            OutlinedButton(onClick = { c = if (c == "optional") "" else "optional" }) {
                                Text(if (c == "optional") "Skips quietly without Shizuku: yes" else "Skips quietly without Shizuku: no")
                            }
                        } else
                        if (la.isNotEmpty()) OutlinedTextField(a, { a = it }, label = { Text(la) })
                        if (type != Step.ACTION && type != Step.SHIZUKU) {
                            if (lb.isNotEmpty()) OutlinedTextField(b, { b = it }, label = { Text(lb) })
                            if (lc.isNotEmpty()) OutlinedTextField(c, { c = it }, label = { Text(lc) })
                        }
                    }
                },
                confirmButton = { TextButton(onClick = {
                    val s = Step(type, a, b, c)
                    snap()
                    if (idx < steps.size) steps[idx] = s
                    else { val at = insertAt.coerceIn(0, steps.size); steps.addAll(at, FlowOps.withClosers(s)); sel = at }
                    save(); edit = null
                }) { Text("OK") } },
                dismissButton = { TextButton(onClick = { edit = null }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun ValuesScreen(close: () -> Unit) {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("My values", fontSize = 20.sp)
            Text(
                "Keys, codes and names that flows use as {name}. They stay only on this phone: they are not in the settings backup and not in copies of the app.",
                fontSize = 12.sp,
            )
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(PrivateValues.allSlots(this@FlowActivity)) { _, slot ->
                    var v by remember { mutableStateOf(PrivateValues.get(this@FlowActivity, slot.name)) }
                    OutlinedTextField(
                        v, { v = it; PrivateValues.set(this@FlowActivity, slot.name, it) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(slot.label + "   {" + slot.name + "}") },
                        supportingText = { if (slot.hint.isNotEmpty()) Text(slot.hint) },
                    )
                }
            }
            Button(onClick = close) { Text("Done") }
        }
    }

    private fun labels(type: String): Triple<String, String, String> = when (type) {
        Step.SHELL -> Triple("Command", "Put the output in variable (default out)", "")
        Step.WAIT -> Triple("Milliseconds", "", "")
        Step.MESSAGE -> Triple("Text", "", "Type window to keep it on screen")
        Step.LAUNCH -> Triple("Package name", "", "")
        Step.INTENT -> Triple("Intent URI", "", "")
        Step.SET -> Triple("Variable", "Value", "")
        Step.IF -> Triple("Left (e.g. {out})", "Operator: = != contains > <", "Right")
        Step.REPEAT -> Triple("Times", "", "")
        Step.HTTP -> Triple("URL", "Method (GET/POST)", "Put the answer in variable")
        Step.RUN -> Triple("Flow name", "", "")
        Step.ACTION -> Triple("", "Argument (if the action takes one)", "")
        Step.SHIZUKU -> Triple("Command (runs with Shizuku)", "Put the output in variable (default out)", "")
        Step.BROADCAST -> Triple("Package or package/.Receiver", "Action", "Extras: key=value;key=value")
        else -> Triple("", "", "")
    }
}
