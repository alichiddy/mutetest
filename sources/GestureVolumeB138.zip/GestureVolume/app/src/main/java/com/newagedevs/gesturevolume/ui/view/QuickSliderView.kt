package com.newagedevs.gesturevolume.ui.view

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.animation.DecelerateInterpolator
import android.view.View
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.DrawableCompat
import com.newagedevs.gesturevolume.utils.PixelFill
import com.newagedevs.gesturevolume.utils.ShaderFill
import com.newagedevs.gesturevolume.R
import com.newagedevs.gesturevolume.utils.EffortFill
import com.newagedevs.gesturevolume.utils.GlimmerFill
import com.newagedevs.gesturevolume.utils.SurgeFill
import com.newagedevs.gesturevolume.utils.SliderFill
import com.newagedevs.gesturevolume.utils.ContentInk
import com.newagedevs.gesturevolume.utils.LevelFeedback
import kotlin.math.ceil
import kotlin.math.roundToInt
import com.newagedevs.gesturevolume.utils.PanelAnimation
import com.newagedevs.gesturevolume.utils.HandlerShape
import android.view.ViewConfiguration

/**
 * The bar, mid-way through becoming a track, at any point on that journey.
 *
 * Drawn rather than composed. It is created and destroyed inside a single touch gesture, in a
 * Service-owned window, and it has to redraw every frame the finger moves — a Compose window with
 * its own recomposer and lifecycle owners would be several milliseconds of setup at the exact
 * moment the user is expecting the bar to snap open. The Deck can afford that because it opens
 * once and stays; this cannot.
 *
 * **Why this draws a rect instead of being scaled.**
 *
 * The version this replaces was a finished slider that `View.scaleX`/`scaleY` squashed down to the
 * bar's proportions and then let go of. Two things are wrong with that and both are visible. A
 * rounded rectangle under non-uniform scale has elliptical corners, so through the whole animation
 * the pill was a lozenge that un-squashed at the end — the "ugly" part of it. And the shape it
 * squashed to was a *slider*, in slider colours, so it never actually resembled the bar it was
 * supposed to be growing out of; the bar was simply blanked on the same frame and the eye read a
 * swap rather than a movement.
 *
 * So the geometry is interpolated instead of transformed. [setExpansion] moves the drawn rect
 * between [setCollapsedRect] — the bar's own bounds, in this window's coordinates — and the full
 * window, and the radius, the colour and the contents all travel with it. Corners stay circular at
 * every value because the radius is a number being animated rather than a curve being stretched,
 * and at expansion 0 what is on screen is the bar: same rectangle, same colour, same corner. That
 * is what lets the handoff be invisible.
 *
 * **Why the expansion is not animated here.** It is a property, set from outside, and for most of
 * its life the thing setting it is the user's finger. The gesture reports how far it has pulled
 * between the two thresholds and that number goes straight in, so the bar tracks the finger one
 * pixel for one pixel and there is no animator between the two to add lag or overshoot. Only the
 * collapse is animated, because only the collapse has no finger driving it.
 *
 * **Why everything is drawn twice.** The value label and the icon sit inside the track, which is
 * one colour below the fill line and another above it. Picking a single colour for them means
 * choosing which half of the range they disappear in. So each is drawn once in the colour that
 * contrasts the track, then again clipped to the filled region in the colour that contrasts the
 * fill. The result inverts exactly at the fill line and is legible at every value, which is the
 * only property that matters for something the user reads while their finger is moving.
 */
class QuickSliderView(context: Context) : View(context) {

    private companion object {
        /**
         * The expansion at which the contents have finished fading in.
         *
         * Well before the end, so the icon and the number are solid for the whole second half of
         * the pull rather than arriving with the commit. The user is deciding whether to keep
         * pulling during exactly that stretch, and what the slider is going to control is the
         * information that decision needs.
         */
        const val CONTENT_FADE_END = 0.55f

        /**
         * The expansion at which the contents start to appear at all.
         *
         * Not zero: at low expansion the shape is still bar-sized and an icon drawn into it would
         * be a smudge that pops. Starting a third of the way in means the first thing that
         * happens is the bar moving, which is the part that has to read as continuous.
         */
        const val CONTENT_FADE_START = 0.18f

        /** Thickness of the bright lip drawn on the fill line while a finger is on the track. */
        const val GRAB_LIP_DP = 3f
    }

    private val density = context.resources.displayMetrics.density

    init {
        // The same depth the Deck and the menu turn through (see PanelEntrance.panelFrame), so a
        // flip or a tilt has the same perspective on every panel. The default is so close that a
        // tall, narrow panel turned sixty degrees swings its far end out past its own window.
        cameraDistance = 18f * density * context.resources.displayMetrics.densityDpi
    }

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    /** The bar's bounds in this window's coordinates — where a fully collapsed slider is drawn. */
    private val collapsedRect = RectF()

    /** The window's own bounds — where a fully expanded slider is drawn. */
    private val expandedRect = RectF()

    /**
     * How much of the window the open panel actually fills, and which side it sits against.
     *
     * The two used to be the same thing, which put a floor under how thin the panel could be: the
     * window has to be at least as wide as the bar, because the bar is what the morph starts from
     * and a collapsed rect wider than its own window is a first frame with its edge cut off. So
     * the window keeps that floor and the panel is drawn inside it, pushed against the screen edge
     * — the same arrangement the handler has always used, and for the same reason.
     */
    private var drawnThicknessPx = 0f
    private var drawnOnLeft = false

    fun setDrawnThickness(px: Float, onLeft: Boolean) {
        drawnThicknessPx = px.coerceAtLeast(0f)
        drawnOnLeft = onLeft
        applyExpandedRect()
        rebuildPath()
        invalidate()
    }

    /**
     * Lying along the top or bottom edge, for a bar that follows the phone (Dynamic position).
     *
     * Everything in this class is written for an upright panel and stays that way. The window is
     * turned on its side instead, and this view draws and hears touches through a quarter turn:
     * its upright bottom at the window's left, so the fill grows rightward the way a slider does,
     * and its upright left against the top edge. The number and the icon are turned back so they
     * still read. Callers hand [setCollapsedRect] upright coordinates; the glass comes back out in
     * window coordinates, as it always has.
     */
    private var turned = false

    fun setTurned(value: Boolean) {
        if (turned == value) return
        turned = value
        applyExpandedRect()
        rebuildPath()
        invalidate()
    }

    /**
     * Room around the panel inside its window, in upright pixels: above it, below it, and on its
     * inward side, away from the screen edge.
     *
     * The entrances move the panel — a slide, a drop, a swing — and a window sized exactly to the
     * panel clips every one of those at its own edge, so half of them looked like no animation at
     * all. The window is that much larger and the panel is drawn inside it. A touch in that room
     * is treated as a tap outside the panel, which is what it looks like.
     */
    private var roomTop = 0
    private var roomBottom = 0
    private var roomInward = 0

    fun setPanelRoom(top: Int, bottom: Int, inward: Int) {
        roomTop = top.coerceAtLeast(0)
        roomBottom = bottom.coerceAtLeast(0)
        roomInward = inward.coerceAtLeast(0)
        applyExpandedRect()
        rebuildPath()
        invalidate()
    }

    /** The visible band of the panel during a wipe, as fractions of its height. See PanelAnimation.Frame. */
    private var revealFrom = 0f
    private var revealTo = 1f

    /** The number's and the icon's own colours, or null to swap with the fill. See [setContentColors]. */
    private var valueInk: Int? = null
    private var iconInk: Int? = null

    fun setContentColors(value: Int?, icon: Int?) {
        if (valueInk == value && iconInk == icon) return
        valueInk = value
        iconInk = icon
        invalidate()
    }

    /** Set when a touch began in the room around the panel, so the rest of that touch is ignored. */
    private var touchInRoom = false

    /** The panel's own upright width and height, whichever way its window lies. */
    private val logicalWidth: Int get() = if (turned) height else width
    private val logicalHeight: Int get() = if (turned) width else height

    private val turnMatrix = android.graphics.Matrix()

    override fun draw(canvas: Canvas) {
        val wiping = revealFrom > 0f || revealTo < 1f
        if (!turned && !wiping) {
            super.draw(canvas)
            return
        }
        canvas.save()
        if (turned) {
            // Upright (u, v) lands at window (width - v, u).
            canvas.translate(width.toFloat(), 0f)
            canvas.rotate(90f)
        }
        if (wiping) {
            // The wipe entrances show a band of the panel rather than moving it: clipped, not
            // scaled, the way PanelEntrance.panelFrame clips the Deck and the menu.
            val top = drawRect.top + drawRect.height() * revealFrom
            val bottom = drawRect.top + drawRect.height() * revealTo
            if (bottom <= top) {
                canvas.restore()
                return
            }
            canvas.clipRect(-BIG_CLIP, top, BIG_CLIP, bottom)
        }
        super.draw(canvas)
        canvas.restore()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (!turned) return super.dispatchTouchEvent(event)
        // The inverse of the turn draw() applies: window (x, y) is upright (y, width - x).
        turnMatrix.setValues(floatArrayOf(0f, 1f, 0f, -1f, 0f, width.toFloat(), 0f, 0f, 1f))
        val upright = MotionEvent.obtain(event)
        upright.transform(turnMatrix)
        return try {
            super.dispatchTouchEvent(upright)
        } finally {
            upright.recycle()
        }
    }

    /** [collapsedRect] and [expandedRect] interpolated by [expansion]. What actually gets drawn. */
    private val drawRect = RectF()
    private val drawPath = Path()

    /**
     * What the lit rim follows: [drawPath], except that a tab's is left open along the screen edge,
     * the way the bar's own border is. A rim down the straight side was a line along the frame of
     * the phone.
     */
    private val rimPath = Path()

    /**
     * The four corners the shape ends on, clockwise from the top left, in pixels.
     *
     * Four, and usually the same four as [collapsedCornersPx]. The panel takes the handler's own
     * corners, so the morph is a *growth* and nothing else: the radii hold still while the rect
     * expands, which is what makes the panel read as the bar getting bigger rather than as a
     * different object fading in over it.
     */
    private val expandedCornersPx = FloatArray(4) { 22f * density }

    /**
     * The bar's four corners, clockwise from the top left, in pixels.
     *
     * Four rather than one because the bar's are not required to agree: the default shape is
     * square where it meets the screen edge and rounded where it faces the app, and collapsing
     * that to an average would make the first frame of every morph a shape the bar has never had.
     */
    private val collapsedCornersPx = FloatArray(4) { 22f * density }

    /** The eight radii `Path.addRoundRect` wants: an x and a y for each corner. */
    private val drawRadii = FloatArray(8)

    /**
     * Which outline the open panel is cut to, and how far a tab's ends sweep.
     *
     * The bar's shape is the *collapsed* end and the panel's is the expanded one, exactly as the
     * corner radii are. Where the two agree the morph interpolates the flare and the change is
     * seamless; where they disagree there is nothing to interpolate — a rectangle and a tab are
     * not the same outline with different numbers — so the panel's shape is used throughout and
     * the first frame is a close approximation of the bar rather than a copy of it.
     */
    private var expandedShape = HandlerShape.ROUNDED
    private var expandedFlare = HandlerShape.DEFAULT_FLARE
    private var collapsedShape = HandlerShape.ROUNDED
    private var collapsedFlare = HandlerShape.DEFAULT_FLARE

    /** Which side of the panel the screen edge is on, for a tab's sweeps. */
    private var edgeOnLeft = false

    /**
     * How far the number sits from the top of the panel, and the icon from the bottom, in pixels.
     *
     * From the panel's own edges, and deliberately not from where a tab's sweep ends: tied to the
     * sweep, the contents slid up and down whenever the sweep was adjusted. See
     * `QuickSliderStore.getValueMarginDp`.
     */
    private var valueMarginPx = 26f * density
    private var iconMarginPx = 26f * density

    fun setContentMargins(valueTopDp: Float, iconBottomDp: Float) {
        valueMarginPx = valueTopDp.coerceAtLeast(0f) * density
        iconMarginPx = iconBottomDp.coerceAtLeast(0f) * density
        invalidate()
    }

    /** Reused by the stripe pass, so a repeating animation allocates nothing per frame. */

    /** Reused by the gradients that slide, for the same reason. */

    /**
     * The pictures most fill styles paint. See [FillArt].
     *
     * Made on first use and thrown away when the animation colours change: it caches gradients,
     * images and colour tables with the palette baked into them, and a new one is the one way to be
     * sure none of those is left in the old colours.
     */
    private var fillArtOrNull: FillArt? = null
    private val fillArt: FillArt
        get() = fillArtOrNull ?: FillArt(density).also { fillArtOrNull = it }

    /** The user's animation colours, or null for each style's own. See [setFillColors]. */
    private var fillColors: IntArray? = null

    /** The Pixels fill's pattern and grid, used while [fillStyle] is [SliderFill.PIXELS]. */
    private var pixelStyle = PixelFill.Style()
    private val pixelArt = PixelArt()

    /** The Shaders fill's effect and settings, used while [fillStyle] is [SliderFill.SHADER]. */
    private var shaderStyle = ShaderFill.Style()

    /** Made on first use, and only on Android 13 and later: before that there is no RuntimeShader. */
    private var shaderArt: ShaderArt? = null

    /** The Surge fill's look and settings, used while [fillStyle] is [SliderFill.SURGE]. */
    private var surgeStyle = SurgeFill.Style()

    /** Made on first use, and only on Android 13 and later, like [shaderArt]. */
    private var surgeArt: SurgeArt? = null

    /** The look's four colours, the user's when they have set some. See [SurgeFill.paletteWith]. */
    private var surgePalette: IntArray = SurgeFill.paletteWith(SurgeFill.CURVE, null)

    /** The surge's own clock, in seconds, run at its speed and the level's pace like [shaderTime]. */
    private var surgeTime = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
    private var surgeTickAt = 0L

    /** The Effort fill's look and settings, used while [fillStyle] is [SliderFill.EFFORT]. */
    private var effortStyle = EffortFill.Style()
    private var effortArtOrNull: EffortArt? = null
    private val effortArt: EffortArt
        get() = effortArtOrNull ?: EffortArt(density).also { effortArtOrNull = it }

    /** The picker's colours, the user's when they have set some. See [EffortFill.paletteWith]. */
    private var effortPalette: IntArray = EffortFill.paletteWith(null)

    /** The levels' names, lowest first, in the app's language. */
    private val effortLabels: Array<String> by lazy {
        arrayOf(
            context.getString(R.string.effort_level_low),
            context.getString(R.string.effort_level_high),
            context.getString(R.string.effort_level_extra_high),
            context.getString(R.string.effort_level_max),
            context.getString(R.string.effort_level_ultra_max),
        )
    }

    /** The same, shortened for a track with no room for the whole name. */
    private val effortShortLabels: Array<String> by lazy {
        arrayOf(
            context.getString(R.string.effort_level_low),
            context.getString(R.string.effort_level_high),
            context.getString(R.string.effort_level_extra_high_short),
            context.getString(R.string.effort_level_max),
            context.getString(R.string.effort_level_ultra_max_short),
        )
    }

    /**
     * The picker's own clock, in seconds: advanced a frame at a time by what the frame took, times
     * its speed, so a new speed takes over from the next frame without the sheen jumping. Starts
     * somewhere in the hour, like [shaderTime].
     */
    private var effortTime = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
    private var effortTickAt = 0L

    /** The Glimmer fill's settings, used while [fillStyle] is [SliderFill.GLIMMER]. */
    private var glimmerStyle = GlimmerFill.Style()
    private var glimmerArtOrNull: GlimmerArt? = null
    private val glimmerArt: GlimmerArt
        get() = glimmerArtOrNull ?: GlimmerArt(density).also { glimmerArtOrNull = it }

    /** The glimmer's colours, the user's when they have set some. See [GlimmerFill.paletteWith]. */
    private var glimmerPalette: IntArray = GlimmerFill.paletteWith(null)

    /** The glimmer's own clock, in seconds, run at its speed like [effortTime]. */
    private var glimmerTime = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
    private var glimmerTickAt = 0L

    /**
     * Where the glimmer's stops keep clear of, as (top, bottom) pairs: the number, then the icon.
     * NaN for one that is not shown, which no stop is ever inside. Filled in each frame, never made.
     */
    private val glimmerKeepOut = FloatArray(4)

    /**
     * How the fill answers the level — see [LevelFeedback] — and how fast it moves, for the fills
     * without a speed of their own. The Effort fill keeps its own answer to the level.
     */
    private var feedback = LevelFeedback.Style()
    private var feedbackArtOrNull: LevelFeedbackArt? = null
    private val feedbackArt: LevelFeedbackArt
        get() = feedbackArtOrNull ?: LevelFeedbackArt(density).also { feedbackArtOrNull = it }

    /** The fifth the level was last in, or -1 before it has had one; and whether it was full. */
    private var feedbackLevel = -1
    private var wasFull = false

    /** When a fifth was last passed, and the top last reached, in uptime; 0 for not yet. */
    private var stepAt = 0L
    private var fullAt = 0L

    /**
     * Whether the top is reached over and over, every [SHOWCASE_S] of the feedback's clock, rather
     * than when the level gets there: for a picker's tile, a panel held at 100% that has to show
     * its flourish arriving as well as staying.
     */
    private var showcase = false

    fun setFeedbackShowcase(on: Boolean) {
        if (showcase == on) return
        showcase = on
        invalidate()
    }

    /** Seconds since the top was reached, as the feedback reads it; negative for not yet. */
    private fun fullSeconds(): Float = if (showcase) feedbackTime % SHOWCASE_S else secondsSince(fullAt)

    /** The feedback's own clock, in seconds, at the fill's speed; and the fill clock's last tick. */
    private var feedbackTime = 0f
    private var phaseTickAt = 0L

    /** Whether this fill has the feedback layer. */
    private val feedbackOn: Boolean
        get() = fillStyle != SliderFill.EFFORT && feedback.drawsAnything

    /** The fills with a speed slider of their own, which [LevelFeedback.Style.speed] leaves alone. */
    private val ownSpeed: Boolean
        get() = fillStyle == SliderFill.PIXELS || fillStyle == SliderFill.SHADER ||
            fillStyle == SliderFill.SURGE || fillStyle == SliderFill.GLIMMER || fillStyle == SliderFill.EFFORT

    /** How much faster than its own pace the fill runs at this level. */
    private fun levelPace(): Float = LevelFeedback.pace(value, feedbackOn && feedback.follow)

    /** The effect's four colours, the user's when they have set some. See [ShaderFill.paletteWith]. */
    private var shaderPalette: IntArray = ShaderFill.paletteWith(ShaderFill.LAVA_LAMP, null)

    /**
     * The effect's own clock, in seconds. Advanced by what each frame took times the speed, rather
     * than read off a clock and multiplied, so dragging the speed slider changes the pace without
     * jumping the picture. Starts somewhere in the hour, so each opening finds it mid-flow rather
     * than at the same first frame.
     */
    private var shaderTime = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
    private var shaderTickAt = 0L

    /**
     * The palette the current style is painted with, worked out when the style or the colours
     * change rather than on every frame: [SliderFill.paletteWith] makes a new array each call.
     */
    private var fillPalette: LongArray = SliderFill.palette(SliderFill.SOLID)

    private var trackColor = Color.BLACK
    private var fillColor = Color.WHITE

    /** The bar's background colour, so a collapsed slider is the bar rather than a small slider. */
    private var collapsedColor = Color.BLACK

    /** The colour actually painted: [collapsedColor] to [trackColor], travelling with the shape. */
    private var blendedTrackColor = Color.BLACK

    private var icon: Drawable? = null
    private var showValue = true

    /**
     * Whether a tap on the icon is its own gesture. See [Listener.onIconTapped].
     *
     * A tap only. A finger that lands on the icon and moves is setting the level like anywhere
     * else on the track, so nothing is decided until it either lifts or travels.
     */
    var iconTapEnabled = false

    /** A finger is down on the icon and has not travelled far enough to be a drag. */
    private var iconPressed = false
    private var iconDownY = 0f
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val iconPressPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** 0 = the bar's shape and colour, 1 = the full track. */
    private var expansion = 0f

    /**
     * How much of the contents to draw, 0..1. Purely a function of [expansion].
     *
     * It governs the fill as well as the number and the icon, so a track that is retracting
     * dissolves as one thing. Left solid to the last frame instead, the shape's final state is a
     * bar-sized pill with a fill line and a two-digit number crammed into it — briefly, but it is
     * the frame the eye lands on as the motion stops.
     */
    private var contentAlpha = 0f

    /** 0..1. The value the fill is drawn to. */
    private var value = 0f

    /**
     * How much of the track's own colour survives, 0..1. See PanelTheme.
     *
     * Applied to the painted colour rather than to the whole view's alpha, because the contents —
     * the number, the icon, the fill — have to stay legible on a surface that is deliberately
     * see-through. Fading the view would fade them with it.
     */
    private var surfaceAlpha = 1f

    /**
     * The glass lighting: a rim, a sheen and a counter-light, or null for the other themes.
     *
     * Three paints rather than one border, for the reason the menu's version gives: a border of
     * even weight all the way round reads as a fainter card, not as a material. The rim is bright
     * along the top and nearly gone by the bottom, the sheen falls across the upper surface, and
     * the counter-light is what real glass picks up from whatever it is sitting on.
     *
     * Their shaders depend on the drawn rectangle, which moves every frame of the morph, so they
     * are rebuilt in [rebuildGlass] rather than once here.
     */
    private var edgePaint: Paint? = null
    private var sheenPaint: Paint? = null
    private var counterLightPaint: Paint? = null
    private var glassEnabled = false

    /**
     * Whether the fill is drawn at all.
     *
     * False for the whole pre-commit stretch. A pull that has not yet reached the slider controls
     * nothing, and a track already showing a fill level would say it does — the user would read
     * the current brightness as something their finger had just set, and lifting early would look
     * like the value had been applied and then thrown away.
     */
    private var fillVisible = false

    /**
     * How the panel reports the user's finger back to whoever opened it.
     *
     * The panel drives itself now. It used to be a read-only picture of a value the gesture engine
     * was computing from a finger held somewhere else on the screen, which is why it could be
     * opened and then not adjusted: the stroke that opened it was the only thing that could move
     * it, and once that stroke ended there was no way in. Taking its own touches is the whole
     * difference between a readout and a control.
     */
    interface Listener {
        /**
         * The finger is on the track at this fraction of its height, 0 at the bottom.
         *
         * Absolute, not a delta. A panel the user has *deliberately opened* and is now touching is
         * a slider like any other, and every slider on the platform jumps to where it is touched;
         * a relative grab would mean the first touch does nothing visible, which on a control that
         * closes itself shortly afterwards reads as broken.
         */
        fun onValuePicked(fraction: Float)

        /** The finger lifted. The panel has been used, so it can now show its result and go. */
        fun onAdjustFinished()

        /**
         * The icon was tapped, as opposed to the track under it. Only ever reported while
         * [iconTapEnabled] is on; otherwise the icon is part of the track like everything else.
         */
        fun onIconTapped() {}
    }

    var listener: Listener? = null

    /**
     * Where the blur behind this panel belongs, told whenever that changes.
     *
     * The panel cannot blur what is behind it itself: window blur lives on a separate window (see
     * `PanelBackdrop`), so whoever owns that window has to keep it under the panel. That used to be
     * done once, at full size, when the panel finished opening, and then left alone. Everything
     * this view animates moved the panel off its glass. The morph shrank it back into the bar in a
     * tenth of a second and left a blurred rectangle, hard edge and all, standing where it had been
     * until the retraction ended: the line that blinked at the edge on every auto-close. The
     * entrance slid, scaled and faded the panel over a pane that did none of those.
     *
     * So the view reports where the glass belongs once the panel is at rest, the full-width part
     * of its final shape, and how strongly to blur there right now: by how much of that rectangle
     * the panel covers this frame, through the morph and whatever the entrance is doing to the
     * layer, and by its fade. The rectangle never changes while the panel animates, so the glass
     * window is never moved, which measured at 2.5ms of the main thread per frame; the blur
     * arrives with the panel and leaves with it instead. In this window's coordinates. A strength
     * of zero means nothing to blur.
     */
    fun interface GlassListener {
        fun onGlass(left: Float, top: Float, right: Float, bottom: Float, cornerPx: Float, strength: Float)
    }

    var glassListener: GlassListener? = null
        set(value) {
            field = value
            reportGlass()
        }

    /**
     * Called once, when this view first draws, so whatever it is replacing can wait until it has
     * certainly reached the screen. See `OverlayController.openQuickSliderWindow`.
     */
    var onFirstFrame: (() -> Unit)? = null
    private var firstFrameDrawn = false

    /** The outline [rebuildPath] last drew, kept so the glass can be cut to match it. */
    private var drawnIsTab = false
    private var drawnFlare = HandlerShape.DEFAULT_FLARE
    private val glassBounds = RectF()
    private val glassFinal = RectF()
    private val glassBox = FloatArray(4)

    /**
     * Whether [fillShapePath] has to be built again, and what it was last built for.
     *
     * Rebuilt only when it would come out different. It used to be rebuilt on every frame, and a
     * rebuilt path is a new path to the renderer, which cannot reuse the clip masks and edges it
     * rasterised for the last one: that was most of the ten milliseconds of render time an open
     * panel spent on each frame of its fill animation.
     */
    private var fillPathDirty = true

    /** Spectrum's colour wheel as a strip one mirrored period tall, and its sheen. Built once. */
    private var builtFillTop = Float.NaN
    private var builtFillPhase = Float.NaN

    private fun reportGlass() {
        val glass = glassListener ?: return
        if (expandedRect.isEmpty) {
            glass.onGlass(0f, 0f, 0f, 0f, 0f, 0f)
            return
        }
        // Where the glass sits: the full-width part of the panel at rest. Only a tab's straight
        // middle is full width. A blur region is a rounded rectangle and nothing else, so behind a
        // tab's sweeps it would poke out past the shape, and because blur lightens what is behind
        // it the corners would read as a second panel.
        val finalCorner: Float
        if (expandedShape == HandlerShape.TAB) {
            val depth = HandlerShape.tabSweepDepth(expandedRect.height(), expandedFlare)
            glassFinal.set(expandedRect.left, expandedRect.top + depth, expandedRect.right, expandedRect.bottom - depth)
            finalCorner = minOf(expandedRect.width() / 2f, depth)
        } else {
            glassFinal.set(expandedRect)
            // The largest of the four. A rounder corner cuts deeper, so it stays inside all four.
            finalCorner = (expandedCornersPx.maxOrNull() ?: 0f)
                .coerceAtMost(minOf(expandedRect.width(), expandedRect.height()) / 2f)
        }
        if (glassFinal.isEmpty) {
            glass.onGlass(0f, 0f, 0f, 0f, 0f, 0f)
            return
        }
        if (turned) {
            // Out of the upright frame and into the window's, which is where the glass lives.
            glass.onGlass(
                width - glassFinal.bottom, glassFinal.left, width - glassFinal.top, glassFinal.right,
                finalCorner, currentGlassStrength(),
            )
        } else {
            glass.onGlass(
                glassFinal.left, glassFinal.top, glassFinal.right, glassFinal.bottom,
                finalCorner, currentGlassStrength(),
            )
        }
    }

    /** How much of its resting place the panel covers this frame, through morph and entrance. */
    private fun currentGlassStrength(): Float {
        if (drawRect.isEmpty || expansion <= 0f || alpha <= 0f) return 0f
        if (drawnIsTab) {
            val depth = HandlerShape.tabSweepDepth(drawRect.height(), drawnFlare)
            glassBounds.set(drawRect.left, drawRect.top + depth, drawRect.right, drawRect.bottom - depth)
        } else {
            glassBounds.set(drawRect)
        }
        if (revealFrom > 0f || revealTo < 1f) {
            val h = drawRect.height()
            glassBounds.top = maxOf(glassBounds.top, drawRect.top + h * revealFrom)
            glassBounds.bottom = minOf(glassBounds.bottom, drawRect.top + h * revealTo)
        }
        if (glassBounds.isEmpty) return 0f
        val m = matrix
        if (!m.isIdentity) m.mapRect(glassBounds)
        glassBox[0] = glassBounds.left
        glassBox[1] = glassBounds.top
        glassBox[2] = glassBounds.right
        glassBox[3] = glassBounds.bottom
        return PanelAnimation.glassStrength(
            glassBox, glassFinal.left, glassFinal.top, glassFinal.right, glassFinal.bottom, alpha,
        )
    }

    /**
     * What to do when a touch lands anywhere but on this panel.
     *
     * Delivered as `ACTION_OUTSIDE` because the window carries `FLAG_WATCH_OUTSIDE_TOUCH`, and it
     * is a notification rather than an interception: the touch still reaches whatever is under it,
     * so dismissing the panel never costs the user the tap they were actually making.
     */
    private var onTouchOutside: (() -> Unit)? = null

    fun setOnTouchOutside(block: (() -> Unit)?) {
        onTouchOutside = block
    }

    /**
     * Whether this panel answers touches.
     *
     * False until the opening animation has grown it enough to be worth aiming at — a track two
     * pixels tall that already accepts touches turns the first frame of the animation into a
     * value the user did not choose.
     */
    private var interactive = false

    /** Whether a finger is on the track right now. Widens the fill's leading edge as a grab cue. */
    private var grabbed = false

    /** Whether the surface is a pale one, which halves the strength of the glass lighting. */
    private var glassLight = false

    /** The entrance, when one is playing. Held so a second opening can take it over. */
    private var entranceAnimator: ValueAnimator? = null

    /** Which of [SliderFill]'s behaviours the filled portion has. */
    private var fillStyle = SliderFill.SOLID

    /** 0..1 through the current style's cycle. Driven by [fillClock] while the panel is open. */
    private var fillPhase = 0f
    private var fillClock: ValueAnimator? = null

    /** The fill's outline. A rectangle for most styles, a wave or a stack of blocks for the rest. */
    private val fillShapePath = Path()
    private val effectPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** Held so a second glide, or a finger arriving mid-glide, can take it over. */
    private var valueAnimator: ValueAnimator? = null

    /**
     * Dresses the panel: how much of its colour survives, and whether it has a lit edge.
     *
     * Blur is not set here — it belongs to the window, not the view, and `OverlayController`
     * applies it when the window is added. This is only the part that is painted.
     */
    fun setPanelTheme(surface: Float, litEdge: Boolean, light: Boolean = false) {
        surfaceAlpha = surface.coerceIn(0f, 1f)
        glassEnabled = litEdge
        glassLight = light
        if (litEdge) {
            edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1.2f * density
            }
            sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            counterLightPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        } else {
            edgePaint = null
            sheenPaint = null
            counterLightPaint = null
        }
        refreshBlend()
        rebuildGlass()
        invalidate()
    }

    /**
     * Re-aims the glass shaders at the rectangle currently being drawn.
     *
     * Called from [rebuildPath], so it follows the panel as it grows out of the bar — a shader
     * fixed to the panel's final size would put the highlight somewhere off the shape for the
     * whole of the morph.
     */
    private fun rebuildGlass() {
        if (!glassEnabled || drawRect.isEmpty) return
        val top = drawRect.top
        val bottom = drawRect.bottom
        // On a pale pane, white lighting piled on a white surface flattens it. Same correction the
        // menu and the Deck make, and for the same reason.
        // And by how open the panel is. The lighting belongs to the panel's material, and collapsed
        // the panel has to be the bar exactly, since it stands in for it at both ends of the morph,
        // and the bar has none.
        val k = (if (glassLight) 0.45f else 1f) * expansion
        fun w(alpha: Int): Int = ((alpha * k).toInt().coerceIn(0, 255) shl 24) or 0xFFFFFF

        sheenPaint?.shader = android.graphics.LinearGradient(
            0f, top, 0f, top + drawRect.height() * 0.5f,
            intArrayOf(w(0x2E), w(0x08), 0x00FFFFFF),
            floatArrayOf(0f, 0.55f, 1f),
            android.graphics.Shader.TileMode.CLAMP,
        )
        counterLightPaint?.shader = android.graphics.LinearGradient(
            0f, bottom - drawRect.height() * 0.2f, 0f, bottom,
            intArrayOf(0x00FFFFFF, w(0x1A)),
            null,
            android.graphics.Shader.TileMode.CLAMP,
        )
        edgePaint?.shader = android.graphics.LinearGradient(
            0f, top, 0f, bottom,
            intArrayOf(w(0xA6), w(0x3D), w(0x14), w(0x4D)),
            floatArrayOf(0f, 0.35f, 0.75f, 1f),
            android.graphics.Shader.TileMode.CLAMP,
        )
    }

    fun setColors(track: Int, fill: Int) {
        trackColor = track
        fillColor = fill
        // Assigning `color` resets the paint's alpha to the colour's own, so the per-frame alpha
        // set in onDraw is re-applied there rather than being expected to survive this.
        fillPaint.color = fill
        refreshBlend()
    }

    /**
     * The bar's own colour and corner, so expansion 0 is a pixel-accurate stand-in for it.
     *
     * Taken from the live handler rather than assumed, because the bar is fully themeable: a user
     * with a translucent red bar and a dark slider would otherwise see the red flick to dark on
     * the first frame of every pull.
     */
    fun setCollapsedAppearance(
        color: Int,
        topLeftDp: Float,
        topRightDp: Float,
        bottomLeftDp: Float,
        bottomRightDp: Float,
    ) {
        collapsedColor = color
        collapsedCornersPx[0] = topLeftDp * density
        collapsedCornersPx[1] = topRightDp * density
        collapsedCornersPx[2] = bottomRightDp * density
        collapsedCornersPx[3] = bottomLeftDp * density
        refreshBlend()
        rebuildPath()
        invalidate()
    }

    /** Where the bar sits inside this window. See the class note on why the window is bigger. */
    fun setCollapsedRect(left: Float, top: Float, right: Float, bottom: Float) {
        collapsedRect.set(left, top, right, bottom)
        rebuildPath()
        invalidate()
    }

    /** One radius for all four. For callers with a uniform shape — the settings preview. */
    fun setCornerRadiusDp(dp: Float) {
        expandedCornersPx.fill(dp * density)
        rebuildPath()
        invalidate()
    }

    /**
     * The outline the panel grows into, and the one it grows out of.
     *
     * @param edgeLeft which screen edge the bar is on, so a tab's sweeps run the right way.
     */
    fun setShapes(
        expanded: String,
        expandedFlare: Float,
        collapsed: String,
        collapsedFlare: Float,
        edgeLeft: Boolean,
    ) {
        this.expandedShape = HandlerShape.sanitize(expanded)
        this.expandedFlare = HandlerShape.sanitizeFlare(expandedFlare)
        this.collapsedShape = HandlerShape.sanitize(collapsed)
        this.collapsedFlare = HandlerShape.sanitizeFlare(collapsedFlare)
        this.edgeOnLeft = edgeLeft
        rebuildPath()
        invalidate()
    }

    /** The four the shape grows into. Clockwise from the top left, like the collapsed set. */
    fun setExpandedCorners(
        topLeftDp: Float,
        topRightDp: Float,
        bottomLeftDp: Float,
        bottomRightDp: Float,
    ) {
        expandedCornersPx[0] = topLeftDp * density
        expandedCornersPx[1] = topRightDp * density
        expandedCornersPx[2] = bottomRightDp * density
        expandedCornersPx[3] = bottomLeftDp * density
        rebuildPath()
        invalidate()
    }

    fun setIcon(@DrawableRes res: Int?) {
        icon = res?.let { ContextCompat.getDrawable(context, it)?.mutate() }
        invalidate()
    }

    fun setShowValue(show: Boolean) {
        showValue = show
        invalidate()
    }

    /**
     * Moves the shape between the bar and the track.
     *
     * The one property the finger drives, and everything else here is downstream of it: the size,
     * the corner, the colour and how much of the contents show are all read off this single
     * number, so there is no way for them to get out of step with each other or with the gesture.
     */
    fun setExpansion(fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        if (clamped == expansion) return
        expansion = clamped
        contentAlpha = contentFadeFor(clamped)
        refreshBlend()
        rebuildPath()
        invalidate()
    }

    fun expansion(): Float = expansion

    /**
     * The pull became a live slider: start drawing the fill.
     *
     * One-way. Nothing un-commits — the window is torn down and rebuilt for the next gesture —
     * so there is no path back to a track that has a value and stops showing it.
     */
    fun setCommitted() {
        if (fillVisible) return
        fillVisible = true
        invalidate()
    }

    /**
     * Puts the fill at [fraction] this frame.
     *
     * For a finger on the track, and nothing else. A drag must be exactly where the finger is —
     * a control that eases toward the touch instead of sitting under it feels like it is lagging,
     * however short the ease is. Use [animateValue] when there is no finger to explain the move.
     */
    fun setValue(fraction: Float) {
        valueAnimator?.cancel()
        setValueNow(fraction)
    }

    private fun setValueNow(fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        if (clamped == value) return
        value = clamped
        noteLevel()
        invalidate()
    }

    /**
     * Notes a fifth passed, or the top reached, for the feedback to flash. Not on the first value
     * the panel is given: that is where it opened, not somewhere the finger went.
     */
    private fun noteLevel() {
        val now = SystemClock.uptimeMillis()
        val level = LevelFeedback.levelAt(value)
        val full = LevelFeedback.isFull(value)
        if (feedbackLevel >= 0) {
            if (level != feedbackLevel) stepAt = now
            if (full && !wasFull) fullAt = now
        }
        feedbackLevel = level
        wasFull = full
    }

    /**
     * Glides the fill to [fraction].
     *
     * For the moves nothing on screen accounts for: the nudge buttons, and a level changed from
     * somewhere else while the panel happens to be open. A jump there reads as a glitch, because
     * the user's eye has nothing to attribute it to.
     */
    fun animateValue(fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        if (clamped == value) return
        valueAnimator?.cancel()
        valueAnimator = ValueAnimator.ofFloat(value, clamped).apply {
            duration = VALUE_GLIDE_MS
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { setValueNow(it.animatedValue as Float) }
            start()
        }
    }

    private fun contentFadeFor(e: Float): Float =
        ((e - CONTENT_FADE_START) / (CONTENT_FADE_END - CONTENT_FADE_START)).coerceIn(0f, 1f)

    private fun refreshBlend() {
        blendedTrackColor = ColorUtils.blendARGB(collapsedColor, trackColor, expansion)
        trackPaint.color = blendedTrackColor
        // Scales whatever alpha the colour already carried — the bar can itself be translucent,
        // and a theme that replaced that alpha rather than multiplying it would make a see-through
        // bar grow into a solid panel.
        trackPaint.alpha =
            (Color.alpha(blendedTrackColor) * surfaceAlpha).toInt().coerceIn(0, 255)
    }

    /**
     * Opens the panel to touches. Called once the grow animation has finished.
     */
    fun setInteractive(value: Boolean) {
        interactive = value
        if (!value && (grabbed || iconPressed)) {
            grabbed = false
            iconPressed = false
            invalidate()
        }
    }

    /**
     * Which behaviour the fill has, and starts or stops the clock that drives it.
     *
     * The clock only runs while there is something to animate and the panel is on screen — this
     * view's whole life is a few seconds, but a repeating animator left running after the window
     * is gone is a leak that outlives the thing that leaked it.
     */
    fun setFillStyle(style: String) {
        val next = SliderFill.sanitize(style)
        if (next == fillStyle) return
        fillStyle = next
        fillPalette = SliderFill.paletteWith(next, fillColors)
        fillPhase = 0f
        fillPathDirty = true
        restartFillClock()
        invalidate()
    }

    /**
     * The colours the pictorial fills are painted in: the user's, spread over each style's own
     * palette by [SliderFill.paletteWith], or null for the style's own.
     *
     * The styles drawn in the fill and track colours ignore these, since those colours are already
     * the user's. Setting the same colours again does nothing, so a caller can apply its settings
     * on every change without throwing away the pictures' caches each time.
     */
    fun setFillColors(colors: IntArray?) {
        val next = colors?.takeIf { it.isNotEmpty() }?.copyOf()
        if (next.contentEquals(fillColors)) return
        fillColors = next
        fillPalette = SliderFill.paletteWith(fillStyle, next)
        shaderPalette = ShaderFill.paletteWith(shaderStyle.effect, next)
        surgePalette = SurgeFill.paletteWith(surgeStyle.look, next)
        effortPalette = EffortFill.paletteWith(next)
        glimmerPalette = GlimmerFill.paletteWith(next)
        fillArtOrNull = null
        invalidate()
    }

    /**
     * The Pixels fill's settings. The clock is restarted only when what it keeps time for changes —
     * the pattern or its speed — so dragging the gap or the glow slider does not restart the pattern
     * on every step of the drag.
     */
    fun setPixelStyle(style: PixelFill.Style) {
        val next = style.sanitized()
        if (next == pixelStyle) return
        val retime = next.pattern != pixelStyle.pattern || next.speed != pixelStyle.speed
        pixelStyle = next
        if (retime && fillStyle == SliderFill.PIXELS) restartFillClock()
        invalidate()
    }

    /**
     * The Shaders fill's settings. Only stopping or starting it touches the clock: the speed is
     * applied a frame at a time, so a new speed simply takes over from the next frame.
     */
    fun setShaderStyle(style: ShaderFill.Style) {
        val next = style.sanitized()
        if (next == shaderStyle) return
        val retime = next.isAnimated != shaderStyle.isAnimated
        if (next.effect != shaderStyle.effect) shaderPalette = ShaderFill.paletteWith(next.effect, fillColors)
        shaderStyle = next
        if (retime && fillStyle == SliderFill.SHADER) restartFillClock()
        invalidate()
    }

    /**
     * The Surge fill's settings. As with the shader's, only stopping or starting it touches the
     * clock; a new speed takes over from the next frame.
     */
    fun setSurgeStyle(style: SurgeFill.Style) {
        val next = style.sanitized()
        if (next == surgeStyle) return
        val retime = next.isAnimated != surgeStyle.isAnimated
        if (next.look != surgeStyle.look) surgePalette = SurgeFill.paletteWith(next.look, fillColors)
        surgeStyle = next
        if (retime && fillStyle == SliderFill.SURGE) restartFillClock()
        invalidate()
    }

    /**
     * The Effort fill's settings. Nothing here touches the clock: the picker keeps its own time,
     * and a new speed or look simply takes over from the next frame.
     */
    fun setEffortStyle(style: EffortFill.Style) {
        val next = style.sanitized()
        if (next == effortStyle) return
        effortStyle = next
        invalidate()
    }

    /** The Glimmer fill's settings. Like the picker's, they take over from the next frame; the clock runs on. */
    fun setGlimmerStyle(style: GlimmerFill.Style) {
        val next = style.sanitized()
        if (next == glimmerStyle) return
        glimmerStyle = next
        invalidate()
    }

    /**
     * How the fill answers the level, and its speed. The clock is restarted only when whether there
     * is anything to animate changes, so a switch flipped mid-animation does not restart it.
     */
    fun setLevelFeedback(style: LevelFeedback.Style) {
        val next = style.sanitized()
        if (next == feedback) return
        val retime = next.drawsAnything != feedback.drawsAnything
        feedback = next
        if (retime) restartFillClock()
        invalidate()
    }

    /** Whether this phone can draw the Shaders fill at all. */
    private val shadersSupported: Boolean get() = Build.VERSION.SDK_INT >= ShaderFill.MIN_SDK

    /**
     * Plays one of [PanelAnimation]'s entrances on this view.
     *
     * On top of the morph, not instead of it: the panel grows out of the bar because that is what
     * it *is*, and the entrance is what it does while it grows. They compose because the morph
     * animates the shape that gets drawn and this animates the layer it is drawn into.
     *
     * Not for the pull gesture. There a finger is driving the expansion, and a second animation
     * moving the panel while the user is trying to place it is the panel arguing with them.
     */
    fun playEntrance(animation: String, towardLeft: Boolean, speed: Float) {
        entranceAnimator?.cancel()
        val id = PanelAnimation.sanitize(animation)
        entranceAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = PanelAnimation.scaledDurationMs(id, speed).toLong()
            interpolator = null
            addUpdateListener {
                applyFrame(PanelAnimation.frameAt(id, it.animatedValue as Float, towardLeft))
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    // Exactly at rest, whatever the clock did on its last frame. A panel left a
                    // hundredth of a degree off is a panel that never settles.
                    applyFrame(PanelAnimation.Frame())
                    if (entranceAnimator === animation) entranceAnimator = null
                }
            })
            start()
        }
    }

    private fun applyFrame(f: PanelAnimation.Frame) {
        alpha = f.alpha
        rotation = f.rotationZ
        if (revealFrom != f.revealFrom || revealTo != f.revealTo) {
            revealFrom = f.revealFrom
            revealTo = f.revealTo
            invalidate()
        }
        // About the panel, not the window: the window has room around the panel for the entrance
        // to move in, and a pivot at the window's centre would swing the panel about a point
        // beside it.
        val rect = if (expandedRect.isEmpty) RectF(0f, 0f, logicalWidth.toFloat(), logicalHeight.toFloat()) else expandedRect
        val pivotU = rect.left + rect.width() * f.originX
        val pivotV = rect.top + rect.height() * f.originY
        if (turned) {
            // The entrance is written for an upright panel, so it is turned with the drawing:
            // upright x runs down the window and upright y runs right to left.
            pivotX = width - pivotV
            pivotY = pivotU
            scaleX = f.scaleY
            scaleY = f.scaleX
            translationX = -f.translationY * density
            translationY = f.translationX * density
            rotationX = f.rotationY
            rotationY = -f.rotationX
        } else {
            pivotX = pivotU
            pivotY = pivotV
            scaleX = f.scaleX
            scaleY = f.scaleY
            translationX = f.translationX * density
            translationY = f.translationY * density
            rotationX = f.rotationX
            rotationY = f.rotationY
        }
        reportGlass()
    }

    private fun restartFillClock() {
        fillClock?.cancel()
        fillClock = null
        val pixels = fillStyle == SliderFill.PIXELS
        val shader = fillStyle == SliderFill.SHADER
        val surge = fillStyle == SliderFill.SURGE
        val effort = fillStyle == SliderFill.EFFORT
        val glimmer = fillStyle == SliderFill.GLIMMER
        val animated = when {
            pixels -> PixelFill.isAnimated(pixelStyle.pattern)
            shader -> shadersSupported && shaderStyle.isAnimated
            surge -> shadersSupported && surgeStyle.isAnimated
            else -> SliderFill.isAnimated(fillStyle)
        }
        // The feedback moves on its own too, so a fill that holds still still runs a clock for it.
        if ((!animated && !feedbackOn) || !isAttachedToWindow) return
        shaderTickAt = 0L
        surgeTickAt = 0L
        effortTickAt = 0L
        glimmerTickAt = 0L
        phaseTickAt = 0L
        val cycleMs = (if (pixels) PixelFill.cycleMs(pixelStyle) else SliderFill.cycleMs(fillStyle).toLong())
            .coerceAtLeast(1L)
        // A ticker rather than the phase itself: the phase is advanced a frame at a time by what
        // the frame took, at a pace that follows the level, so the pace can change without the
        // picture jumping. Still whole cycles, so the loops stay seamless.
        fillClock = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = null
            addUpdateListener {
                tickFillPhase(cycleMs, animated)
                if (shader) tickShaderClock()
                if (surge) tickSurgeClock()
                if (effort) tickEffortClock()
                if (glimmer) tickGlimmerClock()
                invalidate()
            }
            start()
        }
    }

    /**
     * Moves [fillPhase] on by the time since the last frame, a whole cycle every [cycleMs] at the
     * fill's speed and the level's pace, and the feedback's clock with it. Capped like
     * [tickShaderClock].
     */
    private fun tickFillPhase(cycleMs: Long, animated: Boolean) {
        val now = SystemClock.uptimeMillis()
        val last = phaseTickAt
        phaseTickAt = now
        if (last == 0L) return
        val dt = (now - last).coerceIn(0L, 100L).toFloat()
        val speed = if (ownSpeed) 1f else feedback.speed
        if (animated) fillPhase = (fillPhase + dt / cycleMs * speed * levelPace()) % 1f
        feedbackTime = (feedbackTime + dt / 1000f * speed) % FEEDBACK_TIME_WRAP_S
    }

    /**
     * Moves [shaderTime] on by the time since the last frame, at the effect's speed. A frame that
     * took longer than a tenth of a second — the panel held off screen, a stall — counts as a
     * tenth, so the effect resumes where it was rather than leaping.
     */
    private fun tickShaderClock() {
        val now = SystemClock.uptimeMillis()
        val last = shaderTickAt
        shaderTickAt = now
        if (last == 0L) return
        val step = (now - last).coerceIn(0L, 100L) / 1000f * shaderStyle.speed * levelPace()
        shaderTime = (shaderTime + step) % ShaderFill.TIME_WRAP_S
    }

    /** Moves [surgeTime] on by the time since the last frame, at the look's speed and the level's pace, like [tickShaderClock]. */
    private fun tickSurgeClock() {
        val now = SystemClock.uptimeMillis()
        val last = surgeTickAt
        surgeTickAt = now
        if (last == 0L) return
        val step = (now - last).coerceIn(0L, 100L) / 1000f * surgeStyle.speed * levelPace()
        surgeTime = (surgeTime + step) % SurgeFill.TIME_WRAP_S
    }

    /** Moves [effortTime] on by the time since the last frame, at the picker's speed, capped like [tickShaderClock]. */
    private fun tickEffortClock() {
        val now = SystemClock.uptimeMillis()
        val last = effortTickAt
        effortTickAt = now
        if (last == 0L) return
        val step = (now - last).coerceIn(0L, 100L) / 1000f * effortStyle.speed
        effortTime = (effortTime + step) % EffortFill.TIME_WRAP_S
    }

    /** Moves [glimmerTime] on by the time since the last frame, at the glimmer's speed, capped like [tickShaderClock]. */
    private fun tickGlimmerClock() {
        val now = SystemClock.uptimeMillis()
        val last = glimmerTickAt
        glimmerTickAt = now
        if (last == 0L) return
        val step = (now - last).coerceIn(0L, 100L) / 1000f * glimmerStyle.speed * levelPace()
        glimmerTime = (glimmerTime + step) % GlimmerFill.TIME_WRAP_S
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        restartFillClock()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        fillClock?.cancel()
        fillClock = null
        pixelArt.release()
        glimmerArtOrNull?.release()
        backdropBitmap?.recycle()
        backdropBitmap = null
        backdropKey = 0
        valueAnimator?.cancel()
        valueAnimator = null
        entranceAnimator?.cancel()
        entranceAnimator = null
    }

    /**
     * The outline of the filled portion.
     *
     * A plain rectangle unless the style says otherwise. The wave styles replace its top edge with
     * a surface; the block styles cut the whole thing into a stack. Everything downstream — the
     * fill itself, the effects, the clip that inverts the content colour — uses this one path, so
     * a style cannot end up with its fill and its ink disagreeing about where the fill is.
     */
    private fun buildFillPath(fillTop: Float) {
        fillShapePath.reset()
        val l = drawRect.left
        val r = drawRect.right
        val b = drawRect.bottom

        when {
            SliderFill.hasWave(fillStyle) && fillTop > drawRect.top -> {
                val amp = SliderFill.WAVE_AMPLITUDE_DP * density
                fillShapePath.moveTo(l, b)
                fillShapePath.lineTo(l, fillTop)
                var x = l
                while (x <= r) {
                    val at = (x - l) / (r - l).coerceAtLeast(1f)
                    fillShapePath.lineTo(x, fillTop - SliderFill.waveAt(fillStyle, fillPhase, at) * amp)
                    x += WAVE_STEP_PX
                }
                fillShapePath.lineTo(r, fillTop - SliderFill.waveAt(fillStyle, fillPhase, 1f) * amp)
                fillShapePath.lineTo(r, b)
                fillShapePath.close()
            }

            else -> fillShapePath.addRect(l, fillTop, r, b, Path.Direction.CW)
        }

        // Cut to the panel's own outline rather than left to a clip to do it. Same reason as the
        // surface: a clipped edge is a stepped edge, and on a tab the fill's edge *is* the tab's.
        fillShapePath.op(drawPath, Path.Op.INTERSECT)
    }

    /** The part of a style that is drawn *over* the fill rather than being its shape. */
    private fun drawFillEffects(canvas: Canvas, fillTop: Float, alpha: Int) {
        if (fillStyle == SliderFill.SOLID) return
        // Unclipped here: the caller has already clipped the canvas to the fill.
        if (SliderFill.isPictorial(fillStyle)) {
            drawPictorialFill(canvas, fillTop, alpha)
        } else {
            drawTintedFill(canvas, fillTop, alpha)
        }
    }

    /**
     * The styles that tint the fill rather than painting over it.
     *
     * Drawn in the *track's* colour, not in white. White was the obvious choice and it was wrong:
     * the fill's own default is white, so a white charging band on it was invisible. The track
     * colour is the one colour in this view guaranteed to contrast with the fill — it is already
     * what the number and the icon are drawn in over the filled half, for the same reason.
     */
    private fun drawTintedFill(canvas: Canvas, fillTop: Float, alpha: Int) {
        if (fillStyle != SliderFill.STRIPES) return
        fillArt.drawStripes(canvas, drawRect, fillTop, fillPhase, blendedTrackColor or (0xFF shl 24), alpha)
    }

    /**
     * The styles that paint their own picture on the fill.
     *
     * Most are painted by [FillArt], ground and all. The three left here are the ones that already
     * looked right, kept exactly as they were: they carry a palette rather than borrowing the
     * track's colour, laid over a darkened fill so their own light has something to be light
     * against — a neon line on a white bar is a grey line.
     */
    private fun drawPictorialFill(canvas: Canvas, fillTop: Float, alpha: Int) {
        if (FillArt.handles(fillStyle)) {
            fillArt.draw(canvas, fillStyle, fillPalette, drawRect, fillTop, fillPhase, value, alpha)
            return
        }
        val palette = fillPalette
        val height = (drawRect.bottom - fillTop).coerceAtLeast(1f)
        val width = drawRect.width().coerceAtLeast(1f)

        // The ground. Without it every one of these is washed out by whatever colour the fill is.
        // Not under the styles that paint an opaque ground of their own over the whole fill: there
        // it was a full pass of the GPU over the panel that nothing could see.
        effectPaint.shader = null
        if (fillStyle !in OPAQUE_PICTORIAL) {
            effectPaint.color = Color.BLACK
            effectPaint.alpha = (0.82f * alpha).toInt().coerceIn(0, 255)
            canvas.drawRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom, effectPaint)
        }

        when (fillStyle) {
            SliderFill.NEBULA -> {
                // Four soft clouds on their own slow orbits. Radial gradients rather than circles:
                // a cloud with an edge is a balloon.
                for (i in palette.indices) {
                    val seed = SliderFill.pseudoRandom(i * 17 + 3)
                    // Whole turns per cycle, so a cloud is exactly where it started when the cycle
                    // wraps. A fractional speed made every cloud jump once a cycle.
                    val drift = fillPhase * 2f * Math.PI.toFloat() * (1f + (seed * 2f).toInt()) +
                        seed * 6.28f
                    val cx = drawRect.left + width * (0.5f + 0.42f * kotlin.math.cos(drift))
                    val cy = fillTop + logicalHeight * (0.5f + 0.42f * kotlin.math.sin(drift * 2f + 1.1f))
                    val radius = logicalWidth * (1.1f + seed * 0.6f)
                    effectPaint.shader = android.graphics.RadialGradient(
                        cx, cy, radius,
                        intArrayOf(palette[i].toInt(), palette[i].toInt() and 0x00FFFFFF),
                        null,
                        android.graphics.Shader.TileMode.CLAMP,
                    )
                    effectPaint.alpha = alpha
                    canvas.drawRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom, effectPaint)
                }
                effectPaint.shader = null
            }

            SliderFill.EMBER -> {
                // Sparks, each on its own seeded path, fading as it climbs. Deterministic, so the
                // same panel opened twice shows the same fire continuing rather than restarting.
                effectPaint.shader = null
                for (i in 0 until EMBER_COUNT) {
                    val seed = SliderFill.pseudoRandom(i * 97 + 5)
                    val seed2 = SliderFill.pseudoRandom(i * 131 + 17)
                    val life = ((fillPhase * (1f + (seed * 2f).toInt()) + seed2) % 1f)
                    val y = drawRect.bottom - height * life
                    if (y < fillTop) continue
                    val sway = kotlin.math.sin(life * 9f + seed * 6.28f) * logicalWidth * 0.16f
                    val x = drawRect.left + width * (0.2f + seed * 0.6f) + sway
                    // Faded in as well as out. A spark that appeared at full strength at the bottom
                    // was a pop every time one was born.
                    val fade = kotlin.math.sin(life * 3.14159f).coerceIn(0f, 1f)
                    val idx = (life * (palette.size - 1)).toInt().coerceIn(0, palette.size - 1)
                    effectPaint.color = palette[idx].toInt()
                    effectPaint.alpha = (fade * fade * alpha).toInt().coerceIn(0, 255)
                    canvas.drawCircle(x, y, (1.1f + seed2 * 1.6f) * density, effectPaint)
                }
            }

            SliderFill.GALAXY -> {
                // Deep space with stars at three depths drifting upward, the near ones faster and
                // brighter. Parallax is what turns dots into distance.
                effectPaint.shader = android.graphics.LinearGradient(
                    0f, drawRect.bottom, 0f, fillTop,
                    intArrayOf(palette[0].toInt(), palette[1].toInt()), null,
                    android.graphics.Shader.TileMode.CLAMP,
                )
                effectPaint.alpha = alpha
                canvas.drawRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom, effectPaint)
                // A faint band of dust through the middle, so the stars are *in* something.
                effectPaint.shader = android.graphics.RadialGradient(
                    drawRect.centerX(), (fillTop + drawRect.bottom) / 2f, width * 1.2f,
                    intArrayOf(0x40A98BFF, 0x00A98BFF), null,
                    android.graphics.Shader.TileMode.CLAMP,
                )
                canvas.drawRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom, effectPaint)
                effectPaint.shader = null
                val track = drawRect.height().coerceAtLeast(1f)
                for (layer in 0 until 3) {
                    // Whole-number speeds — one, two and three passes a cycle — so the sky is
                    // exactly where it started when the cycle wraps.
                    val speed = (layer + 1).toFloat()
                    for (i in 0 until STARS_PER_LAYER) {
                        val seed = SliderFill.pseudoRandom(layer * 997 + i * 37 + 1)
                        val seed2 = SliderFill.pseudoRandom(layer * 571 + i * 53 + 9)
                        val pos = (seed2 + fillPhase * speed) % 1f
                        val y = drawRect.bottom - pos * track
                        if (y < fillTop) continue
                        val x = drawRect.left + width * (0.06f + seed * 0.88f)
                        val twinkle = 0.55f + 0.45f * kotlin.math.sin(
                            fillPhase * 6.28318f * (1f + (seed * 3f).toInt()) + seed * 10f
                        )
                        // Faded at both ends of its pass, so a star never blinks into place.
                        val envelope = kotlin.math.sin(pos * 3.14159f).coerceIn(0f, 1f)
                        effectPaint.color = if (seed > 0.8f) palette[3].toInt() else palette[2].toInt()
                        effectPaint.alpha = (twinkle * envelope * (0.45f + layer * 0.27f) * alpha)
                            .toInt().coerceIn(0, 255)
                        canvas.drawCircle(x, y, (0.55f + layer * 0.45f) * density, effectPaint)
                    }
                }
            }
        }
        effectPaint.shader = null
        effectPaint.style = Paint.Style.FILL
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Ahead of the interactive gate, and deliberately. A panel still growing is exactly the
        // one a user is most likely to dismiss by tapping past it, and refusing to notice would
        // leave it on screen until its idle timeout.
        if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onTouchOutside?.invoke()
            return true
        }
        // A touch in the room left around the panel for its entrance is a touch beside the panel,
        // and does what a tap outside it does.
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            val slack = ICON_TOUCH_SLACK_DP * density
            touchInRoom = !drawRect.isEmpty && (
                event.x < drawRect.left - slack || event.x > drawRect.right + slack ||
                    event.y < drawRect.top - slack || event.y > drawRect.bottom + slack
                )
            if (touchInRoom) {
                onTouchOutside?.invoke()
                return true
            }
        }
        if (touchInRoom) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                touchInRoom = false
            }
            return true
        }
        if (!interactive) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // On the icon nothing is picked yet: a lift makes it the icon's tap, and travel
                // makes it the track's drag after all. Picking on the way down would set the level
                // to wherever the icon is drawn before either was known.
                if (iconTapEnabled && isOnIcon(event.y)) {
                    iconPressed = true
                    iconDownY = event.y
                    invalidate()
                } else {
                    pickAt(event.y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (iconPressed) {
                    if (kotlin.math.abs(event.y - iconDownY) <= touchSlop) return true
                    iconPressed = false
                }
                pickAt(event.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (iconPressed) {
                    iconPressed = false
                    invalidate()
                    if (event.actionMasked == MotionEvent.ACTION_UP) listener?.onIconTapped()
                    return true
                }
                grabbed = false
                invalidate()
                listener?.onAdjustFinished()
            }
        }
        return true
    }

    /** The finger is on the track at [y], and that is the value. */
    private fun pickAt(y: Float) {
        grabbed = true
        // Measured against the drawn rect rather than the view, because the two are only the same
        // once the panel is fully open — and a touch landing during the last few frames of the
        // animation must still mean what it looks like it means.
        val h = drawRect.height()
        if (h <= 0f) return
        val fraction = (1f - (y - drawRect.top) / h).coerceIn(0f, 1f)
        listener?.onValuePicked(fraction)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyExpandedRect()
        // Sized from the *drawn* panel rather than the window, so a panel deliberately made
        // narrower than the bar gets a number that fits it. Still not from the rect being drawn,
        // because text that scales during the morph reads as a zoom rather than as a reveal.
        textPaint.textSize = (expandedRect.width() * 0.34f).coerceIn(9f * density, 20f * density)
        // A collapsed rect the caller has not set yet would leave the first frame at the window's
        // full size, which is the pop this class exists to remove.
        if (collapsedRect.isEmpty) collapsedRect.set(expandedRect)
        rebuildPath()
    }

    private fun applyExpandedRect() {
        val w = logicalWidth.toFloat()
        val h = logicalHeight.toFloat()
        if (w <= 0f || h <= 0f) return
        // The room around the panel comes off the window first; the panel is what is left, pressed
        // against the screen edge as it always has been.
        val across = (w - roomInward).coerceAtLeast(1f)
        val top = roomTop.toFloat().coerceAtMost(h - 1f)
        val bottom = (h - roomBottom).coerceAtLeast(top + 1f)
        val drawn = if (drawnThicknessPx <= 0f) across else drawnThicknessPx.coerceAtMost(across)
        if (drawnOnLeft) {
            expandedRect.set(0f, top, drawn, bottom)
        } else {
            expandedRect.set(w - drawn, top, w, bottom)
        }
    }

    private fun rebuildPath() {
        if (expandedRect.isEmpty) return

        drawRect.set(
            lerp(collapsedRect.left, expandedRect.left),
            lerp(collapsedRect.top, expandedRect.top),
            lerp(collapsedRect.right, expandedRect.right),
            lerp(collapsedRect.bottom, expandedRect.bottom)
        )

        drawPath.reset()
        rimPath.reset()
        fillPathDirty = true
        if (drawRect.isEmpty) {
            rebuildGlass()
            reportGlass()
            return
        }

        // A tab at either end means a tab: the outline has no corners to travel, only a sweep, and
        // the sweep's length is what interpolates.
        val tab = expandedShape == HandlerShape.TAB ||
            (collapsedShape == HandlerShape.TAB && expansion < 0.5f)
        drawnIsTab = tab

        if (tab) {
            val flare = when {
                expandedShape == collapsedShape -> lerp(collapsedFlare, expandedFlare)
                expandedShape == HandlerShape.TAB -> expandedFlare
                else -> collapsedFlare
            }
            drawnFlare = flare
            val outline = HandlerShape.tabOutline(drawRect.width(), drawRect.height(), flare, edgeOnLeft)
            val l = drawRect.left
            val t = drawRect.top
            drawPath.moveTo(l + outline[0], t + outline[1])
            var i = 2
            while (i < outline.size) {
                drawPath.lineTo(l + outline[i], t + outline[i + 1])
                i += 2
            }
            rimPath.set(drawPath)
            drawPath.close()
        } else {
            // Never more than half the shorter side, or the corners overlap and the round-rect
            // degenerates into a shape the caller did not ask for. Clamped against the rect being
            // drawn rather than the window, because the collapsed rect is the smaller of the two
            // and is where the clamp actually bites.
            val limit = minOf(drawRect.width(), drawRect.height()) / 2f
            // Each corner travels from its own starting radius to its own finishing one, so a bar
            // that is square on one side rounds off as it grows rather than snapping round on
            // frame one. `addRoundRect` takes them as x/y pairs, clockwise from the top left.
            for (corner in 0..3) {
                val r = lerp(collapsedCornersPx[corner], expandedCornersPx[corner]).coerceIn(0f, limit)
                drawRadii[corner * 2] = r
                drawRadii[corner * 2 + 1] = r
            }
            drawPath.addRoundRect(drawRect, drawRadii, Path.Direction.CW)
            rimPath.set(drawPath)
        }
        rebuildGlass()
        reportGlass()
    }

    private fun lerp(from: Float, to: Float): Float = from + (to - from) * expansion

    override fun onDraw(canvas: Canvas) {
        if (!firstFrameDrawn) {
            firstFrameDrawn = true
            onFirstFrame?.let { callback ->
                onFirstFrame = null
                callback()
            }
        }
        if (drawRect.isEmpty) return

        /*
         * The surface is *drawn* as a path, not a rectangle inside a clip.
         *
         * It used to be the second, and a clip is not antialiased. On a rounded rectangle that
         * shows as a slightly hard corner and nobody notices; on a tab, whose sides are one long
         * sweep, it shows as stair-steps down the whole edge. Everything that has to stay inside
         * the shape is still clipped — but the shape's own outline, the part the eye follows, is
         * now a path with antialiasing on.
         */
        canvas.drawPath(drawPath, trackPaint)

        canvas.save()
        canvas.clipPath(drawPath)

        // Under the contents: lighting on the surface, not over the number.
        sheenPaint?.let { canvas.drawRect(drawRect, it) }
        counterLightPaint?.let { canvas.drawRect(drawRect, it) }

        if (fillStyle == SliderFill.PIXELS || fillStyle == SliderFill.EFFORT || fillStyle == SliderFill.GLIMMER ||
            (fillStyle == SliderFill.SHADER && drawShaderFill(canvas)) ||
            (fillStyle == SliderFill.SURGE && drawSurgeFill(canvas))
        ) {
            if (fillStyle == SliderFill.PIXELS) drawPixelFill(canvas)
            if (fillStyle == SliderFill.EFFORT) drawEffortFill(canvas)
            if (fillStyle == SliderFill.GLIMMER) drawGlimmerFill(canvas)
            canvas.restore()
            drawFeedbackPanel(canvas)
            // The glimmer's handle is its own grab cue: it glows while held, where a lip would be
            // a line drawn across the middle of it.
            if (fillStyle != SliderFill.GLIMMER || !glimmerStyle.handle) drawGrabLip(canvas)
            edgePaint?.let { canvas.drawPath(rimPath, it) }
            return
        }

        drawContent(canvas, overFill = false)
        canvas.restore()

        if (fillVisible && contentAlpha > 0.01f) {
            val fillTop = drawRect.bottom - drawRect.height() * value
            if (fillPathDirty || fillTop != builtFillTop ||
                (SliderFill.hasWave(fillStyle) && fillPhase != builtFillPhase)
            ) {
                buildFillPath(fillTop)
                builtFillTop = fillTop
                builtFillPhase = fillPhase
                fillPathDirty = false
            }

            val alpha = (contentAlpha * 255f).toInt().coerceIn(0, 255)
            fillPaint.alpha = alpha
            canvas.drawPath(fillShapePath, fillPaint)

            /*
             * Whatever the style adds on top of a plain fill, and the contents again in the
             * inverted colour, all clipped to the fill, so none of it strays onto the empty half of
             * the track. The fill's own edge is already drawn antialiased underneath, so the clip
             * lands colour-on-colour rather than colour-on-wallpaper.
             *
             * A clip rather than a layer cut to shape, measured both ways on a phone: the layer
             * was never cheaper and was slower with spikes past 16ms once the glass was off, the
             * cost of a second render pass on a mobile GPU. The cost that matters with the glass on
             * is the system blurring behind the panel on every frame anything animates, which is
             * the compositor's and the same either way.
             */
            canvas.save()
            canvas.clipPath(fillShapePath)
            drawFillEffects(canvas, fillTop, alpha)
            drawFeedbackLit(canvas, fillTop, clip = false)
            drawContent(canvas, overFill = true)
            canvas.restore()

            drawGrabLip(canvas)
            fillPaint.alpha = 255
        }
        drawFeedbackPanel(canvas)

        // The rim last and outside the fill pass, so the filled half of the track does not paint
        // over the edge.
        edgePaint?.let { canvas.drawPath(rimPath, it) }
    }

    /**
     * A bright lip on the fill's leading edge while a finger is on it. The panel has no thumb — the
     * fill line *is* the value — so without this there is nothing to confirm that the touch was
     * received, and on a control the user only touches for a moment that confirmation is most of
     * the feedback there is.
     */
    private fun drawGrabLip(canvas: Canvas) {
        if (!grabbed || !fillVisible || contentAlpha <= 0.01f) return
        val fillTop = drawRect.bottom - drawRect.height() * value
        canvas.save()
        canvas.clipPath(drawPath)
        fillPaint.alpha = 255
        canvas.drawRect(
            drawRect.left,
            fillTop - GRAB_LIP_DP * density / 2f,
            drawRect.right,
            fillTop + GRAB_LIP_DP * density / 2f,
            fillPaint
        )
        canvas.restore()
    }

    /**
     * The Pixels fill, inside the panel's clip: the grid over the whole track, lit below the level,
     * and the number and the icon over it — in the fill colour where the grid is resting and in the
     * track's where it is lit, as over any other fill.
     *
     * The grid takes the place of the filled shape rather than being drawn on it: the pixels above
     * the level are part of the picture, so it cannot be cut to the fill the way the others are.
     */
    private fun drawPixelFill(canvas: Canvas) {
        if (!fillVisible || contentAlpha <= 0.01f) {
            drawContent(canvas, overFill = false)
            return
        }
        val fillTop = drawRect.bottom - drawRect.height() * value
        pixelArt.draw(canvas, drawRect, fillTop, fillPhase, pixelStyle, fillColor, fillColors, contentAlpha)
        drawFeedbackLit(canvas, fillTop, clip = true)

        canvas.save()
        canvas.clipRect(drawRect.left, drawRect.top, drawRect.right, fillTop)
        drawContent(canvas, overFill = false)
        canvas.restore()
        canvas.save()
        canvas.clipRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom)
        drawContent(canvas, overFill = true)
        canvas.restore()
    }

    /**
     * The Shaders fill, inside the panel's clip: the effect over the whole track, lit below the
     * level and faint above it, with the number and the icon over it as over the Pixels grid.
     *
     * Returns false, having drawn nothing, where the effect cannot be drawn — before Android 13, or
     * on a phone that would not compile it — and the panel is then drawn with a plain fill.
     */
    private fun drawShaderFill(canvas: Canvas): Boolean {
        if (Build.VERSION.SDK_INT < ShaderFill.MIN_SDK) return false
        if (!fillVisible || contentAlpha <= 0.01f) {
            drawContent(canvas, overFill = false)
            return true
        }
        val fillTop = drawRect.bottom - drawRect.height() * value
        val art = shaderArt ?: ShaderArt().also { shaderArt = it }
        if (!art.draw(canvas, drawRect, fillTop, shaderTime, shaderStyle, shaderPalette, contentAlpha)) return false
        drawOverProgramFill(canvas, fillTop)
        return true
    }

    /**
     * The Surge fill, inside the panel's clip: the look's front climbing to the level, the light
     * behind it and a halo past it, with the number and the icon over it as over the shader.
     *
     * Returns false, having drawn nothing, where it cannot be drawn, as [drawShaderFill] does.
     */
    private fun drawSurgeFill(canvas: Canvas): Boolean {
        if (Build.VERSION.SDK_INT < SurgeFill.MIN_SDK) return false
        if (!fillVisible || contentAlpha <= 0.01f) {
            drawContent(canvas, overFill = false)
            return true
        }
        val fillTop = drawRect.bottom - drawRect.height() * value
        val art = surgeArt ?: SurgeArt().also { surgeArt = it }
        if (!art.draw(canvas, drawRect, fillTop, surgeTime, surgeStyle, surgePalette, contentAlpha)) return false
        drawOverProgramFill(canvas, fillTop)
        return true
    }

    /**
     * What goes over a fill a program on the graphics chip drew: the feedback on its lit part, and
     * the number and the icon, in the track's ink above [fillTop] and the fill's below it.
     */
    private fun drawOverProgramFill(canvas: Canvas, fillTop: Float) {
        drawFeedbackLit(canvas, fillTop, clip = true)

        canvas.save()
        canvas.clipRect(drawRect.left, drawRect.top, drawRect.right, fillTop)
        drawContent(canvas, overFill = false)
        canvas.restore()
        canvas.save()
        canvas.clipRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom)
        drawContent(canvas, overFill = true)
        canvas.restore()
    }

    /**
     * The Effort fill, inside the panel's clip: the picker over the whole track, lit below the
     * level, and the number and the icon over it in the fill colour above the level and in the
     * picker's own ink below it. The level's name is kept clear of both.
     */
    private fun drawEffortFill(canvas: Canvas) {
        if (!fillVisible || contentAlpha <= 0.01f) {
            drawContent(canvas, overFill = false)
            return
        }
        val fillTop = drawRect.bottom - drawRect.height() * value
        // Where the number ends and the icon begins, give or take, for the name to keep between.
        val numberBottom = if (showValue) {
            drawRect.top + valueMarginPx + if (turned) textPaint.measureText("100") else textPaint.textSize
        } else {
            drawRect.top
        }
        val iconTop = if (icon != null) iconCenterY(iconSize()) - iconSize() / 2f else drawRect.bottom
        effortArt.draw(
            canvas, drawRect, fillTop, value, effortTime, effortStyle, effortPalette, effortLabels, effortShortLabels,
            labelTop = numberBottom + 4f * density,
            labelBottom = iconTop - 4f * density,
            ghost = fillColor,
            alpha = contentAlpha,
        )

        canvas.save()
        canvas.clipRect(drawRect.left, drawRect.top, drawRect.right, fillTop)
        drawContent(canvas, overFill = false)
        canvas.restore()
        canvas.save()
        canvas.clipRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom)
        drawContent(canvas, overFill = true)
        canvas.restore()
    }

    /**
     * The Glimmer fill, inside the panel's clip: the dots over the whole track, lit up to the level,
     * and the number and the icon over them — in the fill colour over the dots, which are dark
     * wherever they are, and in the track's through the handle, which is painted in the fill colour.
     * The stops keep clear of both.
     */
    private fun drawGlimmerFill(canvas: Canvas) {
        if (!fillVisible || contentAlpha <= 0.01f) {
            drawContent(canvas, overFill = false)
            return
        }
        glimmerKeepOut.fill(Float.NaN)
        if (showValue) {
            glimmerKeepOut[0] = drawRect.top + valueMarginPx
            glimmerKeepOut[1] = glimmerKeepOut[0] + if (turned) textPaint.measureText("100") else textPaint.textSize
        }
        if (icon != null) {
            val size = iconSize()
            glimmerKeepOut[2] = iconCenterY(size) - size / 2f
            glimmerKeepOut[3] = glimmerKeepOut[2] + size
        }
        val art = glimmerArt
        art.draw(
            canvas, drawRect, value, glimmerTime, glimmerStyle, glimmerPalette,
            light = fillColor,
            // The panel's roundest corner, as the slider's handle has its track's. A tab's ends are
            // sweeps rather than corners, so on a tab the handle is a pill.
            corner = if (drawnIsTab) drawRect.width() / 2f else maxOf(drawRadii[0], drawRadii[2], drawRadii[4], drawRadii[6]),
            grabbed = grabbed,
            keepOut = glimmerKeepOut,
            alpha = contentAlpha,
        )
        drawFeedbackLit(canvas, drawRect.bottom - drawRect.height() * value, clip = true)
        if (art.handle.isEmpty) {
            drawContent(canvas, overFill = false)
            return
        }
        canvas.save()
        canvas.clipOutPath(art.handlePath)
        drawContent(canvas, overFill = false)
        canvas.restore()
        canvas.save()
        canvas.clipPath(art.handlePath)
        drawContent(canvas, overFill = true)
        canvas.restore()
    }

    /**
     * The feedback over the lit part, under the number and the icon: see [LevelFeedbackArt.drawLit].
     * [clip] for the fills drawn over the whole track, whose lit part the canvas is not cut to.
     */
    private fun drawFeedbackLit(canvas: Canvas, fillTop: Float, clip: Boolean) {
        if (!feedbackOn || contentAlpha <= 0.01f) return
        if (clip) {
            canvas.save()
            canvas.clipRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom)
        }
        feedbackArt.drawLit(
            canvas, drawRect, fillTop, value, feedback, feedbackTime,
            stepS = secondsSince(stepAt),
            fullS = fullSeconds(),
            ink = feedbackInk(),
            // A band across dots or a grid would paint the gaps between them as well.
            sheen = fillStyle != SliderFill.PIXELS && fillStyle != SliderFill.GLIMMER,
            alpha = contentAlpha,
        )
        if (clip) canvas.restore()
    }

    /** The feedback over the whole panel, over everything but its rim: see [LevelFeedbackArt.drawPanel]. */
    private fun drawFeedbackPanel(canvas: Canvas) {
        if (!feedbackOn || !fillVisible || contentAlpha <= 0.01f) return
        canvas.save()
        canvas.clipPath(drawPath)
        feedbackArt.drawPanel(
            canvas, drawPath, drawRect,
            fillTop = drawRect.bottom - drawRect.height() * value,
            value = value,
            style = feedback,
            timeS = feedbackTime,
            fullS = fullSeconds(),
            // On the track, where the low glow mostly is: the fill colour, unless it would vanish.
            glow = ContentInk.pick(blendedTrackColor, fillColor),
            // At the top, where the flourishes are, the panel is all fill.
            ink = feedbackInk(),
            alpha = contentAlpha,
        )
        canvas.restore()
    }

    private fun secondsSince(at: Long): Float = if (at == 0L) -1f else (SystemClock.uptimeMillis() - at) / 1000f

    /** The light the feedback paints the lit part in: white over a dark fill, near black over a pale one. */
    private fun feedbackInk(): Int {
        // The glimmer's dots are dark wherever they are; its fill colour is only the handle's.
        if (fillStyle == SliderFill.GLIMMER) return Color.WHITE
        return if (ContentInk.luminance(fillBackdrop(LIT_BACKDROP)) > 0.6) FEEDBACK_DARK_INK else Color.WHITE
    }

    /** The icon's size and centre, shared by the drawing and the touch test so the two agree. */
    private fun iconSize(): Float = (drawRect.width() * 0.46f).coerceIn(12f * density, 26f * density)

    private fun iconCenterY(size: Float): Float = drawRect.bottom - iconMarginPx - size / 2f

    /** Whether a touch at [y] is on the icon, give or take a fingertip. */
    private fun isOnIcon(y: Float): Boolean {
        if (icon == null) return false
        val size = iconSize()
        val reach = size / 2f + ICON_TOUCH_SLACK_DP * density
        val cy = iconCenterY(size)
        return y >= cy - reach && y <= cy + reach
    }

    /**
     * What the fill looks like under the number and under the icon, for [ContentInk] to pick their
     * colour against: the fill colour for the fills drawn in it, and for the ones that paint a
     * picture, the average of that picture where each of them sits. See [refreshBackdrops].
     */
    private fun fillBackdrop(which: Int): Int = when {
        fillStyle == SliderFill.GLIMMER -> fillColor
        fillStyle == SliderFill.SHADER -> averageOf(shaderPalette)
        fillStyle == SliderFill.SURGE -> surgeBody()
        fillStyle == SliderFill.PIXELS || SliderFill.isPictorial(fillStyle) -> {
            refreshBackdrops()
            backdrops[which]
        }
        else -> fillColor
    }

    /**
     * What most of the Surge fill is, for the ink over it: its dark, lit a little by the deep light.
     * The bright colours are the front's alone, and only for the moment it passes under the number
     * or the icon; averaged in with the rest, they made the ink dark over a body that is dark.
     */
    private fun surgeBody(): Int {
        val dark = surgePalette[0]
        val deep = surgePalette.getOrElse(1) { dark }
        fun mix(shift: Int) = (((dark shr shift) and 0xFF) * 0.65f + ((deep shr shift) and 0xFF) * 0.35f).toInt()
        return Color.rgb(mix(16), mix(8), mix(0))
    }

    /**
     * A program's colours, averaged, for the ink over the Shaders fill: it is drawn on the GPU,
     * where the picture cannot be read back.
     */
    private fun averageOf(palette: IntArray): Int {
        var r = 0
        var g = 0
        var b = 0
        for (c in palette) {
            r += (c shr 16) and 0xFF
            g += (c shr 8) and 0xFF
            b += c and 0xFF
        }
        val n = palette.size.coerceAtLeast(1)
        return Color.rgb(r / n, g / n, b / n)
    }

    /** Under the number, under the icon, and over the whole lit part, for the feedback. */
    private val backdrops = intArrayOf(Color.WHITE, Color.WHITE, Color.WHITE)
    private var backdropKey = 0
    private var backdropBitmap: Bitmap? = null
    private val backdropPaint = Paint()
    private val backdropRegion = RectF()

    /**
     * Paints the fill into a small image off screen and averages it where the number and the icon
     * sit, at a few moments of its animation, so the ink suits the picture as a whole rather than
     * one frame of it.
     *
     * At the level, to the nearest twentieth: most pictures are drawn to the fill, not the panel, so
     * what is under the icon moves as the level does — half full, a sunrise's sun is right behind
     * it. Only again when that step or anything else that changes the picture changes — the style,
     * its colours, the panel's size — so a drag redraws it a few times, and a frame never does.
     */
    private fun refreshBackdrops() {
        val w = logicalWidth
        val h = logicalHeight
        if (w <= 0 || h <= 0 || drawRect.isEmpty) return
        val level = (value * BACKDROP_LEVELS).roundToInt() / BACKDROP_LEVELS.toFloat()
        val key = arrayOf<Any?>(
            level, fillStyle, fillPalette.contentHashCode(), fillColor, trackColor, fillColors?.contentHashCode(), pixelStyle,
            w, h, drawRect.left, drawRect.top, drawRect.right, drawRect.bottom,
            turned, showValue, icon != null, valueMarginPx, iconMarginPx, textPaint.textSize,
        ).contentHashCode()
        if (key == backdropKey) return
        backdropKey = key

        val bw = ceil(w * BACKDROP_SCALE).toInt().coerceAtLeast(1)
        val bh = ceil(h * BACKDROP_SCALE).toInt().coerceAtLeast(1)
        val bitmap = backdropBitmap?.takeIf { it.width == bw && it.height == bh }
            ?: Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888).also {
                backdropBitmap?.recycle()
                backdropBitmap = it
            }
        val canvas = Canvas(bitmap)
        val sums = LongArray(4 * backdrops.size)
        val pixels = IntArray(bw * bh)
        val phase = fillPhase
        val fillTop = drawRect.bottom - drawRect.height() * level
        for (moment in BACKDROP_PHASES) {
            bitmap.eraseColor(Color.TRANSPARENT)
            canvas.save()
            canvas.scale(BACKDROP_SCALE, BACKDROP_SCALE)
            canvas.clipPath(drawPath)
            // The track under it, opaque: what shows through a picture's gaps.
            backdropPaint.color = blendedTrackColor or OPAQUE
            canvas.drawRect(drawRect, backdropPaint)
            fillPhase = moment
            if (fillStyle == SliderFill.PIXELS) {
                pixelArt.draw(canvas, drawRect, fillTop, moment, pixelStyle, fillColor, fillColors, 1f)
            } else {
                backdropPaint.color = fillColor or OPAQUE
                canvas.clipRect(drawRect.left, fillTop, drawRect.right, drawRect.bottom)
                canvas.drawRect(drawRect, backdropPaint)
                drawFillEffects(canvas, fillTop, 255)
            }
            canvas.restore()
            bitmap.getPixels(pixels, 0, bw, 0, 0, bw, bh)
            for (which in backdrops.indices) {
                if (!contentRegion(which, backdropRegion)) continue
                // Only the part of it the fill is under: that is the part drawn in this ink.
                backdropRegion.top = maxOf(backdropRegion.top, fillTop)
                if (backdropRegion.top >= backdropRegion.bottom) continue
                val left = (backdropRegion.left * BACKDROP_SCALE).toInt().coerceIn(0, bw - 1)
                val right = ceil(backdropRegion.right * BACKDROP_SCALE).toInt().coerceIn(left + 1, bw)
                val top = (backdropRegion.top * BACKDROP_SCALE).toInt().coerceIn(0, bh - 1)
                val bottom = ceil(backdropRegion.bottom * BACKDROP_SCALE).toInt().coerceIn(top + 1, bh)
                for (y in top until bottom) for (x in left until right) {
                    val c = pixels[y * bw + x]
                    sums[which * 4] += ((c shr 16) and 0xFF).toLong()
                    sums[which * 4 + 1] += ((c shr 8) and 0xFF).toLong()
                    sums[which * 4 + 2] += (c and 0xFF).toLong()
                    sums[which * 4 + 3]++
                }
            }
        }
        fillPhase = phase
        for (which in backdrops.indices) {
            val n = sums[which * 4 + 3]
            backdrops[which] = if (n == 0L) {
                fillColor
            } else {
                Color.rgb(
                    (sums[which * 4] / n).toInt(),
                    (sums[which * 4 + 1] / n).toInt(),
                    (sums[which * 4 + 2] / n).toInt(),
                )
            }
        }
    }

    /**
     * Where the number (0) or the icon (1) is drawn, into [out]; false when it is not shown. Or,
     * for [LIT_BACKDROP], the whole panel, of which the caller keeps the lit part.
     */
    private fun contentRegion(which: Int, out: RectF): Boolean {
        val cx = drawRect.centerX()
        if (which == LIT_BACKDROP) {
            out.set(drawRect)
        } else if (which == 0) {
            if (!showValue) return false
            val across = textPaint.measureText("88")
            val along = textPaint.textSize
            // Lying down, the number is turned about its centre, so it is as tall as it is long.
            val halfWidth = if (turned) along / 2f else across / 2f
            val tall = if (turned) across else along
            out.set(cx - halfWidth, drawRect.top + valueMarginPx, cx + halfWidth, drawRect.top + valueMarginPx + tall)
        } else {
            if (icon == null) return false
            val size = iconSize()
            val cy = iconCenterY(size)
            out.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f)
        }
        return true
    }

    private fun drawContent(canvas: Canvas, overFill: Boolean) {
        if (contentAlpha <= 0.01f) return
        // Unless the user has chosen them, the number and the icon take a colour that stands out
        // from what is under them: the track, the fill, or the fill's picture. See ContentInk.
        // Over the picker's lit stops, whose colour changes with the level, the picker's own ink.
        val ink = when {
            !overFill -> ContentInk.pick(blendedTrackColor, fillColor)
            fillStyle == SliderFill.EFFORT -> effortArt.ink
            else -> null
        }
        val alpha = (contentAlpha * 255f).toInt().coerceIn(0, 255)

        if (showValue) {
            textPaint.color = valueInk ?: ink ?: ContentInk.pick(fillBackdrop(0), blendedTrackColor)
            textPaint.alpha = alpha
            val label = "${(value * 100f).toInt()}"
            // Baseline placed by the font's own metrics rather than a guessed offset, so the
            // number sits the same distance from the top on every device font scale.
            // From the panel's top edge and nothing else — see QuickSliderStore.getValueMarginDp.
            if (turned) {
                // Lying down, the number is turned back upright about its own centre, which sits
                // the same distance in from the panel's end.
                val metrics = textPaint.fontMetrics
                val cy = drawRect.top + valueMarginPx + textPaint.measureText(label) / 2f
                canvas.save()
                canvas.rotate(-90f, drawRect.centerX(), cy)
                canvas.drawText(label, drawRect.centerX(), cy - (metrics.ascent + metrics.descent) / 2f, textPaint)
                canvas.restore()
            } else {
                val y = drawRect.top + valueMarginPx - textPaint.fontMetrics.ascent
                canvas.drawText(label, drawRect.centerX(), y, textPaint)
            }
        }

        icon?.let { drawable ->
            val size = iconSize()
            val cx = drawRect.centerX()
            val cy = iconCenterY(size)
            // Pressed, a soft disc behind the glyph in the same ink, so the tap is seen to land.
            val iconColor = iconInk ?: ink ?: ContentInk.pick(fillBackdrop(1), blendedTrackColor)
            if (iconPressed) {
                iconPressPaint.color = iconColor
                iconPressPaint.alpha = (alpha * 0.22f).toInt()
                canvas.drawCircle(cx, cy, size * 0.85f, iconPressPaint)
            }
            val wrapped = DrawableCompat.wrap(drawable)
            DrawableCompat.setTint(wrapped, iconColor)
            wrapped.alpha = alpha
            wrapped.setBounds(
                (cx - size / 2f).toInt(),
                (cy - size / 2f).toInt(),
                (cx + size / 2f).toInt(),
                (cy + size / 2f).toInt()
            )
            if (turned) {
                canvas.save()
                canvas.rotate(-90f, cx, cy)
                wrapped.draw(canvas)
                canvas.restore()
            } else {
                wrapped.draw(canvas)
            }
        }
    }
}

/**
 * How long the fill takes to travel to a value nobody's finger is on.
 *
 * Short. This is a confirmation that something moved, not a journey; anything longer and a second
 * press of a nudge button arrives while the first is still travelling.
 */
private const val VALUE_GLIDE_MS = 130L

/** Far enough to take a clip off a canvas in one direction, whatever the panel's size. */
private const val BIG_CLIP = 100_000f

/** Where the feedback's clock wraps, in seconds: its breath and its rim both divide it. */
private const val FEEDBACK_TIME_WRAP_S = 3600f

/** How often a showcase reaches the top again, in seconds of the feedback's clock: see [QuickSliderView.setFeedbackShowcase]. */
private const val SHOWCASE_S = 3.6f

private val FEEDBACK_DARK_INK = 0xFF14161B.toInt()

/** The slot in the backdrops that averages the whole lit part rather than under the contents. */
private const val LIT_BACKDROP = 2

/** How much smaller than the panel the image the ink is picked from is: an average needs few pixels. */
private const val BACKDROP_SCALE = 0.25f

/** How finely the level that image is taken at follows the panel's: to the nearest twentieth. */
private const val BACKDROP_LEVELS = 20

/** The moments of a fill's cycle that image is taken at, spread so no one frame decides. */
private val BACKDROP_PHASES = floatArrayOf(0.13f, 0.46f, 0.79f)

private const val OPAQUE = 0xFF shl 24

/** How far outside the drawn icon a touch still counts as on it, in dp. */
private const val ICON_TOUCH_SLACK_DP = 8f

/** How often the wave's outline is sampled across the track. Finer than the eye can resolve. */
private const val WAVE_STEP_PX = 6f

/** The width of one diagonal band, and of the gap after it. */

/** How many sparks an ember fill carries. Enough to read as fire, few enough to stay sparks. */
private const val EMBER_COUNT = 22

/** How many bubbles rise through a liquid fill. Enough to read as fizz, few enough to stay bubbles. */

/** How many stars each of a galaxy's three depths carries. */
private const val STARS_PER_LAYER = 16

/** The pictorial styles whose first pass is an opaque ground over the whole fill. */
private val OPAQUE_PICTORIAL = setOf(SliderFill.GALAXY)

/** The largest grid Plasma samples. At two dp a cell, well beyond any panel's size. */

