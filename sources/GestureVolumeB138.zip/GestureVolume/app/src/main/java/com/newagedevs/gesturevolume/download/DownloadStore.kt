package com.newagedevs.gesturevolume.download

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** The download list, kept as one small JSON text in preferences. Nothing is held in memory until a download is used. */
object DownloadStore {
    const val QUEUED = 0
    const val RUNNING = 1
    const val PAUSED = 2
    const val STOPPED = 3
    const val DONE = 4
    const val FAILED = 5

    const val NORMAL = 0
    const val REPLACE = 1
    const val RENAME = 2

    class Job(
        val id: Int,
        var url: String,
        var name: String,
        var nameEdited: Boolean,
        var mode: Int,
    ) {
        @Volatile var state = QUEUED
        @Volatile var total = -1L
        @Volatile var done = 0L
        @Volatile var speed = 0L
        @Volatile var message = ""
        var etag: String? = null
        var lastMod: String? = null
        var mime = ""
        var savedName: String? = null
        var savedUri: String? = null
        var referer: String? = null
        var cookie: String? = null
        var ua: String? = null
        var created = System.currentTimeMillis()
        /** True for a download the user just added: it may take over an unfinished one of the same file. */
        @Volatile var fresh = false
        val isApk get() = (savedName ?: name).endsWith(".apk", true)
    }

    private var sp: android.content.SharedPreferences? = null
    private val jobs = ArrayList<Job>()
    private var loaded = false

    @Synchronized fun init(context: Context) {
        if (loaded) return
        sp = context.applicationContext.getSharedPreferences("a_downloads", Context.MODE_PRIVATE)
        runCatching {
            val arr = JSONArray(sp!!.getString("jobs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val j = Job(o.getInt("id"), o.getString("url"), o.getString("name"), o.optBoolean("edited"), o.optInt("mode"))
                j.state = o.optInt("state"); j.total = o.optLong("total", -1); j.done = o.optLong("done")
                j.message = o.optString("msg"); j.etag = o.optString("etag").ifEmpty { null }; j.lastMod = o.optString("lm").ifEmpty { null }
                j.mime = o.optString("mime"); j.savedName = o.optString("sname").ifEmpty { null }; j.savedUri = o.optString("suri").ifEmpty { null }
                j.referer = o.optString("ref").ifEmpty { null }; j.cookie = o.optString("cookie").ifEmpty { null }; j.ua = o.optString("ua").ifEmpty { null }
                j.created = o.optLong("created")
                jobs.add(j)
            }
        }
        loaded = true
    }

    @Synchronized fun all(): List<Job> = ArrayList(jobs)
    @Synchronized fun get(id: Int): Job? = jobs.firstOrNull { it.id == id }
    @Synchronized fun nextId(): Int = (jobs.maxOfOrNull { it.id } ?: 0) + 1

    @Synchronized fun add(job: Job) { jobs.add(job); save() }
    @Synchronized fun remove(id: Int) { jobs.removeAll { it.id == id }; save() }

    @Synchronized fun save() {
        val arr = JSONArray()
        for (j in jobs) arr.put(JSONObject().apply {
            put("id", j.id); put("url", j.url); put("name", j.name); put("edited", j.nameEdited); put("mode", j.mode)
            put("state", j.state); put("total", j.total); put("done", j.done); put("msg", j.message)
            put("etag", j.etag ?: ""); put("lm", j.lastMod ?: ""); put("mime", j.mime)
            put("sname", j.savedName ?: ""); put("suri", j.savedUri ?: ""); put("ref", j.referer ?: "")
            put("cookie", j.cookie ?: ""); put("ua", j.ua ?: ""); put("created", j.created)
        })
        sp?.edit()?.putString("jobs", arr.toString())?.apply()
    }

    fun partFile(context: Context, job: Job): File = File(File(context.filesDir, "dl"), "${job.id}.part")

    fun statusText(context: Context, j: Job): String {
        fun size(n: Long) = android.text.format.Formatter.formatShortFileSize(context, n)
        val pct = if (j.total > 0) " ${(j.done * 100 / j.total).toInt()}%" else ""
        val amount = if (j.total > 0) "${size(j.done)} of ${size(j.total)}" else size(j.done)
        return when (j.state) {
            QUEUED -> "Waiting" + if (j.message.isNotEmpty()) ". ${j.message}" else ""
            RUNNING -> (if (j.message.isNotEmpty()) j.message + ". " else "") + "$pct  $amount" + if (j.speed > 0) "  ${size(j.speed)}/s" else ""
            PAUSED -> "Paused$pct  $amount" + if (j.message.isNotEmpty() && j.message != "Paused") ". ${j.message}" else ""
            STOPPED -> "Stopped$pct  $amount. Resume continues from here; Restart starts over."
            DONE -> "Done: ${j.savedName ?: j.name}" + if (j.message.isNotEmpty()) "\n${j.message}" else ""
            else -> "Failed. ${j.message}  ($amount kept)"
        }
    }
}
