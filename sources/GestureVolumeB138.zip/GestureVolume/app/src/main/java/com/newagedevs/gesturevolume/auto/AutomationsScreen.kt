package com.newagedevs.gesturevolume.auto

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.flow.FlowStore

/**
 * Rules like "when a text arrives, run CopyOTP". Rules run only while the A service is on
 * (the app-opened rule) or the app is installed (text rule works even when A is off).
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun AutomationsScreen(close: () -> Unit) {
    val c = LocalContext.current
    val rules = remember { mutableStateListOf<AutoRule>().apply { addAll(AutoStore.load(c)) } }
    var adding by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    fun persist() { AutoStore.save(c, rules.toList()); Automations.start(c) }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        info = if (ok) "Text permission allowed." else "Text permission refused. Use Grant permissions (Shizuku) or allow it in Android settings."
    }
    Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Automations", fontSize = 20.sp)
        Text("When something happens, run one of your flows. Turn A off and on once after adding the first rule.", fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { adding = true }) { Text("Add rule") }
            OutlinedButton(onClick = {
                AutoStore.ensureFlows(c)
                if (rules.none { it.trigger == AutoTriggers.SMS && it.flow == "CopyOTP" }) rules.add(AutoRule(AutoTriggers.SMS, "", "CopyOTP"))
                persist()
                info = "Added: text arrives → CopyOTP. Allow text reading below if you have not."
            }) { Text("Copy OTP from texts") }
            OutlinedButton(onClick = {
                if (c.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) info = "Text permission is already allowed."
                else smsPerm.launch(Manifest.permission.RECEIVE_SMS)
            }) { Text("Allow reading texts") }
            OutlinedButton(onClick = { runCatching { c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) { Text("Allow usage access") }
            OutlinedButton(onClick = close) { Text("Back") }
        }
        if (info.isNotEmpty()) Text(info, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(rules) { i, r ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(AutoTriggers.label(r.trigger) + if (r.arg.isNotBlank()) ": ${r.arg}" else "")
                        Text("runs ${r.flow}", fontSize = 12.sp)
                    }
                    Switch(r.enabled, { rules[i] = r.copy(enabled = it); persist() })
                    TextButton(onClick = { rules.removeAt(i); persist() }) { Text("Delete") }
                }
            }
        }
    }
    if (adding) {
        var trig by remember { mutableStateOf(AutoTriggers.SMS) }
        var arg by remember { mutableStateOf("") }
        var flow by remember { mutableStateOf("") }
        val flows = remember { FlowStore.names(c) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New rule") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("When:", fontSize = 12.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        AutoTriggers.all.forEach { t ->
                            if (t == trig) Button(onClick = {}) { Text(AutoTriggers.label(t), fontSize = 11.sp) }
                            else OutlinedButton(onClick = { trig = t }) { Text(AutoTriggers.label(t), fontSize = 11.sp) }
                        }
                    }
                    if (AutoTriggers.argHint(trig).isNotEmpty())
                        OutlinedTextField(arg, { arg = it }, label = { Text(AutoTriggers.argHint(trig)) }, singleLine = true)
                    Text("Run flow:", fontSize = 12.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        flows.forEach { n ->
                            if (n == flow) Button(onClick = {}) { Text(n, fontSize = 11.sp) }
                            else OutlinedButton(onClick = { flow = n }) { Text(n, fontSize = 11.sp) }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (flow.isNotEmpty()) { rules.add(AutoRule(trig, arg.trim(), flow)); persist() }
                    adding = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}
