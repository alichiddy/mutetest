package a.a

import com.newagedevs.gesturevolume.service.GestureAccessibilityService

/**
 * The accessibility service under its short name, so it is written `a.a/.S` in a command or in
 * Automate. Everything it does is in [GestureAccessibilityService].
 */
class S : GestureAccessibilityService()
