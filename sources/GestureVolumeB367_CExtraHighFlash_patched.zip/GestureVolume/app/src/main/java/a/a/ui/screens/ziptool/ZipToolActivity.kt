package a.a.ui.screens.ziptool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Zip tools: one window for everything done to zips and project folders, one tab each.
 *
 *  - Replace one: swap one file inside a zip for a new file.
 *  - Extract files: take chosen files out of a zip, saved as folders or as a new zip.
 *  - Patch several: replace many files inside a project zip at once.
 *  - Rename app: change the package name and app name inside a project zip.
 *  - Zip a folder: zip a whole folder into a new zip, changing nothing in it.
 *  - Compare and merge: compare two zips or folders, see what differs, and choose file by file what to take.
 *
 * Every tab saves a new zip in Downloads, reads it back and checks it, and never changes what you picked.
 * Nothing runs or is held in memory until this window is open.
 */
class ZipToolActivity : ComponentActivity() {
    private enum class Mode(val tab: String, val key: String) {
        REPLACE("Replace one", "replace"),
        EXTRACT("Extract files", "extract"),
        PATCH("Patch several", "patch"),
        RENAME("Rename app", "rename"),
        FOLDER("Zip a folder", "folder"),
        MERGE("Compare & merge", "merge"),
    }

    private var mode by mutableStateOf(Mode.REPLACE)

    private val replace by lazy { ReplaceState(applicationContext) }
    private val extract by lazy { ExtractState(applicationContext) }
    private val patch by lazy { PatchState(applicationContext) }
    private val rename by lazy { RenameState(applicationContext) }
    private val folder by lazy { FolderState(applicationContext) }
    private val merge by lazy { MergeState(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modeFrom(intent)
        setContent {
            AWindow {
                AWindowPage("Zip tools", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            for (m in Mode.entries) {
                                ChoiceChip(m.tab, mode == m, onClick = { mode = m })
                            }
                        }
                        when (mode) {
                            Mode.REPLACE -> ReplaceTab(replace)
                            Mode.EXTRACT -> ExtractTab(extract)
                            Mode.PATCH -> PatchTab(patch)
                            Mode.RENAME -> RenameTab(rename)
                            Mode.FOLDER -> FolderTab(folder)
                            Mode.MERGE -> MergeTab(merge)
                        }
                    }
                }
            }
        }
    }

    /** The Rename and Patch shortcuts saved before the tools were merged open this window on their own tab. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        modeFrom(intent)
    }

    private fun modeFrom(i: Intent?) {
        val key = i?.getStringExtra(EXTRA_MODE) ?: return
        Mode.entries.firstOrNull { it.key == key }?.let { mode = it }
    }

    override fun onDestroy() {
        if (isFinishing) {
            replace.cleanup()
            extract.cleanup()
            patch.cleanup()
            rename.cleanup()
            folder.cleanup()
            merge.cleanup()
        }
        super.onDestroy()
    }

    companion object {
        /** Which tab to open: replace, extract, patch, rename, folder or merge. */
        const val EXTRA_MODE = "zipToolMode"
    }
}

/**
 * Extract files from a zip: pick the zip, tick the files you want from a searchable list, choose whether they
 * are saved as folders (the zip's own folders kept, inside one folder in Downloads) or as one new zip holding
 * only them. Every file is checked against its checksum, and the zip you picked is never changed.
 */
class ExtractState(private val ctx: Context) {
    var zipName by mutableStateOf<String?>(null)
    var srcFile by mutableStateOf<File?>(null)
    var entries by mutableStateOf<List<String>>(emptyList())
    var picked by mutableStateOf<Set<String>>(emptySet())
    var asFolders by mutableStateOf(true)
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var log by mutableStateOf("")
    var showList by mutableStateOf(false)
    private var stem = "extracted"
    private var nameAuto = true

    val ready: Boolean get() = srcFile != null && picked.isNotEmpty() && outName.isNotBlank()

    fun cleanup() {
        File(ctx.cacheDir, SRC_TMP).delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    private fun defaultName(): String = if (asFolders) "${stem}_extracted" else "${stem}_extracted.zip"

    /** The name box was typed in: it is the user's now, and stays when the choice changes. */
    fun renamed(s: String) {
        outName = s
        nameAuto = false
    }

    /** Folders or one zip; the suggested name follows unless it was typed in. */
    fun chooseFolders(on: Boolean) {
        asFolders = on
        if (nameAuto) outName = defaultName()
    }

    /** Copies the chosen zip into the app's cache and lists the files inside it. */
    fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            try {
                val f = File(ctx.cacheDir, SRC_TMP)
                ZipIo.copyToCache(ctx.contentResolver, u, f)
                val names = ZipIo.listFiles(f)
                srcFile = f
                zipName = name
                entries = names
                picked = emptySet()
                stem = ZipIo.stem(name).ifEmpty { "extracted" }
                nameAuto = true
                outName = defaultName()
            } catch (e: Throwable) {
                log = "ZIP ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    fun toggle(path: String) {
        picked = if (path in picked) picked - path else picked + path
    }

    fun tick(paths: List<String>) {
        picked = picked + paths
    }

    fun untick(paths: List<String>) {
        picked = picked - paths.toSet()
    }

    fun clear() {
        picked = emptySet()
    }

    fun make() {
        val src = srcFile ?: return
        if (busy || picked.isEmpty()) return
        busy = true
        log = ""
        val names = entries.filter { it in picked }.distinct()
        val toFolders = asFolders
        val name = outName
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                log = if (toFolders) toFolder(src, names, name) else toZip(src, tmp, names, name)
            } catch (e: Throwable) {
                log = "ERROR: ${e.javaClass.simpleName}: ${e.message}\n" +
                    if (toFolders) "Stopped. Files saved before the error are in Downloads." else "Nothing was saved."
            } finally {
                tmp.delete()
                busy = false
            }
        }.start()
    }

    /** One new zip holding only [names], each with its own path, read back and checked before it is saved. */
    private fun toZip(src: File, tmp: File, names: List<String>, outName: String): String {
        val saveName = ZipIo.cleanName(outName, "extracted")
        val expect = HashMap<String, Long>()
        ZipFile(src).use { zf ->
            ZipOutputStream(tmp.outputStream().buffered()).use { zo ->
                for (n in names) {
                    val e = zf.getEntry(n) ?: throw IllegalStateException("$n was not found in the zip.")
                    val o = ZipEntry(n)
                    if (e.time != -1L) o.time = e.time
                    if (e.comment != null) o.comment = e.comment
                    o.method = ZipEntry.DEFLATED
                    zo.putNextEntry(o)
                    val crc = CRC32()
                    zf.getInputStream(e).use { i -> pump(i, zo, crc) }
                    zo.closeEntry()
                    if (e.crc != -1L && e.crc != crc.value) throw IllegalStateException("$n is damaged inside the zip.")
                    expect[n] = crc.value
                }
            }
        }
        val problem = ZipIo.verify(tmp, names.size, expect)
        if (problem != null) return "ZIP ERROR: $problem\nNothing was saved."
        val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
        return "Created: $where (${ZipIo.mb(tmp.length())})\nZIP integrity check passed. ${names.size} files.\n" + fileList(names)
    }

    /** Every file of [names] saved under Downloads/[outName], keeping its folders; each is read back and checked. */
    private fun toFolder(src: File, names: List<String>, outName: String): String {
        var folder = outName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").trim('.', ' ')
        if (folder.isEmpty()) folder = "extracted"
        val skipped = ArrayList<String>()
        var count = 0
        var bytes = 0L
        ZipFile(src).use { zf ->
            for (n in names) {
                val parts = n.split('/').filter { it.isNotEmpty() }
                if (parts.isEmpty() || parts.any { it == ".." || it == "." }) {
                    skipped.add(n)
                    continue
                }
                val e = zf.getEntry(n) ?: throw IllegalStateException("$n was not found in the zip.")
                val sub = parts.dropLast(1).joinToString("/")
                bytes += saveFile(zf, e, folder, sub, parts.last())
                count++
            }
        }
        val sb = StringBuilder("Saved: Downloads/$folder/ ($count files, ${ZipIo.size(bytes)})\n")
        sb.append("Every file was read back and checked.\n")
        if (skipped.isNotEmpty()) sb.append("Left out (unsafe path): ${skipped.joinToString(", ")}\n")
        sb.append(fileList(names))
        return sb.toString()
    }

    /** Saves one file in Downloads/[folder]/[sub] and returns its size; throws when what was saved does not match. */
    @Suppress("DEPRECATION")
    private fun saveFile(zf: ZipFile, e: ZipEntry, folder: String, sub: String, fileName: String): Long {
        val crc = CRC32()
        var total = 0L
        val back = CRC32()
        var backTotal = 0L
        val path = if (sub.isEmpty()) folder else "$folder/$sub"
        if (Build.VERSION.SDK_INT >= 29) {
            val cr = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + path)
            }
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create $fileName in Downloads.")
            val os = cr.openOutputStream(uri) ?: throw IllegalStateException("Could not write $fileName in Downloads.")
            os.use { o -> zf.getInputStream(e).use { i -> total = pump(i, o, crc) } }
            val ins = cr.openInputStream(uri) ?: throw IllegalStateException("Could not read $fileName back.")
            ins.use { i -> backTotal = pump(i, null, back) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), path)
            dir.mkdirs()
            val dest = File(dir, fileName)
            dest.outputStream().use { o -> zf.getInputStream(e).use { i -> total = pump(i, o, crc) } }
            dest.inputStream().use { i -> backTotal = pump(i, null, back) }
        }
        if (e.crc != -1L && e.crc != crc.value) throw IllegalStateException("${e.name} is damaged inside the zip.")
        if (back.value != crc.value || backTotal != total) throw IllegalStateException("${e.name} was not saved correctly.")
        return total
    }

    /** Copies [i] to [o] (when there is one) while counting the checksum; returns how many bytes went through. */
    private fun pump(i: InputStream, o: OutputStream?, crc: CRC32): Long {
        val buf = ByteArray(ZipIo.BUF)
        var total = 0L
        while (true) {
            val r = i.read(buf)
            if (r < 0) break
            crc.update(buf, 0, r)
            o?.write(buf, 0, r)
            total += r
        }
        return total
    }

    /** The files that were taken out, one per line (the first 40). */
    private fun fileList(names: List<String>): String {
        val sb = StringBuilder()
        for (n in names.take(40)) sb.append(" - ").append(n).append('\n')
        if (names.size > 40) sb.append("... and ${names.size - 40} more")
        return sb.toString().trimEnd()
    }

    private companion object {
        const val SRC_TMP = "zt_extract_src.zip"
        const val OUT_TMP = "zt_extract_out.zip"
    }
}

@Composable
fun ExtractTab(s: ExtractState) {
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(u)
    }
    HeroCard(
        title = "Extract files from a zip",
        text = "Pick the zip, tick the files you want, and choose folders or one zip. It is saved in Downloads and checked.",
        leading = { IconTile(Icons.Filled.Folder, lit = true) },
    )
    Column {
        GroupHeading("Pick")
        RowGroup {
            KitRow(
                title = "Zip file",
                shape = cardShape(0, 2),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = s.zipName ?: "Tap to choose",
                description = if (s.zipName != null) "${s.entries.size} files inside" else null,
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "Files to take out",
                shape = cardShape(1, 2),
                summary = if (s.picked.isEmpty()) "Tap to choose from the list" else "${s.picked.size} chosen",
                description = if (s.entries.isEmpty()) "Choose the zip first" else null,
                onClick = { if (!s.busy && s.entries.isNotEmpty()) s.showList = true },
            )
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GroupHeading("Save as")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Folders", s.asFolders, onClick = { if (!s.busy) s.chooseFolders(true) })
            ChoiceChip("One zip", !s.asFolders, onClick = { if (!s.busy) s.chooseFolders(false) })
        }
        OutlinedTextField(
            value = s.outName,
            onValueChange = { s.renamed(it) },
            singleLine = true,
            label = { Text(if (s.asFolders) "Folder name (saved in Downloads)" else "File name (saved in Downloads)") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
    Button(
        onClick = { s.make() },
        enabled = s.ready && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) "Working..." else if (s.asFolders) "Extract to folders" else "Extract to a zip") }
    ResultBox(s.log)

    if (s.showList) {
        var query by remember { mutableStateOf("") }
        val shown = remember(s.entries, query) {
            val q = query.trim()
            if (q.isEmpty()) s.entries else s.entries.filter { it.contains(q, ignoreCase = true) }
        }
        CardWindow(title = "Files to take out (${s.picked.size} chosen)", onBack = { s.showList = false }, scroll = false) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search (${shown.size} files)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { s.tick(shown) }) { Text("Tick all shown") }
                TextButton(onClick = { s.untick(shown) }) { Text("Untick shown") }
                TextButton(onClick = { s.clear() }) { Text("Clear") }
            }
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shown) { path ->
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        onClick = { s.toggle(path) },
                        trailing = { Checkbox(checked = path in s.picked, onCheckedChange = { s.toggle(path) }) },
                    )
                }
            }
            Button(
                onClick = { s.showList = false },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("Done") }
        }
    }
}
