package a.a.ui.screens.handler_action

import a.a.flow.ChoiceRow
import a.a.flow.CellActionPicker
import a.a.flow.WhenCellPicker
import a.a.flow.WhenWhereChoice
import a.a.strip.StripItem
import a.a.strip.StripScope
import a.a.strip.WhenRules
import a.a.ui.motion.OutlinedButton
import a.a.ui.motion.TextButton
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.BuiltInIcons
import a.a.ui.screens.strip.BuiltInPage
import a.a.ui.screens.strip.MyScriptsPage
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** The words of one row for the list. */
private fun rowText(r: WhenRules.Rule, context: android.content.Context): String {
    val ev = WhenRules.EVENTS.firstOrNull { it.first == r.event }?.second ?: r.event
    val cell = if (r.event == WhenRules.CELL_RUNS) " \"" + r.cellName.ifEmpty { "?" } + "\"" else ""
    val only = when (r.only) {
        WhenRules.ONLY_APP -> "  -  only if " + r.onlyArg + " is in front"
        "" -> ""
        else -> "  -  only if: " + (WhenRules.ONLY.firstOrNull { it.first == r.only }?.second ?: r.only)
    }
    val from = if (r.where.isEmpty()) "" else "  -  " + WhenRules.whereLabel(context, r.where).replaceFirstChar { it.lowercase() }
    val actions = r.actions.ifEmpty { listOf(WhenRules.Action(r.action, r.actionName)).filter { it.action.isNotBlank() } }
    return ev + cell + from + only + "\n-> " + actions.mapIndexed { i, a -> "${i + 1}. " + a.name.ifEmpty { a.action.take(40) } }.joinToString("  ·  ")
}

/**
 * "When..." on the Actions screen: rows of event + optional "only if" + action, for the main bar.
 * Nothing is read or run here until the card is shown, and the rows are looked at only when their event happens.
 */
@Composable
fun WhenCard(shape: Shape) {
    val context = LocalContext.current
    var rules by remember { mutableStateOf(WhenRules.load(context)) }
    var editing by remember { mutableStateOf<Int?>(null) }

    fun store(list: List<WhenRules.Rule>) {
        rules = list
        WhenRules.save(context, list)
    }

    Column(
        Modifier.fillMaxWidth().clip(shape).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("When...", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
        Text(
            "Start an action when something happens on the main bar or a side bar: you slide in, the volume moves, a cell runs, the cells window closes. Add \"only if\" to limit it. Each row is checked only when its event happens.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        rules.forEachIndexed { i, r ->
            Text(
                rowText(r, context), fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                    .clickable { editing = i }.padding(12.dp),
            )
        }
        OutlinedButton(onClick = { editing = -1 }) { Text("Add a row") }
    }

    editing?.let { idx ->
        WhenEditor(
            initial = rules.getOrNull(idx) ?: WhenRules.Rule(WhenRules.SLIDE_IN),
            existing = idx >= 0,
            onSave = { r ->
                store(if (idx >= 0) rules.toMutableList().also { it[idx] = r } else rules + r)
                editing = null
            },
            onDelete = { store(rules.toMutableList().also { it.removeAt(idx) }); editing = null },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun WhenEditor(initial: WhenRules.Rule, existing: Boolean, onSave: (WhenRules.Rule) -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var r by remember { mutableStateOf(initial) }
    var actions by remember { mutableStateOf(initial.actions.ifEmpty { listOf(WhenRules.Action(initial.action, initial.actionName)).filter { it.action.isNotBlank() } }) }
    var delayUnit by remember { mutableStateOf("ms") }
    var pickAction by remember { mutableStateOf(false) }
    var pickCell by remember { mutableStateOf(false) }
    var pickApp by remember { mutableStateOf(false) }

    if (pickAction) ActionChooserDialog(onPicked = { action, name -> actions = actions + WhenRules.Action(action, name, if (actions.isEmpty()) 0L else 500L); pickAction = false }, onDismiss = { pickAction = false })
    if (pickCell) {
        WhenCellPicker(
            where = r.where,
            onPicked = { key, name -> r = r.copy(cellKey = key, cellName = name); pickCell = false },
            onDismiss = { pickCell = false },
        )
    }
    if (pickApp) {
        Dialog(onDismissRequest = { pickApp = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Surface(Modifier.fillMaxSize()) {
                AppList(onPick = { app -> r = r.copy(onlyArg = app.packageName); pickApp = false }, onBack = { pickApp = false }, everything = true)
            }
        }
    }

    val ready = actions.isNotEmpty() && actions.all { it.action.isNotBlank() } && (r.event != WhenRules.CELL_RUNS || r.cellKey.isNotEmpty()) &&
        (r.only != WhenRules.ONLY_APP || r.onlyArg.isNotBlank())
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing) "Edit this row" else "New row") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("When", fontWeight = FontWeight.SemiBold)
                ChoiceRow(WhenRules.EVENTS.map { it.second to it.first }, r.event) { r = r.copy(event = it) }
                Text("Where", fontWeight = FontWeight.SemiBold)
                WhenWhereChoice(r.where) { r = r.copy(where = it) }
                if (r.event == WhenRules.CELL_RUNS) {
                    OutlinedButton(onClick = { pickCell = true }) { Text(if (r.cellName.isEmpty()) "Choose the cell..." else "Cell: " + r.cellName) }
                }
                Text("Only if", fontWeight = FontWeight.SemiBold)
                ChoiceRow(WhenRules.ONLY.map { it.second to it.first }, r.only) { r = r.copy(only = it) }
                if (r.only == WhenRules.ONLY_APP) {
                    OutlinedButton(onClick = { pickApp = true }) { Text(if (r.onlyArg.isEmpty()) "Choose the app..." else r.onlyArg) }
                    Text("Needs Usage access (or the accessibility service reporting the app) to know which app is in front.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("Do", fontWeight = FontWeight.SemiBold)
                actions.forEachIndexed { i, item ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}. " + item.name.ifEmpty { item.action.take(40) }, Modifier.weight(1f))
                        TextButton(onClick = { actions = actions.toMutableList().also { it.removeAt(i) } }) { Text("Remove") }
                    }
                    if (i > 0) {
                        Text("Wait before action ${i + 1}", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        ChoiceRow(listOf("Milliseconds" to "ms", "Seconds" to "s"), delayUnit) { delayUnit = it }
                        val delay = item.delayBeforeMs.coerceIn(0L, 10_000L)
                        androidx.compose.material3.Slider(
                            value = delay.toFloat(),
                            onValueChange = { v -> actions = actions.toMutableList().also { it[i] = it[i].copy(delayBeforeMs = v.toLong()) } },
                            valueRange = 0f..10_000f,
                            steps = if (delayUnit == "s") 99 else 99,
                        )
                        Text(if (delayUnit == "s") "${"%.1f".format(item.delayBeforeMs / 1000f)} seconds" else "${item.delayBeforeMs} milliseconds", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                OutlinedButton(onClick = { pickAction = true }) { Text("+ Add an action") }
                Text("Actions run in order. Each delay is the wait after the previous action starts and before this action starts.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (r.event == WhenRules.SLIDE_IN) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Also open the cells window", Modifier.weight(1f))
                        Switch(checked = r.alsoOpen, onCheckedChange = { r = r.copy(alsoOpen = it) })
                    }
                    Text("When I lift my thumb", fontWeight = FontWeight.SemiBold)
                    ChoiceRow(listOf("Stay open" to "stay", "Close the action" to "close"), if (r.closeOnLift) "close" else "stay") { r = r.copy(closeOnLift = it == "close") }
                    Text(
                        "Close works for floating windows the action opens (a widget, notes, gallery). A screen of another app cannot be closed this way.",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (ready) onSave(r.copy(action = actions.firstOrNull()?.action.orEmpty(), actionName = actions.firstOrNull()?.name.orEmpty(), actions = actions)) }) { Text(if (ready) "Save" else "Save (fill in the rest)") } },
        dismissButton = {
            Row {
                if (existing) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
    )
}

/** The same lists as the shortcut picker for other apps: Built-in shortcuts (with device actions and Open an app), then My Scripts. */
@Composable
private fun ActionChooserDialog(onPicked: (action: String, name: String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var page by remember { mutableStateOf(0) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
            when (page) {
                0 -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    Text("Choose an action", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                    Text("Built-in shortcuts (device actions, Open an app, Open a widget)", Modifier.fillMaxWidth().clickable { page = 1 }.padding(vertical = 14.dp, horizontal = 6.dp))
                    Text("Pick a cell (folders and side segments' cells too)", Modifier.fillMaxWidth().clickable { page = 3 }.padding(vertical = 14.dp, horizontal = 6.dp))
                    Text("My Scripts", Modifier.fillMaxWidth().clickable { page = 2 }.padding(vertical = 14.dp, horizontal = 6.dp))
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                }
                1 -> BuiltInPage(
                    onPick = { entry, name -> onPicked(entry.action, name); onDismiss() },
                    onBack = { page = 0 },
                    onPickAction = { a, n, _ -> onPicked(a, n); onDismiss() },
                    onPickApp = { app, _, act -> onPicked(act, app.label); onDismiss() },
                )
                3 -> CellActionPicker(
                    onPicked = { action, name -> onPicked(action, name); onDismiss() },
                    onDismiss = { page = 0 },
                )
                else -> MyScriptsPage(
                    onPick = { label, action, _ -> onPicked(action, label); onDismiss() },
                    onBack = { page = 0 },
                )
            }
        }
    }
}
