package a.a.strip

import android.annotation.SuppressLint
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Context
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.FrameLayout
import android.widget.TextView

/**
 * What the widget windows share: the saved widget ids, and the "tile" helpers.
 *
 * A tile is a view inside a hosted widget that reacts to a tap (one chat in Eitaa's chats widget).
 * Android hides what a tile's tap will start, so instead of copying the intent the grabber notes
 * which tile it is (its name, and its place among the tiles), and the runner later presses that
 * same tile in the widget, which fires the widget's own tap exactly as a finger would.
 */
object WidgetKit {
    const val HOST_ID = 1717
    private const val PREFS = "widgets"

    fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The widgets saved in A that still exist (the others are dropped). */
    fun savedIds(ctx: Context, host: AppWidgetHost): List<Int> {
        val mgr = AppWidgetManager.getInstance(ctx)
        val out = ArrayList<Int>()
        for (id in prefs(ctx).getString("ids", "").orEmpty().split(',').mapNotNull { it.toIntOrNull() }) {
            if (mgr.getAppWidgetInfo(id) != null) out += id else runCatching { host.deleteAppWidgetId(id) }
        }
        return out
    }

    fun saveIds(ctx: Context, ids: List<Int>) {
        prefs(ctx).edit().putString("ids", ids.joinToString(",")).apply()
    }

    /** Every tappable view inside the widget, in a fixed order (the widget itself only if nothing else taps). */
    fun tiles(root: View): List<View> {
        val out = ArrayList<View>()
        fun walk(v: View) {
            if (v.visibility == View.GONE) return
            if (v !== root && v.hasOnClickListeners()) out += v
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(root)
        if (out.isEmpty() && root.hasOnClickListeners()) out += root
        return out
    }

    private fun collectTexts(v: View, out: MutableList<String>) {
        if (v.visibility == View.GONE) return
        if (v is TextView) {
            val t = v.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty()) out += t
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) collectTexts(v.getChildAt(i), out)
    }

    /**
     * The tile's name: the first text with a letter in it (counts such as "3" or "99+" and times
     * change, a chat's name does not). Empty when the tile shows no text.
     */
    fun nameOf(tile: View, root: View): String {
        var t: View = tile
        for (step in 0 until 3) {
            val texts = ArrayList<String>()
            collectTexts(t, texts)
            texts.firstOrNull { s -> s.any { c -> c.isLetter() } }?.let { return it.take(60) }
            val p = t.parent as? ViewGroup ?: return ""
            if (p === root || p is AdapterView<*>) return ""
            t = p
        }
        return ""
    }

    /** The tappable view under a point (in [root]'s own coordinates), or null. */
    fun tileAt(root: View, x: Float, y: Float): View? {
        fun hit(v: View, px: Float, py: Float): View? {
            if (px < 0 || py < 0 || px >= v.width || py >= v.height) return null
            if (v is ViewGroup) {
                for (i in v.childCount - 1 downTo 0) {
                    val c = v.getChildAt(i)
                    if (c.visibility != View.VISIBLE) continue
                    hit(c, px + v.scrollX - c.left, py + v.scrollY - c.top)?.let { return it }
                }
            }
            return v
        }
        var t: View? = hit(root, x, y)
        while (t != null) {
            if (t.hasOnClickListeners() && t !== root) return t
            if (t === root) break
            t = t.parent as? View
        }
        return null
    }

    /** The tile to press: by name when it has one (a changed name is not guessed), else by its place. */
    fun pick(root: View, name: String, pos: Int): View? {
        val ts = tiles(root)
        if (name.isNotBlank()) {
            val m = ts.filter { nameOf(it, root).equals(name, ignoreCase = true) }
            return m.firstOrNull { ts.indexOf(it) == pos } ?: m.firstOrNull()
        }
        return ts.getOrNull(pos)
    }
}

/**
 * Holds a hosted widget. While [grabbing] it swallows the tap, so nothing opens, and reports the
 * tile that was under the finger.
 */
class GrabFrame(context: Context, val hv: AppWidgetHostView) : FrameLayout(context) {
    var grabbing = false
    var onGrab: ((View?) -> Unit)? = null

    init {
        addView(hv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = grabbing

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!grabbing) return super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP) {
            onGrab?.invoke(WidgetKit.tileAt(hv, ev.x - hv.left, ev.y - hv.top))
        }
        return true
    }
}
