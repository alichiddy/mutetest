package a.a.strip

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The Widgets window: hosts other apps' real home-screen widgets (Eitaa's chats widget, for
 * example), the way a launcher does. It works whether or not A is the default launcher.
 *
 * Three cells can come out of it:
 * - the window itself,
 * - a popup panel with the widgets over the app in front ([WidgetPopupActivity]),
 * - one cell per chat ([WidgetTapActivity]): "Grab a chat", tap the tile, save. Android hides the
 *   intent behind a tile, so the cell notes which tile it is and presses that tile in the widget.
 *
 * Costs nothing while closed: the host only listens while a widget window is on screen.
 */
class WidgetHostActivity : ComponentActivity() {
    private class Grab(val name: String, val pos: Int, val pkg: String)

    private val host by lazy { AppWidgetHost(this, WidgetKit.HOST_ID) }
    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val prefs by lazy { WidgetKit.prefs(this) }
    private val ids = mutableStateListOf<Int>()
    private var picking by mutableStateOf(false)
    private var grabbing by mutableStateOf(false)
    private var grab by mutableStateOf<Grab?>(null)
    private var pendingId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingId = savedInstanceState?.getInt("pending", -1) ?: -1
        ids.addAll(WidgetKit.savedIds(this, host))
        save()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (picking) Picker() else Main()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pending", pendingId)
    }

    override fun onStart() {
        super.onStart()
        runCatching { host.startListening() }
    }

    override fun onStop() {
        runCatching { host.stopListening() }
        super.onStop()
    }

    private fun save() = WidgetKit.saveIds(this, ids.toList())

    // ---- adding a widget: bind (Android asks once), set up (the widget's own screen), keep ----

    private fun begin(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, p.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun afterBind(id: Int) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) {
            val ok = runCatching { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }.isSuccess
            if (!ok) {
                Toast.makeText(this, "The widget's setup screen would not open; added without it", Toast.LENGTH_LONG).show()
                finishAdd(id)
            }
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        if (id !in ids) ids.add(id)
        pendingId = -1
        save()
    }

    private fun cancelAdd() {
        if (pendingId != -1) runCatching { host.deleteAppWidgetId(pendingId) }
        pendingId = -1
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBind(id) else cancelAdd()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishAdd(id) else cancelAdd()
        }
    }

    // ---- the cells ----

    private fun saveWindowCell() {
        val i = Intent(this, WidgetHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, "Widgets", "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME))
        Toast.makeText(this, "Saved to cells", Toast.LENGTH_SHORT).show()
    }

    private fun savePopupCell() {
        val i = Intent(this, WidgetPopupActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, "Widgets popup", "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME))
        Toast.makeText(this, "Saved to cells", Toast.LENGTH_SHORT).show()
    }

    private fun saveChatCell(label: String, g: Grab) {
        val i = Intent(this, WidgetTapActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("tap", g.name).putExtra("pos", g.pos).putExtra("pkg", g.pkg)
        ActionSaver.saveToCells(this, label.ifBlank { "Chat" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:" + g.pkg)
        Toast.makeText(this, "Saved to cells", Toast.LENGTH_SHORT).show()
    }

    // ---- screens ----

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Main() {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Widgets", fontSize = 18.sp)
            Text(
                if (grabbing) "Tap the chat you want. Nothing opens: A only notes which tile it is."
                else "Add another app's widget (for example Eitaa's chats widget). It runs here as it does on a home screen.",
                fontSize = 12.sp,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { picking = true }) { Text("Add widget") }
                OutlinedButton(onClick = { grabbing = !grabbing }, enabled = ids.isNotEmpty()) {
                    Text(if (grabbing) "Stop grabbing" else "Grab a chat")
                }
                OutlinedButton(onClick = { savePopupCell() }) { Text("Save popup as a cell") }
                OutlinedButton(onClick = { saveWindowCell() }) { Text("Save window as a cell") }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(ids.toList(), key = { it }) { id -> WidgetBox(id) }
            }
        }
        grab?.let { g ->
            var label by remember(g) { mutableStateOf(g.name) }
            AlertDialog(
                onDismissRequest = { grab = null },
                title = { Text("Save this chat as a cell") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            if (g.name.isNotBlank()) "Found the tile named ${g.name}."
                            else "The tile shows no name, so the cell will press the tile by its place (number ${g.pos + 1}).",
                            fontSize = 12.sp,
                        )
                        OutlinedTextField(value = label, onValueChange = { label = it }, singleLine = true, label = { Text("Cell name") })
                    }
                },
                confirmButton = { TextButton(onClick = { saveChatCell(label.ifBlank { "Chat ${g.pos + 1}" }, g); grab = null }) { Text("Save as a cell") } },
                dismissButton = { TextButton(onClick = { grab = null }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun WidgetBox(id: Int) {
        val info = remember(id) { mgr.getAppWidgetInfo(id) }
        if (info == null) return
        val density = LocalDensity.current
        val startH = with(density) { info.minHeight.toDp().value.toInt() }.coerceAtLeast(110)
        var h by remember(id) { mutableStateOf(prefs.getInt("h$id", startH)) }
        Column {
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val w = maxWidth.value.toInt()
                AndroidView(
                    factory = { ctx -> GrabFrame(ctx, host.createView(ctx, id, info)) },
                    update = { f ->
                        f.grabbing = grabbing
                        f.onGrab = { tile ->
                            if (tile == null) {
                                Toast.makeText(this@WidgetHostActivity, "Tap right on a chat tile", Toast.LENGTH_SHORT).show()
                            } else {
                                val tiles = WidgetKit.tiles(f.hv)
                                grab = Grab(WidgetKit.nameOf(tile, f.hv), tiles.indexOf(tile), info.provider.packageName)
                                grabbing = false
                            }
                        }
                        f.hv.updateAppWidgetSize(null, w, h, w, h)
                    },
                    modifier = Modifier.fillMaxWidth().height(h.dp),
                )
            }
            androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { h = (h - 60).coerceAtLeast(60); prefs.edit().putInt("h$id", h).apply() }) { Text("Shorter") }
                TextButton(onClick = { h += 60; prefs.edit().putInt("h$id", h).apply() }) { Text("Taller") }
                TextButton(onClick = {
                    runCatching { host.deleteAppWidgetId(id) }
                    ids.remove(id)
                    save()
                }) { Text("Remove") }
            }
        }
    }

    @Composable
    private fun Picker() {
        BackHandler { picking = false }
        var q by remember { mutableStateOf("") }
        val all = remember {
            val pm = packageManager
            mgr.installedProviders.map { p ->
                val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() }.getOrDefault(p.provider.packageName)
                val name = runCatching { p.loadLabel(pm).toString() }.getOrDefault("")
                Triple(p, app, name)
            }.sortedBy { it.second.lowercase() }
        }
        val shown = all.filter { q.isBlank() || it.second.contains(q, true) || it.third.contains(q, true) || it.first.provider.packageName.contains(q, true) }
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Pick a widget", fontSize = 18.sp)
            OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Search (for example eitaa)") }, modifier = Modifier.fillMaxWidth())
            if (shown.isEmpty()) Text("No widgets found.", fontSize = 13.sp)
            LazyColumn(Modifier.weight(1f)) {
                items(shown) { (p, app, name) ->
                    Text(
                        "$app: $name",
                        Modifier.fillMaxWidth().clickable { picking = false; begin(p) }.padding(vertical = 12.dp),
                    )
                }
            }
        }
    }

    private companion object {
        const val REQ_BIND = 7101
        const val REQ_CONFIG = 7102
    }
}
