package a.a.strip

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast

/**
 * Runs a grabbed chat cell: loads the saved widget out of sight, waits for its tiles to appear,
 * presses the one that was grabbed (the widget's own tap, so Eitaa opens that chat) and closes.
 * Draws nothing and takes no touches.
 */
class WidgetTapActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var host: AppWidgetHost? = null
    private val views = ArrayList<AppWidgetHostView>()
    private var name = ""
    private var pos = -1
    private var tries = 0
    private var done = false

    private val poll = object : Runnable {
        override fun run() {
            if (done) return
            for (v in views) {
                val tile = WidgetKit.pick(v, name, pos)
                if (tile != null) {
                    done = true
                    tile.performClick()
                    handler.postDelayed({ finish() }, 400)
                    return
                }
            }
            tries++
            if (tries > 40) {
                done = true
                Toast.makeText(this@WidgetTapActivity, "That chat was not found in the widget", Toast.LENGTH_LONG).show()
                finish()
                return
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        name = intent.getStringExtra("tap").orEmpty()
        pos = intent.getIntExtra("pos", -1)
        val pkg = intent.getStringExtra("pkg").orEmpty()
        val h = AppWidgetHost(this, WidgetKit.HOST_ID)
        host = h
        val mgr = AppWidgetManager.getInstance(this)
        val root = FrameLayout(this)
        setContentView(root)
        val d = resources.displayMetrics.density
        for (id in WidgetKit.savedIds(this, h)) {
            val info = mgr.getAppWidgetInfo(id) ?: continue
            if (pkg.isNotEmpty() && info.provider.packageName != pkg) continue
            val v = h.createView(this, id, info)
            v.alpha = 0f
            root.addView(v, FrameLayout.LayoutParams((320 * d).toInt(), (520 * d).toInt()))
            v.updateAppWidgetSize(null, 320, 520, 320, 520)
            views += v
        }
        if (views.isEmpty()) {
            Toast.makeText(this, "No widget saved in A for this cell", Toast.LENGTH_LONG).show()
            done = true
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        runCatching { host?.startListening() }
        if (!done) handler.postDelayed(poll, 300)
    }

    override fun onStop() {
        runCatching { host?.stopListening() }
        handler.removeCallbacks(poll)
        if (!isFinishing) finish()
        super.onStop()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
