package a.a.strip

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * The saved widgets as a panel over whatever app is in front, like a widget on a home screen.
 * Tapping outside the panel closes it, and so does opening a chat from it.
 */
class WidgetPopupActivity : Activity() {
    private var host: AppWidgetHost? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0.55f)
        val h = AppWidgetHost(this, WidgetKit.HOST_ID)
        host = h
        val mgr = AppWidgetManager.getInstance(this)
        val dm = resources.displayMetrics
        val d = dm.density
        val pkg = intent.getStringExtra("pkg").orEmpty()

        val root = FrameLayout(this)
        root.setOnClickListener { finish() }
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding((10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt(), (10 * d).toInt())
        card.background = GradientDrawable().apply {
            setColor(0xF2202124.toInt())
            cornerRadius = 22 * d
        }
        val panelWidth = (dm.widthPixels * 0.92f).toInt()
        val wDp = (panelWidth / d).toInt() - 20
        var shown = 0
        for (id in WidgetKit.savedIds(this, h)) {
            val info = mgr.getAppWidgetInfo(id) ?: continue
            if (pkg.isNotEmpty() && info.provider.packageName != pkg) continue
            val hDp = WidgetKit.prefs(this).getInt("h$id", maxOf(110, (info.minHeight / d).toInt()))
            val hv = h.createView(this, id, info)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (hDp * d).toInt())
            lp.bottomMargin = (8 * d).toInt()
            card.addView(hv, lp)
            hv.updateAppWidgetSize(null, wDp, hDp, wDp, hDp)
            shown++
        }
        if (shown == 0) {
            Toast.makeText(this, "No widget saved in A yet", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val scroll = ScrollView(this)
        scroll.addView(card)
        val slp = FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.gravity = Gravity.CENTER
        root.addView(scroll, slp)
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        runCatching { host?.startListening() }
    }

    override fun onStop() {
        runCatching { host?.stopListening() }
        if (!isFinishing) finish()
        super.onStop()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
