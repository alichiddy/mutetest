package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * The Widgets window. Widgets of other apps (Eitaa's chats, Hotspot Shield's VPN switch...) are
 * added here once; each one then becomes cells that:
 *
 * - float it over whatever app is in front ([WidgetFloat]): one widget, draggable and resizable,
 *   remembering where you left it, with settings for size, opacity, auto-close and more,
 * - or press one tile of it (a chat, the VPN switch), hidden or shown for a few seconds. The tile
 *   is chosen with "Grab a tile": the widget floats, you tap the tile, and A notes which one it
 *   is. Android hides the intent behind a tile, so the cell presses that tile in the widget.
 *
 * It works whether or not A is the default launcher.
 */
class WidgetHostActivity : ComponentActivity() {
    private class GrabResult(val wid: Int, val name: String, val pos: Int, val pkg: String, val details: String)

    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val prefs by lazy { WidgetKit.prefs(this) }
    private val ids = mutableStateListOf<Int>()
    private val frames = HashMap<Int, AppWidgetHostView>()
    private var picking by mutableStateOf(false)
    private var grabResult by mutableStateOf<GrabResult?>(null)
    private var settingsFor by mutableStateOf(-1)
    private var inspectText by mutableStateOf<String?>(null)
    private var cfgTick by mutableStateOf(0)
    private var pendingId = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingId = savedInstanceState?.getInt("pending", -1) ?: -1
        ids.addAll(WidgetKit.savedIds(this))
        save()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    if (picking) Picker() else Main()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pending", pendingId)
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun save() = WidgetKit.saveIds(this, ids.toList())

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    /** True (and the permission screen opens) when A may not draw over other apps yet. */
    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        toast("Allow \"Display over other apps\" for A, then try again")
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return true
    }

    private fun appLabel(info: AppWidgetProviderInfo): String =
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(info.provider.packageName, 0)).toString() }
            .getOrDefault(info.provider.packageName)

    // ---- adding a widget: bind (Android asks once), set up (the widget's own screen), keep ----

    private fun begin(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pendingId = id
        if (mgr.bindAppWidgetIdIfAllowed(id, p.provider)) {
            afterBind(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun afterBind(id: Int) {
        val info = mgr.getAppWidgetInfo(id)
        if (info?.configure != null) {
            val ok = runCatching { host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) }.isSuccess
            if (!ok) {
                toast("The widget's setup screen would not open; added without it")
                finishAdd(id)
            }
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        if (id !in ids) ids.add(id)
        pendingId = -1
        save()
    }

    private fun cancelAdd() {
        if (pendingId != -1) runCatching { host.deleteAppWidgetId(pendingId) }
        pendingId = -1
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val id = pendingId
        if (id == -1) return
        when (requestCode) {
            REQ_BIND -> if (resultCode == RESULT_OK) afterBind(id) else cancelAdd()
            REQ_CONFIG -> if (resultCode == RESULT_OK) finishAdd(id) else cancelAdd()
        }
    }

    // ---- the cells ----

    private fun saveWindowCell() {
        val i = Intent(this, WidgetHostActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ActionSaver.saveToCells(this, "Widgets", "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME))
        toast("Saved to cells")
    }

    private fun saveFloatCell(id: Int, label: String, pkg: String) {
        val i = Intent(this, WidgetFloatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("mode", "show").putExtra("wid", id).putExtra("pkg", pkg)
        ActionSaver.saveToCells(this, label.ifBlank { "Widget" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:$pkg")
        toast("Saved to cells")
    }

    private fun savePressCell(g: GrabResult, label: String, showSec: Int) {
        val i = Intent(this, WidgetFloatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("mode", "press").putExtra("wid", g.wid).putExtra("pkg", g.pkg)
            .putExtra("tap", g.name).putExtra("pos", g.pos).putExtra("show", showSec)
        ActionSaver.saveToCells(this, label.ifBlank { "Tile" }, "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME), "app:" + g.pkg)
        toast("Saved to cells")
    }

    private fun copy(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("A widget", text))
        toast("Copied")
    }

    // ---- screens ----

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun Main() {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Widgets", fontSize = 18.sp)
            Text(
                "1. Add a widget.  2. Tap \"Show floating\" to try it: drag it by its top bar, resize it from the corner.  " +
                    "3. \"Cell: floating\" puts it on your strip.  4. For a widget's button or chat, tap \"Grab a tile\", tap the button, and save the cell.",
                fontSize = 12.sp,
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { picking = true }) { Text("Add widget") }
                OutlinedButton(onClick = { WidgetFloat.closeAll() }) { Text("Close all floating") }
                OutlinedButton(onClick = { saveWindowCell() }) { Text("Cell: this window") }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(ids.toList(), key = { it }) { id -> WidgetCard(id) }
            }
        }
        grabResult?.let { GrabDialog(it) }
        if (settingsFor != -1) SettingsDialog(settingsFor)
        inspectText?.let { InspectDialog(it) }
    }

    @OptIn(ExperimentalLayoutApi::class)
    @Composable
    private fun WidgetCard(id: Int) {
        val info = remember(id) { mgr.getAppWidgetInfo(id) }
        if (info == null) return
        val cfg = remember(id, cfgTick) { WidgetKit.loadCfg(this@WidgetHostActivity, id) }
        val title = cfg.name.ifBlank { appLabel(info) }
        val density = LocalDensity.current
        val startH = with(density) { info.minHeight.toDp().value.toInt() }.coerceAtLeast(110)
        var h by remember(id) { mutableStateOf(prefs.getInt("h$id", startH)) }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 15.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { if (!needOverlay()) WidgetFloat.show(this@WidgetHostActivity, id) }) { Text("Show floating") }
                OutlinedButton(onClick = { settingsFor = id }) { Text("Settings") }
                OutlinedButton(onClick = { saveFloatCell(id, title, info.provider.packageName) }) { Text("Cell: floating") }
                OutlinedButton(onClick = {
                    if (!needOverlay()) {
                        WidgetFloat.grab(this@WidgetHostActivity, id) { name, pos, details ->
                            grabResult = GrabResult(id, name, pos, info.provider.packageName, details)
                        }
                    }
                }) { Text("Grab a tile") }
                OutlinedButton(onClick = { inspectText = frames[id]?.let { WidgetKit.dump(it) } ?: "The widget has not loaded yet." }) { Text("Inspect") }
                OutlinedButton(onClick = {
                    WidgetFloat.close(id)
                    runCatching { host.deleteAppWidgetId(id) }
                    frames.remove(id)
                    ids.remove(id)
                    WidgetKit.forget(this@WidgetHostActivity, id)
                    save()
                }) { Text("Remove") }
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val w = maxWidth.value.toInt()
                AndroidView(
                    factory = { ctx -> host.createView(ctx, id, info).also { frames[id] = it } },
                    update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                    modifier = Modifier.fillMaxWidth().height(h.dp),
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { h = (h - 60).coerceAtLeast(60); prefs.edit().putInt("h$id", h).apply() }) { Text("Shorter preview") }
                TextButton(onClick = { h += 60; prefs.edit().putInt("h$id", h).apply() }) { Text("Taller preview") }
            }
        }
    }

    // ---- small building blocks for the settings ----

    @Composable
    private fun Opts(title: String, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        Column {
            Text(title, fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                labels.forEachIndexed { i, l ->
                    OutlinedButton(onClick = { onPick(i) }) { Text(if (i == selected) "● $l" else l, fontSize = 12.sp) }
                }
            }
        }
    }

    @Composable
    private fun Toggle(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = value, onCheckedChange = onChange)
        }
    }

    @Composable
    private fun Slide(title: String, value: Int, from: Int, to: Int, unit: String, onChange: (Int) -> Unit) {
        Column {
            Text("$title: $value$unit", fontSize = 12.sp)
            Slider(value = value.toFloat(), onValueChange = { onChange(it.toInt()) }, valueRange = from.toFloat()..to.toFloat())
        }
    }

    // ---- floating settings of one widget ----

    @Composable
    private fun SettingsDialog(id: Int) {
        var c by remember(id) { mutableStateOf(WidgetKit.loadCfg(this@WidgetHostActivity, id)) }
        var resetPos by remember(id) { mutableStateOf(false) }
        val autoSecs = listOf(0, 3, 5, 10, 30)
        val tapSecs = listOf(0, 1, 2, 3, 5)
        fun commit() {
            val cur = WidgetKit.loadCfg(this@WidgetHostActivity, id)
            WidgetKit.saveCfg(
                this@WidgetHostActivity, id,
                c.copy(x = if (resetPos) Int.MIN_VALUE else cur.x, y = if (resetPos) Int.MIN_VALUE else cur.y),
            )
            cfgTick++
        }
        AlertDialog(
            onDismissRequest = { settingsFor = -1 },
            title = { Text("Floating widget settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = c.name, onValueChange = { c = c.copy(name = it) }, singleLine = true,
                        label = { Text("Name (shown on the bar and the cell)") }, modifier = Modifier.fillMaxWidth(),
                    )
                    val sizeSel = when {
                        c.wDp == 0 -> 0
                        c.wDp <= 170 -> 1
                        c.wDp <= 280 -> 2
                        else -> 3
                    }
                    Opts("Size (you can also drag the corner when it floats)", listOf("Auto", "Small", "Medium", "Large"), sizeSel) {
                        c = when (it) {
                            0 -> c.copy(wDp = 0, hDp = 0)
                            1 -> c.copy(wDp = 150, hDp = 100)
                            2 -> c.copy(wDp = 260, hDp = 180)
                            else -> c.copy(wDp = 340, hDp = 300)
                        }
                    }
                    if (c.wDp > 0) {
                        Slide("Width", c.wDp, 96, 420, " dp") { c = c.copy(wDp = it) }
                        Slide("Height", c.hDp.coerceAtLeast(64), 64, 700, " dp") { c = c.copy(hDp = it) }
                    }
                    Slide("Opacity", c.opacity, 20, 100, "%") { c = c.copy(opacity = it) }
                    Slide("Rounded corners", c.radius, 0, 32, " dp") { c = c.copy(radius = it) }
                    Opts("Background behind the widget", listOf("None", "Dark", "Light"), c.bg) { c = c.copy(bg = it) }
                    Opts("First position", listOf("Centre", "Top", "Bottom", "Left", "Right"), c.startAt) { c = c.copy(startAt = it) }
                    Toggle("Show the top bar (drag, close, resize)", c.handle) { c = c.copy(handle = it) }
                    Toggle("Lock position and size", c.lock) { c = c.copy(lock = it) }
                    Toggle("Remember where I leave it", c.remember) { c = c.copy(remember = it) }
                    Toggle("Snap to the screen edges", c.snap) { c = c.copy(snap = it) }
                    Toggle("Close when I tap outside it", c.outside) { c = c.copy(outside = it) }
                    Opts("Close after no touch for", autoSecs.map { if (it == 0) "Never" else "${it}s" }, autoSecs.indexOf(c.autoClose).coerceAtLeast(0)) {
                        c = c.copy(autoClose = autoSecs[it])
                    }
                    Opts("Close after I tap something in it", tapSecs.map { if (it == 0) "Off" else "${it}s" }, tapSecs.indexOf(c.afterTap).coerceAtLeast(0)) {
                        c = c.copy(afterTap = tapSecs[it])
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { resetPos = true }) { Text(if (resetPos) "Position will reset" else "Reset position") }
                        TextButton(onClick = {
                            if (!needOverlay()) {
                                commit()
                                WidgetFloat.reopen(this@WidgetHostActivity, id)
                            }
                        }) { Text("Try it now") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { commit(); settingsFor = -1 }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { settingsFor = -1 }) { Text("Cancel") } },
        )
    }

    // ---- save a grabbed tile ----

    @Composable
    private fun GrabDialog(g: GrabResult) {
        var label by remember(g) { mutableStateOf(g.name.ifBlank { "Tile" }) }
        var showIdx by remember(g) { mutableStateOf(2) }
        val secs = listOf(0, 2, 3, 5, 10)
        AlertDialog(
            onDismissRequest = { grabResult = null },
            title = { Text("Save this tile as a cell") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(g.details, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    OutlinedTextField(
                        value = label, onValueChange = { label = it }, singleLine = true,
                        label = { Text("Cell name") }, modifier = Modifier.fillMaxWidth(),
                    )
                    Opts("After pressing it", listOf("Keep it hidden", "Show 2s", "Show 3s", "Show 5s", "Show 10s"), showIdx) { showIdx = it }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            if (!needOverlay()) WidgetFloat.press(this@WidgetHostActivity, g.wid, g.name, g.pos, maxOf(3, secs[showIdx]))
                        }) { Text("Test press") }
                        TextButton(onClick = { copy(g.details) }) { Text("Copy details") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { savePressCell(g, label, secs[showIdx]); grabResult = null }) { Text("Save as a cell") } },
            dismissButton = { TextButton(onClick = { grabResult = null }) { Text("Cancel") } },
        )
    }

    @Composable
    private fun InspectDialog(text: String) {
        AlertDialog(
            onDismissRequest = { inspectText = null },
            title = { Text("What the widget is made of") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("[TAP] marks the tiles that can be pressed.", fontSize = 11.sp)
                    Text(text, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = { TextButton(onClick = { copy(text) }) { Text("Copy") } },
            dismissButton = { TextButton(onClick = { inspectText = null }) { Text("Close") } },
        )
    }

    // ---- picking a widget to add ----

    @Composable
    private fun Picker() {
        BackHandler { picking = false }
        var q by remember { mutableStateOf("") }
        val all = remember {
            val pm = packageManager
            mgr.installedProviders.map { p ->
                val app = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() }.getOrDefault(p.provider.packageName)
                val name = runCatching { p.loadLabel(pm).toString() }.getOrDefault("")
                Triple(p, app, name)
            }.sortedBy { it.second.lowercase() }
        }
        val shown = all.filter { q.isBlank() || it.second.contains(q, true) || it.third.contains(q, true) || it.first.provider.packageName.contains(q, true) }
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Pick a widget", fontSize = 18.sp)
            OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Search (for example eitaa)") }, modifier = Modifier.fillMaxWidth())
            if (shown.isEmpty()) Text("No widgets found.", fontSize = 13.sp)
            LazyColumn(Modifier.weight(1f)) {
                items(shown) { (p, app, name) ->
                    Text(
                        "$app: $name",
                        Modifier.fillMaxWidth().clickable { picking = false; begin(p) }.padding(vertical = 12.dp),
                    )
                }
            }
        }
    }

    private companion object {
        const val REQ_BIND = 7101
        const val REQ_CONFIG = 7102
    }
}
