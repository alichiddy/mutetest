package com.newagedevs.gesturevolume.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.newagedevs.gesturevolume.data.local.SharedPref
import com.newagedevs.gesturevolume.strip.SettingsBackup
import com.newagedevs.gesturevolume.strip.StripConfig
import com.newagedevs.gesturevolume.ui.screens.strip.backupLauncher
import com.newagedevs.gesturevolume.ui.screens.strip.restoreLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The three backups (settings, scripts, everything): save, restore, or make an APK that carries them. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupDialog(pref: SharedPref, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    val backupSettings = backupLauncher(pref.sharedPreferences, true, false, "Settings saved") { status = it }
    val restoreSettings = restoreLauncher(pref.sharedPreferences, true, false, "settings", { }) { status = it }
    val backupScripts = backupLauncher(pref.sharedPreferences, false, true, "Scripts saved") { status = it }
    val restoreScripts = restoreLauncher(pref.sharedPreferences, false, true, "scripts", { }) { status = it }
    val backupAll = backupLauncher(pref.sharedPreferences, true, true, "Everything saved") { status = it }
    val restoreAll = restoreLauncher(pref.sharedPreferences, true, true, "settings and scripts", { }) { status = it }
    fun makeApk(name: String, settings: Boolean, scripts: Boolean) {
        status = "Making the APK…"
        val strip = if (scripts) StripConfig.load(context, pref.getStripConfigJson()).toJson() else null
        val all = if (settings) SettingsBackup.toJson(pref.sharedPreferences, true, false) else null
        scope.launch {
            status = withContext(Dispatchers.IO) {
                com.newagedevs.gesturevolume.strip.ApkCloner.make(context.applicationContext, name, strip, all)
            }
        }
    }
    var autoOn by remember { mutableStateOf(com.newagedevs.gesturevolume.strip.AutoBackup.enabled(context)) }
    var files by remember { mutableStateOf<List<com.newagedevs.gesturevolume.strip.AutoBackup.Entry>?>(null) }
    var chosen by remember { mutableStateOf<com.newagedevs.gesturevolume.strip.AutoBackup.Entry?>(null) }
    fun restoreFrom(e: com.newagedevs.gesturevolume.strip.AutoBackup.Entry, settings: Boolean, scripts: Boolean) {
        val json = com.newagedevs.gesturevolume.strip.AutoBackup.read(context, e)
        status = if (json == null) "Could not read ${e.name}" else {
            val n = SettingsBackup.apply(pref.sharedPreferences, json, settings, scripts)
            when {
                n < 0 -> "${e.name} is not a backup"
                n == 0 -> "${e.name} holds nothing of that part"
                else -> "Restored $n items from ${e.name}"
            }
        }
        chosen = null
    }
    if (chosen != null) {
        val e = chosen!!
        AlertDialog(
            onDismissRequest = { chosen = null },
            title = { Text("Restore ${e.name.removePrefix("A settings ").removeSuffix(".json")}") },
            text = { Text("What should be restored from this file?") },
            confirmButton = {
                Column {
                    TextButton(onClick = { restoreFrom(e, false, true) }) { Text("Only scripts (the cells, their shortcuts and scripts)") }
                    TextButton(onClick = { restoreFrom(e, true, false) }) { Text("Only settings (everything except the cells)") }
                    TextButton(onClick = { restoreFrom(e, true, true) }) { Text("Both (all settings)") }
                }
            },
            dismissButton = { TextButton(onClick = { chosen = null }) { Text("Cancel") } },
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Backups") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Settings (everything except the cells)", fontWeight = FontWeight.SemiBold)
                FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { backupSettings.launch("A only settings.json") }) { Text("Backup") }
                    OutlinedButton(onClick = { restoreSettings.launch(arrayOf("*/*")) }) { Text("Restore") }
                    OutlinedButton(onClick = { makeApk("A only settings.apk", true, false) }) { Text("Make APK") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Scripts (the cells: shortcuts, flows, layout)", fontWeight = FontWeight.SemiBold)
                FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { backupScripts.launch("A only scripts.json") }) { Text("Backup") }
                    OutlinedButton(onClick = { restoreScripts.launch(arrayOf("*/*")) }) { Text("Restore") }
                    OutlinedButton(onClick = { makeApk("A only scripts.apk", false, true) }) { Text("Make APK") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Everything (settings and scripts)", fontWeight = FontWeight.SemiBold)
                FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { backupAll.launch("A all settings.json") }) { Text("Backup") }
                    OutlinedButton(onClick = { restoreAll.launch(arrayOf("*/*")) }) { Text("Restore") }
                    OutlinedButton(onClick = { makeApk("A all settings.apk", true, true) }) { Text("Make APK") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Automatic backup", fontWeight = FontWeight.SemiBold)
                androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Save a copy to Download/settings after I change settings (last 5 kept)", Modifier.weight(1f), fontSize = 13.sp)
                    androidx.compose.material3.Switch(checked = autoOn, onCheckedChange = {
                        autoOn = it
                        pref.sharedPreferences.edit().putBoolean(com.newagedevs.gesturevolume.strip.AutoBackup.ON, it).apply()
                        com.newagedevs.gesturevolume.strip.AutoBackup.refresh(context)
                        if (it) scope.launch(Dispatchers.IO) {
                            com.newagedevs.gesturevolume.strip.AutoBackup.save(context)
                            files = com.newagedevs.gesturevolume.strip.AutoBackup.list(context)
                        }
                    })
                }
                FlowRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        scope.launch { files = withContext(Dispatchers.IO) { com.newagedevs.gesturevolume.strip.AutoBackup.list(context) } }
                    }) { Text("Check files") }
                }
                files?.let { list ->
                    if (list.isEmpty()) Text("No saved files found in Download/settings.", fontSize = 12.sp)
                    list.forEach { e ->
                        OutlinedButton(onClick = { chosen = e }, modifier = Modifier.fillMaxWidth()) {
                            Text(e.name.removePrefix("A settings ").removeSuffix(".json"), fontSize = 13.sp)
                        }
                    }
                }
                if (status.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
