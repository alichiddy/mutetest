package a.a.utils

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * A small diary of what went wrong, and a report that can be copied and sent.
 *
 * The report says what phone this is, which permissions and settings are in place, what each
 * audio stream looks like, the app's own recent notes, and the app's own warnings and errors from
 * the system log (an app may read its own lines of the log without any permission).
 */
object DiagLog {
    private class Note(val at: Long, val text: String)
    private val lines = ArrayDeque<Note>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun note(text: String) {
        if (lines.size >= 400) lines.removeFirst()
        lines.addLast(Note(System.currentTimeMillis(), text))
    }

    /** What a copied report holds. [seconds] how far back to look, 0 = everything. */
    class ReportOptions(
        val seconds: Int = 300,
        val phone: Boolean = false,
        val settings: Boolean = false,
        val audio: Boolean = false,
        val saved: Boolean = true,
        val notes: Boolean = true,
        val system: Boolean = false,
        val disconnects: Boolean = false,
        val appLog: Boolean = true,
        /** The "Screenshot diagnostics" part: every screenshot attempt, why it failed, no pictures. */
        val screenshot: Boolean = true,
    )

    private val stampFmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    /** The time at the start of a log line ("MM-dd HH:mm:ss..."), this year, or null. */
    private fun stampOf(line: String): Long? {
        if (line.length < 14) return null
        val t = runCatching { stampFmt.parse(line.substring(0, 14)) }.getOrNull() ?: return null
        val c = java.util.Calendar.getInstance()
        val year = c.get(java.util.Calendar.YEAR)
        c.time = t
        c.set(java.util.Calendar.YEAR, year)
        // A line from late December read in early January belongs to last year.
        if (c.timeInMillis > System.currentTimeMillis() + 86_400_000L) c.set(java.util.Calendar.YEAR, year - 1)
        return c.timeInMillis
    }

    private fun recent(lines: List<String>, since: Long): List<String> =
        if (since <= 0L) lines else lines.filter { (stampOf(it) ?: Long.MAX_VALUE) >= since }

    /**
     * A note that survives the process being killed: kept in a small private file, newest last,
     * so the next report can say what happened before the app last died.
     */
    fun persist(context: Context, text: String) {
        attach(context)
        note(text)
        runCatching {
            val f = java.io.File(context.filesDir, "events.log")
            val old = if (f.exists()) f.readLines().takeLast(60) else emptyList()
            f.writeText((old + "${java.text.SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())} $text").joinToString("\n") + "\n")
        }
    }

    /**
     * A watched system setting changed (the accessibility list, the Do Not Disturb access list): note
     * what was removed and added and, through Shizuku, which processes had just started, so the app
     * that rewrote it can be found. Runs on its own short thread.
     */
    fun noteSettingChange(context: Context, label: String, old: String, now: String, sep: Char) {
        val before = old.split(sep).filter { it.isNotEmpty() }.toSet()
        val after = now.split(sep).filter { it.isNotEmpty() }.toSet()
        if (before == after) return
        // For the accessibility list: was A taken out alone (what its switch in Settings does), or was the
        // whole list replaced by another app or flow (A dropped along with other changes)?
        val mine = before.filter { it.startsWith(context.packageName + "/") }.toSet()
        val verdict = if (label.startsWith("Accessibility") && mine.isNotEmpty() && (after.none { it.startsWith(context.packageName + "/") })) {
            if ((before - after) == mine && (after - before).isEmpty()) "  -> A's entry was removed ALONE (like its switch in Settings)"
            else "  -> the LIST WAS REPLACED: A's entry went with other changes (an app or flow wrote the whole list)"
        } else ""
        persist(context, "$label changed: removed=${before - after} added=${after - before}$verdict")
        Thread {
            val sb = StringBuilder()
            sb.append("---- $label changed at ${SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
            sb.append("removed: ${before - after}\nadded: ${after - before}\n$verdict\n")
            if (ShizukuShell.isReady()) {
                for (c in listOf(
                    "logcat -d -b events -t 600 | grep -E 'am_proc_start|am_proc_died' | tail -14",
                    "dumpsys activity activities | grep -E 'mResumedActivity' | head -2",
                )) {
                    sb.append("$ ").append(c.take(80)).append('\n')
                    runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }
                }
            } else sb.append("(Shizuku not ready: only the change itself is recorded)\n")
            runCatching {
                val f = java.io.File(context.filesDir, "unbind.txt")
                val old2 = if (f.exists()) f.readText().takeLast(30000) else ""
                f.writeText(old2 + sb.toString())
            }
        }.start()
    }

    /**
     * When the system disconnects the service: what the settings now say, which app was in front,
     * and, through Shizuku, the system log around that moment (who touched what). Kept in a file
     * the report includes. Runs once per disconnection, on its own short thread.
     */
    fun captureUnbind(context: Context) {
        val settingNow = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull()
        persist(context, "  at disconnect, settings list = $settingNow")
        Thread {
            val sb = StringBuilder()
            sb.append("---- disconnect at ${SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())}\n")
            sb.append("settings list: $settingNow\n")
            if (ShizukuShell.isReady()) {
                val cmds = listOf(
                    "dumpsys activity activities | grep -E 'topResumedActivity|mResumedActivity' | head -3",
                    "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -3",
                    "settings get secure enabled_accessibility_services; settings get secure accessibility_enabled",
                    "dumpsys accessibility 2>&1 | grep -i -E '${context.packageName}|crashed|bound|enabled' | head -40",
                    "dumpsys package ${context.packageName} | grep -E 'firstInstallTime|lastUpdateTime|versionName' ; echo pid=\$(pidof ${context.packageName})",
                    "L=\$(logcat -d -b all -t 6000 | grep -E 'START u0|startActivity|Accessibility(Settings|SubSettings)' | grep -i -E 'settings' | tail -6); echo \"\$L\"; for u in \$(echo \"\$L\" | grep -o -E '(from uid|callingUid=|uid=)[ ]?[0-9]+' | grep -o -E '[0-9]+' | sort -u); do pm list packages --uid \$u; done",
                    "logcat -d -b all -t 1500 | grep -v -E 'AccessibilityDelegate|resource failed|ImeFocus|inline cache' | grep -i -E 'accessib|a11y|a\\.a|settings|pem|imanager|ActivityTaskManager|ActivityManager|PackageManager|Binder' | tail -80",
                )
                for (c in cmds) {
                    sb.append("$ ").append(c.take(220)).append('\n')
                    runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }
                }
            } else sb.append("(Shizuku not ready: no system log captured)\n")
            runCatching {
                val f = java.io.File(context.filesDir, "unbind.txt")
                val old = if (f.exists()) f.readText().takeLast(30000) else ""
                f.writeText(old + sb.toString())
            }
        }.start()
    }

    /** Written once each time the app process starts, with what the settings say about the service. */
    fun processStarted(context: Context) {
        attach(context)
        val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        persist(context, "process started; accessibility in settings=${enabled.contains(context.packageName)}")
    }

    /** After a report is copied the next one starts from scratch: notes, saved events and disconnect captures. */
    fun clear(context: Context) {
        synchronized(this) {
            lines.clear()
            shots.clear()
            shotOk = 0; shotFailed = 0; shotSkipped = 0
            shotLastOkAt = 0L; shotLastFailAt = 0L; shotLastFailWhy = ""
        }
        runCatching { java.io.File(context.filesDir, "events.log").delete() }
        runCatching { java.io.File(context.filesDir, SHOT_FILE).delete() }
        runCatching { java.io.File(context.filesDir, "unbind.txt").delete() }
        runCatching { Runtime.getRuntime().exec(arrayOf("logcat", "-c")) }
    }

    fun e(what: String, error: Throwable) = note("ERROR $what: ${error.javaClass.simpleName}: ${error.message}")

    /** A volume write that raised no error but left the level where it was is the Realme-type failure. */
    fun verify(manager: AudioManager, stream: Int, wanted: Int) {
        val now = runCatching { manager.getStreamVolume(stream) }.getOrNull() ?: return
        if (now == wanted) return
        note("WRITE IGNORED stream=$stream wanted=$wanted now=$now fixed=${runCatching { manager.isVolumeFixed }.getOrNull()} mode=${runCatching { manager.mode }.getOrNull()}")
        // Another route: the relative adjust, one step at a time. Some ROMs (Realme) drop the
        // absolute write but honour this.
        runCatching {
            var guard = 0
            var cur = now
            while (cur != wanted && guard++ < 40) {
                manager.adjustStreamVolume(stream, if (wanted > cur) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
                val next = manager.getStreamVolume(stream)
                if (next == cur) break
                cur = next
            }
            if (cur == wanted) { note("WRITE FIXED by adjustStreamVolume stream=$stream now=$cur"); return }
        }
        // Last route: the system's own command through Shizuku, off the main thread.
        if (ShizukuShell.isReady()) Thread {
            runCatching {
                ShizukuShell.run("cmd media_session volume --stream $stream --set $wanted") { }
                val after = manager.getStreamVolume(stream)
                note(if (after == wanted) "WRITE FIXED by cmd media_session stream=$stream now=$after" else "WRITE still ignored after cmd media_session stream=$stream now=$after")
            }
        }.start()
        else note("WRITE not fixed: no Shizuku for the last route")
    }

    // ---- Screenshot diagnostics -------------------------------------------------------------
    // Every attempt to get a picture of the screen is written down as a ShotRun: which method was
    // tried, what Shizuku and the phone looked like, what the command or call returned, and how it
    // ended. Only facts about the attempt are kept (sizes, times, exit codes, error names), never the
    // picture and never anything read from the screen. At most SHOT_KEEP runs are held in memory, and
    // identical repeats are folded into one ("x87"), so a loop that fails every 300 ms cannot flood
    // the report. New distinct problems are also saved to a small file, so they survive the app
    // being killed (the report shows those from earlier processes too).

    private const val SHOT_KEEP = 40
    private const val SHOT_FILE = "shots.log"

    /** One screenshot attempt (or one note about a picture). Built by [shotBegin], closed by [shotEnd]. */
    class ShotRun internal constructor(val seq: Int, val caller: String, val kind: Int) {
        val api = Build.VERSION.SDK_INT
        val at = System.currentTimeMillis()
        var lastAt = at
        var repeat = 1
        var ok = false
        var width = 0
        var height = 0
        var maxMs = 0L
        var verdict = ""
        val steps = ArrayList<String>(8)

        /** One fact about this attempt, with the time since it began. Bounded: 14 steps of 300 characters. */
        fun step(text: String) {
            if (steps.size < 14) steps.add("+${System.currentTimeMillis() - at}ms " + text.replace(Regex("\\s+"), " ").trim().take(300))
        }
    }

    private const val SHOT_ATTEMPT = 0
    private const val SHOT_NOT_STARTED = 1
    private const val SHOT_NOTE = 2

    private val shots = ArrayDeque<ShotRun>()
    private var shotSeq = 0
    private var shotOk = 0
    private var shotFailed = 0
    private var shotSkipped = 0
    private var shotLastOkAt = 0L
    private var shotLastFailAt = 0L
    private var shotLastFailWhy = ""
    @Volatile private var appContext: Context? = null

    /** Lets the screenshot diary save problems to a file, and read the power state, without a Context at every call. */
    fun attach(context: Context) { appContext = context.applicationContext }

    /** The phone's power state right now: what a power-saving mode would show up as. */
    private fun powerState(context: Context?): String {
        if (context == null) return "power state unknown (no context yet)"
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return "power state unavailable"
        val idle = if (Build.VERSION.SDK_INT >= 23) runCatching { pm.isDeviceIdleMode }.getOrNull() else null
        val ignoring = if (Build.VERSION.SDK_INT >= 23) runCatching { pm.isIgnoringBatteryOptimizations(context.packageName) }.getOrNull() else null
        return "powerSave=${runCatching { pm.isPowerSaveMode }.getOrNull()} interactive=${runCatching { pm.isInteractive }.getOrNull()} deviceIdle=$idle ignoringBatteryOptimizations=$ignoring"
    }

    /**
     * What can be known about Shizuku without its source: ShizukuShell.isReady() and, when Shizuku's
     * own API class is present in the app, whether its binder answers and whether this app holds the
     * permission. Never throws.
     */
    fun shizukuState(): String {
        val ready = runCatching { ShizukuShell.isReady() }
        val head = "isReady=" + (ready.getOrNull() ?: ("error " + ready.exceptionOrNull()?.javaClass?.simpleName))
        val api = runCatching {
            val c = Class.forName("rikka.shizuku.Shizuku")
            val binder = c.getMethod("pingBinder").invoke(null)
            val perm = runCatching { c.getMethod("checkSelfPermission").invoke(null) }
            "binder=$binder permission=" + perm.fold(
                { p -> if (p == 0) "granted" else if (p == -1) "denied" else p.toString() },
                { t -> "unknown (" + ((t as? java.lang.reflect.InvocationTargetException)?.cause ?: t).javaClass.simpleName + ")" },
            )
        }.getOrElse { "binder/permission not readable (" + it.javaClass.simpleName + ")" }
        return "$head $api"
    }

    /** Starts the record of one screenshot attempt by [caller] (who asked: "snap", "read", "system-action"...). */
    fun shotBegin(caller: String): ShotRun {
        val seq = synchronized(this) { ++shotSeq }
        val run = ShotRun(seq, caller, SHOT_ATTEMPT)
        run.step("state: " + powerState(appContext))
        return run
    }

    /** A screenshot that was asked for but never started, with the reason (a permission or Shizuku was missing). */
    fun shotNotStarted(caller: String, why: String) {
        val seq = synchronized(this) { ++shotSeq }
        val run = ShotRun(seq, caller, SHOT_NOT_STARTED)
        run.step(why)
        shotEnd(run, false, verdict = why)
    }

    /** A note about a picture that is not an attempt itself (a cut that failed, a size that did not match). [ok] false = a problem. */
    fun shotNote(caller: String, ok: Boolean, text: String) {
        val seq = synchronized(this) { ++shotSeq }
        val run = ShotRun(seq, caller, SHOT_NOTE)
        run.step(text)
        shotEnd(run, ok, verdict = text)
    }

    /** Closes a record. [verdict] is one short line: what happened and, when known, why. Keep it free of timings so repeats fold together. */
    fun shotEnd(run: ShotRun, ok: Boolean, width: Int = 0, height: Int = 0, verdict: String) {
        val now = System.currentTimeMillis()
        run.ok = ok
        run.width = width
        run.height = height
        run.verdict = verdict.replace(Regex("\\s+"), " ").trim().take(220)
        run.maxMs = now - run.at
        var saveLine: String? = null
        synchronized(this) {
            when (run.kind) {
                SHOT_ATTEMPT -> if (ok) { shotOk++; shotLastOkAt = now } else { shotFailed++; shotLastFailAt = now; shotLastFailWhy = run.verdict }
                SHOT_NOT_STARTED -> { shotSkipped++; shotLastFailAt = now; shotLastFailWhy = "not started: " + run.verdict }
            }
            val last = shots.peekLast()
            if (last != null && last.kind == run.kind && last.ok == run.ok && last.caller == run.caller &&
                last.verdict == run.verdict && last.width == run.width && last.height == run.height
            ) {
                last.repeat++
                last.lastAt = now
                if (run.maxMs > last.maxMs) last.maxMs = run.maxMs
            } else {
                if (shots.size >= SHOT_KEEP) shots.removeFirst()
                shots.addLast(run)
                if (!run.ok) {
                    saveLine = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date(run.at)) +
                        " pid=${android.os.Process.myPid()} #${run.seq} caller=${run.caller} api=${run.api} ${label(run)}: ${run.verdict} | " +
                        run.steps.joinToString(" ; ").take(900)
                }
            }
        }
        val line = saveLine ?: return
        val ctx = appContext ?: return
        synchronized(this) {
            runCatching {
                val f = java.io.File(ctx.filesDir, SHOT_FILE)
                val old = if (f.exists()) f.readLines().takeLast(SHOT_KEEP) else emptyList()
                f.writeText((old + line).joinToString("\n") + "\n")
            }
        }
    }

    private fun label(r: ShotRun): String = when (r.kind) {
        SHOT_NOT_STARTED -> "NOT STARTED"
        SHOT_NOTE -> if (r.ok) "NOTE" else "PROBLEM"
        else -> if (r.ok) "OK" else "FAILED"
    }

    /** The "Screenshot diagnostics" part of a report. Bounded by SHOT_KEEP runs of at most 14 short steps each. */
    private fun screenshotSection(context: Context, since: Long): String {
        val sb = StringBuilder()
        fun line(s: String = "") = sb.append(s).append('\n')
        val tf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
        line("== Screenshot diagnostics ==")
        line("Phone: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
        line("Capture methods this build calls (only these are instrumented):")
        line("  1. Shizuku shell: \"screencap -p | base64\", decoded to a bitmap (ScreenOcr.capture: OCR shortcut, box reading, picture teaching).")
        line("  2. Accessibility action TAKE_SCREENSHOT (performSystemAction, API 28+): asks the system to take its own screenshot. true means the request was accepted, not that an image was saved; the app gets no image from it.")
        line("  ScreenOcr.kt and GestureAccessibilityService.kt contain no other capture call (no takeScreenshot(), MediaProjection or ImageReader).")
        val a11y = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
        line("Now: shizuku ${shizukuState()} | accessibility service enabled in settings=${a11y.contains(context.packageName)} | ${powerState(context)}")
        val (mine, counts) = synchronized(this) {
            Pair(
                shots.filter { since <= 0L || it.lastAt >= since },
                "$shotOk ok, $shotFailed failed, $shotSkipped not started" +
                    (if (shotLastOkAt > 0L) "; last ok ${tf.format(Date(shotLastOkAt))}" else "; no successful capture yet") +
                    (if (shotLastFailAt > 0L) "; last problem ${tf.format(Date(shotLastFailAt))} ($shotLastFailWhy)" else ""),
            )
        }
        line("Since this app process started: $counts")
        if (mine.isEmpty()) {
            line("No screenshot attempt in this time window${if (since > 0L) " (widen \"How far back\" to see older ones)" else ""}.")
        } else {
            line("Attempts in this window, oldest first (identical repeats are folded into one entry):")
            for (r in mine) {
                val rep = if (r.repeat > 1) " x${r.repeat} until ${tf.format(Date(r.lastAt))}" else ""
                line("${tf.format(Date(r.at))} #${r.seq} caller=${r.caller} api=${r.api} ${label(r)}: ${r.verdict}$rep (up to ${r.maxMs} ms)")
                r.steps.forEach { line("      $it") }
            }
        }
        val saved = recent(runCatching { java.io.File(context.filesDir, SHOT_FILE).readLines() }.getOrDefault(emptyList()), since)
            .filter { !it.contains(" pid=${android.os.Process.myPid()} ") }
        if (saved.isNotEmpty()) {
            line("Problems saved by earlier runs of the app (before this process started):")
            saved.takeLast(SHOT_KEEP).forEach { line("  $it") }
        }
        return sb.toString()
    }

    fun report(context: Context): String = report(context, ReportOptions())

    fun report(context: Context, o: ReportOptions): String {
        attach(context)
        val since = if (o.seconds <= 0) 0L else System.currentTimeMillis() - o.seconds * 1000L
        val sb = StringBuilder()
        fun line(s: String) = sb.append(s).append('\n')
        line("== A report: ${if (o.seconds <= 0) "everything kept" else "last ${o.seconds / 60} min ${o.seconds % 60} s"}, made ${SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())} ==")
        runCatching {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            line("App: ${context.packageName} ${info.versionName}")
        }
        if (o.phone) {
            line("Phone: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE}), Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
            line("Build: ${Build.DISPLAY}")
        }
        if (o.settings) {
            line("Volume boost: ${VolumeBoost.status()}")
            line("Overlay allowed: ${runCatching { Settings.canDrawOverlays(context) }.getOrNull()}")
            line("Write settings allowed: ${runCatching { Settings.System.canWrite(context) }.getOrNull()}")
            line("Notification policy (DND) access: ${runCatching { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted }.getOrNull()}")
            val enabled = runCatching { Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }.getOrNull() ?: ""
            line("Accessibility service on: ${enabled.contains(context.packageName)}")
        }
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (o.audio && audio != null) {
            line("Audio mode: ${runCatching { audio.mode }.getOrNull()}  volume fixed: ${runCatching { audio.isVolumeFixed }.getOrNull()}  music active: ${runCatching { audio.isMusicActive }.getOrNull()}")
            val names = listOf(
                AudioManager.STREAM_MUSIC to "music", AudioManager.STREAM_RING to "ring",
                AudioManager.STREAM_NOTIFICATION to "notification", AudioManager.STREAM_ALARM to "alarm",
                AudioManager.STREAM_VOICE_CALL to "call", AudioManager.STREAM_SYSTEM to "system",
            )
            for ((s, n) in names) {
                line("Stream $n: ${runCatching { audio.getStreamVolume(s) }.getOrNull()} of ${if (Build.VERSION.SDK_INT >= 28) runCatching { audio.getStreamMinVolume(s) }.getOrNull() else 0}..${runCatching { audio.getStreamMaxVolume(s) }.getOrNull()}")
            }
            // A harmless live test: set music to its current value and see whether the call is accepted.
            val cur = runCatching { audio.getStreamVolume(AudioManager.STREAM_MUSIC) }.getOrNull()
            if (cur != null) {
                val res = runCatching { audio.setStreamVolume(AudioManager.STREAM_MUSIC, cur, 0) }
                line("Test write of music volume: ${if (res.isSuccess) "accepted" else "REFUSED " + res.exceptionOrNull()}")
            }
        }
        if (o.screenshot) {
            line("")
            sb.append(screenshotSection(context, since))
        }
        if (o.saved) {
            val ev = recent(runCatching { java.io.File(context.filesDir, "events.log").readLines() }.getOrDefault(emptyList()), since)
            if (ev.isNotEmpty()) { line(""); line("== Saved events =="); ev.forEach { line(it) } }
        }
        if (o.system) {
            line("")
            line("== Why the system ended this app's earlier processes (not time-filtered) ==")
            sb.append(systemView(context))
        }
        if (o.disconnects) {
            val raw = runCatching { java.io.File(context.filesDir, "unbind.txt").readText().takeLast(30000) }.getOrDefault("")
            val blocks = raw.split("---- ").filter { it.isNotBlank() }.map { "---- $it" }
                .filter { since <= 0L || (stampOf(it.removePrefix("---- ").substringAfter(" at ", "")) ?: Long.MAX_VALUE) >= since }
            if (blocks.isNotEmpty()) { line(""); line("== System view at each disconnection =="); blocks.forEach { sb.append(it.take(9000)) } }
        }
        if (o.notes) {
            val n = synchronized(this) { lines.filter { it.at >= since }.map { "${clock.format(Date(it.at))} ${it.text}" } }
            if (n.isNotEmpty()) { line(""); line("== The app's own notes =="); n.forEach { line(it) } }
        }
        if (o.appLog) {
            val l = recent(ownLog().lines(), since).filter { it.isNotBlank() }
            if (l.isNotEmpty()) { line(""); line("== The app's log (warnings and errors) =="); l.forEach { line(it) } }
        }
        return sb.toString()
    }

    /** With Shizuku: Android's own record of why this app's processes ended, and of the service. */
    private fun systemView(context: Context): String {
        if (!ShizukuShell.isReady()) return "(Shizuku is not running or not allowed, so the system's own record is not available. Start Shizuku and copy the report again.)\n"
        val pkg = context.packageName
        val sb = StringBuilder()
        val cmds = listOf(
            "dumpsys activity exit-info $pkg 2>&1 | head -60",
            "logcat -d -b crash -t 120",
            "dumpsys accessibility 2>&1 | grep -i -E '$pkg|crashed|bound|enabled' | head -30",
            "logcat -d -b all -t 4000 2>&1 | grep -i -E 'accessibility.*($pkg|disabl|crash|unbind)|$pkg.*(died|kill|force|disabl)|(kill|force).*$pkg' | tail -40",
        )
        for (c in cmds) {
            sb.append("$ ").append(c.substringBefore(" 2>&1")).append('\n')
            runCatching { ShizukuShell.run(c) { sb.append(it).append('\n') } }.onFailure { sb.append("failed: ${it.message}\n") }
        }
        return sb.toString()
    }

    private fun ownLog(): String = runCatching {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", "300", "-v", "time", "*:W"))
        p.inputStream.bufferedReader().use { it.readText() }.ifBlank { "(empty)" }
    }.getOrElse { "(could not read the log: ${it.message})" }
}
