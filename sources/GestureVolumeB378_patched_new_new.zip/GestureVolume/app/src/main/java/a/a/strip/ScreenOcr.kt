package a.a.strip

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import a.a.utils.DiagLog
import a.a.utils.ShizukuShell
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Reads digits from any part of the screen (a widget, a USSD window, any app). The person drags a
 * box over what to read; A then takes screenshots through Shizuku, cuts out that box and reads it
 * with [OtpOcr] until the same digits show up twice in a row. Nothing stays in memory afterwards.
 */
object ScreenOcr {
    class Region(val rect: Rect, val screenW: Int, val screenH: Int)

    private fun pos(app: Context) = app.getSharedPreferences("otp_ocr_pos", Context.MODE_PRIVATE)

    /** Remembers a box as fractions of the screen, so the shortcut can read the same place again by itself. */
    fun saveRegion(app: Context, r: Region) {
        val w = r.screenW.coerceAtLeast(1).toFloat()
        val h = r.screenH.coerceAtLeast(1).toFloat()
        pos(app).edit().putFloat("l", r.rect.left / w).putFloat("t", r.rect.top / h)
            .putFloat("r", r.rect.right / w).putFloat("b", r.rect.bottom / h).apply()
    }

    fun savedRegion(app: Context): Region? {
        val p = pos(app)
        if (!p.contains("l")) return null
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val box = Rect((p.getFloat("l", 0f) * w).toInt(), (p.getFloat("t", 0f) * h).toInt(), (p.getFloat("r", 1f) * w).toInt(), (p.getFloat("b", 1f) * h).toInt())
        return if (box.width() < 10 || box.height() < 10) null else Region(box, w, h)
    }

    // ---- Named boxes ("Box 1", "156"...): each is a part of the screen kept as fractions of it.
    // The OCR shortcut picks one by name and reads it by itself.
    private fun boxes(app: Context) = app.getSharedPreferences("ocr_boxes", Context.MODE_PRIVATE)

    fun cleanName(s: String): String = s.replace(Regex("[:|\\n\\r]"), "").trim().take(40)

    fun boxNames(app: Context): List<String> =
        boxes(app).all.keys.sortedWith(compareBy<String>({ it.toIntOrNull() ?: Int.MAX_VALUE }, { it.lowercase() }))

    fun nextName(app: Context): String {
        val have = boxNames(app).toSet()
        var n = 1
        while ("Box $n" in have) n++
        return "Box $n"
    }

    fun saveBox(app: Context, name: String, r: Region) {
        val w = r.screenW.coerceAtLeast(1).toFloat()
        val h = r.screenH.coerceAtLeast(1).toFloat()
        val v = "${r.rect.left / w},${r.rect.top / h},${r.rect.right / w},${r.rect.bottom / h}"
        val clean = cleanName(name)
        boxes(app).edit().putString(clean, v).apply()
        aliases(app).edit().remove(clean).apply()   // a box with this name exists again: it is not an old name any more
    }

    // Old names of renamed boxes: a shortcut or script that still says the old name finds the box.
    private fun aliases(app: Context) = app.getSharedPreferences("ocr_box_aliases", Context.MODE_PRIVATE)

    /** The box's current name for [name], which may be an old name of a renamed box; [name] itself when unknown. */
    fun currentName(app: Context, name: String): String {
        val b = boxes(app)
        val al = aliases(app)
        var n = name
        var hops = 0
        while (!b.contains(n) && hops < 8) {
            n = al.getString(n, null) ?: return name
            hops++
        }
        return if (b.contains(n)) n else name
    }

    fun box(app: Context, name: String): Region? {
        val p = boxes(app).getString(currentName(app, name), null)?.split(',')?.mapNotNull { it.toFloatOrNull() } ?: return null
        if (p.size != 4) return null
        val dm = app.resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val rect = Rect((p[0] * w).toInt(), (p[1] * h).toInt(), (p[2] * w).toInt(), (p[3] * h).toInt())
        return if (rect.width() < 10 || rect.height() < 10) null else Region(rect, w, h)
    }

    fun deleteBox(app: Context, name: String) { boxes(app).edit().remove(name).apply() }

    /** False when the new name is empty or already used. */
    fun renameBox(app: Context, old: String, newName: String): Boolean {
        val n = cleanName(newName)
        val sp = boxes(app)
        val v = sp.getString(old, null) ?: return false
        if (n.isEmpty() || (n != old && sp.contains(n))) return false
        sp.edit().remove(old).putString(n, v).apply()
        if (n != old) {
            val al = aliases(app).edit()
            al.remove(n)
            al.putString(old, n)
            al.apply()
        }
        return true
    }

    fun saveWidget(app: Context, id: Int) { pos(app).edit().putInt("wid", id).apply() }

    /** The widget the shortcut reads: the one floating on the screen now, or the chosen one, or the first saved. */
    fun widgetFor(app: Context, now: Boolean): Int {
        if (now) { val open = WidgetFloat.firstOpenId(); if (open >= 0) return open }
        val saved = WidgetKit.savedIds(app)
        val chosen = pos(app).getInt("wid", -1)
        return if (chosen in saved) chosen else (saved.firstOrNull() ?: -1)
    }

    /** The message of a USSD window (not its buttons), read through the text reader. Blocking. */
    fun readUssd(app: Context): String {
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        if (!TextReaderControl.ensureOnBlocking(app, 3000)) throw IllegalStateException("The text reader could not be switched on")
        val limit = System.currentTimeMillis() + 12000
        try {
            while (System.currentTimeMillis() < limit) {
                val t = runCatching { TextReaderService.instance?.ussdText() }.getOrNull().orEmpty()
                if (t.isNotBlank()) return ScreenCopy.normalize(t)
                pause(400)
            }
        } finally {
            TextReaderControl.offLater(app, 1500)
        }
        throw IllegalStateException("No USSD screen was found")
    }

    private fun toast(app: Context, text: String) {
        Handler(Looper.getMainLooper()).post { WidgetFloat.toast(app, text) }
    }

    /** When the extra look at screencap's own error message last ran (see [probeScreencap]). */
    private var lastProbeAt = 0L

    /** After a capture that printed nothing, run screencap once more (picture thrown away) to read its error and exit code. Set to false to switch that off. */
    private const val PROBE_AFTER_FAILURE = true

    /**
     * A screenshot through Shizuku. Blocking; null when it fails.
     *
     * Every attempt is written to A's report ("Screenshot diagnostics"): the Shizuku state, the
     * command's exit code and output size, the image size, and why it failed. [caller] only labels
     * the attempt there. No pixels or screen contents are ever recorded.
     */
    fun capture(caller: String = "capture"): Bitmap? {
        val run = DiagLog.shotBegin(caller)
        fun fail(why: String): Bitmap? {
            DiagLog.shotEnd(run, false, verdict = why)
            return null
        }
        try {
            run.step("method 1/1 shizuku-screencap: screencap -p | base64. shizuku: " + DiagLog.shizukuState())
            if (!ShizukuShell.isReady()) return fail("Shizuku is not ready, so screencap was not run")
            val sb = StringBuilder()
            val t0 = System.currentTimeMillis()
            val rc: Any? = ShizukuShell.run("screencap -p | base64") { sb.append(it) }
            val took = System.currentTimeMillis() - t0
            val exit = when (rc) {
                is Int -> "exit=$rc"
                is Unit, null -> "exit code not reported by ShizukuShell.run"
                else -> "returned $rc"
            }
            run.step("command finished in $took ms; $exit; ${sb.length} characters of output")
            if (sb.isEmpty()) {
                probeScreencap(run)
                return fail("screencap printed nothing ($exit), so no image data reached the app")
            }
            val bytes = try {
                Base64.decode(sb.toString(), Base64.DEFAULT)
            } catch (e: Throwable) {
                run.step("Base64 decode failed: " + e.javaClass.simpleName + ": " + e.message)
                return fail("the output is not valid base64 (" + e.javaClass.simpleName + ")")
            }
            val png = bytes.size >= 4 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() && bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte()
            run.step("decoded to ${bytes.size} bytes; first bytes " + bytes.take(8).joinToString(" ") { "%02X".format(it) } + "; PNG signature " + (if (png) "present" else "MISSING"))
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: return fail("the image could not be decoded (${bytes.size} bytes, PNG signature ${if (png) "present" else "missing"})")
            val look = describePixels(bmp)
            run.step("decoded image ${bmp.width}x${bmp.height}; $look")
            DiagLog.shotEnd(run, true, bmp.width, bmp.height, verdict = "image ${bmp.width}x${bmp.height}, $look")
            return bmp
        } catch (t: Throwable) {
            // The same exception goes on to the caller exactly as before; it is only written down first.
            run.step("EXCEPTION " + t.javaClass.name + ": " + t.message)
            DiagLog.shotEnd(run, false, verdict = "exception " + t.javaClass.simpleName + ": " + t.message)
            throw t
        }
    }

    /** Samples about 100 points and says only "varied", "all black", "all transparent" or "one colour". Nothing is kept or logged. */
    private fun describePixels(b: Bitmap): String = runCatching {
        var first = 0
        var same = true
        var n = 0
        for (iy in 0 until 10) for (ix in 0 until 10) {
            val p = b.getPixel((b.width - 1) * ix / 9, (b.height - 1) * iy / 9)
            if (n == 0) first = p else if (p != first) same = false
            n++
        }
        if (!same) "pixels varied"
        else if (first == Color.BLACK) "ALL SAMPLED PIXELS BLACK (a blocked, protected or blank screen?)"
        else if (Color.alpha(first) == 0) "all sampled pixels transparent"
        else "all sampled pixels one colour"
    }.getOrElse { "pixels not checked (" + it.javaClass.simpleName + ")" }

    /**
     * Run once after an empty capture, at most every 20 seconds: screencap again with the picture
     * thrown away, to read its exit code and its own error message. Only that text is kept.
     */
    private fun probeScreencap(run: DiagLog.ShotRun) {
        if (!PROBE_AFTER_FAILURE) return
        val now = System.currentTimeMillis()
        if (now - lastProbeAt < 20_000L) { run.step("failure probe skipped (it runs at most once every 20 s)"); return }
        lastProbeAt = now
        val out = StringBuilder()
        try {
            ShizukuShell.run("{ screencap -p >/dev/null; echo screencap_exit=\$?; } 2>&1 | head -c 400") { if (out.length < 400) out.append(it).append(' ') }
            run.step("failure probe (screencap run again, picture thrown away): " + out.toString().trim().ifEmpty { "no output at all" })
        } catch (t: Throwable) {
            run.step("failure probe raised " + t.javaClass.simpleName + ": " + t.message)
        }
    }

    /** The chosen box cut out of a screenshot; the screenshot is recycled. */
    fun crop(full: Bitmap, r: Region): Bitmap? {
        val kx = full.width.toFloat() / r.screenW.coerceAtLeast(1)
        val ky = full.height.toFloat() / r.screenH.coerceAtLeast(1)
        val l = (r.rect.left * kx).toInt().coerceIn(0, full.width - 1)
        val t = (r.rect.top * ky).toInt().coerceIn(0, full.height - 1)
        val w = ((r.rect.right * kx).toInt() - l).coerceIn(1, full.width - l)
        val h = ((r.rect.bottom * ky).toInt() - t).coerceIn(1, full.height - t)
        val fw = full.width
        val fh = full.height
        val made = runCatching { Bitmap.createBitmap(full, l, t, w, h) }
        val out = made.getOrNull()
        if (out == null) {
            DiagLog.shotNote("crop", false, "cutting the box (left=$l top=$t width=$w height=$h) out of the ${fw}x$fh screenshot failed: " + made.exceptionOrNull()?.javaClass?.simpleName + ": " + made.exceptionOrNull()?.message)
        } else {
            // A screenshot whose shape differs from the screen the box was drawn on means the box lands on the wrong place.
            val shotShape = fw.toFloat() / fh.coerceAtLeast(1)
            val boxShape = r.screenW.toFloat() / r.screenH.coerceAtLeast(1)
            if (Math.abs(shotShape - boxShape) > 0.03f) DiagLog.shotNote("crop", true, "the screenshot is ${fw}x$fh but the box was drawn on a ${r.screenW}x${r.screenH} screen; their shapes differ, so the box may land in the wrong place")
        }
        if (out !== full) full.recycle()
        return out
    }

    /** Lets the person drag a box over the screen. Blocking; null when cancelled or when it cannot be shown. */
    fun pick(app: Context): Region? {
        val main = Handler(Looper.getMainLooper())
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val latch = CountDownLatch(1)
        var result: Region? = null
        var view: PickView? = null
        main.post {
            val v = PickView(app) { r -> result = r; latch.countDown() }
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            if (runCatching { wm.addView(v, p) }.isSuccess) view = v else latch.countDown()
        }
        latch.await(90, TimeUnit.SECONDS)
        main.post { view?.let { runCatching { wm.removeView(it) } } }
        pause(350)
        return result
    }

    /** Picks a box, then takes one picture of it (used to teach the digits from any screen). */
    fun snap(app: Context): Bitmap? {
        DiagLog.attach(app)
        if (!WidgetFloat.allowed(app)) { DiagLog.shotNotStarted("snap", "Display over other apps is not allowed for A"); return null }
        if (!ShizukuShell.isReady()) { DiagLog.shotNotStarted("snap", "Shizuku is not ready (" + DiagLog.shizukuState() + ")"); return null }
        val region = pick(app) ?: run { DiagLog.shotNotStarted("snap", "the box picker was cancelled or could not be shown"); return null }
        val full = capture("snap") ?: return null
        return crop(full, region)
    }

    /** What one OCR run did, for the report. */
    private class Trace {
        var box = ""
        var path = "-"
        var text = ""
        var tries = 0
        var lastRaw = ""
    }

    private fun flat(s: String) = s.replace(Regex("\\s+"), " ").trim().take(80)

    /** The screen on top right now, for the report. Blocking and short; "?" when it cannot be read. */
    private fun topNow(): String {
        var out = ""
        runCatching {
            ShizukuShell.run("dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'") { line ->
                if (out.isEmpty()) {
                    val m = Regex("u\\d+ ([\\w.]+/[\\w.$]+)").find(line)
                    if (m != null) out = m.groupValues[1]
                }
            }
        }
        return out.ifEmpty { "?" }
    }

    /**
     * Picks a box and reads the digits in it, up to about 15 seconds, until the same digits are seen
     * twice in a row. Blocking. Throws a short message when nothing could be read.
     * Every run writes one line to A's report: path, text found, box, app on top, result.
     */
    fun read(app: Context, saved: Boolean = false, given: Region? = null, boxName: String = ""): String {
        DiagLog.attach(app)
        val tr = Trace()
        val top = if (ShizukuShell.isReady()) topNow() else "?"
        val t0 = System.currentTimeMillis()
        fun log(result: String) {
            DiagLog.note("OCR run: path=" + tr.path + " text=\"" + tr.text + "\" box=" + tr.box +
                " top=" + top + " tries=" + tr.tries + (if (tr.lastRaw.isNotEmpty()) " lastPicture=\"" + tr.lastRaw + "\"" else "") +
                " ms=" + (System.currentTimeMillis() - t0) + " result=" + result)
        }
        try {
            val r = readCore(app, saved, given, boxName, tr)
            log("\"" + r + "\"")
            return r
        } catch (e: Exception) {
            log("FAILED " + (e.message ?: e.javaClass.simpleName))
            throw e
        }
    }

    private fun readCore(app: Context, saved: Boolean, given: Region?, boxName: String, tr: Trace): String {
        if (!WidgetFloat.allowed(app)) throw IllegalStateException("Allow Display over other apps for A, then try again")
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        // The text reader (switched on through Shizuku for these moments) reads written text at once.
        val readerOn = TextReaderControl.ensureOnBlocking(app, 3000)
        // The saved box is read by itself; with none saved (or "choose it now") the box is dragged and kept for next time.
        val region: Region = given ?: (if (saved) savedRegion(app) else null) ?: run {
            toast(app, "Drag a box over what to read")
            val p = pick(app)
            if (p == null) { TextReaderControl.offLater(app, 500); throw IllegalStateException("Cancelled") }
            saveRegion(app, p)
            tr.box = "dragged now"
            p
        }
        if (tr.box.isEmpty()) tr.box = if (boxName.isNotEmpty()) "\"" + boxName + "\"" else if (given != null) "given" else "saved region"
        tr.box += "(" + region.rect.left + "," + region.rect.top + "," + region.rect.right + "," + region.rect.bottom + ")"
        if (readerOn) {
            val written = runCatching { TextReaderService.instance?.textIn(region.rect) }.getOrNull().orEmpty()
            TextReaderControl.offLater(app, 1500)
            tr.text = flat(written)
            // Written text with no digits (a bank name, a label) is not the code: read the picture instead.
            if (written.isNotBlank()) {
                val norm = ScreenCopy.normalize(written)
                if (norm.any { Character.isDigit(it) }) { tr.path = "text"; return norm }
                tr.path = "text ignored (no digits), then picture"
            } else tr.path = "text empty, then picture"
        } else tr.path = "text reader off, then picture"
        val limit = System.currentTimeMillis() + 15000
        var last = ""
        try {
            while (System.currentTimeMillis() < limit) {
                val full = capture("read") ?: throw IllegalStateException("The screenshot failed")
                val pic = crop(full, region)
                val r = if (pic == null) "" else runCatching { OtpOcr.read(app, pic) }.getOrDefault("")
                pic?.recycle()
                tr.tries++
                tr.lastRaw = flat(r)
                if (r.isNotEmpty() && !r.contains('?')) {
                    if (r == last) return r
                    last = r
                } else last = ""
                pause(300)
            }
        } finally {
            OtpOcr.release()
        }
        throw IllegalStateException("No digits were found in that box")
    }

    /**
     * The "OCR wait" script block: waits up to [timeoutMs] for what [mode] asks for ("digits", "text",
     * "both", or "word:<the word>") in a named box ([source] "box:<name>") or in a widget ("widget",
     * "widgetnow": digits only). Written text is read first, the picture only for digits. The same
     * thing must be seen twice in a row. Returns "" when nothing came in time. Blocking.
     */
    fun waitRead(
        app: Context, source: String, mode: String, timeoutMs: Int,
        digitCount: Int = 0, ignore: List<String> = emptyList(), stop: () -> Boolean,
    ): String {
        DiagLog.attach(app)
        val kind = mode.substringBefore(':')
        val word = mode.substringAfter(':', "").trim()
        val t0 = System.currentTimeMillis()
        val skip = ignore.map { OtpOcr.toEnglish(it).filter { ch -> !ch.isWhitespace() } }.filter { it.isNotEmpty() }.toSet()
        // A reading is taken only when it is not on the ignore list and (for digits) has the right length.
        // Anything else is skipped and the wait goes on, so an error word the screen shows first (read as digits)
        // does not hide the real code that comes a few seconds later.
        fun acceptable(v: String): Boolean {
            val flat = OtpOcr.toEnglish(v).filter { ch -> !ch.isWhitespace() }
            if (flat in skip) return false
            if (digitCount > 0 && flat.isNotEmpty() && flat.all { ch -> ch in '0'..'9' } && flat.length != digitCount) return false
            return true
        }
        if (source == "widget" || source == "widgetnow") {
            val id = widgetFor(app, now = source == "widgetnow")
            if (id < 0) throw IllegalStateException("No widget is chosen. In the OCR screen show a widget and tap \"Use for the OCR shortcut\".")
            val r = runCatching {
                WidgetFloat.readNow(app, id, timeoutMs) { v -> acceptable(v) && (digitCount <= 0 || v.length == digitCount) }
            }.getOrDefault("")
            DiagLog.note("OCR wait: source=" + source + " mode=digits (widgets are digits only) digits=" + (if (digitCount > 0) digitCount.toString() else "any") + " ignore=" + skip.joinToString(",") + " ms=" + (System.currentTimeMillis() - t0) + " result=\"" + r + "\"")
            return r
        }
        val name = source.removePrefix("box:")
        val region = box(app, name) ?: throw IllegalStateException("The box \"" + name + "\" is not saved. Make it in the OCR screen.")
        if (!WidgetFloat.allowed(app)) throw IllegalStateException("Allow Display over other apps for A, then try again")
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku. Start Shizuku and allow A, then try again.")
        val readerOn = TextReaderControl.ensureOnBlocking(app, 3000)
        val end = System.currentTimeMillis() + timeoutMs
        var last = ""
        var result = ""
        var tries = 0
        var seen = ""
        try {
            while (System.currentTimeMillis() < end && !stop()) {
                val written = if (readerOn) runCatching { TextReaderService.instance?.textIn(region.rect) }.getOrNull().orEmpty() else ""
                seen = flat(written)
                val norm = if (written.isBlank()) "" else ScreenCopy.normalize(written)
                val digits = Regex("[0-9]+").findAll(OtpOcr.toEnglish(written)).maxByOrNull { it.value.length }?.value.orEmpty()
                var cand = ""
                when (kind) {
                    "text" -> cand = norm
                    "word" -> if (word.isNotEmpty() && norm.contains(word, ignoreCase = true)) cand = norm
                    else -> {
                        cand = digits
                        if (cand.isNotEmpty() && !acceptable(cand)) cand = ""
                        if (cand.isEmpty()) {
                            // Not written text: read the picture of the box.
                            val full = capture("waitRead:" + name)
                            val pic = if (full == null) null else crop(full, region)
                            val r = if (pic == null) "" else runCatching { OtpOcr.read(app, pic) }.getOrDefault("")
                            pic?.recycle()
                            if (r.isNotEmpty() && !r.contains('?') && acceptable(r)) cand = r
                        }
                        if (cand.isEmpty() && kind == "both") cand = norm
                    }
                }
                if (cand.isNotEmpty() && !acceptable(cand)) cand = ""
                tries++
                if (cand.isNotEmpty()) {
                    if (cand == last) { result = cand; break }
                    last = cand
                } else last = ""
                pause(300)
            }
        } finally {
            OtpOcr.release()
            if (readerOn) TextReaderControl.offLater(app, 1500)
        }
        DiagLog.note("OCR wait: box=\"" + name + "\" mode=" + kind + (if (word.isNotEmpty()) "(" + word + ")" else "") + " text=\"" + seen + "\" tries=" + tries + " ms=" + (System.currentTimeMillis() - t0) + " result=\"" + result + "\"")
        return result
    }

    /** The "Wait for a field" script block: true when a text field with the cursor showed up within [timeoutMs]. Blocking. */
    fun waitField(app: Context, timeoutMs: Int, stop: () -> Boolean): Boolean {
        if (!ShizukuShell.isReady()) throw IllegalStateException("This needs Shizuku (it switches the text reader on). Start Shizuku and allow A, then try again.")
        if (!TextReaderControl.ensureOnBlocking(app, 3000)) throw IllegalStateException("The text reader could not be switched on")
        val end = System.currentTimeMillis() + timeoutMs
        try {
            while (System.currentTimeMillis() < end && !stop()) {
                if (runCatching { TextReaderService.instance?.hasInputFocus() }.getOrNull() == true) return true
                pause(300)
            }
        } finally {
            TextReaderControl.offLater(app, 1500)
        }
        return false
    }

    private fun pause(ms: Int) {
        try { Thread.sleep(ms.toLong()) } catch (_: InterruptedException) { }
    }

    /** The full-screen layer where the box is dragged. Tap "Cancel" (top right) to give up. */
    private class PickView(ctx: Context, private val onDone: (Region?) -> Unit) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private val dim = Paint().apply { color = 0x88000000.toInt() }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 2f * d }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 16f * d }
        private var x0 = 0f
        private var y0 = 0f
        private var x1 = 0f
        private var y1 = 0f
        private var has = false
        private var cancelDown = false
        private var finished = false

        private fun box() = Rect(minOf(x0, x1).toInt(), minOf(y0, y1).toInt(), maxOf(x0, x1).toInt(), maxOf(y0, y1).toInt())
        private fun inCancel(x: Float, y: Float) = x > width - 130f * d && y < 110f * d

        override fun onDraw(c: Canvas) {
            if (has) {
                val b = box()
                c.save()
                c.clipOutRect(b)
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
                c.restore()
                c.drawRect(b, edge)
            } else {
                c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
            }
            c.drawText("Drag a box over what to read", 16f * d, 70f * d, text)
            c.drawText("Cancel", width - 100f * d, 70f * d, text)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (finished) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    cancelDown = inCancel(e.x, e.y)
                    if (!cancelDown) { x0 = e.x; y0 = e.y; x1 = e.x; y1 = e.y; has = true }
                }
                MotionEvent.ACTION_MOVE -> if (!cancelDown) { x1 = e.x; y1 = e.y; invalidate() }
                MotionEvent.ACTION_UP -> {
                    if (cancelDown) {
                        if (inCancel(e.x, e.y)) { finished = true; onDone(null) }
                    } else {
                        x1 = e.x; y1 = e.y
                        val b = box()
                        if (b.width() >= 20 && b.height() >= 12) {
                            val at = IntArray(2)
                            getLocationOnScreen(at)
                            b.offset(at[0], at[1])
                            finished = true
                            onDone(Region(b, width, height))
                        } else { has = false; invalidate() }
                    }
                }
                MotionEvent.ACTION_CANCEL -> { has = false; invalidate() }
            }
            return true
        }
    }
}
