package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipFile

/**
 * The one tab for everything done to a zip or a project folder (step 2 of HANDOFF_ZipTools_OneTab).
 *
 * Section A: pick a source, a zip or a folder (a folder is packed into a zip in the cache, with or without its
 * own name as the top folder). Section B: what to do; for now "Replace or add files" (Patch several moved into
 * the common plan) and "Rename app", one at a time or together (the switch "Combine actions"), and "Take files
 * out", which makes a subset and so always stands alone. Then the Check box, Save as, the button and the Result,
 * exactly as in the old tabs. The old tabs stay until every action has been moved here.
 */
class OneState(private val ctx: Context) {
    var source by mutableStateOf<ZipSource?>(null)
    var keepName by mutableStateOf(true)
    var replaceOn by mutableStateOf(true)
    var renameOn by mutableStateOf(false)
    var extractOn by mutableStateOf(false)
    var combine by mutableStateOf(false)
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var log by mutableStateOf("")

    val replaceAdd = ReplaceAddAction(ctx)
    val rename = RenameAction()
    val extract = ExtractAction(ctx)

    /** The picked folder, kept so that the "Keep the folder name" switch can pack it again. */
    private var folderUri: Uri? = null

    fun cleanup() {
        for (n in listOf(SRC_TMP, REP_TMP, OUT_TMP)) {
            File(ctx.cacheDir, n).delete()
            File(ctx.cacheDir, "$n.part").delete()
        }
    }

    // ---------------------------------------------------------------- picking the source

    fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the zip..."
        Thread {
            try {
                val s = ZipSources.fromZip(ctx, u, File(ctx.cacheDir, SRC_TMP))
                folderUri = null
                useSource(s, true)
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    /** [fresh] is false when the same folder is packed again because the switch was changed. */
    fun loadFolder(tree: Uri, fresh: Boolean) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the folder..."
        val keep = keepName
        Thread {
            try {
                val s = ZipSources.fromFolder(ctx, tree, File(ctx.cacheDir, SRC_TMP), keep) { status = it }
                folderUri = tree
                useSource(s, fresh)
            } catch (e: Throwable) {
                if (!fresh) keepName = !keepName
                log = "FOLDER ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    /** The switch "Keep the folder name": when a folder is already picked it is packed again the new way. */
    fun changeKeepName(v: Boolean) {
        if (busy) return
        keepName = v
        val t = folderUri
        if (t != null && source?.fromFolder == true) loadFolder(t, false)
    }

    private fun useSource(s: ZipSource, fresh: Boolean) {
        replaceAdd.chosen = emptySet()
        rename.forget()
        source = s
        if (fresh || outName.isBlank()) outName = ZipIo.stem(s.name) + "_new.zip"
        replaceAdd.autoSelect(s)
        extract.setSource(s, fresh)
        if (renameOn) rename.analyse(s)
    }

    // ---------------------------------------------------------------- ticking the actions

    fun tickReplace(v: Boolean) {
        if (busy) return
        replaceOn = v
        if (v) extractOn = false
        if (v && !combine) renameOn = false
    }

    fun tickRename(v: Boolean) {
        if (busy) return
        renameOn = v
        if (v) extractOn = false
        if (v && !combine) replaceOn = false
        if (v) analyseRename()
    }

    /** Take files out makes a subset of the source, so it always stands alone: ticking it unticks the others. */
    fun tickExtract(v: Boolean) {
        if (busy) return
        extractOn = v
        if (v) {
            replaceOn = false
            renameOn = false
        }
    }

    /** The window was opened by a shortcut that names the action to tick (EXTRA_TICK). */
    fun tickFromShortcut(key: String?) {
        when (key) {
            "extract" -> tickExtract(true)
            "rename" -> tickRename(true)
            "replace" -> tickReplace(true)
        }
    }

    /** Off: one action at a time (the first one stays ticked). On: several can be ticked together. */
    fun changeCombine(v: Boolean) {
        if (busy) return
        combine = v
        if (!v && replaceOn && renameOn) renameOn = false
    }

    /** Looks for the package name and app name of the source, once per source. */
    private fun analyseRename() {
        val src = source ?: return
        if (busy || rename.forSource === src) return
        busy = true
        status = "Looking for the package name and app name..."
        Thread {
            try {
                rename.analyse(src)
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    // ---------------------------------------------------------------- new versions for "Replace or add files"

    fun useLoose(us: List<Uri>) {
        if (busy) return
        log = ""
        replaceAdd.useLoose(us, source)
    }

    fun loadRepZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the zip..."
        Thread {
            try {
                val z = ZipSources.fromZip(ctx, u, File(ctx.cacheDir, REP_TMP))
                replaceAdd.useRepZip(z, source)
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    // ---------------------------------------------------------------- plan and build

    /** What every ticked action wants, joined into one plan (two actions on one file is a PROBLEM). */
    fun plan(src: ZipSource): ZipPlan {
        val parts = ArrayList<Pair<String, ZipPlan>>()
        if (replaceOn) parts.add("Replace or add files" to replaceAdd.plan(src))
        if (renameOn) parts.add("Rename app" to rename.plan(src))
        return ZipPlan.combine(parts)
    }

    fun make() {
        val src = source ?: return
        if (busy) return
        if (extractOn) {
            makeExtract(src)
            return
        }
        val built = plan(src)
        if (!built.canBuild) {
            log = "ZIP ERROR: fix what the Check box shows first.\nNothing was saved."
            return
        }
        busy = true
        log = ""
        val name = outName
        Thread {
            try {
                val r = ZipBuilder.build(ctx, src, built, name, File(ctx.cacheDir, OUT_TMP)) { status = it }
                log = r.text
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    /** Take files out: its own writer, so it does not go through the plan and builder. */
    private fun makeExtract(src: ZipSource) {
        if (extract.picked.isEmpty()) {
            log = "ERROR: choose the files to take out first."
            return
        }
        busy = true
        log = ""
        status = "Taking the files out..."
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                log = extract.run(src, tmp)
            } catch (e: Throwable) {
                log = "ERROR: ${e.javaClass.simpleName}: ${e.message}"
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    private companion object {
        const val SRC_TMP = "zt_one_src.zip"
        const val REP_TMP = "zt_one_rep.zip"
        const val OUT_TMP = "zt_one_out.zip"
    }
}

/**
 * "Replace or add files": swap files in the source for new versions (loose files matched by name, or one zip
 * matched by path), and add the files that fit nothing. The matching is the one of Patch several, now giving a
 * [ZipPlan] instead of building the zip itself.
 */
class ReplaceAddAction(private val ctx: Context) : ZipAction {
    var chosen by mutableStateOf<Set<String>>(emptySet())
    var looseFiles by mutableStateOf<List<Pair<String, Uri>>>(emptyList())
    var repZip by mutableStateOf<ZipSource?>(null)
    var addNew by mutableStateOf(true)
    var addFolder by mutableStateOf("")
    var showList by mutableStateOf(false)
    var showFolders by mutableStateOf(false)

    /** One new version: a loose file (uri) or an entry of the replacement zip. */
    class Rep(val label: String, val uri: Uri?, val entry: String?)

    /** [map] holds source path -> its new version. [unmatched] are new versions that fit no file in the source. */
    class Resolved(
        val map: LinkedHashMap<String, Rep>,
        val problems: List<String>,
        val unmatched: List<String>,
        /** New path in the zip -> the new file to put there (files that fit nothing, when adding is on). */
        val adds: LinkedHashMap<String, Rep> = LinkedHashMap(),
    )

    /** Several loose files were picked: they replace any replacement zip picked before. */
    fun useLoose(us: List<Uri>, src: ZipSource?) {
        repZip?.discard()
        repZip = null
        looseFiles = us.map { ZipIo.nameOf(ctx.contentResolver, it) to it }
        if (src != null) autoSelect(src)
    }

    /** One zip holding the new files was picked: it replaces any loose files picked before. */
    fun useRepZip(z: ZipSource, src: ZipSource?) {
        looseFiles = emptyList()
        repZip = z
        if (src != null) autoSelect(src)
    }

    /** Every file that has a new version is ticked for you (you can untick any in the list). */
    fun autoSelect(src: ZipSource) {
        val r = resolveAll(src)
        if (r.map.isNotEmpty()) chosen = chosen + r.map.keys
    }

    /** Every folder in the source (without the project folder), for the "folder for new files" list. */
    fun folderList(src: ZipSource): List<String> {
        return src.entries.map { it.removePrefix(src.root).substringBeforeLast('/', "") }
            .filter { it.isNotEmpty() }.distinct().sorted()
    }

    // ---------------------------------------------------------------- matching

    /** Where a new file from the replacement zip goes: its own path, under the project folder of the source. */
    private fun newPathFor(p: String, entries: List<String>, root: String, repRoot: String): String {
        var rel = p
        if (root.isNotEmpty() && p.startsWith(root)) {
            rel = p.removePrefix(root)
        } else {
            if (repRoot.isNotEmpty() && repRoot != root) {
                val tops = entries.map { it.removePrefix(root).substringBefore('/', "") }.toHashSet()
                if (repRoot.removeSuffix("/") !in tops) rel = p.removePrefix(repRoot)
            }
        }
        return root + rel
    }

    /** Finds which source file a path from the replacement zip stands for (same path, with or without the project folder). */
    private fun resolve(p: String, entries: List<String>, srcSet: Set<String>, root: String): String? {
        if (p in srcSet) return p
        if (root.isNotEmpty() && (root + p) in srcSet) return root + p
        val rest = p.substringAfter('/', "")
        if (rest.isNotEmpty()) {
            if (rest in srcSet) return rest
            if (root.isNotEmpty() && (root + rest) in srcSet) return root + rest
        }
        if (p.contains('/')) {
            val hits = entries.filter { it.endsWith("/" + p) }
            return if (hits.size == 1) hits[0] else null
        }
        val hits = entries.filter { it.substringAfterLast('/') == p }
        return if (hits.size == 1) hits[0] else null
    }

    fun resolveAll(src: ZipSource): Resolved {
        val map = LinkedHashMap<String, Rep>()
        val problems = ArrayList<String>()
        val unmatched = ArrayList<String>()
        val entries = src.entries
        if (entries.isEmpty()) return Resolved(map, problems, unmatched)
        val srcSet = entries.toHashSet()
        val root = src.root
        val repEntries = repZip?.entries ?: emptyList()
        val repRoot = repZip?.root ?: ""
        if (looseFiles.isNotEmpty()) {
            for ((name, uri) in looseFiles) {
                val cands = entries.filter { it.substringAfterLast('/') == name }
                var target: String? = null
                var skip = false
                if (cands.size == 1) {
                    target = cands[0]
                } else if (cands.size > 1) {
                    val inChosen = cands.filter { it in chosen }
                    if (inChosen.size == 1) {
                        target = inChosen[0]
                    } else {
                        problems.add("$name fits ${cands.size} files in the zip. Tick the one you mean in the list.")
                        skip = true
                    }
                }
                if (skip) continue
                if (target == null) {
                    unmatched.add(name)
                    continue
                }
                if (map.containsKey(target)) {
                    problems.add("Two new files are named $name.")
                    continue
                }
                map[target] = Rep(name, uri, null)
            }
        } else {
            for (p in repEntries) {
                val target = resolve(p, entries, srcSet, root)
                if (target == null) {
                    unmatched.add(p)
                    continue
                }
                val prev = map[target]
                if (prev != null) {
                    problems.add("${prev.label} and $p both fit ${target.removePrefix(root)}.")
                    continue
                }
                map[target] = Rep(p, null, p)
            }
        }
        val adds = LinkedHashMap<String, Rep>()
        if (addNew && unmatched.isNotEmpty()) {
            val folder = addFolder.trim().trim('/')
            for (u in unmatched) {
                val newPath: String
                if (looseFiles.isNotEmpty()) {
                    if (folder.isEmpty()) {
                        problems.add("$u is new: choose the folder for new files, or switch adding off.")
                        continue
                    }
                    newPath = root + folder + "/" + u
                } else {
                    if (entries.any { it.endsWith("/" + u) }) {
                        problems.add("$u fits several files in the zip. Give its full path in the replacement zip.")
                        continue
                    }
                    newPath = newPathFor(u, entries, root, repRoot)
                }
                if (newPath in srcSet) {
                    problems.add("$u would be added as ${newPath.removePrefix(root)}, which is already in the zip.")
                    continue
                }
                if (adds.containsKey(newPath)) {
                    problems.add("Two new files would be added as ${newPath.removePrefix(root)}.")
                    continue
                }
                val rp = if (looseFiles.isNotEmpty()) {
                    Rep(u, looseFiles.first { it.first == u }.second, null)
                } else {
                    Rep(u, null, u)
                }
                adds[newPath] = rp
            }
        }
        return Resolved(map, problems, unmatched, adds)
    }

    // ---------------------------------------------------------------- the plan

    /** The content is only opened when the zip is written, so making a plan for the Check box reads no file. */
    private fun blobOf(r: Rep): ZipIo.Blob {
        val u = r.uri
        if (u != null) {
            return ZipIo.Blob(opener = {
                ctx.contentResolver.openInputStream(u) ?: throw IllegalStateException("Could not open ${r.label}.")
            })
        }
        val f = repZip?.file ?: throw IllegalStateException("The replacement zip is not open.")
        val entry = r.entry ?: throw IllegalStateException("${r.label} has no place in the replacement zip.")
        return ZipIo.Blob(opener = {
            ZipFile(f).use { zf ->
                val e = zf.getEntry(entry) ?: throw IllegalStateException("$entry is missing in the replacement zip.")
                ByteArrayInputStream(zf.getInputStream(e).use { it.readBytes() })
            }
        })
    }

    override fun plan(src: ZipSource): ZipPlan {
        val res = resolveAll(src)
        val toApply = chosen.filter { res.map.containsKey(it) }.sorted()
        val missing = chosen.filter { !res.map.containsKey(it) }.sorted()
        val problems = ArrayList<String>(res.problems)
        for (m in missing) problems.add("${src.shown(m)} has no new version. Untick it in the list.")
        val replace = LinkedHashMap<String, ZipIo.Blob>()
        for (t in toApply) replace[t] = blobOf(res.map[t]!!)
        val add = res.adds.keys.sorted().map { it to blobOf(res.adds[it]!!) }
        val quiet = chosen.isEmpty() && looseFiles.isEmpty() && repZip == null
        return ZipPlan(replace, emptySet(), add, if (quiet) "" else summary(src, res, toApply), problems, emptyList())
    }

    private fun summary(src: ZipSource, res: Resolved, toApply: List<String>): String {
        val sb = StringBuilder()
        if (toApply.isNotEmpty() || res.adds.isEmpty()) sb.append("Will replace ${toApply.size} file(s):\n")
        for (t in toApply) sb.append(" ${src.shown(t)}\n    <- ${res.map[t]!!.label}\n")
        if (res.adds.isNotEmpty()) {
            sb.append("\nWill ADD ${res.adds.size} new file(s):\n")
            for ((p, r) in res.adds) sb.append(" ${src.shown(p)}\n    <- ${r.label}\n")
        }
        val left = res.map.keys.count { it !in chosen }
        if (left > 0) sb.append("\nLeft alone (fits a file, not ticked): $left\n")
        if (!addNew && res.unmatched.isNotEmpty()) {
            sb.append("\nNot in the source, ignored: ${res.unmatched.size}\n")
            for (u in res.unmatched.take(8)) sb.append(" $u\n")
            if (res.unmatched.size > 8) sb.append(" ...and ${res.unmatched.size - 8} more\n")
        }
        return sb.toString().trim()
    }
}

private fun shortNames(list: List<String>): String {
    val first = list.take(3).joinToString(", ") { it.substringAfterLast('/') }
    return if (list.size > 3) "$first and ${list.size - 3} more" else first
}

@Composable
fun OneTab(s: OneState) {
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(u)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) s.loadFolder(u, true)
    }
    val src = s.source

    HeroCard(
        title = "Zips and folders in one tab",
        text = "Pick a zip or a folder, then choose what to do with it. A new zip is saved in Downloads and checked. What you picked is never changed.",
        leading = { IconTile(Icons.Filled.Settings, lit = true) },
    )
    Column {
        GroupHeading("Source")
        RowGroup {
            KitRow(
                title = "Zip",
                shape = cardShape(0, 3),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = if (src != null && !src.fromFolder) src.name else "Tap to choose",
                description = if (src != null && !src.fromFolder) src.info else null,
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "Folder",
                shape = cardShape(1, 3),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = if (src != null && src.fromFolder) src.name else "Tap to choose",
                description = if (src != null && src.fromFolder) src.info else null,
                onClick = { if (!s.busy) pickFolder.launch(null) },
            )
            KitRow(
                title = "Keep the folder name inside the zip",
                shape = cardShape(2, 3),
                description = if (s.keepName) "A folder is packed with its own name as the top folder" else "A folder is packed with its files at the top",
                onClick = { s.changeKeepName(!s.keepName) },
                trailing = { Switch(checked = s.keepName, onCheckedChange = { s.changeKeepName(it) }) },
            )
        }
    }
    if (s.busy && s.status.isNotEmpty()) TextBox(s.status)

    if (src != null) {
        val a = s.replaceAdd
        Column {
            GroupHeading("What to do")
            RowGroup {
                KitRow(
                    title = "Replace or add files",
                    shape = cardShape(0, 4),
                    leading = { IconTile(Icons.Filled.Settings) },
                    description = "New versions of files in the source, and files that fit nothing are added",
                    onClick = { s.tickReplace(!s.replaceOn) },
                    trailing = { Switch(checked = s.replaceOn, onCheckedChange = { s.tickReplace(it) }) },
                )
                KitRow(
                    title = "Rename app",
                    shape = cardShape(1, 4),
                    leading = { IconTile(Icons.Filled.Edit) },
                    description = "Change the package name and the app name",
                    onClick = { s.tickRename(!s.renameOn) },
                    trailing = { Switch(checked = s.renameOn, onCheckedChange = { s.tickRename(it) }) },
                )
                KitRow(
                    title = "Take files out",
                    shape = cardShape(2, 4),
                    leading = { IconTile(Icons.Filled.Folder) },
                    description = "Save chosen files as folders or as one new zip (always on its own)",
                    onClick = { s.tickExtract(!s.extractOn) },
                    trailing = { Switch(checked = s.extractOn, onCheckedChange = { s.tickExtract(it) }) },
                )
                KitRow(
                    title = "Combine actions",
                    shape = cardShape(3, 4),
                    description = if (s.combine) "Several actions can be ticked and done in one go" else "One action at a time",
                    onClick = { s.changeCombine(!s.combine) },
                    trailing = { Switch(checked = s.combine, onCheckedChange = { s.changeCombine(it) }) },
                )
            }
        }
        if (s.replaceOn) ReplaceAddSection(s, src)
        if (s.renameOn) RenameSection(s.rename, src)

        if (s.extractOn) {
            val x = s.extract
            ExtractSection(x, src, s.busy)
            val xs = remember(src, x.picked, x.asFolders, x.outName) { x.summary(src) }
            Column {
                GroupHeading("Check")
                TextBox(xs)
            }
            ExtractSaveAs(x, s.busy)
            Button(
                onClick = { s.make() },
                enabled = x.picked.isNotEmpty() && x.outName.isNotBlank() && !s.busy,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    if (s.busy) (s.status.ifEmpty { "Working..." })
                    else if (x.asFolders) "Take files out to folders" else "Take files out to a zip",
                )
            }
        } else {
            val r = s.rename
            val plan = remember(
                src, s.replaceOn, a.chosen, a.looseFiles, a.repZip, a.addNew, a.addFolder,
                s.renameOn, r.forSource, r.error, r.newPkg, r.newLabel,
            ) { s.plan(src) }
            val check = plan.checkText()
            if (check.isNotEmpty()) {
                Column {
                    GroupHeading("Check")
                    TextBox(check)
                }
            }
            SaveAsField(s.outName) { s.outName = it }
            Button(
                onClick = { s.make() },
                enabled = plan.canBuild && s.outName.isNotBlank() && !s.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (s.busy) (s.status.ifEmpty { "Working..." }) else "Make zip") }
        }
    }
    ResultBox(s.log)
    if (src != null && s.renameOn && s.rename.forSource === src && s.rename.review.isNotEmpty()) {
        Column {
            GroupHeading("To review (not changed)")
            TextBox(s.rename.review)
        }
    }
}

/** The boxes of "Replace or add files": the files to replace, the new versions, and the files that fit nothing. */
@Composable
private fun ReplaceAddSection(s: OneState, src: ZipSource) {
    val a = s.replaceAdd
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.isNotEmpty()) s.useLoose(us)
    }
    val pickRepZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadRepZip(u)
    }
    Column {
        GroupHeading("Files to replace")
        RowGroup {
            KitRow(
                title = "Files to replace",
                shape = cardShape(0, 1),
                summary = if (a.chosen.isEmpty()) "Tap to choose from the list" else "${a.chosen.size} chosen",
                description = if (a.chosen.isEmpty()) null else shortNames(a.chosen.sorted()),
                onClick = { if (!s.busy) a.showList = true },
            )
        }
    }
    Column {
        GroupHeading("New versions (use one of the two)")
        RowGroup {
            KitRow(
                title = "Several files",
                shape = cardShape(0, 2),
                summary = if (a.looseFiles.isEmpty()) "Tap to choose the new files" else "${a.looseFiles.size} files",
                description = if (a.looseFiles.isEmpty()) "Matched to the zip by file name" else shortNames(a.looseFiles.map { it.first }),
                onClick = { if (!s.busy) pickFiles.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "One zip with the files",
                shape = cardShape(1, 2),
                summary = a.repZip?.name ?: "Tap to choose the zip",
                description = if (a.repZip != null) "${a.repZip?.entries?.size ?: 0} files inside" else "Matched to the zip by path",
                onClick = { if (!s.busy) pickRepZip.launch(arrayOf("*/*")) },
            )
        }
    }
    Column {
        GroupHeading("New files (not in the source yet)")
        RowGroup {
            KitRow(
                title = "Add files that fit nothing",
                shape = cardShape(0, 2),
                description = if (a.addNew) "They are added to the new zip" else "They are ignored",
                onClick = { if (!s.busy) a.addNew = !a.addNew },
                trailing = { Switch(checked = a.addNew, onCheckedChange = { if (!s.busy) a.addNew = it }) },
            )
            KitRow(
                title = "Folder for new files",
                shape = cardShape(1, 2),
                summary = if (a.addFolder.isBlank()) "Tap to choose" else a.addFolder,
                description = "Only for files picked one by one. A replacement zip keeps its own paths.",
                onClick = { if (!s.busy) a.showFolders = true },
            )
        }
    }

    if (a.showList) {
        var query by remember { mutableStateOf("") }
        val shown = remember(src, query) {
            val q = query.trim()
            if (q.isEmpty()) src.entries else src.entries.filter { it.contains(q, ignoreCase = true) }
        }
        CardWindow(title = "Files to replace", onBack = { a.showList = false }, scroll = false) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search (${shown.size} files, ${a.chosen.size} chosen)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shown) { path ->
                    val on = path in a.chosen
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        background = if (on) MaterialTheme.colorScheme.primaryContainer else rowColor(),
                        onClick = { a.chosen = if (on) a.chosen - path else a.chosen + path },
                        trailing = { if (on) Icon(Icons.Filled.Check, contentDescription = null) },
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { a.chosen = emptySet() },
                    enabled = a.chosen.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                ) { Text("Clear") }
                Button(
                    onClick = { a.showList = false },
                    modifier = Modifier.weight(1f),
                ) { Text("Done (${a.chosen.size})") }
            }
        }
    }

    if (a.showFolders) {
        var typed by remember { mutableStateOf(a.addFolder) }
        val folders = remember(src) { a.folderList(src) }
        val shownF = remember(folders, typed) {
            val q = typed.trim()
            if (q.isEmpty()) folders else folders.filter { it.contains(q, ignoreCase = true) }
        }
        CardWindow(title = "Folder for new files", onBack = { a.showFolders = false }, scroll = false) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                singleLine = true,
                label = { Text("Type a folder, or tap one below (${shownF.size} folders)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shownF.take(300)) { path ->
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        onClick = { typed = path },
                        trailing = null,
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { a.addFolder = ""; a.showFolders = false },
                    modifier = Modifier.weight(1f),
                ) { Text("No folder") }
                Button(
                    onClick = { a.addFolder = typed.trim().trim('/'); a.showFolders = false },
                    enabled = typed.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) { Text("Use this folder") }
            }
        }
    }
}
