package a.a.ui.screens.main

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.utils.DiagLog

/**
 * Copies a report using the options last saved in the Copy report window (or its defaults when
 * nothing was saved yet). Used by a long press on the report icon. Honours "Start empty after copying".
 */
object ReportCopier {
    fun copySaved(context: Context) {
        val app = context.applicationContext
        val sp = app.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val clear = sp.getBoolean("rep_clear", false)
        val opts = DiagLog.ReportOptions(
            sp.getInt("rep_min", 5) * 60 + sp.getInt("rep_sec", 0),
            sp.getBoolean("rep_phone", false), sp.getBoolean("rep_settings", false), sp.getBoolean("rep_audio", false),
            sp.getBoolean("rep_saved", true), sp.getBoolean("rep_notes", true), sp.getBoolean("rep_system", false),
            sp.getBoolean("rep_disc", false), sp.getBoolean("rep_applog", true), sp.getBoolean("rep_shot", true),
        )
        Toast.makeText(app, "Copying report…", Toast.LENGTH_SHORT).show()
        // Shizuku and the log are read off the main thread; the copy happens when they are done.
        Thread {
            val text = DiagLog.report(app, opts)
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("A report", text))
                if (clear) DiagLog.clear(app)
                Toast.makeText(app, "Report copied (${text.length / 1000} KB)", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}

/** "Copy report": pick how far back to look and what to include, in the card design (back arrow = Cancel).
 * "Save" keeps the choices without copying; hold the report icon on the main screen to copy with them.
 * "Copy" saves them and copies now. Same preference keys as before (rep_*). */
@Composable
fun ReportDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sp = remember { context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE) }
    var minutes by remember { mutableIntStateOf(sp.getInt("rep_min", 5)) }
    var secs by remember { mutableIntStateOf(sp.getInt("rep_sec", 0)) }
    // Bumped by the quick choices so the number boxes show the new values.
    var boxes by remember { mutableIntStateOf(0) }
    var phone by remember { mutableStateOf(sp.getBoolean("rep_phone", false)) }
    var settings by remember { mutableStateOf(sp.getBoolean("rep_settings", false)) }
    var audio by remember { mutableStateOf(sp.getBoolean("rep_audio", false)) }
    var saved by remember { mutableStateOf(sp.getBoolean("rep_saved", true)) }
    var notes by remember { mutableStateOf(sp.getBoolean("rep_notes", true)) }
    var system by remember { mutableStateOf(sp.getBoolean("rep_system", false)) }
    var disc by remember { mutableStateOf(sp.getBoolean("rep_disc", false)) }
    var applog by remember { mutableStateOf(sp.getBoolean("rep_applog", true)) }
    var shot by remember { mutableStateOf(sp.getBoolean("rep_shot", true)) }
    var clear by remember { mutableStateOf(sp.getBoolean("rep_clear", false)) }

    fun save() {
        sp.edit().putInt("rep_min", minutes).putInt("rep_sec", secs).putBoolean("rep_phone", phone).putBoolean("rep_settings", settings)
            .putBoolean("rep_audio", audio).putBoolean("rep_saved", saved).putBoolean("rep_notes", notes)
            .putBoolean("rep_system", system).putBoolean("rep_disc", disc).putBoolean("rep_applog", applog).putBoolean("rep_shot", shot)
            .putBoolean("rep_clear", clear).apply()
    }

    CardWindow(title = "Copy report", onBack = onDismiss) {
        CardGroup(title = "Quick choices", hint = "Fill in the boxes below for you. You can still change them after.") {
            row { sh ->
                LinkRow(
                    title = "Just now", summary = "The last minute, without the long extras", shape = sh, icon = Icons.Filled.PlayArrow,
                ) {
                    minutes = 1; secs = 0; boxes++; notes = true; saved = true; applog = true; shot = true; phone = false; settings = false; audio = false; disc = false; system = false
                }
            }
            row { sh ->
                LinkRow(
                    title = "Service stopped", summary = "The last hour, with settings, disconnections and why the system ended the app",
                    shape = sh, icon = Icons.Filled.Check,
                ) {
                    minutes = 60; secs = 0; boxes++; notes = true; saved = true; applog = true; shot = true; phone = false; settings = true; audio = false; disc = true; system = true
                }
            }
        }
        CardGroup(title = "How far back", hint = "0 and 0 = everything kept.") {
            row { sh -> key(boxes) { NumRow("Minutes", minutes, sh) { minutes = it } } }
            row { sh -> key(boxes) { NumRow("Seconds", secs, sh) { secs = it } } }
        }
        CardGroup(title = "Include") {
            row { sh ->
                SwitchRow(title = "What the app noted", checked = notes, shape = sh, icon = Icons.Filled.Edit,
                    summary = "Gestures, cells, errors") { notes = it }
            }
            row { sh ->
                SwitchRow(title = "Saved events", checked = saved, shape = sh, icon = Icons.Filled.Star,
                    summary = "Kept after the app was killed") { saved = it }
            }
            row { sh ->
                SwitchRow(title = "System log", checked = applog, shape = sh, icon = Icons.Filled.Terminal,
                    summary = "The app's warnings and errors from the system log") { applog = it }
            }
            row { sh ->
                SwitchRow(title = "Screenshot diagnostics", checked = shot, shape = sh, icon = Icons.Filled.Info,
                    summary = "Every screenshot try and why it failed. No pictures") { shot = it }
            }
            row { sh ->
                SwitchRow(title = "Phone model and Android version", checked = phone, shape = sh, icon = Icons.Filled.Info) { phone = it }
            }
            row { sh ->
                SwitchRow(title = "Permissions and settings state", checked = settings, shape = sh, icon = Icons.Filled.Tune) { settings = it }
            }
            row { sh ->
                SwitchRow(title = "Volume streams and a test write", checked = audio, shape = sh, icon = Icons.Filled.Notifications) { audio = it }
            }
            row { sh ->
                SwitchRow(title = "Accessibility disconnections", checked = disc, shape = sh, icon = Icons.Filled.Lock,
                    summary = "Disconnections of the accessibility service") { disc = it }
            }
            row { sh ->
                SwitchRow(title = "Why the system ended the app earlier", checked = system, shape = sh, icon = Icons.Filled.History,
                    summary = "Needs Shizuku. Long.") { system = it }
            }
        }
        CardGroup(title = "After copying") {
            row { sh ->
                SwitchRow(title = "Start empty after copying", checked = clear, shape = sh, icon = Icons.Filled.Delete) { clear = it }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                save()
                Toast.makeText(context, "Saved. Hold the report icon to copy with these.", Toast.LENGTH_SHORT).show()
                onDismiss()
            }, modifier = Modifier.weight(1f)) { Text("Save") }
            Button(onClick = {
                save()
                ReportCopier.copySaved(context)
                onDismiss()
            }, modifier = Modifier.weight(1f)) { Text("Copy") }
        }
    }
}

/** A row with a number box at its end (digits only, up to 100000; an empty or half-typed box keeps the last good value). */
@Composable
private fun NumRow(title: String, value: Int, shape: Shape, onValue: (Int) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    SettingRow(
        title = title, shape = shape,
        trailing = {
            OutlinedTextField(
                value = text,
                onValueChange = { t ->
                    val clean = t.filter { it.isDigit() }.take(6)
                    text = clean
                    clean.toIntOrNull()?.let { onValue(it.coerceIn(0, 100000)) }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.width(110.dp),
            )
        },
    )
}
