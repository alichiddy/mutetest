plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.hilt)
  alias(libs.plugins.ksp)
  alias(libs.plugins.secrets)
}

android {
  namespace = "a.a"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  // Only English and Arabic: the libraries' own translations are left out too.
  androidResources {
    localeFilters += listOf("en", "ar")
  }

  defaultConfig {
    applicationId = "a.a"
    minSdk = 26
    targetSdk = 36
    versionCode = (project.findProperty("buildNo") as String?)?.toIntOrNull() ?: 42
    versionName = "1.5.4-b" + (project.findProperty("buildNo") ?: "local")

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

    buildConfigField("boolean", "ADS_DISABLED", project.hasProperty("noAds").toString())
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

dependencies {
  // Signs the copy of this app that the strip editor makes ("Make APK with my shortcuts").
  implementation("com.android.tools.build:apksig:8.5.2")
  implementation("com.google.zxing:core:3.5.3")
  implementation("dev.rikka.shizuku:api:13.1.5")
  implementation("dev.rikka.shizuku:provider:13.1.5")
  implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.appcompat)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.activity.compose)
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.compose.material3)

  // Hilt
  implementation(libs.hilt.android)
  implementation(libs.androidx.lifecycle.process)
  implementation(libs.androidx.constraintlayout)
  implementation(libs.androidx.cardview)
  ksp(libs.hilt.compiler)
  implementation(libs.hilt.navigation.compose)
  implementation(libs.androidx.navigation.compose)

  // Splashscreen
  implementation(libs.androidx.core.splashscreen)

  // Icons
  implementation(libs.androidx.compose.material.icons.extended)

  // Lottie
  implementation(libs.lottie.compose)

  // Coil
  implementation(libs.coil.compose)
  implementation(libs.coil.network.okhttp)
  implementation(libs.coil)

  // Sheets
  implementation(libs.color)

  // QR / barcode scanning
  implementation(libs.play.services.code.scanner)

  // Testing
  testImplementation(libs.junit)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  debugImplementation(libs.androidx.compose.ui.tooling)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
}
