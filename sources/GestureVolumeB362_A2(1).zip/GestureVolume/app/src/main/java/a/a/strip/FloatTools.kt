package a.a.strip

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.LruCache
import android.util.Size
import android.animation.ValueAnimator
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * The floating notes and the floating gallery. Each is one overlay window that exists only while it
 * is open: closing it drops every view, picture and thread, so nothing stays in memory.
 */
object FloatTools {
    private val open = HashMap<String, ToolWindow>()

    fun isOpen(kind: String) = open.containsKey(kind)

    fun passThrough(on: Boolean) { open.values.toList().forEach { it.passThrough(on) } }

    /** The tools open now (a copy). */
    fun openKinds(): Set<String> = open.keys.toSet()

    fun close(kind: String) {
        open[kind]?.close()
    }

    /** Opens the tool, or closes it when it is already open. */
    fun toggle(ctx: Context, kind: String): Boolean {
        val app = ctx.applicationContext
        val existing = open[kind]
        if (existing != null) {
            if (existing.isMinimized()) existing.restore() else existing.close()
            return true
        }
        if (!WidgetFloat.allowed(app)) return false
        if (kind == "gallery" && !canReadPhotos(app)) {
            WidgetFloat.toast(app, "Give A access to photos (or All files access), then try again")
            runCatching {
                app.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
            return false
        }
        val w: ToolWindow = if (kind == "notes") NotesWindow(app) { open.remove(kind) } else GalleryWindow(app) { open.remove(kind) }
        if (!w.show()) {
            WidgetFloat.toast(app, "It could not be shown")
            return false
        }
        open[kind] = w
        return true
    }

    fun closeAll() {
        open.values.toList().forEach { it.close() }
    }

    private fun canReadPhotos(app: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) return true
        val perm = if (Build.VERSION.SDK_INT >= 33) "android.permission.READ_MEDIA_IMAGES" else "android.permission.READ_EXTERNAL_STORAGE"
        return app.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}

/** A draggable, resizable window with a title bar, the content of the tool, and a corner handle. */
abstract class ToolWindow(protected val app: Context, private val kind: String, private val onClosed: () -> Unit) {
    protected val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    protected val d = app.resources.displayMetrics.density
    protected val handler = Handler(Looper.getMainLooper())
    protected val prefs = app.getSharedPreferences("float_tools", Context.MODE_PRIVATE)
    protected var root: LinearLayout? = null
    protected var lp: WindowManager.LayoutParams? = null
    protected var bar: LinearLayout? = null
    protected var foot: LinearLayout? = null
    protected var titleView: TextView? = null
    protected var closed = false
    private var bubble: FloatBubble? = null
    private var mini = false

    protected fun dp(v: Int) = (v * d).toInt()

    fun isMinimized() = mini

    /** Hides the window and leaves a bubble: drag it anywhere, tap it to bring the window back as it was. */
    fun minimize() {
        val r = root ?: return
        val p = lp ?: return
        if (mini || closed) return
        val b = FloatBubble(app, kind, kind.take(1)) { restore() }
        if (!b.show()) return
        bubble = b
        mini = true
        // Not touchable and no keyboard while hidden; typing is switched on again by tapping in the text.
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        r.visibility = View.GONE
        update()
    }

    /** No touches while the click circle is moving; touchable again after (unless tucked away). */
    fun passThrough(on: Boolean) {
        val p = lp ?: return
        if (root == null) return
        if (on) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else if (!mini) p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        update()
    }

    fun restore() {
        val r = root ?: return
        val p = lp ?: return
        if (!mini) return
        mini = false
        bubble?.hide()
        bubble = null
        p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        if (WidgetFloat.throughNow) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        r.visibility = View.VISIBLE
        update()
    }

    protected abstract val defaultW: Int
    protected abstract val defaultH: Int
    protected abstract fun title(): String
    protected abstract fun content(): View
    protected open fun barButtons(): List<TextView> = emptyList()
    protected open fun footButtons(): List<TextView> = emptyList()
    protected open fun onBarTouched() {}
    protected open fun onClose() {}

    protected fun button(label: String, onClick: () -> Unit): TextView {
        val t = TextView(app)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.minWidth = dp(34)
        t.setPadding(dp(4), 0, dp(4), 0)
        t.setOnClickListener { onClick() }
        return t
    }

    fun show(): Boolean {
        val dm = app.resources.displayMetrics
        val w = prefs.getInt(kind + "_w", dp(defaultW)).coerceIn(dp(160), dm.widthPixels)
        val h = prefs.getInt(kind + "_h", dp(defaultH)).coerceIn(dp(120), dm.heightPixels)
        val r = LinearLayout(app)
        r.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xF2202124.toInt())
        bg.cornerRadius = dp(12).toFloat()
        r.background = bg
        r.clipToOutline = true

        val b = LinearLayout(app)
        b.orientation = LinearLayout.HORIZONTAL
        b.gravity = Gravity.CENTER_VERTICAL
        b.setBackgroundColor(0x33FFFFFF)
        val tv = TextView(app)
        tv.setTextColor(0xFFFFFFFF.toInt())
        tv.textSize = 13f
        tv.setPadding(dp(10), 0, dp(4), 0)
        tv.maxLines = 1
        titleView = tv
        tv.text = title()
        b.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        for (x in barButtons()) b.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.addView(button("–") { minimize() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.addView(button("✕") { close() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bar = b
        r.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        r.addView(content(), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val f = LinearLayout(app)
        f.orientation = LinearLayout.HORIZONTAL
        f.gravity = Gravity.CENTER_VERTICAL
        for (x in footButtons()) f.addView(x, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Opacity bar: drag left to see through the window (20% to 100%), remembered for next time.
        val alphaNow = prefs.getInt(kind + "_alpha", 100).coerceIn(20, 100)
        val sb = SeekBar(app)
        sb.max = 80
        sb.progress = alphaNow - 20
        sb.setPadding(dp(10), 0, dp(10), 0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (!fromUser) return
                lp?.alpha = (v + 20) / 100f
                update()
            }
            override fun onStartTrackingTouch(s: SeekBar?) { onBarTouched() }
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt(kind + "_alpha", (s?.progress ?: 80) + 20).apply()
            }
        })
        f.addView(sb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val grip = TextView(app)
        grip.text = "◢"
        grip.setTextColor(0xAAFFFFFF.toInt())
        grip.gravity = Gravity.CENTER
        f.addView(grip, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))
        foot = f
        r.addView(f, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)))

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        val p = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        if (WidgetFloat.throughNow) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt(kind + "_x", (dm.widthPixels - w) / 2).coerceIn(0, maxOf(0, dm.widthPixels - w))
        p.y = prefs.getInt(kind + "_y", dp(90)).coerceIn(0, maxOf(0, dm.heightPixels - h))
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        p.alpha = alphaNow / 100f
        lp = p
        root = r

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        b.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    onBarTouched()
                    sx = ev.rawX; sy = ev.rawY; ox = p.x; oy = p.y
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (ox + (ev.rawX - sx)).toInt().coerceIn(0, maxOf(0, dm.widthPixels - p.width))
                    p.y = (oy + (ev.rawY - sy)).toInt().coerceIn(0, maxOf(0, dm.heightPixels - p.height))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        var gw = 0
        var gh = 0
        grip.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = ev.rawX; sy = ev.rawY; gw = p.width; gh = p.height }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (gw + (ev.rawX - sx)).toInt().coerceIn(dp(160), maxOf(dp(160), dm.widthPixels - p.x))
                    p.height = (gh + (ev.rawY - sy)).toInt().coerceIn(dp(120), maxOf(dp(120), dm.heightPixels - p.y))
                    update()
                }
                MotionEvent.ACTION_UP -> remember()
            }
            true
        }
        return runCatching { wm.addView(r, p) }.isSuccess
    }

    protected fun update() {
        val r = root ?: return
        val p = lp ?: return
        runCatching { wm.updateViewLayout(r, p) }
    }

    private fun remember() {
        val p = lp ?: return
        prefs.edit().putInt(kind + "_x", p.x).putInt(kind + "_y", p.y).putInt(kind + "_w", p.width).putInt(kind + "_h", p.height).apply()
    }

    /** Lets the keyboard type into this window (on), or hands the screen back to the app underneath (off). */
    protected fun setTyping(on: Boolean) {
        val p = lp ?: return
        p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        update()
    }

    fun close() {
        if (closed) return
        closed = true
        runCatching { onClose() }
        remember()
        bubble?.hide()
        bubble = null
        root?.let { v -> runCatching { wm.removeView(v) } }
        root = null
        onClosed()
    }
}

class NotesWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "notes", onClosed) {
    override val defaultW = 290
    override val defaultH = 320

    private val notes = ArrayList<String>()
    private var idx = 0
    private var size = 16f
    private var edit: EditText? = null
    private var sure = false
    private var delBtn: TextView? = null
    private var listMode = false
    private val checked = LinkedHashSet<Int>()
    private var listDelConfirm = false
    private var listView: android.widget.ListView? = null
    private var editorActions: android.widget.HorizontalScrollView? = null
    private var listBox: LinearLayout? = null
    private var listConfirmBar: LinearLayout? = null
    private var listConfirmLabel: TextView? = null
    private var listAllBtn: TextView? = null
    private var listBtn: TextView? = null
    private val saveRun = Runnable { save() }

    init {
        runCatching {
            val a = JSONArray(prefs.getString("notes_list", "[]"))
            for (n in 0 until a.length()) notes.add(a.getString(n))
        }
        if (notes.isEmpty()) notes.add("")
        idx = prefs.getInt("notes_idx", 0).coerceIn(0, notes.size - 1)
        size = prefs.getFloat("notes_size", 16f)
    }

    override fun title() = if (listMode) "${checked.size} of ${notes.size} selected" else "Note ${idx + 1} of ${notes.size}"

    private fun save() {
        val a = JSONArray()
        for (t in notes) a.put(t)
        prefs.edit().putString("notes_list", a.toString()).putInt("notes_idx", idx).putFloat("notes_size", size).apply()
    }

    private fun showNote() {
        edit?.setText(notes[idx])
        edit?.setSelection(edit?.text?.length ?: 0)
        titleView?.text = title()
        listBtn?.text = "Select (${notes.size})"
        sure = false
        delBtn?.setTextColor(0xFFFFFFFF.toInt())
    }

    private fun keep() {
        val e = edit ?: return
        notes[idx] = e.text?.toString().orEmpty()
    }

    private fun activeText(): String {
        keep()
        val e = edit
        if (e != null && e.hasSelection()) {
            val s = minOf(e.selectionStart, e.selectionEnd).coerceAtLeast(0)
            val en = maxOf(e.selectionStart, e.selectionEnd).coerceAtLeast(s)
            val sub = e.text?.subSequence(s, en)?.toString().orEmpty()
            if (sub.isNotEmpty()) return sub
        }
        return notes.getOrNull(idx).orEmpty()
    }

    private fun copyText(text: String, what: String) {
        if (text.isEmpty()) {
            WidgetFloat.toast(app, "Nothing to copy")
            return
        }
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("A note", text))
        WidgetFloat.toast(app, "Copied $what")
    }

    private fun shareText(text: String) {
        if (text.isEmpty()) {
            WidgetFloat.toast(app, "Nothing to share")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
        runCatching {
            app.startActivity(Intent.createChooser(send, "Share note").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { WidgetFloat.toast(app, "Could not open share") }
    }

    private fun exportTxt(text: String) {
        if (text.isEmpty()) {
            WidgetFloat.toast(app, "Nothing to export")
            return
        }
        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
        val name = "A_Note_$stamp.txt"
        val ok = runCatching {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = android.content.ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val u = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: error("Could not create file")
                app.contentResolver.openOutputStream(u)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                cv.clear()
                cv.put(MediaStore.Downloads.IS_PENDING, 0)
                app.contentResolver.update(u, cv, null, null)
            } else {
                @Suppress("DEPRECATION")
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                java.io.File(dir, name).writeText(text, Charsets.UTF_8)
            }
            true
        }.getOrDefault(false)
        WidgetFloat.toast(app, if (ok) "Saved to Downloads: $name" else "Could not export .txt")
    }

    private fun selectedCombined(): String {
        val picked = checked.filter { it in notes.indices }.sorted()
        return picked.map { notes[it] }.filter { it.isNotEmpty() }.joinToString("\n\n---\n\n")
    }

    private fun refreshList() {
        titleView?.text = title()
        listAllBtn?.text = if (checked.size == notes.size && notes.isNotEmpty()) "None" else "All"
        (listView?.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    private fun setListMode(on: Boolean) {
        if (on) {
            keep()
            save()
            typingOff()
            checked.clear()
            listDelConfirm = false
            listConfirmBar?.visibility = View.GONE
            listMode = true
            editorActions?.visibility = View.GONE
            edit?.visibility = View.GONE
            listBox?.visibility = View.VISIBLE
            refreshList()
        } else {
            listMode = false
            listDelConfirm = false
            listConfirmBar?.visibility = View.GONE
            listBox?.visibility = View.GONE
            editorActions?.visibility = View.VISIBLE
            edit?.visibility = View.VISIBLE
            showNote()
        }
    }

    private fun typingOff() {
        val e = edit ?: return
        e.clearFocus()
        (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(e.windowToken, 0)
        setTyping(false)
    }

    override fun onBarTouched() = typingOff()

    private fun pill(label: String, bgColor: Int = 0x26FFFFFF, onClick: () -> Unit): TextView {
        val t = TextView(app)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(4), dp(10), dp(4))
        val gd = GradientDrawable()
        gd.setColor(bgColor)
        gd.cornerRadius = dp(12).toFloat()
        t.background = gd
        t.setOnClickListener { onClick() }
        return t
    }

    override fun content(): View {
        val wrap = LinearLayout(app)
        wrap.orientation = LinearLayout.VERTICAL

        // Compact secondary strip for Copy / Share / Export .txt / Select multiple notes.
        val actScroll = android.widget.HorizontalScrollView(app)
        actScroll.isHorizontalScrollBarEnabled = false
        actScroll.setBackgroundColor(0x18FFFFFF)
        val actRow = LinearLayout(app)
        actRow.orientation = LinearLayout.HORIZONTAL
        actRow.gravity = Gravity.CENTER_VERTICAL
        actRow.setPadding(dp(8), dp(4), dp(8), dp(4))
        fun addAct(v: TextView) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            actRow.addView(v, lp)
        }
        addAct(pill("Copy") {
            val sel = edit?.hasSelection() == true
            copyText(activeText(), if (sel) "selection" else "note")
        })
        addAct(pill("Share") { shareText(activeText()) })
        addAct(pill("Export .txt") { exportTxt(activeText()) })
        val lb = pill("Select (${notes.size})") { setListMode(true) }
        listBtn = lb
        addAct(lb)
        actScroll.addView(actRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        editorActions = actScroll
        wrap.addView(actScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val e = EditText(app)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setHintTextColor(0x88FFFFFF.toInt())
        e.hint = "Type a note"
        e.textSize = size
        e.gravity = Gravity.TOP or Gravity.START
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        e.background = null
        e.setPadding(dp(10), dp(8), dp(10), dp(8))
        e.setText(notes[idx])
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                notes[idx] = s?.toString().orEmpty()
                handler.removeCallbacks(saveRun)
                handler.postDelayed(saveRun, 500)
            }
        })
        e.setOnTouchListener { v, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                setTyping(true)
                v.postDelayed({
                    v.requestFocus()
                    (app.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(v, 0)
                }, 150)
            }
            false
        }
        edit = e
        wrap.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Multi-note list mode (hidden until "Select" is tapped).
        val lbWrap = LinearLayout(app)
        lbWrap.orientation = LinearLayout.VERTICAL
        lbWrap.visibility = View.GONE

        val lScroll = android.widget.HorizontalScrollView(app)
        lScroll.isHorizontalScrollBarEnabled = false
        lScroll.setBackgroundColor(0x22FFFFFF)
        val lRow = LinearLayout(app)
        lRow.orientation = LinearLayout.HORIZONTAL
        lRow.gravity = Gravity.CENTER_VERTICAL
        lRow.setPadding(dp(8), dp(4), dp(8), dp(4))
        fun addListAct(v: TextView) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            lRow.addView(v, lp)
        }
        val allB = pill("All") {
            if (checked.size == notes.size) checked.clear() else checked.addAll(notes.indices)
            refreshList()
        }
        listAllBtn = allB
        addListAct(allB)
        addListAct(pill("Share") {
            if (checked.isEmpty()) WidgetFloat.toast(app, "Select notes first")
            else shareText(selectedCombined())
        })
        addListAct(pill("Export .txt") {
            if (checked.isEmpty()) WidgetFloat.toast(app, "Select notes first")
            else exportTxt(selectedCombined())
        })
        addListAct(pill("Delete", 0x55FF4444) {
            if (checked.isEmpty()) WidgetFloat.toast(app, "Select notes first")
            else {
                listDelConfirm = true
                listConfirmLabel?.text = "Delete ${checked.size} note(s)?"
                listConfirmBar?.visibility = View.VISIBLE
            }
        })
        addListAct(pill("Done") { setListMode(false) })
        lScroll.addView(lRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        lbWrap.addView(lScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Inline delete confirmation bar for selected notes.
        val cBar = LinearLayout(app)
        cBar.orientation = LinearLayout.HORIZONTAL
        cBar.gravity = Gravity.CENTER_VERTICAL
        cBar.setBackgroundColor(0xCC7F1D1D.toInt())
        cBar.setPadding(dp(10), dp(4), dp(8), dp(4))
        cBar.visibility = View.GONE
        val cLbl = TextView(app)
        cLbl.setTextColor(0xFFFFFFFF.toInt())
        cLbl.textSize = 12f
        listConfirmLabel = cLbl
        cBar.addView(cLbl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cBar.addView(pill("Delete", 0xFFDC2626.toInt()) {
            val toRemove = checked.toSet()
            val kept = ArrayList<String>()
            notes.forEachIndexed { i, s -> if (i !in toRemove) kept.add(s) }
            if (kept.isEmpty()) kept.add("")
            notes.clear()
            notes.addAll(kept)
            idx = idx.coerceIn(0, notes.size - 1)
            checked.clear()
            listDelConfirm = false
            listConfirmBar?.visibility = View.GONE
            save()
            refreshList()
            WidgetFloat.toast(app, "Deleted ${toRemove.size} note(s)")
        }.also {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            it.layoutParams = lp
        })
        cBar.addView(pill("Cancel") {
            listDelConfirm = false
            listConfirmBar?.visibility = View.GONE
        })
        listConfirmBar = cBar
        lbWrap.addView(cBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lv = android.widget.ListView(app)
        lv.divider = android.graphics.drawable.ColorDrawable(0x22FFFFFF)
        lv.dividerHeight = dp(1)
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = notes.size
            override fun getItem(p: Int) = notes[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, old: View?, parent: ViewGroup?): View {
                val row = (old as? LinearLayout) ?: LinearLayout(app).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    val chk = TextView(app).apply {
                        textSize = 15f
                        gravity = Gravity.CENTER
                    }
                    addView(chk, LinearLayout.LayoutParams(dp(28), ViewGroup.LayoutParams.WRAP_CONTENT))
                    val txt = TextView(app).apply {
                        setTextColor(0xFFFFFFFF.toInt())
                        textSize = 13f
                        maxLines = 2
                    }
                    addView(txt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                }
                val chk = row.getChildAt(0) as TextView
                val txt = row.getChildAt(1) as TextView
                val sel = p in checked
                chk.text = if (sel) "☑" else "☐"
                chk.setTextColor(if (sel) 0xFF60A5FA.toInt() else 0xAAFFFFFF.toInt())
                val body = notes[p].trim().replace('\n', ' ')
                txt.text = "${p + 1}. " + if (body.isEmpty()) "(empty note)" else body
                row.setBackgroundColor(if (sel) 0x2660A5FA else if (p == idx) 0x14FFFFFF else 0)
                return row
            }
        }
        lv.setOnItemClickListener { _, _, p, _ ->
            if (p in checked) checked.remove(p) else checked.add(p)
            refreshList()
        }
        lv.setOnItemLongClickListener { _, _, p, _ ->
            idx = p
            setListMode(false)
            true
        }
        listView = lv
        lbWrap.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        listBox = lbWrap
        wrap.addView(lbWrap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        return wrap
    }

    override fun barButtons(): List<TextView> {
        val del = button("🗑") {
            if (listMode) {
                if (checked.isEmpty()) WidgetFloat.toast(app, "Select notes first")
                else {
                    listConfirmLabel?.text = "Delete ${checked.size} note(s)?"
                    listConfirmBar?.visibility = View.VISIBLE
                }
                return@button
            }
            if (!sure) {
                sure = true
                delBtn?.setTextColor(0xFFFF6666.toInt())
                handler.postDelayed({ sure = false; delBtn?.setTextColor(0xFFFFFFFF.toInt()) }, 2500)
            } else {
                if (notes.size > 1) { notes.removeAt(idx); idx = idx.coerceAtMost(notes.size - 1) } else notes[0] = ""
                showNote(); save()
            }
        }
        delBtn = del
        return listOf(
            button("◀") { if (listMode) setListMode(false) else if (idx > 0) { keep(); idx--; showNote(); save() } },
            button("▶") { if (listMode) setListMode(false) else if (idx < notes.size - 1) { keep(); idx++; showNote(); save() } },
            button("＋") { if (listMode) setListMode(false); keep(); notes.add(idx + 1, ""); idx++; showNote(); save() },
            del,
            button("✓") { typingOff() },
        )
    }

    override fun footButtons(): List<TextView> = listOf(
        button("A−") { size = (size - 2f).coerceAtLeast(10f); edit?.textSize = size; save() },
        button("A＋") { size = (size + 2f).coerceAtMost(40f); edit?.textSize = size; save() },
    )

    override fun onClose() {
        handler.removeCallbacks(saveRun)
        typingOff()
        if (!listMode) keep()
        save()
    }
}

class GalleryWindow(app: Context, onClosed: () -> Unit) : ToolWindow(app, "gallery", onClosed) {
    override val defaultW = 320
    override val defaultH = 440

    private var ids = LongArray(0)
    private var grid: GridView? = null
    private var viewer: FrameLayout? = null
    private var big: ImageView? = null
    private var counter: TextView? = null
    private var pos = 0
    private var pool: ExecutorService? = null
    private val thumbs = LruCache<Long, Bitmap>(60)
    private var sc = 1f
    private var tx = 0f
    private var ty = 0f
    private var anim: ValueAnimator? = null

    private var selecting = false
    private val selectedIds = LinkedHashSet<Long>()
    private var selScroll: android.widget.HorizontalScrollView? = null
    private var selAllBtn: TextView? = null
    private var delConfirmBar: LinearLayout? = null
    private var delConfirmLabel: TextView? = null
    private var pendingDeleteTargets: List<Long> = emptyList()
    private var detailsCard: LinearLayout? = null
    private var detailsText: TextView? = null
    private var viewerMenu: android.widget.HorizontalScrollView? = null

    override fun title(): String = when {
        selecting -> "${selectedIds.size} selected"
        ids.isEmpty() -> "Gallery (no photos found)"
        else -> "Gallery"
    }

    private fun uri(id: Long): Uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())

    private fun pill(label: String, bgColor: Int = 0x26FFFFFF, onClick: () -> Unit): TextView {
        val t = TextView(app)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.textSize = 12f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(4), dp(10), dp(4))
        val gd = GradientDrawable()
        gd.setColor(bgColor)
        gd.cornerRadius = dp(12).toFloat()
        t.background = gd
        t.setOnClickListener { onClick() }
        return t
    }

    private fun refreshSelectionUi() {
        titleView?.text = title()
        selScroll?.visibility = if (selecting) View.VISIBLE else View.GONE
        selAllBtn?.text = if (ids.isNotEmpty() && selectedIds.size >= ids.size) "Select none" else "Select all"
        (grid?.adapter as? BaseAdapter)?.notifyDataSetChanged()
    }

    private fun exitSelection() {
        selecting = false
        selectedIds.clear()
        delConfirmBar?.visibility = View.GONE
        pendingDeleteTargets = emptyList()
        refreshSelectionUi()
    }

    private fun shareIds(targetIds: List<Long>) {
        if (targetIds.isEmpty()) {
            WidgetFloat.toast(app, "Select photos first")
            return
        }
        val uris = ArrayList<Uri>(targetIds.size)
        for (id in targetIds) uris.add(uri(id))
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND)
                .setType("image/*")
                .putExtra(Intent.EXTRA_STREAM, uris[0])
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .setType("image/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            app.startActivity(Intent.createChooser(intent, "Share photo(s)").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { WidgetFloat.toast(app, "Could not share photos") }
    }

    private fun openExternal(id: Long) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri(id), "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching {
            app.startActivity(Intent.createChooser(intent, "Open in another app").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { WidgetFloat.toast(app, "No app can open this image") }
    }

    private data class PhotoMeta(val name: String, val path: String, val size: Long, val w: Int, val h: Int, val mime: String, val modifiedSec: Long)

    @Suppress("DEPRECATION")
    private fun queryMeta(id: Long): PhotoMeta? = runCatching {
        val cols = arrayListOf(
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.DATA,
        )
        if (Build.VERSION.SDK_INT >= 29) cols.add(MediaStore.Images.Media.RELATIVE_PATH)
        app.contentResolver.query(uri(id), cols.toTypedArray(), null, null, null)?.use { c ->
            if (!c.moveToFirst()) return@use null
            val name = c.getString(0).orEmpty()
            val sz = c.getLong(1)
            val w = c.getInt(2)
            val h = c.getInt(3)
            val mime = c.getString(4).orEmpty()
            val mod = c.getLong(5)
            val data = c.getString(6).orEmpty()
            val rel = if (Build.VERSION.SDK_INT >= 29) c.getString(7).orEmpty() else ""
            val p = data.ifEmpty { if (rel.isNotEmpty()) "$rel$name" else uri(id).toString() }
            PhotoMeta(name, p, sz, w, h, mime, mod)
        }
    }.getOrNull()

    private fun copyPaths(targetIds: List<Long>) {
        if (targetIds.isEmpty()) {
            WidgetFloat.toast(app, "Select photos first")
            return
        }
        pool?.execute {
            val lines = targetIds.map { id -> queryMeta(id)?.path ?: uri(id).toString() }
            val text = lines.joinToString("\n")
            handler.post {
                if (closed) return@post
                val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("photo path", text))
                WidgetFloat.toast(app, if (lines.size == 1) "Copied path" else "Copied ${lines.size} paths")
            }
        }
    }

    private fun showDetails(targetIds: List<Long>) {
        if (targetIds.isEmpty()) {
            WidgetFloat.toast(app, "Select photos first")
            return
        }
        pool?.execute {
            val metas = targetIds.mapNotNull { id -> queryMeta(id) }
            val body = if (metas.isEmpty()) {
                targetIds.joinToString("\n") { uri(it).toString() }
            } else if (metas.size == 1) {
                val m = metas[0]
                val kb = android.text.format.Formatter.formatShortFileSize(app, m.size)
                val dt = if (m.modifiedSec > 0) java.text.DateFormat.getDateTimeInstance().format(java.util.Date(m.modifiedSec * 1000L)) else "-"
                "Name: ${m.name}\nSize: $kb (${m.w}×${m.h})\nType: ${m.mime}\nModified: $dt\nPath: ${m.path}"
            } else {
                val total = android.text.format.Formatter.formatShortFileSize(app, metas.sumOf { it.size })
                buildString {
                    append("${metas.size} photos · Total $total\n\n")
                    metas.forEach { m -> append("• ${m.name} (${m.w}×${m.h})\n  ${m.path}\n") }
                }.trim()
            }
            handler.post {
                if (closed) return@post
                detailsText?.text = body
                detailsCard?.visibility = View.VISIBLE
            }
        }
    }

    private fun deleteIds(targetIds: List<Long>) {
        if (targetIds.isEmpty()) {
            WidgetFloat.toast(app, "Select photos first")
            return
        }
        val allFiles = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
        if (Build.VERSION.SDK_INT >= 30 && !allFiles) {
            val uris = ArrayList<Uri>(targetIds.map { uri(it) })
            GalleryDeleteActivity.pendingCallback = { ok ->
                handler.post {
                    if (closed) return@post
                    if (ok) {
                        targetIds.forEach { thumbs.remove(it) }
                        if (viewer?.visibility == View.VISIBLE) backToGrid()
                        exitSelection()
                        loadList()
                        WidgetFloat.toast(app, "Deleted ${targetIds.size} photo(s)")
                    } else {
                        WidgetFloat.toast(app, "Delete cancelled")
                    }
                }
            }
            val started = runCatching {
                app.startActivity(
                    Intent(app, GalleryDeleteActivity::class.java)
                        .putParcelableArrayListExtra("uris", uris)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
                true
            }.getOrDefault(false)
            if (!started) {
                GalleryDeleteActivity.pendingCallback = null
                WidgetFloat.toast(app, "Could not open delete confirmation")
            }
        } else {
            pendingDeleteTargets = targetIds
            delConfirmLabel?.text = "Delete ${targetIds.size} photo(s)?"
            delConfirmBar?.visibility = View.VISIBLE
        }
    }

    private fun executeDirectDelete(targetIds: List<Long>) {
        delConfirmBar?.visibility = View.GONE
        pendingDeleteTargets = emptyList()
        pool?.execute {
            var count = 0
            for (id in targetIds) {
                val path = queryMeta(id)?.path
                val rows = runCatching { app.contentResolver.delete(uri(id), null, null) }.getOrDefault(0)
                if (rows > 0) {
                    count++
                } else if (!path.isNullOrEmpty() && !path.startsWith("content://")) {
                    val f = java.io.File(path)
                    if (runCatching { f.delete() }.getOrDefault(false)) {
                        count++
                        runCatching { android.media.MediaScannerConnection.scanFile(app, arrayOf(path), null, null) }
                    }
                }
                thumbs.remove(id)
            }
            handler.post {
                if (closed) return@post
                if (viewer?.visibility == View.VISIBLE) backToGrid()
                exitSelection()
                loadList()
                WidgetFloat.toast(app, if (count > 0) "Deleted $count photo(s)" else "Could not delete selected photo(s)")
            }
        }
    }

    private fun loadList() {
        pool?.execute {
            val out = ArrayList<Long>()
            runCatching {
                app.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    null, null, MediaStore.Images.Media.DATE_ADDED + " DESC",
                )?.use { c ->
                    while (c.moveToNext() && out.size < 300) out.add(c.getLong(0))
                }
            }
            handler.post {
                if (closed) return@post
                ids = out.toLongArray()
                val valid = ids.toSet()
                selectedIds.retainAll(valid)
                refreshSelectionUi()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun thumb(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 29) app.contentResolver.loadThumbnail(uri(id), Size(240, 240), null)
        else MediaStore.Images.Thumbnails.getThumbnail(app.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
    }.getOrNull()

    private fun full(id: Long): Bitmap? = runCatching {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(app.contentResolver, uri(id))) { dec, info, _ ->
                val m = maxOf(info.size.width, info.size.height)
                if (m > 1600) dec.setTargetSampleSize(m / 1600 + 1)
            }
        } else {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o) }
            val m = maxOf(o.outWidth, o.outHeight)
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = if (m > 1600) m / 1600 + 1 else 1
            app.contentResolver.openInputStream(uri(id))?.use { BitmapFactory.decodeStream(it, null, o2) }
        }
    }.getOrNull()

    private fun applyZoom() {
        val v = big ?: return
        v.scaleX = sc; v.scaleY = sc; v.translationX = tx; v.translationY = ty
    }

    /** Keeps the picture from being dragged away from the window. */
    private fun clampPan() {
        val w = viewer?.width ?: return
        val h = viewer?.height ?: return
        val mx = (sc - 1f) * w / 2f
        val my = (sc - 1f) * h / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
    }

    /** Zooms to [target] while the picture point under (fx, fy) stays under the fingers. */
    private fun zoomAbout(fx: Float, fy: Float, target: Float) {
        val v = viewer ?: return
        val cx = v.width / 2f
        val cy = v.height / 2f
        val s1 = sc
        val s2 = target.coerceIn(1f, 6f)
        tx = fx - cx - (fx - cx - tx) * s2 / s1
        ty = fy - cy - (fy - cy - ty) * s2 / s1
        sc = s2
        if (sc <= 1.001f) { sc = 1f; tx = 0f; ty = 0f }
        clampPan()
        applyZoom()
    }

    /** Double tap: zoom in on the tapped spot, or back out when already zoomed. */
    private fun doubleTapZoom(fx: Float, fy: Float) {
        val v = viewer ?: return
        anim?.cancel()
        val s0 = sc; val x0 = tx; val y0 = ty
        val s1: Float; val x1: Float; val y1: Float
        if (sc > 1.05f) {
            s1 = 1f; x1 = 0f; y1 = 0f
        } else {
            s1 = 2.5f
            val mx = (s1 - 1f) * v.width / 2f
            val my = (s1 - 1f) * v.height / 2f
            x1 = (-(fx - v.width / 2f) * (s1 - 1f)).coerceIn(-mx, mx)
            y1 = (-(fy - v.height / 2f) * (s1 - 1f)).coerceIn(-my, my)
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 200
        a.addUpdateListener {
            val t = it.animatedValue as Float
            sc = s0 + (s1 - s0) * t
            tx = x0 + (x1 - x0) * t
            ty = y0 + (y1 - y0) * t
            applyZoom()
        }
        anim = a
        a.start()
    }

    private fun openAt(n: Int) {
        if (ids.isEmpty()) return
        anim?.cancel()
        pos = (n + ids.size) % ids.size
        sc = 1f; tx = 0f; ty = 0f
        applyZoom()
        big?.setImageDrawable(null)
        counter?.text = "${pos + 1} / ${ids.size}"
        viewerMenu?.visibility = View.GONE
        viewer?.visibility = View.VISIBLE
        val id = ids[pos]
        val want = pos
        pool?.execute {
            val b = full(id)
            handler.post { if (!closed && pos == want) big?.setImageBitmap(b) }
        }
    }

    private fun backToGrid() {
        viewerMenu?.visibility = View.GONE
        viewer?.visibility = View.GONE
        big?.setImageDrawable(null)
    }

    override fun content(): View {
        pool = Executors.newFixedThreadPool(2)
        val frame = FrameLayout(app)

        val gridBox = LinearLayout(app)
        gridBox.orientation = LinearLayout.VERTICAL

        // Multi-selection toolbar (shown when selecting).
        val sScroll = android.widget.HorizontalScrollView(app)
        sScroll.isHorizontalScrollBarEnabled = false
        sScroll.setBackgroundColor(0x22FFFFFF)
        sScroll.visibility = View.GONE
        val sRow = LinearLayout(app)
        sRow.orientation = LinearLayout.HORIZONTAL
        sRow.gravity = Gravity.CENTER_VERTICAL
        sRow.setPadding(dp(8), dp(4), dp(8), dp(4))
        fun addSelBtn(v: TextView) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            sRow.addView(v, lp)
        }
        val allBtn = pill("Select all") {
            if (selectedIds.size >= ids.size && ids.isNotEmpty()) selectedIds.clear()
            else { selectedIds.clear(); for (id in ids) selectedIds.add(id) }
            refreshSelectionUi()
        }
        selAllBtn = allBtn
        addSelBtn(allBtn)
        addSelBtn(pill("Share") { shareIds(selectedIds.toList()) })
        addSelBtn(pill("Delete", 0x55FF4444) { deleteIds(selectedIds.toList()) })
        addSelBtn(pill("Copy path") { copyPaths(selectedIds.toList()) })
        addSelBtn(pill("Details") { showDetails(selectedIds.toList()) })
        addSelBtn(pill("Open with") {
            val first = selectedIds.firstOrNull()
            if (first == null) WidgetFloat.toast(app, "Select a photo first") else openExternal(first)
        })
        addSelBtn(pill("Done") { exitSelection() })
        sScroll.addView(sRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        selScroll = sScroll
        gridBox.addView(sScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Inline confirmation bar when deleting with All files access / pre-Android 11.
        val dBar = LinearLayout(app)
        dBar.orientation = LinearLayout.HORIZONTAL
        dBar.gravity = Gravity.CENTER_VERTICAL
        dBar.setBackgroundColor(0xCC7F1D1D.toInt())
        dBar.setPadding(dp(10), dp(4), dp(8), dp(4))
        dBar.visibility = View.GONE
        val dLbl = TextView(app)
        dLbl.setTextColor(0xFFFFFFFF.toInt())
        dLbl.textSize = 12f
        delConfirmLabel = dLbl
        dBar.addView(dLbl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        dBar.addView(pill("Delete", 0xFFDC2626.toInt()) { executeDirectDelete(pendingDeleteTargets) }.also {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            it.layoutParams = lp
        })
        dBar.addView(pill("Cancel") {
            delConfirmBar?.visibility = View.GONE
            pendingDeleteTargets = emptyList()
        })
        delConfirmBar = dBar
        gridBox.addView(dBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val g = GridView(app)
        g.numColumns = GridView.AUTO_FIT
        g.columnWidth = dp(92)
        g.horizontalSpacing = dp(2)
        g.verticalSpacing = dp(2)
        g.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        g.adapter = object : BaseAdapter() {
            override fun getCount() = ids.size
            override fun getItem(p: Int) = ids[p]
            override fun getItemId(p: Int) = ids[p]
            override fun getView(p: Int, old: View?, parent: ViewGroup?): View {
                val cell = (old as? FrameLayout) ?: FrameLayout(app).also { fl ->
                    fl.layoutParams = AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT, dp(92))
                    val iv = ImageView(app).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundColor(0x22FFFFFF)
                    }
                    fl.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    val dim = View(app).apply {
                        setBackgroundColor(0x551E40AF)
                        visibility = View.GONE
                    }
                    fl.addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    val badge = TextView(app).apply {
                        textSize = 12f
                        gravity = Gravity.CENTER
                        setTextColor(0xFFFFFFFF.toInt())
                    }
                    val blp = FrameLayout.LayoutParams(dp(22), dp(22))
                    blp.gravity = Gravity.TOP or Gravity.END
                    blp.setMargins(0, dp(4), dp(4), 0)
                    fl.addView(badge, blp)
                }
                val iv = cell.getChildAt(0) as ImageView
                val dim = cell.getChildAt(1)
                val badge = cell.getChildAt(2) as TextView
                val id = ids[p]
                iv.tag = id
                val cached = thumbs.get(id)
                if (cached != null) {
                    iv.setImageBitmap(cached)
                } else {
                    iv.setImageDrawable(null)
                    pool?.execute {
                        val b = thumb(id)
                        if (b != null) handler.post {
                            if (!closed) { thumbs.put(id, b); if (iv.tag == id) iv.setImageBitmap(b) }
                        }
                    }
                }
                val picked = id in selectedIds
                dim.visibility = if (selecting && picked) View.VISIBLE else View.GONE
                if (selecting) {
                    badge.visibility = View.VISIBLE
                    badge.text = if (picked) "✓" else ""
                    val gd = GradientDrawable()
                    gd.shape = GradientDrawable.OVAL
                    gd.setColor(if (picked) 0xFF2563EB.toInt() else 0x66000000)
                    gd.setStroke(dp(1), 0xFFFFFFFF.toInt())
                    badge.background = gd
                } else {
                    badge.visibility = View.GONE
                }
                return cell
            }
        }
        g.setOnItemClickListener { _, _, p, _ ->
            if (selecting) {
                val id = ids[p]
                if (!selectedIds.remove(id)) selectedIds.add(id)
                refreshSelectionUi()
            } else {
                openAt(p)
            }
        }
        g.setOnItemLongClickListener { _, _, p, _ ->
            val id = ids[p]
            selecting = true
            selectedIds.add(id)
            refreshSelectionUi()
            true
        }
        grid = g
        gridBox.addView(g, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frame.addView(gridBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val vw = FrameLayout(app)
        vw.setBackgroundColor(0xFF000000.toInt())
        vw.visibility = View.GONE
        val iv = ImageView(app)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        big = iv
        // The touches are read on the fixed frame, not on the picture that is being scaled and moved.
        // (Reading them on the picture itself made the coordinates shift while zooming: that was the jump.)
        val sgd = ScaleGestureDetector(
            app,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(det: ScaleGestureDetector): Boolean {
                    zoomAbout(det.focusX, det.focusY, sc * det.scaleFactor)
                    return true
                }
            },
        )
        sgd.isQuickScaleEnabled = false
        val gd = GestureDetector(
            app,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent): Boolean = true
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    doubleTapZoom(e.x, e.y)
                    return true
                }
            },
        )
        var lcx = 0f
        var lcy = 0f
        fun centre(ev: MotionEvent, skip: Int) {
            var sx = 0f; var sy = 0f; var n = 0
            for (i in 0 until ev.pointerCount) {
                if (i == skip) continue
                sx += ev.getX(i); sy += ev.getY(i); n++
            }
            if (n > 0) { lcx = sx / n; lcy = sy / n }
        }
        vw.setOnTouchListener { _, ev ->
            // A running zoom animation stops first. (Stopping it after the detectors ran cancelled the
            // animation that the double tap had just started, so a double tap never zoomed.)
            if (ev.actionMasked == MotionEvent.ACTION_DOWN || ev.actionMasked == MotionEvent.ACTION_POINTER_DOWN) anim?.cancel()
            gd.onTouchEvent(ev)
            sgd.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_DOWN -> centre(ev, -1)
                MotionEvent.ACTION_POINTER_UP -> centre(ev, ev.actionIndex)
                MotionEvent.ACTION_MOVE -> {
                    val ox = lcx; val oy = lcy
                    centre(ev, -1)
                    if (sc > 1f) {
                        tx += lcx - ox; ty += lcy - oy
                        clampPan()
                        applyZoom()
                    }
                }
            }
            true
        }
        vw.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val vMenuScroll = android.widget.HorizontalScrollView(app)
        vMenuScroll.isHorizontalScrollBarEnabled = false
        vMenuScroll.setBackgroundColor(0xBB000000.toInt())
        vMenuScroll.visibility = View.GONE
        val vMenuRow = LinearLayout(app)
        vMenuRow.orientation = LinearLayout.HORIZONTAL
        vMenuRow.setPadding(dp(8), dp(6), dp(8), dp(6))
        fun addVm(v: TextView) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(6)
            vMenuRow.addView(v, lp)
        }
        addVm(pill("Share") { ids.getOrNull(pos)?.let { shareIds(listOf(it)) } })
        addVm(pill("Delete", 0x55FF4444) { ids.getOrNull(pos)?.let { deleteIds(listOf(it)) } })
        addVm(pill("Copy path") { ids.getOrNull(pos)?.let { copyPaths(listOf(it)) } })
        addVm(pill("Details") { ids.getOrNull(pos)?.let { showDetails(listOf(it)) } })
        addVm(pill("Open with") { ids.getOrNull(pos)?.let { openExternal(it) } })
        vMenuScroll.addView(vMenuRow, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        viewerMenu = vMenuScroll

        val ctlBox = LinearLayout(app)
        ctlBox.orientation = LinearLayout.VERTICAL
        ctlBox.addView(vMenuScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val ctl = LinearLayout(app)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        ctl.setBackgroundColor(0x88000000.toInt())
        val cnt = TextView(app)
        cnt.setTextColor(0xFFFFFFFF.toInt())
        cnt.textSize = 12f
        cnt.gravity = Gravity.CENTER
        counter = cnt
        ctl.addView(button("◀") { openAt(pos - 1) }, LinearLayout.LayoutParams(dp(44), dp(34)))
        ctl.addView(button("▦") { backToGrid() }, LinearLayout.LayoutParams(dp(44), dp(34)))
        ctl.addView(cnt, LinearLayout.LayoutParams(dp(64), dp(34)))
        ctl.addView(button("▶") { openAt(pos + 1) }, LinearLayout.LayoutParams(dp(44), dp(34)))
        ctl.addView(button("⋯") {
            vMenuScroll.visibility = if (vMenuScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }, LinearLayout.LayoutParams(dp(40), dp(34)))
        ctlBox.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.BOTTOM
        vw.addView(ctlBox, cl)
        viewer = vw
        frame.addView(vw, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Details popup overlay inside frame.
        val detCard = LinearLayout(app)
        detCard.orientation = LinearLayout.VERTICAL
        detCard.setBackgroundColor(0xEE18191C.toInt())
        detCard.setPadding(dp(12), dp(10), dp(12), dp(10))
        detCard.visibility = View.GONE
        val detHead = TextView(app)
        detHead.text = "Photo details"
        detHead.setTextColor(0xFFFFFFFF.toInt())
        detHead.textSize = 14f
        detCard.addView(detHead)
        val detScroll = android.widget.ScrollView(app)
        val detTxt = TextView(app)
        detTxt.setTextColor(0xFFD1D5DB.toInt())
        detTxt.textSize = 12f
        detTxt.setPadding(0, dp(6), 0, dp(8))
        detTxt.setTextIsSelectable(true)
        detailsText = detTxt
        detScroll.addView(detTxt)
        detCard.addView(detScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val detBtns = LinearLayout(app)
        detBtns.orientation = LinearLayout.HORIZONTAL
        detBtns.gravity = Gravity.END
        detBtns.addView(pill("Copy") { copyTextOrToast(detailsText?.text?.toString().orEmpty()) }.also {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            it.layoutParams = lp
        })
        detBtns.addView(pill("Close") { detCard.visibility = View.GONE })
        detCard.addView(detBtns)
        detailsCard = detCard
        frame.addView(detCard, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loadList()
        return frame
    }

    private fun copyTextOrToast(text: String) {
        if (text.isBlank()) return
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("details", text))
        WidgetFloat.toast(app, "Copied details")
    }

    override fun onClose() {
        if (GalleryDeleteActivity.pendingCallback != null) GalleryDeleteActivity.pendingCallback = null
        anim?.cancel()
        anim = null
        pool?.shutdownNow()
        pool = null
        thumbs.evictAll()
        grid?.adapter = null
        big?.setImageDrawable(null)
        ids = LongArray(0)
        selectedIds.clear()
    }
}

/**
 * Tiny translucent bridge activity used on Android 11+ when A does not have All files access,
 * because MediaStore.createDeleteRequest requires an Activity to run its system confirmation sheet.
 */
class GalleryDeleteActivity : android.app.Activity() {
    companion object {
        var pendingCallback: ((Boolean) -> Unit)? = null
        private const val REQ_DELETE = 4401
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        val uris: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableArrayListExtra("uris", Uri::class.java)
        } else {
            intent.getParcelableArrayListExtra("uris")
        }
        if (Build.VERSION.SDK_INT < 30 || uris.isNullOrEmpty()) {
            pendingCallback?.invoke(false)
            pendingCallback = null
            finish()
            return
        }
        runCatching {
            val pi = MediaStore.createDeleteRequest(contentResolver, uris)
            startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
        }.onFailure {
            pendingCallback?.invoke(false)
            pendingCallback = null
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DELETE) {
            val cb = pendingCallback
            pendingCallback = null
            cb?.invoke(resultCode == RESULT_OK)
            finish()
        }
    }
}
