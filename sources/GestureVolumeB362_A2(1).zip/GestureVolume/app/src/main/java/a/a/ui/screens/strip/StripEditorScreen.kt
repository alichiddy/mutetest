package a.a.ui.screens.strip

import a.a.utils.AppStarter
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.ViewSidebar
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.ui.draw.scale
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import a.a.ui.motion.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import a.a.ui.motion.IconButton
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.gestures.detectTapGestures
import a.a.ui.screens.deck.loadEveryApp
import a.a.ui.screens.deck.AppKinds
import a.a.ui.components.ChoiceChip
import a.a.ui.components.MsBox
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.toSize
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import a.a.strip.StripScope
import a.a.strip.PlusCells
import a.a.strip.StripConfig
import a.a.strip.EdgeFields
import a.a.utils.ActionIcon
import a.a.utils.DeviceActionIcons
import a.a.strip.StripItem
import a.a.strip.StripView
import a.a.ui.components.ActionIconImage
import a.a.ui.components.actionDisplayName
import a.a.ui.screens.deck.InstalledApp
import a.a.ui.screens.deck.loadLaunchableApps
import a.a.ui.viewmodels.MainViewModel
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import a.a.utils.PreviousApp
import a.a.strip.SettingsBackup
import a.a.strip.LauncherModeActivity
import a.a.service.OverlayRuntime
import a.a.strip.FitText
import a.a.share.FilePaths
import a.a.utils.DiagLog
import a.a.strip.IconExport
import a.a.flow.FlowActivity
import a.a.flow.FlowStore
import a.a.strip.ActionSaver
import a.a.flow.NativePicker
import a.a.flow.Step

/**
 * Edits the shortcut strip: the grid itself (tap a cell to select it, then move, copy, blank,
 * delete or edit it), the columns, the cell size, the labels, the position.
 *
 * Every change is saved at once, as one small JSON string, so the settings backup that already
 * copies the preferences file carries the strip too.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun StripEditorScreen(viewModel: MainViewModel, windowId: String = StripScope.MAIN, onNavigateBack: () -> Unit) {
    val pref = viewModel.preference
    val appContext = LocalContext.current
    // The window being edited: the main slider's ("") or a segment's own. Every "strip..." setting goes through [sp];
    // the shared tools (click circle, previous app...) keep using sp.
    val sp = remember(windowId) { StripScope.prefs(appContext, windowId) }
    var cfg by remember { mutableStateOf(StripScope.load(appContext, windowId)) }
    val windowTitle = remember(windowId) {
        if (windowId.isEmpty()) "Cells" else "Cells window of " + (StripScope.ownWindowIds(appContext).firstOrNull { it.first == windowId }?.second ?: "a segment")
    }
    // The folders being edited, from the top: empty = the main strip.
    var path by remember { mutableStateOf(listOf<Int>()) }
    var movingTo by remember { mutableStateOf(false) }
    // Several cells at once: Select mode, the cells ticked, and a cell being dragged.
    var multi by remember { mutableStateOf(false) }
    var lastTapIdx by remember { mutableIntStateOf(-1) }
    var lastTapAt by remember { mutableStateOf(0L) }
    var doubleMsText by remember { mutableStateOf(sp.getInt("stripDoubleTapMs", 400).toString()) }
    val doubleMs = doubleMsText.toLongOrNull() ?: 400L
    val picked = remember { androidx.compose.runtime.mutableStateListOf<Int>() }
    var drag by remember { mutableStateOf<DragInfo?>(null) }
    var viewRoot by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    var upZone by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    // Earlier versions of the strip, for Undo.
    val history = remember { ArrayList<List<StripItem>>() }
    var undoCount by remember { mutableIntStateOf(0) }
    var folderCorner by remember { mutableStateOf(sp.getBoolean("stripFolderCorner", false)) }
    var folderCornerNested by remember { mutableStateOf(sp.getBoolean("stripFolderCornerNested", true)) }
    var folderCenterMode by remember { mutableIntStateOf(sp.getInt("stripFolderCenterMode", 0)) }
    var folderHideMain by remember { mutableStateOf(sp.getBoolean("stripFolderHideMain", false)) }
    var swiftyStyle by remember { mutableStateOf(sp.getBoolean("stripSwifty", false)) }
    var folderDelay by remember { mutableIntStateOf(sp.getInt("stripFolderDelayMs", 200)) }
    var iconKeep by remember { mutableIntStateOf(sp.getInt("stripIconKeepSec", 300)) }
    // The "+" options: a + in empty cells (and where), hold a cell to edit it, a + after the last cell (and where).
    var plusEmptyOn by remember { mutableStateOf(sp.getBoolean("stripPlusEmpty", false)) }
    var plusEmptyMain by remember { mutableStateOf(PlusCells.scopeMain(sp, PlusCells.PREFIX_EMPTY)) }
    var plusEmptyFolders by remember { mutableStateOf(PlusCells.scopeFolders(sp, PlusCells.PREFIX_EMPTY)) }
    var holdEdit by remember { mutableStateOf(sp.getBoolean("stripHoldEdit", false)) }
    var holdCells by remember { mutableStateOf(PlusCells.holdCells(sp)) }
    var holdBlank by remember { mutableStateOf(PlusCells.holdBlank(sp)) }
    var holdSpace by remember { mutableStateOf(PlusCells.holdSpace(sp)) }
    var holdOwn by remember { mutableStateOf(sp.getBoolean("stripHoldOwn", false)) }
    var holdMs by remember { mutableIntStateOf(sp.getInt("stripHoldMs", PlusCells.HOLD_MS_DEFAULT).coerceIn(50, PlusCells.HOLD_MS_MAX)) }
    var plusEndOn by remember { mutableStateOf(sp.getBoolean("stripPlusEnd", false)) }
    var plusEndMain by remember { mutableStateOf(PlusCells.scopeMain(sp, PlusCells.PREFIX_END)) }
    var plusEndFolders by remember { mutableStateOf(PlusCells.scopeFolders(sp, PlusCells.PREFIX_END)) }
    var plusEndGesture by remember { mutableStateOf(PlusCells.endGesture(sp)) }
    var plusEndEditor by remember { mutableStateOf(PlusCells.endEditor(sp)) }
    // The cell just added by the "+" after the last cell: Cancel in its editing window removes it again.
    var newCellAt by remember { mutableIntStateOf(-1) }
    // "Action outside of cells window": what a release above, left of, below or right of the window does.
    var edgeOn by remember { mutableStateOf(sp.getBoolean("stripEdgeOn", false)) }
    // Add a cell / folder / pin / select / undo: kept in view with the cells window (true) or scrolling with the options.
    var addLive by remember { mutableStateOf(sp.getBoolean("stripAddLive", false)) }
    var edgeEditKey by remember { mutableStateOf<String?>(null) }
    // Moving the outside fields: Select mode (tick several), then Move to... a target field, or Delete.
    var edgeSelect by remember { mutableStateOf(false) }
    var edgeMoving by remember { mutableStateOf(false) }
    val edgePicked = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    // Gap to the screen's side, the thumb popup and the effects outside the window.
    var tipDlg by remember { mutableStateOf(false) }
    var lookDlg by remember { mutableStateOf(false) }
    var lookTick by remember { mutableIntStateOf(0) }
    var edgeAllOn by remember { mutableStateOf(sp.getBoolean("stripEdgeAll", false)) }
    var gapMode by remember { mutableStateOf(false) }
    var gapOnS by remember { mutableStateOf(EdgeFields.gapOn(sp)) }
    var edgeTick by remember { mutableIntStateOf(0) }
    // "Previous app" built-in: apps to skip, tracking without Shizuku, and a Test button.
    var prevDlg by remember { mutableStateOf(false) }
    val prevContext = LocalContext.current
    // "Click circle" built-in settings.
    var ccDlg by remember { mutableStateOf(false) }
    val cur: List<StripItem> = itemsAt(cfg.items, path)
    val viewCols = if (path.isEmpty()) cfg.columns.coerceIn(1, 16)
        else (itemsAt(cfg.items, path.dropLast(1)).getOrNull(path.last())?.cols ?: 3).coerceIn(1, 8)
    var selected by remember { mutableIntStateOf(-1) }
    var swapMode by remember { mutableStateOf(false) }
    var editing by remember { mutableIntStateOf(-1) }
    // Save the strip being shown, so a backup has it even when it is still the built-in default.
    LaunchedEffect(Unit) { if (pref.sharedPreferences.getString(StripScope.configKey(windowId), null) == null) StripScope.save(appContext, windowId, cfg) }
    // A cell saved from another screen (Widgets, the script window) is already in the preferences but not in
    // this screen: read it again every time the screen comes back.
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    androidx.compose.runtime.DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                val fresh = StripScope.load(appContext, windowId)
                if (fresh.toJson() != cfg.toJson()) cfg = fresh
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    val sb = SettingsBackup
    fun reload() {
        cfg = StripScope.load(appContext, windowId)
        selected = -1
    }
    fun commit(next: StripConfig, keep: Int = 0) {
        if (next.items != cfg.items) {
            history.add(cfg.items); if (history.size > 40) history.removeAt(0); undoCount = history.size
        }
        val settled = next.copy(items = StripConfig.settlePins(next.items, next.columns.coerceIn(1, 16), sp.getInt("stripPinFollow", StripConfig.PIN_ALL), if (keep > 0) path else null, keep))
        cfg = settled
        StripScope.save(appContext, windowId, settled)
    }

    /** A pinned cell that was moved on purpose now wants the slot it is in. */
    fun anchor(l: MutableList<StripItem>, vararg at: Int) {
        for (a in at) StripConfig.anchorPin(l, a, viewCols)
    }

    fun commitItems(list: List<StripItem>, keep: Int = 0) = commit(cfg.copy(items = setItemsAt(cfg.items, path, list)), keep)

    /** Inside a folder: changes the columns of that folder's own window (1 to 8). */
    fun changeFolderCols(delta: Int) {
        if (path.isEmpty()) return
        val parent = itemsAt(cfg.items, path.dropLast(1))
        val np = parent.mapIndexed { n, it -> if (n == path.last()) it.copy(cols = (it.cols + delta).coerceIn(1, 8)) else it }
        commit(cfg.copy(items = setItemsAt(cfg.items, path.dropLast(1), np)))
    }

    fun undo() {
        if (history.isEmpty()) return
        val prev = history.removeAt(history.size - 1)
        undoCount = history.size
        cfg = cfg.copy(items = prev)
        StripScope.save(appContext, windowId, cfg)
        selected = -1; picked.clear(); swapMode = false
        // Keep only the part of the folder path that still exists.
        var p = listOf<Int>(); var l = prev
        for (i in path) { val k = l.getOrNull(i)?.children ?: break; p = p + i; l = k }
        path = p
    }

    /** Moves cells of the folder being shown into the folder above it. */
    fun moveUp(ids: Set<Int>) {
        if (path.isEmpty()) return
        val moved = cur.filterIndexed { n, _ -> n in ids }.map { if (it.pinned) it.copy(pinned = false) else it }
        val without = setItemsAt(cfg.items, path, cur.filterIndexed { n, _ -> n !in ids })
        commit(cfg.copy(items = setItemsAt(without, path.dropLast(1), itemsAt(without, path.dropLast(1)) + moved)))
    }

    fun applyDrop(d: DragInfo) {
        val ids = d.ids.toSet()
        when {
            d.up && path.isNotEmpty() -> moveUp(ids)
            d.target >= 0 && d.target !in ids && cur[d.target].isFolder -> commitItems(moveIntoFolder(cur, ids, d.target))
            d.target >= 0 && d.target !in ids -> {
                val movedRefs = ids.map { cur[it] }
                val l = moveToSlot(cur, ids, d.target).toMutableList()
                for (n in l.indices) if (l[n].pinned && movedRefs.any { m -> m === l[n] }) StripConfig.anchorPin(l, n, viewCols)
                commitItems(l)
            }
            else -> return
        }
        // The move is finished: nothing stays selected and Select mode ends, so no "move" options linger.
        selected = -1; picked.clear(); multi = false; movingTo = false; swapMode = false
    }

    // Back goes up one folder first, and leaves the editor only from the top level.
    val goBack: () -> Unit = {
        if (path.isNotEmpty()) { path = path.dropLast(1); selected = -1; swapMode = false; picked.clear(); movingTo = false; drag = null } else onNavigateBack()
    }
    androidx.activity.compose.BackHandler(enabled = true) { goBack() }

    // The cells window with the outside fields around it: the part that stays in view while the options scroll.
    val livePart: @Composable () -> Unit = {
                // The cells are drawn by the strip's own view, so they look exactly as they do
                // when the strip slides in, at the size they will have on this screen.
                if (path.isNotEmpty()) Box(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        .border(1.dp, if (drag?.up == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        .onGloballyPositioned { upZone = androidx.compose.ui.geometry.Rect(it.positionInRoot(), it.size.toSize()) }
                        .padding(10.dp),
                ) { Text("⬆ Drag cells here to move them out, into the folder above", fontSize = 12.sp) }
                androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxWidth()) {
                    val density = androidx.compose.ui.platform.LocalDensity.current
                    val ctx = LocalContext.current
                    // Sized from the screen, exactly as the strip is when it slides in.
                    val dm = ctx.resources.displayMetrics
                    val screenW = minOf(dm.widthPixels, dm.heightPixels).toFloat()
                    val screenH = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
                    // Folder cells are the same size as the main strip's.
                    val rootCols = cfg.columns.coerceIn(1, 16)
                    val endMain = PlusCells.end(sp, folder = false, gesture = false)
                    val rowsN = ((cfg.items.size + (if (endMain) 1 else 0) + rootCols - 1) / rootCols).coerceAtLeast(1)
                    // The outside fields frame the grid on the main window (not inside folders). The cells window keeps
                    // its true size; the fields take what is left around it.
                    val frame = path.isEmpty()
                    val edgeGapF = sp.getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                    val fitW = (screenW * 0.94f) / (rootCols * (1f + edgeGapF) + edgeGapF)
                    val fitH = screenH * 0.88f / (rowsN * (1f + edgeGapF) + edgeGapF)
                    val cell = (minOf(fitW, fitH) * cfg.sizePct / 100f).toInt().coerceAtLeast(24)
                    val view = remember(cur, cell, viewCols, cfg.showLabels, lookTick, path.isNotEmpty()) {
                        StripView(
                            ctx, cur, cell, viewCols, cfg.showLabels, folderLook = path.isNotEmpty(),
                            plusEmpty = PlusCells.empty(sp, path.isNotEmpty()), plusEnd = PlusCells.end(sp, path.isNotEmpty(), gesture = false),
                        ).apply { setScreenOrigin(0f, 0f); editorMode = true }
                    }
                    val panel: @Composable () -> Unit = {
                        // Keyed on the view, so a new one (more cells, another size) replaces the old at once.
                        androidx.compose.runtime.key(view) {
                            androidx.compose.ui.viewinterop.AndroidView(
                                factory = { view },
                                update = {
                                    it.setMarked(drag?.ids?.toSet() ?: if (multi) picked.toSet() else emptySet())
                                    it.highlight(if (drag != null) drag!!.target else if (multi) -1 else selected)
                                },
                                modifier = Modifier.requiredSize(
                                    with(density) { view.panelWidthPx.toDp() },
                                    with(density) { view.panelHeightPx.toDp() },
                                ).onGloballyPositioned { viewRoot = it.positionInRoot() }
                                .pointerInput(view) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { off ->
                                            val idx = view.cellAt(off.x, off.y, exact = true)
                                            if (idx >= 0) drag = DragInfo(if (multi && idx in picked) picked.sorted() else listOf(idx), idx, false)
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            drag?.let { d ->
                                                val p = change.position
                                                drag = d.copy(target = view.cellAt(p.x, p.y, exact = true), up = upZone?.contains(viewRoot + p) == true)
                                            }
                                        },
                                        onDragEnd = { val d = drag; drag = null; if (d != null) applyDrop(d) },
                                        onDragCancel = { drag = null },
                                    )
                                }.pointerInput(view, swapMode, selected, multi) {
                                    detectTapGestures { off ->
                                val idx = view.cellAt(off.x, off.y, exact = true)
                                // Option "+ after the last cell": a tap adds a blank cell and opens its editing window;
                                // Cancel there removes it again.
                                if (!multi && !swapMode && idx < 0 && view.endSlotAt(off.x, off.y, exact = true)) {
                                    lastTapIdx = -1
                                    val fresh = StripItem("", "", "")
                                    commitItems(cur + fresh, 1)
                                    val made = itemsAt(cfg.items, path)
                                    val at = made.indexOfFirst { it === fresh }.let { if (it >= 0) it else made.size - 1 }
                                    newCellAt = at; selected = at; editing = at
                                    return@detectTapGestures
                                }
                                // Option "+ in empty cells": a tap on a blank cell opens its editing window at once.
                                if (!multi && !swapMode && view.plusEmpty && idx in cur.indices &&
                                    cur[idx].let { it.action.isEmpty() && it.label.isEmpty() && it.icon.isEmpty() && !it.isFolder }
                                ) {
                                    lastTapIdx = -1; selected = idx; editing = idx
                                    return@detectTapGestures
                                }
                                // The tap always selects at once; a second tap on the same folder within the
                                // chosen time opens it (nothing waits for a double tap).
                                val nowMs = android.os.SystemClock.uptimeMillis()
                                if (!multi && idx in cur.indices && cur[idx].isFolder && idx == lastTapIdx && nowMs - lastTapAt <= doubleMs) {
                                    lastTapIdx = -1; path = path + idx; selected = -1; swapMode = false
                                    return@detectTapGestures
                                }
                                // Same for a cell: a quick second tap opens its editing window.
                                if (!multi && idx in cur.indices && !cur[idx].isFolder && idx == lastTapIdx && nowMs - lastTapAt <= doubleMs) {
                                    lastTapIdx = -1; selected = idx; swapMode = false; editing = idx
                                    return@detectTapGestures
                                }
                                lastTapIdx = idx; lastTapAt = nowMs
                                if (idx >= 0) {
                                    val s0 = selected
                                    if (multi) {
                                        if (idx in picked) picked.remove(idx) else picked.add(idx)
                                    } else if (swapMode && s0 in cur.indices && s0 != idx) {
                                        val l = cur.toMutableList()
                                        val t = l[s0]; l[s0] = l[idx]; l[idx] = t
                                        anchor(l, s0, idx)
                                        commitItems(l); selected = idx; swapMode = false
                                    } else {
                                        selected = idx
                                    }
                                }
                            }
                                },
                            )
                        }
                    }
                    val availW = maxWidth
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (frame) {
                            val pw = with(density) { view.panelWidthPx.toDp() }
                            val ph = with(density) { view.panelHeightPx.toDp() }
                            EdgeFrame(
                                sp = sp, tick = edgeTick, enabled = edgeOn,
                                panelW = pw, panelH = ph, bar = ((availW - pw) / 2f).coerceIn(EDGE_MIN, EDGE_BAR), availW = availW,
                                onEdit = { k ->
                                    if (gapMode && gapOnS) {
                                        val (sd, z) = EdgeFields.parse(k)
                                        EdgeFields.setGapActive(sp, sd, z, !EdgeFields.gapActive(sp, sd, z)); edgeTick++
                                    } else if (!edgeSelect) edgeEditKey = k
                                    else if (edgeMoving) {
                                        val (sd, z) = EdgeFields.parse(k)
                                        val msg = EdgeFields.move(sp, edgePicked.toList(), sd, z)
                                        if (msg == null) { status = "Moved ${edgePicked.size}"; edgePicked.clear(); edgeMoving = false; edgeTick++ } else status = msg
                                    } else if (k in edgePicked) edgePicked.remove(k) else edgePicked.add(k)
                                },
                                marked = edgePicked.toSet(),
                                onSwap = { a, b -> EdgeFields.swap(sp, a, b); status = "Swapped"; edgeTick++ },
                                content = panel,
                            )
                        } else panel()
                    }
                }
    }

    // Add a cell, add a folder, pin, select, undo: icons only, in one row. The switch at the end chooses whether the row
    // stays in view with the cells window (on) or scrolls with the options (off).
    val buttonsPart: @Composable () -> Unit = {
        val ic = androidx.compose.material.icons.Icons.Filled
        // Pin: the picked cells (Select mode) or the selected cell keep their own slot. All pinned already = unpin.
        val pinTargets: Set<Int> = if (multi) picked.toSet() else if (selected in cur.indices) setOf(selected) else emptySet()
        val allPinned = pinTargets.isNotEmpty() && pinTargets.all { cur.getOrNull(it)?.pinned == true }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(a.a.ui.components.rowColor())
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            ToolIcon(ic.Add, "Add a cell") {
                val blankAt = StripConfig.firstBlank(cur)
                if (blankAt >= 0) { selected = blankAt; editing = blankAt }
                else {
                    val fresh = StripItem("", "", "")
                    val (list, keep) = StripConfig.withNewCell(cur, fresh)
                    commitItems(list, keep)
                    val at = itemsAt(cfg.items, path).indexOfFirst { it === fresh }
                    selected = at; editing = at
                }
            }
            ToolIcon(ic.CreateNewFolder, "Add a folder") {
                val fresh = StripItem(uniqueFolderName(cur), "📁", "", children = emptyList())
                commitItems(StripConfig.withNewCell(cur, fresh).first)
                selected = itemsAt(cfg.items, path).indexOfFirst { it === fresh }
            }
            ToolIcon(
                if (allPinned) androidx.compose.material.icons.Icons.Outlined.PushPin else ic.PushPin,
                if (allPinned) "Unpin" else "Pin", lit = allPinned,
            ) {
                if (pinTargets.isEmpty()) {
                    status = if (multi) "Tap the cells you want to pin first." else "Tap a cell first, then Pin."
                } else {
                    val l = cur.toMutableList()
                    for (n in pinTargets) if (n in l.indices) {
                        if (allPinned) l[n] = l[n].copy(pinned = false)
                        else { l[n] = l[n].copy(pinned = true); StripConfig.anchorPin(l, n, viewCols) }
                    }
                    commitItems(l)
                    status = ""
                }
            }
            ToolIcon(ic.Checklist, "Select several cells", lit = multi) {
                multi = !multi; picked.clear(); selected = -1; swapMode = false
            }
            ToolIcon(Icons.AutoMirrored.Filled.Undo, "Undo", enabled = undoCount > 0) { undo() }
            Column(Modifier.padding(start = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Switch(
                    checked = addLive,
                    onCheckedChange = { addLive = it; sp.edit().putBoolean("stripAddLive", it).apply() },
                    modifier = Modifier.scale(0.75f),
                )
                Text("Fixed", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(windowTitle) },
                navigationIcon = {
                    IconButton(onClick = goBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        bottomBar = {
            val i = selected
            if (multi && picked.isNotEmpty()) {
                Surface(tonalElevation = 6.dp) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text("${picked.size} selected", Modifier.padding(8.dp), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                        TextButton(onClick = { movingTo = true }) { Text("Move to…") }
                        TextButton(onClick = {
                            val ids = picked.sorted()
                            val kids = ids.map { cur[it] }.map { if (it.pinned) it.copy(pinned = false) else it }
                            val l = cur.filterIndexed { n, _ -> n !in ids }.toMutableList()
                            l.add(ids.first().coerceAtMost(l.size), StripItem(uniqueFolderName(cur), "📁", "", children = kids))
                            commitItems(l); picked.clear()
                        }) { Text("Make folder of them") }
                        TextButton(onClick = {
                            val ids = picked.toSet()
                            commitItems(StripConfig.deleteCells(cur, ids)); picked.clear()
                        }) { Text("Delete") }
                        TextButton(onClick = { picked.clear() }) { Text("Clear") }
                    }
                }
            } else if (i in cur.indices) {
                Surface(tonalElevation = 6.dp) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        TextButton(onClick = { editing = i }) { Text("Edit") }
                        if (cur[i].isFolder) TextButton(onClick = { path = path + i; selected = -1; swapMode = false }) { Text("Open ▸") }
                        // A new folder goes in before this cell, which moves one place on, like Blank.
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i, StripItem(uniqueFolderName(cur), "📁", "", children = emptyList())); commitItems(l)
                        }) { Text("Make folder") }
                        TextButton(onClick = { movingTo = true }) { Text("Move to…") }
                        TextButton(onClick = {
                            if (i > 0) {
                                val l = cur.toMutableList()
                                l.add(i - 1, l.removeAt(i)); anchor(l, i - 1, i); commitItems(l); selected = i - 1
                            }
                        }) { Text("◀") }
                        TextButton(onClick = {
                            if (i < cur.size - 1) {
                                val l = cur.toMutableList()
                                l.add(i + 1, l.removeAt(i)); anchor(l, i, i + 1); commitItems(l); selected = i + 1
                            }
                        }) { Text("▶") }
                        TextButton(onClick = { swapMode = !swapMode }) {
                            Text(if (swapMode) "Swap: tap a cell" else "Swap…")
                        }
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i + 1, cur[i].copy(pinned = false)); commitItems(l); selected = i + 1
                        }) { Text("Copy") }
                        TextButton(onClick = {
                            val l = cur.toMutableList(); l.add(i, StripItem("", "", "")); commitItems(l)
                        }) { Text("Blank") }
                        TextButton(onClick = {
                            commitItems(StripConfig.deleteCells(cur, setOf(i))); selected = -1; swapMode = false
                        }) { Text("Delete") }
                        TextButton(onClick = { selected = -1; swapMode = false }) { Text("✕") }
                    }
                }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // The part that stays: the cells window with its outside fields (and the buttons when "Fixed" is on). If it is
            // taller than most of the screen it scrolls by itself, so the options always keep some room.
            Column(
                Modifier.fillMaxWidth()
                    .heightIn(max = (androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp * 0.58f).dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                val note = status.takeIf { it.isNotEmpty() }
                    ?: drag?.let { "Moving ${it.ids.size} cell(s): let go on a folder to put them inside, or on a cell to place them there." }
                if (note != null) Text(
                    note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
                livePart()
                if (addLive) { Spacer(Modifier.height(8.dp)); buttonsPart() }
            }
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
            if (path.isNotEmpty()) item {
                val names = path.indices.map { n -> itemsAt(cfg.items, path.take(n)).getOrNull(path[n])?.label?.ifBlank { "Folder" } ?: "Folder" }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                    OutlinedButton(onClick = { path = path.dropLast(1); selected = -1; swapMode = false }) { Text("↑ Up") }
                    Text("  📁 " + names.joinToString(" › "), Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                }
                StepperRow("Folder columns", "$viewCols", { changeFolderCols(-1) }, { changeFolderCols(1) })
            }
            if (path.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                    SwitchRow(
                        "Actions outside the window", edgeOn, a.a.ui.components.cardShape(0, 1),
                        icon = androidx.compose.material.icons.Icons.Filled.OpenWith,
                        summary = "Let go on a field around the cells window to run its action",
                        info = "Slide in, move the thumb out of the cells window and let go over a field: its action runs. Use − and + beside the grid to cut a side into 2-6 equal fields. The window is shown at its true size with the real field shapes (corners cut at 45°); only a strip of each field is drawn here, on screen they go on to the edge. Tap a field to set its shortcut, name and icon. Hold a field and drag it onto another to swap them, or onto an empty one to move it. Select fields lets you move or delete several at once.",
                    ) {
                        edgeOn = it; sp.edit().putBoolean("stripEdgeOn", it).apply()
                    }
                    // Everything that belongs to the outside fields is hidden while they are off.
                    if (edgeOn) {
                        Spacer(Modifier.height(6.dp))
                        EdgeCounts(sp, edgeTick, { edgeTick++ }) {
                            if (!gapMode) FlowRow(
                                Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(2.dp),
                            ) {
                                OutlinedButton(onClick = { edgeSelect = !edgeSelect; edgePicked.clear(); edgeMoving = false }) {
                                    Text(if (edgeSelect) "Select fields ✓" else "Select fields")
                                }
                                if (edgeSelect) {
                                    Text("${edgePicked.size} selected", Modifier.padding(8.dp), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                                    TextButton(enabled = edgePicked.isNotEmpty(), onClick = { edgeMoving = !edgeMoving }) {
                                        Text(if (edgeMoving) "Tap the target field…" else "Move to…")
                                    }
                                    TextButton(enabled = edgePicked.isNotEmpty(), onClick = {
                                        EdgeFields.clearMany(sp, edgePicked.toList())
                                        status = "Deleted ${edgePicked.size}"; edgePicked.clear(); edgeMoving = false; edgeTick++
                                    }) { Text("Delete") }
                                    TextButton(onClick = { edgePicked.clear(); edgeMoving = false }) { Text("Clear") }
                                }
                            }
                        }
                    }
                }
            }
            item {
                Text(
                    if (multi) "Select mode: tap the cells you want, then hold the last one to drag them all."
                    else "Tap a cell to select it. Hold and drag a cell to move it. Same order as the cells window on screen.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 6.dp),
                )
            }
            if (!addLive) item { buttonsPart() }
            if (path.isEmpty()) item {
                GapPanel(sp, gapOnS, { gapOnS = it }, gapMode, { gapMode = it }) { edgeTick++ }
            }
            item {
                val ic = androidx.compose.material.icons.Icons.Filled
                val pickCtx = androidx.compose.ui.platform.LocalContext.current
                var pickAsk by remember { mutableStateOf(a.a.strip.ShortcutTools.askOnPick(pickCtx)) }

                CardGroup("Grid and look", "How the cells window is laid out") {
                    row { sh ->
                        if (path.isEmpty()) StepRow(
                            "Columns", "${cfg.columns}", sh,
                            { commit(cfg.copy(columns = (cfg.columns - 1).coerceAtLeast(1))) },
                            { commit(cfg.copy(columns = (cfg.columns + 1).coerceAtMost(16))) },
                            icon = ic.ViewColumn, summary = "Cells in each row",
                        ) else StepRow(
                            "Folder columns", "$viewCols", sh, { changeFolderCols(-1) }, { changeFolderCols(1) },
                            icon = ic.ViewColumn, summary = "Cells in each row of this folder",
                        )
                    }
                    row { sh ->
                        StepRow(
                            "Cell size", "${cfg.sizePct}%", sh,
                            { commit(cfg.copy(sizePct = (cfg.sizePct - 4).coerceAtLeast(30))) },
                            { commit(cfg.copy(sizePct = (cfg.sizePct + 4).coerceAtMost(100))) },
                            icon = ic.AspectRatio, summary = "How big each cell is",
                        )
                    }
                    row { sh ->
                        SwitchRow("Names under icons", cfg.showLabels, sh, icon = ic.Visibility, summary = "Write each cell's name below its icon") {
                            commit(cfg.copy(showLabels = it))
                        }
                    }
                    row { sh ->
                        SwitchRow("Centered", cfg.centered, sh, icon = ic.OpenWith, summary = "Off: the window opens beside the bar") {
                            commit(cfg.copy(centered = it))
                        }
                    }
                    row { sh ->
                        SwitchRow(
                            "Swiftly Switch style", swiftyStyle, sh, icon = ic.Animation,
                            summary = "The window opens under the thumb and the cells fly out",
                            info = "Each cell gets a round touch zone, and a cell fades to its lit colour instead of jumping.",
                        ) { swiftyStyle = it; sp.edit().putBoolean("stripSwifty", it).apply() }
                    }
                    row { sh ->
                        StepRow(
                            "Keep icons ready",
                            when (iconKeep) { 0 -> "off"; in 1..119 -> "$iconKeep s"; else -> "${iconKeep / 60} min" }, sh,
                            {
                                iconKeep = iconKeepSteps.lastOrNull { it < iconKeep } ?: 0
                                sp.edit().putInt("stripIconKeepSec", iconKeep).apply(); a.a.strip.IconCache.clear()
                            },
                            {
                                iconKeep = iconKeepSteps.firstOrNull { it > iconKeep } ?: iconKeepSteps.last()
                                sp.edit().putInt("stripIconKeepSec", iconKeep).apply()
                            },
                            icon = ic.Memory, summary = "The window opens faster; the icons are let go after this time",
                        )
                    }
                }

                CardGroup("Folders", "How a folder opens from a cell") {
                    row { sh ->
                        SwitchRow(
                            "Folders in a corner", folderCorner, sh, icon = ic.ViewSidebar,
                            summary = "They open inside the cells window and share that corner",
                        ) { folderCorner = it; sp.edit().putBoolean("stripFolderCorner", it).apply() }
                    }
                    if (folderCorner) {
                        row { sh ->
                            SwitchRow("Also folders inside folders", folderCornerNested, sh) {
                                folderCornerNested = it; sp.edit().putBoolean("stripFolderCornerNested", it).apply()
                            }
                        }
                        row { sh ->
                            SwitchRow(
                                "Centre the other folders on their cell", folderCenterMode == 1, sh,
                                summary = "Folders not in a corner. Off: the thumb is in the middle of the folder",
                            ) { folderCenterMode = if (it) 1 else 0; sp.edit().putInt("stripFolderCenterMode", folderCenterMode).apply() }
                        }
                    }
                    row { sh ->
                        SwitchRow(
                            "Hide the window while a folder is open", folderHideMain, sh, icon = ic.VisibilityOff,
                            summary = "It comes back when the thumb leaves the folder",
                        ) { folderHideMain = it; sp.edit().putBoolean("stripFolderHideMain", it).apply() }
                    }
                    row { sh ->
                        StepRow(
                            "Folder opens after", if (folderDelay == 0) "at once" else "$folderDelay ms", sh,
                            { folderDelay = (folderDelay - 50).coerceAtLeast(0); sp.edit().putInt("stripFolderDelayMs", folderDelay).apply() },
                            { folderDelay = (folderDelay + 50).coerceAtMost(1000); sp.edit().putInt("stripFolderDelayMs", folderDelay).apply() },
                            icon = ic.Timer, summary = "How long the thumb rests on a folder",
                        )
                    }
                }

                CardGroup("Touch and editing", "How the thumb edits and picks cells") {
                    row { sh ->
                        StepRow(
                            "Double-tap time", "$doubleMs ms", sh,
                            { val v = (doubleMs - 50).coerceAtLeast(100).toInt(); doubleMsText = v.toString(); sp.edit().putInt("stripDoubleTapMs", v).apply() },
                            { val v = (doubleMs + 50).coerceAtMost(1000).toInt(); doubleMsText = v.toString(); sp.edit().putInt("stripDoubleTapMs", v).apply() },
                            icon = ic.TouchApp, summary = "Two taps closer than this count as a double tap",
                        )
                    }
                    row { sh ->
                        SwitchRow(
                            "Ask before using a picked shortcut", pickAsk, sh, icon = ic.Checklist,
                            summary = "Test, Add to launcher or Use. Off: it is picked at once",
                        ) { pickAsk = it; a.a.strip.ShortcutTools.setAskOnPick(pickCtx, it) }
                    }
                    row { sh ->
                        SwitchRow(
                            "+ in empty cells", plusEmptyOn, sh, icon = ic.Add,
                            summary = "Tap it here, or let go on it in the cells window, to set that cell's action",
                        ) { plusEmptyOn = it; sp.edit().putBoolean("stripPlusEmpty", it).apply(); lookTick++ }
                    }
                    if (plusEmptyOn) row { sh ->
                        // Each button on = the + shows there; off = it does not.
                        ChipsCardRow("Show the + in", listOf("Main cells window" to plusEmptyMain, "Folders" to plusEmptyFolders), sh, {
                            if (it == 0) plusEmptyMain = !plusEmptyMain else plusEmptyFolders = !plusEmptyFolders
                            sp.edit().putBoolean("stripPlusEmptyMain", plusEmptyMain).putBoolean("stripPlusEmptyFolders", plusEmptyFolders).apply(); lookTick++
                        })
                    }
                    row { sh ->
                        SwitchRow(
                            "Hold a cell to edit it", holdEdit, sh, icon = ic.Edit,
                            summary = "Rest the thumb on a cell and its editing window opens",
                        ) { holdEdit = it; sp.edit().putBoolean("stripHoldEdit", it).apply() }
                    }
                    if (holdEdit) {
                        row { sh ->
                            // Only the chosen buttons count; all three together make the hold work everywhere in the window.
                            ChipsCardRow(
                                "Hold works on", listOf("Cells" to holdCells, "Blank cells" to holdBlank, "Empty space" to holdSpace), sh, {
                                    when (it) {
                                        0 -> { holdCells = !holdCells; sp.edit().putBoolean("stripHoldCells", holdCells).apply() }
                                        1 -> { holdBlank = !holdBlank; sp.edit().putBoolean("stripHoldBlank", holdBlank).apply() }
                                        else -> { holdSpace = !holdSpace; sp.edit().putBoolean("stripHoldSpace", holdSpace).apply() }
                                    }
                                },
                                summary = if (holdSpace) "Holding on empty space starts a new cell: its editing window opens, and the cell is added only when you save it."
                                else "Tap each one to turn it on or off",
                            )
                        }
                        row { sh ->
                            // On = the system's hold time; off = a hold time of your own.
                            ChipsCardRow(
                                "Hold time", listOf("System's default" to !holdOwn), sh,
                                { holdOwn = !holdOwn; sp.edit().putBoolean("stripHoldOwn", holdOwn).apply() },
                                below = if (holdOwn) ({
                                    MsBox("Hold time", holdMs, PlusCells.HOLD_MS_MAX, 3000) {
                                        holdMs = it.coerceIn(50, PlusCells.HOLD_MS_MAX); sp.edit().putInt("stripHoldMs", holdMs).apply()
                                    }
                                }) else null,
                            )
                        }
                    }
                    row { sh ->
                        SwitchRow(
                            "+ after the last cell", plusEndOn, sh, icon = ic.Add,
                            summary = "Adds a blank cell and opens its editing window. Cancel removes the cell again",
                            info = "The + shows whether or not there is an empty cell. Tap it, or let the thumb go on it.",
                        ) { plusEndOn = it; sp.edit().putBoolean("stripPlusEnd", it).apply(); lookTick++ }
                    }
                    if (plusEndOn) {
                        row { sh ->
                            ChipsCardRow("Show the + in", listOf("Main cells window" to plusEndMain, "Folders" to plusEndFolders), sh, {
                                if (it == 0) plusEndMain = !plusEndMain else plusEndFolders = !plusEndFolders
                                sp.edit().putBoolean("stripPlusEndMain", plusEndMain).putBoolean("stripPlusEndFolders", plusEndFolders).apply(); lookTick++
                            })
                        }
                        row { sh ->
                            ChipsCardRow(
                                "Show it", listOf("From a gesture (like Slide-in)" to plusEndGesture, "In the cells editing window" to plusEndEditor), sh, {
                                    if (it == 0) plusEndGesture = !plusEndGesture else plusEndEditor = !plusEndEditor
                                    sp.edit().putBoolean("stripPlusEndGesture", plusEndGesture).putBoolean("stripPlusEndEditor", plusEndEditor).apply(); lookTick++
                                },
                            )
                        }
                    }
                }

                CardGroup("After a shortcut runs", "For all cells. A cell can set its own") {
                    row { sh ->
                        StepRow(
                            "Stay on screen", if (cfg.stay == 0) "off" else "${cfg.stay} s", sh,
                            { commit(cfg.copy(stay = (cfg.stay - 1).coerceAtLeast(0))) },
                            { commit(cfg.copy(stay = (cfg.stay + 1).coerceAtMost(60))) },
                            icon = ic.Timer, summary = "How long the window stays open",
                        )
                    }
                    row { sh ->
                        StepRow(
                            "Toast message", toastName(cfg.toast), sh,
                            { commit(cfg.copy(toast = (cfg.toast - 1).coerceAtLeast(0))) },
                            { commit(cfg.copy(toast = (cfg.toast + 1).coerceAtMost(2))) },
                            icon = ic.Sms, summary = "A short note about what ran",
                        )
                    }
                    row { sh ->
                        StepRow(
                            "Notification", if (cfg.notify == 0) "off" else "${cfg.notify} s", sh,
                            { commit(cfg.copy(notify = (cfg.notify - 1).coerceAtLeast(0))) },
                            { commit(cfg.copy(notify = (cfg.notify + 1).coerceAtMost(120))) },
                            icon = ic.Notifications, summary = "How long a notification about it stays",
                        )
                    }
                }

                CardGroup(
                    "More settings",
                    if (windowId.isNotEmpty()) "Widgets and Launcher mode, Previous app and Click circle are shared by all cells windows." else null,
                ) {
                    row { sh -> LinkRow("Look of the cells", "Colours, shapes and effects of the cells", sh, ic.Palette) { lookDlg = true } }
                    row { sh -> LinkRow("Gap, popup and effects", "The band, the thumb popup and the outside fields' look", sh, ic.Tune) { tipDlg = true } }
                    row { sh -> LinkRow("Previous app", "Which apps it skips and how it tracks them", sh, ic.History) { prevDlg = true } }
                    row { sh -> LinkRow("Click circle", "Speed, timing and how it taps", sh, ic.TouchApp) { ccDlg = true } }
                    row { sh ->
                        LinkRow("Widgets and Launcher mode", "Catch shortcuts pinned by other apps, and open Widgets", sh, ic.Widgets) {
                            prevContext.startActivity(android.content.Intent(prevContext, LauncherModeActivity::class.java))
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    val movers: Set<Int> = if (multi && picked.isNotEmpty()) picked.toSet() else if (selected in cur.indices) setOf(selected) else emptySet()
    if (movingTo && movers.isNotEmpty()) {
        MoveToDialog(
            count = movers.size,
            canGoUp = path.isNotEmpty(),
            folders = cur.mapIndexedNotNull { t, item -> if (item.isFolder && t !in movers) t to item.label.ifBlank { "Folder" } else null },
            onUp = { moveUp(movers); selected = -1; picked.clear(); multi = false; movingTo = false },
            onInto = { t -> commitItems(moveIntoFolder(cur, movers, t)); selected = -1; picked.clear(); multi = false; movingTo = false },
            onDismiss = { movingTo = false },
        )
    }
    if (ccDlg) ClickCircleDialog(pref.sharedPreferences) { ccDlg = false }
    if (prevDlg) PreviousAppDialog(pref.sharedPreferences) { prevDlg = false }
    if (lookDlg) {
        LookDialog(
            sp = sp,
            rootItems = cfg.items, rootCols = cfg.columns, sizePct = cfg.sizePct, showLabels = cfg.showLabels,
            startOnFolders = path.isNotEmpty(),
            onChange = { lookTick++ },
            onDismiss = { lookDlg = false },
        )
    }
    if (tipDlg) GapPopupDialog(sp) { tipDlg = false }
    edgeEditKey?.let { key ->
        val ctx = LocalContext.current
        // The field's current shortcut, name and icon come up in the editor, ready to change one at a time.
        val start = remember(key) {
            val raw = sp.getString(key, "").orEmpty()
            val bare = StripConfig.bare(raw)
            val (ml, mi) = EdgeFields.meta(sp, key)
            val entry = HandlerActionCatalog.entryFor(bare)
            val icon = mi.ifEmpty {
                when {
                    bare.isEmpty() -> ""
                    entry != null -> BuiltInIcons.save(ctx, entry.icon, bare) ?: EMOJI_FOR_ACTION[bare].orEmpty()
                    NativePicker.isNative(bare) -> BuiltInIcons.save(ctx, ActionIcon.Vector(DeviceActionIcons.forTitle(NativePicker.label(bare))), bare).orEmpty()
                    else -> ""
                }
            }
            StripItem(ml.ifEmpty { if (bare.isEmpty()) "" else edgeActionName(ctx, bare) }, icon, bare, touch = StripConfig.isTouch(raw))
        }
        ItemEditor(
            item = start,
            onSave = { updated ->
                EdgeFields.save(sp, key, StripConfig.withTouch(updated.action, updated.touch), updated.label, updated.icon)
                edgeTick++; edgeEditKey = null
            },
            onCancel = { edgeEditKey = null },
        )
    }
    val e = editing
    if (e in cur.indices) {
        ItemEditor(
            item = cur[e],
            onSave = { updated ->
                val l = cur.toMutableList(); l[e] = updated; commitItems(l); editing = -1; newCellAt = -1
            },
            onCancel = {
                // A cell just added by the "+" after the last cell is taken away again when its window is cancelled.
                if (newCellAt == e) { commitItems(StripConfig.deleteCells(cur, setOf(e))); selected = -1 }
                newCellAt = -1; editing = -1
            },
        )
    }
}

internal data class DragInfo(val ids: List<Int>, val target: Int, val up: Boolean)

/** Puts the cells [ids] at the end of the folder cell [target]. */
internal fun moveIntoFolder(list: List<StripItem>, ids: Set<Int>, target: Int): List<StripItem> {
    val moved = list.filterIndexed { n, _ -> n in ids }
    val l = list.toMutableList()
    l[target] = l[target].copy(children = l[target].children.orEmpty() + moved)
    return l.filterIndexed { n, _ -> n !in ids }
}

/** Moves the cells [ids] to the place of cell [t]; the cell there makes room. */
internal fun moveToSlot(list: List<StripItem>, ids: Set<Int>, t: Int): List<StripItem> {
    val first = ids.minOrNull() ?: return list
    val moved = list.filterIndexed { n, _ -> n in ids }
    val rest = list.filterIndexed { n, _ -> n !in ids }
    val at = if (t > first) (0..t).count { it !in ids } else (0 until t).count { it !in ids }
    return rest.take(at) + moved + rest.drop(at)
}

/** "Folder1", "Folder2"… the first not used by a cell of the same folder, so a new one is easy to tell apart. */
internal fun uniqueFolderName(list: List<StripItem>): String {
    val used = list.map { it.label }.toSet()
    var n = 1
    while ("Folder$n" in used) n++
    return "Folder$n"
}

/** The cells of the folder reached by [path] (empty path = the main strip). */
internal fun itemsAt(root: List<StripItem>, path: List<Int>): List<StripItem> {
    var l = root
    for (i in path) l = l.getOrNull(i)?.children ?: return emptyList()
    return l
}

internal fun setItemsAt(root: List<StripItem>, path: List<Int>, new: List<StripItem>): List<StripItem> =
    if (path.isEmpty()) new
    else root.mapIndexed { i, it -> if (i == path[0]) it.copy(children = setItemsAt(it.children.orEmpty(), path.drop(1), new)) else it }

@Composable
internal fun backupLauncher(
    prefs: android.content.SharedPreferences, settings: Boolean, scripts: Boolean, done: String,
    report: (String) -> Unit,
): androidx.activity.result.ActivityResultLauncher<String> {
    val context = LocalContext.current
    return androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            report(runCatching {
                val text = SettingsBackup.toJson(prefs, settings, scripts)
                context.contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
                done
            }.getOrElse { "Backup failed: ${it.message}" })
        }
    }
}

@Composable
internal fun restoreLauncher(
    prefs: android.content.SharedPreferences, settings: Boolean, scripts: Boolean, what: String,
    reload: () -> Unit, report: (String) -> Unit,
): androidx.activity.result.ActivityResultLauncher<Array<String>> {
    val context = LocalContext.current
    return androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            report(runCatching {
                val text = context.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
                SettingsBackup.saveUndo(context, prefs)
                val n = SettingsBackup.apply(prefs, text, settings, scripts)
                when {
                    n < 0 -> "Not a backup file"
                    n == 0 -> "That file has no $what"
                    else -> { reload(); "Restored $what. Close and reopen the app to apply them everywhere." }
                }
            }.getOrElse { "Restore failed: ${it.message}" })
        }
    }
}

private fun toastName(v: Int) = when (v) { 0 -> "off"; 1 -> "short"; else -> "long" }

@Composable
private fun AddCell(onClick: () -> Unit) {
    Box(
        Modifier.padding(2.dp).aspectRatio(1f).clip(RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text("+", fontSize = 18.sp) }
}

@Composable
private fun ItemCell(item: StripItem, selected: Boolean, onClick: () -> Unit) {
    val colours = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(8.dp)
    androidx.compose.foundation.layout.BoxWithConstraints(
        Modifier.padding(2.dp).aspectRatio(1f).clip(shape)
            .background(if (item.action.isNotEmpty()) colours.primaryContainer else colours.surfaceVariant)
            .then(if (selected) Modifier.border(BorderStroke(2.dp, colours.primary), shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        // Drawn as the strip draws a cell: the icon takes the upper part, the name sits under it,
        // both sized from the cell so nothing is cut off.
        val side = maxWidth.value
        val hasIcon = item.appIconPackage != null || (item.icon.isNotEmpty() && item.icon != FitText.NONE)
        val showName = hasIcon && item.label.isNotEmpty()
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxSize().padding((side * 0.06f).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                IconOrLabel(item, Modifier.fillMaxSize().padding((side * 0.04f).dp), (side * 0.38f).toInt().coerceAtLeast(10))
            }
            if (showName) {
                Text(item.label, fontSize = (side * 0.17f).coerceIn(6f, 11f).sp, maxLines = 1, overflow = TextOverflow.Clip, textAlign = TextAlign.Center)
            }
        }
    }
}

/** An item as the strip shows it: its icon (emoji or the app's own), else its name. */
@Composable
private fun IconOrLabel(item: StripItem, modifier: Modifier, emojiSp: Int) {
    val context = LocalContext.current
    val pkg = item.appIconPackage
    val bitmap = remember(pkg) {
        pkg?.let { p ->
            runCatching { context.packageManager.getApplicationIcon(p).toBitmap(64, 64).asImageBitmap() }.getOrNull()
        }
    }
    val img = remember(item.icon) {
        item.iconFile?.let { f ->
            val iconFile = java.io.File(context.filesDir, "sicons/$f")
            if (iconFile.isFile) runCatching { android.graphics.BitmapFactory.decodeFile(iconFile.path)?.asImageBitmap() }.getOrNull() else null
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        when {
            img != null -> Image(bitmap = img, contentDescription = item.label, modifier = Modifier.fillMaxSize())
            bitmap != null -> Image(bitmap = bitmap, contentDescription = item.label, modifier = Modifier.fillMaxSize())
            item.icon == FitText.NONE -> {
                val ink = MaterialTheme.colorScheme.onSurface.toArgb()
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    drawIntoCanvas { c ->
                        FitText.draw(
                            c.nativeCanvas, android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG),
                            item.label, android.graphics.RectF(0f, 0f, size.width, size.height), ink,
                        )
                    }
                }
            }
            item.icon.isNotEmpty() && pkg == null && item.iconFile == null -> Text(item.icon, fontSize = emojiSp.sp)
            else -> Text(item.label, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        }
    }
}

/** An installed app's own icon. */
@Composable
internal fun PackageIcon(pkg: String, modifier: Modifier) {
    val context = LocalContext.current
    val bitmap = remember(pkg) {
        runCatching { context.packageManager.getApplicationIcon(pkg).toBitmap(64, 64).asImageBitmap() }.getOrNull()
    }
    if (bitmap != null) Image(bitmap = bitmap, contentDescription = null, modifier = modifier) else Spacer(modifier)
}

private enum class Page { MAIN, EMOJI, ICON_APP, ACTION_APP, ACTION, FLOW, SHORTCUTS, SCRIPTS, HAIL }

@Composable
internal fun ItemEditor(item: StripItem, onSave: (StripItem) -> Unit, onCancel: () -> Unit) {
    var label by remember { mutableStateOf(item.label) }
    var icon by remember { mutableStateOf(item.icon) }
    var action by remember { mutableStateOf(item.action) }
    var stay by remember { mutableStateOf(item.stay?.toString() ?: "") }
    var notify by remember { mutableStateOf(item.notify?.toString() ?: "") }
    var toast by remember { mutableStateOf(item.toast) }
    var touch by remember { mutableStateOf(item.touch) }
    var page by remember { mutableStateOf(Page.MAIN) }
    var shellDialog by remember { mutableStateOf(false) }
    var shellText by remember { mutableStateOf(item.action.removePrefix("Shell:").takeIf { item.action.startsWith("Shell:") } ?: "") }
    val context = LocalContext.current
    // Icon history: whatever changes the icon (a picked shortcut, a built-in, an emoji) can be undone and redone.
    val iconUndo = remember { ArrayList<String>() }
    val iconRedo = remember { ArrayList<String>() }
    var iconPrev by remember { mutableStateOf(icon) }
    var iconSkip by remember { mutableStateOf(false) }
    var iconRev by remember { mutableIntStateOf(0) }
    LaunchedEffect(icon) {
        if (iconSkip) iconSkip = false
        else if (icon != iconPrev) { iconUndo.add(iconPrev); iconRedo.clear() }
        iconPrev = icon
        iconRev++
    }
    // The colour behind the icon preview, chosen by the user (white built-in icons need a dark one, a dark icon a light one).
    val tilePrefs = remember { context.getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE) }
    var tileColor by remember { mutableIntStateOf(tilePrefs.getInt("iconTileColor", 0xFF37474F.toInt())) }
    var tileHex by remember { mutableStateOf("") }
    // Per-cell / per-folder tile colour saved on this item (0 = follow the global or folder cells look).
    var customTileColor by remember { mutableIntStateOf(item.tileColor) }
    var customTileHex by remember {
        mutableStateOf(if (item.tileColor != 0) String.format("%06X", item.tileColor and 0xFFFFFF) else "")
    }
    var showInfo by remember { mutableStateOf(false) }
    var rawDialog by remember { mutableStateOf(false) }
    var rawText by remember { mutableStateOf("") }
    var creatorPkg by remember { mutableStateOf("") }
    val fileLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            action = "File:$uri"
            label = FilePaths.displayName(context, uri) ?: label
            if (icon.isEmpty()) icon = "📄"
            page = Page.MAIN
        }
    }
    val creatorLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        @Suppress("DEPRECATION")
        val picked = data?.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_SHORTCUT_INTENT)
        if (result.resultCode == android.app.Activity.RESULT_OK && picked != null) {
            action = INTENT_ACTION_PREFIX + AppStarter.save(picked)
            // A folder or file shortcut points at an address the maker only lent A for now: keep the right to read it, when it allows that.
            picked.data?.takeIf { it.scheme == "content" }?.let { d ->
                runCatching { context.contentResolver.takePersistableUriPermission(d, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            }
            val name = data?.getStringExtra(android.content.Intent.EXTRA_SHORTCUT_NAME)
            if (label.isBlank() && !name.isNullOrBlank()) label = name
            // The icon chosen in the shortcut maker (Automate's own picker) wins over an older one.
            val own = saveShortcutIcon(context, data)
            DiagLog.note("shortcut maker icon: ${own ?: "none"}; extras=${data?.extras?.keySet()?.joinToString()}")
            if (own != null) icon = own
            if (icon.isEmpty()) {
                val pkg = picked.component?.packageName ?: picked.`package` ?: creatorPkg
                if (pkg.isNotEmpty()) icon = "app:$pkg"
            }
            page = Page.MAIN
        }
    }

    // Back inside a sub-page (apps, shortcuts, built-in, scripts...) returns to the editor first.
    Dialog(onDismissRequest = { if (page != Page.MAIN) page = Page.MAIN else onCancel() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding()) {
            when (page) {
                Page.MAIN -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    val textMode = icon == FitText.NONE
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = if (textMode) it.split('\n').take(3).joinToString("\n") else it },
                        singleLine = !textMode, maxLines = if (textMode) 3 else 1,
                        label = { Text(if (textMode) "Text in the cell (up to 3 lines, Enter = new line)" else "Name") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(16.dp))
                    Text("Icon", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Built-in icons are white: shown on a tile whose colour is chosen below, so they can be seen the moment they are chosen.
                        Box(
                            Modifier.size(56.dp).clip(RoundedCornerShape(10.dp))
                                .background(androidx.compose.ui.graphics.Color(customTileColor.takeIf { it != 0 } ?: tileColor))
                                .pointerInput(icon, label) {
                                    detectTapGestures(
                                        onTap = { IconExport.copy(context, StripItem(label, icon, action)) },
                                        onLongPress = { IconExport.saveToDownloads(context, StripItem(label, icon, action)) },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            IconOrLabel(StripItem(label, icon, action), Modifier.fillMaxSize().padding(6.dp), 32)
                        }
                        // Undo and redo of the icon, to the right of the preview.
                        val canUndo = iconRev >= 0 && iconUndo.isNotEmpty()
                        val canRedo = iconRev >= 0 && iconRedo.isNotEmpty()
                        TextButton(enabled = canUndo, onClick = {
                            if (iconUndo.isNotEmpty()) { iconSkip = true; iconRedo.add(icon); icon = iconUndo.removeAt(iconUndo.lastIndex) }
                        }) { Text("↶") }
                        TextButton(enabled = canRedo, onClick = {
                            if (iconRedo.isNotEmpty()) { iconSkip = true; iconUndo.add(icon); icon = iconRedo.removeAt(iconRedo.lastIndex) }
                        }) { Text("↷") }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(onClick = { page = Page.EMOJI }) { Text("Emoji") }
                            OutlinedButton(onClick = { page = Page.ICON_APP }) { Text("App icon") }
                            OutlinedButton(onClick = { icon = FitText.NONE }) { Text("None") }
                        }
                    }
                    // Preview colour: any colour the user likes.
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Preview colour", fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        listOf(0xFF37474F, 0xFF000000, 0xFF212121, 0xFF757575, 0xFFFFFFFF, 0xFFFFF59D, 0xFF81D4FA, 0xFF2196F3, 0xFF1F8A8A, 0xFF4CAF50, 0xFFFF9800, 0xFFE53935, 0xFF8E24AA).forEach { c ->
                            val argb = c.toInt()
                            Box(
                                Modifier.padding(horizontal = 3.dp).size(28.dp).clip(RoundedCornerShape(14.dp))
                                    .background(androidx.compose.ui.graphics.Color(argb))
                                    .border(if (tileColor == argb) 3.dp else 1.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (tileColor == argb) 1f else 0.35f), RoundedCornerShape(14.dp))
                                    .clickable { tileColor = argb; tilePrefs.edit().putInt("iconTileColor", argb).apply() },
                            )
                        }
                        OutlinedTextField(
                            value = tileHex,
                            onValueChange = { v ->
                                tileHex = v.filter { it.isLetterOrDigit() }.take(6)
                                if (tileHex.length == 6) tileHex.toLongOrNull(16)?.let {
                                    tileColor = (0xFF000000 or it).toInt(); tilePrefs.edit().putInt("iconTileColor", tileColor).apply()
                                }
                            },
                            singleLine = true, label = { Text("#RRGGBB") }, modifier = Modifier.width(110.dp).padding(start = 6.dp),
                        )
                    }
                    // Per-cell / per-folder tile colour override: 0 = follow the Look of the cells / folders setting.
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (item.isFolder) "Folder tile" else "Tile colour", fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = { customTileColor = 0; customTileHex = "" },
                            modifier = Modifier.padding(end = 4.dp),
                        ) { Text(if (customTileColor == 0) "✓ Default" else "Default", fontSize = 12.sp) }
                        listOf(0xFFE65100, 0xFFFF9800, 0xFFF5B400, 0xFF4CAF50, 0xFF00897B, 0xFF2196F3, 0xFF3949AB, 0xFF8E24AA, 0xFFE53935, 0xFF37474F, 0xFF212121, 0xFFFFFFFF).forEach { c ->
                            val argb = c.toInt()
                            Box(
                                Modifier.padding(horizontal = 3.dp).size(28.dp).clip(RoundedCornerShape(14.dp))
                                    .background(androidx.compose.ui.graphics.Color(argb))
                                    .border(if (customTileColor == argb) 3.dp else 1.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (customTileColor == argb) 1f else 0.35f), RoundedCornerShape(14.dp))
                                    .clickable { customTileColor = argb; customTileHex = String.format("%06X", argb and 0xFFFFFF) },
                            )
                        }
                        OutlinedTextField(
                            value = customTileHex,
                            onValueChange = { v ->
                                customTileHex = v.filter { it.isLetterOrDigit() }.take(6)
                                if (customTileHex.length == 6) customTileHex.toLongOrNull(16)?.let {
                                    customTileColor = (0xFF000000 or it).toInt()
                                }
                            },
                            singleLine = true, label = { Text("#RRGGBB") }, modifier = Modifier.width(110.dp).padding(start = 6.dp),
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Action", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Text(
                        when {
                            action.isEmpty() -> "Nothing"
                            action.startsWith(StripConfig.FLOW_PREFIX) -> "Automate flow " + action.removePrefix(StripConfig.FLOW_PREFIX)
                            action.startsWith(INTENT_ACTION_PREFIX) -> "App shortcut"
                            action.startsWith("File:") -> "Open file: " + FilePaths.nameOf(action)
                            else -> actionDisplayName(action)
                        },
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                    if (action.isNotEmpty()) {
                        ShortcutToolRow(label, icon, action)
                        TextButton(onClick = { showInfo = !showInfo }) { Text(if (showInfo) "Hide details" else "Details of this shortcut") }
                        if (showInfo) {
                            val details = remember(action) { describeAction(context, action) }
                            androidx.compose.foundation.text.selection.SelectionContainer {
                                Text(details, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 12.sp)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", action))
                                    android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
                                }) { Text("Copy raw") }
                                OutlinedButton(onClick = { rawText = action; rawDialog = true }) { Text("Edit raw") }
                                if (action.startsWith("MyFlow:")) {
                                    OutlinedButton(onClick = {
                                        context.startActivity(
                                            android.content.Intent(context, FlowActivity::class.java)
                                                .putExtra("flow", FlowStore.resolve(context, action.removePrefix("MyFlow:")) ?: action.removePrefix("MyFlow:"))
                                        )
                                    }) { Text("Edit this script") }
                                }
                                if (action.startsWith(INTENT_ACTION_PREFIX) || action.startsWith("Shell:")) {
                                    OutlinedButton(onClick = {
                                        val ok = ActionSaver.saveToScripts(context, label, action)
                                        android.widget.Toast.makeText(context, if (ok) "Saved to My Scripts" else "Cannot save this kind", android.widget.Toast.LENGTH_SHORT).show()
                                    }) { Text("Save to My Scripts") }
                                }
                            }
                        }
                    }
                    if (rawDialog) {
                        RawActionDialog(
                            initial = rawText,
                            onUse = { t -> action = t.trim(); rawDialog = false },
                            onDismiss = { rawDialog = false },
                        )
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(onClick = { page = Page.HAIL }) { Text("Open with Hail (any app, even hidden)") }
                        OutlinedButton(onClick = { page = Page.SHORTCUTS }) { Text("App shortcuts") }
                        OutlinedButton(onClick = {
                            // Automate's own "pick a flow" screen, straight from here.
                            val cr = runCatching { loadCreators(context) }.getOrDefault(emptyList())
                                .firstOrNull { it.packageName == "com.llamalab.automate" }
                            if (cr == null) page = Page.SHORTCUTS else {
                                creatorPkg = cr.packageName
                                runCatching {
                                    creatorLauncher.launch(
                                        android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT)
                                            .setClassName(cr.packageName, cr.className)
                                    )
                                }
                            }
                        }) { Text("Automate flow") }
                        OutlinedButton(onClick = { shellDialog = true }) { Text("Shell command") }
                        OutlinedButton(onClick = { page = Page.ACTION }) { Text("Built-in shortcuts (with device actions)") }
                        OutlinedButton(onClick = { page = Page.SCRIPTS }) { Text("My Scripts") }
                        OutlinedButton(onClick = { fileLauncher.launch(arrayOf("*/*")) }) { Text("Open a file") }
                        OutlinedButton(onClick = { action = "" }) { Text("Nothing") }
                    }
                    if (shellDialog) {
                        ShellCommandDialog(
                            initial = shellText,
                            onUse = { t ->
                                shellText = t
                                if (t.isNotBlank()) {
                                    action = "Shell:" + t.trim()
                                    if (label.isBlank()) label = "Shell"
                                }
                                shellDialog = false
                            },
                            onDismiss = { shellDialog = false },
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    ToggleRow("Run as soon as the thumb is on it (no release needed)", touch) { touch = it }
                    Text("After it runs (empty = follow the cells' setting)", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = stay, onValueChange = { stay = it.filter(Char::isDigit).take(2) }, singleLine = true,
                            label = { Text("Stay (s)") }, modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = notify, onValueChange = { notify = it.filter(Char::isDigit).take(3) }, singleLine = true,
                            label = { Text("Notification (s)") }, modifier = Modifier.weight(1f),
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Toast", Modifier.weight(1f))
                        OutlinedButton(onClick = { toast = when (toast) { null -> 0; 0 -> 1; 1 -> 2; else -> null } }) {
                            Text(toast?.let { toastName(it) } ?: "follow")
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onSave(item.copy(label = label.trim(), icon = icon, action = action, stay = stay.toIntOrNull(), toast = toast, notify = notify.toIntOrNull(), touch = touch, tileColor = customTileColor)) }) { Text("Save") }
                        TextButton(onClick = onCancel) { Text("Cancel") }
                    }
                }

                Page.EMOJI -> Column(Modifier.fillMaxSize().padding(12.dp)) {
                    var typed by remember { mutableStateOf("") }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = typed, onValueChange = { typed = it }, singleLine = true,
                            label = { Text("Type or paste any emoji") }, modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { if (typed.isNotBlank()) { icon = typed.trim(); page = Page.MAIN } }) { Text("Use") }
                    }
                    Spacer(Modifier.height(8.dp))
                    var query by remember { mutableStateOf("") }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        label = { Text("Search by name (power, wifi, lock, battery…)") }, modifier = Modifier.fillMaxWidth(),
                    )
                    val everything = remember { drawableEmoji() }
                    val shown = remember(query) {
                        val words = query.lowercase().split(' ').filter { it.isNotBlank() }
                        everything.filter { e -> words.all { e.words.contains(it) } }.map { it.emoji }
                    }
                    androidx.compose.ui.viewinterop.AndroidView(
                        factory = { c ->
                            android.widget.GridView(c).apply {
                                numColumns = android.widget.GridView.AUTO_FIT
                                columnWidth = (52 * c.resources.displayMetrics.density).toInt()
                                stretchMode = android.widget.GridView.STRETCH_COLUMN_WIDTH
                            }
                        },
                        update = { gv ->
                            gv.adapter = EmojiAdapter(shown)
                            gv.setOnItemClickListener { _, _, pos, _ -> icon = shown[pos]; page = Page.MAIN }
                        },
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                    )
                    TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                }

                Page.ICON_APP -> AppList(onPick = { app -> icon = appIconRef(context, app); page = Page.MAIN }, onBack = { page = Page.MAIN }, everything = true, kindFilter = true)

                Page.ACTION_APP -> AppList(
                    onPick = { app ->
                        action = HandlerActions.launchApp(app.packageName)
                        if (label.isBlank()) label = plainAppLabel(app.label)
                        if (icon.isEmpty()) icon = appIconRef(context, app)
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.HAIL -> AppList(
                    onPick = { app ->
                        action = ActionSaver.hailAction(app.packageName)
                        label = plainAppLabel(app.label)
                        icon = appIconRef(context, app)
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                    everything = true,
                    kindFilter = true,
                    kindKey = AppKinds.HAIL_PREF_KEY,
                )

                Page.ACTION -> Column(Modifier.fillMaxSize()) {
                    TextButton(
                        onClick = { fileLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.padding(horizontal = 12.dp),
                    ) { Text("Open a file… (a web page opens in A's HTML viewer)") }
                    BuiltInPage(
                        modifier = Modifier.weight(1f),
                        onPick = { entry, name ->
                            action = entry.action
                            // The chosen built-in shortcut brings its own name and icon at once.
                            label = name
                            icon = BuiltInIcons.save(context, entry.icon, entry.action) ?: EMOJI_FOR_ACTION[entry.action].orEmpty()
                            page = Page.MAIN
                        },
                        onBack = { page = Page.MAIN },
                        // Device actions (Wi-Fi, flashlight, lock…) are in the same list and bring their own name and icon.
                        onPickAction = { a, n, ic ->
                            action = a
                            label = n
                            icon = BuiltInIcons.save(context, ic, a).orEmpty()
                            page = Page.MAIN
                        },
                        // "Open an app" lives in this list too.
                        onPickApp = { app, _, act ->
                            action = act
                            if (label.isBlank()) label = plainAppLabel(app.label)
                            if (icon.isEmpty()) icon = appIconRef(context, app)
                            page = Page.MAIN
                        },
                    )
                }

                Page.SCRIPTS -> MyScriptsPage(
                    onPick = { name, act, cell ->
                        action = act
                        label = name.removePrefix("Script: ")
                        if (cell != null && cell.icon.isNotEmpty()) icon = cell.icon
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.SHORTCUTS -> AppShortcutsPage(
                    onCreator = { cr ->
                        creatorPkg = cr.packageName
                        runCatching {
                            creatorLauncher.launch(
                                android.content.Intent(android.content.Intent.ACTION_CREATE_SHORTCUT)
                                    .setClassName(cr.packageName, cr.className)
                            )
                        }
                    },
                    onShortcut = { sc ->
                        action = INTENT_ACTION_PREFIX + sc.intentUri
                        label = sc.label
                        icon = "app:${sc.packageName}"
                        page = Page.MAIN
                    },
                    onBack = { page = Page.MAIN },
                )

                Page.FLOW -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                    var text by remember { mutableStateOf(action.removePrefix(StripConfig.FLOW_PREFIX).takeIf { action.startsWith(StripConfig.FLOW_PREFIX) }.orEmpty()) }
                    Text("Paste the shortcut's Automate address (content://com.llamalab.automate.provider/flows/…/statements/…) or type flow/statement, for example 468/233.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            StripConfig.parseFlow(text)?.let { action = it; page = Page.MAIN }
                        }) { Text("Use") }
                        TextButton(onClick = { page = Page.MAIN }) { Text("Back") }
                    }
                }
            }
        }
    }
}

/** A script's steps as indented text, with the scripts it runs shown under their step. */
private fun flowText(context: android.content.Context, name: String, depth: Int, seen: MutableSet<String>): String {
    val pad = "      ".repeat(depth)
    if (!seen.add(name)) return pad + "(\"$name\" is shown above)\n"
    if (depth > 4) return pad + "(deeper scripts not shown)\n"
    val steps = FlowStore.load(context, name)
    if (steps.isEmpty()) return pad + "(no steps found for \"$name\")\n"
    val sb = StringBuilder()
    var ind = 0
    for (s in steps) {
        if (s.type == Step.END || s.type == Step.ELSE) ind = (ind - 1).coerceAtLeast(0)
        sb.append(pad).append("  ".repeat(ind)).append(s.describe()).append('\n')
        if (s.id == 0 && (s.type == Step.IF || s.type == Step.REPEAT || s.type == Step.ELSE)) ind++
        if (s.type == Step.RUN && s.a.isNotBlank()) sb.append(flowText(context, s.a, depth + 1, seen))
    }
    return sb.toString()
}

/** Everything the cell's action holds, in words, so a shortcut can be read, copied or rebuilt. */
private fun describeAction(context: android.content.Context, action: String): String {
    val sb = StringBuilder()
    when {
        action.startsWith(INTENT_ACTION_PREFIX) -> {
            sb.append("Type: app shortcut (an intent)\n")
            val uri = action.removePrefix(INTENT_ACTION_PREFIX)
            val i = runCatching { AppStarter.parse(uri) }.getOrNull()
            if (i != null) {
                i.action?.let { sb.append("Action: $it\n") }
                i.dataString?.let { sb.append("Data: $it\n") }
                i.type?.let { sb.append("MIME type: $it\n") }
                i.`package`?.let { sb.append("Package: $it\n") }
                i.component?.let { sb.append("Component: ${it.flattenToString()}\n") }
                i.categories?.let { sb.append("Categories: ${it.joinToString()}\n") }
                @Suppress("DEPRECATION")
                i.extras?.let { ex -> for (k in ex.keySet()) sb.append("Extra $k = ${ex.get(k)}\n") }
                sb.append("Flags: 0x${Integer.toHexString(i.flags)}\n")
            }
            sb.append("\nRaw: $uri")
        }
        action.startsWith(StripConfig.FLOW_PREFIX) -> sb.append("Type: Automate flow\nAddress: ${action.removePrefix(StripConfig.FLOW_PREFIX)}")
        action.startsWith("Shell:") -> sb.append("Type: shell command\nCommand: ${action.removePrefix("Shell:")}")
        action.startsWith("MyFlow:") -> {
            val name = FlowStore.resolve(context, action.removePrefix("MyFlow:")) ?: action.removePrefix("MyFlow:")
            sb.append("Type: My Script\nName: $name\n\nSteps (scripts it runs are shown indented under their step):\n")
            sb.append(flowText(context, name, 0, HashSet()))
        }
        action.startsWith("N:") -> sb.append("Type: device action\nName: ${NativePicker.label(action)}\nId: $action")
        action.startsWith("File:") -> sb.append("Type: open a file\nName: ${FilePaths.nameOf(action)}\nUri: ${action.removePrefix("File:")}")
        else -> sb.append("Type: built-in, device action or app\nAction: $action")
    }
    return sb.toString()
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun AppList(onPick: (InstalledApp) -> Unit, onBack: () -> Unit, everything: Boolean = false, kindFilter: Boolean = false, kindKey: String = AppKinds.PREF_KEY) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<InstalledApp>?>(null) }
    var query by remember { mutableStateOf("") }
    // Which kinds of app are listed (App icon screen only). Saved on every change, so it is the same next time.
    var kinds by remember { mutableIntStateOf(if (kindFilter) AppKinds.load(context, kindKey) else AppKinds.ALL) }
    LaunchedEffect(kinds) {
        apps = null
        apps = withContext(Dispatchers.IO) {
            if (kindFilter) loadEveryApp(context, kinds)
            else if (everything) loadEveryApp(context) else loadLaunchableApps(context, includeSelf = true)
        }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        if (kindFilter) {
            val options = listOf(
                AppKinds.USER to "User",
                AppKinds.USER_HIDDEN to "User hidden/disabled",
                AppKinds.SYSTEM to "System",
                AppKinds.SYSTEM_HIDDEN to "System hidden/disabled",
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                options.forEach { (bit, name) ->
                    ChoiceChip(label = name, selected = kinds and bit != 0, onClick = {
                        // From the plain default (user apps only) a first tap on another kind switches to that kind alone;
                        // after that the buttons add and remove kinds, and all four show every app.
                        kinds = if (kinds == AppKinds.DEFAULT && bit != AppKinds.USER) bit else kinds xor bit
                        AppKinds.save(context, kinds, kindKey)
                    })
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            label = { Text("Search apps") }, modifier = Modifier.fillMaxWidth(),
        )
        val loaded = apps
        if (kindFilter && kinds and AppKinds.ALL == 0) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Nothing is selected. Choose User, User hidden/disabled, System or System hidden/disabled above to see apps.", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        } else if (loaded == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val words = query.trim().lowercase().split(' ').filter { it.isNotEmpty() }
            val shown = if (words.isEmpty()) loaded else loaded.filter { a ->
                val hay = (a.label + " " + a.packageName).lowercase()
                words.all { hay.contains(it) }
            }
            if (shown.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(if (kindFilter) "No apps of the selected kinds match." else "No apps match.", textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            } else LazyColumn(Modifier.weight(1f)) {
                items(shown, key = { it.packageName }) { app ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(app) }.padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        app.icon?.let { Image(bitmap = it, contentDescription = null, modifier = Modifier.size(40.dp)) }
                            ?: Spacer(Modifier.size(40.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}

/** A first emoji for the actions that have an obvious one; the rest keep their name until chosen. */
private val EMOJI_FOR_ACTION: Map<String, String> = mapOf(
    HandlerActions.SCAN_QR to "🔳",
    HandlerActions.TOGGLE_FLASHLIGHT to "🔦",
    HandlerActions.OPEN_CAMERA to "📷",
    HandlerActions.OPEN_CALCULATOR to "🧮",
    HandlerActions.OPEN_NOTES to "📝",
    HandlerActions.OPEN_TIMER to "⏱️",
    HandlerActions.OPEN_SEARCH to "🔍",
    HandlerActions.COIN_TOSS to "🪙",
    HandlerActions.DICE_ROLL to "🎲",
    HandlerActions.MUTE to "🔇",
    HandlerActions.MUTE_OR_UNMUTE to "🔇",
    HandlerActions.VOLUME_BOOST to "📢",
    HandlerActions.VOLUME_BOOST_ALLOW to "📣",
    HandlerActions.VOLUME_BOOST_OFF to "🔇",
    HandlerActions.MEDIA_PLAY_PAUSE to "⏯️",
    HandlerActions.MEDIA_NEXT to "⏭️",
    HandlerActions.MEDIA_PREVIOUS to "⏮️",
    HandlerActions.SCREENSHOT to "📸",
    HandlerActions.LOCK to "🔒",
    HandlerActions.HOME to "🏠",
    HandlerActions.BACK to "⬅️",
    HandlerActions.WIFI_PANEL to "📶",
    HandlerActions.BLUETOOTH_SETTINGS to "🔵",
    HandlerActions.VOICE_ASSISTANT to "🎤",
    HandlerActions.OPEN_DECK to "🗂️",
    HandlerActions.OPEN_MENU to "☰",
)


/** One icon of the row of tools under the cells window: round-cornered, lit in the accent when it is on. */
@Composable
private fun ToolIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector, description: String,
    lit: Boolean = false, enabled: Boolean = true, onClick: () -> Unit,
) {
    val primary = MaterialTheme.colorScheme.primary
    IconButton(
        onClick = onClick, enabled = enabled, tooltip = description,
        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
            .background(if (lit) primary.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color.Transparent),
    ) {
        Icon(
            icon, contentDescription = description,
            tint = when {
                !enabled -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                lit -> primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
    }
}

private val EDGE_BAR = 56.dp
private val EDGE_MIN = 22.dp

/** What a field is called when its owner has not named it: the action's own name (shared with the running strip). */
private fun edgeActionName(context: android.content.Context, b: String): String = EdgeFields.actionName(context, b)

/**
 * "Gap" under the live view, above the add buttons: a switch that turns the cancel gap on or off, and a button
 * beside it that shows or hides all the gap's options (it can be hidden while the gap stays on in the
 * background). The gap is a band between the cells window and the outside fields; a thumb let go in it
 * runs nothing. Options: a size per side (the live view shows the true size), tap a field in the picture to
 * switch the gap next to it on or off, and how the band looks on screen.
 */
@Composable
private fun GapPanel(
    sp: android.content.SharedPreferences, on: Boolean, onOn: (Boolean) -> Unit,
    open: Boolean, onOpen: (Boolean) -> Unit, onChanged: () -> Unit,
) {
    var glowHide by remember { mutableStateOf(sp.getBoolean("stripEdgeGlowHideFolder", false)) }
    var style by remember { mutableIntStateOf(EdgeFields.gapStyle(sp)) }
    var color by remember { mutableIntStateOf(EdgeFields.gapColor(sp)) }
    var hex by remember { mutableStateOf(String.format("%06X", EdgeFields.gapColor(sp) and 0xFFFFFF)) }
    val sizes = remember { androidx.compose.runtime.mutableStateMapOf<String, Int>().also { m -> for (sd in EdgeFields.SIDES) m[sd] = EdgeFields.gapDp(sp, sd) } }
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp)) {
        val rows = 2
        androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            SettingRow(
                "Gap", a.a.ui.components.cardShape(0, rows), icon = androidx.compose.material.icons.Icons.Filled.Tune, lit = on,
                summary = "A band around the cells window where letting go cancels",
                info = "A band around the cells window: a thumb let go in it runs nothing, so you can cancel the slide-in. The picture above shows its true size. Tap a field in the picture to switch the gap next to it on or off. A field's name is shown where its gap ends.",
                onClick = { onOn(!on); sp.edit().putBoolean("stripCxlOn", !on).apply(); onChanged() },
                trailing = { Switch(checked = on, onCheckedChange = null) },
            )
            SettingRow(
                if (open) "Hide gap options" else "Show gap options", a.a.ui.components.cardShape(1, rows),
                summary = "Size of each side, how the band looks and its colour",
                onClick = { onOpen(!open) },
                trailing = { Text(if (open) "▴" else "▾", fontSize = 18.sp, color = MaterialTheme.colorScheme.primary) },
            )
        }
        if (open) {
            Spacer(Modifier.height(3.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(a.a.ui.components.rowColor()).padding(14.dp)) {
            OptSwitch("Hide Gap when folder opens", glowHide, info = "The band is not drawn while a folder is open.") {
                glowHide = it; sp.edit().putBoolean("stripEdgeGlowHideFolder", it).apply()
            }
            for (pair in listOf(listOf("Top", "Bottom"), listOf("Left", "Right"))) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (sd in pair) Column(Modifier.weight(1f)) {
                        Text("$sd gap: ${sizes[sd] ?: 0} dp", fontSize = 12.sp)
                        androidx.compose.material3.Slider(
                            value = (sizes[sd] ?: 0).toFloat(), valueRange = 0f..EdgeFields.GAP_MAX_DP.toFloat(), enabled = on,
                            onValueChange = { v -> sizes[sd] = v.toInt(); EdgeFields.setGapDp(sp, sd, v.toInt()); onChanged() },
                        )
                    }
                }
            }
            Text("How the gap looks when you slide in", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(2 to "Blur", 1 to "Glow", 0 to "Colour").forEach { (v, name) ->
                    ChoiceChip(label = name, selected = style == v, onClick = { style = v; sp.edit().putInt("stripCxlStyle", v).apply(); onChanged() })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(0xFFFF3B30, 0xFFFF9500, 0xFFFFD60A, 0xFF34C759, 0xFF00C7BE, 0xFF0A84FF, 0xFFBF5AF2, 0xFFFFFFFF).forEach { c ->
                    val ci = c.toInt()
                    Box(
                        Modifier.size(28.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .background(androidx.compose.ui.graphics.Color(ci))
                            .border(if (color == ci) 3.dp else 1.dp, if (color == ci) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, androidx.compose.foundation.shape.CircleShape)
                            .clickable {
                                color = ci; hex = String.format("%06X", ci and 0xFFFFFF)
                                sp.edit().putInt("stripCxlColor", ci).apply(); onChanged()
                            },
                    )
                }
            }
            OutlinedTextField(
                value = hex, singleLine = true, label = { Text("Colour #RRGGBB") },
                onValueChange = { raw ->
                    hex = raw.filter { it.isLetterOrDigit() }.take(6).uppercase()
                    if (hex.length == 6) hex.toLongOrNull(16)?.let { v ->
                        color = (0xFF000000L or v).toInt(); sp.edit().putInt("stripCxlColor", color).apply(); onChanged()
                    }
                },
                modifier = Modifier.width(190.dp).padding(top = 4.dp),
            )
            }
        }
    }
}

/** The number of fields of each outside side: − and + beside the side's name. */
@Composable
private fun EdgeCounts(sp: android.content.SharedPreferences, tick: Int, onChanged: () -> Unit, below: @Composable () -> Unit = {}) {
    @Composable
    fun one(side: String, m: Modifier) {
        val n = remember(tick) { EdgeFields.count(sp, side) }
        Row(m, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("$side $n", Modifier.width(58.dp), fontSize = 12.sp)
            listOf("−" to -1, "+" to 1).forEach { (sym, d) ->
                val can = if (d < 0) n > 1 else n < EdgeFields.MAX
                val c = MaterialTheme.colorScheme.primary.copy(alpha = if (can) 1f else 0.3f)
                Box(
                    Modifier.size(28.dp).clip(RoundedCornerShape(14.dp))
                        .border(1.dp, c, RoundedCornerShape(14.dp))
                        .clickable(enabled = can) { EdgeFields.setCount(sp, side, n + d); onChanged() },
                    contentAlignment = Alignment.Center,
                ) { Text(sym, fontSize = 15.sp, color = c) }
            }
        }
    }
    var namesOn by remember { mutableStateOf(sp.getBoolean("stripEdgeAll", false)) }
    var namesWords by remember { mutableStateOf(EdgeFields.namesWords(sp)) }
    var namesIcon by remember { mutableStateOf(EdgeFields.namesIcon(sp)) }
    var namesHide by remember { mutableStateOf(sp.getBoolean("stripEdgeNamesHideFolder", false)) }
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        // The counts stick to the left and the options beside them start at the same height.
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (sd in listOf("Top", "Bottom", "Left", "Right")) one(sd, Modifier)
        }
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            OptSwitch("Show the Actions", namesOn, info = "Shown as soon as the cells window opens.") {
                namesOn = it; sp.edit().putBoolean("stripEdgeAll", it).apply(); onChanged()
            }
            // What each shown name is made of: Words and Icon are separate on/off buttons (both on = icon + words, both off = nothing shown).
            if (namesOn) ChipsRow(null, listOf("Words" to namesWords, "Icon" to namesIcon)) {
                if (it == 0) namesWords = !namesWords else namesIcon = !namesIcon
                sp.edit().putBoolean("stripEdgeNamesWords", namesWords).putBoolean("stripEdgeNamesIcon", namesIcon).apply(); onChanged()
            }
            OptSwitch("Hide Actions when folder opens", namesHide) {
                namesHide = it; sp.edit().putBoolean("stripEdgeNamesHideFolder", it).apply()
            }
        }
    }
    below()
    }
}

/**
 * The cells window at its true size with the outside fields drawn around it exactly as they work on
 * screen: the side the thumb is furthest past wins, so the corners are cut at 45 degrees, the fields of a
 * side are equal parts of the window's length, and the end fields reach on past the window's corners.
 * (On screen the fields go on to the edge of the screen; here only [bar] of them is drawn.)
 * Only the fields fade when the outside actions are off; the cells window stays clear.
 */
@Composable
private fun EdgeFrame(
    sp: android.content.SharedPreferences, tick: Int, enabled: Boolean,
    panelW: androidx.compose.ui.unit.Dp, panelH: androidx.compose.ui.unit.Dp, bar: androidx.compose.ui.unit.Dp,
    availW: androidx.compose.ui.unit.Dp,
    onEdit: (String) -> Unit,
    marked: Set<String>,
    onSwap: (String, String) -> Unit,
    content: @Composable () -> Unit,
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val t = with(density) { bar.toPx() }
    val w = with(density) { panelW.toPx() }
    val h = with(density) { panelH.toPx() }
    val fctx = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    val emptyFill = MaterialTheme.colorScheme.surfaceVariant
    val setFill = androidx.compose.ui.graphics.Color(0xFF37474F)

    /** One field: its key, the corners of its shape, and the straight part where its label goes (x0, y0, x1, y1). */
    class Fld(val side: String, val zone: Int, val n: Int, val pts: List<androidx.compose.ui.geometry.Offset>, val box: FloatArray, val gapPts: List<androidx.compose.ui.geometry.Offset>? = null)
    // The cancel gap is drawn at its true size (dp, the same px as on screen). Each side's frame is the strip of
    // fields shown (t) plus the room its gap needs.
    fun gapPx(side: String, zone: Int): Float = EdgeFields.gapFor(sp, side, zone) * density.density
    fun room(side: String): Float {
        var m = 0f
        for (i in 0 until EdgeFields.count(sp, side)) m = maxOf(m, gapPx(side, i))
        return m
    }
    val tT = t + room("Top"); val tB = t + room("Bottom"); val tL = t + room("Left"); val tR = t + room("Right")
    val totW = tL + w + tR; val totH = tT + h + tB
    // Too wide for the screen: the whole picture shrinks together, so every size stays true to the others.
    val sc = minOf(1f, with(density) { availW.toPx() } / totW)
    val fields = remember(tick, t, w, h, tT, tB, tL, tR) {
        val list = ArrayList<Fld>()
        for (side in EdgeFields.SIDES) {
            val n = EdgeFields.count(sp, side)
            for (i in 0 until n) {
                val first = i == 0; val last = i == n - 1
                val a = i.toFloat() / n; val b = (i + 1).toFloat() / n
                val pts: List<androidx.compose.ui.geometry.Offset>
                val box: FloatArray
                val d = gapPx(side, i)
                var gp: List<androidx.compose.ui.geometry.Offset>? = null
                if (side == "Top" || side == "Bottom") {
                    val xa = tL + w * a; val xb = tL + w * b
                    val yIn = if (side == "Top") tT else tT + h
                    val yOut = if (side == "Top") 0f else totH
                    val yG = if (side == "Top") yIn - d else yIn + d
                    val xaOut = if (first) xa - tL else xa; val xbOut = if (last) xb + tR else xb
                    val xaG = if (first) xa - d else xa; val xbG = if (last) xb + d else xb
                    pts = listOf(
                        androidx.compose.ui.geometry.Offset(xaG, yG), androidx.compose.ui.geometry.Offset(xbG, yG),
                        androidx.compose.ui.geometry.Offset(xbOut, yOut), androidx.compose.ui.geometry.Offset(xaOut, yOut),
                    )
                    if (d > 0f) gp = listOf(
                        androidx.compose.ui.geometry.Offset(xa, yIn), androidx.compose.ui.geometry.Offset(xb, yIn),
                        androidx.compose.ui.geometry.Offset(xbG, yG), androidx.compose.ui.geometry.Offset(xaG, yG),
                    )
                    box = floatArrayOf(xa, minOf(yG, yOut), xb, maxOf(yG, yOut))
                } else {
                    val ya = tT + h * a; val yb = tT + h * b
                    val xIn = if (side == "Left") tL else tL + w
                    val xOut = if (side == "Left") 0f else totW
                    val xG = if (side == "Left") xIn - d else xIn + d
                    val yaOut = if (first) ya - tT else ya; val ybOut = if (last) yb + tB else yb
                    val yaG = if (first) ya - d else ya; val ybG = if (last) yb + d else yb
                    pts = listOf(
                        androidx.compose.ui.geometry.Offset(xG, yaG), androidx.compose.ui.geometry.Offset(xG, ybG),
                        androidx.compose.ui.geometry.Offset(xOut, ybOut), androidx.compose.ui.geometry.Offset(xOut, yaOut),
                    )
                    if (d > 0f) gp = listOf(
                        androidx.compose.ui.geometry.Offset(xIn, ya), androidx.compose.ui.geometry.Offset(xIn, yb),
                        androidx.compose.ui.geometry.Offset(xG, ybG), androidx.compose.ui.geometry.Offset(xG, yaG),
                    )
                    box = floatArrayOf(minOf(xG, xOut), ya, maxOf(xG, xOut), yb)
                }
                list.add(Fld(side, i, n, pts, box, gp))
            }
        }
        list
    }
    // The same rule the strip uses on screen: the side the thumb is furthest past, then the equal part along it.
    fun hit(x: Float, y: Float): String? {
        val dTop = tT - y; val dBottom = y - (tT + h); val dLeft = tL - x; val dRight = x - (tL + w)
        val best = maxOf(maxOf(dTop, dBottom), maxOf(dLeft, dRight))
        if (best <= 0f) return null
        val side: String; val frac: Float
        when (best) {
            dTop -> { side = "Top"; frac = (x - tL) / maxOf(1f, w) }
            dBottom -> { side = "Bottom"; frac = (x - tL) / maxOf(1f, w) }
            dLeft -> { side = "Left"; frac = (y - tT) / maxOf(1f, h) }
            else -> { side = "Right"; frac = (y - tT) / maxOf(1f, h) }
        }
        val n = EdgeFields.count(sp, side)
        return EdgeFields.key(side, (frac * n).toInt().coerceIn(0, n - 1))
    }
    // Hold a set field and drag it onto another field: the two swap (an empty target just receives it).
    var dragFrom by remember { mutableStateOf<String?>(null) }
    var dragAt by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
    Box(
        Modifier.layout { m, c ->
            val pl = m.measure(androidx.compose.ui.unit.Constraints())
            layout(Math.round(pl.width * sc), Math.round(pl.height * sc)) {
                pl.placeWithLayer(0, 0) {
                    scaleX = sc; scaleY = sc
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0f)
                }
            }
        },
    ) {
    Box(
        Modifier.requiredSize(with(density) { totW.toDp() }, with(density) { totH.toDp() })
            .pointerInput(tick, tT, tB, tL, tR, w, h) { detectTapGestures { off -> hit(off.x, off.y)?.let(onEdit) } }
            .pointerInput(tick, tT, tB, tL, tR, w, h) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { off ->
                        dragFrom = hit(off.x, off.y)?.takeIf { k -> StripConfig.bare(sp.getString(k, "").orEmpty()).isNotEmpty() }
                        dragAt = off
                    },
                    onDrag = { ch, amount -> ch.consume(); dragAt = (dragAt ?: ch.position) + amount },
                    onDragEnd = {
                        val f = dragFrom; val at = dragAt
                        dragFrom = null; dragAt = null
                        if (f != null && at != null) { val k = hit(at.x, at.y); if (k != null && k != f) onSwap(f, k) }
                    },
                    onDragCancel = { dragFrom = null; dragAt = null },
                )
            },
    ) {
        Box(Modifier.matchParentSize().alpha(if (enabled) 1f else 0.4f)) {
            androidx.compose.foundation.Canvas(Modifier.matchParentSize()) {
                for (f in fields) {
                    val key = EdgeFields.key(f.side, f.zone)
                    val set = StripConfig.bare(sp.getString(key, "").orEmpty()).isNotEmpty()
                    val path = androidx.compose.ui.graphics.Path().apply {
                        moveTo(f.pts[0].x, f.pts[0].y)
                        for (k in 1 until f.pts.size) lineTo(f.pts[k].x, f.pts[k].y)
                        close()
                    }
                    drawPath(path, if (set) setFill else emptyFill)
                    val over = dragFrom?.let { dragAt?.let { a -> hit(a.x, a.y) } }
                    if (key in marked) drawPath(path, primary.copy(alpha = 0.55f))
                    else if (key == dragFrom) drawPath(path, primary.copy(alpha = 0.3f))
                    else if (over == key) drawPath(path, primary.copy(alpha = 0.6f))
                    drawPath(path, primary.copy(alpha = 0.7f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.dp.toPx()))
                    f.gapPts?.let { gp ->
                        val gpath = androidx.compose.ui.graphics.Path().apply {
                            moveTo(gp[0].x, gp[0].y)
                            for (k in 1 until gp.size) lineTo(gp[k].x, gp[k].y)
                            close()
                        }
                        val gc = androidx.compose.ui.graphics.Color(EdgeFields.gapColor(sp))
                        val gs = EdgeFields.gapStyle(sp)
                        drawPath(gpath, gc.copy(alpha = if (gs == 2) 0.35f else if (gs == 1) 0.15f else 0.6f))
                        if (gs != 0) for (k in 1..3) drawPath(gpath, gc.copy(alpha = 0.14f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = (k * 3).dp.toPx()))
                        if (gs != 2) drawPath(gpath, gc.copy(alpha = 0.95f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = (if (gs == 1) 2 else 1).dp.toPx()))
                    }
                }
            }
            for (f in fields) {
                val key = EdgeFields.key(f.side, f.zone)
                val raw = sp.getString(key, "").orEmpty()
                val (ml, mi) = EdgeFields.meta(sp, key)
                val bare = StripConfig.bare(raw)
                val set = bare.isNotEmpty()
                val entry = HandlerActionCatalog.entryFor(bare)
                val name = ml.ifEmpty { if (set) edgeActionName(fctx, bare) else "" }
                val tint = if (set) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                val bw = with(density) { (f.box[2] - f.box[0]).toDp() }
                val bh = with(density) { (f.box[3] - f.box[1]).toDp() }
                Box(
                    Modifier.offset { androidx.compose.ui.unit.IntOffset(f.box[0].toInt(), f.box[1].toInt()) }
                        .requiredSize(bw, bh).clip(RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        val room = minOf(bw, bh)
                        if (set && room >= 28.dp) {
                            val isz = (room * 0.45f).coerceIn(12.dp, 20.dp)
                            if (mi.isNotEmpty()) IconOrLabel(StripItem("", mi, ""), Modifier.size(isz), 14)
                            else if (entry != null) ActionIconImage(entry.icon, null, Modifier.size(isz), tint)
                        }
                        val label = (if (f.n > 1) "${f.zone + 1}" else "") +
                            (if (set && room >= 44.dp && name.isNotEmpty()) (if (f.n > 1) " " else "") + name else if (!set && f.n == 1) "—" else "")
                        if (label.isNotEmpty()) Text(
                            label, fontSize = 9.sp, color = tint, maxLines = 2, overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 2.dp),
                        )
                    }
                }
            }
        }
        Box(Modifier.offset { androidx.compose.ui.unit.IntOffset(tL.toInt(), tT.toInt()) }.size(panelW, panelH)) { content() }
        val gAt = dragAt
        if (dragFrom != null && gAt != null) Box(
            Modifier.offset { androidx.compose.ui.unit.IntOffset((gAt.x - 24.dp.toPx()).toInt(), (gAt.y - 24.dp.toPx()).toInt()) }
                .size(48.dp).clip(RoundedCornerShape(10.dp)).background(primary.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center,
        ) { Text("⇄", fontSize = 18.sp, color = androidx.compose.ui.graphics.Color.White) }
    }
    }
}

/** Choices for "Keep the icons ready": seconds; 0 = off. Dropped by themselves after this long unused. */
private val iconKeepSteps = listOf(0, 30, 60, 120, 300, 600, 1800)
