package a.a.flow

import a.a.auto.AutoStore
import a.a.strip.WhenRules
import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * The Scripts window's advanced search: which scripts have chosen actions, and which hold a text
 * (also the text inside Note blocks). Scripts are read only while a search is applied.
 */
object FlowSearch {
    /** [keys] are picks from [blockItems] and [actionItems]; [all] = must have every pick, else any pick. */
    class Query(
        val text: String = "", val scope: String = "all", val all: Boolean = false, val keys: Set<String> = emptySet(),
    ) {
        val active: Boolean get() = text.isNotBlank() || keys.isNotEmpty()
    }

    val SCOPES: List<Pair<String, String>> = listOf(
        "all" to "Everywhere in the script",
        "notes" to "Notes only",
        "messages" to "Messages and countdown texts",
        "commands" to "Commands, web addresses and shortcuts",
        "values" to "Variables and conditions",
    )

    class Item(val key: String, val label: String)

    /** Every kind of block that can be picked. */
    fun blockItems(): List<Item> {
        val out = ArrayList<Item>()
        for (t in Step.TYPES) {
            if (t == Step.ELSE || t == Step.END || t == Step.ACTION) continue
            if (t == Step.INTENT) {
                out.add(Item("t:intent", "Send intent"))
                out.add(Item("t:intent:raw", "Run raw shortcut"))
                continue
            }
            out.add(Item("t:$t", BlockStyle.title(Step(t))))
        }
        return out
    }

    /** Scripts that stay armed, wait or keep running. */
    fun stayItems(): List<Item> = listOf(
        Item("f:alwayson", "Marked Always On"),
        Item("f:running", "Running right now"),
        Item("f:starts", "Starts by itself (a When block that starts it)"),
        Item("f:waits", "Waits for something (a When block that waits)"),
        Item("f:appfront", "Only runs while a chosen app is in front"),
    )

    /** Other checks on what a script contains or how it is used. */
    fun otherItems(): List<Item> = listOf(
        Item("f:shizuku", "Uses Shizuku"),
        Item("f:values", "Uses {my values}"),
        Item("f:empty", "Empty (no blocks to run)"),
        Item("f:missing", "Calls a script that is missing"),
        Item("f:unused", "Not used by any cell, automation or script"),
    )

    /** Every device action a script can do. */
    fun actionItems(): List<Item> =
        NativeActions.all.map { Item("a:" + it.id, it.label) }.sortedBy { it.label.lowercase() }

    private fun keyOf(s: Step): String? = when (s.type) {
        Step.BEGIN, Step.ELSE, Step.END -> null
        Step.ACTION -> "a:" + s.a
        Step.INTENT -> if (s.b == "raw") "t:intent:raw" else "t:intent"
        else -> "t:" + s.type
    }

    /** The texts of one block that the chosen place covers. */
    private fun texts(s: Step, scope: String): List<String> = when (scope) {
        "notes" -> if (s.type == Step.NOTE) listOf(s.a) else emptyList()
        "messages" -> when (s.type) {
            Step.MESSAGE -> listOf(s.a)
            Step.COUNTDOWN -> listOf(s.b)
            Step.RATELIMIT -> listOf(s.d)
            else -> emptyList()
        }
        "commands" -> when (s.type) {
            Step.SHELL, Step.SHIZUKU, Step.INTENT, Step.HTTP -> listOf(s.a)
            Step.SHORTCUT -> listOf(s.a, s.b)
            Step.BROADCAST -> listOf(s.a, s.b, s.c)
            Step.LAUNCH -> listOf(s.a, s.c)
            Step.ACTION -> listOf(s.b)
            else -> emptyList()
        }
        "values" -> when (s.type) {
            Step.SET -> listOf(s.a, s.b)
            Step.IF -> listOf(s.a, s.b, s.c)
            Step.REPEAT -> listOf(s.a, s.c)
            Step.OCRWAIT -> listOf(s.d)
            else -> emptyList()
        }
        else -> {
            val l = arrayListOf(s.a, s.b, s.c, s.d, s.e, s.f)
            if (s.type == Step.ACTION) NativeActions.find(s.a)?.label?.let { l.add(it) }
            if (s.type == Step.RUN) l.add(FlowStore.display(s.a))
            l
        }
    }

    private fun around(t: String, at: Int, len: Int): String {
        val from = maxOf(0, at - 18)
        val to = minOf(t.length, at + len + 30)
        val core = t.substring(from, to).replace('\n', ' ')
        return (if (from > 0) "…" else "") + core + (if (to < t.length) "…" else "")
    }

    /** The text of every saved setting that mentions a script as "MyFlow:..." (what a cell stores), read as plain files. */
    private fun cellText(context: Context): String {
        val sb = StringBuilder()
        val dir = File(context.applicationInfo.dataDir, "shared_prefs")
        dir.listFiles()?.forEach { f ->
            if (!f.name.endsWith(".xml") || f.name == "FlowMeta.xml") return@forEach
            val t = runCatching { f.readText() }.getOrDefault("")
            if (!t.contains("MyFlow:")) return@forEach
            // The scripts themselves live in MyPrefs: leave them out, only cells count.
            val own = if (f.name == "MyPrefs.xml")
                t.replace(Regex("<string name=\"(flowsV1|flowIdsV1|flowAliasV1)\">[\\s\\S]*?</string>"), "") else t
            sb.append(own.replace("&quot;", "\"").replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")).append('\n')
        }
        return sb.toString()
    }

    /** True when [text] holds "MyFlow:" + [ref] and the reference does not just start a longer name. */
    private fun mentions(text: String, ref: String): Boolean {
        val needle = "MyFlow:$ref"
        var from = 0
        while (true) {
            val at = text.indexOf(needle, from)
            if (at < 0) return false
            val end = at + needle.length
            if (end >= text.length || !text[end].let { it.isLetterOrDigit() || it == ' ' || it == '_' }) return true
            from = at + 1
        }
    }

    private class Entry(val name: String, val have: HashSet<String>, val found: String?)

    /** The scripts in [names] that fit [q], each with a short piece of what was found ("" when only actions were asked). */
    fun match(context: Context, names: List<String>, q: Query): Map<String, String> {
        val root = runCatching { JSONObject(FlowStore.rawJson(context) ?: "{}") }.getOrDefault(JSONObject())
        val needle = q.text.trim()
        val wantF = q.keys.any { it.startsWith("f:") }
        val wantUnused = "f:unused" in q.keys
        val wantValues = "f:values" in q.keys
        // One pass over the saved data tells names, ids and always-on marks.
        val linkOf = HashMap<String, String>()
        val nameOfId = HashMap<String, String>()
        if (wantF) FlowStore.links(context).forEach { (n, link) -> linkOf[n] = link; if (link.startsWith("#")) nameOfId[link] = n }
        val alwaysOn: Set<String> = if ("f:alwayson" in q.keys)
            context.getSharedPreferences("FlowPrefs", Context.MODE_PRIVATE).getStringSet("alwaysOn", emptySet()) ?: emptySet()
        else emptySet()
        val runningNow: Set<String> = if ("f:running" in q.keys) {
            FlowRunner.running(includeBackground = WhenEvents.isBgEnabled(context), context = context).map { it.name }.toSet()
        } else emptySet()
        val tokens: List<String> = if (wantValues) PrivateValues.allSlots(context).map { "{" + it.name + "}" } else emptyList()
        fun target(ref: String): String? = when {
            ref.isEmpty() -> null
            ref.startsWith("#") -> nameOfId[ref] ?: FlowStore.resolve(context, ref)
            linkOf.containsKey(ref) -> ref
            else -> FlowStore.resolve(context, ref)
        }
        val called = HashSet<String>()
        val entries = ArrayList<Entry>()
        for (n in names) {
            val arr = root.optJSONArray(n) ?: continue
            val have = HashSet<String>()
            var found: String? = null
            var blocks = 0
            if (needle.isNotEmpty() && q.scope == "all" && n.contains(needle, true)) found = "Name: $n"
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val s = Step.fromJson(o)
                keyOf(s)?.let { have.add(it) }
                if (needle.isNotEmpty() && found == null) {
                    for (t in texts(s, q.scope)) {
                        val at = t.indexOf(needle, ignoreCase = true)
                        if (at >= 0) { found = BlockStyle.title(s) + ": " + around(t, at, needle.length); break }
                    }
                }
                if (wantF || wantUnused) {
                    if (s.type != Step.BEGIN && s.type != Step.NOTE) blocks++
                    when (s.type) {
                        Step.WHEN -> {
                            val mode = s.b.ifEmpty { WhenEvents.MODE_START }
                            if (mode == WhenEvents.MODE_START || mode == WhenEvents.MODE_BOTH) have.add("f:starts")
                            if (mode == WhenEvents.MODE_WAIT || mode == WhenEvents.MODE_BOTH) have.add("f:waits")
                        }
                        Step.ONLYIF -> if (s.a == WhenRules.ONLY_APP) have.add("f:appfront")
                        Step.SHIZUKU -> have.add("f:shizuku")
                        Step.ACTION -> if (NativeActions.find(s.a)?.need == NativeActions.Need.SHIZUKU) have.add("f:shizuku")
                        Step.RUN -> {
                            val t = target(s.a)
                            if (t == null) { if (s.a.isNotEmpty()) have.add("f:missing") } else called.add(t)
                        }
                    }
                    if (wantValues && tokens.isNotEmpty()) {
                        val fields = listOf(s.a, s.b, s.c, s.d, s.e, s.f)
                        if (tokens.any { tk -> fields.any { it.contains(tk) } }) have.add("f:values")
                    }
                }
            }
            if (wantF) {
                if (blocks == 0) have.add("f:empty")
                if ((linkOf[n] ?: "") in alwaysOn || n in alwaysOn) have.add("f:alwayson")
                if (n in runningNow) have.add("f:running")
            }
            entries.add(Entry(n, have, found))
        }
        if (wantUnused) {
            val cells = cellText(context)
            val auto = AutoStore.load(context).mapNotNull { target(it.flow) ?: it.flow }.toSet()
            for (e in entries) {
                val link = linkOf[e.name] ?: e.name
                val used = e.name in called || e.name in auto || mentions(cells, link) || mentions(cells, e.name)
                if (!used) e.have.add("f:unused")
            }
        }
        val out = LinkedHashMap<String, String>()
        for (e in entries) {
            if (needle.isNotEmpty() && e.found == null) continue
            if (q.keys.isNotEmpty() && !(if (q.all) e.have.containsAll(q.keys) else q.keys.any { it in e.have })) continue
            out[e.name] = e.found ?: ""
        }
        return out
    }
}
