package a.a.utils

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.util.ArrayDeque

/**
 * Two small helpers for the bug where the phone jumps between apps by itself.
 *
 * Log: every time A starts or switches to an app, and every app the accessibility service sees
 * come to the front, is written in the report's notes with the time to the millisecond and the
 * chain of A's own functions that asked for it.
 *
 * Brake: when A asks for more than [MAX_IN_WINDOW] app switches within [WINDOW_MS], it stops
 * switching apps for [PAUSE_MS] so there is time to reach A and turn the service off.
 *
 * Both are switches in A's main screen. Nothing runs or stays in memory between calls.
 */
object SwitchBrake {
    const val PREF_BRAKE = "switchBrakeOn"
    const val PREF_LOG = "switchLogOn"
    private const val MAX_IN_WINDOW = 6
    private const val WINDOW_MS = 5_000L
    private const val PAUSE_MS = 30_000L

    private val stamps = ArrayDeque<Long>()
    @Volatile private var blockedUntil = 0L

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(a.a.data.local.PREFERENCES_FILE, Context.MODE_PRIVATE)

    fun brakeOn(c: Context): Boolean = sp(c).getBoolean(PREF_BRAKE, true)
    fun logOn(c: Context): Boolean = sp(c).getBoolean(PREF_LOG, true)

    private fun ms(now: Long): String = String.format(java.util.Locale.US, "[.%03d]", now % 1000)

    /** The few of A's own functions that led here, newest first. */
    private fun caller(): String {
        val sb = StringBuilder()
        var n = 0
        for (e in Throwable().stackTrace) {
            val cn = e.className
            if (cn.startsWith("a.a.utils.SwitchBrake")) continue
            if (cn.startsWith("java.") || cn.startsWith("android.") || cn.startsWith("kotlin.") || cn.startsWith("dalvik.")) continue
            if (n > 0) sb.append(" < ")
            sb.append(cn.substringAfterLast('.')).append('.').append(e.methodName)
            if (++n >= 4) break
        }
        return sb.toString()
    }

    /**
     * Call right before A starts or switches to an app. False means the brake says no: do not start it.
     * [count] false for A's own screens: they are logged but never counted or blocked.
     */
    fun allow(context: Context, what: String, count: Boolean = true): Boolean {
        val app = context.applicationContext
        val logging = logOn(app)
        val brake = brakeOn(app)
        if (!logging && !brake) return true
        val now = System.currentTimeMillis()
        var tripped = false
        var blocked = false
        synchronized(this) {
            if (brake && count) {
                if (now < blockedUntil) {
                    blocked = true
                } else {
                    while (stamps.isNotEmpty() && now - stamps.first() > WINDOW_MS) stamps.removeFirst()
                    stamps.addLast(now)
                    if (stamps.size > MAX_IN_WINDOW) {
                        blockedUntil = now + PAUSE_MS
                        stamps.clear()
                        tripped = true
                        blocked = true
                    }
                }
            }
        }
        if (logging) DiagLog.note("SWITCH ${ms(now)} ${if (blocked) "BLOCKED " else ""}$what  <- ${caller()}")
        if (tripped) onTrip(app)
        return !blocked
    }

    /** An app came to the front (seen by the accessibility service). */
    fun front(context: Context, pkg: String?, cls: String?) {
        if (!logOn(context)) return
        DiagLog.note("FRONT ${ms(System.currentTimeMillis())} $pkg/${cls ?: "?"}")
    }

    /** One line of what is switched on right now, for the moments the service connects. */
    fun snapshot(context: Context, why: String) {
        if (!logOn(context)) return
        val running = runCatching {
            a.a.flow.FlowRunner.runningAll(context).joinToString(", ") {
                it.name + (if (it.listening) " (listening)" else "") + (if (it.waiting.isNotEmpty()) " [" + it.waiting + "]" else "")
            }
        }.getOrDefault("?")
        DiagLog.note(
            "STATE ${ms(System.currentTimeMillis())} $why: launcher mode=${runCatching { a.a.strip.LauncherGuard.isOn(context) }.getOrNull()}" +
                " brake=${brakeOn(context)} scripts=[${running.ifEmpty { "none" }}]"
        )
    }

    private fun onTrip(app: Context) {
        DiagLog.persist(app, "SWITCH BRAKE tripped: more than $MAX_IN_WINDOW app switches in ${WINDOW_MS / 1000} s. A stops switching apps for ${PAUSE_MS / 1000} s.")
        snapshot(app, "at brake")
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(app, "A stopped switching apps for 30 s (brake). You can turn the brake off in A's main screen.", Toast.LENGTH_LONG).show()
        }
        if (ShizukuShell.isReady()) Thread {
            val sb = StringBuilder()
            runCatching {
                ShizukuShell.run("dumpsys activity activities | grep -m2 -E 'topResumedActivity|mResumedActivity'") { sb.append(it.trim()).append(" | ") }
            }
            val recents = runCatching { PreviousApp.readRecents()?.take(8)?.joinToString(",") { t -> t.pkg } }.getOrNull()
            DiagLog.persist(app, "SWITCH BRAKE view: top=${sb.toString().take(300)} recents=${recents ?: "?"}")
        }.start()
    }
}
