package a.a.ui.screens.ziptool

import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipFile

/**
 * The text Claude gives Ali for the Terminal tab. It is plain text: a first line, a few header lines, then one
 * block for every change, then a last line that says how many changes there are. Every block carries a checksum
 * and every file its line count, so a paste that was cut short or changed on the way is refused, never applied.
 * The format is described in TERMINAL.md, and tool/make_terminal.py writes it.
 *
 *   ZIPTERMINAL 1
 *   NAME GestureVolumeB378.zip
 *   NOTE what this is
 *   @@FILE path crc32 lines [nonl]      whole new file (replaces the old one, or adds it)
 *   ...the lines of the file...
 *   @@END
 *   @@EDIT path findCrc replaceCrc      change one piece of a file; the piece must be found exactly once
 *   @@FIND
 *   ...the lines to find...
 *   @@WITH
 *   ...the lines to put there...
 *   @@END
 *   @@DELETE path
 *   @@DONE 3
 *
 * Paths are inside the project (app/src/...), the top folder of the zip is added by the Terminal.
 */
object TerminalScript {
    const val HEADER = "ZIPTERMINAL 1"
    private const val END = "@@END"
    private const val FIND = "@@FIND"
    private const val WITH = "@@WITH"

    sealed class Op(val path: String) {
        class Put(path: String, val bytes: ByteArray) : Op(path)
        class Edit(path: String, val find: String, val replacement: String) : Op(path)
        class Delete(path: String) : Op(path)
    }

    /** [problems] block the run. [chars] is how much text was pasted. */
    class Parsed(
        val ops: List<Op>,
        val name: String?,
        val notes: List<String>,
        val problems: List<String>,
        val chars: Int,
    )

    private class Block(val lines: List<String>, val end: Int)

    fun crcHex(b: ByteArray): String {
        val c = CRC32()
        c.update(b)
        return String.format(Locale.US, "%08x", c.value)
    }

    fun crcOf(s: String): String = crcHex(s.toByteArray(Charsets.UTF_8))

    /** The lines from [from] up to the next line that is exactly [stop], and where that line is. Null when there is none. */
    private fun readUntil(lines: List<String>, from: Int, stop: String): Block? {
        var j = from
        while (j < lines.size) {
            if (lines[j].trimEnd() == stop) return Block(lines.subList(from, j), j)
            j++
        }
        return null
    }

    private fun badPath(p: String): String? = when {
        p.isEmpty() -> "the path is empty"
        p.startsWith("/") || p.contains('\\') -> "the path is not safe"
        p.split('/').any { it.isEmpty() || it == ".." } -> "the path is not safe"
        else -> null
    }

    fun parse(raw: String): Parsed {
        val problems = ArrayList<String>()
        val ops = ArrayList<Op>()
        val notes = ArrayList<String>()
        var name: String? = null
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        var i = 0
        while (i < lines.size && lines[i].isBlank()) i++
        if (i >= lines.size || lines[i].trim() != HEADER) {
            return Parsed(
                emptyList(), null, emptyList(),
                listOf("This is not terminal text. It must start with the line $HEADER. Copy all of it."),
                raw.length,
            )
        }
        i++
        while (i < lines.size && !lines[i].startsWith("@@")) {
            val l = lines[i].trim()
            if (l.startsWith("NAME ")) {
                name = l.substring(5).trim()
            } else if (l.startsWith("NOTE ")) {
                notes.add(l.substring(5).trim())
            } else if (l.isNotEmpty()) {
                problems.add("line ${i + 1}: unknown line \"${l.take(60)}\".")
            }
            i++
        }
        var done = false
        var declared = -1
        var stop = false
        while (i < lines.size && !stop) {
            val line = lines[i]
            if (line.isBlank()) {
                i++
                continue
            }
            val no = i + 1
            val t = line.trim().split(Regex("\\s+"))
            when (t[0]) {
                "@@FILE" -> {
                    if (t.size < 4) {
                        problems.add("line $no: the FILE line is not complete.")
                        stop = true
                    } else {
                        val path = t[1]
                        val crc = t[2].lowercase(Locale.ROOT)
                        val count = t[3].toIntOrNull()
                        val nonl = t.size > 4 && t[4] == "nonl"
                        val blk = readUntil(lines, i + 1, END)
                        if (blk == null) {
                            problems.add("$path is cut short: there is no @@END after it. Copy all of the terminal text.")
                            stop = true
                        } else {
                            val bad = badPath(path)
                            if (bad != null) problems.add("line $no: $bad ($path).")
                            val body = blk.lines
                            val text = if (body.isEmpty()) "" else body.joinToString("\n") + (if (nonl) "" else "\n")
                            val bytes = text.toByteArray(Charsets.UTF_8)
                            if (count == null || count != body.size) {
                                problems.add("$path: should have ${count ?: "?"} lines, the paste has ${body.size}.")
                            } else if (crcHex(bytes) != crc) {
                                problems.add("$path: changed on the way (the checksum is different). Copy the terminal text again.")
                            }
                            ops.add(Op.Put(path, bytes))
                            i = blk.end + 1
                        }
                    }
                }
                "@@EDIT" -> {
                    if (t.size < 4) {
                        problems.add("line $no: the EDIT line is not complete.")
                        stop = true
                    } else if (lines.getOrNull(i + 1)?.trimEnd() != FIND) {
                        problems.add("line $no: ${t[1]}: the line after EDIT must be $FIND.")
                        stop = true
                    } else {
                        val path = t[1]
                        val findBlk = readUntil(lines, i + 2, WITH)
                        val withBlk = if (findBlk == null) null else readUntil(lines, findBlk.end + 1, END)
                        if (findBlk == null || withBlk == null) {
                            problems.add("$path is cut short: its EDIT block is not finished. Copy all of the terminal text.")
                            stop = true
                        } else {
                            val bad = badPath(path)
                            if (bad != null) problems.add("line $no: $bad ($path).")
                            val find = findBlk.lines.joinToString("\n")
                            val rep = withBlk.lines.joinToString("\n")
                            if (find.isEmpty()) {
                                problems.add("$path: the text to find is empty.")
                            } else if (crcOf(find) != t[2].lowercase(Locale.ROOT) || crcOf(rep) != t[3].lowercase(Locale.ROOT)) {
                                problems.add("$path: an edit changed on the way (the checksum is different). Copy the terminal text again.")
                            }
                            ops.add(Op.Edit(path, find, rep))
                            i = withBlk.end + 1
                        }
                    }
                }
                "@@DELETE" -> {
                    if (t.size < 2) {
                        problems.add("line $no: the DELETE line has no path.")
                        stop = true
                    } else {
                        val bad = badPath(t[1])
                        if (bad != null) problems.add("line $no: $bad (${t[1]}).")
                        ops.add(Op.Delete(t[1]))
                        i++
                    }
                }
                "@@DONE" -> {
                    declared = if (t.size > 1) (t[1].toIntOrNull() ?: -1) else -1
                    done = true
                    stop = true
                    i++
                }
                else -> {
                    problems.add("line $no: unexpected text \"${line.trim().take(60)}\".")
                    stop = true
                }
            }
        }
        if (done) {
            for (j in i until lines.size) {
                if (lines[j].isNotBlank()) {
                    problems.add("line ${j + 1}: there is text after the last line (@@DONE).")
                    break
                }
            }
            if (declared != ops.size) {
                problems.add("The paste has ${ops.size} change(s) but says $declared. Copy all of the terminal text.")
            }
        } else if (problems.isEmpty()) {
            problems.add("The paste looks cut short: the last line (@@DONE) is missing. Copy all of the terminal text.")
        }
        if (ops.isEmpty() && problems.isEmpty()) problems.add("The terminal text has no changes in it.")
        return Parsed(ops, name, notes, problems, raw.length)
    }
}

/**
 * Works out, for a source zip, what the pasted text would do: which files are replaced, added or removed. Every
 * path must be exact (nothing is guessed by file name), every EDIT must find its text exactly once, and a path
 * must not appear twice. Reads the source zip but never changes it.
 */
class TerminalAction(private val parsed: TerminalScript.Parsed) : ZipAction {

    override fun plan(src: ZipSource): ZipPlan {
        val problems = ArrayList<String>(parsed.problems)
        val replace = LinkedHashMap<String, ZipIo.Blob>()
        val add = ArrayList<Pair<String, ZipIo.Blob>>()
        val remove = LinkedHashSet<String>()
        val how = HashMap<String, String>()
        val unchanged = ArrayList<String>()
        val have = src.entries.toHashSet()

        val kinds = HashMap<String, String>()
        val twice = HashSet<String>()
        for (op in parsed.ops) {
            val kind = when (op) {
                is TerminalScript.Op.Put -> "file"
                is TerminalScript.Op.Edit -> "edit"
                is TerminalScript.Op.Delete -> "delete"
            }
            val before = kinds[op.path]
            if (before != null && !(before == "edit" && kind == "edit")) {
                if (twice.add(op.path)) problems.add("${op.path} is in the terminal text twice (as $before and as $kind).")
            }
            kinds[op.path] = kind
        }

        try {
            ZipFile(src.file).use { zf ->
                val edited = LinkedHashMap<String, String>()
                val editCount = HashMap<String, Int>()
                for (op in parsed.ops) {
                    if (op.path in twice) continue
                    val existing = locate(op.path, src, have)
                    when (op) {
                        is TerminalScript.Op.Put -> {
                            if (existing == null) {
                                add.add(newPath(op.path, src) to ZipIo.Blob(op.bytes))
                            } else {
                                val e = zf.getEntry(existing)
                                if (e != null && e.size == op.bytes.size.toLong() && e.crc == crcValue(op.bytes)) {
                                    unchanged.add(existing)
                                } else {
                                    replace[existing] = ZipIo.Blob(op.bytes)
                                    how[existing] = "whole file"
                                }
                            }
                        }
                        is TerminalScript.Op.Edit -> {
                            if (existing == null) {
                                problems.add("${op.path} is not in the zip, so it cannot be edited.")
                            } else {
                                val cur = edited[existing] ?: readText(zf, existing)
                                if (cur == null) {
                                    problems.add("${op.path} is not plain UTF-8 text, so it cannot be edited.")
                                } else {
                                    val crlf = cur.contains("\r\n")
                                    val find = if (crlf) op.find.replace("\n", "\r\n") else op.find
                                    val rep = if (crlf) op.replacement.replace("\n", "\r\n") else op.replacement
                                    val first = cur.indexOf(find)
                                    val n = (editCount[existing] ?: 0) + 1
                                    if (first < 0) {
                                        problems.add("${op.path}: the text for edit $n was not found in the file.")
                                    } else if (cur.indexOf(find, first + 1) >= 0) {
                                        problems.add("${op.path}: the text for edit $n was found more than once.")
                                    } else {
                                        edited[existing] = cur.substring(0, first) + rep + cur.substring(first + find.length)
                                        editCount[existing] = n
                                    }
                                }
                            }
                        }
                        is TerminalScript.Op.Delete -> {
                            if (existing == null) {
                                problems.add("${op.path} is not in the zip, so it cannot be removed.")
                            } else {
                                remove.add(existing)
                            }
                        }
                    }
                }
                for ((target, text) in edited) {
                    val bytes = text.toByteArray(Charsets.UTF_8)
                    val e = zf.getEntry(target)
                    if (e != null && e.size == bytes.size.toLong() && e.crc == crcValue(bytes)) {
                        unchanged.add(target)
                    } else {
                        replace[target] = ZipIo.Blob(bytes)
                        val n = editCount[target] ?: 1
                        how[target] = if (n == 1) "1 edit" else "$n edits"
                    }
                }
            }
        } catch (e: Throwable) {
            problems.add("The source zip could not be read: ${e.message ?: e.javaClass.simpleName}")
        }

        val lines = ArrayList<String>()
        for (n in parsed.notes) lines.add(n)
        section(lines, "Will replace", replace.keys, src, how)
        section(lines, "Will ADD", add.map { it.first }, src, null)
        section(lines, "Will REMOVE", remove, src, null)
        if (unchanged.isNotEmpty()) {
            lines.add("Already the same, left alone (${unchanged.size}): " + unchanged.sorted().joinToString(", ") { src.shown(it).substringAfterLast('/') })
        }
        if (replace.isEmpty() && add.isEmpty() && remove.isEmpty() && problems.isEmpty()) {
            lines.add("Nothing to change: the source zip already has all of this.")
        }
        return ZipPlan(replace, remove, add, lines.joinToString("\n"), problems, emptyList())
    }

    private fun section(out: MutableList<String>, title: String, names: Collection<String>, src: ZipSource, how: Map<String, String>?) {
        if (names.isEmpty()) return
        val sorted = names.sorted()
        out.add("$title ${sorted.size} file(s):")
        for ((i, n) in sorted.withIndex()) {
            if (i >= 40) {
                out.add(" ...and ${sorted.size - 40} more")
                break
            }
            val h = how?.get(n)
            out.add(" - " + src.shown(n) + (if (h != null) "  ($h)" else ""))
        }
    }

    /** The entry a path in the terminal text means: inside the zip's top folder, or exactly as written. Null when none. */
    private fun locate(p: String, src: ZipSource, have: Set<String>): String? =
        if ((src.root + p) in have) src.root + p else if (p in have) p else null

    /** Where a new file goes: inside the zip's top folder, unless the path already starts with it. */
    private fun newPath(p: String, src: ZipSource): String =
        if (src.root.isNotEmpty() && !p.startsWith(src.root)) src.root + p else p

    private fun readText(zf: ZipFile, name: String): String? {
        val e = zf.getEntry(name) ?: return null
        val b = zf.getInputStream(e).use { it.readBytes() }
        val s = String(b, Charsets.UTF_8)
        return if (s.toByteArray(Charsets.UTF_8).contentEquals(b)) s else null
    }

    private fun crcValue(b: ByteArray): Long {
        val c = CRC32()
        c.update(b)
        return c.value
    }
}
