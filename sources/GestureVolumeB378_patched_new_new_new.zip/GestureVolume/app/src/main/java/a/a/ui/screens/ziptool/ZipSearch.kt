package a.a.ui.screens.ziptool

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.components.KitRow
import a.a.ui.motion.Button

/**
 * The search of every list in Zip/Patch Tools. One line of text filters the list (the text is somewhere in the
 * path). Several pasted lines are read as a list of files: a line with a file name (or a whole path) is a file,
 * and a line that is only a folder path says where the file above it (or the one below it) lives, so you can
 * paste "ZipPlan.kt / GestureVolume/app/.../ziptool / ZipSource.kt / ..." as it comes. Every file that is found
 * exactly once is shown and ticked for you; a name that fits several files is shown but not ticked.
 */
object ZipSearch {
    /** [shown] is what the list shows, [pick] what is ticked for you, [note] one line about the result (or ""). */
    class Found(val shown: List<String>, val pick: List<String>, val note: String)

    private class Item(val name: String, var folder: String?)

    /** True when the text is several pasted lines (and not just one line with a line break at the end). */
    fun isList(q: String): Boolean = q.trim().contains('\n')

    fun filter(paths: List<String>, q: String): Found {
        val t = q.trim()
        if (t.isEmpty()) return Found(paths, emptyList(), "")
        if (!isList(q)) return Found(paths.filter { it.contains(t, ignoreCase = true) }, emptyList(), "")
        return fromList(paths, t)
    }

    private fun clean(raw: String): String {
        var s = raw.trim().replace('\\', '/')
        s = s.removePrefix("- ").removePrefix("* ").removePrefix("\u2022 ").trim()
        s = s.trim('"', '\'', '`', ',', ';').trim()
        return s.trim('/')
    }

    private fun dirOf(p: String): String = p.substringBeforeLast('/', "")

    private fun baseOf(p: String): String = p.substringAfterLast('/')

    /** [p] is the file [name] when they are the same path, or one is the end of the other (a project folder more or less). */
    private fun pathMatches(p: String, name: String): Boolean =
        p.equals(name, ignoreCase = true) ||
            p.endsWith("/$name", ignoreCase = true) ||
            name.endsWith("/$p", ignoreCase = true)

    private fun dirMatches(d: String, h: String): Boolean {
        if (d.isEmpty() || h.isEmpty()) return false
        return d.equals(h, ignoreCase = true) ||
            d.endsWith("/$h", ignoreCase = true) ||
            h.endsWith("/$d", ignoreCase = true)
    }

    private fun isFileLine(line: String, paths: List<String>, bases: Set<String>): Boolean {
        if (line.contains('/')) return paths.any { pathMatches(it, line) }
        return line.lowercase() in bases || line.contains('.')
    }

    private fun fromList(paths: List<String>, text: String): Found {
        val bases = HashSet<String>()
        for (p in paths) bases.add(baseOf(p).lowercase())
        val items = ArrayList<Item>()
        val folders = ArrayList<String>()
        var pending: String? = null
        for (raw in text.lines()) {
            val line = clean(raw)
            if (line.isEmpty()) continue
            if (isFileLine(line, paths, bases)) {
                items.add(Item(line, pending))
                pending = null
            } else {
                folders.add(line)
                val last = items.lastOrNull()
                if (last != null && last.folder == null && !last.name.contains('/')) {
                    last.folder = line
                } else {
                    pending = line
                }
            }
        }
        if (items.isEmpty()) {
            val inFolders = paths.filter { p -> folders.any { dirMatches(dirOf(p), it) } }
            val note = if (folders.isEmpty()) {
                "No file names found in the pasted text."
            } else {
                "${folders.size} folder(s) pasted: ${inFolders.size} files shown, none ticked."
            }
            return Found(inFolders, emptyList(), note)
        }
        val shown = LinkedHashSet<String>()
        val pick = LinkedHashSet<String>()
        val several = ArrayList<String>()
        val missing = ArrayList<String>()
        for (item in items) {
            var c = if (item.name.contains('/')) {
                paths.filter { pathMatches(it, item.name) }
            } else {
                paths.filter { baseOf(it).equals(item.name, ignoreCase = true) }
            }
            val h = item.folder
            if (h != null && c.size > 1) {
                val f = c.filter { dirMatches(dirOf(it), h) }
                if (f.isNotEmpty()) c = f
            }
            if (c.isEmpty()) {
                missing.add(baseOf(item.name))
            } else {
                shown.addAll(c)
                if (c.size == 1) pick.add(c[0]) else several.add(baseOf(item.name))
            }
        }
        val sb = StringBuilder("${items.size} name(s) pasted: ${pick.size} found and ticked")
        if (several.isNotEmpty()) sb.append(", ${several.size} fit several files (shown, not ticked)")
        if (missing.isNotEmpty()) {
            sb.append(". Not found: ").append(missing.take(5).joinToString(", "))
            if (missing.size > 5) sb.append(" and ${missing.size - 5} more")
        }
        return Found(shown.toList(), pick.toList(), sb.toString())
    }
}

/** The search box. It takes several lines, so a pasted list keeps its line breaks. */
@Composable
fun SearchField(query: String, label: String, onQuery: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        maxLines = 3,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
    )
}

/**
 * The window to tick files from a list, used wherever Zip/Patch Tools asks for files (to replace, to delete,
 * to take out). [picked] are the ticked paths; every change goes back through [onPicked]. Pasting a list of
 * names into the search box shows those files and ticks them for you (see [ZipSearch]); you can untick any.
 */
@Composable
fun PickListWindow(
    title: String,
    entries: List<String>,
    picked: Set<String>,
    onPicked: (Set<String>) -> Unit,
    onClose: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val found = remember(entries, query) { ZipSearch.filter(entries, query) }
    CardWindow(title = "$title (${picked.size} chosen)", onBack = onClose, scroll = false) {
        SearchField(
            query = query,
            label = "Search or paste names (${found.shown.size} files)",
            onQuery = { q ->
                query = q
                if (ZipSearch.isList(q)) {
                    val f = ZipSearch.filter(entries, q)
                    if (f.pick.isNotEmpty()) onPicked(picked + f.pick)
                }
            },
            modifier = Modifier.padding(bottom = 4.dp),
        )
        if (found.note.isNotEmpty()) {
            Text(
                found.note,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { onPicked(picked + found.shown) }) { Text("Tick all shown") }
            TextButton(onClick = { onPicked(picked - found.shown.toSet()) }) { Text("Untick shown") }
            TextButton(onClick = { onPicked(emptySet()) }) { Text("Clear") }
        }
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(found.shown) { path ->
                val on = path in picked
                KitRow(
                    title = path.substringAfterLast('/'),
                    shape = RoundedCornerShape(14.dp),
                    description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                    onClick = { onPicked(if (on) picked - path else picked + path) },
                    trailing = { Checkbox(checked = on, onCheckedChange = { onPicked(if (on) picked - path else picked + path) }) },
                )
            }
        }
        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Done") }
    }
}
