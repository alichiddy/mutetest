package a.a.ui.screens.ziptool

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * "Take files out" for the one tab: tick files of the source and save them as folders (the zip's own folders
 * kept, inside one folder in Downloads) or as one new zip holding only them. It makes a subset, not a changed
 * copy of the source, so it is not a [ZipPlan]: when it is ticked the other actions are switched off. The
 * writing is the one of the old Extract tab: every file is checked against its checksum while it is copied
 * and read back, and the source is never changed.
 */
class ExtractAction(private val ctx: Context) {
    var picked by mutableStateOf<Set<String>>(emptySet())
    var asFolders by mutableStateOf(true)
    var outName by mutableStateOf("")
    var showList by mutableStateOf(false)
    private var stem = "extracted"
    private var nameAuto = true

    private fun defaultName(): String = if (asFolders) "${stem}_extracted" else "${stem}_extracted.zip"

    /** A source was loaded: nothing is ticked yet, and the suggested name follows it (unless it was typed in). */
    fun setSource(src: ZipSource, fresh: Boolean) {
        picked = emptySet()
        stem = ZipIo.stem(src.name).ifEmpty { "extracted" }
        if (fresh || nameAuto) {
            nameAuto = true
            outName = defaultName()
        }
    }

    /** The name box was typed in: it is the user's now, and stays when the choice changes. */
    fun renamed(s: String) {
        outName = s
        nameAuto = false
    }

    /** Folders or one zip; the suggested name follows unless it was typed in. */
    fun chooseFolders(on: Boolean) {
        asFolders = on
        if (nameAuto) outName = defaultName()
    }

    fun toggle(path: String) {
        picked = if (path in picked) picked - path else picked + path
    }

    fun tick(paths: List<String>) {
        picked = picked + paths
    }

    fun untick(paths: List<String>) {
        picked = picked - paths.toSet()
    }

    fun clear() {
        picked = emptySet()
    }

    /** The Check box text: what will be taken out and where it will be saved. */
    fun summary(src: ZipSource): String {
        val names = src.entries.filter { it in picked }
        if (names.isEmpty()) return "Take files out: choose the files from the list."
        val sb = StringBuilder()
        sb.append("Take files out: ${names.size} file(s)\n")
        val name = outName.trim()
        if (asFolders) {
            sb.append(" saved as folders in Downloads/${name.ifEmpty { "..." }}/\n")
        } else {
            sb.append(" saved as one new zip ${name.ifEmpty { "..." }}\n")
        }
        for (n in names.take(8)) sb.append("  ").append(src.shown(n)).append('\n')
        if (names.size > 8) sb.append("  ...and ${names.size - 8} more\n")
        return sb.toString().trim()
    }

    /** Takes the ticked files out of [src] and returns the text for the Result box. Blocks: run it on a worker thread. */
    fun run(src: ZipSource, tmp: File): String {
        val names = src.entries.filter { it in picked }.distinct()
        val toFolders = asFolders
        val name = outName
        return try {
            if (toFolders) toFolder(src.file, names, name) else toZip(src.file, tmp, names, name)
        } catch (e: Throwable) {
            "ERROR: ${e.javaClass.simpleName}: ${e.message}\n" +
                (if (toFolders) "Stopped. Files saved before the error are in Downloads." else "Nothing was saved.")
        }
    }

    /** One new zip holding only [names], each with its own path, read back and checked before it is saved. */
    private fun toZip(src: File, tmp: File, names: List<String>, outName: String): String {
        val saveName = ZipIo.cleanName(outName, "extracted")
        val expect = HashMap<String, Long>()
        ZipFile(src).use { zf ->
            ZipOutputStream(tmp.outputStream().buffered()).use { zo ->
                for (n in names) {
                    val e = zf.getEntry(n) ?: throw IllegalStateException("$n was not found in the zip.")
                    val o = ZipEntry(n)
                    if (e.time != -1L) o.time = e.time
                    if (e.comment != null) o.comment = e.comment
                    o.method = ZipEntry.DEFLATED
                    zo.putNextEntry(o)
                    val crc = CRC32()
                    zf.getInputStream(e).use { i -> pump(i, zo, crc) }
                    zo.closeEntry()
                    if (e.crc != -1L && e.crc != crc.value) throw IllegalStateException("$n is damaged inside the zip.")
                    expect[n] = crc.value
                }
            }
        }
        val problem = ZipIo.verify(tmp, names.size, expect)
        if (problem != null) return "ZIP ERROR: $problem\nNothing was saved."
        val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
        return "Created: $where (${ZipIo.mb(tmp.length())})\nZIP integrity check passed. ${names.size} files.\n" + fileList(names)
    }

    /** Every file of [names] saved under Downloads/[outName], keeping its folders; each is read back and checked. */
    private fun toFolder(src: File, names: List<String>, outName: String): String {
        var folder = outName.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").trim('.', ' ')
        if (folder.isEmpty()) folder = "extracted"
        val skipped = ArrayList<String>()
        var count = 0
        var bytes = 0L
        ZipFile(src).use { zf ->
            for (n in names) {
                val parts = n.split('/').filter { it.isNotEmpty() }
                if (parts.isEmpty() || parts.any { it == ".." || it == "." }) {
                    skipped.add(n)
                    continue
                }
                val e = zf.getEntry(n) ?: throw IllegalStateException("$n was not found in the zip.")
                val sub = parts.dropLast(1).joinToString("/")
                bytes += saveFile(zf, e, folder, sub, parts.last())
                count++
            }
        }
        val sb = StringBuilder("Saved: Downloads/$folder/ ($count files, ${ZipIo.size(bytes)})\n")
        sb.append("Every file was read back and checked.\n")
        if (skipped.isNotEmpty()) sb.append("Left out (unsafe path): ${skipped.joinToString(", ")}\n")
        sb.append(fileList(names))
        return sb.toString()
    }

    /** Saves one file in Downloads/[folder]/[sub] and returns its size; throws when what was saved does not match. */
    @Suppress("DEPRECATION")
    private fun saveFile(zf: ZipFile, e: ZipEntry, folder: String, sub: String, fileName: String): Long {
        val crc = CRC32()
        var total = 0L
        val back = CRC32()
        var backTotal = 0L
        val path = if (sub.isEmpty()) folder else "$folder/$sub"
        if (Build.VERSION.SDK_INT >= 29) {
            val cr = ctx.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + path)
            }
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create $fileName in Downloads.")
            val os = cr.openOutputStream(uri) ?: throw IllegalStateException("Could not write $fileName in Downloads.")
            os.use { o -> zf.getInputStream(e).use { i -> total = pump(i, o, crc) } }
            val ins = cr.openInputStream(uri) ?: throw IllegalStateException("Could not read $fileName back.")
            ins.use { i -> backTotal = pump(i, null, back) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), path)
            dir.mkdirs()
            val dest = File(dir, fileName)
            dest.outputStream().use { o -> zf.getInputStream(e).use { i -> total = pump(i, o, crc) } }
            dest.inputStream().use { i -> backTotal = pump(i, null, back) }
        }
        if (e.crc != -1L && e.crc != crc.value) throw IllegalStateException("${e.name} is damaged inside the zip.")
        if (back.value != crc.value || backTotal != total) throw IllegalStateException("${e.name} was not saved correctly.")
        return total
    }

    /** Copies [i] to [o] (when there is one) while counting the checksum; returns how many bytes went through. */
    private fun pump(i: InputStream, o: OutputStream?, crc: CRC32): Long {
        val buf = ByteArray(ZipIo.BUF)
        var total = 0L
        while (true) {
            val r = i.read(buf)
            if (r < 0) break
            crc.update(buf, 0, r)
            o?.write(buf, 0, r)
            total += r
        }
        return total
    }

    /** The files that were taken out, one per line (the first 40). */
    private fun fileList(names: List<String>): String {
        val sb = StringBuilder()
        for (n in names.take(40)) sb.append(" - ").append(n).append('\n')
        if (names.size > 40) sb.append("... and ${names.size - 40} more")
        return sb.toString().trimEnd()
    }
}

/** The box of "Take files out" that opens the list, and the list window itself (search, tick all shown, clear). */
@Composable
fun ExtractSection(x: ExtractAction, src: ZipSource, busy: Boolean) {
    Column {
        GroupHeading("Take files out")
        RowGroup {
            KitRow(
                title = "Files to take out",
                shape = cardShape(0, 1),
                summary = if (x.picked.isEmpty()) "Tap to choose from the list" else "${x.picked.size} chosen",
                onClick = { if (!busy) x.showList = true },
            )
        }
    }
    if (x.showList) {
        PickListWindow(
            title = "Files to take out",
            entries = src.entries,
            picked = x.picked,
            onPicked = { x.picked = it },
            onClose = { x.showList = false },
        )
    }
}

/** "Save as" for Take files out: the Folders / One zip chips, then the name box. */
@Composable
fun ExtractSaveAs(x: ExtractAction, busy: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        GroupHeading("Save as")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Folders", x.asFolders, onClick = { if (!busy) x.chooseFolders(true) })
            ChoiceChip("One zip", !x.asFolders, onClick = { if (!busy) x.chooseFolders(false) })
        }
        OutlinedTextField(
            value = x.outName,
            onValueChange = { x.renamed(it) },
            singleLine = true,
            label = { Text(if (x.asFolders) "Folder name (saved in Downloads)" else "File name (saved in Downloads)") },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}
