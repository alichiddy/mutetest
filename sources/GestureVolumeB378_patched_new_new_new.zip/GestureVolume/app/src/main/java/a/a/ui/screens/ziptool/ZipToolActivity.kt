package a.a.ui.screens.ziptool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip

/**
 * Zip/Patch Tools: one window, one tab, for everything done to zips and project folders. Pick a zip or a folder,
 * then choose what to do: replace or add files, rename the app, zip it as it is, delete files, compare with
 * another zip or folder and take what you choose, or take files out. Actions can be combined (except taking
 * files out).
 *
 * Terminal: a second tab where you paste the text Claude gives you; the full source zip is patched and saved as
 * a new full zip.
 *
 * Every action saves a new zip (or folders) in Downloads, reads it back and checks it, and never changes what you
 * picked. Nothing runs or is held in memory until this window is open.
 */
class ZipToolActivity : ComponentActivity() {
    private enum class Mode(val tab: String) {
        ONE("Zip/Patch Tools"),
        TERMINAL("Terminal"),
    }

    private var mode by mutableStateOf(Mode.ONE)

    private val one by lazy { OneState(applicationContext) }
    private val terminal by lazy { TerminalState(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modeFrom(intent)
        setContent {
            AWindow {
                AWindowPage("Zip/Patch Tools", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            for (m in Mode.entries) {
                                ChoiceChip(m.tab, mode == m, onClick = { mode = m })
                            }
                        }
                        when (mode) {
                            Mode.ONE -> OneTab(one)
                            Mode.TERMINAL -> TerminalTab(terminal)
                        }
                    }
                }
            }
        }
    }

    /** Shortcuts saved before the tools were merged still work: they open the first tab with that action ticked. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        modeFrom(intent)
    }

    private fun modeFrom(i: Intent?) {
        val key = i?.getStringExtra(EXTRA_MODE) ?: return
        if (key == "terminal") {
            mode = Mode.TERMINAL
            return
        }
        mode = Mode.ONE
        val tick = when (key) {
            "one" -> i?.getStringExtra(EXTRA_TICK)
            "replace", "patch" -> "replace"
            "rename" -> "rename"
            "extract" -> "extract"
            "folder" -> "asis"
            "merge" -> "compare"
            else -> null
        }
        one.tickFromShortcut(tick)
    }

    override fun onDestroy() {
        if (isFinishing) {
            one.cleanup()
            terminal.cleanup()
        }
        super.onDestroy()
    }

    companion object {
        /** "terminal" opens the Terminal tab. "one" opens Zip/Patch Tools (with EXTRA_TICK ticked). The old keys replace, patch, rename, extract, folder and merge still work: they tick the matching action. */
        const val EXTRA_MODE = "zipToolMode"

        /** With EXTRA_MODE "one": the action to tick (replace, rename, asis, delete, compare or extract). */
        const val EXTRA_TICK = "zipToolTick"
    }
}
