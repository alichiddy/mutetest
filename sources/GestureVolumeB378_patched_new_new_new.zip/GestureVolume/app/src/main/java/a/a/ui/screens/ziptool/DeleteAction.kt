package a.a.ui.screens.ziptool

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import a.a.ui.components.GroupHeading
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape

/**
 * "Delete files": the chosen files are left out of the new zip. The picked zip or folder is not changed, only the
 * new zip lacks them. It is a plain [ZipPlan] (the `remove` part), so it can be combined with the other actions.
 */
class DeleteAction : ZipAction {
    var picked by mutableStateOf<Set<String>>(emptySet())
    var showList by mutableStateOf(false)

    /** A new source was loaded: nothing is ticked yet. */
    fun reset() {
        picked = emptySet()
    }

    override fun plan(src: ZipSource): ZipPlan {
        val names = src.entries.filter { it in picked }
        if (names.isEmpty()) return ZipPlan(emptyMap(), emptySet(), emptyList(), "", emptyList(), emptyList())
        val sb = StringBuilder("Delete files: ${names.size} file(s) will be left out of the new zip:\n")
        for (n in names.take(40)) sb.append("  ").append(src.shown(n)).append('\n')
        if (names.size > 40) sb.append("  ...and ${names.size - 40} more\n")
        return ZipPlan(emptyMap(), names.toHashSet(), emptyList(), sb.toString().trim(), emptyList(), emptyList())
    }
}

/** The box of "Delete files" that opens the list (search, or paste a list of names to tick them). */
@Composable
fun DeleteSection(d: DeleteAction, src: ZipSource, busy: Boolean) {
    Column {
        GroupHeading("Delete files")
        RowGroup {
            KitRow(
                title = "Files to delete",
                shape = cardShape(0, 1),
                summary = if (d.picked.isEmpty()) "Tap to choose from the list" else "${d.picked.size} chosen",
                description = "They are left out of the new zip. What you picked is not changed.",
                onClick = { if (!busy) d.showList = true },
            )
        }
    }
    if (d.showList) {
        PickListWindow(
            title = "Files to delete",
            entries = src.entries,
            picked = d.picked,
            onPicked = { d.picked = it },
            onClose = { d.showList = false },
        )
    }
}
