package a.a.ui.screens.ziptool

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.CardWindow
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.File
import java.util.TreeSet
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * "Compare with another zip or folder": the source of the tab is A (the base), the second source is B (the other
 * version). Every file is compared; the ones that differ are listed with what is different (lines added and
 * removed for text), and you choose, file by file, what to take from B: a changed file replaces A's, a file that
 * is new in B is added, a file that is only in A is removed. It is a plain [ZipPlan], so it can be combined with
 * the other actions. A and B themselves are never changed.
 */
class CompareAction(private val ctx: Context) : ZipAction {
    /** CHANGED: in both, different. ONLY_B: new in B. ONLY_A: in A but not in B. */
    enum class Kind { CHANGED, ONLY_B, ONLY_A }

    /** One difference. [rel] is the path with each source's top folder taken off, so the two line up. */
    class Diff(
        val rel: String,
        val kind: Kind,
        val aName: String?,
        val bName: String?,
        val aSize: Long,
        val bSize: Long,
        val summary: String,
        val isText: Boolean,
    )

    var b by mutableStateOf<ZipSource?>(null)
    var diffs by mutableStateOf<List<Diff>>(emptyList())
    var same by mutableStateOf(0)
    var compared by mutableStateOf(false)
    var comparedA by mutableStateOf<ZipSource?>(null)
    var picked by mutableStateOf<Set<String>>(emptySet())
    var showReview by mutableStateOf(false)
    var detail by mutableStateOf<Diff?>(null)
    var detailLines by mutableStateOf<List<String>?>(null)

    /** B is opened only while the new zip is written, and closed again by [ZipPlan.finish]. */
    private var zfB: ZipFile? = null

    private fun closeB() {
        val z = zfB
        zfB = null
        if (z != null) {
            try {
                z.close()
            } catch (e: Exception) {
                // nothing to do: the file is only read
            }
        }
    }

    /** The old comparison no longer fits (a new A or B). B itself stays. */
    fun resetDiffs() {
        diffs = emptyList()
        same = 0
        compared = false
        comparedA = null
        picked = emptySet()
        showReview = false
        detail = null
        detailLines = null
    }

    fun setB(z: ZipSource) {
        closeB()
        b = z
        resetDiffs()
    }

    // ---------------------------------------------------------------- comparing

    /** Runs on a worker thread. Lines A and B up by path (their top folders taken off) and lists what differs. */
    fun compare(a: ZipSource, status: (String) -> Unit) {
        val bs = b ?: return
        val fa = a.file
        val fb = bs.file
        status("Comparing...")
        val aRoot = a.root
        val bRoot = bs.root
        val found = ArrayList<Diff>()
        var identical = 0
        ZipFile(fa).use { za ->
            ZipFile(fb).use { zb ->
                val aMap = HashMap<String, ZipEntry>()
                for (n in a.entries) {
                    val e = za.getEntry(n) ?: continue
                    aMap[n.removePrefix(aRoot)] = e
                }
                val bMap = HashMap<String, ZipEntry>()
                for (n in bs.entries) {
                    val e = zb.getEntry(n) ?: continue
                    bMap[n.removePrefix(bRoot)] = e
                }
                val rels = TreeSet<String>()
                rels.addAll(aMap.keys)
                rels.addAll(bMap.keys)
                var i = 0
                for (rel in rels) {
                    i++
                    if (i % 10 == 0) status("Comparing $i of ${rels.size}...")
                    val ea = aMap[rel]
                    val eb = bMap[rel]
                    if (ea != null && eb != null) {
                        if (ea.size == eb.size && ea.crc == eb.crc) {
                            identical++
                        } else {
                            found.add(changed(rel, za, ea, zb, eb))
                        }
                    } else if (eb != null) {
                        found.add(Diff(rel, Kind.ONLY_B, null, eb.name, 0L, eb.size, "new in B, ${ZipIo.size(eb.size)}", false))
                    } else if (ea != null) {
                        found.add(Diff(rel, Kind.ONLY_A, ea.name, null, ea.size, 0L, "not in B, ${ZipIo.size(ea.size)}", false))
                    }
                }
            }
        }
        picked = emptySet()
        diffs = found
        same = identical
        comparedA = a
        compared = true
        status("")
    }

    /** One file that is in both and differs: for text, how many lines were added and removed. */
    private fun changed(rel: String, za: ZipFile, ea: ZipEntry, zb: ZipFile, eb: ZipEntry): Diff {
        val sa = ea.size
        val sb = eb.size
        var summary = "different content, ${ZipIo.size(sa)} -> ${ZipIo.size(sb)}"
        var isText = false
        if (sa <= LineDiff.MAX_TEXT && sb <= LineDiff.MAX_TEXT) {
            val ba = za.getInputStream(ea).use { it.readBytes() }
            val bb = zb.getInputStream(eb).use { it.readBytes() }
            if (LineDiff.looksText(ba) && LineDiff.looksText(bb)) {
                isText = true
                val r = LineDiff.diff(
                    LineDiff.split(String(ba, Charsets.UTF_8)),
                    LineDiff.split(String(bb, Charsets.UTF_8)),
                )
                summary = when {
                    r.tooBig -> "big change: ${r.regionOld} lines became ${r.regionNew}"
                    r.sameLines -> "only line endings or the last newline differ"
                    else -> "+${r.added} / -${r.removed} lines"
                }
            }
        }
        return Diff(rel, Kind.CHANGED, ea.name, eb.name, sa, sb, summary, isText)
    }

    // ---------------------------------------------------------------- choosing

    fun toggle(rel: String) {
        picked = if (rel in picked) picked - rel else picked + rel
    }

    fun pickAll(rels: Collection<String>) {
        picked = picked + rels
    }

    fun clear(rels: Collection<String>) {
        picked = picked - rels.toSet()
    }

    /** Reads the two versions and builds the lines of the "what is different" view. */
    fun openDetail(a: ZipSource, d: Diff) {
        detail = d
        detailLines = null
        val fa = a.file
        val fb = b?.file
        Thread {
            val lines: List<String> = try {
                if (fb == null) {
                    listOf("B is not loaded.")
                } else {
                    ZipFile(fa).use { za ->
                        ZipFile(fb).use { zb ->
                            describe(d, za, zb)
                        }
                    }
                }
            } catch (e: Throwable) {
                listOf("Could not read the files: ${e.message ?: e.javaClass.simpleName}")
            }
            if (detail === d) detailLines = lines
        }.start()
    }

    private fun describe(d: Diff, za: ZipFile, zb: ZipFile): List<String> {
        val ea = d.aName?.let { za.getEntry(it) }
        val eb = d.bName?.let { zb.getEntry(it) }
        return when (d.kind) {
            Kind.CHANGED ->
                if (ea == null || eb == null) listOf("A file is missing from one of the sources.")
                else describeChanged(d, za, ea, zb, eb)
            Kind.ONLY_B ->
                if (eb == null) listOf("The file is missing from B.") else whole(zb, eb, '+')
            Kind.ONLY_A ->
                if (ea == null) listOf("The file is missing from A.") else whole(za, ea, '-')
        }
    }

    private fun describeChanged(d: Diff, za: ZipFile, ea: ZipEntry, zb: ZipFile, eb: ZipEntry): List<String> {
        if (!d.isText) {
            return listOf(
                "This file is not plain text (or is very large), so it cannot be compared line by line.",
                "A: ${ZipIo.size(d.aSize)}",
                "B: ${ZipIo.size(d.bSize)}",
            )
        }
        val ba = za.getInputStream(ea).use { it.readBytes() }
        val bb = zb.getInputStream(eb).use { it.readBytes() }
        val r = LineDiff.diff(
            LineDiff.split(String(ba, Charsets.UTF_8)),
            LineDiff.split(String(bb, Charsets.UTF_8)),
        )
        return when {
            r.tooBig -> listOf("The changed part is too large to show line by line: ${r.regionOld} lines in A became ${r.regionNew} in B.")
            r.sameLines -> listOf("The lines are the same. Only line endings or the last newline differ.")
            else -> r.lines
        }
    }

    private fun whole(z: ZipFile, e: ZipEntry, mark: Char): List<String> {
        if (e.size > LineDiff.MAX_TEXT) return listOf("This file is too large to show (${ZipIo.size(e.size)}).")
        val bytes = z.getInputStream(e).use { it.readBytes() }
        if (!LineDiff.looksText(bytes)) return listOf("This file is not plain text (${ZipIo.size(e.size)}).")
        return LineDiff.whole(String(bytes, Charsets.UTF_8), mark)
    }

    // ---------------------------------------------------------------- the plan

    private fun blobOf(f: File, name: String): ZipIo.Blob = ZipIo.Blob(opener = {
        val zf = zfB ?: ZipFile(f).also { zfB = it }
        val e = zf.getEntry(name) ?: throw IllegalStateException("$name is missing in B.")
        zf.getInputStream(e)
    })

    private fun blocked(text: String): ZipPlan =
        ZipPlan(emptyMap(), emptySet(), emptyList(), "", listOf(text), emptyList())

    override fun plan(src: ZipSource): ZipPlan {
        val bs = b ?: return blocked("Compare: pick the other zip or folder (B).")
        if (!compared || comparedA !== src) return blocked("Compare: comparing A and B...")
        val chosen = diffs.filter { it.rel in picked }
        if (chosen.isEmpty()) {
            val text = if (diffs.isEmpty()) {
                "Compare: A and B are the same. ${same} files match."
            } else {
                "Compare: ${diffs.size} difference(s) found. Choose what to take from B in \"Review the differences\"."
            }
            return ZipPlan(emptyMap(), emptySet(), emptyList(), text, emptyList(), emptyList())
        }
        val replace = LinkedHashMap<String, ZipIo.Blob>()
        val remove = LinkedHashSet<String>()
        val add = ArrayList<Pair<String, ZipIo.Blob>>()
        for (d in chosen) {
            when (d.kind) {
                Kind.CHANGED -> replace[d.aName ?: d.rel] = blobOf(bs.file, d.bName ?: d.rel)
                Kind.ONLY_B -> add.add((src.root + d.rel) to blobOf(bs.file, d.bName ?: d.rel))
                Kind.ONLY_A -> remove.add(d.aName ?: d.rel)
            }
        }
        val sb = StringBuilder()
        sb.append("Compare with ${bs.name}: ${chosen.size} chosen (")
        sb.append("${replace.size} taken from B, ${add.size} added, ${remove.size} removed)")
        sb.append('\n')
        for ((i, d) in chosen.withIndex()) {
            if (i >= 40) {
                sb.append("  ...and ${chosen.size - 40} more\n")
                break
            }
            val mark = when (d.kind) {
                Kind.CHANGED -> "~ "
                Kind.ONLY_B -> "+ "
                Kind.ONLY_A -> "- "
            }
            sb.append("  ").append(mark).append(d.rel).append('\n')
        }
        return ZipPlan(
            replace, remove, add, sb.toString().trim(), emptyList(), emptyList(),
            finish = { closeB() },
        )
    }
}

private fun kindLabel(k: CompareAction.Kind): String = when (k) {
    CompareAction.Kind.CHANGED -> "Different in B"
    CompareAction.Kind.ONLY_B -> "Only in B (new)"
    CompareAction.Kind.ONLY_A -> "Only in A (not in B)"
}

/** What will happen to this file in the new zip, in a few words. */
private fun actionNow(d: CompareAction.Diff, on: Boolean): String = when (d.kind) {
    CompareAction.Kind.CHANGED -> if (on) "Take B's version" else "Keep A's"
    CompareAction.Kind.ONLY_B -> if (on) "Add from B" else "Don't add"
    CompareAction.Kind.ONLY_A -> if (on) "Remove" else "Keep"
}

/** The boxes of "Compare": the second source B, what differs, and the windows to choose what to take. */
@Composable
fun CompareSection(s: OneState, src: ZipSource) {
    val c = s.compare
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadBZip(u)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) s.loadBFolder(u)
    }
    val bs = c.b
    Column {
        GroupHeading("Compare with (B)")
        RowGroup {
            KitRow(
                title = "B: Zip",
                shape = cardShape(0, 2),
                leading = { IconTile(Icons.Filled.Folder, lit = bs != null && !bs.fromFolder) },
                summary = if (bs != null && !bs.fromFolder) bs.name else "Tap to choose",
                description = if (bs != null && !bs.fromFolder) bs.info else "A is the source above, B is the other version",
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "B: Folder",
                shape = cardShape(1, 2),
                leading = { IconTile(Icons.Filled.Folder, lit = bs != null && bs.fromFolder) },
                summary = if (bs != null && bs.fromFolder) bs.name else "Tap to choose",
                description = if (bs != null && bs.fromFolder) bs.info else null,
                onClick = { if (!s.busy) pickFolder.launch(null) },
            )
        }
    }
    if (bs != null) {
        Button(
            onClick = { s.swapWithB() },
            enabled = !s.busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Swap A and B") }
    }
    if (c.compared && c.comparedA === src) {
        val changed = c.diffs.count { it.kind == CompareAction.Kind.CHANGED }
        val onlyB = c.diffs.count { it.kind == CompareAction.Kind.ONLY_B }
        val onlyA = c.diffs.count { it.kind == CompareAction.Kind.ONLY_A }
        Column {
            GroupHeading("What is different")
            if (c.diffs.isEmpty()) {
                TextBox("A and B are the same. ${c.same} files match.")
            } else {
                TextBox(
                    "Different in B: $changed\n" +
                        "Only in B (new): $onlyB\n" +
                        "Only in A (not in B): $onlyA\n" +
                        "Same in both: ${c.same}\n\n" +
                        "Chosen to take from B: ${c.picked.size}",
                )
            }
        }
        if (c.diffs.isNotEmpty()) {
            Button(
                onClick = { c.showReview = true },
                enabled = !s.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Review the differences (${c.diffs.size})") }
        }
    }
    if (c.showReview) ReviewWindow(c, src)
    val d = c.detail
    if (d != null) DetailWindow(c, d)
}

@Composable
private fun ReviewWindow(c: CompareAction, src: ZipSource) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    val rels = remember(c.diffs) { c.diffs.map { it.rel } }
    val found = remember(rels, query) { ZipSearch.filter(rels, query) }
    val shown = remember(c.diffs, found, filter, c.picked) {
        val ok = found.shown.toHashSet()
        c.diffs.filter { d ->
            d.rel in ok && when (filter) {
                1 -> d.kind == CompareAction.Kind.CHANGED
                2 -> d.kind == CompareAction.Kind.ONLY_B
                3 -> d.kind == CompareAction.Kind.ONLY_A
                4 -> d.rel in c.picked
                else -> true
            }
        }
    }
    CardWindow(title = "Differences", onBack = { c.showReview = false }, scroll = false) {
        SearchField(
            query = query,
            label = "Search or paste names (${shown.size} shown, ${c.picked.size} chosen)",
            onQuery = { q ->
                query = q
                if (ZipSearch.isList(q)) {
                    val f = ZipSearch.filter(rels, q)
                    if (f.pick.isNotEmpty()) c.pickAll(f.pick)
                }
            },
            modifier = Modifier.padding(bottom = 6.dp),
        )
        if (found.note.isNotEmpty()) {
            Text(
                found.note,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ChoiceChip("All", filter == 0, onClick = { filter = 0 })
            ChoiceChip("Different", filter == 1, onClick = { filter = 1 })
            ChoiceChip("Only in B", filter == 2, onClick = { filter = 2 })
            ChoiceChip("Only in A", filter == 3, onClick = { filter = 3 })
            ChoiceChip("Chosen", filter == 4, onClick = { filter = 4 })
        }
        if (filter == 3) {
            Text(
                "Choosing a file here leaves it out of the new zip.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = { c.pickAll(shown.map { it.rel }) },
                enabled = shown.isNotEmpty(),
                modifier = Modifier.weight(1f),
            ) { Text("Choose all shown") }
            Button(
                onClick = { c.clear(shown.map { it.rel }) },
                enabled = shown.isNotEmpty(),
                modifier = Modifier.weight(1f),
            ) { Text("Clear shown") }
        }
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(shown, key = { it.rel }) { d ->
                val on = d.rel in c.picked
                val dir = d.rel.substringBeforeLast('/', "")
                KitRow(
                    title = d.rel.substringAfterLast('/'),
                    shape = RoundedCornerShape(14.dp),
                    summary = d.summary,
                    description = kindLabel(d.kind) + (if (dir.isNotEmpty()) " \u00B7 $dir" else ""),
                    background = if (on) MaterialTheme.colorScheme.primaryContainer else rowColor(),
                    onClick = { c.toggle(d.rel) },
                    trailing = { Text(actionNow(d, on), fontSize = 12.sp) },
                    footer = {
                        TextButton(
                            onClick = { c.openDetail(src, d) },
                            modifier = Modifier.padding(start = 6.dp),
                        ) { Text("See what is different") }
                    },
                )
            }
        }
        Button(
            onClick = { c.showReview = false },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Done (${c.picked.size} chosen)") }
    }
}

@Composable
private fun DetailWindow(c: CompareAction, d: CompareAction.Diff) {
    val lines = c.detailLines
    val on = d.rel in c.picked
    val colours = MaterialTheme.colorScheme
    CardWindow(title = d.rel.substringAfterLast('/'), onBack = { c.detail = null }, scroll = false) {
        Text(
            kindLabel(d.kind) + ": " + d.rel,
            style = MaterialTheme.typography.bodySmall,
            color = colours.onSurfaceVariant,
        )
        Text(d.summary, color = colours.primary, modifier = Modifier.padding(top = 2.dp))
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            if (lines == null) {
                Text("Reading...")
            } else {
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(lines) { line ->
                        val colour = when (line.firstOrNull()) {
                            '+' -> Color(0xFF2E9E4F)
                            '-' -> Color(0xFFD64545)
                            '@' -> colours.primary
                            else -> colours.onSurface
                        }
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = colour)
                    }
                }
            }
        }
        Button(
            onClick = { c.toggle(d.rel) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Now: ${actionNow(d, on)}. Tap to change") }
    }
}
