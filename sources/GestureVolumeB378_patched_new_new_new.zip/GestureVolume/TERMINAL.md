# Terminal text (Zip tools > Terminal)

Ali does not receive zip files any more. He receives one block of text, copies it, and pastes it into the
Terminal tab of the Zip tools window. The tab patches his full source zip and saves a new full zip in Downloads.

## What the tab does

1. Source: the zip to patch. With the switch "Keep the new zip as the next source" on (the default, remembered),
   the new zip from every run is kept inside the app and is the source of the next paste. Off: he picks it each time.
2. Paste: the box, or the "Paste from clipboard" button. The text is checked at once (checksums, paths, every
   edit found exactly once) and the Check box says what will be replaced, added and removed, or what is wrong.
3. Run: `ZipBuilder` writes the new zip, `CodeChecks` looks at every new file (empty, placeholder text, brackets),
   `ZipIo.verify` reads the zip back, and only then it is saved in Downloads. The source is never changed.

## Format

    ZIPTERMINAL 1
    NAME GestureVolumeB378.zip
    NOTE a line for the Check box
    @@FILE app/src/main/java/a/a/Foo.kt 1a2b3c4d 12      whole file: crc32 of its text, number of lines [nonl]
    ...the 12 lines...
    @@END
    @@EDIT app/src/main/java/a/a/Big.kt 11112222 33334444   crc32 of the FIND text, crc32 of the WITH text
    @@FIND
    ...exact lines to find (must be in the file exactly once)...
    @@WITH
    ...lines to put there (none = delete the found text)...
    @@END
    @@DELETE app/src/main/java/a/a/Old.kt
    @@DONE 3

- Paths are inside the project (`app/...`, `README.md`). The top folder of the source zip is added by the tab.
- A file text ends with a line break unless the header says `nonl`. FIND and WITH are the lines joined with `\n`
  (add an empty last line to include a final line break).
- The crc32 is of the UTF-8 bytes, 8 lower-case hex digits. A paste that was cut short (no `@@DONE`, no `@@END`),
  has a different number of changes than `@@DONE` says, or whose checksum does not match, is refused.
- No line of any text may start with `@@`. Text files only: UTF-8, LF line ends.
- A path may appear once, except EDIT which may appear several times for one file (applied in order).
- Nothing is guessed by file name: a path must be exact. EDIT and DELETE of a missing file is a PROBLEM.
- A FILE that is identical to the file already in the zip is skipped ("Already the same"), so pasting twice is safe.

## Making the text

`tool/make_terminal.py` writes it (see the top of the script). Always pass `--source` with the zip the text will be
applied to, so every edit is checked here first. Use whole files for small files and EDIT for big ones
(`OverlayController.kt` is over 300 KB): the clipboard and the chat both have size limits.
