#!/usr/bin/env python3
"""Writes the text that is pasted into the Terminal tab of the Zip tools window.

The format is described in TERMINAL.md. Typical use, from the folder that holds GestureVolume/:

  python3 make_terminal.py --files changed --root GestureVolume --name GestureVolumeB378.zip \
      --note "B378: what changed" --source GestureVolumeB377.zip --out terminal.txt

  --files DIR      a folder with the changed files laid out as in the project (DIR/GestureVolume/app/...).
                   Every file in it becomes a whole-file change.
  --root NAME      the project's top folder; it is cut off the paths (paths in the text are inside the project).
  --edits FILE     a JSON list of small changes: [{"path": "app/...kt", "find": "old text", "with": "new text"}].
                   The old text must be in the file exactly once. Use this for big files.
  --delete PATH    remove a file (path inside the project). Can be repeated.
  --name NAME      the name of the new zip. --note TEXT  a line shown in the Check box. Can be repeated.
  --source ZIP     the zip the text will be applied to: every edit and delete is checked against it here.
  --out FILE       where to write the text (default: terminal.txt).

Text files only (UTF-8, LF line endings). Nothing in the text may start a line with @@.
"""
import argparse
import json
import os
import sys
import zipfile
import zlib


def crc(s: str) -> str:
    return "%08x" % (zlib.crc32(s.encode("utf-8")) & 0xFFFFFFFF)


def fail(msg: str):
    sys.exit("ERROR: " + msg)


def check_path(p: str):
    if not p or p.startswith("/") or "\\" in p or " " in p or any(x in ("", "..") for x in p.split("/")):
        fail("not a safe path: %r" % p)


def check_lines(where: str, text: str):
    if "\r" in text:
        fail("%s has CR characters (Windows line ends). Convert it to LF first." % where)
    for n, line in enumerate(text.split("\n"), 1):
        if line.startswith("@@"):
            fail("%s line %d starts with @@, which the terminal text uses for its own lines." % (where, n))


def file_block(path: str, text: str) -> str:
    check_path(path)
    check_lines(path, text)
    nonl = not text.endswith("\n")
    body = text if nonl else text[:-1]
    lines = body.split("\n") if text else []
    head = "@@FILE %s %s %d%s" % (path, crc(text), len(lines), " nonl" if nonl and text else "")
    return "\n".join([head] + lines + ["@@END"])


def edit_block(path: str, find: str, rep: str) -> str:
    check_path(path)
    if not find:
        fail("%s: the text to find is empty" % path)
    check_lines(path + " (find)", find)
    check_lines(path + " (with)", rep)
    head = "@@EDIT %s %s %s" % (path, crc(find), crc(rep))
    return "\n".join([head, "@@FIND"] + find.split("\n") + ["@@WITH"] + (rep.split("\n") if rep != "" else []) + ["@@END"])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--files")
    ap.add_argument("--root", default="")
    ap.add_argument("--edits")
    ap.add_argument("--delete", action="append", default=[])
    ap.add_argument("--name")
    ap.add_argument("--note", action="append", default=[])
    ap.add_argument("--source")
    ap.add_argument("--out", default="terminal.txt")
    a = ap.parse_args()

    root = a.root.strip("/")
    src = None
    src_names = set()
    if a.source:
        src = zipfile.ZipFile(a.source)
        src_names = set(src.namelist())
        tops = {n.split("/")[0] for n in src_names}
        src_root = (tops.pop() + "/") if len(tops) == 1 and all("/" in n for n in src_names) else ""

    def in_source(path: str):
        if src is None:
            return None
        for cand in (src_root + path, path):
            if cand in src_names:
                return cand
        return None

    blocks = []
    if a.files:
        base = os.path.join(a.files, root) if root else a.files
        if not os.path.isdir(base):
            fail("no folder %s" % base)
        for d, _, fs in sorted(os.walk(base)):
            for f in sorted(fs):
                full = os.path.join(d, f)
                rel = os.path.relpath(full, base).replace(os.sep, "/")
                try:
                    text = open(full, "rb").read().decode("utf-8")
                except UnicodeDecodeError:
                    fail("%s is not UTF-8 text; the terminal handles text files only" % rel)
                blocks.append(file_block(rel, text))
    if a.edits:
        for e in json.load(open(a.edits, encoding="utf-8")):
            path, find, rep = e["path"], e["find"], e["with"]
            hit = in_source(path)
            if src is not None:
                if hit is None:
                    fail("%s is not in the source zip" % path)
                cur = src.read(hit).decode("utf-8")
                n = cur.count(find)
                if n != 1:
                    fail("%s: the text to find is in the file %d times, it must be exactly once:\n%s" % (path, n, find[:200]))
            blocks.append(edit_block(path, find, rep))
    for p in a.delete:
        check_path(p)
        if src is not None and in_source(p) is None:
            fail("%s is not in the source zip, so it cannot be deleted" % p)
        blocks.append("@@DELETE " + p)
    if not blocks:
        fail("nothing to do: give --files, --edits or --delete")

    head = ["ZIPTERMINAL 1"]
    if a.name:
        if " " in a.name or "/" in a.name:
            fail("the zip name must not have spaces or slashes")
        head.append("NAME " + a.name)
    for n in a.note:
        head.append("NOTE " + n.replace("\n", " "))
    text = "\n".join(head + blocks + ["@@DONE %d" % len(blocks)]) + "\n"
    open(a.out, "w", encoding="utf-8", newline="\n").write(text)
    print("wrote %s: %d change(s), %.1f KB" % (a.out, len(blocks), len(text.encode("utf-8")) / 1024))


if __name__ == "__main__":
    main()
