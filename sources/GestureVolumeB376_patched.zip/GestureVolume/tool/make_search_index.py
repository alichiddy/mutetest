#!/usr/bin/env python3
"""
Builds app/src/main/assets/search_index.json for the main menu's "Search everything".

Run from the project root:   python3 tool/make_search_index.py

It reads the Kotlin sources, collects every piece of text a person can read in a settings screen
(labels, titles, summaries, info texts, tooltips, button names), works out which screen each one is
on, and writes one list. The app loads that list only while the search is open, so the search costs
no memory the rest of the time. Re-run it whenever screens change.

Each entry:  t = name, i = info text, p = where it is ("Appearance > Content"),
             r = where to go (route / activity / dialog key), s = section it sits in.
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "app/src/main/java/a/a")
RES = os.path.join(ROOT, "app/src/main/res/values/strings.xml")
OUT = os.path.join(ROOT, "app/src/main/assets/search_index.json")

# ---------------------------------------------------------------------------------------------
# Where each file / function lives.  r: "nav:<route>", "act:<class>", "dlg:<key>"
# ---------------------------------------------------------------------------------------------
FILE_SCREENS = [
    # (path prefix relative to SRC, route, screen name)
    ("ui/screens/handler_appearance/", "nav:appearance", "Appearance"),
    ("ui/screens/handler_action/GitHub", "dlg:github", "GitHub build settings"),
    ("ui/screens/handler_action/", "nav:actions", "Actions"),
    ("ui/screens/visibility/", "nav:visibility", "Visibility"),
    ("ui/screens/quick_slider/", "nav:quick_slider", "Quick slider"),
    ("ui/screens/menu/", "nav:long_press_menu", "Long-press menu"),
    ("ui/screens/boost/", "nav:volume_boost", "Volume boost"),
    ("ui/screens/deck/DeckScreen", "nav:deck", "Deck"),
    ("ui/screens/deck/DeckTiles", "nav:deck_tiles", "Deck > Tiles"),
    ("ui/screens/deck/AppShortcuts", "nav:deck_apps", "Deck > Apps"),
    ("ui/screens/deck/QuickDial", "nav:deck_quick_dial", "Deck > Quick dial"),
    ("ui/screens/deck/SearchSettings", "nav:deck_search", "Deck > Search"),
    ("ui/screens/deck/Notes", "nav:notes", "Deck > Notes"),
    ("ui/screens/app_gestures/", "nav:app_gestures", "App gestures"),
    ("ui/screens/permission/", "nav:permissions", "Permissions"),
    ("ui/screens/troubleshoot/", "nav:troubleshoot", "Troubleshoot"),
    ("ui/screens/strip/", "nav:strip_editor", "Cells"),
    ("ui/screens/main/BackupDialog", "dlg:backups", "Backups"),
    ("ui/screens/main/ReportDialog", "dlg:report", "Copy report"),
    ("ui/screens/main/ThemeDialog", "menu:Theme", "Theme"),
    ("ui/screens/main/LanguageDialog", "menu:Language", "Language"),
    ("ui/screens/main/Preset", "dlg:presets", "Quick presets"),
    ("ui/screens/main/", "nav:main", "Main screen"),
    ("ui/screens/shell/", "act:ui.screens.shell.ShellActivity", "Shell runner"),
    ("ui/screens/apps/", "act:ui.screens.apps.AllAppsActivity", "All apps"),
    ("flow/", "act:flow.FlowActivity", "Scripts"),
    ("sides/", "act:sides.SidesActivity", "Side bars"),
    ("download/", "act:download.DownloadsActivity", "Downloads"),
    ("clip/", "act:clip.ClipActivity", "Copy options"),
    ("share/Wifi", "act:share.WifiShareActivity", "Wi-Fi share"),
    ("share/Html", "nav:appearance", "Appearance"),
    ("strip/Launcher", "act:strip.LauncherModeActivity", "Launcher mode"),
    ("strip/Widget", "act:strip.LauncherModeActivity", "Launcher mode"),
    ("strip/QsTiles", "act:strip.LauncherModeActivity", "Launcher mode"),
    ("strip/", "nav:strip_editor", "Cells"),
    ("overlay/deck/", "nav:deck", "Deck"),
    ("auto/", "nav:main", "Main screen"),
]

# Pieces of a file that belong somewhere else than the file says (top-level function name).
FUNC_SCREENS = {
    "GitHubSettingsDialog": ("dlg:github", "GitHub build settings"),
    "GitHubManager": ("dlg:github", "GitHub build settings"),
    "ShizukuGrantRow": ("nav:main", "Main screen"),
}

# Files that only draw other apps / system things, or hold no screen text.
SKIP_FILES = (
    "ui/theme/", "ui/motion/", "ui/view/", "ui/util/", "ui/viewmodels/", "service/", "utils/",
    "data/", "di/", "helper/", "livedata/", "adb/", "S.kt", "GestureApplication.kt",
    "ui/screens/walkthrough/", "ui/components/", "ui/activities/",
    "overlay/OverlayTheme", "overlay/PanelBackdrop", "overlay/PanelEntrance",
    "strip/StripView", "strip/FitText", "strip/IconCache", "strip/FloatBubble", "strip/ScreenCopy",
    "strip/ScreenOcr", "strip/TextReader", "strip/ApkCloner", "strip/ClickCircle", "strip/ReturnGuard",
    "strip/OtpOcr", "strip/StripTip", "strip/EdgeFields", "strip/IconExport",
    "flow/FlowRunner", "flow/Interpreter", "flow/Expr", "flow/FlowGraph", "flow/FlowCanvasView",
    "flow/AutomateImporter", "flow/AutomateFlows", "flow/SeedFlows", "flow/Countdown",
    "flow/RunningNotes",
    "download/DownloadService", "download/DownloadSaver", "download/DownloadStore",
    "share/WifiShareServer", "share/WifiShareService", "share/FilePaths", "share/QrImage",
    "share/PickerProvider",
)

# The screens themselves, with words people use for them.  (name, where, extra words)
SCREENS = [
    ("Appearance", "nav:appearance", "bar handler look colour color width height position icon corners size shape slider percentage"),
    ("Actions", "nav:actions", "gestures tap swipe hold double tap slide in what the bar does timing"),
    ("Cells", "nav:strip_editor", "shortcuts strip folders grid icons order cells window edit pins"),
    ("Scripts", "act:flow.FlowActivity", "automate flows blocks steps automation shell run"),
    ("Launcher mode", "act:strip.LauncherModeActivity", "widgets pinned shortcuts launcher home catch tiles"),
    ("Permissions", "nav:permissions", "overlay accessibility write settings shizuku usage access notification grant"),
    ("Volume boost", "nav:volume_boost", "louder amplify loudness enhancer"),
    ("Deck", "nav:deck", "panel tiles apps quick dial notes search card"),
    ("Quick slider", "nav:quick_slider", "second volume brightness slider panel"),
    ("Long-press menu", "nav:long_press_menu", "hold bar menu items move hide"),
    ("Visibility", "nav:visibility", "hide show keyboard lock screen media calls apps shade"),
    ("Side bars", "act:sides.SidesActivity", "left right segments edge"),
    ("Shell runner", "act:ui.screens.shell.ShellActivity", "terminal commands shizuku adb run"),
    ("Downloads", "act:download.DownloadsActivity", "download manager resume links"),
    ("Copy options", "act:clip.ClipActivity", "clipboard copy digits persian arabic feedback"),
    ("Backups", "dlg:backups", "backup restore export import settings scripts"),
    ("GitHub build settings", "dlg:github", "build apk zip upload workflow actions yml"),
    ("Copy report", "dlg:report", "diagnostic log debug report problem"),
    ("Quick presets", "dlg:presets", "presets history look"),
    ("Wi-Fi share", "act:share.WifiShareActivity", "wifi direct qr code share files server"),
    ("Theme", "menu:Theme", "dark light colour mode"),
    ("Language", "menu:Language", "translate locale"),
    ("Troubleshoot", "nav:troubleshoot", "fix help problems not working"),
    ("Reset app", "menu:Reset", "factory default erase everything"),
    ("All apps", "act:ui.screens.apps.AllAppsActivity", "installed apps hidden system"),
    ("App gestures", "nav:app_gestures", "per app gestures chosen apps"),
    ("Deck tiles", "nav:deck_tiles", "deck tiles"),
    ("Deck apps", "nav:deck_apps", "deck app shortcuts"),
    ("Deck quick dial", "nav:deck_quick_dial", "deck contacts call"),
    ("Deck search settings", "nav:deck_search", "deck search providers"),
    ("Notes", "nav:notes", "deck notes"),
]

# Words that are buttons rather than things to find.
GENERIC = {
    "ok", "cancel", "close", "save", "done", "yes", "no", "back", "copy", "delete", "add", "remove",
    "reset", "apply", "retry", "clear", "edit", "open", "off", "on", "none", "more", "next", "dismiss",
    "confirm", "continue", "skip", "undo", "redo", "refresh", "share", "paste", "select", "all", "default",
    "test", "stop", "start", "show", "hide", "enable", "disable", "choose", "browse", "rename", "install",
    "settings", "menu", "search", "pick", "set", "get", "use", "update", "allow", "deny", "grant",
}

NAMED = r"(?:label|title|summary|description|subtitle|text|tooltip|hint|placeholder|header|body|caption|note|info|desc|sub)"
STR = r'"(?:[^"\\\n]|\\.)*"'
RESREF = r"(?:stringResource|context\.getString|ctx\.getString|getString|LocalContext\.current\.getString)\(\s*R\.string\.(\w+)[^)]*\)"
EXPR = rf"(?:{STR}(?:\s*\+\s*{STR})*|{RESREF})"

named_re = re.compile(rf"\b({NAMED})\s*=\s*({EXPR})")
pos_re = re.compile(
    rf"\b(Text|GroupLabel|SectionTitle|AppearanceSection|HomeLinkRow|HomeToggleRow|SettingSwitchItem|"
    rf"ActionSettingItem|SwitchControl|SliderControl|TextButton|Button|OutlinedButton|FilledTonalButton|"
    rf"DropdownMenuItem|FilterChip|AssistChip|Tab|ChoiceRow|NumberBox)\(\s*({EXPR})"
)
func_re = re.compile(r"^(?:private |internal |public )?(?:@\w+\s+)*fun\s+(?:\w+\.)?(\w+)\s*\(", re.M)
section_fn = re.compile(r"\b(AppearanceSection|GroupLabel|SectionTitle)\(\s*(?:title\s*=\s*)?(" + EXPR + ")")


def load_strings():
    out = {}
    try:
        data = open(RES, encoding="utf-8").read()
    except OSError:
        return out
    for m in re.finditer(r'<string\s+name="(\w+)"[^>]*>(.*?)</string>', data, re.S):
        v = m.group(2)
        v = v.replace("\\'", "'").replace('\\"', '"').replace("\\n", " ").replace("&amp;", "&")
        v = v.replace("&lt;", "<").replace("&gt;", ">")
        v = re.sub(r"<[^>]+>", "", v)
        v = re.sub(r"%\d*\$?[sdf]", " ", v)
        out[m.group(1)] = re.sub(r"\s+", " ", v).strip()
    return out


STRINGS = load_strings()


def unescape(s):
    s = s[1:-1]
    s = s.replace("\\n", " ").replace("\\t", " ").replace('\\"', '"').replace("\\'", "'").replace("\\\\", "\\")
    s = re.sub(r"\\u([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), s)
    s = re.sub(r"\$\{[^}]*\}", " ", s)
    s = re.sub(r"\$\w+", " ", s)
    return s


def resolve(expr):
    expr = expr.strip()
    m = re.fullmatch(RESREF, expr)
    if m:
        return STRINGS.get(m.group(1), "")
    parts = re.findall(STR, expr)
    return "".join(unescape(p) for p in parts)


def clean(s):
    s = re.sub(r"\s+", " ", s).strip()
    return s.rstrip(":").strip()


def usable(s):
    if not re.search(r"[A-Za-z]{3}", s):
        return False
    if any(c in s for c in "{};") or "%%" in s or "( )" in s or re.search(r'["\u201c] ["\u201d]', s):
        return False
    if s.lower().startswith(("loading", "nothing ", "search ")) or s.strip().endswith("..."):
        return False
    if re.fullmatch(r"[a-z]+[A-Z]\w*", s) or re.fullmatch(r"[a-z0-9]+(_[a-z0-9]+)+", s):
        return False  # a preference key
    if s.startswith(("http", "content:", "android.", "/", "#", ".")) or "://" in s:
        return False
    if re.fullmatch(r"[\w./:-]+", s) and not s[0].isupper():
        return False  # a package, a class, a command word
    return True


def screen_for(rel, func):
    if func in FUNC_SCREENS:
        return FUNC_SCREENS[func]
    for prefix in SKIP_FILES:
        if rel.startswith(prefix):
            return None
    for prefix, route, name in FILE_SCREENS:
        if rel.startswith(prefix):
            return route, name
    return None


def main():
    entries = {}
    per_screen = {}
    for dirpath, _, files in os.walk(SRC):
        for fn in sorted(files):
            if not fn.endswith(".kt"):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, SRC).replace(os.sep, "/")
            text = open(full, encoding="utf-8").read()
            funcs = [(m.start(), m.group(1)) for m in func_re.finditer(text)]
            sections = []
            for m in section_fn.finditer(text):
                v = clean(resolve(m.group(2)))
                if v:
                    sections.append((m.start(), v))
            hits = []
            for rx in (named_re, pos_re):
                for m in rx.finditer(text):
                    hits.append((m.start(), m.group(2) if rx is pos_re else m.group(2), m.group(1)))
            hits.sort()
            last = None  # (key, line) of the last name entry, to hang info texts on
            seen_pos = set()
            for pos, expr, kind in hits:
                if pos in seen_pos:
                    continue
                seen_pos.add(pos)
                value = clean(resolve(expr))
                if not value or not usable(value):
                    continue
                func = None
                for fp, fname in funcs:
                    if fp <= pos:
                        func = fname
                    else:
                        break
                sc = screen_for(rel, func)
                if not sc:
                    continue
                route, screen = sc
                section = ""
                for sp, sv in sections:
                    if sp <= pos:
                        section = sv
                    else:
                        break
                line = text.count("\n", 0, pos) + 1
                is_info = len(value) > 64 or kind in ("description", "summary", "subtitle", "body", "info", "desc", "sub", "note", "caption")
                if is_info and last and last["screen"] == screen and last["rel"] == rel and 0 <= line - last["line"] <= 14 and last["t"] != value:
                    old = last["i"]
                    if value not in old:
                        last["i"] = (old + " " + value).strip()[:600]
                    continue
                if not is_info:
                    low = value.lower().strip(" .:…")
                    if low in GENERIC:
                        continue
                    if len(value) > 64:
                        continue
                    t = value
                    info = ""
                else:
                    t = value if len(value) <= 64 else value[:60].rsplit(" ", 1)[0] + "…"
                    info = "" if len(value) <= 64 else value[:600]
                key = (route, t.lower())
                if key in entries:
                    e = entries[key]
                    if info and info not in e["i"]:
                        e["i"] = (e["i"] + " " + info).strip()[:600]
                    last = e
                    continue
                if section.lower() == t.lower():
                    section = ""
                e = {"t": t, "i": info, "p": screen + (" > " + section if section else ""), "r": route,
                     "s": section, "rel": rel, "line": line, "screen": screen}
                entries[key] = e
                last = e
                per_screen[screen] = per_screen.get(screen, 0) + 1

    screen_names = {n.lower() for n, _, _ in SCREENS}
    out = [{"t": n, "i": words, "p": "Screens", "r": route, "s": ""} for n, route, words in SCREENS]
    for e in entries.values():
        if e["t"].lower() in screen_names:
            continue  # the screen is listed above, with its own way there
        out.append({"t": e["t"], "i": e["i"], "p": e["p"], "r": e["r"], "s": e["s"]})
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    print(f"{len(out)} entries -> {os.path.relpath(OUT, ROOT)} ({os.path.getsize(OUT)//1024} KB)")
    for k, v in sorted(per_screen.items(), key=lambda kv: -kv[1]):
        print(f"  {v:5d}  {k}")


if __name__ == "__main__":
    sys.exit(main())
