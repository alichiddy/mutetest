package a.a.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The menu search must find what a person half-remembers: any word order, wifi = wi-fi, typos, plurals, synonyms. */
class SmartSearchTest {
    private val names = listOf(
        "Wi-Fi Mode Toggle",
        "Wi-Fi",
        "Bluetooth: toggle",
        "Flashlight",
        "Open the Cells window from the volume panel",
        "No slider while sound plays",
        "Volume boost",
        "Quick slider",
        "Shortcuts folder",
        "Take a screenshot",
    )
    private val index = SmartSearch.Index(names) { SmartSearch.Doc(it) }
    private fun top(q: String) = index.search(q).firstOrNull()

    @Test fun wifiToggleFindsTheModeToggle() = assertEquals("Wi-Fi Mode Toggle", top("wifi toggle"))
    @Test fun anyWordOrder() = assertEquals("Wi-Fi Mode Toggle", top("toggle wifi"))
    @Test fun splitWifi() = assertEquals("Wi-Fi", top("wi fi"))
    @Test fun beginningsOfWords() = assertEquals("Open the Cells window from the volume panel", top("cells vol pan"))
    @Test fun typos() = assertEquals("Open the Cells window from the volume panel", top("volum panl cells"))
    @Test fun plurals() = assertEquals("Shortcuts folder", top("shortcut folders"))
    @Test fun synonyms() = assertEquals("Flashlight", top("torch"))
    @Test fun oneLetterFindsNothing() = assertTrue(index.search("w").isEmpty())
    @Test fun partialWhenNothingHoldsAll() {
        val r = index.search("bluetooth screenshot")
        assertTrue(r.contains("Bluetooth: toggle") && r.contains("Take a screenshot"))
    }
}
