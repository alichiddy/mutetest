package a.a.strip

import a.a.flow.WhenEvents
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhenRulesTest {
    @Test fun mainBarOnlyByDefault() {
        assertTrue(WhenRules.sourceMatches("", ""))
        assertFalse(WhenRules.sourceMatches("", "k3x9a1"))
    }

    @Test fun sideBarsMatchAnySegmentButNotTheMainBar() {
        assertTrue(WhenRules.sourceMatches(WhenRules.WHERE_SIDE, "k3x9a1"))
        assertFalse(WhenRules.sourceMatches(WhenRules.WHERE_SIDE, ""))
    }

    @Test fun oneSegmentMatchesOnlyItself() {
        assertTrue(WhenRules.sourceMatches("seg:k3x9a1", "k3x9a1"))
        assertFalse(WhenRules.sourceMatches("seg:k3x9a1", "zzzzzz"))
        assertFalse(WhenRules.sourceMatches("seg:k3x9a1", ""))
        assertFalse(WhenRules.sourceMatches("seg:", "k3x9a1"))
    }

    @Test fun anywhereMatchesEveryBar() {
        assertTrue(WhenRules.sourceMatches(WhenRules.WHERE_ANY, ""))
        assertTrue(WhenRules.sourceMatches(WhenRules.WHERE_ANY, "k3x9a1"))
    }

    @Test fun blockFlagsKeepTheBarAndTheOtherFlags() {
        var f = WhenEvents.setFlag("", WhenEvents.FLAG_AGAIN, true)
        f = WhenEvents.setFrom(f, "seg:k3x9a1")
        assertEquals("seg:k3x9a1", WhenEvents.fromOf(f))
        assertTrue(WhenEvents.hasFlag(f, WhenEvents.FLAG_AGAIN))
        f = WhenEvents.setFlag(f, WhenEvents.FLAG_NOOPEN, true)
        assertEquals("seg:k3x9a1", WhenEvents.fromOf(f))
        f = WhenEvents.setFrom(f, "")
        assertEquals("", WhenEvents.fromOf(f))
        assertTrue(WhenEvents.hasFlag(f, WhenEvents.FLAG_AGAIN) && WhenEvents.hasFlag(f, WhenEvents.FLAG_NOOPEN))
    }

    @Test fun oldBlocksWithoutTheFlagListenToTheMainBar() {
        assertEquals("", WhenEvents.fromOf(""))
        assertEquals("", WhenEvents.fromOf("again,lift"))
    }
}
