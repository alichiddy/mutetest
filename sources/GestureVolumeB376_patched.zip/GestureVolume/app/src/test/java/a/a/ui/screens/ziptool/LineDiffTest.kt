package a.a.ui.screens.ziptool

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The smart merger's line-by-line "what is different" view. */
class LineDiffTest {

    private fun lines(vararg s: String) = s.toList()

    @Test
    fun `identical files have no changes`() {
        val r = LineDiff.diff(lines("a", "b"), lines("a", "b"))
        assertTrue(r.sameLines)
        assertEquals(0, r.added)
        assertEquals(0, r.removed)
    }

    @Test
    fun `a changed, an added and a removed line are counted`() {
        val a = (1..20).map { "l$it" }
        val b = a.toMutableList()
        b[4] = "CHANGED"
        b.add(10, "NEW")
        b.removeAt(16)
        val r = LineDiff.diff(a, b)
        assertEquals(2, r.added)
        assertEquals(2, r.removed)
        assertTrue(r.lines.contains("- l5"))
        assertTrue(r.lines.contains("+ CHANGED"))
        assertTrue(r.lines.contains("+ NEW"))
    }

    @Test
    fun `line endings and the last newline do not count as changes`() {
        val r = LineDiff.diff(LineDiff.split("a\r\nb\r\n"), LineDiff.split("a\nb"))
        assertTrue(r.sameLines)
    }

    @Test
    fun `everything is added to or removed from an empty file`() {
        assertEquals(2, LineDiff.diff(emptyList(), lines("x", "y")).added)
        assertEquals(1, LineDiff.diff(lines("x"), emptyList()).removed)
    }

    @Test
    fun `binary data is not treated as text`() {
        assertFalse(LineDiff.looksText(byteArrayOf(1, 2, 0, 3)))
        assertTrue(LineDiff.looksText("hello\nworld".toByteArray()))
    }
}
