package a.a.sides

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SegLandscapeTest {

    @Test
    fun `landscape starts as the portrait place and height`() {
        val g = Seg(topPct = 30, heightPct = 40, posMain = true, shiftPct = 5, linkTo = "L1")
        assertNull(g.land)
        val l = g.landscape()
        assertEquals(30, l.topPct)
        assertEquals(40, l.heightPct)
        assertTrue(l.posMain)
        assertEquals(5, l.shiftPct)
        assertEquals("L1", l.linkTo)
    }

    @Test
    fun `forLandscape uses the landscape place and keeps the width rule`() {
        val g = Seg(topPct = 10, heightPct = 20, sizeAll = true, land = SegLand(50, 25, false, 0, false, ""))
        val v = g.forLandscape()
        assertEquals(50, v.topPct)
        assertEquals(25, v.heightPct)
        assertFalse(v.hMain)
        assertTrue(v.wMain)
    }

    @Test
    fun `forLandscape can follow the main slider height while portrait does not`() {
        val g = Seg(sizeAll = false, heightMain = false, land = SegLand(0, 20, false, 0, true, ""))
        assertFalse(g.hMain)
        assertTrue(g.forLandscape().hMain)
    }
}
