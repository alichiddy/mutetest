package a.a.ui.screens.handler_appearance

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.share.PickerConfig

/*
 * Appearance > what the "A" and "A files" tabs of Android's file picker show.
 * Two boxes, each with a switch (show the tab or not) and an arrow that opens its options.
 * Every change is saved at once; the picker reads it the next time it is opened.
 */

@Composable
fun FilePickerTabsSettings() {
    val ctx = LocalContext.current
    val cfg = remember { PickerConfig(ctx) }
    val changed = { PickerConfig.changed(ctx) }

    TabBox(
        title = "File picker: the \"A\" tab",
        summary = "Photos, and the files and folders of your download folders",
        shown = cfg.aShow,
        onShown = { cfg.aShow = it; changed() },
    ) {
        Opt("Photos from everywhere", cfg.aPhotos) { cfg.aPhotos = it; changed() }
        Opt("Videos from everywhere", cfg.aVideos) { cfg.aVideos = it; changed() }
        Opt("Audio from everywhere", cfg.aAudio) { cfg.aAudio = it; changed() }
        Opt("Files lying directly in the download folders", cfg.aFiles) { cfg.aFiles = it; changed() }
        Opt("Folders inside the download folders, shown as folders", cfg.aFolders) { cfg.aFolders = it; changed() }
        Opt("Also list photos, videos and audio that are inside those folders", cfg.aMediaInFolders) { cfg.aMediaInFolders = it; changed() }
        Opt("Show hidden files and folders (names starting with a dot)", cfg.aHidden) { cfg.aHidden = it; changed() }
        Note("Off for the last two keeps a folder of many files (for example a decompiled app) to one line.")

        Heading("Only items changed in the last")
        Choices(
            listOf("Any time" to 0, "1 day" to 1, "7 days" to 7, "30 days" to 30, "1 year" to 365),
            cfg.aDays,
        ) { cfg.aDays = it; changed() }

        Heading("Most items listed")
        Choices(listOf("100" to 100, "300" to 300, "1000" to 1000, "3000" to 3000), cfg.aMax) { cfg.aMax = it; changed() }

        Heading("Download folders (listed like Download)")
        TextSetting(cfg.aDirsText, "Folders, separated by commas") { cfg.aDirsText = it; changed() }
        Note("Paths under the phone's storage, for example: Download, Documents, Telegram. Leave Download for the usual one.")

        Heading("Opens in")
        StartFolder(
            current = cfg.aStart,
            firstLabel = "Photos and downloads list",
            hint = "Another folder (for example Download/Apps)",
        ) { cfg.aStart = it; changed() }
        Note("Photos and downloads list is the usual view. Any folder opens that folder's real contents instead, which are then filtered by the \"A files\" options below.")
    }

    TabBox(
        title = "File picker: the \"A files\" tab",
        summary = "Every file on the phone, folder by folder",
        shown = cfg.fShow,
        onShown = { cfg.fShow = it; changed() },
    ) {
        Opt("Photos", cfg.fPhotos) { cfg.fPhotos = it; changed() }
        Opt("Videos", cfg.fVideos) { cfg.fVideos = it; changed() }
        Opt("Audio", cfg.fAudio) { cfg.fAudio = it; changed() }
        Opt("Documents (PDF, text, Office, HTML)", cfg.fDocs) { cfg.fDocs = it; changed() }
        Opt("Archives and apps (zip, rar, 7z, apk)", cfg.fArchives) { cfg.fArchives = it; changed() }
        Opt("Other files", cfg.fOther) { cfg.fOther = it; changed() }
        Opt("Folders", cfg.fFolders) { cfg.fFolders = it; changed() }
        Opt("Show hidden files and folders (names starting with a dot)", cfg.fHidden) { cfg.fHidden = it; changed() }
        Note("Turning off Folders leaves only the files of the folder it opens in. A kind turned off is also hidden from apps that were given a folder through A's folder picker.")

        Heading("Opens in")
        StartFolder(
            current = cfg.fStart,
            firstLabel = "Phone storage",
            hint = "Another folder (for example Download/Apps)",
            storageButton = false,
        ) { cfg.fStart = it; changed() }
    }
}

/** A box with a title, a switch for showing the tab at all, and an arrow that opens its options. */
@Composable
private fun TabBox(
    title: String,
    summary: String,
    shown: Boolean,
    onShown: (Boolean) -> Unit,
    content: @Composable () -> Unit,
) {
    var open by rememberSaveable(title) { mutableStateOf(false) }
    var on by remember { mutableStateOf(shown) }
    HorizontalDivider(Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
    Row(
        Modifier.fillMaxWidth().clickable { open = !open },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(
                if (on) summary else "Hidden from the picker",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = on, onCheckedChange = { on = it; onShown(it) }, modifier = Modifier.padding(horizontal = 8.dp))
        IconButton(onClick = { open = !open }) {
            Icon(
                if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (open) "Hide the options" else "Show the options",
            )
        }
    }
    AnimatedVisibility(visible = open, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
        Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) { content() }
    }
}

@Composable
private fun Opt(label: String, initial: Boolean, set: (Boolean) -> Unit) {
    var on by remember { mutableStateOf(initial) }
    SwitchControl(label = label, checked = on, borderColor = MaterialTheme.colorScheme.primary) { on = it; set(it) }
}

@Composable
private fun Note(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 16.sp)
}

@Composable
private fun Heading(text: String) {
    Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(top = 10.dp))
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun Choices(options: List<Pair<String, Int>>, initial: Int, set: (Int) -> Unit) {
    var now by remember { mutableStateOf(initial) }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, v) ->
            FilterChip(selected = now == v, onClick = { now = v; set(v) }, label = { Text(label) })
        }
    }
}

@Composable
private fun TextSetting(initial: String, label: String, set: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    OutlinedTextField(
        value = text, onValueChange = { text = it; set(it) }, singleLine = true,
        label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
    )
}

/** Folder buttons plus a box for any other folder. An empty choice means the tab's usual first view. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun StartFolder(current: String, firstLabel: String, hint: String, storageButton: Boolean = true, set: (String) -> Unit) {
    var now by remember { mutableStateOf(current) }
    var box by remember { mutableStateOf(current) }
    val presets = listOf(
        firstLabel to "", (if (storageButton) "Phone storage" else firstLabel) to ".", "Download" to "Download", "DCIM" to "DCIM", "Pictures" to "Pictures",
        "Documents" to "Documents", "Movies" to "Movies", "Music" to "Music",
    ).distinctBy { it.second }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        presets.forEach { (label, path) ->
            FilterChip(
                selected = now == path,
                onClick = { now = path; box = path; set(path) },
                label = { Text(label) },
            )
        }
    }
    OutlinedTextField(
        value = box, singleLine = true, label = { Text(hint) }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        onValueChange = { box = it; now = it.trim(); set(it.trim()) },
    )
}
