package a.a.ui.screens.ziptool

import android.content.Context
import java.io.File

/**
 * What one action wants done to a zip, in the three ways [ZipIo.rewrite] understands: files to [replace] (new
 * content), files to [remove], and new files to [add]. Every tool of the Zip tools window only fills this in;
 * [ZipBuilder] then does the same work for all of them.
 *
 * [summary] is the text of the Check box. Every line of [problems] blocks the button, [warnings] only inform.
 * [finish] is called by the builder when it is done (also after an error), for an action that keeps something
 * open for its [ZipIo.Blob]s, such as a second zip.
 */
class ZipPlan(
    val replace: Map<String, ZipIo.Blob>,
    val remove: Set<String>,
    val add: List<Pair<String, ZipIo.Blob>>,
    val summary: String,
    val problems: List<String>,
    val warnings: List<String>,
    val finish: () -> Unit = {},
) {
    /** True when nothing would change. */
    val isEmpty: Boolean get() = replace.isEmpty() && remove.isEmpty() && add.isEmpty()

    /** The button may be pressed: something changes and nothing blocks it. */
    val canBuild: Boolean get() = problems.isEmpty() && !isEmpty

    /** The Check box text: the summary, then a PROBLEM line for each problem, then a WARNING line for each warning. */
    fun checkText(): String {
        val lines = ArrayList<String>()
        if (summary.isNotEmpty()) lines.add(summary)
        for (p in problems) lines.add("PROBLEM: $p")
        for (w in warnings) lines.add("WARNING: $w")
        return lines.joinToString("\n")
    }

    companion object {
        /**
         * Joins the plans of several ticked actions (each with the name it is shown under) into one. When two
         * actions touch the same path the result has a problem line "path is changed by A and B".
         */
        fun combine(parts: List<Pair<String, ZipPlan>>): ZipPlan {
            val replace = LinkedHashMap<String, ZipIo.Blob>()
            val remove = LinkedHashSet<String>()
            val add = ArrayList<Pair<String, ZipIo.Blob>>()
            val owner = HashMap<String, String>()
            val problems = ArrayList<String>()
            val warnings = ArrayList<String>()
            val summary = ArrayList<String>()
            val finishers = ArrayList<() -> Unit>()
            for ((label, p) in parts) {
                for ((path, blob) in p.replace) {
                    if (claim(owner, problems, path, label)) replace[path] = blob
                }
                for (path in p.remove) {
                    if (claim(owner, problems, path, label)) remove.add(path)
                }
                for ((path, blob) in p.add) {
                    if (claim(owner, problems, path, label)) add.add(path to blob)
                }
                problems.addAll(p.problems)
                warnings.addAll(p.warnings)
                if (p.summary.isNotEmpty()) summary.add(p.summary)
                finishers.add(p.finish)
            }
            return ZipPlan(
                replace, remove, add,
                summary.joinToString("\n"), problems, warnings,
                { for (f in finishers) f() },
            )
        }

        private fun claim(owner: MutableMap<String, String>, problems: MutableList<String>, path: String, label: String): Boolean {
            val other = owner[path]
            if (other != null && other != label) {
                problems.add("$path is changed by $other and $label")
                return false
            }
            owner[path] = label
            return true
        }
    }
}

/** One box of the "What to do" section: looks at the source and says what it would do. Must not change anything. */
interface ZipAction {
    fun plan(src: ZipSource): ZipPlan
}

/**
 * The one builder: checks the new files, writes the new zip with [ZipIo.rewrite], reads it back with
 * [ZipIo.verify], and only then saves it in Downloads. The source is never changed. Blocks: run it on a worker thread.
 */
object ZipBuilder {
    /** [saved] is true when the zip is in Downloads. [text] goes into the Result box. */
    class Built(val saved: Boolean, val text: String)

    private const val SHOW = 60

    fun build(
        ctx: Context,
        src: ZipSource,
        plan: ZipPlan,
        saveName: String,
        tmp: File,
        status: (String) -> Unit = {},
    ): Built {
        if (!plan.canBuild) return Built(false, "ZIP ERROR: fix what the Check box shows first.\nNothing was saved.")
        val name = ZipIo.cleanName(saveName, ZipIo.stem(src.name) + "_new")
        return try {
            status("Checking the new files...")
            val chk = Inspect()
            for ((path, blob) in plan.replace) chk.file(path, blob)
            for ((path, blob) in plan.add) chk.file(path, blob)
            if (chk.problems.isNotEmpty()) {
                throw IllegalStateException("A new file was not accepted:\n" + chk.problems.joinToString("\n") { " - $it" })
            }
            status("Building the new zip...")
            val out = ZipIo.rewrite(src.file, tmp, plan.replace, plan.remove, plan.add)
            if (out.replaced != plan.replace.size) {
                throw IllegalStateException("Only ${out.replaced} of ${plan.replace.size} files to replace were found in the zip.")
            }
            if (out.removed != plan.remove.size) {
                throw IllegalStateException("Only ${out.removed} of ${plan.remove.size} files to remove were found in the zip.")
            }
            if (out.added != plan.add.size) {
                throw IllegalStateException("Only ${out.added} of ${plan.add.size} new files were added.")
            }
            val sb = StringBuilder()
            section(sb, "REPLACED", plan.replace.keys, src)
            section(sb, "ADDED", plan.add.map { it.first }, src)
            section(sb, "REMOVED", plan.remove, src)
            if (out.skipped > 0) sb.append("Note: ${out.skipped} repeated file name(s) in the zip were left out.\n")
            if (chk.warnings.isNotEmpty()) {
                for (w in chk.warnings) sb.append("WARNING brackets: $w\n")
            } else if (chk.codeChecked > 0) {
                sb.append("Brackets: ${chk.codeChecked} code file(s) balanced.\n")
            }
            status("Checking the zip...")
            val problem = ZipIo.verify(tmp, out.written, out.expectCrc)
            if (problem != null) {
                sb.append("ZIP ERROR: $problem\nNothing was saved.")
                Built(false, sb.toString())
            } else {
                val where = ZipIo.saveToDownloads(ctx, tmp, name)
                sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                sb.append("Read back and checked. ${out.written} entries. ${src.name} was not changed.")
                Built(true, sb.toString())
            }
        } catch (e: Throwable) {
            Built(false, "ZIP ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved.")
        } finally {
            tmp.delete()
            runCatching { plan.finish() }
        }
    }

    /** A heading and the paths under it, without the top folder, at most [SHOW] of them. */
    private fun section(sb: StringBuilder, title: String, names: Collection<String>, src: ZipSource) {
        if (names.isEmpty()) return
        val sorted = names.sorted()
        sb.append("$title ${sorted.size} file(s):\n")
        for ((i, n) in sorted.withIndex()) {
            if (i >= SHOW) {
                sb.append(" ...and ${sorted.size - SHOW} more\n")
                break
            }
            sb.append(" - ").append(src.shown(n)).append('\n')
        }
    }

    /**
     * The checks on every new or changed file, as Patch does today: an empty file, a placeholder line instead of
     * real code (both block), and unbalanced brackets in .kt and .java files (a warning).
     */
    private class Inspect {
        val problems = ArrayList<String>()
        val warnings = ArrayList<String>()
        var codeChecked = 0

        fun file(path: String, blob: ZipIo.Blob) {
            val leaf = path.substringAfterLast('/')
            val ext = leaf.substringAfterLast('.', "").lowercase()
            if (ext in CodeChecks.TEXT_EXT) {
                val b = blob.bytes ?: blob.open().use { it.readBytes() }
                if (b.isEmpty()) {
                    problems.add("$leaf: the new file is empty.")
                    return
                }
                val text = String(b, Charsets.UTF_8)
                val hit = CodeChecks.placeholderHit(text)
                if (hit != null) {
                    problems.add("$leaf line ${hit.first}: ${hit.second}")
                } else if (ext == "kt" || ext == "java") {
                    codeChecked++
                    val note = CodeChecks.bracketNote(text)
                    if (note != null) warnings.add("$leaf: $note")
                }
            } else {
                val empty = blob.bytes?.isEmpty() ?: blob.open().use { it.read() < 0 }
                if (empty) problems.add("$leaf: the new file is empty.")
            }
        }
    }
}
