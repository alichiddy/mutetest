package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * A zip or a folder that was picked, ready to work on. A folder is packed into a zip in the cache first, so
 * every tool sees "just a zip". [file] is that cache copy (never the picked file itself), [entries] lists the
 * files inside it (not folders), [root] is the top folder ("Project/") or "" when there is none.
 */
class ZipSource(
    val file: File,
    val name: String,
    val entries: List<String>,
    val root: String,
    val fromFolder: Boolean,
    val folders: Int = 0,
    val bytes: Long = 0L,
) {
    /** The line shown under the name: "zip, 12 files" or "folder, 12 files, 3 folders, 1.50 MB". */
    val info: String
        get() = if (fromFolder) {
            "folder, ${entries.size} files, $folders folders, ${ZipIo.size(bytes)}"
        } else {
            "zip, ${entries.size} files"
        }

    /** A path as it is shown to Ali: without the top folder. */
    fun shown(path: String): String = path.removePrefix(root)

    /** Deletes the cache copy. The picked zip or folder is not touched. */
    fun discard() {
        file.delete()
    }
}

/** Turns a picked zip or folder into a [ZipSource]. Both functions block: run them on a worker thread. */
object ZipSources {

    /** Copies the picked zip into the cache at [dest] and lists it. A failed pick leaves the old [dest] alone. */
    fun fromZip(ctx: Context, uri: Uri, dest: File): ZipSource {
        val name = ZipIo.nameOf(ctx.contentResolver, uri)
        val part = partOf(dest)
        try {
            ZipIo.copyToCache(ctx.contentResolver, uri, part)
            val names = try {
                ZipIo.listFiles(part)
            } catch (e: Exception) {
                throw IllegalStateException("$name could not be opened as a zip (${e.message ?: e.javaClass.simpleName}).")
            }
            if (names.isEmpty()) throw IllegalStateException("$name has no files in it.")
            install(part, dest)
            return ZipSource(dest, name, names, ZipIo.rootOf(names), false)
        } finally {
            part.delete()
        }
    }

    /**
     * Reads the picked folder and packs it into a zip in the cache at [dest] (quickest compression, it is only
     * read back). With [keepName] every path starts with the folder's own name, as in a project zip.
     * [status] gets the progress text. A failed pick leaves the old [dest] alone.
     */
    fun fromFolder(
        ctx: Context,
        tree: Uri,
        dest: File,
        keepName: Boolean = true,
        status: (String) -> Unit = {},
    ): ZipSource {
        val part = partOf(dest)
        try {
            status("Reading the folder...")
            val sc = FolderZip.scan(ctx, tree)
            if (sc.fileCount == 0) throw IllegalStateException("The folder has no files in it.")
            val prefix = if (keepName) sc.rootName + "/" else ""
            FolderZip.pack(ctx, sc, part, prefix, fast = true) { done, total ->
                status("Reading the folder: $done of $total...")
            }
            val names = ZipIo.listFiles(part)
            install(part, dest)
            return ZipSource(dest, sc.rootName, names, ZipIo.rootOf(names), true, sc.folderCount, sc.bytes)
        } finally {
            part.delete()
        }
    }

    private fun partOf(dest: File): File = File(dest.parentFile, dest.name + ".part")

    /** A finished temporary file takes the place of the old one only once it is complete. */
    private fun install(tmp: File, dest: File) {
        if (!tmp.renameTo(dest)) {
            dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("Could not keep the file in the app's cache.")
        }
    }
}
