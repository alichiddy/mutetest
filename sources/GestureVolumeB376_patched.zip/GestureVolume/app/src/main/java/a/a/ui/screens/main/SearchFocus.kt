package a.a.ui.screens.main

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import a.a.utils.SmartSearch
import kotlinx.coroutines.delay

/**
 * What a tapped search result asks the next screen to show: the section to open and the setting to
 * scroll to and flash. Nothing is kept once it was shown (or after a few seconds), so it costs nothing.
 */
object SearchFocus {
    private var name = ""
    private var section = ""
    private var until = 0L

    private fun key(s: String) = SmartSearch.tokenize(s).joinToString("")

    fun set(title: String, section: String) {
        name = key(title)
        this.section = key(section)
        until = System.currentTimeMillis() + 8000
    }

    fun clear() { name = ""; section = ""; until = 0L }

    private fun live() = name.isNotEmpty() && System.currentTimeMillis() < until

    /** True when a section with this title should open itself. */
    fun wantsSection(title: String) = live() && section.isNotEmpty() && key(title) == section

    fun wantsItem(label: String) = live() && key(label) == name
}

/** Scrolls this setting into view and flashes it when a search result pointed at it. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.searchTarget(label: String): Modifier = composed {
    val mine = SearchFocus.wantsItem(label)
    val request = remember { BringIntoViewRequester() }
    val flash = remember { Animatable(0f) }
    if (mine) {
        LaunchedEffect(Unit) {
            delay(450)
            runCatching { request.bringIntoView() }
            repeat(3) {
                flash.animateTo(1f, tween(260))
                flash.animateTo(0f, tween(260))
            }
            SearchFocus.clear()
        }
    }
    val colour = MaterialTheme.colorScheme.primary
    this
        .bringIntoViewRequester(request)
        .drawBehind { if (flash.value > 0f) drawRect(colour.copy(alpha = 0.28f * flash.value)) }
}
