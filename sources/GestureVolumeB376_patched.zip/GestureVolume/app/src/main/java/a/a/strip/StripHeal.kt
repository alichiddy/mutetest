package a.a.strip

import android.content.Context
import android.content.Intent
import a.a.utils.AppStarter
import a.a.utils.DiagLog

/**
 * Writes a repaired app shortcut over the broken one, so it is repaired once and not on every run.
 * [AppStarter] finds the current form of a shortcut that no longer fits the installed app; this
 * puts it where the old one was saved: the cells of the main window and of every segment's own
 * window (folders too), and any plain gesture or edge action that holds exactly that shortcut.
 * Runs only right after a repair.
 */
object StripHeal {

    /** Call after a successful start of [oldAction] (the saved text, "Intent:..."): saves the repair, if there was one. */
    fun saveIfHealed(context: Context, oldAction: String) {
        val fix = AppStarter.lastHealed ?: return
        AppStarter.clearHealed()
        val new = "Intent:" + AppStarter.save(fix)
        if (new == oldAction) return
        val n = replace(context, oldAction, new)
        DiagLog.persist(context, "shortcut repair saved over the broken one in $n place(s)")
    }

    /** Replaces action [old] by [new] wherever it is saved; returns how many places changed. */
    fun replace(context: Context, old: String, new: String): Int {
        var n = 0
        fun fix(items: List<StripItem>): List<StripItem> = items.map { item ->
            val kids = item.children?.let { fix(it) }
            val action = if (item.action == old) { n++; new } else item.action
            item.copy(action = action, children = kids)
        }
        val windows = listOf(StripScope.MAIN) + StripScope.ownWindowIds(context).map { it.first }
        for (id in windows) {
            val before = n
            val cfg = StripScope.load(context, id)
            val items = fix(cfg.items)
            if (n > before) StripScope.save(context, id, cfg.copy(items = items))
        }
        // Gestures and edge actions are plain text settings; an outside action may carry the touch prefix.
        val prefs = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val edit = prefs.edit()
        var changed = false
        for ((k, v) in prefs.all) {
            if (v !is String || StripConfig.bare(v) != old) continue
            edit.putString(k, if (StripConfig.isTouch(v)) StripConfig.TOUCH_PREFIX + new else new)
            n++; changed = true
        }
        if (changed) edit.apply()
        return n
    }
}
