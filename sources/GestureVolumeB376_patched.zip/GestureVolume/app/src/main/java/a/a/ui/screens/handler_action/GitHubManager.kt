package a.a.ui.screens.handler_action

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import a.a.ui.components.CardWindow
import a.a.ui.components.ChoiceChip
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.ChipsCardRow
import a.a.ui.screens.strip.LinkRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.data.local.SharedPref
import a.a.utils.GitHubApi
import a.a.utils.GitHubBuild
import java.io.File

private val uiHandler = Handler(Looper.getMainLooper())
private fun bg(block: () -> Unit) { Thread { block() }.start() }
private fun post(block: () -> Unit) { uiHandler.post(block) }
private fun toast(c: Context, t: String) { Toast.makeText(c, t, Toast.LENGTH_LONG).show() }

private fun displayName(context: Context, uri: Uri): String? = runCatching {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
}.getOrNull()

/** Sizes: bytes below 1 KB (so an empty file reads "0 bytes", not a doubtful "0 KB"), then KB, then MB. */
private fun kb(bytes: Long) = when {
    bytes >= 1024 * 1024 -> "%.1f MB".format(bytes / 1048576.0)
    bytes >= 1024 -> "${bytes / 1024} KB"
    else -> "$bytes bytes"
}

private fun fileTime(f: File): String =
    java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date(f.lastModified()))

/** The "are you sure" question of the manager: the text in a card, Cancel and the confirming button under it. */
@Composable
private fun GhConfirm(title: String, text: String, confirm: String, enabled: Boolean = true, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    CardWindow(title = title, onBack = onDismiss) {
        Text(
            text, fontSize = 14.sp,
            modifier = Modifier.padding(top = 12.dp).fillMaxWidth().clip(cardShape(0, 1)).background(rowColor()).padding(16.dp),
        )
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            a.a.ui.motion.OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
            a.a.ui.motion.Button(onClick = onConfirm, enabled = enabled, modifier = Modifier.weight(1f)) { Text(confirm) }
        }
    }
}

/** The name a workflow file must have in .github/workflows, from the name of the file on the phone. */
private fun workflowName(fileName: String): String =
    GitHubBuild.workflowFileFor(fileName)

/**
 * One window for everything on GitHub besides starting builds: browse the repository and download,
 * replace or delete any file in it (workflow ymls included), see and download what the releases
 * hold, and take single files (build.gradle.kts, say) out of the zips on the phone.
 * The token and repository are the ones saved in GitHub build settings.
 */
@Composable
internal fun GitHubManagerDialog(preference: SharedPref, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val token = preference.getGhToken()
    val repo = preference.getGhRepo()
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Repo files", "Releases", "My zips")
    CardWindow(title = "GitHub manager", onBack = onDismiss) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tabs.forEachIndexed { i, t -> ChoiceChip(t, tab == i, { tab = i }) }
        }
        Text(repo, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (token.isEmpty()) Text("Set your GitHub token first (GitHub build settings), then open this again.")
            else when (tab) {
                0 -> RepoTab(context, preference, token, repo)
                1 -> ReleasesTab(context, token, repo)
                else -> ZipsTab(context, preference, token, repo)
            }
        }
    }
}

@Composable
private fun RepoTab(context: Context, preference: SharedPref, token: String, repo: String) {
    var path by remember { mutableStateOf("") }
    var entries by remember { mutableStateOf<List<GitHubApi.Entry>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var askDelete by remember { mutableStateOf<GitHubApi.Entry?>(null) }
    var askDeleteAll by remember { mutableStateOf(false) }
    var byDate by remember { mutableStateOf(false) }
    val picked = remember { androidx.compose.runtime.mutableStateMapOf<String, Boolean>() }
    // When each file or folder last changed, filled in by a few background requests after the list shows.
    val dates = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }

    fun load(p: String) {
        msg = "Reading…"
        bg {
            val r = runCatching { GitHubApi.listDir(token, repo, p) }
            post {
                r.onSuccess { list ->
                    entries = list; path = p; picked.clear(); msg = if (list.isEmpty()) "Empty folder." else ""
                    val todo = java.util.concurrent.ConcurrentLinkedQueue(list.filter { it.path !in dates })
                    repeat(4) {
                        bg {
                            while (true) {
                                val e = todo.poll() ?: break
                                val t = GitHubApi.lastModified(token, repo, e.path)
                                post { dates[e.path] = t }
                            }
                        }
                    }
                }.onFailure { msg = GitHubBuild.explain(it) }
            }
        }
    }
    LaunchedEffect(Unit) { load("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val dir = path
            msg = "Uploading…"
            bg {
                val r = runCatching {
                    val name = displayName(context, uri) ?: error("That file has no name.")
                    val bytes = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    GitHubApi.putFile(token, repo, (if (dir.isEmpty()) "" else "$dir/") + name, bytes, "Upload $name from phone")
                }
                post {
                    r.onSuccess { toast(context, it); load(dir) }.onFailure { msg = GitHubBuild.explain(it) }
                }
            }
        }
    }

    val fileList = entries.filter { !it.dir }
    val nPicked = fileList.count { picked[it.path] == true }
    val shownEntries = if (!byDate) entries else entries.sortedWith(
        compareBy<GitHubApi.Entry> { !it.dir }.thenByDescending { dates[it.path].orEmpty() }.thenBy { it.name.lowercase() }
    )

    CardGroup("Folder") {
        row { sh ->
            SettingRow(
                title = "Folder: /$path", shape = sh, icon = Icons.Filled.Folder,
                summary = if (msg.isEmpty()) null else msg,
            )
        }
        row { sh ->
            ChipsCardRow(
                title = "Go to",
                options = listOf("Root" to (path == ""), ".github/workflows" to (path == ".github/workflows"), "sources" to (path == "sources")),
                shape = sh,
                onToggle = { n -> load(when (n) { 0 -> ""; 1 -> ".github/workflows"; else -> "sources" }) },
            )
        }
        if (path.isNotEmpty()) {
            row { sh ->
                LinkRow("Up one folder", "/" + path.substringBeforeLast('/', ""), sh, icon = Icons.Filled.ArrowUpward) {
                    load(path.substringBeforeLast('/', ""))
                }
            }
        }
        row { sh -> LinkRow("Refresh", "Read this folder again", sh, icon = Icons.Filled.Refresh) { load(path) } }
        row { sh ->
            ChipsCardRow(
                title = "Sort by",
                options = listOf("Name" to !byDate, "Date modified" to byDate),
                shape = sh,
                onToggle = { n -> byDate = (n == 1) },
            )
        }
    }

    CardGroup("Pick and send") {
        row { sh ->
            val allPicked = fileList.isNotEmpty() && nPicked == fileList.size
            SettingRow(
                title = if (allPicked) "Select none" else "Select all", shape = sh,
                icon = Icons.Filled.CheckCircle, lit = nPicked > 0,
                summary = "$nPicked of ${fileList.size} files ticked",
                onClick = {
                    val on = nPicked < fileList.size
                    for (f in fileList) picked[f.path] = on
                },
            )
        }
        row { sh ->
            SettingRow(
                title = "Delete selected ($nPicked)", shape = sh, icon = Icons.Filled.Delete,
                summary = if (nPicked > 0) "Removes the ticked files from the repository" else "Tick files in the list first",
                onClick = if (nPicked > 0) ({ askDeleteAll = true }) else null,
            )
        }
        row { sh ->
            LinkRow("Upload a file here", "Into /$path", sh, icon = Icons.Filled.CloudUpload) { picker.launch(arrayOf("*/*")) }
        }
    }

    CardGroup("In this folder (${entries.size})") {
        for (e in shownEntries) {
            row { sh ->
                val whenText = dates[e.path].orEmpty().ifEmpty { "…" }
                if (e.dir) {
                    SettingRow(
                        title = e.name, shape = sh, icon = Icons.Filled.Folder,
                        summary = "Folder · $whenText",
                        onClick = { load(e.path) },
                        trailing = { a.a.ui.components.Chevron() },
                    )
                } else {
                    SettingRow(
                        title = e.name, shape = sh, icon = Icons.Filled.Description,
                        lit = picked[e.path] == true,
                        summary = "${kb(e.size)} · $whenText",
                        onClick = { picked[e.path] = picked[e.path] != true },
                        trailing = { androidx.compose.material3.Checkbox(checked = picked[e.path] == true, onCheckedChange = null) },
                        footer = {
                            Row(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 4.dp)) {
                                TextButton(onClick = {
                                    bg {
                                        val r = runCatching { GitHubApi.downloadRepoFile(context, token, repo, e.path, e.name) }
                                        post { toast(context, r.map { "Saved to Downloads: $it" }.getOrElse { GitHubBuild.explain(it) }) }
                                    }
                                }) { Text("Download") }
                                TextButton(onClick = { askDelete = e }) { Text("Delete") }
                            }
                        },
                    )
                }
            }
        }
    }

    CardGroup("Workflow files") {
        row { sh ->
            SettingRow(
                title = "Put my ticked ymls into .github/workflows", shape = sh, icon = Icons.Filled.CloudUpload,
                summary = "Replaces the workflow files in the repository with the ticked yml files from GitHub build settings.",
                info = "The token needs the Workflows permission for it.",
                onClick = {
                    val ymls = preference.getGhFiles("yml").filter { it.on && it.path.isNotBlank() }
                    msg = "Sending the ticked workflow files…"
                    bg {
                        val out = StringBuilder()
                        for (f in ymls) {
                            val file = GitHubBuild.newest(File(f.path))
                            if (file == null) { out.append("Not found: ${File(f.path).name}\n"); continue }
                            val target = workflowName(file.name)
                            val r = runCatching { GitHubApi.putFile(token, repo, ".github/workflows/$target", file.readBytes(), "Update $target from phone") }
                            out.append(r.getOrElse { "$target: " + GitHubBuild.explain(it) }).append('\n')
                        }
                        if (ymls.isEmpty()) out.append("No workflow yml is ticked in GitHub build settings.")
                        post { msg = out.toString().trim(); toast(context, msg); load(".github/workflows") }
                    }
                },
                trailing = { a.a.ui.components.Chevron() },
            )
        }
    }

    if (askDeleteAll) {
        val files = entries.filter { !it.dir && picked[it.path] == true }
        GhConfirm(
            title = "Delete the selected files?",
            text = if (files.isEmpty()) "No file is selected in /$path (folders are never deleted)."
            else "${files.size} files in /$path are removed from the repository (folders are left alone):\n\n" + files.joinToString("\n") { it.name },
            confirm = "Delete selected",
            enabled = files.isNotEmpty(),
            onDismiss = { askDeleteAll = false },
            onConfirm = {
                askDeleteAll = false
                msg = "Deleting ${files.size} files…"
                val dir = path
                bg {
                    var done = 0
                    var fail = ""
                    for (f in files) {
                        val r = runCatching { GitHubApi.deleteFile(token, repo, f.path, f.sha) }
                        if (r.isSuccess) done++ else { fail = GitHubBuild.explain(r.exceptionOrNull()!!); break }
                    }
                    post { toast(context, "Deleted $done of ${files.size}" + if (fail.isEmpty()) "" else ". $fail"); load(dir) }
                }
            },
        )
    }

    askDelete?.let { e ->
        GhConfirm(
            title = "Delete ${e.name}?",
            text = "It is removed from the repository (${e.path}).",
            confirm = "Delete",
            onDismiss = { askDelete = null },
            onConfirm = {
                askDelete = null
                bg {
                    val r = runCatching { GitHubApi.deleteFile(token, repo, e.path, e.sha) }
                    post { toast(context, r.getOrElse { GitHubBuild.explain(it) }); load(path) }
                }
            },
        )
    }
}

@Composable
private fun ReleasesTab(context: Context, token: String, repo: String) {
    var rels by remember { mutableStateOf<List<GitHubApi.Rel>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var byDate by remember { mutableStateOf(true) }
    var askDeleteAll by remember { mutableStateOf(false) }
    val picked = remember { androidx.compose.runtime.mutableStateMapOf<Long, Boolean>() }
    var pickTarget by remember { mutableStateOf<Uri?>(null) }

    fun load() {
        msg = "Reading…"
        bg {
            val r = runCatching { GitHubApi.listReleases(token, repo) }
            post {
                r.onSuccess { rels = it; picked.clear(); msg = if (it.isEmpty()) "No releases in $repo." else "" }
                    .onFailure { msg = GitHubBuild.explain(it) }
            }
        }
    }
    LaunchedEffect(Unit) { load() }

    fun upload(uri: Uri, rel: GitHubApi.Rel) {
        msg = "Uploading to ${rel.tag}…"
        bg {
            val r = runCatching {
                val name = displayName(context, uri) ?: error("That file has no name.")
                val tmp = File(context.cacheDir, "gh_upload.tmp")
                context.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                try { GitHubApi.uploadAsset(token, repo, rel, name, tmp) } finally { tmp.delete() }
            }
            post { toast(context, r.getOrElse { GitHubBuild.explain(it) }); load() }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { if (rels.size == 1) upload(uri, rels[0]) else pickTarget = uri }
    }

    val allAssets = rels.flatMap { it.assets }
    val nPicked = allAssets.count { picked[it.id] == true }

    CardGroup("Releases") {
        row { sh ->
            SettingRow(
                title = "Releases in $repo (${rels.size})", shape = sh, icon = Icons.Filled.Info,
                summary = if (msg.isEmpty()) null else msg,
            )
        }
        row { sh -> LinkRow("Refresh", "Read the releases again", sh, icon = Icons.Filled.Refresh) { load() } }
        row { sh ->
            ChipsCardRow(
                title = "Sort by",
                options = listOf("Name" to !byDate, "Date modified" to byDate),
                shape = sh,
                onToggle = { n -> byDate = (n == 1) },
            )
        }
        row { sh ->
            SettingRow(
                title = "About zips sent for a build", shape = sh,
                info = "A zip sent for a build stays here only until the workflow has started; the workflow then removes it. " +
                    "To keep your sources, turn on \"Keep a copy of every uploaded zip in the repo\" in GitHub build settings.",
            )
        }
    }

    CardGroup("Pick and send") {
        row { sh ->
            val allPicked = allAssets.isNotEmpty() && nPicked == allAssets.size
            SettingRow(
                title = if (allPicked) "Select none" else "Select all", shape = sh,
                icon = Icons.Filled.CheckCircle, lit = nPicked > 0,
                summary = "$nPicked of ${allAssets.size} files ticked",
                onClick = {
                    val on = nPicked < allAssets.size
                    for (f in allAssets) picked[f.id] = on
                },
            )
        }
        row { sh ->
            SettingRow(
                title = "Delete selected ($nPicked)", shape = sh, icon = Icons.Filled.Delete,
                summary = if (nPicked > 0) "Removes the ticked files from the releases" else "Tick files in the lists first",
                onClick = if (nPicked > 0) ({ askDeleteAll = true }) else null,
            )
        }
        row { sh ->
            LinkRow("Upload a file here", "Into one of the releases", sh, icon = Icons.Filled.CloudUpload) { picker.launch(arrayOf("*/*")) }
        }
    }

    pickTarget?.let { uri ->
        CardWindow(title = "Upload into which release?", onBack = { pickTarget = null }) {
            CardGroup(title = "Pick one") {
                for (rel in rels) row { sh -> SettingRow(title = rel.tag, shape = sh, onClick = { pickTarget = null; upload(uri, rel) }) }
            }
        }
    }
    if (askDeleteAll) {
        val all = rels.flatMap { r -> r.assets.filter { picked[it.id] == true }.map { r.tag to it } }
        GhConfirm(
            title = "Delete the selected release files?",
            text = if (all.isEmpty()) "No release file is selected." else "${all.size} files are removed from the releases (the releases themselves stay):\n\n" + all.joinToString("\n") { "${it.first}: ${it.second.name}" },
            confirm = "Delete selected",
            enabled = all.isNotEmpty(),
            onDismiss = { askDeleteAll = false },
            onConfirm = {
                askDeleteAll = false
                msg = "Deleting ${all.size} files…"
                bg {
                    var done = 0
                    var fail = ""
                    for ((_, a) in all) {
                        val r = runCatching { GitHubApi.deleteAsset(token, repo, a.id) }
                        if (r.isSuccess) done++ else { fail = GitHubBuild.explain(r.exceptionOrNull()!!); break }
                    }
                    post { toast(context, "Deleted $done of ${all.size}" + if (fail.isEmpty()) "" else ". $fail"); load() }
                }
            },
        )
    }
    for (rel in rels) {
        CardGroup("Release: ${rel.tag}") {
            if (rel.assets.isEmpty()) {
                row { sh -> SettingRow(title = "No files", shape = sh, summary = "This release holds no files.") }
            }
            val sorted = if (byDate) rel.assets.sortedByDescending { it.created } else rel.assets.sortedBy { it.name.lowercase() }
            for (asset in sorted) {
                row { sh ->
                    SettingRow(
                        title = asset.name, shape = sh, icon = Icons.Filled.Description,
                        lit = picked[asset.id] == true,
                        summary = "${kb(asset.size)} · ${asset.created}",
                        onClick = { picked[asset.id] = picked[asset.id] != true },
                        trailing = { androidx.compose.material3.Checkbox(checked = picked[asset.id] == true, onCheckedChange = null) },
                        footer = {
                            Row(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 4.dp)) {
                                TextButton(onClick = {
                                    bg {
                                        val r = runCatching { GitHubApi.downloadAsset(context, token, repo, asset.id, asset.name) }
                                        post { toast(context, r.map { "Saved to Downloads: $it" }.getOrElse { GitHubBuild.explain(it) }) }
                                    }
                                }) { Text("Download") }
                                TextButton(onClick = {
                                    bg {
                                        val r = runCatching { GitHubApi.deleteAsset(token, repo, asset.id) }
                                        post { toast(context, r.getOrElse { GitHubBuild.explain(it) }); load() }
                                    }
                                }) { Text("Delete") }
                            }
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ZipsTab(context: Context, preference: SharedPref, token: String, repo: String) {
    var byDate by remember { mutableStateOf(false) }
    val allZips = remember {
        preference.getGhFiles("zip").filter { it.path.isNotBlank() }
            .mapNotNull { GitHubBuild.newest(File(it.path)) }.distinctBy { it.absolutePath }
    }
    val zips = if (byDate) allZips.sortedByDescending { it.lastModified() } else allZips.sortedBy { it.name.lowercase() }
    var opened by remember { mutableStateOf<File?>(null) }
    var items by remember { mutableStateOf<List<GitHubApi.ZipItem>>(emptyList()) }
    var filter by remember { mutableStateOf("build.gradle") }
    var msg by remember { mutableStateOf("") }

    CardGroup("My zips") {
        row { sh ->
            SettingRow(
                title = "Zips on this phone (${zips.size})", shape = sh, icon = Icons.Filled.Info,
                summary = if (msg.isNotEmpty()) msg else if (zips.isEmpty()) "No zip was found at the paths in GitHub build settings." else null,
                info = "The zips from GitHub build settings, as they are on this phone. Open one and take any single file out of it.",
            )
        }
        row { sh ->
            ChipsCardRow(
                title = "Sort by",
                options = listOf("Name" to !byDate, "Date modified" to byDate),
                shape = sh,
                onToggle = { n -> byDate = (n == 1) },
            )
        }
    }

    CardGroup("Zips") {
        for (z in zips) {
            row { sh ->
                SettingRow(
                    title = z.name, shape = sh, icon = Icons.Filled.Description,
                    lit = opened == z,
                    summary = "${kb(z.length())} · ${fileTime(z)}",
                    footer = {
                        Row(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 4.dp)) {
                            TextButton(onClick = {
                                opened = z; items = emptyList(); msg = "Reading…"
                                bg {
                                    val r = runCatching { GitHubApi.zipEntries(z) }
                                    post { r.onSuccess { items = it; msg = "${it.size} files" }.onFailure { msg = GitHubBuild.explain(it) } }
                                }
                            }) { Text("Show files") }
                            TextButton(onClick = {
                                msg = "Saving ${z.name} in the repo (sources/)…"
                                bg {
                                    val r = runCatching { GitHubApi.putFile(token, repo, "sources/${z.name}", z.readBytes(), "Source copy of ${z.name}") }
                                    post { msg = r.getOrElse { GitHubBuild.explain(it) }; toast(context, msg) }
                                }
                            }) { Text("Save copy in repo") }
                        }
                    },
                )
            }
        }
    }

    opened?.let { z ->
        val shown = items.filter { it.path.contains(filter.trim(), ignoreCase = true) }
        CardGroup("Files in ${z.name}", hint = "Tap a file to save it to Downloads.") {
            row { sh ->
                SettingRow(
                    title = "Search in ${z.name}", shape = sh,
                    summary = if (shown.size > 60) "Showing 60 of ${shown.size}: type more of the name." else "${shown.size} files shown",
                    footer = {
                        OutlinedTextField(
                            value = filter, onValueChange = { filter = it }, singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                        )
                    },
                )
            }
            for (item in shown.take(60)) {
                row { sh ->
                    SettingRow(
                        title = item.path, shape = sh, compact = true,
                        summary = kb(item.size),
                        onClick = {
                            bg {
                                val r = runCatching { GitHubApi.extractEntry(context, z, item) }
                                post { toast(context, r.map { n -> "Saved to Downloads: $n" }.getOrElse { e -> GitHubBuild.explain(e) }) }
                            }
                        },
                        trailing = { androidx.compose.material3.Icon(Icons.Filled.Download, contentDescription = "Download") },
                    )
                }
            }
        }
    }
}
