package a.a.flow

import android.content.Context

/**
 * Every built-in device action (flashlight, Wi-Fi, airplane, network mode, ...) as an ordinary A
 * action. Stored as "N:<id>" or "N:<id>|<argument>". One entry per thing: on / off / toggle are
 * chosen after picking it, in flow/DeviceActionPicker.kt (cards), which opens only when needed.
 */
object NativePicker {
    const val PREFIX = "N:"

    fun isNative(action: String) = action.startsWith(PREFIX)

    private fun idOf(action: String) = action.removePrefix(PREFIX).substringBefore('|')
    private fun argOf(action: String) = action.substringAfter('|', "")

    fun label(action: String): String {
        val d = NativeActions.find(idOf(action)) ?: return action
        val a = argOf(action)
        return d.label + if (a.isNotEmpty()) " (" + ActionArgs.label(idOf(action), a) + ")" else ""
    }

    fun isValid(action: String) = isNative(action) && NativeActions.find(idOf(action)) != null

    /** Blocking: call from a background thread. Returns the result line. */
    fun run(context: Context, action: String): String =
        NativeActions.run(context, idOf(action), argOf(action), HashMap())

    /** One device action as the pickers list it: its name, and its On / Off / Toggle modes (mode label, id), or one entry with an empty label. */
    class Group(val title: String, val options: List<Pair<String, String>>)

    fun groups(): List<Group> {
        val out = ArrayList<Group>()
        val byBase = LinkedHashMap<String, MutableList<Pair<String, String>>>()
        for (d in NativeActions.all) {
            if (d.id.startsWith("A:")) continue
            val mode = when {
                d.id.endsWith("_toggle") && d.label.contains(": toggle") -> "Toggle"
                d.id.endsWith("_on") -> "On"
                d.id.endsWith("_off") -> "Off"
                else -> null
            }
            if (mode != null && d.label.contains(": ")) {
                val base = d.label.substringBefore(": ")
                byBase.getOrPut(base) { ArrayList() }.add(mode to d.id)
            } else out += Group(d.label, listOf("" to d.id))
        }
        for ((base, opts) in byBase) {
            val order = listOf("On", "Off", "Toggle")
            out += Group(base, opts.sortedBy { order.indexOf(it.first) })
        }
        return out.sortedBy { it.title.lowercase() }
    }
}
