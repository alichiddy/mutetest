package a.a.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A time everywhere in A: a bar that starts in milliseconds, plus a seconds box and a milliseconds box. */

fun msText(ms: Int): String = when {
    ms <= 0 -> "0 ms"
    ms < 1000 -> "$ms ms"
    ms % 1000 == 0 -> "${ms / 1000} s"
    else -> "${ms / 1000} s ${ms % 1000} ms"
}

// The first half of the bar is 0 to 1 second (steps of 10 ms), the second half is 1 second up to the end of the bar.
private fun msToPos(ms: Int, barMax: Int): Float {
    val m = ms.coerceIn(0, barMax)
    if (barMax <= 1000) return m.toFloat() / barMax.coerceAtLeast(1)
    return if (m <= 1000) m / 2000f else 0.5f + (m - 1000f) / (barMax - 1000f) / 2f
}

private fun posToMs(p: Float, barMax: Int): Int {
    val q = p.coerceIn(0f, 1f)
    if (barMax <= 1000) return (Math.round(q * barMax / 10f) * 10).coerceIn(0, barMax)
    if (q <= 0.5f) return Math.round(q * 2000f / 10f) * 10
    val raw = 1000f + (q - 0.5f) * 2f * (barMax - 1000f)
    return (Math.round(raw / 100f) * 100).coerceIn(1000, barMax)
}

/** Only the two boxes: seconds (can be 0) and milliseconds. [maxMs] is the biggest time that can be typed. */
@Composable
fun MsFields(ms: Int, maxMs: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
    var sT by remember { mutableStateOf((ms / 1000).toString()) }
    var mT by remember { mutableStateOf((ms % 1000).toString()) }
    var emitted by remember { mutableStateOf(ms) }
    LaunchedEffect(ms) {
        if (ms != emitted) {
            sT = (ms / 1000).toString()
            mT = (ms % 1000).toString()
            emitted = ms
        }
    }
    fun push(s: String, m: String) {
        val v = ((s.toLongOrNull() ?: 0L) * 1000L + (m.toLongOrNull() ?: 0L)).coerceIn(0L, maxMs.toLong()).toInt()
        emitted = v
        onChange(v)
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = sT,
            onValueChange = { t ->
                val d = t.filter { ch -> ch.isDigit() }.take(5)
                sT = d
                push(d, mT)
            },
            singleLine = true,
            label = { Text("seconds", fontSize = 10.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
        )
        OutlinedTextField(
            value = mT,
            onValueChange = { t ->
                val d = t.filter { ch -> ch.isDigit() }.take(6)
                mT = d
                push(sT, d)
            },
            singleLine = true,
            label = { Text("milliseconds", fontSize = 10.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f),
        )
    }
}

/** A title with the time written out, the bar (in milliseconds), and the seconds and milliseconds boxes. */
@Composable
fun MsBox(title: String, ms: Int, maxMs: Int, barMax: Int = maxMs, onChange: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("$title: ${msText(ms)}", fontSize = 12.sp)
        Slider(
            value = msToPos(ms, barMax),
            onValueChange = { onChange(posToMs(it, barMax)) },
            valueRange = 0f..1f,
        )
        MsFields(ms, maxMs, onChange)
    }
}
