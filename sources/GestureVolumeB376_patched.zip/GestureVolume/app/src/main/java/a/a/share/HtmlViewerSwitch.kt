package a.a.share

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * Which of the two HTML viewer entries is live: [HtmlViewerActivity] (its own window in Recent apps)
 * or [HtmlViewerSameTaskActivity] (opens inside the task of whoever opened it). Only one is enabled,
 * and neither when the viewer is hidden from other apps' Share / Open with lists.
 */
object HtmlViewerSwitch {
    private fun prefs(c: Context) = c.getSharedPreferences("html_viewer", Context.MODE_PRIVATE)

    /** The viewer has its own entry in Recent apps (default on). */
    fun separate(c: Context) = prefs(c).getBoolean("separate", true)

    /** The viewer is offered in other apps' Share / Open with lists. */
    fun shareOn(c: Context): Boolean {
        val p = prefs(c)
        if (p.contains("shareOn")) return p.getBoolean("shareOn", true)
        // Before this setting existed the switch in Appearance disabled the component itself.
        return c.packageManager.getComponentEnabledSetting(ComponentName(c, HtmlViewerActivity::class.java)) !=
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    }

    /** The class A itself opens HTML pages with. */
    fun cls(c: Context): Class<out HtmlViewerActivity> =
        if (separate(c)) HtmlViewerActivity::class.java else HtmlViewerSameTaskActivity::class.java

    fun setSeparate(c: Context, on: Boolean) { prefs(c).edit().putBoolean("separate", on).apply(); apply(c) }

    fun setShareOn(c: Context, on: Boolean) { prefs(c).edit().putBoolean("shareOn", on).apply(); apply(c) }

    private fun apply(c: Context) {
        val share = shareOn(c)
        val sep = separate(c)
        fun set(cls: Class<*>, on: Boolean) = c.packageManager.setComponentEnabledSetting(
            ComponentName(c, cls),
            if (on) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP,
        )
        set(HtmlViewerActivity::class.java, share && sep)
        set(HtmlViewerSameTaskActivity::class.java, share && !sep)
    }
}

/** The same viewer, opened inside the task of the app that started it (no window of its own in Recent apps). */
class HtmlViewerSameTaskActivity : HtmlViewerActivity()
