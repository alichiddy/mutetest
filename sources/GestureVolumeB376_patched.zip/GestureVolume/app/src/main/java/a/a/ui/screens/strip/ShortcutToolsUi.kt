package a.a.ui.screens.strip

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.strip.ShortcutTools
import a.a.ui.components.AWindowPage
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton

/** Test (run now) and Add to launcher for the shortcut shown above: used in the cell editor. */
@Composable
fun ShortcutToolRow(label: String, icon: String, action: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var launcher by remember { mutableStateOf(false) }
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { ShortcutTools.test(ctx, label, icon, action) }, modifier = Modifier.weight(1f)) { Text("Test (run now)") }
        OutlinedButton(onClick = { launcher = true }, modifier = Modifier.weight(1f)) { Text("Add to launcher") }
    }
    if (launcher) AddToLauncherDialog(label, icon, action) { launcher = false }
}

/** A full-screen window with the back arrow (back = close), the way the other Cell Settings windows are drawn. */
@Composable
private fun ToolsWindow(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AWindowPage(title, onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                    content = content,
                )
            }
        }
    }
}

/**
 * Shown when a shortcut is tapped in a list: it can be tried (Test), sent to a launcher, or used.
 * [onUse] carries on exactly as the tap did before.
 */
@Composable
fun ShortcutGateDialog(label: String, icon: String, action: String, onUse: () -> Unit, onDismiss: () -> Unit) {
    var launcher by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    if (launcher) { AddToLauncherDialog(label, icon, action) { launcher = false }; return }
    ToolsWindow(label.ifBlank { "Shortcut" }, onDismiss) {
        CardGroup(title = "Try it before you use it") {
            row { sh ->
                LinkRow("Test (run now)", "Runs the shortcut once, right now", sh, Icons.Filled.PlayArrow) {
                    ShortcutTools.test(ctx, label, icon, action)
                }
            }
            row { sh ->
                LinkRow("Add to launcher", "Puts it on the home screen of a launcher", sh, Icons.Filled.Add) { launcher = true }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onUse, modifier = Modifier.fillMaxWidth()) { Text("Use") }
    }
}

/** Where the shortcut goes: the default launcher or another launcher. */
@Composable
fun AddToLauncherDialog(label: String, icon: String, action: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val others = remember { ShortcutTools.otherLaunchers(ctx) }
    val defName = remember {
        ShortcutTools.defaultLauncher(ctx)?.let { p -> runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString() }.getOrNull() }
    }
    if (action.isBlank()) {
        ToolsWindow("Add to launcher", onDismiss) {
            CardGroup("Nothing chosen yet") {
                row { sh -> SettingRow(title = "Choose a shortcut first.", shape = sh, icon = Icons.Filled.Info) }
            }
        }
        return
    }
    ToolsWindow("Add \"" + label.ifBlank { "shortcut" } + "\"", onDismiss) {
        CardGroup("Pick the launcher", hint = "Tap the launcher that should get this shortcut.") {
            row { sh ->
                LinkRow(
                    "Home screen of the default launcher" + (defName?.let { " ($it)" } ?: ""),
                    "Your launcher will ask you to confirm.", sh, Icons.Filled.Home,
                ) {
                    val ok = ShortcutTools.pinToDefault(ctx, label, icon, action)
                    Toast.makeText(ctx, if (ok) "Your launcher will ask you to confirm." else "This launcher does not accept shortcuts from apps.", Toast.LENGTH_LONG).show()
                    onDismiss()
                }
            }
            others.forEach { (pkg, name) ->
                row { sh ->
                    LinkRow(
                        "Launcher: $name",
                        "Works only if that launcher still accepts the old add-shortcut request.", sh, Icons.Filled.Apps,
                    ) {
                        ShortcutTools.sendLegacy(ctx, pkg, label, icon, action)
                        Toast.makeText(ctx, "Sent to $name. If nothing appears, it does not accept it.", Toast.LENGTH_LONG).show()
                        onDismiss()
                    }
                }
            }
        }
    }
}
