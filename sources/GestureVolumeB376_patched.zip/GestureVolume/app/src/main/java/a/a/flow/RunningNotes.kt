package a.a.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.Looper

/**
 * Notifications for running scripts. Each running script gets its own with a Stop button, except the
 * scripts marked "Always On": they all share ONE notification (with a button that stops them all). A script
 * that ends within a second never shows one (cell presses are quick). Nothing is kept when nothing runs.
 */
object RunningNotes {
    private const val CHANNEL = "scripts_running"
    private const val SHARED_ID = 7390
    private const val BASE_ID = 7500
    const val ACTION_STOP = "a.a.flow.STOP_SCRIPT"
    private const val GRACE_MS = 1000L

    private val posted = HashSet<Int>()

    fun started(context: Context, run: FlowRunner.Run) {
        val app = context.applicationContext
        Handler(Looper.getMainLooper()).postDelayed({ if (FlowRunner.isRunning(run.id)) refresh(app) }, GRACE_MS)
    }

    fun ended(context: Context, run: FlowRunner.Run) {
        val app = context.applicationContext
        // Only if it ever had a notification (it ran longer than the grace time).
        if (System.currentTimeMillis() - run.since >= GRACE_MS || synchronized(posted) { posted.isNotEmpty() }) refresh(app)
    }

    private fun noteId(run: FlowRunner.RunInfo) = BASE_ID + (run.id % 900).toInt()

    /** Makes the notifications match what runs now. */
    @Synchronized
    fun refresh(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val now = System.currentTimeMillis()
        val current = FlowRunner.running().filter { now - it.since >= GRACE_MS - 100 }
        val own = current.filter { !it.alwaysOn }
        val shared = current.filter { it.alwaysOn }
        runCatching { nm.createNotificationChannel(NotificationChannel(CHANNEL, "Running scripts", NotificationManager.IMPORTANCE_LOW)) }
        val wanted = HashSet<Int>()
        for (r in own) {
            val id = noteId(r)
            wanted.add(id)
            runCatching {
                nm.notify(
                    id,
                    base(context, r.name, r.since)
                        .setContentText("Running")
                        .addAction(stopAction(context, id, Intent(context, FlowStopReceiver::class.java).setAction(ACTION_STOP).putExtra("run", r.id).putExtra("nid", id), "Stop"))
                        .build(),
                )
            }
        }
        if (shared.isNotEmpty()) {
            wanted.add(SHARED_ID)
            val names = shared.map { it.name }.distinct()
            runCatching {
                nm.notify(
                    SHARED_ID,
                    base(context, names.size.toString() + " Always On script(s) running", shared.minOf { it.since })
                        .setContentText(names.joinToString(", "))
                        .setStyle(Notification.InboxStyle().also { st -> names.forEach { st.addLine(it) } })
                        .addAction(stopAction(context, SHARED_ID, Intent(context, FlowStopReceiver::class.java).setAction(ACTION_STOP).putExtra("alwayson", true).putExtra("nid", SHARED_ID), "Stop all of them"))
                        .build(),
                )
            }
        }
        synchronized(posted) {
            posted.filter { it !in wanted }.forEach { runCatching { nm.cancel(it) } }
            posted.clear()
            posted.addAll(wanted)
        }
    }

    private fun base(context: Context, title: String, since: Long): Notification.Builder {
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, FlowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setWhen(since)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
    }

    private fun stopAction(context: Context, code: Int, intent: Intent, label: String): Notification.Action {
        val pi = PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Action.Builder(Icon.createWithResource(context, android.R.drawable.ic_delete), label, pi).build()
    }
}

/** The Stop button of a running-script notification. Declared in the manifest, so nothing waits in memory. */
class FlowStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != RunningNotes.ACTION_STOP) return
        val nid = intent.getIntExtra("nid", 0)
        if (intent.getBooleanExtra("alwayson", false)) {
            FlowRunner.stopAllRuns(alwaysOnOnly = true)
        } else {
            val run = intent.getLongExtra("run", 0L)
            val live = FlowRunner.isRunning(run)
            FlowRunner.stop(run)
            // A notification left behind by a process that was killed: nothing runs any more, so remove it.
            if (!live && nid != 0) runCatching { context.getSystemService(NotificationManager::class.java)?.cancel(nid) }
        }
        RunningNotes.refresh(context.applicationContext)
    }
}
