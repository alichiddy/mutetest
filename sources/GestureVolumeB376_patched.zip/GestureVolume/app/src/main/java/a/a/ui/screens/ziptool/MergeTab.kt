package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.CardWindow
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.File
import java.util.TreeSet
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * The smart merger. Two sources, each a zip or a folder: A is the base, B is the other version. Every file is
 * compared; the files that differ are listed with what is different (lines added and removed for text), and you
 * choose, file by file, which of B's versions to take. The result is a new zip made from A with only the
 * chosen changes applied. A and B themselves are never changed.
 *
 * Both sources are held as zips in the cache (a folder is packed into one first), so the same read-back
 * check as the other tabs covers the merged result.
 */
class MergeState(private val ctx: Context) {
    enum class Side { A, B }

    /** CHANGED: in both, different. ONLY_B: new in B. ONLY_A: in A but not in B. */
    enum class Kind { CHANGED, ONLY_B, ONLY_A }

    /** One difference. [rel] is the path with each source's top folder taken off, so the two line up. */
    class Diff(
        val rel: String,
        val kind: Kind,
        val aName: String?,
        val bName: String?,
        val aSize: Long,
        val bSize: Long,
        val summary: String,
        val isText: Boolean,
    )

    var aLabel by mutableStateOf<String?>(null)
    var bLabel by mutableStateOf<String?>(null)
    var aInfo by mutableStateOf("")
    var bInfo by mutableStateOf("")
    var diffs by mutableStateOf<List<Diff>>(emptyList())
    var same by mutableStateOf(0)
    var compared by mutableStateOf(false)
    var picked by mutableStateOf<Set<String>>(emptySet())
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var log by mutableStateOf("")
    var showReview by mutableStateOf(false)
    var detail by mutableStateOf<Diff?>(null)
    var detailLines by mutableStateOf<List<String>?>(null)

    private var fileA = File(ctx.cacheDir, A_TMP)
    private var fileB = File(ctx.cacheDir, B_TMP)
    private var rootA = ""

    val bothLoaded: Boolean get() = aLabel != null && bLabel != null

    fun cleanup() {
        File(ctx.cacheDir, A_TMP).delete()
        File(ctx.cacheDir, B_TMP).delete()
        File(ctx.cacheDir, NEW_TMP).delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    // ---------------------------------------------------------------- picking

    private fun fileFor(side: Side): File = if (side == Side.A) fileA else fileB

    /** A finished temporary file takes the place of the side's old one only once it is complete. */
    private fun install(tmp: File, dest: File) {
        if (!tmp.renameTo(dest)) {
            dest.delete()
            if (!tmp.renameTo(dest)) throw IllegalStateException("Could not keep the file in the app's cache.")
        }
    }

    private fun setSide(side: Side, label: String, info: String) {
        if (side == Side.A) {
            aLabel = label
            aInfo = info
        } else {
            bLabel = label
            bInfo = info
        }
        diffs = emptyList()
        compared = false
        picked = emptySet()
        same = 0
        showReview = false
        detail = null
    }

    fun loadZip(side: Side, u: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the zip..."
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            val tmp = File(ctx.cacheDir, NEW_TMP)
            try {
                ZipIo.copyToCache(ctx.contentResolver, u, tmp)
                val count = ZipIo.listFiles(tmp).size
                install(tmp, fileFor(side))
                setSide(side, name, "zip, $count files")
                if (side == Side.A) outName = ZipIo.stem(name) + "_merged.zip"
                if (bothLoaded) compareNow()
            } catch (e: Throwable) {
                log = "MERGE ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    /** A folder is read and packed into a temporary zip, so both sides are compared the same way. */
    fun loadFolder(side: Side, tree: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the folder..."
        Thread {
            val tmp = File(ctx.cacheDir, NEW_TMP)
            try {
                val sc = FolderZip.scan(ctx, tree)
                if (sc.fileCount == 0) throw IllegalStateException("The folder has no files in it.")
                FolderZip.pack(ctx, sc, tmp, sc.rootName + "/", fast = true) { done, total ->
                    status = "Reading the folder: $done of $total..."
                }
                install(tmp, fileFor(side))
                setSide(side, sc.rootName, "folder, ${sc.fileCount} files")
                if (side == Side.A) outName = sc.rootName + "_merged.zip"
                if (bothLoaded) compareNow()
            } catch (e: Throwable) {
                log = "MERGE ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    /** Makes A the other version and B the base, then compares again. */
    fun swap() {
        if (busy || !bothLoaded) return
        busy = true
        log = ""
        val f = fileA
        fileA = fileB
        fileB = f
        val l = aLabel
        aLabel = bLabel
        bLabel = l
        val i = aInfo
        aInfo = bInfo
        bInfo = i
        Thread {
            try {
                compareNow()
            } catch (e: Throwable) {
                log = "MERGE ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    // ---------------------------------------------------------------- comparing

    /** Runs on a worker thread. Lines the two sources up by path (their top folders taken off) and lists what differs. */
    private fun compareNow() {
        val fa = fileA
        val fb = fileB
        status = "Comparing..."
        val aNames = ZipIo.listFiles(fa)
        val bNames = ZipIo.listFiles(fb)
        val aRoot = ZipIo.rootOf(aNames)
        val bRoot = ZipIo.rootOf(bNames)
        val found = ArrayList<Diff>()
        var identical = 0
        ZipFile(fa).use { za ->
            ZipFile(fb).use { zb ->
                val aMap = HashMap<String, ZipEntry>()
                for (n in aNames) {
                    val e = za.getEntry(n) ?: continue
                    aMap[n.removePrefix(aRoot)] = e
                }
                val bMap = HashMap<String, ZipEntry>()
                for (n in bNames) {
                    val e = zb.getEntry(n) ?: continue
                    bMap[n.removePrefix(bRoot)] = e
                }
                val rels = TreeSet<String>()
                rels.addAll(aMap.keys)
                rels.addAll(bMap.keys)
                var i = 0
                for (rel in rels) {
                    i++
                    if (i % 10 == 0) status = "Comparing $i of ${rels.size}..."
                    val ea = aMap[rel]
                    val eb = bMap[rel]
                    if (ea != null && eb != null) {
                        if (ea.size == eb.size && ea.crc == eb.crc) {
                            identical++
                        } else {
                            found.add(changed(rel, za, ea, zb, eb))
                        }
                    } else if (eb != null) {
                        found.add(Diff(rel, Kind.ONLY_B, null, eb.name, 0L, eb.size, "new in B, ${ZipIo.size(eb.size)}", false))
                    } else if (ea != null) {
                        found.add(Diff(rel, Kind.ONLY_A, ea.name, null, ea.size, 0L, "not in B, ${ZipIo.size(ea.size)}", false))
                    }
                }
            }
        }
        rootA = aRoot
        picked = emptySet()
        diffs = found
        same = identical
        compared = true
        status = ""
    }

    /** One file that is in both and differs: for text, how many lines were added and removed. */
    private fun changed(rel: String, za: ZipFile, ea: ZipEntry, zb: ZipFile, eb: ZipEntry): Diff {
        val sa = ea.size
        val sb = eb.size
        var summary = "different content, ${ZipIo.size(sa)} → ${ZipIo.size(sb)}"
        var isText = false
        if (sa <= LineDiff.MAX_TEXT && sb <= LineDiff.MAX_TEXT) {
            val ba = za.getInputStream(ea).use { it.readBytes() }
            val bb = zb.getInputStream(eb).use { it.readBytes() }
            if (LineDiff.looksText(ba) && LineDiff.looksText(bb)) {
                isText = true
                val r = LineDiff.diff(
                    LineDiff.split(String(ba, Charsets.UTF_8)),
                    LineDiff.split(String(bb, Charsets.UTF_8)),
                )
                summary = when {
                    r.tooBig -> "big change: ${r.regionOld} lines became ${r.regionNew}"
                    r.sameLines -> "only line endings or the last newline differ"
                    else -> "+${r.added} / -${r.removed} lines"
                }
            }
        }
        return Diff(rel, Kind.CHANGED, ea.name, eb.name, sa, sb, summary, isText)
    }

    // ---------------------------------------------------------------- choosing

    fun toggle(rel: String) {
        picked = if (rel in picked) picked - rel else picked + rel
    }

    fun pickAll(rels: Collection<String>) {
        picked = picked + rels
    }

    fun clear(rels: Collection<String>) {
        picked = picked - rels.toSet()
    }

    /** Reads the two versions and builds the lines of the "what is different" view. */
    fun openDetail(d: Diff) {
        detail = d
        detailLines = null
        val fa = fileA
        val fb = fileB
        Thread {
            val lines: List<String> = try {
                ZipFile(fa).use { za ->
                    ZipFile(fb).use { zb ->
                        describe(d, za, zb)
                    }
                }
            } catch (e: Throwable) {
                listOf("Could not read the files: ${e.message ?: e.javaClass.simpleName}")
            }
            if (detail === d) detailLines = lines
        }.start()
    }

    private fun describe(d: Diff, za: ZipFile, zb: ZipFile): List<String> {
        val ea = d.aName?.let { za.getEntry(it) }
        val eb = d.bName?.let { zb.getEntry(it) }
        return when (d.kind) {
            Kind.CHANGED ->
                if (ea == null || eb == null) listOf("A file is missing from one of the sources.")
                else describeChanged(d, za, ea, zb, eb)
            Kind.ONLY_B ->
                if (eb == null) listOf("The file is missing from B.") else whole(zb, eb, '+')
            Kind.ONLY_A ->
                if (ea == null) listOf("The file is missing from A.") else whole(za, ea, '-')
        }
    }

    private fun describeChanged(d: Diff, za: ZipFile, ea: ZipEntry, zb: ZipFile, eb: ZipEntry): List<String> {
        if (!d.isText) {
            return listOf(
                "This file is not plain text (or is very large), so it cannot be compared line by line.",
                "A: ${ZipIo.size(d.aSize)}",
                "B: ${ZipIo.size(d.bSize)}",
            )
        }
        val ba = za.getInputStream(ea).use { it.readBytes() }
        val bb = zb.getInputStream(eb).use { it.readBytes() }
        val r = LineDiff.diff(
            LineDiff.split(String(ba, Charsets.UTF_8)),
            LineDiff.split(String(bb, Charsets.UTF_8)),
        )
        return when {
            r.tooBig -> listOf("The changed part is too large to show line by line: ${r.regionOld} lines in A became ${r.regionNew} in B.")
            r.sameLines -> listOf("The lines are the same. Only line endings or the last newline differ.")
            else -> r.lines
        }
    }

    private fun whole(z: ZipFile, e: ZipEntry, mark: Char): List<String> {
        if (e.size > LineDiff.MAX_TEXT) return listOf("This file is too large to show (${ZipIo.size(e.size)}).")
        val b = z.getInputStream(e).use { it.readBytes() }
        if (!LineDiff.looksText(b)) return listOf("This file is not plain text (${ZipIo.size(e.size)}).")
        return LineDiff.whole(String(b, Charsets.UTF_8), mark)
    }

    // ---------------------------------------------------------------- merging

    private fun blobOf(zb: ZipFile, name: String): ZipIo.Blob = ZipIo.Blob(opener = {
        val e = zb.getEntry(name) ?: throw IllegalStateException("$name is missing in B.")
        zb.getInputStream(e)
    })

    /** Builds a new zip from A with the chosen differences applied, reads it back, and saves it in Downloads. */
    fun make() {
        if (busy) return
        val fa = fileA
        val fb = fileB
        val chosen = diffs.filter { it.rel in picked }
        if (chosen.isEmpty()) {
            log = "MERGE ERROR: choose at least one difference first.\nNothing was saved."
            return
        }
        busy = true
        log = ""
        val saveName = ZipIo.cleanName(outName, "merged")
        val aRoot = rootA
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                status = "Building the merged zip..."
                ZipFile(fb).use { zb ->
                    val replace = LinkedHashMap<String, ZipIo.Blob>()
                    val remove = HashSet<String>()
                    val add = ArrayList<Pair<String, ZipIo.Blob>>()
                    for (d in chosen) {
                        when (d.kind) {
                            Kind.CHANGED -> replace[d.aName!!] = blobOf(zb, d.bName!!)
                            Kind.ONLY_B -> add.add((aRoot + d.rel) to blobOf(zb, d.bName!!))
                            Kind.ONLY_A -> remove.add(d.aName!!)
                        }
                    }
                    val out = ZipIo.rewrite(fa, tmp, replace, remove, add)
                    if (out.replaced != replace.size || out.removed != remove.size || out.added != add.size) {
                        throw IllegalStateException("The base zip did not hold every file that was meant to change.")
                    }
                    status = "Checking the zip..."
                    val sb = StringBuilder("MERGED: ${out.replaced} replaced, ${out.added} added, ${out.removed} removed\n")
                    for ((i, d) in chosen.withIndex()) {
                        if (i >= 60) {
                            sb.append("...and ${chosen.size - 60} more\n")
                            break
                        }
                        val mark = when (d.kind) {
                            Kind.CHANGED -> "~ "
                            Kind.ONLY_B -> "+ "
                            Kind.ONLY_A -> "- "
                        }
                        sb.append(mark).append(d.rel).append('\n')
                    }
                    if (out.skipped > 0) sb.append("Note: ${out.skipped} repeated file name(s) in A were left out.\n")
                    val problem = ZipIo.verify(tmp, out.written, out.expectCrc)
                    if (problem != null) {
                        sb.append("MERGE ERROR: $problem\nNothing was saved.")
                    } else {
                        val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
                        sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                        sb.append("Read back and checked. ${out.written} entries. A and B were not changed.")
                    }
                    log = sb.toString()
                }
            } catch (e: Throwable) {
                log = "MERGE ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    private companion object {
        const val A_TMP = "zt_merge_1.zip"
        const val B_TMP = "zt_merge_2.zip"
        const val NEW_TMP = "zt_merge_new.zip"
        const val OUT_TMP = "zt_merge_out.zip"
    }
}

private fun kindLabel(k: MergeState.Kind): String = when (k) {
    MergeState.Kind.CHANGED -> "Different in B"
    MergeState.Kind.ONLY_B -> "Only in B (new)"
    MergeState.Kind.ONLY_A -> "Only in A (not in B)"
}

/** What will happen to this file in the merged zip, in a few words. */
private fun actionNow(d: MergeState.Diff, on: Boolean): String = when (d.kind) {
    MergeState.Kind.CHANGED -> if (on) "Take B's version" else "Keep A's"
    MergeState.Kind.ONLY_B -> if (on) "Add from B" else "Don't add"
    MergeState.Kind.ONLY_A -> if (on) "Remove" else "Keep"
}

@Composable
private fun SourceRow(
    title: String,
    label: String?,
    info: String,
    shape: Shape,
    busy: Boolean,
    onZip: () -> Unit,
    onFolder: () -> Unit,
) {
    KitRow(
        title = title,
        shape = shape,
        leading = { IconTile(Icons.Filled.Folder, lit = label != null) },
        summary = label ?: "Not chosen",
        description = if (label != null) info else null,
        footer = {
            Row(
                Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(onClick = onZip, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Pick a zip") }
                Button(onClick = onFolder, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Pick a folder") }
            }
        },
    )
}

@Composable
fun MergeTab(s: MergeState) {
    val pickAZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(MergeState.Side.A, u)
    }
    val pickAFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) s.loadFolder(MergeState.Side.A, u)
    }
    val pickBZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(MergeState.Side.B, u)
    }
    val pickBFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) s.loadFolder(MergeState.Side.B, u)
    }
    HeroCard(
        title = "Compare two sources and merge",
        text = "Pick A (the base) and B (another version). Each can be a zip or a folder. See what is different, then choose file by file what to take from B. A new zip is saved in Downloads; A and B are never changed.",
        leading = { IconTile(Icons.Filled.Settings, lit = true) },
    )
    Column {
        GroupHeading("Sources")
        RowGroup {
            SourceRow(
                title = "A: the base",
                label = s.aLabel,
                info = s.aInfo,
                shape = cardShape(0, 2),
                busy = s.busy,
                onZip = { pickAZip.launch(arrayOf("*/*")) },
                onFolder = { pickAFolder.launch(null) },
            )
            SourceRow(
                title = "B: the other version",
                label = s.bLabel,
                info = s.bInfo,
                shape = cardShape(1, 2),
                busy = s.busy,
                onZip = { pickBZip.launch(arrayOf("*/*")) },
                onFolder = { pickBFolder.launch(null) },
            )
        }
    }
    if (s.status.isNotEmpty()) Text(s.status, color = MaterialTheme.colorScheme.primary)
    if (s.bothLoaded) {
        Button(
            onClick = { s.swap() },
            enabled = !s.busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Swap A and B") }
    }
    if (s.compared) {
        val changed = s.diffs.count { it.kind == MergeState.Kind.CHANGED }
        val onlyB = s.diffs.count { it.kind == MergeState.Kind.ONLY_B }
        val onlyA = s.diffs.count { it.kind == MergeState.Kind.ONLY_A }
        Column {
            GroupHeading("What is different")
            if (s.diffs.isEmpty()) {
                TextBox("A and B are the same. ${s.same} files match.")
            } else {
                TextBox(
                    "Different in B: $changed\n" +
                        "Only in B (new): $onlyB\n" +
                        "Only in A (not in B): $onlyA\n" +
                        "Same in both: ${s.same}\n\n" +
                        "Chosen to take from B: ${s.picked.size}",
                )
            }
        }
        if (s.diffs.isNotEmpty()) {
            Button(
                onClick = { s.showReview = true },
                enabled = !s.busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Review the differences (${s.diffs.size})") }
        }
    }
    SaveAsField(s.outName) { s.outName = it }
    Button(
        onClick = { s.make() },
        enabled = s.compared && s.picked.isNotEmpty() && s.outName.isNotBlank() && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) "Working..." else "Make merged zip (${s.picked.size} chosen)") }
    ResultBox(s.log)

    if (s.showReview) ReviewWindow(s)
    val d = s.detail
    if (d != null) DetailWindow(s, d)
}

@Composable
private fun ReviewWindow(s: MergeState) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    val shown = remember(s.diffs, query, filter, s.picked) {
        val q = query.trim()
        s.diffs.filter { d ->
            (q.isEmpty() || d.rel.contains(q, ignoreCase = true)) && when (filter) {
                1 -> d.kind == MergeState.Kind.CHANGED
                2 -> d.kind == MergeState.Kind.ONLY_B
                3 -> d.kind == MergeState.Kind.ONLY_A
                4 -> d.rel in s.picked
                else -> true
            }
        }
    }
    CardWindow(title = "Differences", onBack = { s.showReview = false }, scroll = false) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            label = { Text("Search (${shown.size} shown, ${s.picked.size} chosen)") },
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            ChoiceChip("All", filter == 0, onClick = { filter = 0 })
            ChoiceChip("Different", filter == 1, onClick = { filter = 1 })
            ChoiceChip("Only in B", filter == 2, onClick = { filter = 2 })
            ChoiceChip("Only in A", filter == 3, onClick = { filter = 3 })
            ChoiceChip("Chosen", filter == 4, onClick = { filter = 4 })
        }
        if (filter == 3) {
            Text(
                "Choosing a file here leaves it out of the merged zip.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = { s.pickAll(shown.map { it.rel }) },
                enabled = shown.isNotEmpty(),
                modifier = Modifier.weight(1f),
            ) { Text("Choose all shown") }
            Button(
                onClick = { s.clear(shown.map { it.rel }) },
                enabled = shown.isNotEmpty(),
                modifier = Modifier.weight(1f),
            ) { Text("Clear shown") }
        }
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(shown, key = { it.rel }) { d ->
                val on = d.rel in s.picked
                val dir = d.rel.substringBeforeLast('/', "")
                KitRow(
                    title = d.rel.substringAfterLast('/'),
                    shape = RoundedCornerShape(14.dp),
                    summary = d.summary,
                    description = kindLabel(d.kind) + (if (dir.isNotEmpty()) " · $dir" else ""),
                    background = if (on) MaterialTheme.colorScheme.primaryContainer else rowColor(),
                    onClick = { s.toggle(d.rel) },
                    trailing = { Text(actionNow(d, on), fontSize = 12.sp) },
                    footer = {
                        TextButton(
                            onClick = { s.openDetail(d) },
                            modifier = Modifier.padding(start = 6.dp),
                        ) { Text("See what is different") }
                    },
                )
            }
        }
        Button(
            onClick = { s.showReview = false },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Done (${s.picked.size} chosen)") }
    }
}

@Composable
private fun DetailWindow(s: MergeState, d: MergeState.Diff) {
    val lines = s.detailLines
    val on = d.rel in s.picked
    val colours = MaterialTheme.colorScheme
    CardWindow(title = d.rel.substringAfterLast('/'), onBack = { s.detail = null }, scroll = false) {
        Text(
            kindLabel(d.kind) + ": " + d.rel,
            style = MaterialTheme.typography.bodySmall,
            color = colours.onSurfaceVariant,
        )
        Text(d.summary, color = colours.primary, modifier = Modifier.padding(top = 2.dp))
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            if (lines == null) {
                Text("Reading...")
            } else {
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(lines) { line ->
                        val colour = when (line.firstOrNull()) {
                            '+' -> Color(0xFF2E9E4F)
                            '-' -> Color(0xFFD64545)
                            '@' -> colours.primary
                            else -> colours.onSurface
                        }
                        Text(line, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = colour)
                    }
                }
            }
        }
        Button(
            onClick = { s.toggle(d.rel) },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Now: ${actionNow(d, on)}. Tap to change") }
    }
}
