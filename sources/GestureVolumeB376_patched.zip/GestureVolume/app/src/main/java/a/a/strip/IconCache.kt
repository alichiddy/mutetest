package a.a.strip

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper

/**
 * Keeps the cell icons already drawn, so the cells window opens without redoing them.
 *
 * Without it every opening reads each image file and asks the package manager for each app's icon
 * while the finger is down, which is what makes a window with many cells feel heavy. With it only
 * the very first opening pays; later ones take the bitmaps from here.
 *
 * Nothing stays for ever: [keepSec] seconds after the last use everything is dropped, so the app
 * holds no icons while idle. 0 = off (icons are made fresh every time, as before).
 */
object IconCache {
    private val map = HashMap<String, Bitmap?>()
    private val handler = Handler(Looper.getMainLooper())
    private val drop = Runnable { synchronized(map) { map.clear() } }

    fun get(key: String, keepSec: Int, make: () -> Bitmap?): Bitmap? {
        if (keepSec <= 0) return make()
        val hit = synchronized(map) { if (map.containsKey(key)) map[key] else null }
        val bmp = hit ?: make()
        synchronized(map) { map[key] = bmp }
        handler.removeCallbacks(drop)
        handler.postDelayed(drop, keepSec * 1000L)
        return bmp
    }

    fun clear() {
        handler.removeCallbacks(drop)
        synchronized(map) { map.clear() }
    }
}
