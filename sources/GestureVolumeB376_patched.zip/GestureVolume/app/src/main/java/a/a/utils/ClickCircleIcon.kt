package a.a.utils

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * The Click circle's icon: the circle it draws on screen, a ring with a dot in the middle, so the
 * icon in the lists is the thing that appears when the action runs.
 */
object ClickCircleIcon {
    val image: ImageVector by lazy {
        ImageVector.Builder(
            name = "ClickCircle", defaultWidth = 24.dp, defaultHeight = 24.dp, viewportWidth = 24f, viewportHeight = 24f,
        ).apply {
            path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
                // Outer edge of the ring, then its inner edge (the hole), then the dot.
                circle(12f, 12f, 10f)
                circle(12f, 12f, 7.5f)
                circle(12f, 12f, 2.6f)
            }
        }.build()
    }

    private fun androidx.compose.ui.graphics.vector.PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        moveTo(cx - r, cy)
        arcToRelative(r, r, 0f, true, true, 2f * r, 0f)
        arcToRelative(r, r, 0f, true, true, -2f * r, 0f)
        close()
    }
}
