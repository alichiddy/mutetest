package a.a.strip

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import a.a.ui.screens.strip.ItemEditor
import a.a.ui.screens.strip.itemsAt
import a.a.ui.screens.strip.setItemsAt
import a.a.ui.theme.ATheme

/**
 * The editing window of one cell, opened from the cells window itself (option "+ in empty cells", the hold
 * option and the "+ after the last cell"): the same cell editor as inside A, over whatever app is open.
 * Save writes the cell back and closes; Cancel just closes. A new cell ([EXTRA_INDEX] = -1) is only added at
 * the end of its list when it is saved, so cancelling leaves nothing behind.
 *
 * Nothing runs outside the moment it is open.
 */
class CellEditActivity : androidx.activity.ComponentActivity() {

    companion object {
        const val EXTRA_SCOPE = "scope"
        const val EXTRA_PATH = "path"
        const val EXTRA_INDEX = "index"

        /** [scope]: the cells window ("" = the main slider's). [path]: the folders down to the cell's list. [index]: the cell, or -1 for a new one at the end. */
        fun intent(context: Context, scope: String, path: List<Int>, index: Int): Intent =
            Intent(context, CellEditActivity::class.java)
                .putExtra(EXTRA_SCOPE, scope)
                .putExtra(EXTRA_PATH, path.toIntArray())
                .putExtra(EXTRA_INDEX, index)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scope = intent.getStringExtra(EXTRA_SCOPE).orEmpty()
        val path = intent.getIntArrayExtra(EXTRA_PATH)?.toList() ?: emptyList()
        val index = intent.getIntExtra(EXTRA_INDEX, -1)
        val list = itemsAt(StripScope.load(this, scope).items, path)
        val start = list.getOrNull(index) ?: StripItem("", "", "")
        setContent {
            ATheme(darkTheme = isSystemInDarkTheme()) {
                ItemEditor(
                    item = start,
                    onSave = { updated -> save(scope, path, index, updated); finish() },
                    onCancel = { finish() },
                )
            }
        }
    }

    /** Writes the cell the way the cells editor does: the pinned cells settle, and a new blank cell is kept. */
    private fun save(scope: String, path: List<Int>, index: Int, updated: StripItem) {
        val cfg = StripScope.load(this, scope)
        val sp = StripScope.prefs(this, scope)
        val cur = itemsAt(cfg.items, path)
        val isNew = index !in cur.indices
        val list = if (isNew) cur + updated else cur.toMutableList().also { it[index] = updated }
        val blank = updated.action.isEmpty() && updated.label.isEmpty() && updated.icon.isEmpty() && updated.children == null
        val keep = if (isNew && blank) 1 else 0
        val next = cfg.copy(items = setItemsAt(cfg.items, path, list))
        val settled = next.copy(
            items = StripConfig.settlePins(
                next.items, next.columns.coerceIn(1, 16),
                sp.getInt("stripPinFollow", StripConfig.PIN_ALL),
                if (keep > 0) path else null, keep,
            )
        )
        StripScope.save(this, scope, settled)
    }
}
