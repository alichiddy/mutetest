package a.a.ui.screens.strip

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import a.a.ui.motion.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.strip.LookPrefs
import a.a.strip.StripItem
import a.a.strip.StripView
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip

private val SAMPLE = listOf(
    StripItem("Wi-Fi", "📶", "x"), StripItem("Torch", "🔦", "x"), StripItem("Camera", "📷", "x"),
    StripItem("Music", "🎵", "x"), StripItem("Notes", "📝", "x"), StripItem("Maps", "🗺️", "x"),
)

private fun hasContent(list: List<StripItem>): Boolean =
    list.any { it.label.isNotEmpty() || it.icon.isNotEmpty() || it.action.isNotEmpty() }

/** The first folder (looking inside folders too) that has something in it, for the Folders preview. */
private fun firstFolder(list: List<StripItem>): StripItem? {
    for (item in list) {
        val kids = item.children ?: continue
        if (hasContent(kids)) return item
        val deeper = firstFolder(kids)
        if (deeper != null) return deeper
    }
    return null
}

/**
 * "Look of the cells", in the card design of the Cells window: the same live cells window stays at the top while
 * the cards below change it. Two tabs: the cells window, and the windows that open from folders (their own copy
 * of every setting). Only the drawing of this window is new; every setting keeps its name and its stored value.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LookDialog(
    sp: SharedPreferences,
    rootItems: List<StripItem>,
    rootCols: Int,
    sizePct: Int,
    showLabels: Boolean,
    startOnFolders: Boolean,
    onChange: () -> Unit,
    onDismiss: () -> Unit,
) {
    var tab by remember { mutableIntStateOf(if (startOnFolders) 1 else 0) }
    var tick by remember { mutableIntStateOf(0) }
    var resetTick by remember { mutableIntStateOf(0) }
    var bg by remember { mutableIntStateOf(sp.getInt("stripLookPreviewBg", 3)) }
    val folder = tab == 1
    val ctx = LocalContext.current

    fun getInt(name: String, def: Int): Int = sp.getInt(LookPrefs.readKey(sp, folder, name), def)
    fun getBool(name: String, def: Boolean): Boolean = sp.getBoolean(LookPrefs.readKey(sp, folder, name), def)
    fun putInt(name: String, v: Int) { sp.edit().putInt(LookPrefs.writeKey(folder, name), v).apply(); tick++ }
    fun putBool(name: String, v: Boolean) { sp.edit().putBoolean(LookPrefs.writeKey(folder, name), v).apply(); tick++ }
    fun spInt(name: String, v: Int) { sp.edit().putInt(name, v).apply(); tick++ }
    fun spBool(name: String, v: Boolean) { sp.edit().putBoolean(name, v).apply(); tick++ }
    fun finish() { onChange(); onDismiss() }

    Dialog(onDismissRequest = { finish() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().imePadding(), color = MaterialTheme.colorScheme.background) {
            AWindowPage("Look of the cells", onBack = { finish() }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChoiceChip(label = "Cells window", selected = tab == 0, onClick = { tab = 0 })
                        ChoiceChip(label = "Folders", selected = tab == 1, onClick = { tab = 1 })
                    }

                    // ---- the live view ----
                    val folderItem = if (folder) firstFolder(rootItems) else null
                    val realItems = if (folder) folderItem?.children.orEmpty() else rootItems
                    val usingSample = !hasContent(realItems)
                    val items = if (usingSample) SAMPLE else realItems
                    val cols = if (usingSample) 3 else if (folder) (folderItem?.cols ?: 3).coerceIn(1, 8) else rootCols.coerceIn(1, 16)
                    val bgMod = when (bg) {
                        0 -> Modifier.background(Color(0xFF111111))
                        1 -> Modifier.background(Color(0xFF8A8A8A))
                        2 -> Modifier.background(Color.White)
                        else -> Modifier.background(
                            Brush.horizontalGradient(colorStops = arrayOf(0f to Color.Black, 0.5f to Color.Black, 0.5f to Color.White, 1f to Color.White))
                        )
                    }
                    BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(20.dp)).then(bgMod)) {
                        val density = LocalDensity.current
                        val dm = ctx.resources.displayMetrics
                        val screenW = minOf(dm.widthPixels, dm.heightPixels).toFloat()
                        val screenH = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
                        // The size the cells have on the screen (as in the editor), made smaller only to fit this window.
                        val eg = sp.getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                        val rootRows = ((rootItems.size + rootCols.coerceIn(1, 16) - 1) / rootCols.coerceIn(1, 16)).coerceAtLeast(1)
                        val trueCell = minOf(
                            (screenW * 0.94f) / (rootCols.coerceIn(1, 16) * (1f + eg) + eg),
                            screenH * 0.88f / (rootRows * (1f + eg) + eg),
                        ) * sizePct / 100f
                        val g = getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                        val rows = ((items.size + cols - 1) / cols).coerceAtLeast(1)
                        val availW = with(density) { maxWidth.toPx() } * 0.94f
                        val availH = with(density) { 190.dp.toPx() }
                        val cell = minOf(
                            trueCell,
                            availW / (cols * (1f + g) + g),
                            availH / (rows * (1f + g) + g),
                        ).toInt().coerceAtLeast(24)
                        val view = remember(tick, tab, cell, items, cols, showLabels) {
                            StripView(ctx, items, cell, cols, showLabels, folderLook = folder).apply { setScreenOrigin(0f, 0f) }
                        }
                        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                            key(view) {
                                AndroidView(
                                    factory = { view },
                                    modifier = Modifier.requiredSize(
                                        with(density) { view.panelWidthPx.toDp() },
                                        with(density) { view.panelHeightPx.toDp() },
                                    ).pointerInput(view) {
                                        detectTapGestures { off -> view.highlight(view.cellAt(off.x, off.y, exact = true)) }
                                    },
                                )
                            }
                        }
                    }
                    FlowRow(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Text("Behind it:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
                        listOf("Dark", "Grey", "White", "Both").forEachIndexed { i, name ->
                            ChoiceChip(label = name, selected = bg == i, onClick = { bg = i; sp.edit().putInt("stripLookPreviewBg", i).apply() })
                        }
                    }
                    Text(
                        (if (folder) {
                            if (usingSample) "Sample cells (you have no folder with cells yet). " else "Your first folder. "
                        } else if (usingSample) "Sample cells. " else "") +
                            "Tap a cell to light it. This is the same view as in the editor.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 2.dp, bottom = 2.dp),
                    )

                    // ---- the settings of the chosen tab ----
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        key(tab, resetTick) {
                            var look by remember { mutableIntStateOf(getInt("stripLook", 0)) }
                            var halo by remember { mutableStateOf(getBool("stripHalo", false)) }
                            var outline by remember { mutableIntStateOf(getInt("stripOutlineColor", 0)) }
                            var tileBorder by remember { mutableIntStateOf(getInt("stripTileBorderColor", 0)) }
                            var pinDot by remember { mutableStateOf(sp.getBoolean("stripPinDot", true)) }
                            var pinText by remember { mutableStateOf(sp.getBoolean("stripPinText", false)) }
                            var foldPrev by remember { mutableIntStateOf(sp.getInt("stripFoldPreview", 0).coerceIn(0, 2)) }
                            var plate by remember { mutableStateOf(sp.getBoolean("stripFoldPlate", true)) }
                            var foldArrow by remember { mutableStateOf(sp.getBoolean("stripFoldArrow", true)) }

                            CardGroup(
                                "How the cells look",
                                hint = if (folder) "These settings are only for the windows that open from a folder. A setting you have not changed here follows the cells window." else null,
                            ) {
                                row { sh ->
                                    PickCardRow(
                                        "look", "Look", listOf("Tiles (as before)", "Icons only: no tiles, no panel, bigger icons", "Icons only on a very faint dark panel"),
                                        look, sh, Icons.Filled.Palette,
                                    ) { look = it; putInt("stripLook", it) }
                                }
                                if (look == 2) {
                                    row { sh ->
                                        SliderRow("backdropPct", "Opacity of the panel", "%", getInt("stripBackdropPct", 18), 0, 100, sh, summary = "100 = solid") { putInt("stripBackdropPct", it) }
                                    }
                                    row { sh ->
                                        ColorCardRow(
                                            "backdropColor", "Colour of the panel", "Black",
                                            listOf(0xFFFFFFFF.toInt(), 0xFF1F8A8A.toInt(), 0xFF1565C0.toInt(), 0xFF6A1B9A.toInt(), 0xFFC62828.toInt(), 0xFFEF6C00.toInt(), 0xFF2E7D32.toInt(), 0xFF455A64.toInt()),
                                            getInt("stripBackdropColor", 0), sh,
                                        ) { putInt("stripBackdropColor", it) }
                                    }
                                }
                                row { sh ->
                                    SwitchRow(
                                        "Soft dark glow around icons and names", halo, sh, icon = Icons.Filled.Visibility,
                                        summary = "The glow follows the shape of each icon. The cell under the thumb still lights up.",
                                    ) { halo = it; putBool("stripHalo", it) }
                                }
                            }

                            CardGroup("Names under the icons") {
                                row { sh ->
                                    SliderRow(
                                        "labelPct", "Size of the names", "%", getInt("stripLabelPct", 100), 50, 200, sh,
                                        summary = "A very long name is still made smaller so it does not run far into the next cell.",
                                    ) { putInt("stripLabelPct", it) }
                                }
                                row { sh ->
                                    ColorCardRow(
                                        "outlineColor", "Outline round the names", "None",
                                        listOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF0D1B4C.toInt(), 0xFF5A0F0F.toInt(), 0xFF1B3D1B.toInt(), 0xFFFFD600.toInt()),
                                        outline, sh, summary = "So the names read on a white background.",
                                    ) { outline = it; putInt("stripOutlineColor", it) }
                                }
                                if (outline != 0) row { sh ->
                                    SliderRow("outlinePct", "Outline thickness", "%", getInt("stripOutlinePct", 14), 4, 40, sh) { putInt("stripOutlinePct", it) }
                                }
                            }

                            CardGroup("Tiles, icon size and gap", hint = "Each cell and each folder can also have its own tile colour: Cells editor, the cell, Tile colour.") {
                                row { sh ->
                                    ColorCardRow(
                                        "tileColor", "Colour of the cell tiles", "Standard",
                                        TILE_PRESETS,
                                        getInt("stripTileColor", 0), sh, summary = "Not used by the icons-only looks.",
                                    ) { putInt("stripTileColor", it) }
                                }
                                row { sh -> SliderRow("tileAlpha", "Opacity of the tiles", "%", getInt("stripTileAlpha", 100), 0, 100, sh, summary = "100 = solid. 0 = no tile at all, only the icon.") { putInt("stripTileAlpha", it) } }
                                row { sh -> SliderRow("tileRound", "Roundness of the corners", "%", getInt("stripTileRound", 22), 0, 50, sh, summary = "0 = square, 50 = round.") { putInt("stripTileRound", it) } }
                                row { sh ->
                                    ColorCardRow(
                                        "tileBorderColor", "Border colour of the tiles", "None",
                                        listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFB300.toInt(), 0xFF40C4FF.toInt(), 0xFF00E676.toInt(), 0xFFFF5252.toInt(), 0xFFE040FB.toInt()),
                                        tileBorder, sh,
                                    ) { tileBorder = it; putInt("stripTileBorderColor", it) }
                                }
                                if (tileBorder != 0) row { sh -> SliderRow("tileBorderDp", "Border width", " dp", getInt("stripTileBorderDp", 2), 1, 8, sh) { putInt("stripTileBorderDp", it) } }
                                row { sh ->
                                    ColorCardRow(
                                        "litColor", "Colour of the cell under the thumb", "Orange",
                                        listOf(0xFFFFFFFF.toInt(), 0xFF40C4FF.toInt(), 0xFF00E676.toInt(), 0xFFFF5252.toInt(), 0xFFE040FB.toInt(), 0xFFFFD600.toInt()),
                                        getInt("stripLitColor", 0), sh, summary = "The tile that lights up while the thumb is on it.",
                                    ) { putInt("stripLitColor", it) }
                                }
                                row { sh -> SliderRow("iconPct", "Icon size", "%", getInt("stripIconPct", 100), 50, 170, sh, Icons.Filled.Tune) { putInt("stripIconPct", it) } }
                                row { sh -> SliderRow("gapPct", "Gap between the cells", "%", getInt("stripGapPct", 8), 0, 40, sh) { putInt("stripGapPct", it) } }
                            }

                            // (the icon size and the gap stay in the group above)
                            // Pinned cells (same for the cells window and the folders).
                            CardGroup("Pinned cells", hint = "📌 Pin, in the cells editor.") {
                                row { sh ->
                                    PickCardRow(
                                        "pinFollow", "A pinned cell in the bottom row", listOf("Follows the bottom row (blank cells fill the gap)", "Only pinned folders follow the bottom row", "Never follows: it stays on its own row"),
                                        sp.getInt("stripPinFollow", 0).coerceIn(0, 2), sh, summary = "What happens when a new row is added.",
                                    ) { spInt("stripPinFollow", it) }
                                }
                                row { sh -> SwitchRow("Small dot on a pinned cell", pinDot, sh) { pinDot = it; spBool("stripPinDot", it) } }
                                if (pinDot) {
                                    row { sh -> SliderRow("pinDotPx", "Dot size", "", sp.getInt("stripPinDotPx", 5), 1, 12, sh) { spInt("stripPinDotPx", it) } }
                                    row { sh ->
                                        PickCardRow(
                                            "pinDotCorner", "Corner of the cell for the dot", listOf("Top left", "Top right", "Bottom left", "Bottom right"),
                                            sp.getInt("stripPinDotCorner", 0).coerceIn(0, 3), sh,
                                        ) { spInt("stripPinDotCorner", it) }
                                    }
                                    row { sh -> SliderRow("pinDotX", "Distance from the side", " dp", sp.getInt("stripPinDotX", 3), 0, 24, sh) { spInt("stripPinDotX", it) } }
                                    row { sh -> SliderRow("pinDotY", "Distance from the top or bottom", " dp", sp.getInt("stripPinDotY", 3), 0, 24, sh) { spInt("stripPinDotY", it) } }
                                    row { sh ->
                                        ColorCardRow(
                                            "pinDotColor", "Dot colour", "Red",
                                            listOf(0xFFFFD600.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                                            sp.getInt("stripPinDotColor", 0).let { if (it == 0xFFFF5252.toInt()) 0 else it }, sh,
                                        ) { spInt("stripPinDotColor", if (it == 0) 0xFFFF5252.toInt() else it) }
                                    }
                                }
                                row { sh -> SwitchRow("Change the text colour of a pinned cell too", pinText, sh) { pinText = it; spBool("stripPinText", it) } }
                                if (pinText) row { sh ->
                                    ColorCardRow(
                                        "pinTextColor", "Text colour of pinned cells", "Yellow",
                                        listOf(0xFFFF5252.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                                        sp.getInt("stripPinTextColor", 0).let { if (it == 0xFFFFD600.toInt()) 0 else it }, sh,
                                    ) { spInt("stripPinTextColor", if (it == 0) 0xFFFFD600.toInt() else it) }
                                }
                            }

                            // The mark on a folder cell and what a folder cell shows (same for the cells window and the folders).
                            CardGroup("Folder cells") {
                                row { sh ->
                                    PickCardRow(
                                        "foldPreview", "Picture of a folder", listOf("Its own icon", "The first 4 apps inside (when it has no icon of its own)", "The first 4 apps inside, always"),
                                        foldPrev, sh,
                                    ) { foldPrev = it; spInt("stripFoldPreview", it) }
                                }
                                if (foldPrev != 0) {
                                    row { sh -> SwitchRow("Soft plate behind the 4 apps", plate, sh) { plate = it; spBool("stripFoldPlate", it) } }
                                    row { sh -> SliderRow("foldMiniPct", "Size of the 4 small icons", "%", sp.getInt("stripFoldMiniPct", 100), 40, 140, sh) { spInt("stripFoldMiniPct", it) } }
                                }
                                row { sh -> SwitchRow("Mark on a folder cell (the arrow)", foldArrow, sh) { foldArrow = it; spBool("stripFoldArrow", it) } }
                                if (foldArrow) {
                                    row { sh ->
                                        PickCardRow(
                                            "foldArrowShape", "Shape of the mark", listOf("Corner triangle", "Dot", "Square", "Arrow right", "Arrow down", "Diamond"),
                                            sp.getInt("stripFoldArrowShape", 0).coerceIn(0, 5), sh,
                                        ) { spInt("stripFoldArrowShape", it) }
                                    }
                                    row { sh -> SliderRow("foldArrowPct", "Size of the mark", "%", sp.getInt("stripFoldArrowPct", 20), 8, 45, sh) { spInt("stripFoldArrowPct", it) } }
                                    row { sh ->
                                        PickCardRow(
                                            "foldArrowCorner", "Corner of the cell for the mark", listOf("Top left", "Top right", "Bottom left", "Bottom right"),
                                            sp.getInt("stripFoldArrowCorner", 3).coerceIn(0, 3), sh,
                                        ) { spInt("stripFoldArrowCorner", it) }
                                    }
                                    row { sh -> SliderRow("foldArrowX", "Distance from the side", " dp", sp.getInt("stripFoldArrowX", 2), 0, 40, sh) { spInt("stripFoldArrowX", it) } }
                                    row { sh -> SliderRow("foldArrowY", "Distance from the top or bottom", " dp", sp.getInt("stripFoldArrowY", 2), 0, 40, sh) { spInt("stripFoldArrowY", it) } }
                                    row { sh ->
                                        ColorCardRow(
                                            "foldArrowColor", "Colour of the mark", "Same as the text",
                                            listOf(0xFFFFD600.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFFFF5252.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                                            sp.getInt("stripFoldArrowColor", 0), sh,
                                        ) { spInt("stripFoldArrowColor", it) }
                                    }
                                }
                            }

                            if (folder) {
                                OutlinedButton(
                                    onClick = { LookPrefs.clearFolders(sp); resetTick++; tick++ },
                                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                                ) { Text("Folders follow the cells window again (clear all folder settings)") }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        sp.edit().remove("stripTileColor").remove("stripTileAlpha").remove("stripTileRound").remove("stripTileBorderColor")
                                            .remove("stripTileBorderDp").remove("stripLitColor").putInt("stripIconPct", 100).putInt("stripGapPct", 8)
                                            .putInt("stripLabelPct", 100).remove("stripOutlineColor").putInt("stripOutlinePct", 14).apply()
                                        resetTick++; tick++
                                    },
                                    modifier = Modifier.fillMaxWidth().padding(top = 18.dp),
                                ) { Text("Reset colour, tiles, icon size, gap, name size and outline") }
                            }
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}

/** A number on a slider, in its own row of the card: the value sits at the end of the title. */
@Composable
internal fun SliderRow(
    id: String, title: String, unit: String, initial: Int, min: Int, max: Int, shape: Shape,
    icon: ImageVector? = null, summary: String? = null, onValue: (Int) -> Unit,
) {
    key(id) {
        var v by remember { mutableIntStateOf(initial.coerceIn(min, max)) }
        SettingRow(
            title, shape, icon = icon, summary = summary,
            trailing = {
                Text("$v$unit", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            },
            footer = {
                Slider(
                    value = v.toFloat(), valueRange = min.toFloat()..max.toFloat(),
                    onValueChange = { v = it.toInt(); onValue(v) },
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 4.dp),
                )
            },
        )
    }
}

/** One choice out of a few, as chips under the title, in its own row of the card. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun PickCardRow(
    id: String, title: String, names: List<String>, initial: Int, shape: Shape,
    icon: ImageVector? = null, summary: String? = null, onPick: (Int) -> Unit,
) {
    key(id) {
        var cur by remember { mutableIntStateOf(initial) }
        SettingRow(
            title, shape, icon = icon, summary = summary,
            footer = {
                FlowRow(
                    Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    names.forEachIndexed { n, name ->
                        ChoiceChip(label = name, selected = cur == n, onClick = { cur = n; onPick(n) })
                    }
                }
            },
        )
    }
}

/** A colour out of a few, or typed in as hex, in its own row of the card; the first swatch is the "none" one. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ColorCardRow(
    id: String, title: String, noneLabel: String, colors: List<Int>, initial: Int, shape: Shape,
    icon: ImageVector? = null, summary: String? = null, onPick: (Int) -> Unit,
) {
    key(id) {
        var cur by remember { mutableIntStateOf(initial) }
        var hex by remember { mutableStateOf(if (initial == 0) "" else String.format("%06X", initial and 0xFFFFFF)) }
        SettingRow(
            title, shape, icon = icon, summary = summary,
            trailing = {
                Box(
                    Modifier.size(26.dp).clip(RoundedCornerShape(8.dp))
                        .background(if (cur == 0) MaterialTheme.colorScheme.surface else Color(cur))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                )
            },
            footer = {
                FlowRow(
                    Modifier.padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    (listOf(0) + colors).forEach { c ->
                        Box(
                            Modifier.height(32.dp).defaultMinSize(minWidth = 32.dp).clip(RoundedCornerShape(8.dp))
                                .background(if (c == 0) MaterialTheme.colorScheme.surface else Color(c))
                                .border(
                                    if (cur == c) 3.dp else 1.dp,
                                    if (cur == c) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(8.dp),
                                )
                                .clickable {
                                    cur = c; hex = if (c == 0) "" else String.format("%06X", c and 0xFFFFFF)
                                    onPick(c)
                                }.padding(horizontal = if (c == 0) 8.dp else 0.dp),
                            contentAlignment = Alignment.Center,
                        ) { if (c == 0) Text(noneLabel, fontSize = 12.sp) }
                    }
                }
                var picker by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = { picker = !picker },
                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
                ) { Text(if (picker) "Hide the colour picker" else "Colour picker") }
                if (picker) HsvPicker(
                    if (cur == 0) 0xFF1F8A8A.toInt() else cur,
                    Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 8.dp),
                ) { c ->
                    cur = c; hex = String.format("%06X", c and 0xFFFFFF)
                    onPick(c)
                }
                OutlinedTextField(
                    value = hex, singleLine = true, label = { Text("Your own colour (hex, like 1F8A8A)") },
                    onValueChange = { v ->
                        hex = v.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }.take(6)
                        if (hex.length == 6) {
                            cur = (0xFF000000L or hex.toLong(16)).toInt()
                            onPick(cur)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                )
            },
        )
    }
}

/** The presets for a tile colour. */
internal val TILE_PRESETS = listOf(
    0xFF1F8A8A.toInt(), 0xFF1565C0.toInt(), 0xFF6A1B9A.toInt(), 0xFFC62828.toInt(), 0xFFEF6C00.toInt(), 0xFF2E7D32.toInt(),
    0xFF455A64.toInt(), 0xFF000000.toInt(), 0xFFFFB300.toInt(), 0xFFD81B60.toInt(), 0xFF9E9E9E.toInt(), 0xFFFFFFFF.toInt(),
)

/** A small colour picker: shade (hue), strength (saturation) and brightness, three bars. Gives the colour as ARGB. */
@Composable
internal fun HsvPicker(start: Int, modifier: Modifier = Modifier, onPick: (Int) -> Unit) {
    val init = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(start, it) } }
    var h by remember { mutableStateOf(init[0]) }
    var sat by remember { mutableStateOf(init[1]) }
    var v by remember { mutableStateOf(init[2]) }
    fun push() { onPick(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v))) }
    Column(modifier) {
        Text("Shade", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = h, valueRange = 0f..360f, onValueChange = { h = it; push() })
        Text("Strength", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = sat, valueRange = 0f..1f, onValueChange = { sat = it; push() })
        Text("Brightness", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = v, valueRange = 0f..1f, onValueChange = { v = it; push() })
    }
}
