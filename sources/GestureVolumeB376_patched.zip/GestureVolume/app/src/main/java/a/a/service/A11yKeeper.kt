package a.a.service

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import a.a.data.local.SharedPref
import a.a.utils.DiagLog

/**
 * Option "Put A back into the accessibility list if something removes it" (pref [PREF], off by default).
 *
 * Something (another app, or the phone's battery manager) sometimes rewrites the system list of
 * enabled accessibility services without A in it, and the system then disconnects A. With the option
 * on, a watcher on that one setting writes A back at once and the report says what the list was
 * before and after. Needs WRITE_SECURE_SETTINGS (one-time grant); without it nothing is changed and
 * the report says so. The watcher exists only while the service is connected and the option is on.
 * Safety: at most 3 write-backs in a minute, then it rests 10 minutes, so it never fights the user
 * for long. Turn the option off before switching A off on purpose.
 */
object A11yKeeper {
    const val PREF = "keepA11yOn"
    private const val WSS = "android.permission.WRITE_SECURE_SETTINGS"
    private const val KEY = Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES

    private var observer: ContentObserver? = null
    private var lastList: String = ""
    private val stamps = ArrayDeque<Long>()
    private var restUntil = 0L

    fun isOn(c: Context) = SharedPref(c).sharedPreferences.getBoolean(PREF, false)

    fun canWrite(c: Context) = c.checkSelfPermission(WSS) == PackageManager.PERMISSION_GRANTED

    private fun read(c: Context): String =
        runCatching { Settings.Secure.getString(c.contentResolver, KEY) }.getOrNull() ?: ""

    private fun has(list: String, me: ComponentName) =
        list.split(':').any { it.isNotEmpty() && ComponentName.unflattenFromString(it) == me }

    /** Starts or stops the watcher to match the option. Call when the service connects and when the switch changes. */
    @Synchronized
    fun sync(context: Context) {
        val c = context.applicationContext
        stop(c)
        if (!isOn(c) || OverlayRuntime.accessibilityService == null) return
        lastList = read(c)
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) = changed(c, "list changed")
        }
        runCatching { c.contentResolver.registerContentObserver(Settings.Secure.getUriFor(KEY), false, o) }
        observer = o
        DiagLog.persist(c, "keeper ON (write permission: ${canWrite(c)})")
    }

    @Synchronized
    fun stop(context: Context) {
        val o = observer ?: return
        runCatching { context.applicationContext.contentResolver.unregisterContentObserver(o) }
        observer = null
    }

    /** Also called from the service's disconnect, in case the system got there before the watcher. */
    fun changed(context: Context, why: String) {
        val c = context.applicationContext
        if (!isOn(c)) return
        val now = read(c)
        if (now != lastList) {
            val before = lastList.split(':').filter { it.isNotEmpty() }.toSet()
            val after = now.split(':').filter { it.isNotEmpty() }.toSet()
            DiagLog.persist(c, "keeper: $why; removed=${before - after}; added=${after - before}")
            lastList = now
        }
        val me = ComponentName(c, a.a.S::class.java)
        if (has(now, me)) return
        if (!canWrite(c)) {
            DiagLog.persist(c, "keeper: A is not in the list but the write permission is missing")
            return
        }
        val t = System.currentTimeMillis()
        if (t < restUntil) return
        while (stamps.isNotEmpty() && t - stamps.first() > 60_000) stamps.removeFirst()
        if (stamps.size >= 3) {
            restUntil = t + 10 * 60_000
            stamps.clear()
            DiagLog.persist(c, "keeper: 3 write-backs in a minute, resting 10 minutes")
            return
        }
        stamps.addLast(t)
        val fixed = (if (now.isEmpty()) me.flattenToString() else now + ":" + me.flattenToString())
        val ok = runCatching {
            Settings.Secure.putString(c.contentResolver, KEY, fixed)
            Settings.Secure.putInt(c.contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
        }.isSuccess
        lastList = if (ok) fixed else now
        DiagLog.persist(c, "keeper: A was missing, put back = $ok; list now: $fixed")
    }
}
