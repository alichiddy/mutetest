package a.a.flow

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import a.a.flow.NativeActions.Need
import a.a.service.OverlayRuntime
import a.a.utils.ShizukuShell

/**
 * The shortcuts Swiftly Switch has and A did not. They are ordinary device actions ("N:<id>"), so they
 * show in the one Built-in shortcuts list, in cells, segments, scripts and search. Where Shizuku makes an
 * action better it is used when ready; otherwise the plain Android way runs (a settings page opens).
 */
object SwiftlyActions {
    fun register(def: (id: String, label: String, need: Need, help: String, run: (NativeActions.Ctx) -> String) -> Unit) {
        // ---- dark theme
        for ((suffix, mode) in listOf("toggle" to 2, "on" to 1, "off" to 0)) {
            def("dark_$suffix", "Dark theme: $suffix", Need.BETTER, "With Shizuku it switches at once; without it the Display settings open.") { ctx ->
                val now = (ctx.context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
                val want = when (mode) { 0 -> false; 1 -> true; else -> !now }
                if (ShizukuShell.isReady()) {
                    NativeActions.sh("cmd uimode night " + if (want) "yes" else "no")
                    "Dark theme " + if (want) "on" else "off"
                } else openIntent(ctx.context, Intent(Settings.ACTION_DISPLAY_SETTINGS), "Opened Display settings: Android does not let apps change the theme alone.")
            }
        }

        // ---- NFC (Shizuku can switch it; without it the NFC settings open)
        for ((suffix, mode) in listOf("toggle" to 2, "on" to 1, "off" to 0)) {
            def("nfc_$suffix", "NFC: $suffix", Need.BETTER, "With Shizuku it switches at once; without it the NFC settings open.") { ctx ->
                val adapter = android.nfc.NfcAdapter.getDefaultAdapter(ctx.context)
                    ?: throw IllegalStateException("This phone has no NFC.")
                val want = when (mode) { 0 -> false; 1 -> true; else -> !adapter.isEnabled }
                if (ShizukuShell.isReady()) {
                    NativeActions.sh("svc nfc " + if (want) "enable" else "disable")
                    "NFC " + if (want) "on" else "off"
                } else openIntent(ctx.context, Intent(Settings.ACTION_NFC_SETTINGS), "Opened NFC settings: Android does not let apps change this alone.")
            }
        }

        // ---- clean RAM
        def("clean_ram", "Clean RAM", Need.BETTER, "Stops the background processes of your apps (A stays). With Shizuku it also clears every cached process.") { ctx ->
            val c = ctx.context
            val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            fun free(): Long = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem
            val before = free()
            val keep = HashSet<String>().apply {
                add(c.packageName)
                Settings.Secure.getString(c.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.substringBefore('/')?.let { add(it) }
                c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName?.let { add(it) }
            }
            runCatching {
                for (ai in c.packageManager.getInstalledApplications(0)) {
                    if (ai.packageName in keep) continue
                    if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) continue
                    runCatching { am.killBackgroundProcesses(ai.packageName) }
                }
            }
            if (ShizukuShell.isReady()) runCatching { NativeActions.sh("am kill-all") }
            Thread.sleep(600)
            val gained = (free() - before) / (1024 * 1024)
            if (gained > 0) "RAM cleaned: about $gained MB freed" else "RAM cleaned"
        }

        // ---- screen rotation (one entry, the way is chosen when picking it)
        def("rotation", "Screen rotation", Need.ONCE, "Argument: auto, portrait, landscape, portrait-reverse, landscape-reverse or toggle. Needs 'Modify system settings' for A (or Shizuku).") { ctx ->
            val c = ctx.context
            if (!Settings.System.canWrite(c) && !ShizukuShell.isReady()) {
                runCatching { c.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                throw IllegalStateException("Allow 'Modify system settings' for A first (or start Shizuku).")
            }
            fun put(key: String, v: Int) {
                val ok = Settings.System.canWrite(c) && runCatching { Settings.System.putInt(c.contentResolver, key, v) }.getOrDefault(false)
                if (!ok) NativeActions.sh("settings put system $key $v")
            }
            val autoNow = Settings.System.getInt(c.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 1
            when (ctx.arg.lowercase()) {
                "auto" -> { put("accelerometer_rotation", 1); "Rotation: automatic" }
                "toggle" -> { put("accelerometer_rotation", if (autoNow) 0 else 1); "Rotation: " + if (autoNow) "locked" else "automatic" }
                "landscape" -> { put("accelerometer_rotation", 0); put("user_rotation", 1); "Rotation: landscape" }
                "portrait-reverse" -> { put("accelerometer_rotation", 0); put("user_rotation", 2); "Rotation: portrait upside down" }
                "landscape-reverse" -> { put("accelerometer_rotation", 0); put("user_rotation", 3); "Rotation: landscape reversed" }
                else -> { put("accelerometer_rotation", 0); put("user_rotation", 0); "Rotation: portrait" }
            }
        }

        // ---- ringer mode
        def("ringer", "Ringer mode", Need.NONE, "Argument: sound, vibrate, silent, sound-vibrate (cycle) or sound-silent (cycle). Silent needs Do Not Disturb access (or Shizuku).") { ctx ->
            val am = ctx.context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            fun setMode(m: Int, name: String): String {
                val ok = runCatching { am.ringerMode = m }.isSuccess && am.ringerMode == m
                if (!ok && ShizukuShell.isReady()) runCatching { NativeActions.sh("cmd audio set-ringer-mode " + name.uppercase()) }
                return if (am.ringerMode == m) "Ringer: $name" else throw IllegalStateException("Could not set $name. Allow Do Not Disturb access for A, or start Shizuku.")
            }
            val now = am.ringerMode
            when (ctx.arg.lowercase()) {
                "vibrate" -> setMode(AudioManager.RINGER_MODE_VIBRATE, "vibrate")
                "silent" -> setMode(AudioManager.RINGER_MODE_SILENT, "silent")
                "sound-vibrate" -> if (now == AudioManager.RINGER_MODE_NORMAL) setMode(AudioManager.RINGER_MODE_VIBRATE, "vibrate") else setMode(AudioManager.RINGER_MODE_NORMAL, "sound")
                "sound-silent" -> if (now == AudioManager.RINGER_MODE_NORMAL) setMode(AudioManager.RINGER_MODE_SILENT, "silent") else setMode(AudioManager.RINGER_MODE_NORMAL, "sound")
                else -> setMode(AudioManager.RINGER_MODE_NORMAL, "sound")
            }
        }

        // ---- accessibility-only system actions
        def("split_screen", "Split screen", Need.NONE, "Needs the accessibility service (A's).") { ctx ->
            val s = OverlayRuntime.accessibilityService ?: throw IllegalStateException("Turn on A's accessibility service first.")
            if (!runCatching { s.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN) }.getOrDefault(false))
                throw IllegalStateException("This phone refused split screen (open an app first).")
            "Split screen"
        }
        def("circle_search", "Circle to Search", Need.BETTER, "Best effort: with Shizuku it long-presses Home (the way the phone starts Circle to Search); otherwise it opens the assistant.") { ctx ->
            if (ShizukuShell.isReady()) {
                NativeActions.sh("input keyevent --longpress 3")
                "Circle to Search"
            } else openIntent(ctx.context, Intent(Intent.ACTION_ASSIST), "Opened the assistant (this phone has no way to start Circle to Search without Shizuku).")
        }

        // ---- openers (no permission needed)
        def("open_calllog", "Call logs", Need.NONE, "") { ctx ->
            openIntent(ctx.context, Intent(Intent.ACTION_VIEW).setType("vnd.android.cursor.dir/calls"), "Call logs")
        }
        def("open_dialer", "Dialer", Need.NONE, "") { ctx -> openIntent(ctx.context, Intent(Intent.ACTION_DIAL), "Dialer") }
        def("open_contacts", "Contacts", Need.NONE, "") { ctx ->
            val c = ctx.context
            val main = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS)
            if (main.resolveActivity(c.packageManager) != null) openIntent(c, main, "Contacts")
            else openIntent(c, Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/")), "Contacts")
        }
        def("open_calendar", "Calendar", Need.NONE, "") { ctx ->
            openIntent(ctx.context, Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR), "Calendar")
        }
        def("open_recorder", "Record audio", Need.NONE, "Opens the phone's sound recorder.") { ctx ->
            openIntent(ctx.context, Intent(android.provider.MediaStore.Audio.Media.RECORD_SOUND_ACTION), "Sound recorder")
        }
        def("copy_report", "Copy report", Need.NONE, "Copies the report to the clipboard at once, using the options last saved in the Copy report window. It does not open that window.") { ctx ->
            val app = ctx.context.applicationContext
            // The copy and its toasts need the main thread; the report itself is read off it inside ReportCopier.
            android.os.Handler(android.os.Looper.getMainLooper()).post { a.a.ui.screens.main.ReportCopier.copySaved(app) }
            "Copying report"
        }
        def("open_storage", "Storage", Need.NONE, "Opens the Files app at the phone's storage; if that fails, the storage settings.") { ctx ->
            val c = ctx.context
            val browse = Intent(Intent.ACTION_VIEW).setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/root/primary"), "vnd.android.document/root",
            )
            if (browse.resolveActivity(c.packageManager) != null && runCatching { launch(c, browse) }.isSuccess) "Storage"
            else openIntent(c, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS), "Storage settings")
        }
    }

    private fun launch(c: Context, i: Intent) { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    /** Starts the intent; says plainly when no app on the phone can handle it. */
    private fun openIntent(c: Context, i: Intent, ok: String): String {
        try { launch(c, i) } catch (e: Exception) { throw IllegalStateException("No app on this phone can open this ($ok).") }
        return ok
    }
}
