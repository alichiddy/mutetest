package a.a.ui.screens.strip

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.ChoiceChip
import a.a.ui.components.GroupHeading
import a.a.ui.components.IconTile
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor

/*
 * The rows of the Cells window, in the design of the Actions and Visibility screens and the home screen: a
 * heading in the accent, rows joined into one card, a tile with each row's picture, a short title with what it
 * does under it, and the switch, the - and + or the chips at the end. The whole row is the thing to tap.
 * A long explanation goes behind the small "Info" arrow that sits right after the title.
 */

/** The rows of one group, collected so each can be told its shape in the card. */
internal class RowsBuilder {
    val list = ArrayList<@Composable (Shape) -> Unit>()
    fun row(content: @Composable (Shape) -> Unit) { list.add(content) }
}

/** A heading, an optional line under it, and the rows under that joined into one card. */
@Composable
internal fun CardGroup(title: String, hint: String? = null, modifier: Modifier = Modifier, build: RowsBuilder.() -> Unit) {
    val rows = RowsBuilder().apply(build).list
    if (rows.isEmpty()) return
    Column(modifier.fillMaxWidth().padding(top = 14.dp)) {
        GroupHeading(title, hint = hint)
        RowGroup { rows.forEachIndexed { i, r -> r(cardShape(i, rows.size)) } }
    }
}

/** The small "▾ Info" arrow that sits right after a title; the caller shows the text it opens. */
@Composable
internal fun InfoArrow(open: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        if (open) "▴ Hide info" else "▾ Info", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
        modifier = modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

/**
 * One row: [icon] on its tile (lit while [lit]), a [title], what it does in [summary], more behind [info],
 * [trailing] at the end, and [footer] under the row inside the same card. [compact] is for rows in a dialog.
 */
@Composable
internal fun SettingRow(
    title: String,
    shape: Shape,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    lit: Boolean = false,
    summary: String? = null,
    info: String? = null,
    compact: Boolean = false,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable RowScope.() -> Unit)? = null,
    footer: (@Composable ColumnScope.() -> Unit)? = null,
) {
    val colours = MaterialTheme.colorScheme
    var infoOpen by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth().clip(shape).background(rowColor())) {
        Row(
            Modifier.fillMaxWidth()
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                .padding(horizontal = 14.dp, vertical = if (compact) 8.dp else 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                IconTile(icon, lit = lit, size = if (compact) 38.dp else 46.dp)
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        title, fontSize = if (compact) 14.sp else 16.sp,
                        fontWeight = if (compact) FontWeight.Medium else FontWeight.SemiBold,
                        color = colours.onSurface, modifier = Modifier.weight(1f, fill = false),
                    )
                    if (info != null) InfoArrow(infoOpen, { infoOpen = !infoOpen })
                }
                if (summary != null) Text(
                    summary, style = MaterialTheme.typography.bodySmall, color = colours.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp),
                )
                if (info != null && infoOpen) Text(
                    info, style = MaterialTheme.typography.bodySmall, color = colours.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            if (trailing != null) {
                Spacer(Modifier.width(10.dp))
                trailing()
            }
        }
        footer?.invoke(this)
    }
}

/** Something on or off: the whole row is the switch. */
@Composable
internal fun SwitchRow(
    title: String, checked: Boolean, shape: Shape, modifier: Modifier = Modifier,
    icon: ImageVector? = null, summary: String? = null, info: String? = null, compact: Boolean = false,
    onChange: (Boolean) -> Unit,
) {
    SettingRow(
        title, shape, modifier, icon = icon, lit = checked, summary = summary, info = info, compact = compact,
        onClick = { onChange(!checked) },
        trailing = { Switch(checked = checked, onCheckedChange = null) },
    )
}

/** A round - or + button, in the accent while it can be used. */
@Composable
internal fun StepButton(symbol: String, enabled: Boolean = true, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier.size(36.dp).clip(RoundedCornerShape(18.dp))
            .background(if (enabled) c.primaryContainer else c.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(symbol, fontSize = 18.sp, color = if (enabled) c.primary else c.outline) }
}

/** A number or a word that goes down and up: − and + around its value. */
@Composable
internal fun StepRow(
    title: String, value: String, shape: Shape, onMinus: () -> Unit, onPlus: () -> Unit,
    modifier: Modifier = Modifier, icon: ImageVector? = null, summary: String? = null, info: String? = null, compact: Boolean = false,
) {
    SettingRow(
        title, shape, modifier, icon = icon, summary = summary, info = info, compact = compact,
        trailing = {
            StepButton("−", onClick = onMinus)
            Text(
                value, Modifier.width(64.dp), textAlign = TextAlign.Center, fontSize = 14.sp,
                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary,
            )
            StepButton("+", onClick = onPlus)
        },
    )
}

/** Buttons that each turn on or off by themselves (selected = on) under a title, inside the card. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ChipsCardRow(
    title: String, options: List<Pair<String, Boolean>>, shape: Shape, onToggle: (Int) -> Unit,
    modifier: Modifier = Modifier, icon: ImageVector? = null, summary: String? = null, info: String? = null,
    below: (@Composable ColumnScope.() -> Unit)? = null,
) {
    SettingRow(
        title, shape, modifier, icon = icon, summary = summary, info = info,
        footer = {
            FlowRow(
                Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) { options.forEachIndexed { n, (name, on) -> ChoiceChip(label = name, selected = on, onClick = { onToggle(n) }) } }
            if (below != null) Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp), content = below)
        },
    )
}

/** Chips with an optional small title, outside a card (inside a dialog or beside other things). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ChipsRow(title: String?, options: List<Pair<String, Boolean>>, onToggle: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        if (title != null) Text(title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { n, (name, on) -> ChoiceChip(label = name, selected = on, onClick = { onToggle(n) }) }
        }
    }
}

/** A way to another window or dialog: its tile, a title, what it holds, and a chevron. */
@Composable
internal fun LinkRow(title: String, summary: String, shape: Shape, icon: ImageVector? = null, onClick: () -> Unit) {
    SettingRow(title, shape, icon = icon, summary = summary, onClick = onClick, trailing = { a.a.ui.components.Chevron() })
}

private val DIALOG_ROW = RoundedCornerShape(16.dp)

/** A switch in a dialog or beside other things: its own small card. */
@Composable
internal fun ToggleRow(title: String, value: Boolean, onChange: (Boolean) -> Unit) {
    SwitchRow(title, value, DIALOG_ROW, Modifier.padding(vertical = 2.dp), compact = true, onChange = onChange)
}

/** A − and + in a dialog or beside other things: its own small card. */
@Composable
internal fun StepperRow(title: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    StepRow(title, value, DIALOG_ROW, onMinus, onPlus, Modifier.padding(vertical = 2.dp), compact = true)
}

/** A switch with its Info arrow in the same line, for the narrow column beside the outside-field counts. */
@Composable
internal fun OptSwitch(text: String, value: Boolean, info: String? = null, onChange: (Boolean) -> Unit) {
    SwitchRow(text, value, DIALOG_ROW, Modifier.padding(vertical = 2.dp), info = info, compact = true, onChange = onChange)
}
