package a.a.strip

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File

/** A cell's icon as a picture: copied to the clipboard on a short tap, saved to Downloads on a long tap. */
object IconExport {
    private const val SIZE = 256

    /** The icon drawn at 256 px on a transparent background, or null when there is nothing to draw. */
    fun render(context: Context, item: StripItem): Bitmap? {
        val pkg = item.appIconPackage
        val file = item.iconFile
        if (file != null) {
            val f = File(context.filesDir, "sicons/$file")
            val b = if (f.isFile) runCatching { android.graphics.BitmapFactory.decodeFile(f.path) }.getOrNull() else null
            if (b != null) return b
        }
        if (pkg != null) {
            return runCatching { context.packageManager.getApplicationIcon(pkg).toBitmap(SIZE, SIZE) }.getOrNull()
        }
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (item.icon == FitText.NONE) {
            FitText.draw(c, Paint(Paint.ANTI_ALIAS_FLAG), item.label, android.graphics.RectF(0f, 0f, SIZE.toFloat(), SIZE.toFloat()), Color.BLACK)
            return bmp
        }
        if (item.icon.isNotEmpty()) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = SIZE * 0.78f; textAlign = Paint.Align.CENTER }
            val y = SIZE / 2f - (p.descent() + p.ascent()) / 2f
            c.drawText(item.icon, SIZE / 2f, y, p)
            return bmp
        }
        return null
    }

    fun copy(context: Context, item: StripItem) {
        val bmp = render(context, item)
        if (bmp == null) { Toast.makeText(context, "No picture icon to copy", Toast.LENGTH_SHORT).show(); return }
        val ok = runCatching {
            val dir = File(context.cacheDir, "icons").apply { mkdirs() }
            val f = File(dir, "icon.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", f)
            val cm = context.getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newUri(context.contentResolver, "icon", uri))
        }.isSuccess
        Toast.makeText(context, if (ok) "Icon copied" else "Could not copy the icon", Toast.LENGTH_SHORT).show()
    }

    fun saveToDownloads(context: Context, item: StripItem) {
        val bmp = render(context, item)
        if (bmp == null) { Toast.makeText(context, "No picture icon to save", Toast.LENGTH_SHORT).show(); return }
        val base = item.label.replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().take(24).ifEmpty { "icon" }
        val name = "$base icon.png"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "image/png")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val ok = runCatching {
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            context.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }.isSuccess
        Toast.makeText(context, if (ok) "Saved in Downloads as $name" else "Could not save", Toast.LENGTH_SHORT).show()
    }
}
