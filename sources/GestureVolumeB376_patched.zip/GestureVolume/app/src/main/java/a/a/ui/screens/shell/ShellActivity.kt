package a.a.ui.screens.shell

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import a.a.adb.AdbConnection
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CopyAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import a.a.ui.motion.IconButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.utils.ShizukuShell
import a.a.utils.ShellFeedback

/**
 * A plain shell: type a command, watch its output as it appears. Shizuku's privilege when allowed.
 * The screen is the command box, the Run button, a row of small tools and the output; where it runs (this phone with
 * Shizuku, or another device by OTG cable), the Enter key and the shortcut feedback are in the options window.
 */
class ShellActivity : ComponentActivity() {
    private var otgConn: AdbConnection? = null
    private var onPicked: ((List<Uri>) -> Unit)? = null
    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        onPicked?.invoke(uris)
    }

    override fun onDestroy() {
        otgConn?.close()
        otgConn = null
        super.onDestroy()
    }

    private fun nameOf(u: Uri): String {
        var n: String? = null
        runCatching {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                var command by remember { mutableStateOf("") }
                var output by remember { mutableStateOf("") }   // the last run
                var log by remember { mutableStateOf("") }      // every run since the last clear, one after another
                var lastCommand by remember { mutableStateOf("") }
                var running by remember { mutableStateOf(false) }
                var mode by remember { mutableStateOf(modeText()) }
                var adb by remember { mutableStateOf<AdbConnection?>(null) }
                var adbName by remember { mutableStateOf("") }
                var showOtg by remember { mutableStateOf(false) }
                var showPush by remember { mutableStateOf(false) }
                var showOptions by remember { mutableStateOf(false) }
                var pushDir by remember { mutableStateOf(ShellFeedback.prefs(this@ShellActivity).getString("otgPushDir", "/sdcard/Download/") ?: "/sdcard/Download/") }
                val scroll = rememberScrollState()

                fun emit(text: String) { output += text; log += text }

                fun launch(title: String, block: () -> Unit) {
                    if (running) return
                    running = true
                    lastCommand = title
                    output = ""
                    log += (if (log.isEmpty()) "" else "\n") + "$ $title\n"
                    Thread {
                        try { block() } catch (e: Throwable) { emit("ERROR: ${e.javaClass.simpleName}: ${e.message}") }
                        log += "\n"
                        running = false
                    }.start()
                }

                var enterRuns by remember { mutableStateOf(ShellFeedback.prefs(this@ShellActivity).getBoolean("enterRuns", false)) }
                LaunchedEffect(log) { if (running) scroll.scrollTo(scroll.maxValue) }

                var showHistory by remember { mutableStateOf(false) }
                fun runCommand(cmd: String) {
                    ShellHistory.recordRun(this@ShellActivity, cmd)
                    val a = adb
                    if (a != null) {
                        launch(cmd) {
                            val code = a.shell(cmd) { text -> emit(text) }
                            emit("\n[exit " + (if (code < 0) "?" else code.toString()) + "]")
                        }
                    } else launch(cmd) {
                        val code = ShizukuShell.run(cmd) { line -> emit(line + "\n") }
                        emit("\n[exit $code]")
                    }
                }

                fun runPush(uris: List<Uri>, dirIn: String) {
                    val c = adb ?: return
                    val dir = if (dirIn.endsWith("/")) dirIn else "$dirIn/"
                    launch("push " + uris.size + " file(s) to " + dir) {
                        c.shell("mkdir -p '" + dir.replace("'", "'\\''") + "'") { }
                        for (u in uris) {
                            val name = nameOf(u)
                            emit("$name ")
                            var sent = 0L
                            var mark = 0L
                            val ins = contentResolver.openInputStream(u) ?: throw java.io.IOException("Cannot read $name")
                            ins.use { stream ->
                                c.push(stream, dir + name) { n ->
                                    sent = n
                                    if (n - mark >= 4000000L) { mark = n; emit(".") }
                                }
                            }
                            emit(" done (" + sent + " bytes)\n")
                        }
                        emit("[push finished]")
                    }
                }
                if (showOtg) {
                    OtgDialog(
                        connectedName = if (adb != null) adbName else null,
                        onConnected = { c -> otgConn = c; adb = c; adbName = c.deviceName() },
                        onDisconnect = { otgConn?.close(); otgConn = null; adb = null; adbName = "" },
                        onDismiss = { showOtg = false },
                    )
                }
                if (showPush) {
                    PushDialog(
                        dir = pushDir,
                        onDismiss = { showPush = false },
                        onChoose = { d ->
                            pushDir = d
                            showPush = false
                            ShellFeedback.prefs(this@ShellActivity).edit().putString("otgPushDir", d).apply()
                            onPicked = { uris -> if (uris.isNotEmpty()) runPush(uris, d) }
                            pickFiles.launch(arrayOf("*/*"))
                        },
                    )
                }
                if (showHistory) {
                    ShellHistoryDialog(
                        onDismiss = { showHistory = false },
                        onUse = { command = it; showHistory = false },
                        onRun = { command = it; showHistory = false; runCommand(it) },
                        onCopy = { copy(it, "Command copied") },
                    )
                }

                var showFb by remember { mutableStateOf(false) }
                if (showFb) ShellFeedbackDialog(onDismiss = { showFb = false })

                if (showOptions) {
                    ShellWindow(title = "Shell options", onBack = { showOptions = false }) {
                        CardGroup(
                            title = "Where it runs",
                            hint = "On this phone with Shizuku's privilege, or on another device plugged in with an OTG cable.",
                        ) {
                            row { sh ->
                                SettingRow(
                                    title = "Running with", shape = sh, icon = Icons.Filled.Terminal, lit = true,
                                    summary = if (adb != null) "OTG device: $adbName" else mode,
                                )
                            }
                            row { sh ->
                                LinkRow(
                                    title = "OTG device",
                                    summary = if (adb != null) "Connected to $adbName" else "Run on another device plugged in with a cable",
                                    shape = sh, icon = Icons.Filled.Share,
                                ) { showOtg = true }
                            }
                            if (adb != null) row { sh ->
                                LinkRow(
                                    title = "Push file", summary = "Send files to the other device", shape = sh,
                                    icon = Icons.Filled.Download,
                                ) { if (!running) { showOptions = false; showPush = true } }
                            }
                            row { sh ->
                                LinkRow(
                                    title = "Allow Shizuku", summary = "Ask Shizuku to let A use it", shape = sh,
                                    icon = Icons.Filled.Lock,
                                ) {
                                    ShizukuShell.requestPermission { mode = modeText() }
                                    mode = modeText()
                                }
                            }
                            row { sh ->
                                LinkRow(
                                    title = "Grant permissions", summary = "Have Shizuku give A every permission it can use",
                                    shape = sh, icon = Icons.Filled.Check,
                                ) {
                                    if (!running) {
                                        showOptions = false
                                        launch("grant permissions") {
                                            val code = ShizukuShell.grantAll(this@ShellActivity) { line -> emit(line + "\n") }
                                            emit("\n[exit $code]")
                                        }
                                    }
                                }
                            }
                        }
                        CardGroup(title = "Typing") {
                            row { sh ->
                                SwitchRow(
                                    title = "Enter key runs the command", checked = enterRuns, shape = sh,
                                    icon = Icons.Filled.Edit, summary = "Pasted new lines stay.",
                                ) {
                                    enterRuns = it
                                    ShellFeedback.prefs(this@ShellActivity).edit().putBoolean("enterRuns", it).apply()
                                }
                            }
                        }
                        CardGroup(title = "Shell shortcuts") {
                            row { sh ->
                                LinkRow(
                                    title = "Shortcut feedback", summary = "How the result of a shell shortcut is shown",
                                    shape = sh, icon = Icons.Filled.Notifications,
                                ) { showFb = true }
                            }
                        }
                    }
                }

                AWindowPage(
                    title = "Shell",
                    onBack = { this@ShellActivity.finish() },
                    actions = {
                        IconButton(onClick = { showHistory = true }, tooltip = "History and saved commands") {
                            Icon(Icons.Filled.History, contentDescription = null)
                        }
                        IconButton(onClick = { showOptions = true }, tooltip = "Where it runs, Enter key, shortcut feedback") {
                            Icon(Icons.Filled.Tune, contentDescription = null)
                        }
                    },
                ) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp).padding(bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        CardGroup(title = "Run a command") {
                            row { sh ->
                                SettingRow(
                                    title = "Command", shape = sh, icon = Icons.Filled.Terminal, lit = running,
                                    summary = "Runs with: " + (if (adb != null) "OTG device $adbName" else mode),
                                    footer = {
                                        OutlinedTextField(
                                            value = command,
                                            onValueChange = { v ->
                                                // One typed Enter runs the command; a paste (more than one character) keeps its new lines.
                                                var i = 0
                                                while (i < command.length && i < v.length && command[i] == v[i]) i++
                                                val typedEnter = enterRuns && v.length == command.length + 1 && v[i] == '\n' && v.removeRange(i, i + 1) == command
                                                if (typedEnter) { if (command.isNotBlank()) runCommand(command) } else command = v
                                            },
                                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                                        )
                                    },
                                )
                            }
                        }
                        Button(enabled = !running, onClick = { runCommand(command) }, modifier = Modifier.fillMaxWidth()) { Text("Run") }
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(rowColor()).padding(horizontal = 6.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            IconButton(onClick = { copy(output, "Last output copied") }, tooltip = "Copy last output") {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null)
                            }
                            IconButton(onClick = { copy(log, "All output copied") }, tooltip = "Copy all output") {
                                Icon(Icons.Filled.CopyAll, contentDescription = null)
                            }
                            IconButton(onClick = { saveTxt(lastCommand.ifBlank { command }, output) }, tooltip = "Save the last output as a txt file") {
                                Icon(Icons.Filled.Download, contentDescription = null)
                            }
                            IconButton(onClick = { log = ""; output = "" }, tooltip = "Clear output") {
                                Icon(Icons.Filled.Close, contentDescription = null)
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(20.dp)).background(rowColor()),
                        ) {
                            if (log.isEmpty()) {
                                Text(
                                    "The result of a command shows here.",
                                    Modifier.padding(14.dp), fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            androidx.compose.foundation.text.selection.SelectionContainer(
                                Modifier.fillMaxSize().verticalScroll(scroll).padding(12.dp),
                            ) {
                                Text(log, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun modeText(): String = when {
        ShizukuShell.isReady() -> "Shizuku (privileged)"
        ShizukuShell.isRunning() -> "Shizuku running, not allowed yet"
        else -> "normal (Shizuku is not running)"
    }

    private fun copy(text: String, done: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("shell", text))
        Toast.makeText(this, done, Toast.LENGTH_SHORT).show()
    }

    /** Downloads/<first 15 characters of the command>.txt */
    private fun saveTxt(command: String, text: String) {
        val base = command.trim().take(15).replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "output" }
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "$base.txt")
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val ok = runCatching {
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(text.toByteArray()) }
        }.isSuccess
        Toast.makeText(this, if (ok) "Saved in Downloads as $base.txt" else "Could not save", Toast.LENGTH_SHORT).show()
    }
}
