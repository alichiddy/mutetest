package a.a.strip

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import a.a.utils.ShizukuShell

/**
 * Temporary "A is the launcher" mode for the widget and OCR screens. While it is on, A is the phone's home app
 * (set through Shizuku, the old one is remembered). When the bank's own screen closes and Android goes home,
 * A's invisible home screen opens the widget/OCR screen again; a home press from anywhere else opens the
 * remembered launcher. Turning it off puts the old launcher back. It costs nothing while off.
 */
object LauncherGuard {
    private const val HOME_CLASS = "a.a.strip.LauncherHomeActivity"
    private fun sp(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun isOn(c: Context): Boolean = sp(c).getBoolean("tmpLauncherOn", false)
    fun prevHome(c: Context): String? = sp(c).getString("tmpLauncherPrev", null)?.takeIf { it.isNotBlank() }
    fun screen(c: Context): String? = sp(c).getString("tmpLauncherScreen", null)?.takeIf { it.isNotBlank() }

    /** ReturnGuard: the screen to come back to after a tap on a widget. */
    fun noteScreen(c: Context, cls: String) { sp(c).edit().putString("tmpLauncherScreen", cls).apply() }

    /** ReturnGuard saw another app (the bank's screen) on top just now. */
    fun noteOther(c: Context) { sp(c).edit().putLong("tmpLauncherOtherAt", System.currentTimeMillis()).apply() }
    fun clearOther(c: Context) { sp(c).edit().remove("tmpLauncherOtherAt").apply() }
    fun otherRecent(c: Context): Boolean = System.currentTimeMillis() - sp(c).getLong("tmpLauncherOtherAt", 0L) < 90_000L

    private fun aliasOf(c: Context) = ComponentName(c.packageName, HOME_CLASS)

    private fun defaultHome(c: Context): ComponentName? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = c.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY) ?: return null
        return ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
    }

    /** Switches the mode on or off on a background thread; [done] gets (success, message), on that thread. */
    fun set(context: Context, on: Boolean, done: (Boolean, String) -> Unit) {
        val app = context.applicationContext
        Thread {
            runCatching {
                if (!ShizukuShell.isReady()) { done(false, "Shizuku is needed (start it and allow A)."); return@Thread }
                val pm = app.packageManager
                val alias = aliasOf(app)
                if (on) {
                    val cur = defaultHome(app)
                    val e = sp(app).edit()
                    if (cur != null && cur.packageName != app.packageName && cur.packageName != "android") e.putString("tmpLauncherPrev", cur.flattenToString())
                    else if (cur == null || cur.packageName == "android") e.remove("tmpLauncherPrev")
                    e.putBoolean("tmpLauncherAliasWas", pm.getComponentEnabledSetting(alias) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
                    e.apply()
                    pm.setComponentEnabledSetting(alias, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
                    val out = StringBuilder()
                    ShizukuShell.run("cmd package set-home-activity " + alias.flattenToString()) { out.append(it).append(' ') }
                    val now = defaultHome(app)
                    if (now?.packageName == app.packageName) {
                        sp(app).edit().putBoolean("tmpLauncherOn", true).apply()
                        done(true, "A is the launcher now. Turn this off when you are done with the widget.")
                    } else {
                        pm.setComponentEnabledSetting(alias, if (sp(app).getBoolean("tmpLauncherAliasWas", false)) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                        done(false, "Android did not accept it. " + out.toString().trim().take(200))
                    }
                } else {
                    val prev = prevHome(app)
                    val out = StringBuilder()
                    if (prev != null) ShizukuShell.run("cmd package set-home-activity $prev") { out.append(it).append(' ') }
                    else ShizukuShell.run("pm clear-package-preferred-activities " + app.packageName) { out.append(it).append(' ') }
                    sp(app).edit().putBoolean("tmpLauncherOn", false).apply()
                    if (!sp(app).getBoolean("tmpLauncherAliasWas", false)) {
                        // Kept enabled until the old launcher is back, so Android never has no home app.
                        pm.setComponentEnabledSetting(alias, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                    }
                    val now = defaultHome(app)
                    done(true, if (prev != null && now?.packageName == app.packageName) "Could not put the old launcher back. Choose it in Android's default home app setting." else "Your own launcher is back.")
                }
            }.onFailure { done(false, "Failed: " + (it.message ?: it.javaClass.simpleName)) }
        }.start()
    }
}
