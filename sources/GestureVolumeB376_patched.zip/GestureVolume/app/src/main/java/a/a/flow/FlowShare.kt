package a.a.flow

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Flows as a small file others can import. The flow's id goes with it, so a cell that points at
 * the id runs the shared flow as soon as it is imported. Flows that a shared flow runs are
 * included automatically.
 */
object FlowShare {
    const val EXT = ".afl"
    private const val FORMAT = "afl"

    /** The text of the file for [names] (and everything they run). */
    fun export(context: Context, names: Collection<String>): String {
        val todo = ArrayDeque(names.mapNotNull { FlowStore.resolve(context, it) })
        val done = LinkedHashSet<String>()
        while (todo.isNotEmpty()) {
            val n = todo.removeFirst()
            if (!done.add(n)) continue
            FlowStore.dependencies(context, n).forEach { if (it !in done) todo.add(it) }
        }
        val arr = JSONArray()
        for (n in done) {
            val id = FlowStore.idOf(context, n) ?: continue
            val steps = JSONArray(FlowStore.rawSteps(context, n)?.toString() ?: "[]")
            // "Run flow" blocks point at ids, so they still find their flow whatever it is called there.
            for (i in 0 until steps.length()) {
                val s = steps.getJSONObject(i)
                if (s.optString("t") == Step.RUN) {
                    val target = FlowStore.resolve(context, s.optString("a"))
                    val tid = target?.let { FlowStore.idOf(context, it) }
                    if (tid != null) s.put("a", tid)
                }
            }
            arr.put(JSONObject().put("id", id).put("name", n).put("steps", steps))
        }
        return JSONObject().put(FORMAT, 1).put("flows", arr).toString()
    }

    /** Writes the file and opens the share sheet. */
    fun share(context: Context, names: Collection<String>) {
        val text = export(context, names)
        val dir = File(context.cacheDir, "flows").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val label = if (names.size == 1) names.first().replace(Regex("[^A-Za-z0-9 _-]"), "_").trim().ifEmpty { "flow" } else "flows-${names.size}"
        val f = File(dir, label + EXT).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", f)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/octet-stream")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "Share flows").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Imports a shared file. Returns the names now on this phone, or null if it is not a flows file. */
    fun import(context: Context, uri: Uri): List<String>? {
        val text = runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: return null
        return importText(context, text)
    }

    fun importText(context: Context, text: String): List<String>? {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return null
        if (!root.has(FORMAT)) return null
        val arr = root.optJSONArray("flows") ?: return null
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val f = arr.optJSONObject(i) ?: continue
            val id = f.optString("id")
            val steps = f.optJSONArray("steps") ?: continue
            if (!id.startsWith("#")) continue
            out += FlowStore.putShared(context, id, f.optString("name"), steps)
        }
        return out
    }
}
