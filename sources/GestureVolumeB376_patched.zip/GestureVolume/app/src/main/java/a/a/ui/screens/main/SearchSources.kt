package a.a.ui.screens.main

import android.content.Context
import a.a.flow.FlowStore
import a.a.flow.NativeActions
import a.a.flow.NativePicker
import a.a.strip.StripConfig
import a.a.strip.StripItem
import a.a.strip.StripScope
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import org.json.JSONArray

/**
 * One thing the menu search can take you to.
 *
 * [target] says where: "nav:<route>" a screen, "act:<class>" a window of its own, "dlg:<key>" or
 * "menu:<key>" a dialog on the main screen, "script:<name>" one of your scripts.
 */
data class SearchHit(val title: String, val info: String, val path: String, val target: String, val section: String = "")

/**
 * Everything the menu search looks through, collected when the search opens and dropped when it closes:
 * the fixed list of screens and settings (assets/search_index.json, made by tool/make_search_index.py),
 * the built-in shortcuts and device actions, and the person's own cells, folders and scripts.
 * Nothing is kept in memory while the search is closed.
 */
object SearchSources {
    fun load(context: Context): List<SearchHit> {
        val out = ArrayList<SearchHit>(1500)
        runCatching { fixedList(context, out) }
        runCatching { builtIn(context, out) }
        runCatching { cells(context, out) }
        runCatching { scripts(context, out) }
        return out
    }

    private fun fixedList(context: Context, out: MutableList<SearchHit>) {
        val text = context.assets.open("search_index.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(SearchHit(o.optString("t"), o.optString("i"), o.optString("p"), o.optString("r"), o.optString("s")))
        }
    }

    /** The built-in shortcuts and device actions: what a cell, a segment gesture or a script can do. */
    private fun builtIn(context: Context, out: MutableList<SearchHit>) {
        val where = "Cells > Built-in shortcuts"
        for (e in HandlerActionCatalog.ALL) {
            if (e.action == HandlerActions.NONE || e.action == HandlerActions.REPOSITION || e.action == HandlerActions.LAUNCH_APP || e.action in HandlerActionCatalog.HIDDEN) continue
            out.add(SearchHit(context.getString(e.labelRes), "", where, "nav:strip_editor"))
        }
        for (g in NativePicker.groups()) {
            val modes = g.options.map { it.first }.filter { it.isNotEmpty() }.joinToString(" ")
            val help = NativeActions.find(g.options.firstOrNull()?.second ?: "")?.help.orEmpty()
            out.add(SearchHit(g.title, (modes + " " + help).trim(), "$where > Device actions", "nav:strip_editor"))
        }
    }

    /** The cells (and cells inside folders) of the main Cells window and of every segment that has its own. */
    private fun cells(context: Context, out: MutableList<SearchHit>) {
        addCells(context, out, StripScope.load(context, StripScope.MAIN).items, "Cells", "nav:strip_editor")
        for ((id, name) in StripScope.ownWindowIds(context)) {
            addCells(context, out, StripScope.load(context, id).items, "Cells window of $name", "nav:strip_editor_scope/$id")
        }
    }

    private fun addCells(context: Context, out: MutableList<SearchHit>, items: List<StripItem>, path: String, target: String) {
        for (c in items) {
            val name = c.label.replace('\n', ' ').trim()
            if (c.children != null) {
                val folder = name.ifBlank { "Folder" }
                out.add(SearchHit(folder, "Folder", path, target))
                addCells(context, out, c.children, "$path > $folder", target)
            } else if (name.isNotEmpty() || c.action.isNotEmpty()) {
                val what = describe(c.action)
                out.add(SearchHit(name.ifBlank { what.ifBlank { "Cell" } }, if (name.isBlank()) "" else what, path, target))
            }
        }
    }

    /** What a cell's action is, in words. */
    private fun describe(action: String): String {
        val a = StripConfig.bare(action)
        return when {
            a.isEmpty() -> ""
            NativePicker.isNative(a) -> runCatching { NativePicker.label(a) }.getOrDefault(a)
            a.startsWith("MyFlow:") -> "Script " + FlowStore.display(a.removePrefix("MyFlow:"))
            else -> a.take(80)
        }
    }

    private fun scripts(context: Context, out: MutableList<SearchHit>) {
        for ((name, _) in FlowStore.links(context)) {
            out.add(SearchHit(name, "", "Scripts", "script:$name"))
        }
    }
}
