package a.a.ui.screens.strip

import android.content.SharedPreferences
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage
import a.a.ui.motion.OutlinedButton

/**
 * "Click circle" in the card design (full-screen window with the back arrow, like the Look window): how the
 * circle moves and taps, what it copies, and where it starts. [sp] is the main settings file ("MyPrefs").
 * Only the drawing is new; every setting keeps its stored name and value.
 */
@Composable
fun ClickCircleDialog(sp: SharedPreferences, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var ccLong by remember { mutableIntStateOf(sp.getInt("clickCircleLongMs", 200)) }
    var ccDouble by remember { mutableIntStateOf(sp.getInt("clickCircleDoubleMs", 400)) }
    var doubleBump by remember { mutableIntStateOf(0) }
    var shell by remember { mutableStateOf(sp.getBoolean("clickCircleShizuku", false)) }
    var copy by remember { mutableStateOf(sp.getBoolean("clickCircleCopy", true)) }
    var ocr by remember { mutableStateOf(sp.getBoolean("clickCircleOcr", false)) }
    var keep by remember { mutableStateOf(sp.getBoolean("clickCircleKeep", false)) }
    var xMode by remember { mutableIntStateOf(sp.getInt("clickCircleXMode", 0)) }
    var yMode by remember { mutableIntStateOf(sp.getInt("clickCircleYMode", 1)) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().imePadding(), color = MaterialTheme.colorScheme.background) {
            AWindowPage("Click circle", onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup(
                        "Moving and tapping",
                        hint = "Run the built-in 'Click circle' (for example as an outside action). A circle appears mid-screen: touch anywhere and move to move it, lift to tap there. Hold still before lifting: long press, then double tap. If you do not touch it, it goes away after 10 seconds.",
                    ) {
                        row { sh ->
                            SliderRow(
                                "ccSpeed", "Circle speed", "% of your movement", sp.getInt("clickCircleSpeed", 150), 50, 400, sh,
                                icon = Icons.Filled.TouchApp,
                            ) { sp.edit().putInt("clickCircleSpeed", it).apply() }
                        }
                        row { sh ->
                            SliderRow(
                                "ccLong", "Still for a long press", " ms", ccLong, 100, 1000, sh,
                                summary = "Keep the thumb still this long before lifting",
                            ) {
                                ccLong = it
                                if (ccDouble < ccLong + 100) { ccDouble = ccLong + 100; doubleBump++ }
                                sp.edit().putInt("clickCircleLongMs", ccLong).putInt("clickCircleDoubleMs", ccDouble).apply()
                            }
                        }
                        row { sh ->
                            SliderRow(
                                "ccDouble$doubleBump", "Still for a double tap", " ms", ccDouble, ccLong + 100, 2000, sh,
                                summary = "Always at least 100 ms longer than the long press",
                            ) {
                                ccDouble = it.coerceAtLeast(ccLong + 100)
                                sp.edit().putInt("clickCircleDoubleMs", ccDouble).apply()
                            }
                        }
                        row { sh ->
                            SwitchRow(
                                "Tap with Shizuku", shell, sh, icon = Icons.Filled.Terminal,
                                summary = "Instead of accessibility, for apps that block accessibility taps",
                            ) { shell = it; sp.edit().putBoolean("clickCircleShizuku", it).apply() }
                        }
                    }
                    CardGroup("Reading the text under the circle") {
                        row { sh ->
                            SwitchRow(
                                "Also copy the text under the circle", copy, sh, icon = Icons.Filled.ContentCopy,
                                summary = "Read at the moment of release, before the tap",
                                info = "A switches the \"A text reader\" on through Shizuku for a moment.",
                            ) { copy = it; sp.edit().putBoolean("clickCircleCopy", it).apply() }
                        }
                        row { sh ->
                            SwitchRow(
                                "Also read digits drawn as a picture", ocr, sh, icon = Icons.Filled.Visibility,
                                summary = "Only when no text is found",
                                info = "The tap waits a moment while the picture is read. Needs Shizuku.",
                            ) { ocr = it; sp.edit().putBoolean("clickCircleOcr", it).apply() }
                        }
                        row { sh ->
                            SettingRow(
                                "Text reader", sh, icon = Icons.Filled.Memory,
                                summary = "Switch it on or off by hand",
                                footer = {
                                    Row(
                                        Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        OutlinedButton(onClick = { Thread { a.a.strip.TextReaderControl.ensureOnBlocking(context, 3000) }.start() }) { Text("Text reader on") }
                                        OutlinedButton(onClick = { a.a.strip.TextReaderControl.offNow(context) }) { Text("Text reader off") }
                                    }
                                },
                            )
                        }
                    }
                    CardGroup("Where the circle starts") {
                        row { sh ->
                            PickCardRow(
                                "ccX", "Horizontal", listOf("Middle", "From thumb", "% of screen"), xMode, sh, icon = Icons.Filled.Tune,
                            ) { xMode = it; sp.edit().putInt("clickCircleXMode", it).apply() }
                        }
                        if (xMode == 1) row { sh -> OffsetRow(sp, "clickCircleXOffDp", 0, "left", "right", sh) }
                        if (xMode == 2) row { sh -> PercentRow(sp, "clickCircleXPct", sh) }
                        row { sh ->
                            PickCardRow(
                                "ccY", "Vertical", listOf("Middle", "From thumb", "% of screen"), yMode, sh, icon = Icons.Filled.Tune,
                            ) { yMode = it; sp.edit().putInt("clickCircleYMode", it).apply() }
                        }
                        if (yMode == 1) row { sh -> OffsetRow(sp, "clickCircleYOffDp", -150, "above", "below", sh) }
                        if (yMode == 2) row { sh -> PercentRow(sp, "clickCircleYPct", sh) }
                        row { sh ->
                            SwitchRow(
                                "Start where the last tap was", keep, sh, icon = Icons.Filled.Check,
                            ) { keep = it; sp.edit().putBoolean("clickCircleKeep", it).apply() }
                        }
                    }
                }
            }
        }
    }
}

/** "From thumb" distance in dp: minus goes one way, plus the other. */
@Composable
private fun OffsetRow(
    sp: SharedPreferences, pk: String, def: Int, negWord: String, posWord: String, shape: androidx.compose.ui.graphics.Shape,
) {
    key(pk) {
        SettingRow(
            "Distance from the thumb", shape, summary = "Minus = $negWord, plus = $posWord",
            footer = {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                    NumberBox("In dp", sp.getInt(pk, def), min = -3000) { sp.edit().putInt(pk, it).apply() }
                }
            },
        )
    }
}

/** "% of screen" start position. */
@Composable
private fun PercentRow(sp: SharedPreferences, pk: String, shape: androidx.compose.ui.graphics.Shape) {
    key(pk) {
        SettingRow(
            "Percent of the screen", shape, summary = "0 to 100",
            footer = {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                    NumberBox("Percent", sp.getInt(pk, 50), max = 100) { sp.edit().putInt(pk, it).apply() }
                }
            },
        )
    }
}
