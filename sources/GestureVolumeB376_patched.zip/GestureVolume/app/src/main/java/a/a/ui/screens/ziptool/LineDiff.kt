package a.a.ui.screens.ziptool

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/**
 * Compares two versions of a text file line by line, for the smart merger's "what is different" view.
 * Common lines at the start and end are skipped first, then the lines in between are matched with a
 * longest-common-subsequence table. A change region too large for the table is reported as such
 * instead of being guessed at.
 */
object LineDiff {
    /** Biggest file the merger reads to compare line by line. */
    const val MAX_TEXT = 1_500_000L

    /** Biggest (old lines x new lines) the matching table is built for. */
    private const val MAX_CELLS = 4_000_000L

    /** Lines shown around every change. */
    private const val CONTEXT = 3

    /** Most lines [render] gives back. */
    private const val MAX_OUT = 1500

    /**
     * [added] and [removed] are line counts. When [tooBig], the changed region was too large to match line by
     * line: [regionOld] old lines became [regionNew] new lines and [lines] is empty.
     */
    class Result(
        val added: Int,
        val removed: Int,
        val tooBig: Boolean,
        val regionOld: Int,
        val regionNew: Int,
        val lines: List<String>,
    ) {
        /** True when the two files have the same lines (only line endings or the final newline differ). */
        val sameLines: Boolean get() = !tooBig && added == 0 && removed == 0
    }

    private class Op(val c: Char, val text: String, val aNo: Int, val bNo: Int)

    /** Splits text into lines, ignoring a Windows line ending and the newline at the very end. */
    fun split(text: String): List<String> {
        val parts = text.split('\n').map { it.removeSuffix("\r") }
        return if (parts.isNotEmpty() && parts[parts.size - 1].isEmpty()) parts.subList(0, parts.size - 1) else parts
    }

    /** True when the bytes are readable UTF-8 text with no zero bytes (not a picture, a jar, a font...). */
    fun looksText(bytes: ByteArray): Boolean {
        if (bytes.size.toLong() > MAX_TEXT) return false
        val head = minOf(bytes.size, 8000)
        for (i in 0 until head) if (bytes[i].toInt() == 0) return false
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            dec.decode(ByteBuffer.wrap(bytes))
            true
        } catch (e: CharacterCodingException) {
            false
        }
    }

    /** Every line of [text] marked as added ("+ ") or removed ("- "), for a file that exists on one side only. */
    fun whole(text: String, mark: Char, maxLines: Int = 300): List<String> {
        val all = split(text)
        val out = ArrayList<String>()
        for ((i, l) in all.withIndex()) {
            if (i >= maxLines) {
                out.add("... ${all.size - maxLines} more line(s)")
                break
            }
            out.add("$mark $l")
        }
        return out
    }

    fun diff(a: List<String>, b: List<String>): Result {
        val minLen = minOf(a.size, b.size)
        var pre = 0
        while (pre < minLen && a[pre] == b[pre]) pre++
        var suf = 0
        while (suf < minLen - pre && a[a.size - 1 - suf] == b[b.size - 1 - suf]) suf++
        val am = a.subList(pre, a.size - suf)
        val bm = b.subList(pre, b.size - suf)
        val n = am.size
        val m = bm.size
        if (n == 0 && m == 0) return Result(0, 0, false, 0, 0, emptyList())
        if (n.toLong() * m.toLong() > MAX_CELLS) return Result(0, 0, true, n, m, emptyList())

        val w = m + 1
        val t = ShortArray((n + 1) * w)
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                t[i * w + j] = if (am[i] == bm[j]) {
                    (t[(i + 1) * w + j + 1] + 1).toShort()
                } else {
                    maxOf(t[(i + 1) * w + j].toInt(), t[i * w + j + 1].toInt()).toShort()
                }
            }
        }

        val ops = ArrayList<Op>()
        val ctxPre = minOf(CONTEXT, pre)
        var an = pre - ctxPre + 1
        var bn = an
        for (k in pre - ctxPre until pre) {
            ops.add(Op(' ', a[k], an, bn))
            an++
            bn++
        }
        var i = 0
        var j = 0
        while (i < n && j < m) {
            if (am[i] == bm[j]) {
                ops.add(Op(' ', am[i], an, bn))
                an++; bn++; i++; j++
            } else if (t[(i + 1) * w + j] >= t[i * w + j + 1]) {
                ops.add(Op('-', am[i], an, bn))
                an++; i++
            } else {
                ops.add(Op('+', bm[j], an, bn))
                bn++; j++
            }
        }
        while (i < n) {
            ops.add(Op('-', am[i], an, bn))
            an++; i++
        }
        while (j < m) {
            ops.add(Op('+', bm[j], an, bn))
            bn++; j++
        }
        val ctxSuf = minOf(CONTEXT, suf)
        for (k in 0 until ctxSuf) {
            ops.add(Op(' ', a[a.size - suf + k], an, bn))
            an++
            bn++
        }

        var added = 0
        var removed = 0
        for (op in ops) {
            if (op.c == '+') added++ else if (op.c == '-') removed++
        }
        return Result(added, removed, false, n, m, render(ops))
    }

    /** Only the changed lines and a few around them, with a "@@" line where lines were skipped. */
    private fun render(ops: List<Op>): List<String> {
        val keep = BooleanArray(ops.size)
        for (idx in ops.indices) {
            if (ops[idx].c == ' ') continue
            val from = maxOf(0, idx - CONTEXT)
            val to = minOf(ops.size - 1, idx + CONTEXT)
            for (k in from..to) keep[k] = true
        }
        val out = ArrayList<String>()
        var prev = -2
        for (idx in ops.indices) {
            if (!keep[idx]) continue
            if (out.size >= MAX_OUT) {
                out.add("... more changes not shown")
                break
            }
            if (idx != prev + 1) out.add("@@ A line ${ops[idx].aNo}, B line ${ops[idx].bNo} @@")
            out.add("${ops[idx].c} ${ops[idx].text}")
            prev = idx
        }
        return out
    }
}
