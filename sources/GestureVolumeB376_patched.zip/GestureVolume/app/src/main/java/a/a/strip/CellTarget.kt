package a.a.strip

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow

/**
 * Where a cell saved from outside (Widgets, the launcher catcher, tiles) goes: the main slider's cells window by
 * default, or, when "Ask me which cells window" is on and a segment has its own window, a small choice first.
 */
object CellTarget {
    private const val ASK = "cellTargetAsk"
    private fun p(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun askOn(c: Context) = p(c).getBoolean(ASK, false)
    fun setAsk(c: Context, on: Boolean) { p(c).edit().putBoolean(ASK, on).apply() }

    fun save(context: Context, label: String, action: String, icon: String = "") {
        if (!askOn(context) || StripScope.ownWindowIds(context).isEmpty()) {
            ActionSaver.saveToCells(context, label, action, icon)
            Toast.makeText(context, "Saved to cells", Toast.LENGTH_SHORT).show()
            return
        }
        context.startActivity(
            Intent(context, CellTargetActivity::class.java)
                .putExtra("label", label).putExtra("action", action).putExtra("icon", icon)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** The choice: Main slider, or one of the segments that has its own cells window. Nothing stays open after it. */
class CellTargetActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val label = intent.getStringExtra("label").orEmpty()
        val action = intent.getStringExtra("action").orEmpty()
        val icon = intent.getStringExtra("icon").orEmpty()
        val windows = StripScope.ownWindowIds(this)
        fun pick(id: String, name: String) {
            runCatching { ActionSaver.saveToCellsIn(this, id, label, action, icon) }
            Toast.makeText(this, "Saved to $name", Toast.LENGTH_SHORT).show()
            finish()
        }
        setContent {
            AWindow {
                AWindowPage(title = "Save to which cells window?", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                    ) {
                        CardGroup("Pick the place", hint = "Tap a cells window and the cell is saved in it.") {
                            row { sh -> LinkRow(title = "Main slider", summary = "The cells window of the main slider", shape = sh, icon = Icons.Filled.Tune) { pick(StripScope.MAIN, "the main slider") } }
                            windows.forEach { (id, name) ->
                                row { sh -> LinkRow(name, "This segment's own cells window", sh, Icons.Filled.Apps) { pick(id, name) } }
                            }
                        }
                    }
                }
            }
        }
    }
}
