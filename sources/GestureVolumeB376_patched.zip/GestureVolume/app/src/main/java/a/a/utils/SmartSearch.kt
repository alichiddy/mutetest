package a.a.utils

import java.text.Normalizer

/**
 * The matcher behind the main menu's "Search everything". Pure Kotlin, no Android: it is built to be
 * tested on its own (see SmartSearchTest).
 *
 * What "smart" means here:
 *  - every typed word must be found, in any order, in the name, the info text or the place ("Appearance
 *    > Content") of an entry; "wifi toggle" finds "Wi-Fi Mode Toggle";
 *  - punctuation and spacing do not matter: "wifi", "wi-fi" and "wi fi" are the same;
 *  - a word may be a beginning ("volu"), a plural or other ending ("shortcuts"), a close misspelling
 *    ("volum panl"), or a word that means the same ("torch" finds "Flashlight");
 *  - a hit in the name beats a hit in the info text, which beats a hit in the place; names that hold
 *    all the words, in order, and are short come first;
 *  - when nothing holds every word, the entries holding the most words are shown instead.
 *
 * Nothing here is kept between searches except the prepared list inside an [Index], which the caller
 * drops when the search closes.
 */
object SmartSearch {
    /** What is searched for one entry. */
    class Doc(val title: String, val info: String = "", val path: String = "")

    // ---- words -------------------------------------------------------------------------------------

    private val marks = Regex("\\p{Mn}+")

    /** Lower case, no accents, Persian/Arabic digits as 0-9, no apostrophes, split on anything not a letter or digit. */
    fun tokenize(text: String): List<String> {
        if (text.isEmpty()) return emptyList()
        val sb = StringBuilder(text.length)
        for (c in Normalizer.normalize(text, Normalizer.Form.NFD)) {
            when (c) {
                in '۰'..'۹' -> sb.append('0' + (c - '۰'))
                in '٠'..'٩' -> sb.append('0' + (c - '٠'))
                '\'', '’', 'ʼ' -> {}
                '&' -> sb.append(" and ")
                else -> sb.append(c)
            }
        }
        val plain = marks.replace(sb.toString(), "").lowercase()
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (c in plain) {
            if (c.isLetterOrDigit()) cur.append(c) else if (cur.isNotEmpty()) { out.add(cur.toString()); cur.setLength(0) }
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    /** A rough common root, the same for "toggle", "toggles", "toggled" and "toggling". Only used to compare. */
    internal fun stem(w: String): String {
        var s = w
        if (s.length > 4 && s.endsWith("ies")) s = s.dropLast(3) + "y"
        else if (s.length > 3 && s.endsWith("s") && !s.endsWith("ss") && !s.endsWith("us")) s = s.dropLast(1)
        if (s.length > 5 && s.endsWith("ing")) {
            s = s.dropLast(3)
            if (s.length > 2 && s[s.length - 1] == s[s.length - 2] && s.last() !in "lsz") s = s.dropLast(1)
        } else if (s.length > 4 && s.endsWith("ed")) s = s.dropLast(2)
        if (s.length > 3 && s.endsWith("e")) s = s.dropLast(1)
        return s
    }

    /** Words that mean the same in this app; a match through one of them counts a little less. */
    private val synonymGroups: List<List<String>> = listOf(
        listOf("wifi", "wlan"),
        listOf("bluetooth", "bt"),
        listOf("flashlight", "torch", "flash"),
        listOf("airplane", "aeroplane", "flight"),
        listOf("volume", "vol"),
        listOf("brightness", "bright", "dim", "backlight"),
        listOf("notification", "notif", "shade"),
        listOf("screenshot", "screencap", "capture"),
        listOf("vibrate", "vibration", "haptic", "buzz"),
        listOf("lock", "lockscreen"),
        listOf("color", "colour"),
        listOf("setting", "option", "preference", "config", "configuration"),
        listOf("handler", "handle"),
        listOf("cell", "shortcut", "strip"),
        listOf("script", "flow", "automate", "automation"),
        listOf("shell", "terminal", "command"),
        listOf("backup", "export", "restore"),
        listOf("swipe", "slide", "drag"),
        listOf("tap", "click", "press", "touch"),
        listOf("hide", "hidden", "invisible"),
        listOf("delete", "remove", "erase"),
        listOf("copy", "clipboard"),
        listOf("download", "downloads"),
        listOf("mute", "silent", "silence"),
        listOf("dark", "night"),
        listOf("speed", "fast", "quick"),
    )
    private val synonyms: Map<String, List<String>> by lazy {
        val m = HashMap<String, MutableList<String>>()
        for (g in synonymGroups) for (w in g) {
            val key = stem(w)
            val list = m.getOrPut(key) { ArrayList() }
            for (o in g) if (o != w && o !in list) list.add(stem(o))
        }
        m
    }

    /** Edit distance counting a swap of two neighbouring letters as one change; gives up above [max]. */
    internal fun distance(a: String, b: String, max: Int): Int {
        if (a == b) return 0
        if (kotlin.math.abs(a.length - b.length) > max) return max + 1
        val n = a.length
        val m = b.length
        var prev2 = IntArray(m + 1)
        var prev = IntArray(m + 1) { it }
        var cur = IntArray(m + 1)
        for (i in 1..n) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..m) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, prev2[j - 2] + 1)
                cur[j] = v
                if (v < rowMin) rowMin = v
            }
            if (rowMin > max) return max + 1
            val t = prev2; prev2 = prev; prev = cur; cur = t
        }
        return prev[m]
    }

    // ---- prepared text -----------------------------------------------------------------------------

    private class Field(text: String) {
        val tokens: List<String> = tokenize(text)
        val stems: List<String> = tokens.map { stem(it) }
        /** Neighbouring words written as one: "wi fi" also reads "wifi". */
        val joined: List<String> = (0 until (tokens.size - 1).coerceAtLeast(0)).map { tokens[it] + tokens[it + 1] }
        val compact: String = tokens.joinToString("")
        val isEmpty: Boolean get() = tokens.isEmpty()
    }

    private class Row(val title: Field, val info: Field, val path: Field)

    private class Word(val raw: String) {
        val stem: String = stem(raw)
        val alternatives: List<String> = synonyms[stem].orEmpty()
    }

    /** Score of one typed word against one field: 0 = not found; also where in the field it was found. */
    private class Hit(val score: Int, val at: Int, val fuzzy: Boolean = false)
    private val NONE = Hit(0, -1)

    private fun fuzzyLimit(len: Int) = when {
        len < 4 -> 0
        len < 8 -> 1
        else -> 2
    }

    private fun direct(raw: String, st: String, f: Field): Hit {
        if (f.isEmpty) return NONE
        var best = 0
        var at = -1
        var fuzzy = false
        fun take(score: Int, index: Int, byTypo: Boolean = false) {
            if (score > best) { best = score; at = index; fuzzy = byTypo }
        }
        for (i in f.tokens.indices) {
            val d = f.tokens[i]
            val ds = f.stems[i]
            when {
                d == raw -> take(100, i)
                ds == st -> take(95, i)
                raw.length >= 2 && d.startsWith(raw) -> take(if (raw.length >= 3) 85 else 60, i)
                st.length >= 3 && ds.startsWith(st) -> take(80, i)
                raw.length >= 3 && d.length > raw.length && d.contains(raw) -> take(50, i)
            }
            if (raw.length >= 4 && best < 70) {
                val lim = fuzzyLimit(raw.length)
                if (lim > 0) {
                    if (distance(raw, d, lim) <= lim) take(65, i, true)
                    else if (d.length > raw.length && distance(raw, d.substring(0, raw.length), lim) <= lim) take(55, i, true)
                }
            }
        }
        if (best < 95) {
            for (i in f.joined.indices) {
                val d = f.joined[i]
                if (d == raw) take(92, i)
                else if (raw.length >= 3 && d.startsWith(raw)) take(75, i)
            }
        }
        // Written together in the text and typed together here, or typed in pieces that the text joins.
        if (best < 60 && raw.length >= 3 && f.compact.contains(raw)) take(55, 0)
        return if (best == 0) NONE else Hit(best, at, fuzzy)
    }

    private fun match(w: Word, f: Field): Hit {
        var h = direct(w.raw, w.stem, f)
        if (h.score >= 95) return h
        for (alt in w.alternatives) {
            val a = direct(alt, alt, f)
            if (a.score > 0) {
                val s = a.score * 3 / 4
                if (s > h.score) h = Hit(s, a.at, a.fuzzy)
            }
        }
        return h
    }

    // ---- the search --------------------------------------------------------------------------------

    class Index<T>(private val items: List<T>, doc: (T) -> Doc) {
        private val rows: List<Row> = items.map { val d = doc(it); Row(Field(d.title), Field(d.info), Field(d.path)) }

        /** The entries that match [query], best first; empty for a query shorter than two letters. */
        fun search(query: String, limit: Int = 60): List<T> {
            val words = tokenize(query).distinct().map { Word(it) }
            if (words.isEmpty() || (words.size == 1 && words[0].raw.length < 2)) return emptyList()
            val queryCompact = words.joinToString("") { it.raw }
            val full = ArrayList<Triple<Int, Int, Boolean>>()     // (score, row, found only through a misspelling)
            val partial = ArrayList<Pair<Int, Int>>()
            for (r in rows.indices) {
                val row = rows[r]
                var total = 0
                var matched = 0
                var inTitle = 0
                var lastAt = -1
                var ordered = true
                var typo = false
                for (w in words) {
                    val t = match(w, row.title)
                    val i = match(w, row.info)
                    val p = match(w, row.path)
                    val ts = t.score
                    val best = maxOf(ts, i.score * 45 / 100, p.score * 55 / 100)
                    if (best <= 0) continue
                    val chosen = if (best == ts) t else if (best == i.score * 45 / 100) i else p
                    if (chosen.fuzzy) typo = true
                    matched++
                    total += best
                    if (ts > 0) {
                        inTitle++
                        if (t.at < lastAt) ordered = false
                        lastAt = t.at
                    }
                }
                if (matched == 0) continue
                if (matched == words.size) {
                    var s = total
                    if (inTitle == words.size) {
                        s += 120
                        if (ordered) s += 25
                        val tc = row.title.compact
                        if (tc == queryCompact) s += 300
                        else if (tc.startsWith(queryCompact)) s += 80
                        else if (tc.contains(queryCompact)) s += 60
                    }
                    s -= minOf(row.title.tokens.size, 14) * 2
                    full.add(Triple(s, r, typo))
                } else if (words.size >= 2) {
                    partial.add(matched * 1000 + total - minOf(row.title.tokens.size, 14) to r)
                }
            }
            if (full.isNotEmpty()) {
                // A misspelling is only a way to find something when the words are not found as typed.
                val exact = full.filter { !it.third }
                val pick = if (exact.isNotEmpty()) exact else full
                return pick.sortedByDescending { it.first }.take(limit).map { items[it.second] }
            }
            return partial.sortedByDescending { it.first }.take(25).map { items[it.second] }
        }

        /** True when [search] had to fall back to entries that hold only some of the words. */
        fun isPartial(query: String): Boolean {
            val words = tokenize(query).distinct().map { Word(it) }
            if (words.size < 2) return false
            for (row in rows) {
                if (words.all { w -> maxOf(match(w, row.title).score, match(w, row.info).score, match(w, row.path).score) > 0 }) return false
            }
            return true
        }
    }
}
