package a.a.ui.screens.ziptool

import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * The rename rules: find the one applicationId line and the one app_name label in a project zip, work out the
 * new bytes of the files that change, list the places the package name is written by hand, and read a finished
 * zip back to check it. Each line is changed only when it is found exactly once, otherwise nothing is saved.
 */
object RenameLogic {
    const val MAX_SCAN = 3L * 1024 * 1024
    const val MAX_LINES = 40

        val PKG_OK = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
        val APP_ID = Regex("""(?m)^([ \t]*applicationId[ \t]*=?[ \t]*\x22)([^\x22\r\n]*)(\x22)""")
        val LABEL = Regex("""<string\s+name\s*=\s*\x22app_name\x22([^>]*)>(.*?)</string>""", RegexOption.DOT_MATCHES_ALL)
        val DEFAULT_STRINGS = Regex("""(.*/)?res/values/strings\.xml""")
        val PERMISSION = Regex("""<permission\s[^>]*?android:name\s*=\s*\x22([^\x22]+)\x22""")
        val AUTHORITY = Regex("""android:authorities\s*=\s*\x22([^\x22]+)\x22""")
        val SCAN_EXT = setOf("kt", "java", "xml", "json", "kts", "gradle", "pro", "yml", "yaml", "properties", "txt")

    /** The two names found in a zip (as shown to you, label unescaped). */
    class Found(val pkg: String, val label: String)

    /** What will be written: the new bytes of each edited file, keyed by its name in the zip. */
    class Plan(val oldPkg: String, val oldLabel: String, val edits: LinkedHashMap<String, ByteArray>)

    private fun readText(zf: ZipFile, e: ZipEntry): String {
        val bytes = zf.getInputStream(e).use { it.readBytes() }
        val text = String(bytes, Charsets.UTF_8)
        if (!text.toByteArray(Charsets.UTF_8).contentEquals(bytes)) {
            throw IllegalStateException("${e.name} is not clean UTF-8 text, so it is not touched.")
        }
        return text
    }

    private fun isGradle(name: String): Boolean {
        val leaf = name.substringAfterLast('/')
        return leaf == "build.gradle.kts" || leaf == "build.gradle"
    }

    /** Finds the one applicationId line and the one default app_name label. Refuses anything but exactly once. */
    fun find(zf: ZipFile): Found {
        val ids = ArrayList<Pair<String, String>>()
        val en = zf.entries()
        val names = ArrayList<ZipEntry>()
        while (en.hasMoreElements()) names.add(en.nextElement())
        for (e in names) {
            if (e.isDirectory || !isGradle(e.name)) continue
            for (m in APP_ID.findAll(readText(zf, e))) ids.add(e.name to m.groupValues[2])
        }
        if (ids.isEmpty()) throw IllegalStateException("No applicationId line was found in the zip.")
        if (ids.size > 1) {
            throw IllegalStateException("applicationId was found ${ids.size} times (" + ids.joinToString { it.first } + "). It must be exactly once.")
        }
        val defaults = names.filter { !it.isDirectory && DEFAULT_STRINGS.matches(it.name) }
        val hits = ArrayList<Pair<ZipEntry, MatchResult>>()
        for (e in defaults) {
            val ms = LABEL.findAll(readText(zf, e)).toList()
            if (ms.size > 1) throw IllegalStateException("app_name was found ${ms.size} times in ${e.name}. It must be exactly once.")
            if (ms.size == 1) hits.add(e to ms[0])
        }
        if (hits.isEmpty()) throw IllegalStateException("No app_name label was found in res/values/strings.xml.")
        if (hits.size > 1) {
            throw IllegalStateException("app_name was found in ${hits.size} default strings.xml files (" + hits.joinToString { it.first.name } + "). It must be exactly one.")
        }
        return Found(ids[0].second, unescape(hits[0].second.groupValues[2]))
    }

    /** Works out the new bytes of every file to change, again from the zip itself, with the same exactly-once rule. */
    fun plan(zf: ZipFile, pkg: String, label: String): Plan {
        val found = find(zf)
        val edits = LinkedHashMap<String, ByteArray>()
        val names = ArrayList<ZipEntry>()
        val en = zf.entries()
        while (en.hasMoreElements()) names.add(en.nextElement())
        if (pkg != found.pkg) {
            for (e in names) {
                if (e.isDirectory || !isGradle(e.name)) continue
                val text = readText(zf, e)
                val m = APP_ID.findAll(text).toList()
                if (m.size != 1) continue
                val g = m[0].groups[2]!!
                edits[e.name] = (text.substring(0, g.range.first) + pkg + text.substring(g.range.last + 1)).toByteArray(Charsets.UTF_8)
            }
        }
        if (label != found.label) {
            val def = names.first { !it.isDirectory && DEFAULT_STRINGS.matches(it.name) && LABEL.containsMatchIn(readText(zf, it)) }
            val resDir = def.name.removeSuffix("values/strings.xml")
            val esc = escape(label)
            for (e in names) {
                if (e.isDirectory) continue
                if (!(e.name == def.name || (e.name.startsWith(resDir + "values-") && e.name.endsWith("/strings.xml") &&
                        e.name.removePrefix(resDir).count { it == '/' } == 1))) continue
                val text = readText(zf, e)
                val ms = LABEL.findAll(text).toList()
                if (ms.size > 1) throw IllegalStateException("app_name was found ${ms.size} times in ${e.name}. It must be exactly once.")
                if (ms.size != 1) continue
                val g = ms[0].groups[2]!!
                edits[e.name] = (text.substring(0, g.range.first) + esc + text.substring(g.range.last + 1)).toByteArray(Charsets.UTF_8)
            }
        }
        return Plan(found.pkg, found.label, edits)
    }

    /**
     * Lists the places where the old package name is written by hand (so it will not follow the rename),
     * plus names that would clash if both copies of the app are installed together. Nothing here is changed.
     */
    fun reviewList(zf: ZipFile, old: String): String {
        val token = Regex("(?<![A-Za-z0-9_.])" + Regex.escape(old) + "(?![A-Za-z0-9_])(?!\\.[A-Za-z_\"])")
        val hand = ArrayList<String>()
        var handTotal = 0
        val clash = ArrayList<String>()
        val en = zf.entries()
        while (en.hasMoreElements()) {
            val e = en.nextElement()
            if (e.isDirectory || e.size > MAX_SCAN) continue
            val leaf = e.name.substringAfterLast('/')
            val ext = leaf.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext !in SCAN_EXT) continue
            val bytes = zf.getInputStream(e).use { it.readBytes() }
            val text = String(bytes, Charsets.UTF_8)
            for (m in token.findAll(text)) {
                val idx = m.range.first
                val ls = text.lastIndexOf('\n', idx) + 1
                val head = if (idx - ls < 200) text.substring(ls, idx).trim() else ""
                if (head == "package" || head == "import" || head.startsWith("namespace") || head.startsWith("applicationId")) continue
                val lineNo = text.substring(0, idx).count { it == '\n' } + 1
                val from = maxOf(0, idx - 36)
                val to = minOf(text.length, m.range.last + 37)
                val snip = text.substring(from, to).replace('\n', ' ').replace('\r', ' ').trim()
                handTotal++
                if (hand.size < MAX_LINES) hand.add("${e.name.substringAfter('/')}:$lineNo  …$snip…")
            }
            if (leaf == "AndroidManifest.xml") {
                val xml = text
                for (m in PERMISSION.findAll(xml)) clash.add("permission ${m.groupValues[1]}")
                for (m in AUTHORITY.findAll(xml)) {
                    if (!m.groupValues[1].contains("\${applicationId}")) clash.add("provider name ${m.groupValues[1]}")
                }
            }
        }
        val sb = StringBuilder()
        sb.append("Package name written by hand: $handTotal place(s)\n")
        if (handTotal == 0) sb.append("(none found)\n")
        for ((i, s) in hand.withIndex()) sb.append("${i + 1}. $s\n")
        if (handTotal > hand.size) sb.append("...and ${handTotal - hand.size} more\n")
        sb.append("\nFixed names that clash if the old app and the renamed app are both installed:\n")
        if (clash.isEmpty()) sb.append("(none found)") else for (c in clash.distinct()) sb.append("- $c\n")
        return sb.toString().trimEnd()
    }

    private fun escape(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '\'' -> sb.append("\\'")
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun unescape(s: String): String {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'")
            .replace("\\'", "'").replace("\\\"", "\"").replace("\\\\", "\\").replace("&amp;", "&").trim()
    }


    /** Reads the whole new zip back: every checksum, every edited file, and finds the two names again. */
    fun check(file: File, expected: Int, plan: Plan, pkg: String, label: String): String? {
        return try {
            var n = 0
            val got = HashMap<String, ByteArray>()
            ZipInputStream(file.inputStream().buffered()).use { zi ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val e = zi.nextEntry ?: break
                    val sink = if (plan.edits.containsKey(e.name)) java.io.ByteArrayOutputStream() else null
                    while (true) {
                        val r = zi.read(buf)
                        if (r < 0) break
                        sink?.write(buf, 0, r)
                    }
                    if (sink != null) got[e.name] = sink.toByteArray()
                    n++
                }
            }
            if (n != expected) return "the new zip holds $n files, expected $expected."
            for ((name, bytes) in plan.edits) {
                val back = got[name] ?: return "$name is missing in the new zip."
                if (!back.contentEquals(bytes)) return "$name in the new zip does not match what was written."
            }
            val again = ZipFile(file).use { zf -> find(zf) }
            when {
                again.pkg != pkg -> "the new zip says package ${again.pkg}, expected $pkg."
                again.label != label -> "the new zip says app name ${again.label}, expected $label."
                else -> null
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
