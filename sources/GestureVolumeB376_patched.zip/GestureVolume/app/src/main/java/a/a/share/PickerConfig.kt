package a.a.share

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File

/**
 * What the "A" and "A files" tabs of the system file picker show. Set in Appearance, read by
 * [PickerProvider] each time the picker lists something, so a change shows the next time the picker opens.
 *
 *  - "A" tab: a list of photos and the files and folders of chosen folders (Download unless changed).
 *  - "A files" tab: every file on the phone, folder by folder, with kinds of file that can be hidden.
 *
 * Every default is the way the tabs behaved before these settings existed.
 */
class PickerConfig(private val sp: SharedPreferences) {
    constructor(context: Context) : this(context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE))

    private fun b(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun set(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()

    // ---------------------------------------------------------------- the "A" tab
    var aShow: Boolean get() = b("a_show", true); set(v) = set("a_show", v)
    var aPhotos: Boolean get() = b("a_photos", true); set(v) = set("a_photos", v)
    var aVideos: Boolean get() = b("a_videos", false); set(v) = set("a_videos", v)
    var aAudio: Boolean get() = b("a_audio", false); set(v) = set("a_audio", v)
    /** Files lying directly in the listed folders. */
    var aFiles: Boolean get() = b("a_direct", true); set(v) = set("a_direct", v)
    /** The folders inside the listed folders, shown as folders. */
    var aFolders: Boolean get() = b("a_folders", true); set(v) = set("a_folders", v)
    /** Photos, videos and audio inside those folders also appear in the flat list. */
    var aMediaInFolders: Boolean get() = b("a_media_in_folders", false); set(v) = set("a_media_in_folders", v)
    var aHidden: Boolean get() = b("a_hidden", false); set(v) = set("a_hidden", v)
    /** Only items changed in the last this many days; 0 = any time. */
    var aDays: Int get() = sp.getInt("a_days", 0); set(v) = sp.edit().putInt("a_days", v).apply()
    var aMax: Int get() = sp.getInt("a_max", 300); set(v) = sp.edit().putInt("a_max", v).apply()
    /** Folders (under the phone's storage, or a full path) listed like Download, comma separated. */
    var aDirsText: String get() = sp.getString("a_dirs", DOWNLOAD) ?: DOWNLOAD; set(v) = sp.edit().putString("a_dirs", v).apply()
    /** Where the "A" tab opens; empty = the photos and downloads list. */
    var aStart: String get() = sp.getString("a_start", "") ?: ""; set(v) = sp.edit().putString("a_start", v).apply()

    // ---------------------------------------------------------------- the "A files" tab
    var fShow: Boolean get() = b("f_show", true); set(v) = set("f_show", v)
    var fPhotos: Boolean get() = b("f_photos", true); set(v) = set("f_photos", v)
    var fVideos: Boolean get() = b("f_videos", true); set(v) = set("f_videos", v)
    var fAudio: Boolean get() = b("f_audio", true); set(v) = set("f_audio", v)
    var fDocs: Boolean get() = b("f_docs", true); set(v) = set("f_docs", v)
    var fArchives: Boolean get() = b("f_archives", true); set(v) = set("f_archives", v)
    var fOther: Boolean get() = b("f_other", true); set(v) = set("f_other", v)
    var fFolders: Boolean get() = b("f_folders", true); set(v) = set("f_folders", v)
    var fHidden: Boolean get() = b("f_hidden", true); set(v) = set("f_hidden", v)
    /** Where the "A files" tab opens; empty = the phone's storage. */
    var fStart: String get() = sp.getString("f_start", "") ?: ""; set(v) = sp.edit().putString("f_start", v).apply()

    // ---------------------------------------------------------------- what the settings mean
    /** The listed folders as paths under the storage root ("Download", "Documents/Work"). */
    fun aDirs(): List<String> =
        aDirsText.split(',', '\n').map { it.trim().trim('/') }.filter { it.isNotEmpty() && !it.startsWith("..") }.distinct()
            .ifEmpty { listOf(DOWNLOAD) }

    /** Whether a file or folder of the "A files" tab is shown. */
    fun showsInFiles(f: File): Boolean {
        if (!fHidden && f.name.startsWith(".")) return false
        if (f.isDirectory) return fFolders
        return when (kindOf(f.name)) {
            Kind.PHOTO -> fPhotos
            Kind.VIDEO -> fVideos
            Kind.AUDIO -> fAudio
            Kind.DOC -> fDocs
            Kind.ARCHIVE -> fArchives
            Kind.OTHER -> fOther
        }
    }

    enum class Kind { PHOTO, VIDEO, AUDIO, DOC, ARCHIVE, OTHER }

    companion object {
        const val FILE = "a_picker_cfg"
        const val DOWNLOAD = "Download"

        private val docExt = setOf(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "txt", "rtf", "csv", "epub",
            "md", "html", "htm", "json", "xml", "log", "tsv"
        )
        private val archiveExt = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "apk", "apks", "xapk", "apkm", "jar")

        fun kindOf(name: String): Kind {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = PickerProvider.mimeOf(name)
            return when {
                mime.startsWith("image/") -> Kind.PHOTO
                mime.startsWith("video/") -> Kind.VIDEO
                mime.startsWith("audio/") -> Kind.AUDIO
                ext in archiveExt -> Kind.ARCHIVE
                ext in docExt || mime.startsWith("text/") -> Kind.DOC
                else -> Kind.OTHER
            }
        }

        /** A folder named by the user: "Download/Apps" under the storage, or a full path. Null when it is not a folder. */
        fun resolveDir(path: String): File? {
            val p = path.trim()
            if (p.isEmpty()) return null
            val root = Environment.getExternalStorageDirectory()
            val f = when {
                p == "." || p == "/" -> root
                p.startsWith("/") -> File(p)
                p.split('/').any { it == ".." } -> return null
                else -> File(root, p)
            }
            return f.takeIf { it.isDirectory }
        }

        /** Tells the picker that the list of tabs may have changed. */
        fun changed(context: Context) {
            val app = context.applicationContext
            runCatching {
                app.contentResolver.notifyChange(DocumentsContract.buildRootsUri("${app.packageName}.docs"), null)
            }
        }
    }
}
