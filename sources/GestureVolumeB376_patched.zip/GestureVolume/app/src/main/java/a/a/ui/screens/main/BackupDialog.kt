package a.a.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import a.a.data.local.SharedPref
import a.a.strip.SettingsBackup
import a.a.strip.StripConfig
import a.a.ui.components.CardWindow
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.ui.screens.strip.backupLauncher
import a.a.ui.screens.strip.restoreLauncher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import a.a.strip.ApkCloner
import a.a.strip.AutoBackup
import a.a.strip.FileSharer

/**
 * The three backups (settings, scripts, everything): save, share, restore, or make an APK that carries them,
 * in the card design (back arrow = close). The last result and the "Share the APK" row sit at the top so they
 * are seen without scrolling. Same launchers, same file names, same calls as before.
 */
@Composable
fun BackupDialog(pref: SharedPref, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    val backupSettings = backupLauncher(pref.sharedPreferences, true, false, "Settings saved") { status = it }
    val restoreSettings = restoreLauncher(pref.sharedPreferences, true, false, "settings", { }) { status = it }
    val backupScripts = backupLauncher(pref.sharedPreferences, false, true, "Scripts saved") { status = it }
    val restoreScripts = restoreLauncher(pref.sharedPreferences, false, true, "scripts", { }) { status = it }
    var askRestore by remember { mutableStateOf<(() -> Unit)?>(null) }
    val backupAll = backupLauncher(pref.sharedPreferences, true, true, "Everything saved") { status = it }
    val restoreAll = restoreLauncher(pref.sharedPreferences, true, true, "settings and scripts", { }) { status = it }
    // The APK just made, kept so it can be shared at once instead of fetched from Downloads.
    var madeUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var madeName by remember { mutableStateOf("") }
    fun makeApk(name: String, settings: Boolean, scripts: Boolean) {
        status = "Making the APK…"
        madeUri = null
        val strip = if (scripts) StripConfig.load(context, pref.getStripConfigJson()).toJson() else null
        val all = if (settings) SettingsBackup.toJson(pref.sharedPreferences, true, false) else null
        scope.launch {
            val made = withContext(Dispatchers.IO) {
                ApkCloner.makeAndSave(context.applicationContext, name, strip, all)
            }
            status = made.message
            madeUri = made.uri
            madeName = name
        }
    }
    fun shareBackup(name: String, settings: Boolean, scripts: Boolean) {
        status = runCatching {
            FileSharer.shareText(context, name, SettingsBackup.toJson(pref.sharedPreferences, settings, scripts))
        }.getOrElse { "Could not share: ${it.message}" }
    }
    var autoOn by remember { mutableStateOf(AutoBackup.enabled(context)) }
    var files by remember { mutableStateOf<List<AutoBackup.Entry>?>(null) }
    var chosen by remember { mutableStateOf<AutoBackup.Entry?>(null) }
    fun restoreFrom(e: AutoBackup.Entry, settings: Boolean, scripts: Boolean) {
        val json = AutoBackup.read(context, e)
        if (json != null) SettingsBackup.saveUndo(context, pref.sharedPreferences)
        status = if (json == null) "Could not read ${e.name}" else {
            val n = SettingsBackup.apply(pref.sharedPreferences, json, settings, scripts)
            when {
                n < 0 -> "${e.name} is not a backup"
                n == 0 -> "${e.name} holds nothing of that part"
                else -> "Restored $n items from ${e.name}"
            }
        }
        chosen = null
    }

    CardWindow(title = "Backups", onBack = onDismiss) {
        if (status.isNotEmpty() || madeUri != null) {
            CardGroup(title = "Last result") {
                if (status.isNotEmpty()) row { sh ->
                    SettingRow(title = status, shape = sh, icon = Icons.Filled.Info)
                }
                madeUri?.let { uri ->
                    row { sh ->
                        LinkRow(
                            title = "Share $madeName", summary = "Send the APK to another phone or app", shape = sh, icon = Icons.Filled.Share,
                        ) {
                            runCatching {
                                FileSharer.shareUri(context, uri, "application/vnd.android.package-archive", madeName)
                            }.onFailure { status = "Could not share: ${it.message}" }
                        }
                    }
                }
            }
        }
        CardGroup(title = "Settings", hint = "Everything except the cells.") {
            row { sh ->
                LinkRow(title = "Backup", summary = "Save to a file you choose", shape = sh, icon = Icons.Filled.Download) {
                    backupSettings.launch("A only settings.json")
                }
            }
            row { sh ->
                LinkRow(title = "Share", summary = "Send it as a file to another app", shape = sh, icon = Icons.Filled.Share) {
                    shareBackup("A only settings.json", true, false)
                }
            }
            row { sh ->
                LinkRow(title = "Restore", summary = "Take the settings back from a file", shape = sh, icon = Icons.Filled.History) {
                    restoreSettings.launch(arrayOf("*/*"))
                }
            }
            row { sh ->
                LinkRow(title = "Make APK", summary = "A copy of A with these settings built in", shape = sh, icon = Icons.Filled.Apps) {
                    makeApk("A only settings.apk", true, false)
                }
            }
        }
        CardGroup(title = "Scripts", hint = "The cells: shortcuts, scripts and layout.") {
            row { sh ->
                LinkRow(title = "Backup", summary = "Save to a file you choose", shape = sh, icon = Icons.Filled.Download) {
                    backupScripts.launch("A only scripts.json")
                }
            }
            row { sh ->
                LinkRow(title = "Share", summary = "Send it as a file to another app", shape = sh, icon = Icons.Filled.Share) {
                    shareBackup("A only scripts.json", false, true)
                }
            }
            row { sh ->
                LinkRow(title = "Restore", summary = "Replaces your cells, with a question first", shape = sh, icon = Icons.Filled.History) {
                    askRestore = { restoreScripts.launch(arrayOf("*/*")) }
                }
            }
            row { sh ->
                LinkRow(title = "Make APK", summary = "A copy of A with these cells built in", shape = sh, icon = Icons.Filled.Apps) {
                    makeApk("A only scripts.apk", false, true)
                }
            }
        }
        CardGroup(title = "Everything", hint = "Settings and scripts together.") {
            row { sh ->
                LinkRow(title = "Backup", summary = "Save to a file you choose", shape = sh, icon = Icons.Filled.Download) {
                    backupAll.launch("A all settings.json")
                }
            }
            row { sh ->
                LinkRow(title = "Share", summary = "Send it as a file to another app", shape = sh, icon = Icons.Filled.Share) {
                    shareBackup("A all settings.json", true, true)
                }
            }
            row { sh ->
                LinkRow(title = "Restore", summary = "Replaces your cells, with a question first", shape = sh, icon = Icons.Filled.History) {
                    askRestore = { restoreAll.launch(arrayOf("*/*")) }
                }
            }
            row { sh ->
                LinkRow(title = "Make APK", summary = "A copy of A with everything built in", shape = sh, icon = Icons.Filled.Apps) {
                    makeApk("A all settings.apk", true, true)
                }
            }
        }
        if (SettingsBackup.hasUndo(context)) {
            CardGroup(title = "After a restore") {
                row { sh ->
                    LinkRow(
                        title = "Undo last restore", summary = "Brings back what you had before the last restore",
                        shape = sh, icon = Icons.Filled.Refresh,
                    ) {
                        val n = SettingsBackup.undoLast(context, pref.sharedPreferences)
                        status = if (n > 0) "Undone: $n items are back as before the last restore. Close and reopen the app." else "Nothing to undo"
                    }
                }
            }
        }
        CardGroup(title = "Automatic backup") {
            row { sh ->
                SwitchRow(
                    title = "Save a copy after I change settings", checked = autoOn, shape = sh, icon = Icons.Filled.Save,
                    summary = "Into Download/settings. The last 5 are kept.",
                ) {
                    autoOn = it
                    pref.sharedPreferences.edit().putBoolean(AutoBackup.ON, it).apply()
                    AutoBackup.refresh(context)
                    if (it) scope.launch(Dispatchers.IO) {
                        AutoBackup.save(context)
                        files = AutoBackup.list(context)
                    }
                }
            }
            row { sh ->
                LinkRow(title = "Check files", summary = "See the saved copies and restore from one", shape = sh, icon = Icons.Filled.History) {
                    scope.launch { files = withContext(Dispatchers.IO) { AutoBackup.list(context) } }
                }
            }
        }
        files?.let { list ->
            CardGroup(title = "Saved copies") {
                if (list.isEmpty()) row { sh ->
                    SettingRow(title = "No saved files found in Download/settings.", shape = sh, icon = Icons.Filled.Info)
                }
                list.forEach { e ->
                    row { sh ->
                        LinkRow(
                            title = e.name.removePrefix("A settings ").removeSuffix(".json"),
                            summary = "Tap to choose what to restore", shape = sh, icon = Icons.Filled.History,
                        ) { chosen = e }
                    }
                }
            }
        }
    }

    chosen?.let { e ->
        CardWindow(title = "Restore ${e.name.removePrefix("A settings ").removeSuffix(".json")}", onBack = { chosen = null }) {
            CardGroup(title = "What should be restored from this file?") {
                row { sh ->
                    LinkRow(
                        title = "Only scripts", summary = "The cells, their shortcuts and scripts", shape = sh, icon = Icons.Filled.History,
                    ) { askRestore = { restoreFrom(e, false, true) } }
                }
                row { sh ->
                    LinkRow(
                        title = "Only settings", summary = "Everything except the cells", shape = sh, icon = Icons.Filled.History,
                    ) { restoreFrom(e, true, false) }
                }
                row { sh ->
                    LinkRow(
                        title = "Both", summary = "All settings, cells and scripts", shape = sh, icon = Icons.Filled.History,
                    ) { askRestore = { restoreFrom(e, true, true) } }
                }
            }
        }
    }

    askRestore?.let { go ->
        CardWindow(title = "Replace your cells?", onBack = { askRestore = null }) {
            CardGroup(title = "Before you continue") {
                row { sh ->
                    SettingRow(
                        title = "This replaces your current cells and their shortcuts", shape = sh, icon = Icons.Filled.Info,
                        summary = "A copy of what you have now is kept first, and \"Undo last restore\" in the Backups window brings it back.",
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { askRestore = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(onClick = { askRestore = null; go() }, modifier = Modifier.weight(1f)) { Text("Continue") }
            }
        }
    }
}
