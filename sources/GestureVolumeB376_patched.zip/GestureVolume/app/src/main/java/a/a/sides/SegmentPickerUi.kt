package a.a.sides

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.ShellCommandDialog
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import a.a.ui.screens.strip.AppList
import a.a.ui.screens.strip.AppShortcutsPage
import a.a.ui.screens.strip.BuiltInPage
import a.a.ui.screens.strip.INTENT_ACTION_PREFIX
import a.a.ui.screens.strip.MyScriptsPage
import a.a.ui.screens.strip.loadCreators
import a.a.utils.HandlerActions
import a.a.flow.NativePicker

private enum class PickPage { MENU, BUILTIN, APPS, SHORTCUTS, SCRIPTS }

/**
 * The action picker of a segment gesture. It uses the very same pages as the cell editor
 * (Built-in shortcuts with search and "A Windows Shortcuts", apps with icons, App shortcuts, My Scripts).
 */
@Composable
fun SegmentPicker(activity: SidesActivity, slot: String, onPicked: (String) -> Unit, onClose: () -> Unit) {
    var page by remember { mutableStateOf(PickPage.MENU) }
    var shell by remember { mutableStateOf(false) }
    var shellText by remember { mutableStateOf("") }
    fun done(a: String) { onClose(); onPicked(a) }
    val fileLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching { activity.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            done("File:$uri")
        }
    }
    Dialog(onDismissRequest = { if (page != PickPage.MENU) page = PickPage.MENU else onClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.fillMaxSize().then(if (page == PickPage.MENU) Modifier else Modifier.statusBarsPadding()),
            color = MaterialTheme.colorScheme.background,
        ) {
            when (page) {
                PickPage.MENU -> {
                    val mainNow = SidePicker.mainNow(activity, slot)
                    val rows = ArrayList<Pair<String, () -> Unit>>()
                    // An outside-window action is its own: nothing to follow or copy from the main slider.
                    if (slot != "edge") {
                        rows += "Same as Main Slider (Live)" to { done(Seg.MAIN) }
                        rows += "Copy Main Slider's current: ${SidePicker.label(activity, mainNow)} (Stays Fixed)" to { done(mainNow) }
                    }
                    if (slot == "in") rows += "Cells window, mirrored for this side" to { done(Seg.STRIP) }
                    rows += "Built-in Shortcuts (with device actions)" to { page = PickPage.BUILTIN }
                    rows += "App shortcuts" to { page = PickPage.SHORTCUTS }
                    rows += "Automate flow" to {
                        val cr = runCatching { loadCreators(activity) }.getOrDefault(emptyList()).firstOrNull { it.packageName == "com.llamalab.automate" }
                        if (cr == null) page = PickPage.SHORTCUTS
                        else { onClose(); SidePicker.launchCreator(activity, cr.packageName, cr.className, onPicked) }
                    }
                    rows += "Open a file" to { fileLauncher.launch(arrayOf("*/*")) }
                    rows += "Shell command" to { shell = true }
                    rows += "My Scripts" to { page = PickPage.SCRIPTS }
                    rows += "Nothing" to { done("") }
                    AWindowPage(title = "Choose an action", onBack = onClose) { pad ->
                        Column(
                            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 24.dp),
                        ) {
                            CardGroup(title = "Pick one") {
                                rows.forEach { (name, go) -> row { sh -> SettingRow(title = name, shape = sh, onClick = go) } }
                            }
                        }
                    }
                    if (shell) ShellCommandDialog(
                        initial = shellText,
                        onUse = { text -> shell = false; shellText = text; if (text.isNotBlank()) done("Shell:" + text.trim()) },
                        onDismiss = { shell = false },
                    )
                }
                PickPage.BUILTIN -> BuiltInPage(onPick = { entry, _ -> done(entry.action) }, onBack = { page = PickPage.MENU }, onPickAction = { a, _, _ -> done(a) }, onPickApp = { _, _, act -> done(act) })
                PickPage.APPS -> AppList(onPick = { app -> done(HandlerActions.launchApp(app.packageName)) }, onBack = { page = PickPage.MENU })
                PickPage.SHORTCUTS -> AppShortcutsPage(
                    onCreator = { cr -> onClose(); SidePicker.launchCreator(activity, cr.packageName, cr.className, onPicked) },
                    onShortcut = { sc -> done(INTENT_ACTION_PREFIX + sc.intentUri) },
                    onBack = { page = PickPage.MENU },
                )
                PickPage.SCRIPTS -> MyScriptsPage(onPick = { _, action, _ -> done(action) }, onBack = { page = PickPage.MENU })
            }
        }
    }
}
