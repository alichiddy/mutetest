package a.a.flow

import a.a.strip.WhenRules
import a.a.ui.motion.OutlinedButton
import a.a.ui.motion.TextButton
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * "Where": which bar the event comes from. The main bar (as always), every side segment, one chosen side
 * segment, or any bar. The value is what WhenRules.sourceMatches reads: "", "side", "any" or "seg:<id>".
 * Shared by the rows of the When list and the "When" block of a script.
 */
@Composable
internal fun WhenWhereChoice(where: String, onChange: (String) -> Unit) {
    val context = LocalContext.current
    var pick by remember { mutableStateOf(false) }
    val kind = if (where.startsWith(WhenRules.WHERE_SEG)) "seg" else where
    ChoiceRow(
        listOf(
            "The main bar" to WhenRules.WHERE_MAIN,
            "Side bars (any segment)" to WhenRules.WHERE_SIDE,
            "One side segment" to "seg",
            "Anywhere" to WhenRules.WHERE_ANY,
        ),
        kind,
    ) { if (it == "seg") pick = true else onChange(it) }
    if (kind == "seg") OutlinedButton(onClick = { pick = true }) { Text(WhenRules.whereLabel(context, where)) }
    if (pick) WhenSegmentPicker(
        onPicked = { id -> onChange(WhenRules.WHERE_SEG + id); pick = false },
        onDismiss = { pick = false },
    )
}

/** The side segments, by name ("Left 1 - volume"). */
@Composable
private fun WhenSegmentPicker(onPicked: (String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val segs = remember { WhenRules.sideSegments(context) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                Text("Choose a side segment", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                if (segs.isEmpty()) Text("There is no side segment yet. Add one in Side bars first.")
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(segs) { _, s ->
                        Text(s.second, fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { onPicked(s.first) }.padding(vertical = 12.dp))
                    }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    }
}
