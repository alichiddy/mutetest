package a.a.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import a.a.ui.components.Chevron
import a.a.ui.components.cardShape
import a.a.ui.motion.TextButton
import a.a.ui.screens.strip.SettingRow
import a.a.utils.DeviceActionIcons

/**
 * Device actions (flashlight, Wi-Fi, airplane, ...) picked in A's card design: a searchable list, then On / Off / Toggle,
 * then what the action needs (one choice, a sound and how loud, or a few words). [startGroup] skips the list when another list already chose the action. It hands back the same action string
 * and name as the old plain dialogs did, so nothing that stores them changes. Everything is built when it opens and gone when it closes.
 */
@Composable
fun DeviceActionPicker(
    onDismiss: () -> Unit,
    onPicked: (action: String, label: String) -> Unit,
    /** When a list already chose the action, open straight at its On / Off / Toggle (or its argument) instead of the list. */
    startGroup: NativePicker.Group? = null,
) {
    val context = LocalContext.current
    val all = remember { NativePicker.groups() }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf(startGroup?.takeIf { it.options.size > 1 }) }
    // The action chosen so far: its id and its name, once it is known which one (after On / Off / Toggle).
    var target by remember { mutableStateOf<Pair<String, String>?>(null) }

    fun finish(action: String, label: String) {
        onPicked(action, label)
        onDismiss()
    }

    fun withTarget(id: String, name: String) {
        val d = NativeActions.find(id)
        val wantsArg = d != null && (d.label.contains("argument", true) || d.help.contains("Argument", true))
        if (ActionArgs.specFor(id, context) == null && !wantsArg) finish(NativePicker.PREFIX + id, name)
        else target = id to name
    }

    // One mode only: go straight on to its argument, or finish when it needs none.
    LaunchedEffect(Unit) {
        startGroup?.takeIf { it.options.size == 1 }?.let { withTarget(it.options[0].second, it.title) }
    }

    val t = target
    val g = group
    if (t != null) {
        DeviceArgDialog(t.first, t.second, onDone = { action, label -> finish(action, label) }, onDismiss = onDismiss)
    } else if (g != null) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(g.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    g.options.forEachIndexed { i, (mode, id) ->
                        SettingRow(
                            title = mode, shape = cardShape(i, g.options.size), compact = true,
                            onClick = { withTarget(id, g.title + ": " + mode.lowercase()) },
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
    } else if (startGroup == null) {
        val q = query.trim().lowercase()
        val shown = all.filter { q.isEmpty() || it.title.lowercase().contains(q) }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Device actions") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        query, { query = it }, label = { Text("Search") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        itemsIndexed(shown) { i, grp ->
                            SettingRow(
                                title = grp.title, shape = cardShape(i, shown.size), compact = true,
                                icon = DeviceActionIcons.forTitle(grp.title),
                                summary = grp.options.map { it.first }.filter { it.isNotEmpty() }.joinToString(" \u00b7 ").takeIf { it.isNotEmpty() },
                                onClick = {
                                    if (grp.options.size == 1) withTarget(grp.options[0].second, grp.title) else group = grp
                                },
                                trailing = { Chevron() },
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
    }
}

/** What one device action needs after it is picked: a choice, a sound and how loud, or a few words. */
@Composable
private fun DeviceArgDialog(id: String, name: String, onDone: (action: String, label: String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    when (val spec = ActionArgs.specFor(id, context)) {
        is ActionArgs.Choices -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(name) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    spec.options.forEachIndexed { i, (label, v) ->
                        SettingRow(
                            title = label, shape = cardShape(i, spec.options.size), compact = true,
                            onClick = { onDone(NativePicker.PREFIX + id + "|" + v, "$name ($label)") },
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
        ActionArgs.StreamPercent -> {
            var stream by remember { mutableStateOf(ActionArgs.STREAMS[0].second) }
            var percent by remember { mutableStateOf("100") }
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text(name) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FormCard("Which sound") { ChoiceRow(ActionArgs.STREAMS, stream) { stream = it } }
                        FormCard("How loud") {
                            NumberPick(percent, ActionArgs.PERCENTS, step = 5, min = 0, max = 100, shown = { "$it%" }) { percent = it }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val soundName = ActionArgs.STREAMS.firstOrNull { it.second == stream }?.first ?: stream
                        onDone(NativePicker.PREFIX + id + "|" + stream + ":" + percent, "$name ($soundName $percent%)")
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
            )
        }
        null -> {
            var text by remember { mutableStateOf("") }
            val help = NativeActions.find(id)?.help.orEmpty()
            AlertDialog(
                onDismissRequest = onDismiss,
                title = { Text(name) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        FormCard(null) {
                            OutlinedTextField(
                                text, { text = it }, label = { Text("Argument") }, singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        if (help.isNotBlank()) FormHint(help)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = text.trim()
                        onDone(NativePicker.PREFIX + id + if (a.isNotEmpty()) "|$a" else "", if (a.isNotEmpty()) "$name ($a)" else name)
                    }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
            )
        }
    }
}
