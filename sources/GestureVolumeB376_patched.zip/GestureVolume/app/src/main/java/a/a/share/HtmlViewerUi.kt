package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebView
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** A web view that tells its owner how far it is scrolled, for the quick scroll bar. */
class ScrollWebView(context: Context) : WebView(context) {
    var onScrolled: (() -> Unit)? = null
    /** A single tap anywhere on the page (finger down and up in place, no drag, one finger). */
    var onTap: (() -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var downAt = 0L
    private var tapOk = false
    /** The next touch is not a tap (it only stopped the automatic scrolling). */
    var swallowTap = false
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; downAt = event.eventTime; tapOk = !swallowTap; swallowTap = false }
            MotionEvent.ACTION_POINTER_DOWN -> tapOk = false
            MotionEvent.ACTION_MOVE -> if (tapOk) {
                val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop
                if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) tapOk = false
            }
            MotionEvent.ACTION_UP -> {
                if (tapOk && event.eventTime - downAt < android.view.ViewConfiguration.getLongPressTimeout()) onTap?.invoke()
                tapOk = false
            }
            MotionEvent.ACTION_CANCEL -> tapOk = false
        }
        return super.onTouchEvent(event)
    }
    fun range() = computeVerticalScrollRange()
    fun offset() = computeVerticalScrollOffset()
    fun extent() = computeVerticalScrollExtent()
    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrolled?.invoke()
    }
}

/**
 * The HTML viewer's own controls, drawn over the page only while they are used: a blue bar to scroll
 * quickly and, above it, up to four round buttons (screen mode, stay awake, scroll by itself, settings). Scrolling or
 * touching shows them; a set time (3 seconds by default) without touching the bar or a button hides them again.
 *
 * Screen mode cycles: both system bars, status bar only, navigation bar only, full screen.
 * Everything is plain views and nothing runs while the controls are hidden.
 */
class HtmlViewerUi(private val act: Activity, private val web: ScrollWebView, private val frame: FrameLayout) {
    private val prefs = act.getSharedPreferences("html_viewer", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val density = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()
    private val blue = 0xFF1E88E5.toInt()

    private val layer = FrameLayout(act)
    private val buttons = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
    private val bar = Bar(act)
    private var clock: TextView? = null
    private var mode = 0 // 0 both bars, 1 status bar only, 2 navigation bar only, 3 full screen
    private var awake = false
    private var barMove = false   // the bar is being dragged to a new place (Done ends it)
    private var barPrev = false   // the bar is shown by a settings change even if the page is short
    private var holding = false
    private val hideRun = Runnable { if (!holding) { barPrev = false; layer.visibility = View.GONE } }
    private val doneBtn = TextView(act).apply {
        text = "✓ Done"; setTextColor(0xFF0B3D33.toInt()); setTypeface(typeface, Typeface.BOLD); textSize = 15f
        setPadding(dp(14), dp(9), dp(14), dp(9)); visibility = View.GONE
        background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xFFD9A94A.toInt()); setStroke(dp(2), 0xFF0B3D33.toInt()) }
    }

    private val tools = HtmlViewerTools(act, web, frame, prefs)
    private val modeBtn = IconBtn(act, 0)
    private val awakeBtn = IconBtn(act, 1)
    private val setBtn = IconBtn(act, 2)
    private val scrollBtn = IconBtn(act, 3)

    fun start() {
        mode = prefs.getInt("mode", 0).coerceIn(0, 3)
        awake = prefs.getBoolean("awake", false)
        layer.visibility = View.GONE
        frame.addView(layer, FrameLayout.LayoutParams(-1, -1))
        layer.addView(bar, FrameLayout.LayoutParams(dp(44), -1, Gravity.END or Gravity.TOP))
        layer.addView(buttons, FrameLayout.LayoutParams(dp(52), -2, Gravity.END or Gravity.TOP))
        layer.addView(doneBtn, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = dp(24) })
        doneBtn.setOnClickListener { barMove = false; holding = false; layoutBar(); show(); showBarSettings() }
        // The bar's length and place are a share of the screen height: lay it out again when the layer's height is known or changes.
        layer.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob -> if (b - t != ob - ot && !barMove) layer.post { layoutBar() } }
        modeBtn.setOnClickListener { navShown = false; mode = (mode + 1) % 4; prefs.edit().putInt("mode", mode).apply(); applyMode(); show() }
        awakeBtn.setOnClickListener { awake = !awake; prefs.edit().putBoolean("awake", awake).apply(); applyAwake(); show() }
        setBtn.setOnClickListener { holding = true; showSettings() }
        scrollBtn.setOnClickListener { if (tools.autoRunning()) tools.stopAuto() else tools.startAuto(); show() }
        tools.onAuto = { scrollBtn.state = if (tools.autoRunning()) 1 else 0; scrollBtn.invalidate() }
        layoutButtons()
        web.onScrolled = {
            tools.noteScroll()
            if (navShown) { navShown = false; handler.removeCallbacks(navHideRun); applyMode() }
            // While the page scrolls by itself the buttons stay away (only the bar, if it is showing, follows).
            val auto = tools.autoRunning()
            if (auto && layer.visibility == View.VISIBLE) bar.invalidate()
            if (!auto) show()
        }
        web.onTap = { onWebTap() }
        applyMode()
        if (awake) applyAwake()
        tools.start()
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        web.onScrolled = null
        web.onTap = null
        tools.stop()
    }

    /** The window is paused: the place in the page is written now. */
    fun saveNow() = tools.saveScroll()

    /** The page has loaded: the page style, remembered scroll place and so on are applied to it. */
    fun onPageFinished() = tools.onPageFinished()

    fun reapply() = applyMode()

    private fun showBtn(key: String) = prefs.getBoolean(key, true)

    /** Where the scroll bar is: 0 right, 1 left, 2 not shown. Its own setting; older installs follow the two older ones until it is set. */
    private fun barSide(): Int =
        if (prefs.contains("barSide")) prefs.getInt("barSide", 0).coerceIn(0, 2)
        else if (!prefs.getBoolean("showBar", true)) 2 else prefs.getInt("side", 0).coerceIn(0, 1)

    private var movingBtn = false

    private fun layoutButtons() {
        val list = ArrayList<IconBtn>()
        if (showBtn("showModeBtn")) list.add(modeBtn)
        if (showBtn("showAwakeBtn")) list.add(awakeBtn)
        if (showBtn("showScrollBtn")) list.add(scrollBtn)
        list.add(setBtn)
        val landscape = prefs.getBoolean("btnLandscape", false)
        val free = prefs.getBoolean("btnFree", false)
        val separate = free && prefs.getBoolean("btnSeparate", false)
        buttons.removeAllViews()
        for (x in listOf(modeBtn, awakeBtn, scrollBtn, setBtn)) (x.parent as? ViewGroup)?.removeView(x)
        buttons.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0; scrollBtn.state = if (tools.autoRunning()) 1 else 0
        val bs = barSide()
        fun childLp() = LinearLayout.LayoutParams(dp(44), dp(44)).apply { if (landscape) leftMargin = dp(6) else topMargin = dp(6) }
        buttons.visibility = View.VISIBLE
        val lp = buttons.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = 0; lp.rightMargin = 0; lp.topMargin = 0; lp.bottomMargin = 0
        if (!free) {
            // As before: the buttons sit on one edge (the older side setting) at the top, middle or bottom of it.
            val left = prefs.getInt("side", 0) == 1
            val pos = prefs.getInt("btnPos", 0).coerceIn(0, 2)
            val edge = if (left) Gravity.START else Gravity.END
            val sameEdge = bs != 2 && (bs == 1) == left
            // In the middle of the same edge the buttons sit beside the bar (clear of its touch zone and gap).
            lp.width = if (landscape) -2 else dp(52); lp.height = -2
            lp.gravity = edge or (when (pos) { 0 -> Gravity.TOP; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.BOTTOM })
            val beside = if (pos == 1 && sameEdge) dp(pi("barGap", 6, -60, 400).coerceAtLeast(0)) + dp(pi("barHit", 34, 20, 90)) else 0
            lp.leftMargin = if (left) beside else 0
            lp.rightMargin = if (left) 0 else beside
            for (x in list) { buttons.addView(x, childLp()); x.setOnTouchListener(null) }
            buttons.translationX = 0f; buttons.translationY = 0f
        } else if (!separate) {
            // Free: all together, dropped wherever they are dragged (like the clock), else in the chosen corner.
            lp.width = -2; lp.height = -2
            lp.gravity = cornerOf(prefs.getInt("btnCorner", 2))
            lp.setMargins(dp(8), dp(8), dp(8), dp(8))
            for (x in list) { buttons.addView(x, childLp()); makeDraggable(x, buttons, "btnX", "btnY") }
            buttons.translationX = 0f; buttons.translationY = 0f
        } else {
            // Free and separate: every button has its own corner spot and its own dropped place.
            buttons.visibility = View.GONE
            val corner = prefs.getInt("btnCorner", 2)
            list.forEachIndexed { i, x ->
                val keyN = when (x) { modeBtn -> "0"; awakeBtn -> "1"; scrollBtn -> "3"; else -> "2" }
                val l = FrameLayout.LayoutParams(dp(44), dp(44), cornerOf(corner))
                val step = dp(8) + i * dp(50)
                val right = corner == 1 || corner == 3
                val bottom = corner == 2 || corner == 3
                if (landscape) { if (right) l.rightMargin = step else l.leftMargin = step; if (bottom) l.bottomMargin = dp(8) else l.topMargin = dp(8) }
                else { if (right) l.rightMargin = dp(8) else l.leftMargin = dp(8); if (bottom) l.bottomMargin = step else l.topMargin = step }
                x.translationX = 0f; x.translationY = 0f
                layer.addView(x, l)
                makeDraggable(x, x, "btnX$keyN", "btnY$keyN")
            }
        }
        buttons.layoutParams = lp
        layoutBar()
        layer.post { placeStored() }
    }

    private fun pi(key: String, def: Int, lo: Int, hi: Int) = prefs.getInt(key, def).coerceIn(lo, hi)

    /**
     * Puts the scroll bar where its settings say: a length (share of the screen height), an up/down place
     * (share of the free height), a gap from the screen edge in dp (negative = partly behind the edge, so only
     * part of the handle shows) and a touch zone width.
     */
    private fun layoutBar() {
        val bs = barSide()
        bar.visibility = if (bs == 2 && !barMove) View.GONE else View.VISIBLE
        val vh = (if (layer.height > 0) layer.height else act.resources.displayMetrics.heightPixels).toFloat()
        val len = pi("barLen", 60, 20, 100)
        val top = pi("barTop", 50, 0, 100)
        val gap = pi("barGap", 6, -60, 400)
        val hit = pi("barHit", 34, 20, 90)
        val h = Math.min(vh - dp(8), Math.max(dp(120).toFloat(), vh * len / 100f)).toInt()
        val lp = bar.layoutParams as FrameLayout.LayoutParams
        lp.width = dp(hit); lp.height = h
        lp.gravity = (if (bs == 1) Gravity.START else Gravity.END) or Gravity.TOP
        lp.topMargin = ((vh - h) * top / 100f).toInt(); lp.bottomMargin = 0
        lp.leftMargin = if (bs == 1) dp(gap) else 0
        lp.rightMargin = if (bs == 1) 0 else dp(gap)
        bar.layoutParams = lp
        bar.translationX = 0f; bar.translationY = 0f
        bar.alpha = if (barMove) 1f else pi("barOp", 85, 10, 100) / 100f
        doneBtn.visibility = if (barMove) View.VISIBLE else View.GONE
        bar.invalidate()
    }

    /** Shows the bar (even over a short page) so a change in its settings can be seen. */
    private fun previewBar() {
        if (barSide() == 2) return
        barPrev = true; layoutBar(); show()
    }

    /** The bar is dragged by hand: where it is dropped becomes its side, gap and up/down place. */
    private fun commitMove() {
        val lw = layer.width; val lh = layer.height; val w = bar.width; val h = bar.height
        val left = bar.x; val top = bar.y
        val leftSide = left + w / 2f < lw / 2f
        val gap = if (leftSide) left else lw - left - w
        val topPct = if (lh - h > 0) top / (lh - h) * 100f else 0f
        prefs.edit().putInt("barSide", if (leftSide) 1 else 0)
            .putInt("barGap", Math.round(gap / density).coerceIn(-60, 400))
            .putInt("barTop", Math.round(topPct).coerceIn(0, 100)).apply()
        layoutBar()
    }

    private fun enterMove() {
        if (barSide() == 2) prefs.edit().putInt("barSide", 0).apply()
        barMove = true; holding = true
        layoutBar(); show()
        android.widget.Toast.makeText(act, "Drag the bar where you want it, then tap ✓ Done", android.widget.Toast.LENGTH_LONG).show()
    }

    private fun cornerOf(c: Int) = when (c) {
        0 -> Gravity.TOP or Gravity.START
        1 -> Gravity.TOP or Gravity.END
        3 -> Gravity.BOTTOM or Gravity.END
        else -> Gravity.BOTTOM or Gravity.START
    }

    /** Puts the buttons where they were last dropped (their layout place is the corner; this moves them from there). */
    private fun placeStored() {
        if (movingBtn || layer.width <= 0 || !prefs.getBoolean("btnFree", false)) return
        fun place(t: View, kx: String, ky: String) {
            if (!prefs.contains(kx)) return
            t.x = prefs.getFloat(kx, 0f) * (layer.width - t.width).coerceAtLeast(1)
            t.y = prefs.getFloat(ky, 0f) * (layer.height - t.height).coerceAtLeast(1)
        }
        if (!prefs.getBoolean("btnSeparate", false)) place(buttons, "btnX", "btnY")
        else for ((x, n) in listOf(modeBtn to "0", awakeBtn to "1", setBtn to "2", scrollBtn to "3")) if (x.parent === layer) place(x, "btnX$n", "btnY$n")
    }

    /** A touch on [v] either clicks it or, once the finger has gone past the touch slop, drags [target] (the clock's way). */
    private fun makeDraggable(v: View, target: View, kx: String, ky: String) {
        var downX = 0f; var downY = 0f; var tx0 = 0f; var ty0 = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; tx0 = target.x; ty0 = target.y; moved = false
                    holding = true; handler.removeCallbacks(hideRun)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - downX).toDouble(), (e.rawY - downY).toDouble()) > dp(8)) { moved = true; movingBtn = true }
                    if (moved) {
                        target.x = (tx0 + e.rawX - downX).coerceIn(0f, (layer.width - target.width).toFloat().coerceAtLeast(0f))
                        target.y = (ty0 + e.rawY - downY).coerceIn(0f, (layer.height - target.height).toFloat().coerceAtLeast(0f))
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit()
                            .putFloat(kx, target.x / (layer.width - target.width).coerceAtLeast(1))
                            .putFloat(ky, target.y / (layer.height - target.height).coerceAtLeast(1)).apply()
                        movingBtn = false; release()
                    } else { holding = false; v.performClick() }
                }
                MotionEvent.ACTION_CANCEL -> { movingBtn = false; release() }
            }
            true
        }
    }

    /** Shows the controls and starts the 3 second countdown to hide them. */
    private fun show() {
        modeBtn.state = mode; awakeBtn.state = if (awake) 1 else 0; scrollBtn.state = if (tools.autoRunning()) 1 else 0
        modeBtn.invalidate(); awakeBtn.invalidate(); scrollBtn.invalidate()
        bar.invalidate()
        val wasHidden = layer.visibility != View.VISIBLE
        layer.visibility = View.VISIBLE
        if (wasHidden) layer.post { placeStored() }
        handler.removeCallbacks(hideRun)
        if (!holding) handler.postDelayed(hideRun, prefs.getInt("hideMs", 3000).toLong().coerceAtLeast(200L))
    }

    private fun release() { holding = false; show() }

    @Suppress("DEPRECATION")
    // The navigation bar was brought back by a tap while the mode hides it. It goes again at the next scroll or after a few seconds.
    private var navShown = false
    private val navHideRun = Runnable { if (navShown) { navShown = false; applyMode() } }

    private fun onWebTap() {
        if (!(mode == 1 || mode == 3) || navShown) return
        navShown = true
        applyMode()
        handler.removeCallbacks(navHideRun)
        handler.postDelayed(navHideRun, prefs.getInt("navTapMs", 5000).coerceIn(500, 600000).toLong())
    }

    /** The room the page leaves for the bars: none for a bar the mode hides, so the page fills its place. */
    fun padding(ins: WindowInsets): IntArray {
        val hideStatus = mode == 2 || mode == 3
        val hideNav = mode == 1 || mode == 3
        var l = 0; var t = 0; var r = 0; var b = 0
        if (Build.VERSION.SDK_INT >= 30) {
            val s = ins.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars())
            val n = ins.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars())
            if (!hideStatus) { t = s.top; l = s.left; r = s.right }
            if (!hideNav) { b = n.bottom; l = maxOf(l, n.left); r = maxOf(r, n.right) }
            // The window no longer resizes for the keyboard by itself: keep the page's fields above it.
            val ime = ins.getInsets(WindowInsets.Type.ime()).bottom
            if (ime > b) b = ime
        } else {
            if (!hideStatus) t = ins.systemWindowInsetTop
            if (!hideNav) { b = ins.systemWindowInsetBottom; l = ins.systemWindowInsetLeft; r = ins.systemWindowInsetRight }
        }
        return intArrayOf(l, t, r, b)
    }

    private fun applyMode() {
        val hideStatus = mode == 2 || mode == 3
        val hideNav = (mode == 1 || mode == 3) && !navShown
        val w = act.window
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            // With the status bar hidden the page also fills the camera cut-out.
            lp.layoutInDisplayCutoutMode =
                if (hideStatus && Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val c = w.insetsController
            if (c != null) {
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                if (hideStatus) c.hide(WindowInsets.Type.statusBars()) else c.show(WindowInsets.Type.statusBars())
                if (hideNav) c.hide(WindowInsets.Type.navigationBars()) else c.show(WindowInsets.Type.navigationBars())
            }
        } else {
            // The page is laid out under both bars always, so a bar coming back is drawn over it and nothing moves.
            var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            if (hideStatus) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN
            if (hideNav) f = f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            w.decorView.systemUiVisibility = f
        }
        frame.requestApplyInsets()
        modeBtn.state = mode; modeBtn.invalidate()
        updateClock()
    }

    private fun applyAwake() {
        if (awake) act.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        awakeBtn.state = if (awake) 1 else 0; awakeBtn.invalidate()
    }

    /** Clock style: 0 off, 1 24 hours, 2 12 hours with AM / PM, 3 12 hours without AM / PM. Older installs follow their old switch until it is set. */
    private fun clockMode(): Int {
        if (prefs.contains("clockMode")) return prefs.getInt("clockMode", 0).coerceIn(0, 3)
        if (!prefs.getBoolean("showClock", false)) return 0
        return if (android.text.format.DateFormat.is24HourFormat(act)) 1 else 2
    }

    /** The time in plain English digits and AM / PM, whatever the phone's language. */
    private fun clockText(): String {
        val cal = java.util.Calendar.getInstance()
        val hr = cal.get(java.util.Calendar.HOUR_OF_DAY); val mi = cal.get(java.util.Calendar.MINUTE)
        val m = clockMode()
        if (m == 1) return String.format(java.util.Locale.US, "%02d:%02d", hr, mi)
        val h12 = if (hr % 12 == 0) 12 else hr % 12
        return String.format(java.util.Locale.US, "%d:%02d", h12, mi) + if (m == 2) (if (hr < 12) " AM" else " PM") else ""
    }

    // Ticks once a minute, only while a clock is on the screen.
    private val clockRun = object : Runnable {
        override fun run() {
            clock?.text = clockText()
            handler.postDelayed(this, 60000L - System.currentTimeMillis() % 60000L + 100L)
        }
    }

    private fun rebuildClock() {
        handler.removeCallbacks(clockRun)
        clock?.let { frame.removeView(it) }; clock = null
        updateClock()
    }

    /** The floating clock: shown when a clock style is chosen (optionally only while the status bar is hidden, as its own clock is gone then). */
    private fun updateClock() {
        val statusHidden = mode == 2 || mode == 3
        val want = clockMode() > 0 && (!prefs.getBoolean("clockOnlyHidden", false) || statusHidden)
        if (!want) { handler.removeCallbacks(clockRun); clock?.let { frame.removeView(it) }; clock = null; return }
        if (clock != null) return
        val c = TextView(act).apply {
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0x99000000.toInt()) }
            text = clockText()
        }
        clock = c
        frame.addView(c, FrameLayout.LayoutParams(-2, -2, cornerGravity()).apply { setMargins(dp(8), dp(8), dp(8), dp(8)) })
        handler.removeCallbacks(clockRun)
        handler.postDelayed(clockRun, 60000L - System.currentTimeMillis() % 60000L + 100L)
        // Wherever it was dropped, when it has been moved by hand.
        if (prefs.contains("clockX")) c.post {
            c.x = prefs.getFloat("clockX", 0f) * (frame.width - c.width).coerceAtLeast(1)
            c.y = prefs.getFloat("clockY", 0f) * (frame.height - c.height).coerceAtLeast(1)
        }
        var dx = 0f; var dy = 0f
        c.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = v.x - e.rawX; dy = v.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    v.x = (e.rawX + dx).coerceIn(0f, (frame.width - v.width).toFloat().coerceAtLeast(0f))
                    v.y = (e.rawY + dy).coerceIn(0f, (frame.height - v.height).toFloat().coerceAtLeast(0f))
                }
                MotionEvent.ACTION_UP -> prefs.edit()
                    .putFloat("clockX", v.x / (frame.width - v.width).coerceAtLeast(1))
                    .putFloat("clockY", v.y / (frame.height - v.height).coerceAtLeast(1)).apply()
            }
            true
        }
    }

    private fun cornerGravity() = when (prefs.getInt("clockCorner", 2)) {
        0 -> Gravity.TOP or Gravity.START
        1 -> Gravity.TOP or Gravity.END
        3 -> Gravity.BOTTOM or Gravity.END
        else -> Gravity.BOTTOM or Gravity.START
    }

    private fun showSettings() {
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        fun check(text: String, key: String, def: Boolean, after: (Boolean) -> Unit = {}) {
            col.addView(CheckBox(act).apply {
                this.text = text; isChecked = prefs.getBoolean(key, def)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after(on) }
            })
        }
        // The advanced tools (find and replace, page style, source, tools, info) open from here.
        var dlg: AlertDialog? = null
        col.addView(LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(android.widget.Button(act).apply { text = "Find / replace"; setOnClickListener { dlg?.dismiss(); tools.openFind(true) } }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(android.widget.Button(act).apply { text = "Advanced tools"; setOnClickListener { dlg?.dismiss(); tools.openMenu(0) } }, LinearLayout.LayoutParams(0, -2, 1f))
        })
        col.addView(android.widget.Button(act).apply { text = "Scroll bar, clock and stay awake…"; isAllCaps = false; setOnClickListener { dlg?.dismiss(); showBarSettings() } })
        check("Show the screen mode button (both bars / status bar / navigation bar / full screen)", "showModeBtn", true) { layoutButtons() }
        check("Show the stay awake button", "showAwakeBtn", true) { layoutButtons() }
        check("Show the scroll button (the page scrolls by itself; tap it again to stop)", "showScrollBtn", true) { layoutButtons(); show() }
        col.timeRow("Navigation bar after a tap on the page: how long it stays (full screen and status bar only modes)", "navTapMs", 5000, 500, 600000, 30)
        col.note("It comes over the page without moving anything. Use its back or recent apps button within this time.")
        // The scroll bar has its own window (button above); the buttons keep theirs here.
        col.addView(TextView(act).apply { text = "Buttons (their own settings):"; setPadding(0, dp(10), 0, 0); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        check("Free position: drag the buttons where you want them, like the clock", "btnFree", false) { layoutButtons(); show() }
        check("Landscape: the buttons in a row instead of one above the other", "btnLandscape", false) { layoutButtons(); show() }
        check("Each button moves on its own (off: they move together)", "btnSeparate", false) { layoutButtons(); show() }
        col.addView(TextView(act).apply { text = "Corner the free buttons start in (then drag them anywhere):"; setPadding(0, dp(4), 0, 0) })
        val gc = RadioGroup(act)
        listOf("Top left", "Top right", "Bottom left", "Bottom right").forEachIndexed { i, n ->
            gc.addView(RadioButton(act).apply { text = n; id = 600 + i; isChecked = prefs.getInt("btnCorner", 2) == i })
        }
        gc.setOnCheckedChangeListener { _, id ->
            val e = prefs.edit().putInt("btnCorner", id - 600)
            for (k in listOf("btnX", "btnY", "btnX0", "btnY0", "btnX1", "btnY1", "btnX2", "btnY2", "btnX3", "btnY3")) e.remove(k)
            e.apply(); layoutButtons(); show()
        }
        col.addView(gc)
        col.addView(android.widget.Button(act).apply {
            text = "Put the buttons back in their corner"
            setOnClickListener {
                val e = prefs.edit()
                for (k in listOf("btnX", "btnY", "btnX0", "btnY0", "btnX1", "btnY1", "btnX2", "btnY2", "btnX3", "btnY3")) e.remove(k)
                e.apply(); layoutButtons(); show()
            }
        })
        col.addView(TextView(act).apply { text = "Side of the buttons (the scroll bar has its own side in its window):"; setPadding(0, dp(10), 0, 0) })
        val gs = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Right side", "Left side").forEachIndexed { i, n ->
            gs.addView(RadioButton(act).apply { text = n; id = 300 + i; isChecked = prefs.getInt("side", 0) == i })
        }
        gs.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("side", id - 300).apply(); layoutButtons() }
        col.addView(gs)
        val gp = RadioGroup(act).apply { orientation = RadioGroup.HORIZONTAL }
        listOf("Buttons top", "middle", "bottom").forEachIndexed { i, n ->
            gp.addView(RadioButton(act).apply { text = n; id = 400 + i; isChecked = prefs.getInt("btnPos", 0) == i })
        }
        gp.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("btnPos", id - 400).apply(); layoutButtons() }
        col.addView(gp)
        col.addView(CheckBox(act).apply {
            text = "Its own window in Recent apps (separate from A), from the next time a page is opened"
            isChecked = HtmlViewerSwitch.separate(act)
            setOnCheckedChangeListener { _, on -> HtmlViewerSwitch.setSeparate(act, on) }
        })
        AlertDialog.Builder(act).setTitle("HTML viewer settings").setView(ScrollView(act).apply { addView(col) })
            .setPositiveButton("Close", null).setOnDismissListener { release() }.show().also { dlg = it }
    }

    // ---- the scroll bar / clock / stay awake window -------------------------------------------------------

    private fun LinearLayout.head(text: String) {
        addView(TextView(act).apply { this.text = text; setPadding(0, dp(12), 0, dp(2)); setTypeface(typeface, Typeface.BOLD) })
    }

    private fun LinearLayout.note(text: String) {
        addView(TextView(act).apply { this.text = text; textSize = 12f; setPadding(0, dp(2), 0, dp(2)) })
    }

    private fun LinearLayout.chk(text: String, key: String, def: Boolean, after: (Boolean) -> Unit = {}) {
        addView(CheckBox(act).apply {
            this.text = text; isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply(); after(on) }
        })
    }

    private fun LinearLayout.btn(text: String, onClick: () -> Unit) {
        addView(android.widget.Button(act).apply { this.text = text; isAllCaps = false; setOnClickListener { onClick() } })
    }

    /**
     * A time in milliseconds set three ways that follow each other: a seconds box, a milliseconds box and a slider
     * (half-second steps up to [sliderSec] seconds). Stored in milliseconds under [key].
     */
    private fun LinearLayout.timeRow(title: String, key: String, def: Int, lo: Int, hi: Int, sliderSec: Int) {
        head(title)
        val cur = prefs.getInt(key, def).coerceIn(lo, hi)
        fun box(hint: String, v: Int) = android.widget.EditText(act).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            this.hint = hint; setText(v.toString()); setSelectAllOnFocus(true); gravity = Gravity.CENTER
        }
        val secBox = box("seconds", cur / 1000)
        val msBox = box("milliseconds", cur % 1000)
        val sb = SeekBar(act).apply { max = sliderSec * 2; progress = Math.min(cur / 500, sliderSec * 2) }
        var busy = false
        fun put(ms: Int, fromSlider: Boolean) {
            val v = ms.coerceIn(lo, hi)
            prefs.edit().putInt(key, v).apply()
            busy = true
            if (fromSlider) { secBox.setText((v / 1000).toString()); msBox.setText((v % 1000).toString()) }
            else sb.progress = Math.min(v / 500, sb.max)
            busy = false
        }
        val watch = object : android.text.TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                if (busy) return
                val sec = secBox.text.toString().toLongOrNull() ?: 0L
                val ms = msBox.text.toString().toLongOrNull() ?: 0L
                put((sec * 1000 + ms).coerceAtMost(hi.toLong()).toInt(), false)
            }
        }
        secBox.addTextChangedListener(watch); msBox.addTextChangedListener(watch)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) put(p * 500, true) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(secBox, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(msBox, LinearLayout.LayoutParams(0, -2, 1f))
        addView(row); addView(sb)
    }

    /** A slider that stores whole numbers from [lo] to [hi] (in steps) and shows [label] of the value. */
    private fun LinearLayout.sk(label: (Int) -> String, key: String, lo: Int, hi: Int, def: Int, step: Int = 1, after: () -> Unit = {}) {
        val cur = prefs.getInt(key, def).coerceIn(lo, hi)
        val t = TextView(act).apply { text = label(cur); setPadding(0, dp(8), 0, 0) }
        val sb = SeekBar(act).apply {
            max = (hi - lo) / step; progress = (cur - lo) / step
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    val v = lo + p * step
                    t.text = label(v)
                    if (user) { prefs.edit().putInt(key, v).apply(); after() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        addView(t); addView(sb)
    }

    private fun LinearLayout.pick(title: String, options: List<String>, cur: Int, onPick: (Int) -> Unit) {
        head(title)
        val g = RadioGroup(act)
        val ids = options.map { View.generateViewId() }
        options.forEachIndexed { i, n -> g.addView(RadioButton(act).apply { text = n; id = ids[i]; isChecked = cur == i }) }
        g.setOnCheckedChangeListener { _, id -> val i = ids.indexOf(id); if (i >= 0) onPick(i) }
        addView(g)
    }

    private val barColors = intArrayOf(0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFD9A94A.toInt(), 0xFFE53935.toInt(), 0xFF8E24AA.toInt(), 0xFFFFFFFF.toInt(), 0xFF212121.toInt())

    private val barKeys = listOf("barSide", "barLen", "barTop", "barGap", "barHit", "barW", "barWT", "barH", "barHT", "barOp", "barOpT", "barColor", "barJump", "showTrack", "showBar", "hideMs")

    /**
     * Everything about the quick scroll bar (side, length, place, distance from the screen edge, handle size and
     * opacity while resting and while touched, touch zone, colour, how it behaves, how long it stays), the clock
     * (off, 24 hours, 12 hours with or without AM / PM, corner) and stay awake. The window sits on the lower half
     * without dimming, so the bar can be watched while it is tuned; "Window up / down" moves it to the top half.
     */
    private fun showBarSettings() {
        holding = true
        var onTop = false
        val sv = ScrollView(act)
        var dlg: AlertDialog? = null
        fun pv() { previewBar() }
        lateinit var fill: () -> Unit
        fun content(): LinearLayout {
            val c = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), dp(8)) }
            c.note("The window does not dim the page: watch the bar change while you adjust it. Touch the page or the bar behind the window to try it.")
            c.btn("⇅ Window up / down") { onTop = !onTop; dlg?.window?.setGravity(if (onTop) Gravity.TOP else Gravity.BOTTOM) }

            c.pick("Scroll bar", listOf("Right", "Left", "Not shown"), barSide()) { i ->
                prefs.edit().putInt("barSide", i).apply(); layoutButtons(); if (i != 2) pv() else { barPrev = false; layoutBar() }
            }
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(android.widget.Button(act).apply { text = "✥ Move the bar"; isAllCaps = false; setOnClickListener { enterMove(); dlg?.dismiss() } }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(android.widget.Button(act).apply { text = "Touched look"; isAllCaps = false; setOnClickListener { pv(); bar.peekTouched() } }, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(row)

            c.head("Position and length")
            c.sk({ "Bar length: $it% of the screen height" }, "barLen", 20, 100, 60, 5) { pv() }
            c.sk({ "Up / down position: $it% (0 = top, 100 = bottom)" }, "barTop", 0, 100, 50, 1) { pv() }
            c.sk({ "Distance from the screen edge: $it dp" + if (it < 0) "  (behind the edge)" else "" }, "barGap", -50, 200, 6, 1) { pv() }
            c.btn("◐ Stick to the edge: only half of the handle shows") {
                prefs.edit().putInt("barGap", -Math.round(pi("barHit", 34, 20, 90) / 2f)).apply(); pv(); fill()
            }

            c.head("Handle (the part you drag)")
            c.sk({ "Width: $it dp" }, "barW", 2, 40, 10, 1) { pv() }
            c.sk({ "Length: $it dp" }, "barH", 16, 300, 64, 2) { pv() }
            c.sk({ "Width while touched: $it dp" }, "barWT", 2, 40, 5, 1) { pv() }
            c.sk({ "Length while touched: $it dp" }, "barHT", 16, 300, 40, 2) { pv() }
            c.sk({ "Opacity: $it%" }, "barOp", 10, 100, 85, 5) { pv() }
            c.sk({ "Opacity while touched: $it%" }, "barOpT", 10, 100, 100, 5) { pv() }
            c.sk({ "Touch zone around the handle: $it dp wide (smaller = fewer accidental touches)" }, "barHit", 20, 90, 34, 2) { pv() }

            c.head("Colour")
            val sw = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in barColors) {
                sw.addView(View(act).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col); setStroke(dp(1), 0x66888888) }
                    setOnClickListener { prefs.edit().putInt("barColor", col).apply(); pv(); fill() }
                }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(8) })
            }
            c.addView(sw)
            val now = prefs.getInt("barColor", blue)
            val rgb = intArrayOf(Color.red(now), Color.green(now), Color.blue(now))
            val names = listOf("Red", "Green", "Blue")
            for (k in 0..2) {
                val t = TextView(act).apply { text = "${names[k]}: ${rgb[k]}"; setPadding(0, dp(4), 0, 0) }
                val sb = SeekBar(act).apply {
                    max = 255; progress = rgb[k]
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                            t.text = "${names[k]}: $p"
                            if (user) { rgb[k] = p; prefs.edit().putInt("barColor", Color.rgb(rgb[0], rgb[1], rgb[2])).apply(); pv() }
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                }
                c.addView(t); c.addView(sb)
            }

            c.head("Behaviour")
            c.chk("Tap on the faint line jumps there (off: only the handle moves the page, no accidental jumps)", "barJump", false) { pv() }
            c.chk("Show the faint line along the bar", "showTrack", true) { pv() }
            c.head("Hide the bar and buttons after this many milliseconds (1000 = 1 second)")
            c.addView(android.widget.EditText(act).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setText(prefs.getInt("hideMs", 3000).toString())
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(a: CharSequence?, b: Int, c2: Int, d: Int) {}
                    override fun onTextChanged(a: CharSequence?, b: Int, c2: Int, d: Int) {}
                    override fun afterTextChanged(e: android.text.Editable?) {
                        val v = e?.toString()?.toIntOrNull() ?: return
                        prefs.edit().putInt("hideMs", v.coerceIn(200, 600000)).apply()
                    }
                })
            })
            c.btn("↺ Put the bar back to the original look") {
                val e = prefs.edit(); for (k in barKeys) e.remove(k); e.apply()
                layoutButtons(); pv(); fill(); android.widget.Toast.makeText(act, "Bar reset", android.widget.Toast.LENGTH_SHORT).show()
            }

            c.pick("Clock", listOf("Off", "24 hours", "12 hours with AM / PM", "12 hours without AM / PM"), clockMode()) { i ->
                prefs.edit().putInt("clockMode", i).putBoolean("showClock", i > 0).apply(); rebuildClock()
            }
            c.chk("Show the clock only while the status bar is hidden", "clockOnlyHidden", false) { rebuildClock() }
            c.pick("Corner the clock starts in (then drag it where you want)", listOf("Top left", "Top right", "Bottom left", "Bottom right"), prefs.getInt("clockCorner", 2)) { i ->
                prefs.edit().putInt("clockCorner", i).remove("clockX").remove("clockY").apply(); rebuildClock()
            }

            c.head("Screen")
            c.chk("Stay awake (the screen does not turn off)", "awake", false) { awake = it; applyAwake() }
            return c
        }
        fill = {
            val y = sv.scrollY
            sv.removeAllViews(); sv.addView(content())
            sv.post { sv.scrollTo(0, y) }
        }
        fill()
        val d = AlertDialog.Builder(act).setTitle("Scroll bar, clock and stay awake").setView(sv).setPositiveButton("Close", null)
            .setOnDismissListener { if (!barMove) { barPrev = false; release() } }.create()
        dlg = d
        d.setCanceledOnTouchOutside(false)
        d.show()
        d.window?.let { w ->
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            w.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(-1, (act.resources.displayMetrics.heightPixels * 0.5).toInt())
        }
        pv()
    }

    /**
     * The quick scroll bar, the way the HTML page's own bar works: only grabbing the handle moves the page (so a touch
     * beside it never jumps; "tap the line jumps" switches that on). While held, the handle takes its "touched" size and
     * opacity. In move mode the whole bar is dragged to a new side, gap and height.
     */
    private inner class Bar(ctx: Context) : View(ctx) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG)
        private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fillBox = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x24D9A94A }
        private val dash = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFD9A94A.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat()
            pathEffect = DashPathEffect(floatArrayOf(dp(6).toFloat(), dp(4).toFloat()), 0f)
        }
        var dragging = false
        private var peek = false
        private var grab = 0f
        private var downX = 0f; private var downY = 0f; private var x0 = 0f; private var y0 = 0f
        private val r = RectF()

        private fun color() = prefs.getInt("barColor", blue)
        private fun zone() = Math.min(Math.max(dp(44), dp(pi("barH", 64, 16, 300))), height).toFloat()

        /** [zone height, handle top] or null when the page does not scroll (a preview or move shows it anyway). */
        private fun geometry(): FloatArray? {
            if (height <= 0) return null
            val zone = zone()
            val range = web.range(); val ext = web.extent()
            if (range <= ext + dp(4)) return if (barMove || barPrev) floatArrayOf(zone, 0f) else null
            val frac = (web.offset().toFloat() / (range - ext)).coerceIn(0f, 1f)
            return floatArrayOf(zone, (height - zone).coerceAtLeast(0f) * frac)
        }

        override fun onDraw(c: Canvas) {
            val g = geometry() ?: return
            val cx = width / 2f
            if (barMove) { r.set(0f, 0f, width.toFloat(), height.toFloat()); c.drawRoundRect(r, dp(10).toFloat(), dp(10).toFloat(), fillBox); c.drawRoundRect(r, dp(10).toFloat(), dp(10).toFloat(), dash) }
            val col = color()
            if (prefs.getBoolean("showTrack", true) && !barMove) {
                track.color = (col and 0x00FFFFFF) or 0x40000000
                val tw = dp(4) / 2f
                r.set(cx - tw, 0f, cx + tw, height.toFloat()); c.drawRoundRect(r, tw, tw, track)
            }
            val held = dragging || peek
            val hw = dp(if (held) pi("barWT", 5, 2, 40) else pi("barW", 10, 2, 40)) / 2f
            val hh = dp(if (held) pi("barHT", 40, 16, 300) else pi("barH", 64, 16, 300)) / 2f
            val cy = g[1] + g[0] / 2f
            thumb.color = col
            r.set(cx - hw, cy - hh, cx + hw, cy + hh); c.drawRoundRect(r, hw, hw, thumb)
        }

        private fun seek(y: Float, g: FloatArray) {
            val frac = ((y - grab) / (height - g[0]).coerceAtLeast(1f)).coerceIn(0f, 1f)
            web.scrollTo(web.scrollX, (frac * (web.range() - web.extent())).toInt())
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (barMove) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; x0 = x; y0 = y; parent.requestDisallowInterceptTouchEvent(true) }
                    MotionEvent.ACTION_MOVE -> {
                        x = (x0 + e.rawX - downX).coerceIn(-width / 2f, (layer.width - width / 2f).coerceAtLeast(0f))
                        y = (y0 + e.rawY - downY).coerceIn(0f, (layer.height - height).coerceAtLeast(0).toFloat())
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> commitMove()
                }
                return true
            }
            val g = geometry() ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val on = e.y >= g[1] && e.y <= g[1] + g[0]
                    if (!on && !prefs.getBoolean("barJump", false)) return false
                    parent.requestDisallowInterceptTouchEvent(true)
                    dragging = true; holding = true
                    grab = if (on) e.y - g[1] else g[0] / 2
                    alpha = pi("barOpT", 100, 10, 100) / 100f
                    if (!on) seek(e.y, g)
                    invalidate(); show()
                }
                MotionEvent.ACTION_MOVE -> if (dragging) { seek(e.y, g); invalidate(); show() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                    dragging = false; alpha = pi("barOp", 85, 10, 100) / 100f; invalidate(); release()
                }
            }
            return true
        }

        /** Shows the "touched" look for a moment (from the settings window). */
        fun peekTouched() {
            peek = true; alpha = pi("barOpT", 100, 10, 100) / 100f; invalidate()
            postDelayed({ peek = false; if (!dragging) alpha = pi("barOp", 85, 10, 100) / 100f; invalidate() }, 2500)
        }
    }

    /** A round button drawn in code: 0 = screen mode (phone with its two bars), 1 = stay awake (sun), 2 = settings (sliders), 3 = scroll by itself (arrows down). */
    private inner class IconBtn(ctx: Context, private val kind: Int) : View(ctx) {
        var state = 0
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); strokeCap = Paint.Cap.ROUND }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val r = RectF()

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2; val cy = h / 2
            bg.color = if ((kind == 1 || kind == 3) && state == 1) 0xFFFFA000.toInt() else 0xE61E88E5.toInt()
            c.drawCircle(cx, cy, w / 2, bg)
            when (kind) {
                0 -> {
                    val pw = dp(9).toFloat(); val ph = dp(13).toFloat()
                    r.set(cx - pw, cy - ph, cx + pw, cy + ph); c.drawRoundRect(r, dp(3).toFloat(), dp(3).toFloat(), ink)
                    val statusOn = state == 0 || state == 1
                    val navOn = state == 0 || state == 2
                    if (statusOn) { r.set(cx - pw, cy - ph, cx + pw, cy - ph + dp(5)); c.drawRect(r, fill) }
                    if (navOn) { r.set(cx - pw, cy + ph - dp(5), cx + pw, cy + ph); c.drawRect(r, fill) }
                }
                1 -> {
                    c.drawCircle(cx, cy, dp(5).toFloat(), if (state == 1) fill else ink)
                    for (i in 0 until 8) {
                        val a = Math.toRadians(i * 45.0)
                        val x1 = cx + Math.cos(a).toFloat() * dp(8); val y1 = cy + Math.sin(a).toFloat() * dp(8)
                        val x2 = cx + Math.cos(a).toFloat() * dp(12); val y2 = cy + Math.sin(a).toFloat() * dp(12)
                        c.drawLine(x1, y1, x2, y2, ink)
                    }
                }
                3 -> {
                    if (state == 1) {
                        // scrolling by itself: a stop square
                        r.set(cx - dp(6), cy - dp(6), cx + dp(6), cy + dp(6)); c.drawRoundRect(r, dp(2).toFloat(), dp(2).toFloat(), fill)
                    } else {
                        // two chevrons pointing down
                        for (k in 0..1) {
                            val o = cy - dp(9) + k * dp(8)
                            c.drawLine(cx - dp(8), o, cx, o + dp(8), ink)
                            c.drawLine(cx, o + dp(8), cx + dp(8), o, ink)
                        }
                    }
                }
                else -> {
                    val xs = floatArrayOf(0.3f, 0.65f, 0.45f)
                    for (i in 0 until 3) {
                        val y = cy + (i - 1) * dp(8)
                        c.drawLine(cx - dp(11), y, cx + dp(11), y, ink)
                        c.drawCircle(cx - dp(11) + dp(22) * xs[i], y, dp(3).toFloat(), fill)
                    }
                }
            }
        }
    }
}
