package a.a.strip

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import a.a.utils.ShizukuShell

/**
 * "Copy what is under the thumb", used by the click circle and the OCR shortcut.
 *
 * The fast way is [TextReaderService]: the text that is on the screen under the spot (a sentence, a
 * button's label, written digits) is read at the moment of release, before the tap, so the tap is not
 * delayed. The slower way, only when the person turns it on, captures a screenshot first and reads
 * digits that are drawn rather than written with the global [OtpOcr].
 * Nothing is kept in memory afterwards.
 */
object ScreenCopy {
    private val onlyDigits = Regex("[\\d\\s,.\\-]+")

    /** Persian and Arabic digits become English; a text that is only digits loses its spaces and dashes. */
    fun normalize(text: String): String {
        val t = text.trim()
        val e = OtpOcr.toEnglish(t)
        return if (e.matches(onlyDigits)) e.replace(Regex("[\\s,.\\-]"), "") else t
    }

    /** The text under the spot, read at once; "" when there is none or the reader is not on. */
    fun textNow(x: Float, y: Float): String {
        val svc = TextReaderService.instance ?: return ""
        return runCatching { normalize(svc.textAt(x.toInt(), y.toInt())) }.getOrDefault("")
    }

    class Snap(val shot: Bitmap?, val x: Float, val y: Float)

    /** Blocking. The screenshot, taken before the tap (the circle's own window needs a moment to be gone). */
    fun snapshot(x: Float, y: Float): Snap {
        try { Thread.sleep(120) } catch (_: InterruptedException) { }
        val shot = if (ShizukuShell.isReady()) runCatching { ScreenOcr.capture() }.getOrNull() else null
        return Snap(shot, x, y)
    }

    /** The digits drawn around the spot in the screenshot, or "". */
    fun digitsFrom(ctx: Context, s: Snap): String {
        val shot = s.shot ?: return ""
        return try {
            val d = ctx.resources.displayMetrics.density
            val w = (300 * d).toInt()
            val h = (56 * d).toInt()
            val l = (s.x - w / 2f).toInt().coerceIn(0, maxOf(0, shot.width - w))
            val t = (s.y - h / 2f).toInt().coerceIn(0, maxOf(0, shot.height - h))
            val pic = ScreenOcr.crop(shot, ScreenOcr.Region(Rect(l, t, l + w, t + h), shot.width, shot.height))
            val r = if (pic == null) "" else runCatching { OtpOcr.read(ctx, pic) }.getOrDefault("")
            pic?.recycle()
            if (r.length in 4..10 && !r.contains('?')) r else ""
        } finally {
            OtpOcr.release()
        }
    }

    fun copy(ctx: Context, text: String) {
        runCatching {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("A", text))
            WidgetFloat.toast(ctx, "Copied: " + if (text.length > 40) text.take(40) + "…" else text)
        }
    }
}
