package a.a.strip

import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import a.a.flow.NativeActions
import a.a.utils.ShizukuShell
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.CardWindow
import a.a.ui.components.Chevron
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.ui.draw.clip

/**
 * One place for the OCR that reads digits. English digits work from the start; Persian and Arabic
 * digits are taught once here, from a live widget you can press, or from any part of the screen,
 * and then work everywhere (widget cells, the OCR shortcut, scripts).
 */
class OcrActivity : ComponentActivity() {
    private val mgr by lazy { AppWidgetManager.getInstance(this) }
    private val host get() = WidgetKit.host(this)
    private val main = Handler(Looper.getMainLooper())
    private var tick by mutableStateOf(0)
    private var pic by mutableStateOf<Bitmap?>(null)
    private var typed by mutableStateOf("")
    private var liveId by mutableStateOf(-1)
    private var liveView: AppWidgetHostView? = null
    private var pieces by mutableStateOf<List<Bitmap>>(emptyList())
    private var pieceAt by mutableStateOf(0)
    private var boxTick by mutableStateOf(0)
    private var renaming by mutableStateOf<String?>(null)
    private var renameText by mutableStateOf("")

    /** True when the Scripts screen sent the person here to draw a box: A goes straight back to it afterwards. */
    private var fromScripts = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow { Screen() }
        }
        val redo = intent.getStringExtra("boxredo")
        val isNew = intent.getBooleanExtra("boxnew", false)
        if (savedInstanceState == null && (redo != null || isNew)) {
            fromScripts = true
            main.post { boxPick(redo) }
        }
    }

    override fun onStart() {
        super.onStart()
        WidgetKit.hostStart(this)
    }

    // A tap on the live widget may end on the home screen: bring this screen back (see ReturnGuard).
    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        val hit = ReturnGuard.hit(liveView, ev)
        val r = super.dispatchTouchEvent(ev)
        if (hit) ReturnGuard.after(this, OcrActivity::class.java)
        return r
    }

    override fun onStop() {
        WidgetKit.hostStop()
        super.onStop()
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    private fun bringBack() {
        if (fromScripts) {
            fromScripts = false
            runCatching {
                startActivity(Intent(this, a.a.flow.FlowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
            finish()
            return
        }
        runCatching {
            startActivity(Intent(this, OcrActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
    }

    /** A goes to the back; the person drags a box over any screen; then A either keeps the picture to teach from, or reads it. */
    private fun screenPick(learn: Boolean) {
        if (!ShizukuShell.isReady()) {
            toast("This needs Shizuku. Start Shizuku and allow A, then try again.")
            return
        }
        val app = applicationContext
        moveTaskToBack(true)
        Thread {
            try {
                Thread.sleep(500)
                if (learn) {
                    val b = ScreenOcr.snap(app)
                    main.post {
                        if (b == null) toast("Nothing was picked") else {
                            typed = ""
                            pieces = emptyList()
                            pic = b
                            toast("Picked. Open A to teach the digits.")
                            bringBack()
                        }
                    }
                } else {
                    val msg = try { NativeActions.run(app, "ocr_area", "copy", HashMap()) } catch (e: Throwable) { e.message ?: "Could not read it" }
                    main.post { toast(msg); bringBack() }
                }
            } finally {
                OtpOcr.release()
            }
        }.start()
    }

    /** A steps aside; the person drags a box over any screen; it is saved by name (a new one, or [redo] drawn again). */
    private fun boxPick(redo: String?) {
        val app = applicationContext
        if (!WidgetFloat.allowed(app)) {
            toast("Allow Display over other apps for A, then try again.")
            return
        }
        moveTaskToBack(true)
        Thread {
            Thread.sleep(500)
            val r = ScreenOcr.pick(app)
            main.post {
                if (r == null) toast("Nothing was picked") else {
                    val name = redo ?: ScreenOcr.nextName(app)
                    ScreenOcr.saveBox(app, name, r)
                    toast("Saved as $name. You can rename it in A.")
                    boxTick++
                }
                bringBack()
            }
        }.start()
    }

    /** A picture of the live widget as it looks now. */
    private fun liveSnapshot(): Bitmap? {
        val v = liveView ?: return null
        if (v.width < 8 || v.height < 8) return null
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.WHITE)
        v.draw(Canvas(b))
        return b
    }

    @Composable
    private fun Screen() {
        val known = remember(tick) { OtpOcr.learnedDigits(this@OcrActivity) }
        val saved = remember { WidgetKit.savedIds(this@OcrActivity) }
        val boxes = remember(boxTick) { ScreenOcr.boxNames(this@OcrActivity) }
        AWindowPage("OCR: reading digits", onBack = { finish() }) { pad ->
            Column(
                Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp).navigationBarsPadding().padding(bottom = 24.dp),
            ) {
                CardGroup("Taught digits") {
                    row { sh ->
                        SettingRow(
                            title = "Taught digits", shape = sh,
                            summary = if (known.isEmpty()) "none yet" else known.sorted().joinToString(" "),
                            info = "English digits are read from the start. Persian and Arabic digits are taught once here, and then work everywhere: " +
                                "widget cells, the OCR shortcut and scripts.",
                        )
                    }
                    row { sh ->
                        SettingRow(
                            title = "Forget everything taught", shape = sh, icon = Icons.Filled.Delete,
                            onClick = { OtpOcr.forget(this@OcrActivity); tick++ },
                        )
                    }
                }

                CardGroup(
                    "1. Teach from a live widget",
                    hint = "Pick a widget, press its button until the code shows inside it, then tap \"Read it and teach\".",
                ) {
                    if (saved.isEmpty()) {
                        row { sh -> SettingRow(title = "No widget yet", shape = sh, summary = "Add one in the Widgets window first.") }
                    } else {
                        for (id in saved) {
                            row { sh ->
                                val name = mgr.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget $id"
                                SettingRow(
                                    title = name, shape = sh, icon = Icons.Filled.Widgets, lit = liveId == id,
                                    summary = if (liveId == id) "Showing live. Tap to hide it." else "Tap to show it live",
                                    onClick = { liveView = null; liveId = if (liveId == id) -1 else id },
                                )
                            }
                        }
                    }
                }
                val info = if (liveId != -1) mgr.getAppWidgetInfo(liveId) else null
                if (info != null) {
                    Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(20.dp)).background(rowColor())) {
                        key(liveId) {
                            BoxWithConstraints(Modifier.fillMaxWidth()) {
                                val w = maxWidth.value.toInt()
                                val h = 220
                                AndroidView(
                                    factory = { ctx -> host.createView(ctx, liveId, info).also { liveView = it } },
                                    update = { v -> v.updateAppWidgetSize(null, w, h, w, h) },
                                    modifier = Modifier.fillMaxWidth().height(h.dp),
                                )
                            }
                        }
                    }
                    CardGroup("The live widget") {
                        row { sh ->
                            SettingRow(
                                title = "Read it and teach", shape = sh, icon = Icons.Filled.PlayArrow,
                                summary = "Reads the picture inside the widget and asks you for the digits",
                                onClick = {
                                    // Each picture inside the widget alone, the likely code first; the whole widget when it has none.
                                    val v = liveView
                                    val list = if (v == null) emptyList() else WidgetKit.imagePieces(v, Color.WHITE)
                                        .sortedBy { p -> val n = OtpOcr.shapeCount(p); if (n in 3..12) 0 else 1 }
                                    if (list.isNotEmpty()) { typed = ""; pieces = list; pieceAt = 0; pic = list[0] } else {
                                        val b = liveSnapshot()
                                        if (b == null) toast("The widget has not loaded yet") else { typed = ""; pieces = emptyList(); pic = b }
                                    }
                                },
                                trailing = { Chevron() },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                title = "Use for the OCR shortcut", shape = sh,
                                summary = "The OCR shortcut will read this widget",
                                onClick = {
                                    ScreenOcr.saveWidget(this@OcrActivity, liveId)
                                    toast("The OCR shortcut will read this widget")
                                },
                                trailing = { Chevron() },
                            )
                        }
                    }
                }

                CardGroup(
                    "2. Teach from the screen",
                    hint = "A steps aside. Open the app that shows the digits, drag a box over them, then open A again.",
                ) {
                    row { sh ->
                        SettingRow(
                            title = "Pick digits on the screen", shape = sh, icon = Icons.Filled.TouchApp,
                            onClick = { screenPick(true) }, trailing = { Chevron() },
                        )
                    }
                }

                CardGroup(
                    "3. Try it",
                    hint = "The same as the OCR shortcut: drag a box over digits and A copies them.",
                ) {
                    row { sh ->
                        SettingRow(
                            title = "Read part of the screen now", shape = sh, icon = Icons.Filled.PlayArrow,
                            onClick = { screenPick(false) }, trailing = { Chevron() },
                        )
                    }
                }

                CardGroup(
                    "4. Boxes for the OCR shortcut",
                    hint = "A box is a part of the screen, saved by name. A steps aside, you open the app, drag the box, and A comes back. " +
                        "In the OCR shortcut you then pick the box by its name.",
                ) {
                    row { sh ->
                        SettingRow(
                            title = "New box", shape = sh, icon = Icons.Filled.Add,
                            onClick = { boxPick(null) }, trailing = { Chevron() },
                        )
                    }
                    if (boxes.isEmpty()) {
                        row { sh -> SettingRow(title = "No boxes yet", shape = sh) }
                    }
                    for (name in boxes) {
                        row { sh ->
                            SettingRow(
                                title = name, shape = sh, icon = Icons.Filled.Edit,
                                footer = {
                                    Row(Modifier.padding(start = 8.dp, end = 8.dp, bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(onClick = { renameText = name; renaming = name }) { Text("Rename") }
                                        TextButton(onClick = { boxPick(name) }) { Text("Drag again") }
                                        TextButton(onClick = { ScreenOcr.deleteBox(this@OcrActivity, name); boxTick++ }) { Text("Delete") }
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
        renaming?.let { old ->
            CardWindow(title = "Name of the box", onBack = { renaming = null }) {
                CardGroup("Name") {
                    row { sh ->
                        SettingRow(
                            title = "Name of the box", shape = sh, icon = Icons.Filled.Edit,
                            footer = {
                                OutlinedTextField(
                                    value = renameText, onValueChange = { renameText = it }, singleLine = true,
                                    modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                                )
                            },
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { renaming = null }, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    Button(
                        onClick = {
                            toast(if (ScreenOcr.renameBox(this@OcrActivity, old, renameText)) "Renamed" else "That name is empty or already used")
                            renaming = null
                            boxTick++
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Save") }
                }
            }
        }
        pic?.let { Teach(it) }
    }

    @Composable
    private fun Teach(b: Bitmap) {
        val reading = remember(b) { OtpOcr.read(this@OcrActivity, b) }
        val shapes = remember(b) { OtpOcr.shapeCount(b) }
        CardWindow(title = "Teach the digits", onBack = { OtpOcr.release(); pic = null }) {
            Image(
                bitmap = b.asImageBitmap(), contentDescription = null,
                modifier = Modifier.padding(top = 12.dp).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(rowColor())
                    .padding(8.dp).heightIn(max = 180.dp),
            )
            CardGroup("What A reads") {
                row { sh ->
                    SettingRow(
                        title = "Shapes found: $shapes", shape = sh,
                        summary = "A reads it as: " + reading.ifEmpty { "nothing" },
                    )
                }
                if (pieces.size > 1) {
                    row { sh ->
                        SettingRow(
                            title = "Another picture of the widget", shape = sh,
                            summary = "${pieceAt + 1} of ${pieces.size}",
                            onClick = { pieceAt = (pieceAt + 1) % pieces.size; typed = ""; pic = pieces[pieceAt] },
                            trailing = { Chevron() },
                        )
                    }
                }
                row { sh ->
                    SettingRow(
                        title = "Type the digits you see", shape = sh, icon = Icons.Filled.Edit,
                        footer = {
                            OutlinedTextField(
                                value = typed, onValueChange = { typed = it }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                            )
                        },
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { OtpOcr.release(); pic = null }, modifier = Modifier.weight(1f)) {
                    Text(if (pieces.size > 1) "Done" else "Cancel")
                }
                Button(
                    onClick = {
                        toast(OtpOcr.learn(this@OcrActivity, b, typed))
                        tick++
                        if (pieces.size > 1) {
                            // Straight on to the next picture of the widget: more pictures, a better reading.
                            pieceAt = (pieceAt + 1) % pieces.size; typed = ""; pic = pieces[pieceAt]
                        } else {
                            OtpOcr.release()
                            pic = null
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(if (pieces.size > 1) "Teach, then next picture" else "Teach") }
            }
        }
    }
}
