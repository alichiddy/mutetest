package a.a.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * A full-screen card window above whatever is open: the same top bar as the Cells window (back arrow = close),
 * then the cards. [scroll] is false for a window that holds its own list, which scrolls by itself.
 * (Used by the Shell runner windows and the dialogs of the main window.)
 */
@Composable
fun CardWindow(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val state = rememberScrollState()
    Dialog(onDismissRequest = onBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AWindowPage(title, onBack = onBack, actions = actions) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .then(if (scroll) Modifier.verticalScroll(state).padding(bottom = 24.dp) else Modifier),
                    content = content,
                )
            }
        }
    }
}
