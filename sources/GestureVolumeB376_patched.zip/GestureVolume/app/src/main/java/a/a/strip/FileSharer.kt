package a.a.strip

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * Hands a file straight to the system share sheet, so it can go to any app (a messenger, mail,
 * a file manager, Bluetooth...) without being saved somewhere first. Runs only when asked.
 */
object FileSharer {

    /** Shares a file that already has a content address (for example one just saved in Downloads). */
    fun shareUri(context: Context, uri: Uri, mime: String, title: String = "Share") {
        val send = Intent(Intent.ACTION_SEND)
            .setType(mime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .putExtra(Intent.EXTRA_TITLE, title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // The clip is what carries the read permission to the app chosen in the sheet.
        send.clipData = ClipData.newRawUri(title, uri)
        context.startActivity(Intent.createChooser(send, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Shares a file from this app's own storage, through the FileProvider. */
    fun shareFile(context: Context, file: File, mime: String, title: String = "Share") {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        shareUri(context, uri, mime, title)
    }

    /** Writes [text] to a file called [name] and shares it. Returns a short message for the screen. */
    fun shareText(context: Context, name: String, text: String, mime: String = "application/json"): String = try {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, name).apply { writeText(text) }
        shareFile(context, f, mime, name)
        "Choose where to send $name"
    } catch (e: Throwable) {
        "Could not share: ${e.message}"
    }
}
