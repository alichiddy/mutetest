package a.a.adb

import android.content.Context
import android.util.Base64
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

/**
 * A's own ADB key. Made once and kept in the app's private preferences, so a device that was told
 * "Always allow" recognises A again without asking.
 */
object AdbKey {
    private val SHA1_PREFIX = byteArrayOf(0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14)

    @Volatile
    private var cached: KeyPair? = null

    @Synchronized
    private fun pair(c: Context): KeyPair {
        cached?.let { return it }
        val p = c.getSharedPreferences("adb_otg", Context.MODE_PRIVATE)
        val priv = p.getString("priv", null)
        val pub = p.getString("pub", null)
        if (priv != null && pub != null) {
            val loaded = runCatching {
                val kf = KeyFactory.getInstance("RSA")
                KeyPair(
                    kf.generatePublic(X509EncodedKeySpec(Base64.decode(pub, Base64.NO_WRAP))),
                    kf.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(priv, Base64.NO_WRAP)))
                )
            }.getOrNull()
            if (loaded != null) { cached = loaded; return loaded }
        }
        val g = KeyPairGenerator.getInstance("RSA")
        g.initialize(2048)
        val kp = g.generateKeyPair()
        p.edit()
            .putString("priv", Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP))
            .putString("pub", Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP))
            .apply()
        cached = kp
        return kp
    }

    /** Signs the device's 20-byte token the way adb does (RSA, SHA-1 prefix, token already hashed). */
    fun sign(c: Context, token: ByteArray): ByteArray {
        val s = Signature.getInstance("NONEwithRSA")
        s.initSign(pair(c).private)
        s.update(SHA1_PREFIX)
        s.update(token)
        return s.sign()
    }

    private fun le256(v: BigInteger): ByteArray {
        val be = v.toByteArray()
        val out = ByteArray(256)
        var i = 0
        while (i < 256 && i < be.size) {
            out[i] = be[be.size - 1 - i]
            i++
        }
        return out
    }

    /** The public key in the form adb sends it: base64 of Android's RSAPublicKey struct, a name, and a zero byte. */
    fun publicKey(c: Context): ByteArray {
        val pub = pair(c).public as RSAPublicKey
        val n = pub.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.mod(r32).modInverse(r32)).toLong().toInt()
        val rr = BigInteger.ONE.shiftLeft(4096).mod(n)
        val b = ByteBuffer.allocate(4 + 4 + 256 + 256 + 4).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(64)
        b.putInt(n0inv)
        b.put(le256(n))
        b.put(le256(rr))
        b.putInt(pub.publicExponent.toInt())
        val text = Base64.encodeToString(b.array(), Base64.NO_WRAP) + " a@a"
        return text.toByteArray(Charsets.US_ASCII) + byteArrayOf(0)
    }
}
