package a.a.strip

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.ui.text.font.FontWeight
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.flow.FlowStore
import a.a.flow.Step
import a.a.utils.ShizukuShell

/** Saving a shortcut's action into the cells or into My Scripts (used by the details panels). */
object ActionSaver {
    private fun prefs(context: Context) = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    /** Adds a cell at the end of the cells window's top level. */
    fun saveToCells(context: Context, label: String, action: String, icon: String = "") = saveToCellsIn(context, StripScope.MAIN, label, action, icon)

    /** Same, into the cells window [id]: "" = the main slider's, else a segment's own window. */
    fun saveToCellsIn(context: Context, id: String, label: String, action: String, icon: String = "") {
        val p = StripScope.prefs(context, id)
        val cfg = StripScope.load(context, id)
        val (added, keep) = StripConfig.withNewCell(cfg.items, StripItem(label.ifBlank { "Shortcut" }, icon, action))
        val next = cfg.copy(items = StripConfig.settlePins(added, cfg.columns.coerceIn(1, 16), p.getInt("stripPinFollow", StripConfig.PIN_ALL), emptyList(), keep))
        StripScope.save(context, id, next)
    }

    /**
     * The action that opens [pkg] through Hail (also when the app is hidden/frozen): the same intent
     * Shortcut Maker makes for a Hail shortcut, Hail's own API screen with the target in the "package" extra.
     */
    fun hailAction(pkg: String): String {
        val i = Intent("com.aistra.hail.action.LAUNCH")
            .setPackage("com.aistra.hail")
            .setComponent(android.content.ComponentName("com.aistra.hail", "com.aistra.hail.ui.api.ApiActivity"))
            .putExtra("package", pkg)
            .addFlags(0x14000000)
        return "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME)
    }

    /** Saves an app shortcut (intent) or a shell command as a one-step script. False for other kinds. */
    fun saveToScripts(context: Context, name: String, action: String): Boolean {
        val step = when {
            action.startsWith("Intent:") -> Step(Step.INTENT, action.removePrefix("Intent:"))
            action.startsWith("Shell:") -> Step(Step.SHELL, action.removePrefix("Shell:"))
            else -> return false
        }
        var n = name.ifBlank { "Shortcut" }
        val have = FlowStore.names(context).toSet()
        if (n in have) { var i = 2; while ("$n $i" in have) i++; n = "$n $i" }
        FlowStore.save(context, n, listOf(step))
        return true
    }
}

/** Finds a shortcut's real intent in `dumpsys shortcut` (needs Shizuku); the launcher API hides it. Blocking. */
object ShortcutDump {
    fun intentUri(pkg: String, id: String): String? {
        if (!ShizukuShell.isReady()) return null
        val q = id.replace("'", "'\\''")
        val sb = StringBuilder()
        runCatching { ShizukuShell.run("dumpsys shortcut | grep -F 'id=$q,'") { sb.append(it).append('\n') } }
        val line = sb.lines().firstOrNull { it.contains("Intent {") && (it.contains(pkg)) } ?: return null
        val body = line.substringAfter("Intent {").substringBefore("}").trim()
        val i = Intent()
        var data: Uri? = null
        var type: String? = null
        for (t in body.split(' ')) {
            when {
                t.startsWith("act=") -> i.action = t.removePrefix("act=")
                t.startsWith("dat=") -> data = Uri.parse(t.removePrefix("dat="))
                t.startsWith("typ=") -> type = t.removePrefix("typ=")
                t.startsWith("flg=0x") -> i.flags = t.removePrefix("flg=0x").toLongOrNull(16)?.toInt() ?: 0
                t.startsWith("pkg=") -> i.`package` = t.removePrefix("pkg=")
                t.startsWith("cmp=") -> ComponentName.unflattenFromString(t.removePrefix("cmp="))?.let { i.component = it }
                t.startsWith("cat=[") -> t.removePrefix("cat=[").removeSuffix("]").split(',').filter { it.isNotBlank() }.forEach { i.addCategory(it) }
            }
        }
        if (data != null && type != null) i.setDataAndType(data, type) else if (data != null) i.data = data else if (type != null) i.type = type
        return i.toUri(Intent.URI_INTENT_SCHEME)
    }
}

private const val HOME_ALIAS = "a.a.strip.LauncherHomeActivity"

/** What Android gives a launcher about a shortcut someone is pinning, with the actions to keep it. */
class PinCatcherActivity : ComponentActivity() {
    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val la = getSystemService(LauncherApps::class.java)
        val req = runCatching { la.getPinItemRequest(intent) }.getOrNull()
        val si = req?.takeIf { it.isValid }?.shortcutInfo
        if (si == null) { finish(); return }
        val info = StringBuilder()
        runCatching {
            info.append("Name: ${si.shortLabel}\n")
            si.longLabel?.let { info.append("Long name: $it\n") }
            info.append("Id: ${si.id}\nPackage: ${si.`package`}\n")
            si.activity?.let { info.append("Activity: ${it.flattenToString()}\n") }
            si.categories?.let { info.append("Categories: ${it.joinToString()}\n") }
            @Suppress("DEPRECATION")
            si.extras?.let { ex -> for (k in ex.keySet()) info.append("Extra $k = ${ex.get(k)}\n") }
            info.append("User: ${si.userHandle}\n")
        }
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var uri by remember { mutableStateOf("") }
                    var looked by remember { mutableStateOf(false) }
                    var name by remember { mutableStateOf(si.shortLabel?.toString().orEmpty()) }
                    Column(Modifier.statusBarsPadding().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("A pinned shortcut", fontSize = 18.sp)
                        androidx.compose.foundation.text.selection.SelectionContainer {
                            Text(info.toString() + if (uri.isNotEmpty()) "\nIntent: $uri" else "", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        if (uri.isEmpty()) {
                            Text(
                                if (looked) "The real intent was not found (Android hides it from launchers; Shizuku can read it)."
                                else "Android hides the real intent from launchers. With Shizuku running it can be read from the system's shortcut list.",
                                fontSize = 12.sp,
                            )
                            OutlinedButton(onClick = {
                                Thread {
                                    val r = ShortcutDump.intentUri(si.`package`, si.id)
                                    runOnUiThread { uri = r.orEmpty(); looked = true }
                                }.start()
                            }) { Text("Read the intent with Shizuku") }
                        }
                        OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                        val action = if (uri.isNotEmpty()) "Intent:$uri" else ""
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = {
                                val cm = getSystemService(android.content.ClipboardManager::class.java)
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", info.toString() + (if (uri.isNotEmpty()) "Intent: $uri" else "")))
                                Toast.makeText(this@PinCatcherActivity, "Copied", Toast.LENGTH_SHORT).show()
                            }) { Text("Copy info") }
                            if (action.isNotEmpty()) {
                                OutlinedButton(onClick = {
                                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("shortcut", action))
                                    Toast.makeText(this@PinCatcherActivity, "Copied", Toast.LENGTH_SHORT).show()
                                }) { Text("Copy raw") }
                                OutlinedButton(onClick = {
                                    CellTarget.save(this@PinCatcherActivity, name, action)
                                }) { Text("Save to cells") }
                                OutlinedButton(onClick = {
                                    ActionSaver.saveToScripts(this@PinCatcherActivity, name, action)
                                    Toast.makeText(this@PinCatcherActivity, "Saved to My Scripts", Toast.LENGTH_SHORT).show()
                                }) { Text("Save to My Scripts") }
                            }
                            OutlinedButton(onClick = {
                                runCatching { req?.accept() }
                                finish()
                            }) { Text("Let it be added (accept)") }
                            OutlinedButton(onClick = { finish() }) { Text("Close") }
                        }
                    }
                }
            }
        }
    }
}

/** What the home button shows while A is the temporary launcher. */
class LauncherHomeActivity : ComponentActivity() {
    @OptIn(ExperimentalLayoutApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // "A is the launcher while I use widgets/OCR": show nothing. The bank's screen just closed -> back to the
        // widget/OCR screen; any other home press -> the launcher that was in use before.
        if (LauncherGuard.isOn(this)) {
            val screen = LauncherGuard.screen(this)
            a.a.utils.DiagLog.note("Home pressed while A is the launcher: screen=" + screen + " otherRecent=" + LauncherGuard.otherRecent(this))
            if (screen != null && LauncherGuard.otherRecent(this)) {
                LauncherGuard.clearOther(this)
                runCatching {
                    startActivity(Intent().setClassName(this, screen).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                }
                finish(); overridePendingTransition(0, 0); return
            }
            val prev = LauncherGuard.prevHome(this)?.let { ComponentName.unflattenFromString(it) }
            if (prev != null) {
                val ok = runCatching {
                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setComponent(prev).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.isSuccess
                if (ok) { finish(); overridePendingTransition(0, 0); return }
            }
        }
        setContent {
            AWindow {
                val pm = packageManager
                val ic = Icons.Filled
                val others = remember {
                    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
                }
                Column(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp).verticalScroll(rememberScrollState())) {
                    Text(
                        "A is the temporary launcher", fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    Text(
                        "Pin shortcuts now (for example from Hail) and A shows what they contain. Open your usual launcher below, and switch back when you are done.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 4.dp),
                    )
                    if (others.isNotEmpty()) CardGroup("Your launchers", "Open one, then come back here when you are done") {
                        for (ri in others) row { sh ->
                            SettingRow(
                                ri.loadLabel(pm).toString(), sh, icon = ic.Home,
                                onClick = {
                                    val ai = ri.activityInfo
                                    startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                                        .setComponent(ComponentName(ai.packageName, ai.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                },
                            )
                        }
                    }
                    CardGroup("A") {
                        row { sh ->
                            LinkRow("Choose the default home app", "Opens Android's home app setting", sh, ic.SettingsIcon) {
                                startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        }
                        row { sh ->
                            LinkRow("Widgets and Launcher mode", "The switches for catching pinned shortcuts", sh, ic.Tune) {
                                startActivity(Intent(this@LauncherHomeActivity, LauncherModeActivity::class.java))
                            }
                        }
                        row { sh ->
                            LinkRow("Widgets", "Add widgets, show them floating, put them on your cells", sh, ic.Widgets) {
                                startActivity(Intent(this@LauncherHomeActivity, WidgetHostActivity::class.java))
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

/** The switch for the temporary launcher mode, and the steps to use it. */
class LauncherModeActivity : ComponentActivity() {
    private fun enabled(): Boolean = packageManager.getComponentEnabledSetting(ComponentName(this, HOME_ALIAS)) ==
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                AWindowPage("Widgets and Launcher mode", onBack = { finish() }) { pad ->
                    val ic = Icons.Filled
                    val me = this@LauncherModeActivity
                    var on by remember { mutableStateOf(enabled()) }
                    var status by remember { mutableStateOf("") }
                    var tmp by remember { mutableStateOf(LauncherGuard.isOn(me)) }
                    var ask by remember { mutableStateOf(CellTarget.askOn(me)) }
                    Column(
                        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                    ) {
                        CardGroup(
                            "Catch shortcuts pinned by other apps",
                            "Shortcuts pinned by Hail and other apps open in A, which shows everything Android tells about them, " +
                                "with Copy, Save to cells and Save to My Scripts. It costs nothing while off.",
                        ) {
                            row { sh ->
                                SwitchRow(
                                    "Let A be chosen as a launcher", on, sh, icon = ic.Home,
                                    summary = "Step 1: A appears in Android's list of home apps",
                                ) {
                                    on = it
                                    packageManager.setComponentEnabledSetting(
                                        ComponentName(me, HOME_ALIAS),
                                        if (it) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                                        PackageManager.DONT_KILL_APP,
                                    )
                                }
                            }
                            row { sh ->
                                LinkRow(
                                    "Open Android's default home app setting",
                                    "Step 2: choose A there. When you are done, choose your usual launcher again and turn the switch below off",
                                    sh, ic.SettingsIcon,
                                ) { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                            }
                            row { sh ->
                                SwitchRow(
                                    "A is the launcher while I use widgets or OCR", tmp, sh, icon = ic.Widgets,
                                    summary = "Turn it on before you go in, and off when you are done",
                                ) { want ->
                                    status = if (want) "Turning on…" else "Turning off…"
                                    LauncherGuard.set(me, want) { _, msg ->
                                        runOnUiThread { tmp = LauncherGuard.isOn(me); status = msg }
                                    }
                                }
                            }
                            row { sh ->
                                SettingRow(
                                    "Is A the launcher now?", sh, icon = ic.Check,
                                    summary = status.ifEmpty { "Tap to check" },
                                    onClick = { status = if (isDefaultHome()) "A is the default launcher now." else "A is not the default launcher." },
                                )
                            }
                        }

                        CardGroup("Widgets") {
                            row { sh ->
                                LinkRow("Widgets", "Add widgets, show them floating and put them on your cells", sh, ic.Widgets) {
                                    startActivity(Intent(me, WidgetHostActivity::class.java))
                                }
                            }
                        }

                        CardGroup("Saving cells") {
                            row { sh ->
                                SwitchRow(
                                    "Ask me which cells window", ask, sh, icon = ic.Tune,
                                    summary = "When a cell is saved from outside: the main slider or a segment's own window",
                                ) { ask = it; CellTarget.setAsk(me, it) }
                            }
                        }

                        CardGroup("Good to know") {
                            row { sh ->
                                SettingRow(
                                    "Why A must be the launcher", sh, icon = ic.Info,
                                    summary = "Android hides a pinned shortcut's real intent from launchers, so A also offers to read it with Shizuku. " +
                                        "A shortcut that is a plain activity intent keeps working in cells without A being the launcher; " +
                                        "one that only the launcher can start needs A to be the launcher when it runs.",
                                )
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}
