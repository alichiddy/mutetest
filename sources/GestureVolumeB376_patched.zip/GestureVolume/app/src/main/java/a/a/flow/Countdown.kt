package a.a.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import a.a.utils.DiagLog
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * A countdown for the "Countdown" and "Limit how often" script blocks. It can be a bar over every app
 * (drag it anywhere, "-" shrinks it to the time only, see-through as you choose), a notification that counts
 * down by itself, both, or nothing. Countdowns with the same name are ONE countdown: running the script
 * again continues it (or stops the new run, as the block says) instead of starting a new one.
 * It exists only while it counts: nothing stays in memory afterwards.
 */
object Countdown {
    /** show = bar | notice | both | none; opacity 10..100; name = shared name ("" = the text); again = join | stop | restart. */
    class Opts(val show: String = "bar", val opacity: Int = 80, val name: String = "", val again: String = "join")

    private class Session(val end: Long, val label: String) {
        var users = 1
        var box: LinearLayout? = null
        var text: TextView? = null
        var compact = false
        var noticeId = 0
    }

    private val sessions = HashMap<String, Session>()
    private const val PREFS = "countdown_pos"
    private const val CHANNEL = "countdown"

    /**
     * Shows [label] and the time left until [ms] have passed, or until [stop] says so. Blocking.
     * Returns false only when [Opts.again] is "stop" and a countdown of the same name is already running
     * (nothing was waited for then).
     */
    fun show(app: Context, label: String, ms: Long, opts: Opts = Opts(), stop: () -> Boolean): Boolean {
        val ctx = app.applicationContext
        val main = Handler(Looper.getMainLooper())
        val key = opts.name.ifBlank { label }
        var session: Session? = null
        var created = false
        var refused = false
        synchronized(sessions) {
            val old = sessions[key]
            if (old != null && old.end > System.currentTimeMillis() && opts.again != "restart") {
                if (opts.again == "stop") refused = true
                else { old.users++; session = old }
            } else {
                if (old != null) { sessions.remove(key); teardown(ctx, main, old) }
                val fresh = Session(System.currentTimeMillis() + ms, label)
                sessions[key] = fresh
                session = fresh
                created = true
            }
        }
        if (refused) {
            DiagLog.note("Countdown \"" + key + "\": already running, this run is stopped")
            return false
        }
        val s = session ?: return true
        DiagLog.note("Countdown \"" + key + "\": " + (if (created) "started " + ms + " ms" else "continued, " + (s.end - System.currentTimeMillis()) + " ms left") + " show=" + opts.show)
        if (created) {
            if (opts.show == "bar" || opts.show == "both") buildBar(ctx, main, s, opts)
            if (opts.show == "notice" || opts.show == "both") notify(ctx, key, s)
        }
        try {
            while (!stop()) {
                val left = s.end - System.currentTimeMillis()
                if (left <= 0) break
                val sec = (left + 999) / 1000
                val time = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')
                main.post { s.text?.text = if (s.compact) time else s.label + "  " + time }
                Thread.sleep(minOf(left, 250L))
            }
        } catch (_: InterruptedException) {
        } finally {
            synchronized(sessions) {
                s.users--
                if (s.users <= 0) {
                    if (sessions[key] === s) sessions.remove(key)
                    teardown(ctx, main, s)
                }
            }
        }
        return true
    }

    private fun teardown(ctx: Context, main: Handler, s: Session) {
        val box = s.box
        if (box != null) main.post { runCatching { (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(box) } }
        s.box = null
        if (s.noticeId != 0) runCatching { ctx.getSystemService(NotificationManager::class.java).cancel(s.noticeId) }
    }

    private fun notify(ctx: Context, key: String, s: Session) {
        runCatching {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Countdowns", NotificationManager.IMPORTANCE_LOW))
            val id = 7400 + (key.hashCode() and 0x3FF)
            s.noticeId = id
            val left = s.end - System.currentTimeMillis()
            nm.notify(
                id,
                Notification.Builder(ctx, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle(s.label)
                    .setWhen(s.end)
                    .setShowWhen(true)
                    .setUsesChronometer(true)
                    .setChronometerCountDown(true)
                    .setOnlyAlertOnce(true)
                    .setOngoing(true)
                    .setTimeoutAfter((left + 1500).coerceAtLeast(1500L))
                    .build(),
            )
        }
    }

    private fun buildBar(ctx: Context, main: Handler, s: Session, opts: Opts) {
        if (!Settings.canDrawOverlays(ctx)) {
            main.post { Toast.makeText(ctx, s.label + " " + ((s.end - System.currentTimeMillis()) / 1000) + " s", Toast.LENGTH_LONG).show() }
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            runCatching {
                val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val d = ctx.resources.displayMetrics.density
                val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val box = LinearLayout(ctx)
                box.orientation = LinearLayout.HORIZONTAL
                box.gravity = Gravity.CENTER_VERTICAL
                box.setPadding((16 * d).toInt(), (8 * d).toInt(), (8 * d).toInt(), (8 * d).toInt())
                box.background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 24 * d }
                box.alpha = opts.opacity.coerceIn(10, 100) / 100f
                val tv = TextView(ctx)
                tv.setTextColor(Color.WHITE)
                tv.textSize = 20f
                tv.gravity = Gravity.CENTER
                val btn = TextView(ctx)
                btn.text = "–"
                btn.setTextColor(Color.WHITE)
                btn.textSize = 22f
                btn.gravity = Gravity.CENTER
                btn.setPadding((14 * d).toInt(), 0, (8 * d).toInt(), 0)
                box.addView(tv)
                box.addView(btn)
                btn.setOnClickListener {
                    s.compact = !s.compact
                    btn.text = if (s.compact) "+" else "–"
                    tv.textSize = if (s.compact) 14f else 20f
                    val left = s.end - System.currentTimeMillis()
                    val sec = (left.coerceAtLeast(0L) + 999) / 1000
                    val time = (sec / 60).toString() + ":" + (sec % 60).toString().padStart(2, '0')
                    tv.text = if (s.compact) time else s.label + "  " + time
                }
                val p = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT,
                )
                p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                p.x = sp.getInt("x", 0)
                p.y = sp.getInt("y", (80 * d).toInt())
                val slop = ViewConfiguration.get(ctx).scaledTouchSlop
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
                box.setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; moved = false; true }
                        MotionEvent.ACTION_MOVE -> {
                            if (Math.abs(e.rawX - downX) > slop || Math.abs(e.rawY - downY) > slop) moved = true
                            if (moved) {
                                p.x = startX + (e.rawX - downX).toInt()
                                p.y = startY + (e.rawY - downY).toInt()
                                runCatching { wm.updateViewLayout(box, p) }
                            }
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (moved) sp.edit().putInt("x", p.x).putInt("y", p.y).apply()
                            true
                        }
                        else -> false
                    }
                }
                wm.addView(box, p)
                s.box = box
                s.text = tv
            }
            latch.countDown()
        }
        latch.await(2, TimeUnit.SECONDS)
    }
}
