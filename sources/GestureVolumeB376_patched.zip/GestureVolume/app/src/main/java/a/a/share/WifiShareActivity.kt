package a.a.share

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.clickable
import androidx.compose.material3.Checkbox
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import a.a.ui.motion.Button
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * "A Wi-Fi Share" in the share sheet of any app: starts WifiShareService with the shared files and
 * shows the two QR codes (join the Wi-Fi, open the file page), the name, password and a Stop button.
 */
class WifiShareActivity : ComponentActivity() {
    private var pending: Intent? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val i = pending
        pending = null
        if (i != null) startShare(i)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ShareScreen(
                        onUpload = { on -> SharePrefs.saveUpload(this, on) },
                        onApply = { n, p, b -> applySettings(n, p, b) },
                        onStop = { stopShare() },
                        onOpen = { what -> openPanel(what) }
                    )
                }
            }
        }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent) {
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE || i.action == ACTION_START) {
            if (i.action != ACTION_START && urisOf(i).isEmpty()) {
                Toast.makeText(this, "Nothing to share (only files can be shared over Wi-Fi).", Toast.LENGTH_LONG).show()
                return
            }
            val need = ArrayList<String>()
            if (Build.VERSION.SDK_INT >= 33) {
                need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
                need.add(Manifest.permission.POST_NOTIFICATIONS)
            } else need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) startShare(i) else {
                pending = i
                permLauncher.launch(missing.toTypedArray())
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun urisOf(i: Intent): List<Uri> {
        val list = ArrayList<Uri>()
        if (i.action == Intent.ACTION_SEND) {
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.add(it) }
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { list.addAll(it) }
        }
        return list
    }

    private fun startShare(i: Intent) {
        val uris = urisOf(i)
        val s = Intent(this, WifiShareService::class.java)
        if (uris.isNotEmpty()) {
            s.putParcelableArrayListExtra(WifiShareService.EXTRA_URIS, ArrayList(uris))
            val clip = ClipData.newRawUri("files", uris[0])
            for (k in 1 until uris.size) clip.addItem(ClipData.Item(uris[k]))
            s.clipData = clip
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else if (i.action != ACTION_START) return
        startForegroundService(s)
    }

    companion object {
        /** Starts Wi-Fi Direct and the web page with no files (the built-in shortcut), so the other device can send files here. */
        const val ACTION_START = "a.a.share.START"
    }

    private fun applySettings(name: String, pass: String, band: Int) {
        SharePrefs.save(this, name, pass, band)
        startService(Intent(this, WifiShareService::class.java).setAction(WifiShareService.ACTION_REGROUP))
    }

    private fun stopShare() {
        startService(Intent(this, WifiShareService::class.java).setAction(WifiShareService.ACTION_STOP))
    }

    private fun openPanel(what: String) {
        val action = if (what == "wifi") {
            if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS
        } else Settings.ACTION_LOCATION_SOURCE_SETTINGS
        runCatching { startActivity(Intent(action)) }
    }
}

@Composable
private fun ShareScreen(onUpload: (Boolean) -> Unit, onApply: (String, String, Int) -> Unit, onStop: () -> Unit, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val ui by WifiShareState.ui.collectAsState()
    var name by remember { mutableStateOf(SharePrefs.ssid(ctx)) }
    var pass by remember { mutableStateOf(SharePrefs.pass(ctx)) }
    var band by remember { mutableIntStateOf(SharePrefs.band(ctx)) }
    val wifiBmp = remember(ui.wifiQr) { if (ui.wifiQr.isEmpty()) null else QrImage.make(ui.wifiQr, 640) }
    val urlBmp = remember(ui.url) { if (ui.url.isEmpty()) null else QrImage.make(ui.url, 640) }
    val lanBmp = remember(ui.lanUrl) { if (ui.lanUrl.isEmpty()) null else QrImage.make(ui.lanUrl, 640) }
    var upload by remember { mutableStateOf(SharePrefs.upload(ctx)) }
    var big by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Share over Wi-Fi", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(if (ui.status.isEmpty()) "Waiting for files..." else ui.status)
        if (ui.need.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Button(onClick = { onOpen(ui.need) }) {
                Text(if (ui.need == "wifi") "Open Wi-Fi panel" else "Open Location settings")
            }
        }
        if (wifiBmp != null || urlBmp != null || lanBmp != null) {
            Spacer(Modifier.height(14.dp))
            val codes = listOf(
                Triple(1, wifiBmp, "1. Join the Wi-Fi"),
                Triple(2, urlBmp, "2. Open (Wi-Fi Direct)"),
                Triple(3, lanBmp, "3. Open (current Wi-Fi)")
            ).filter { it.second != null }
            if (big != 0 && codes.any { it.first == big }) {
                val c = codes.first { it.first == big }
                Column(
                    modifier = Modifier.fillMaxWidth().clickable { big = 0 },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        bitmap = c.second!!.asImageBitmap(), contentDescription = c.third,
                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).background(Color.White).padding(6.dp)
                    )
                    Text(c.third + "  (tap to make it small)", fontSize = 14.sp)
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in codes) {
                        Column(
                            modifier = Modifier.weight(1f).clickable { big = c.first },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                bitmap = c.second!!.asImageBitmap(), contentDescription = c.third,
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f).background(Color.White).padding(3.dp)
                            )
                            Text(c.third, fontSize = 11.sp)
                        }
                    }
                }
                Text("Tap a code to make it big.", fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            if (ui.ssid.isNotEmpty()) {
                Text("Network: " + ui.ssid)
                Text("Password: " + ui.pass)
                Text("Band: " + ui.bandText)
            }
            if (ui.url.isNotEmpty()) Text("Address (Wi-Fi Direct): " + ui.url)
            Text(if (ui.lanUrl.isNotEmpty()) "Address (current Wi-Fi): " + ui.lanUrl else "Address (current Wi-Fi): not connected to a Wi-Fi network")
            Text("Downloads started: " + ui.served)
            if (upload) {
                Text("Files received: " + ui.received)
                for (n in ui.receivedNames) Text(n, fontSize = 13.sp)
            }
        }
        if (ui.files.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Files (" + ui.files.size + ")", fontWeight = FontWeight.Bold)
            for (f in ui.files) Text(f, fontSize = 13.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Settings", fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier.fillMaxWidth().clickable { upload = !upload; onUpload(upload) },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = upload, onCheckedChange = { upload = it; onUpload(it) })
            Text("Let the other device send files to this phone (saved in Download)")
        }
        OutlinedTextField(
            value = name, onValueChange = { name = it }, singleLine = true,
            label = { Text("Network name (starts with DIRECT-xx)") }, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, singleLine = true,
            label = { Text("Password (8 or more characters)") }, modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = band == 5, onClick = { band = 5 })
            Text("5 GHz")
            Spacer(Modifier.width(16.dp))
            RadioButton(selected = band == 2, onClick = { band = 2 })
            Text("2.4 GHz")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { onApply(name, pass, band) }) { Text("Apply and restart") }
            Button(onClick = onStop) { Text("Stop server") }
        }
    }
}
