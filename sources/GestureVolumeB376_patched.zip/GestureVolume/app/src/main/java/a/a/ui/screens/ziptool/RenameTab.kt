package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File
import java.util.zip.ZipFile

/**
 * Rename the app in a project zip: pick the zip, see its package name (applicationId) and app name (app_name
 * label) found for you, type the new ones, and save a new zip in Downloads that is read back and checked.
 * Only the applicationId line and the app_name label change; the code namespace and every .kt file stay as
 * they are. The rules live in [RenameLogic].
 */
class RenameState(private val ctx: Context) {
    var zipName by mutableStateOf<String?>(null)
    var srcFile by mutableStateOf<File?>(null)
    var oldPkg by mutableStateOf("")
    var oldLabel by mutableStateOf("")
    var newPkg by mutableStateOf("")
    var newLabel by mutableStateOf("")
    var outName by mutableStateOf("")
    var review by mutableStateOf("")
    var busy by mutableStateOf(false)
    var log by mutableStateOf("")

    val pkgOk: Boolean get() = RenameLogic.PKG_OK.matches(newPkg.trim())
    val ready: Boolean get() = srcFile != null && pkgOk && newLabel.isNotBlank() && outName.isNotBlank()

    fun cleanup() {
        File(ctx.cacheDir, SRC_TMP).delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    /** Copies the chosen zip into the app's cache, finds the two names and lists the hand-written spots. */
    fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        review = ""
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            try {
                val f = File(ctx.cacheDir, SRC_TMP)
                ZipIo.copyToCache(ctx.contentResolver, u, f)
                val found = ZipFile(f).use { zf -> RenameLogic.find(zf) }
                val spots = ZipFile(f).use { zf -> RenameLogic.reviewList(zf, found.pkg) }
                srcFile = f
                zipName = name
                oldPkg = found.pkg
                oldLabel = found.label
                newPkg = found.pkg
                newLabel = found.label
                outName = ZipIo.stem(name) + "_renamed.zip"
                review = spots
            } catch (e: Throwable) {
                srcFile = null
                zipName = null
                log = "RENAME ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was changed."
            } finally {
                busy = false
            }
        }.start()
    }

    fun make() {
        val src = srcFile ?: return
        if (busy) return
        val pkg = newPkg.trim()
        val label = newLabel.trim()
        if (!RenameLogic.PKG_OK.matches(pkg)) {
            log = "RENAME ERROR: the package name needs two or more parts with dots, each starting with a letter (like a.a3)."
            return
        }
        busy = true
        log = ""
        val saveName = ZipIo.cleanName(outName, "renamed")
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                val plan = ZipFile(src).use { zf -> RenameLogic.plan(zf, pkg, label) }
                if (plan.edits.isEmpty()) throw IllegalStateException("The new names are the same as the old ones. Nothing to change.")
                val out = ZipIo.rewrite(src, tmp, plan.edits.mapValues { ZipIo.Blob(it.value) })
                val sb = StringBuilder()
                sb.append("PACKAGE: ${plan.oldPkg} -> $pkg\n")
                sb.append("APP NAME: ${plan.oldLabel} -> $label\n")
                sb.append("Changed files:\n")
                for (n in plan.edits.keys) sb.append(" - $n\n")
                if (out.skipped > 0) sb.append("Note: ${out.skipped} repeated file name(s) in the zip were left out.\n")
                val problem = ZipIo.verify(tmp, out.written, out.expectCrc)
                    ?: RenameLogic.check(tmp, out.written, plan, pkg, label)
                if (problem != null) {
                    sb.append("RENAME ERROR: $problem\nNothing was saved.")
                } else {
                    val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
                    sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                    sb.append("Read back and checked. ${out.written} files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "RENAME ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                tmp.delete()
                busy = false
            }
        }.start()
    }

    private companion object {
        const val SRC_TMP = "zt_rename_src.zip"
        const val OUT_TMP = "zt_rename_out.zip"
    }
}

@Composable
fun RenameTab(s: RenameState) {
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(u)
    }
    HeroCard(
        title = "Rename the app in a zip",
        text = "Pick the project zip. Type the new package name and app name. A new zip is saved in Downloads and checked. Only those two things change.",
        leading = { IconTile(Icons.Filled.Edit, lit = true) },
    )
    Column {
        GroupHeading("Project zip")
        RowGroup {
            KitRow(
                title = "Zip file",
                shape = cardShape(0, 3),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = s.zipName ?: "Tap to choose",
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "Package name now",
                shape = cardShape(1, 3),
                summary = if (s.srcFile != null) s.oldPkg else "Found after you choose the zip",
            )
            KitRow(
                title = "App name now",
                shape = cardShape(2, 3),
                summary = if (s.srcFile != null) s.oldLabel else "Found after you choose the zip",
            )
        }
    }
    Column {
        GroupHeading("New names")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = s.newPkg,
                onValueChange = { s.newPkg = it },
                singleLine = true,
                isError = s.newPkg.isNotBlank() && !s.pkgOk,
                label = { Text("New package name (like a.a3)") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.newLabel,
                onValueChange = { s.newLabel = it },
                singleLine = true,
                label = { Text("New app name (like A3)") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.outName,
                onValueChange = { s.outName = it },
                singleLine = true,
                label = { Text("File name (saved in Downloads)") },
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
    Button(
        onClick = { s.make() },
        enabled = s.ready && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) "Working..." else "Rename and make zip") }
    ResultBox(s.log)
    if (s.review.isNotEmpty()) {
        Column {
            GroupHeading("To review (not changed)")
            TextBox(s.review)
        }
    }
}
