package a.a.sides

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import a.a.ui.motion.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.service.OverlayRuntime
import a.a.ui.screens.strip.NumberBox
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip
import a.a.ui.components.CardWindow
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SliderRow
import a.a.ui.screens.strip.StepRow
import a.a.ui.screens.strip.SwitchRow
import a.a.data.local.SharedPref
import a.a.strip.StripConfig
import a.a.strip.StripScope
import a.a.ui.activities.MainActivity

/**
 * Side bars: a thin strip on the left and/or right edge, each with up to three segments. A segment
 * can have actions on tap, double tap, long press and four swipes, or act as a volume or brightness
 * slider. Changes apply at once.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
class SidesActivity : ComponentActivity() {
    private class PickRequest(val slot: String, val onPicked: (String) -> Unit)
    private val pickReq = mutableStateOf<PickRequest?>(null)

    /** Opens the action picker for one gesture; [onPicked] gets the chosen action. */
    fun showPicker(slot: String, onPicked: (String) -> Unit) { pickReq.value = PickRequest(slot, onPicked) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AWindow {
                pickReq.value?.let { req ->
                    SegmentPicker(this@SidesActivity, req.slot, req.onPicked, onClose = { pickReq.value = null })
                }
                var cfg by remember { mutableStateOf(SideConfig.load(this@SidesActivity)) }
                fun update(new: SideConfig) {
                    val keyboardChanged = new.hideForKeyboard != cfg.hideForKeyboard
                    cfg = new
                    SideConfig.save(this@SidesActivity, new)
                    OverlayRuntime.activeController?.let { if (keyboardChanged) it.refreshAutoHide() else it.refreshSides() }
                }
                AWindowPage(title = "Side bars", onBack = { this@SidesActivity.finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(
                            "A thin strip on each edge. Split it into up to 3 segments; each segment has its own actions, or works as a volume or brightness slider. Swipe in/out means toward/away from the screen's middle, so both sides mirror.",
                            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp),
                        )
                        var testBar by remember { mutableStateOf(getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE).getBoolean("testBarOn", false)) }
                        CardGroup(title = "All side bars") {
                            row { sh ->
                                SwitchRow(
                                    "Hide the side bars while the keyboard is open", cfg.hideForKeyboard, sh,
                                    info = "For phones using Back-swipe gestures: with the keyboard open the edge strips would fight the Back swipe. You can bind \"Back\" to Swipe in on a segment instead.",
                                ) { update(cfg.copy(hideForKeyboard = it)) }
                            }
                            row { sh ->
                                SwitchRow("Keep the main slider's bar away while a side segment changes volume or brightness", cfg.hideMainBar, sh) {
                                    update(cfg.copy(hideMainBar = it))
                                }
                            }
                            row { sh ->
                                SwitchRow("Let side sliders go on into the boost bar (up to +32 dB)", cfg.boostBar, sh, summary = "Off = they stop at the maximum volume") {
                                    update(cfg.copy(boostBar = it))
                                }
                            }
                            row { sh ->
                                SwitchRow("Test bar", testBar, sh, summary = "A horizontal strip at the bottom-left; slide along it to set the volume") {
                                    testBar = it
                                    getSharedPreferences("MyPrefs", android.content.Context.MODE_PRIVATE).edit().putBoolean("testBarOn", it).apply()
                                    OverlayRuntime.activeController?.refreshSides()
                                }
                            }
                        }
                        SideEditor("Left side", "L", allSegs(cfg), cfg.left) { update(cfg.copy(left = it)) }
                        SideEditor("Right side", "R", allSegs(cfg), cfg.right) { update(cfg.copy(right = it)) }
                    }
                }
            }
        }
    }

    /** Every segment that is on, as (code, name), for "same place and height as another segment". */
    private fun allSegs(cfg: SideConfig): List<Pair<String, String>> = buildList {
        cfg.left.takeIf { it.on }?.segs?.forEachIndexed { i, g -> if (g.on) add("L${i + 1}" to "Left ${i + 1}") }
        cfg.right.takeIf { it.on }?.segs?.forEachIndexed { i, g -> if (g.on) add("R${i + 1}" to "Right ${i + 1}") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        SidePicker.onResult(requestCode, resultCode, data)
    }

    @Composable
    private fun SideEditor(title: String, letter: String, all: List<Pair<String, String>>, side: Side, onChange: (Side) -> Unit) {
        CardGroup(title = title) {
            row { sh -> SwitchRow("$title on", side.on, sh) { onChange(side.copy(on = it)) } }
        }
        if (!side.on) return
        var sel by remember { mutableStateOf(0) }
        val selected = sel.coerceIn(0, side.segs.lastIndex)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Segment")
            for (n in 1..3) ChoiceChip(
                label = "$n",
                selected = selected == n - 1,
                onClick = {
                    // Pressing a number turns on that many segments (settings of the others are kept,
                    // just switched off) and brings that segment's settings to the top.
                    val segs = side.segs.toMutableList()
                    while (segs.size < n) segs += Seg(topPct = (20 + 25 * segs.size).coerceAtMost(75), heightPct = 20)
                    for (k in segs.indices) segs[k] = segs[k].copy(on = k < n)
                    sel = n - 1
                    onChange(side.copy(segs = segs))
                },
            )
        }
        // The chosen segment first, the others below it.
        val order = listOf(selected) + side.segs.indices.filter { it != selected }
        order.forEach { i ->
            SegEditor(i + 1, letter + (i + 1), all, side.segs[i]) { new -> onChange(side.copy(segs = side.segs.toMutableList().also { it[i] = new })) }
        }
    }

    /** A segment's own place and height for landscape (Separate mode). Width, look and gestures are shared with portrait. */
    @Composable
    private fun LandscapePlace(seg: Seg, selfCode: String, all: List<Pair<String, String>>, onChange: (Seg) -> Unit) {
        val l = seg.landscape()
        fun set(n: SegLand) = onChange(seg.copy(land = n))
        var pickLink by remember { mutableStateOf(false) }
        val options = all.filter { it.first != selfCode }
        if (pickLink) PickWindow(
            title = "Same position and height as",
            onBack = { pickLink = false },
            choices = listOf("Own (not linked)" to { pickLink = false; set(l.copy(linkTo = "")) }) +
                options.map { (code, name) -> name to { pickLink = false; set(l.copy(linkTo = code)) } },
        )
        val linkedName = all.firstOrNull { it.first == l.linkTo && it.first != selfCode }?.second
        CardGroup(
            title = "Landscape: place and height",
            hint = if (linkedName != null) "In landscape, position and height follow $linkedName; the settings below apply when not linked." else null,
        ) {
            if (options.isNotEmpty()) row { sh ->
                LinkRow("Same position and height as", linkedName ?: "Own (not linked)", sh) { pickLink = true }
            }
            row { sh -> SwitchRow("Position: follow the main slider's top (live)", l.posMain, sh) { set(l.copy(posMain = it)) } }
            row { sh ->
                if (l.posMain) SliderRow("${selfCode}_l_shift", "Moved", "%", l.shiftPct, -60, 60, sh, summary = "Negative = up, positive = down") { set(l.copy(shiftPct = it)) }
                else SliderRow("${selfCode}_l_top", "Starts from the top", "%", l.topPct, 0, 95, sh) { set(l.copy(topPct = it)) }
            }
            row { sh -> SwitchRow("Height: same as the main slider (live)", l.heightMain, sh) { set(l.copy(heightMain = it)) } }
            if (!l.heightMain) row { sh ->
                SliderRow("${selfCode}_l_h", "Height of the screen", "%", l.heightPct, 5, 100, sh) { set(l.copy(heightPct = it)) }
            }
        }
    }

    @Composable
    private fun SegEditor(number: Int, selfCode: String, all: List<Pair<String, String>>, seg: Seg, onChange: (Seg) -> Unit) {
        Surface(color = androidx.compose.ui.graphics.Color.Transparent, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                CardGroup(title = "Segment $number") {
                    row { sh -> SwitchRow("Segment $number on", seg.on, sh) { onChange(seg.copy(on = it)) } }
                }
                if (!seg.on) return@Column
                CardGroup(title = "Look and use") {
                    row { sh ->
                        SwitchRow(
                            "Look: exactly like the main slider", seg.copyLook, sh,
                            summary = "Colour, fill, outline, corners, percentage, panel",
                            info = "Look off: a faint edge line that lights up when touched.",
                        ) { onChange(seg.copy(copyLook = it)) }
                    }
                    row { sh ->
                        SettingRow(
                            title = "What this segment does", shape = sh,
                            summary = if (seg.mode != Seg.MODE_ACTIONS) "Swipe up and down on it to change the level like the main slider does. Tap and the swipes in/out still work." else null,
                            footer = {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ChoiceChip("Actions", seg.mode == Seg.MODE_ACTIONS, { onChange(seg.copy(mode = Seg.MODE_ACTIONS)) })
                                    ChoiceChip("Volume slider", seg.mode == Seg.MODE_VOLUME, { onChange(seg.copy(mode = Seg.MODE_VOLUME)) })
                                    ChoiceChip("Brightness", seg.mode == Seg.MODE_BRIGHTNESS, { onChange(seg.copy(mode = Seg.MODE_BRIGHTNESS)) })
                                }
                            },
                        )
                    }
                }
                // Separate settings for landscape: this segment's place and height are chosen for each orientation.
                val separate = remember { !SharedPref(this@SidesActivity).getHandlerSamePositionBothOrientations() }
                var editLand by remember { mutableStateOf(false) }
                if (separate) CardGroup(title = "Place and height for") {
                    row { sh ->
                        SettingRow(
                            title = "Orientation", shape = sh,
                            footer = {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ChoiceChip("Portrait", !editLand, { editLand = false })
                                    ChoiceChip("Landscape", editLand, { editLand = true })
                                }
                            },
                        )
                    }
                }
                if (separate && editLand) {
                    LandscapePlace(seg, selfCode, all, onChange)
                } else {
                // Place and height of another segment, live: a left and a right segment linked this way sit exactly alike.
                var pickLink by remember { mutableStateOf(false) }
                val options = all.filter { it.first != selfCode }
                if (pickLink) PickWindow(
                    title = "Same position and height as",
                    onBack = { pickLink = false },
                    choices = listOf("Own (not linked)" to { pickLink = false; onChange(seg.copy(linkTo = "")) }) +
                        options.map { (code, name) -> name to { pickLink = false; onChange(seg.copy(linkTo = code)) } },
                )
                val linkedName = all.firstOrNull { it.first == seg.linkTo && it.first != selfCode }?.second
                CardGroup(
                    title = "Place and size",
                    hint = if (linkedName != null) "Position and height follow $linkedName; the sliders below apply when not linked." else null,
                ) {
                    if (options.isNotEmpty()) row { sh ->
                        LinkRow("Same position and height as", linkedName ?: "Own (not linked)", sh) { pickLink = true }
                    }
                    // Place: each segment has its own, or follows the main slider live.
                    row { sh -> SwitchRow("Position: follow the main slider's top (live)", seg.posMain, sh) { onChange(seg.copy(posMain = it)) } }
                    row { sh ->
                        if (seg.posMain) SliderRow("${selfCode}_shift", "Moved", "%", seg.shiftPct, -60, 60, sh, summary = "Negative = up, positive = down") { onChange(seg.copy(shiftPct = it)) }
                        else SliderRow("${selfCode}_top", "Starts from the top", "%", seg.topPct, 0, 95, sh) { onChange(seg.copy(topPct = it)) }
                    }
                    // Size: one switch for height and width, or one by one.
                    row { sh -> SwitchRow("Size (height and width): same as the main slider (live)", seg.sizeAll, sh) { onChange(seg.copy(sizeAll = it)) } }
                    if (!seg.sizeAll) {
                        row { sh -> SwitchRow("Height: same as the main slider", seg.heightMain, sh) { onChange(seg.copy(heightMain = it)) } }
                        if (!seg.heightMain) row { sh ->
                            SliderRow("${selfCode}_h", "Height of the screen", "%", seg.heightPct, 5, 100, sh) { onChange(seg.copy(heightPct = it)) }
                        }
                        row { sh -> SwitchRow("Width: same as the main slider", seg.copyWidth, sh) { onChange(seg.copy(copyWidth = it)) } }
                        if (!seg.copyWidth) row { sh ->
                            SliderRow("${selfCode}_w", "Width", " dp", seg.widthDp, 8, 40, sh) { onChange(seg.copy(widthDp = it)) }
                        }
                    }
                }
                }
                // Feel: what the user got used to on the main slider is the same on every segment, unless switched off here.
                CardGroup(title = "Gesture feel") {
                    row { sh ->
                        SwitchRow(
                            "Same as the main slider (live)", seg.feelAll, sh,
                            summary = "Slide-in distance, touch area, straight up/down",
                        ) { onChange(seg.copy(feelAll = it)) }
                    }
                    if (!seg.feelAll) {
                        row { sh -> SwitchRow("Slide-in distance: same as the main slider", seg.inMain, sh) { onChange(seg.copy(inMain = it)) } }
                        if (!seg.inMain) row { sh ->
                            SliderRow("${selfCode}_in", "Slide-in distance", " dp", seg.inDp, 0, 40, sh, summary = "0 = automatic") { onChange(seg.copy(inDp = it)) }
                        }
                        row { sh -> SwitchRow("Touch area: same rule as the main slider", seg.touchMain, sh) { onChange(seg.copy(touchMain = it)) } }
                        if (!seg.touchMain) row { sh ->
                            SliderRow("${selfCode}_touch", "Touch area at least", " dp", seg.touchDp, 0, 60, sh, summary = "0 = exactly as drawn") { onChange(seg.copy(touchDp = it)) }
                        }
                        row { sh -> SwitchRow("Straight up/down needed: same as the main slider", seg.vertMain, sh) { onChange(seg.copy(vertMain = it)) } }
                        if (!seg.vertMain) row { sh ->
                            SliderRow(
                                "${selfCode}_vert", "Level slides only within", "°", seg.vertDeg, 5, 45, sh,
                                summary = "of straight up/down; a more angled slide counts as a slide in",
                            ) { onChange(seg.copy(vertDeg = it.coerceIn(5, 45))) }
                        }
                    }
                }
                // Cells window: the main slider's (live), or this segment's own, which starts empty.
                var confirmOwn by remember { mutableStateOf(false) }
                var confirmCopy by remember { mutableStateOf(false) }
                CardGroup(
                    title = "Cells window",
                    hint = if (seg.ownWindow) "This segment has its own cells window: its own cells, look, gap, popup, effects and outside actions. Switching back to \"same as the main slider\" keeps it saved. Widgets/Launcher mode, Previous app and Click circle stay shared."
                    else "This segment opens the main slider's cells window (mirrored on the left side).",
                ) {
                    row { sh ->
                        SwitchRow("Cells window: same as the main slider", !seg.ownWindow, sh) { same ->
                            if (same) onChange(seg.copy(ownWindow = false))
                            else if (StripScope.prefs(this@SidesActivity, "").contains(StripScope.configKey(seg.id))) onChange(seg.copy(ownWindow = true))
                            else confirmOwn = true
                        }
                    }
                    row { sh -> LinkRow("Cells window settings", "Opens the editor for this window", sh) { openCellsWindow(seg) } }
                    if (seg.ownWindow) row { sh ->
                        LinkRow("Copy the main slider's cells and settings once", "Replaces this window's cells and settings", sh) { confirmCopy = true }
                    }
                }
                if (confirmOwn) ConfirmWindow(
                    title = "Own cells window",
                    text = "This segment gets its own empty cells window. You can fill it with the editor, or copy the main slider's cells and settings once.",
                    confirm = "OK",
                    onBack = { confirmOwn = false },
                    onConfirm = {
                        confirmOwn = false
                        // The old rows' values (gap, outside actions) move into the new window once.
                        val mainLeft = SharedPref(this@SidesActivity).getHandlerPosition() == "Left"
                        StripScope.migrateLegacy(this@SidesActivity, seg, seg.mirror && selfCode.startsWith("L") != mainLeft)
                        onChange(seg.copy(ownWindow = true))
                    },
                )
                var confirmDelete by remember { mutableStateOf(false) }
                if (StripScope.exists(this@SidesActivity, seg.id)) CardGroup(title = "Own cells window") {
                    row { sh -> LinkRow("Delete this segment's own window", "Its cells and settings are removed for good", sh) { confirmDelete = true } }
                }
                if (confirmDelete) ConfirmWindow(
                    title = "Delete the own cells window",
                    text = "Its cells and settings are removed for good. The segment goes back to the main slider's cells window.",
                    confirm = "Delete",
                    onBack = { confirmDelete = false },
                    onConfirm = {
                        confirmDelete = false
                        StripScope.deleteWindow(this@SidesActivity, seg.id)
                        onChange(seg.copy(ownWindow = false))
                    },
                )
                if (confirmCopy) ConfirmWindow(
                    title = "Copy the main slider's window",
                    text = "The cells and settings of this segment's own window are replaced by a copy of the main slider's. Later changes do not follow.",
                    confirm = "Copy",
                    onBack = { confirmCopy = false },
                    onConfirm = { confirmCopy = false; copyMainWindow(seg.id) },
                )
                // Kept in the window's own settings for an own window: "Copy once" and "Delete own window" see it.
                val winPrefs = if (seg.ownWindow) StripScope.prefs(this@SidesActivity, seg.id) else null
                var winMirror by remember(seg.id, confirmCopy) { mutableStateOf(winPrefs?.getBoolean("stripMirror", true) ?: true) }
                var edgeDlg by remember { mutableStateOf(false) }
                CardGroup(title = "Cells window position") {
                    row { sh ->
                        SwitchRow(
                            "Mirrored when this segment is on the other side from the main bar",
                            if (seg.ownWindow) winMirror else seg.mirror, sh,
                        ) {
                            if (seg.ownWindow) { winMirror = it; winPrefs?.edit()?.putBoolean("stripMirror", it)?.apply() }
                            else onChange(seg.copy(mirror = it))
                        }
                    }
                    if (!seg.ownWindow) {
                        // The cells window of this segment: gap to the screen's side and its own outside actions (never copied from the main slider).
                        row { sh -> SwitchRow("Gap to the screen's side: same as the main slider", seg.gapDp < 0, sh) { onChange(seg.copy(gapDp = if (it) -1 else 10)) } }
                        if (seg.gapDp >= 0) row { sh ->
                            SettingRow(title = "Gap", shape = sh, footer = { NumberBox("Gap (dp)", seg.gapDp) { onChange(seg.copy(gapDp = it)) } })
                        }
                        row { sh -> LinkRow("Action outside of cells window", if (seg.edgeOn) "On" else "Off", sh) { edgeDlg = true } }
                    }
                }
                if (!seg.ownWindow) {
                if (edgeDlg) CardWindow(title = "Action outside of cells window", onBack = { edgeDlg = false }) {
                    CardGroup(
                        title = "For this segment only",
                        hint = "Slide in, move the thumb out of the cells window over a side and let go: that side's action runs. A side with nothing set does nothing. On a left segment the window is mirrored, so Left means the side away from the screen's edge.",
                    ) {
                        row { sh -> SwitchRow("All actions follow main", seg.edgeFollow, sh) { onChange(seg.copy(edgeFollow = it)) } }
                        if (!seg.edgeFollow) row { sh -> SwitchRow("On", seg.edgeOn, sh) { onChange(seg.copy(edgeOn = it)) } }
                    }
                    if (seg.edgeFollow) {
                        Text(
                            if (seg.mirror) "These are the main bar's actions and fields, mirrored: Left and Right are swapped on this segment's window, and fields above/below run the other way round."
                            else "These are the main bar's four actions, not mirrored.",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                        )
                    } else {
                        Text(
                            "Own actions: Left stays left and Right stays right, even when the window is mirrored.",
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                        )
                        listOf("Top", "Left", "Bottom", "Right").forEach { side ->
                            val cnt = seg.edgeCount(side)
                            CardGroup(
                                title = side,
                                hint = if (cnt > 1) {
                                    if (side == "Top" || side == "Bottom") "Equal fields, numbered left to right (along the cells window)."
                                    else "Equal fields, numbered top to bottom (along the cells window)."
                                } else null,
                            ) {
                                row { sh ->
                                    StepRow(
                                        title = "$side: fields", value = "$cnt", shape = sh,
                                        onMinus = { if (cnt > 1) onChange(seg.withEdgeCount(side, cnt - 1)) },
                                        onPlus = { if (cnt < 6) onChange(seg.withEdgeCount(side, cnt + 1)) },
                                    )
                                }
                            }
                            for (zone in 0 until cnt) {
                                ActionRow("edge", if (cnt > 1) "$side ${zone + 1}" else side, seg.edgeAct(side, zone)) { onChange(seg.withEdgeAct(side, zone, it)) }
                            }
                        }
                    }
                }
                }
                var pickFrom by remember { mutableStateOf(false) }
                val fromOptions = all.filter { it.first != selfCode }
                val fromName = all.firstOrNull { it.first == seg.actFrom }?.second
                CardGroup(title = "All gestures at once") {
                    row { sh ->
                        SettingRow(
                            title = "All gestures: follow main", shape = sh, summary = "Every gesture follows the main slider (live)",
                            onClick = {
                                onChange(seg.copy(actFrom = "", tap = Seg.MAIN, double = Seg.MAIN, long = Seg.MAIN, up = Seg.MAIN, down = Seg.MAIN, inward = Seg.MAIN, outward = Seg.MAIN))
                            },
                        )
                    }
                    row { sh ->
                        SettingRow(
                            title = "Copy all now", shape = sh, summary = "Copies the main slider's gestures once",
                            onClick = {
                                val p = SharedPref(this@SidesActivity)
                                onChange(seg.copy(
                                    actFrom = "",
                                    tap = p.getHandlerSingleTapAction(), double = p.getHandlerDoubleTapAction(), long = p.getHandlerLongTapAction(),
                                    up = p.getHandlerSwipeUpAction(), down = p.getHandlerSwipeDownAction(),
                                    inward = if (p.getStripEnabled()) Seg.STRIP else p.getHandlerSwipeInAction(), outward = p.getHandlerSwipeOutAction(),
                                ))
                            },
                        )
                    }
                    if (fromOptions.isNotEmpty()) row { sh ->
                        LinkRow(
                            if (fromName != null) "All gestures follow $fromName (live)" else "All gestures: copy from another segment (live)",
                            if (fromName != null) "Tap to change" else "Pick a segment", sh,
                        ) { pickFrom = true }
                    }
                }
                if (pickFrom) PickWindow(
                    title = "Copy all gestures from",
                    hint = "Tap, double tap, long press and the swipes all follow that segment, live. Later changes there apply here too.",
                    onBack = { pickFrom = false },
                    choices = (if (seg.actFrom.isNotEmpty()) listOf("Stop following (own gestures)" to { pickFrom = false; onChange(seg.copy(actFrom = "")) }) else emptyList()) +
                        fromOptions.map { (code, name) -> name to { pickFrom = false; onChange(seg.copy(actFrom = code)) } },
                )
                if (fromName != null) {
                    Text(
                        "Every gesture of this segment follows $fromName, live. Choose \"Stop following\" to set them one by one again.",
                        fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                    )
                    return@Column
                }
                CardGroup(
                    title = "Gestures",
                    hint = "Choose per gesture: each one can follow the main slider (live), copy it once, or be its own." +
                        (if (seg.mode != Seg.MODE_ACTIONS) " Swipe up and down on the strip to change the level like the main slider does. Tap and the swipes in/out below still work." else ""),
                ) {
                    row { sh -> ActionRow("tap", "Tap", seg.tap, sh) { onChange(seg.copy(tap = it)) } }
                    row { sh -> ActionRow("double", "Double tap", seg.double, sh) { onChange(seg.copy(double = it)) } }
                    row { sh -> ActionRow("long", "Long press", seg.long, sh) { onChange(seg.copy(long = it)) } }
                    if (seg.mode == Seg.MODE_ACTIONS) {
                        row { sh -> ActionRow("up", "Swipe up", seg.up, sh) { onChange(seg.copy(up = it)) } }
                        row { sh -> ActionRow("down", "Swipe down", seg.down, sh) { onChange(seg.copy(down = it)) } }
                    }
                    row { sh -> ActionRow("in", "Swipe in", seg.inward, sh) { onChange(seg.copy(inward = it)) } }
                    row { sh -> ActionRow("out", "Swipe out", seg.outward, sh) { onChange(seg.copy(outward = it)) } }
                }
            }
        }
    }

    /** Opens the cells editor: the main slider's window, or this segment's own one. */
    private fun openCellsWindow(seg: Seg) {
        val i = android.content.Intent(this, MainActivity::class.java)
            .addFlags(android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (seg.ownWindow) i.putExtra(MainActivity.EXTRA_SCOPE, seg.id) else i.putExtra(MainActivity.EXTRA_ROUTE, "strip_editor")
        startActivity(i)
    }

    /** Replaces a segment's own window by a copy of the main slider's: cells and every "strip..." setting. Shared tools are not touched. */
    private fun copyMainWindow(id: String) {
        if (id.isEmpty()) return
        val base = StripScope.prefs(this, "")
        val c = SideConfig.load(this)
        val ids = (c.left.segs + c.right.segs).map { it.id }.filter { it.isNotEmpty() }
        val e = base.edit()
        val all = base.all
        for (k in all.keys) if (k.startsWith("strip") && k.endsWith("_$id") && k != "stripMirror_$id") e.remove(k)
        for ((k, v) in all) {
            if (!k.startsWith("strip") || ids.any { k.endsWith("_$it") }) continue
            val nk = k + "_" + id
            when (v) {
                is Boolean -> e.putBoolean(nk, v)
                is Int -> e.putInt(nk, v)
                is Long -> e.putLong(nk, v)
                is Float -> e.putFloat(nk, v)
                is String -> e.putString(nk, v)
                is Set<*> -> e.putStringSet(nk, v.filterIsInstance<String>().toSet())
            }
        }
        // The main slider never saved its cells yet: copy what it shows (the built-in list).
        if (!base.contains(StripScope.configKey(""))) e.putString(StripScope.configKey(id), StripScope.load(this, "").toJson())
        e.apply()
        OverlayRuntime.activeController?.refreshSides()
        android.widget.Toast.makeText(this, "Copied", android.widget.Toast.LENGTH_SHORT).show()
    }

    /** One gesture: its name, what it does under it, tap to pick; × clears it, ⚡ (outside fields) runs it as soon as the thumb is on it. */
    @Composable
    private fun ActionRow(
        slot: String, name: String, action: String,
        shape: androidx.compose.ui.graphics.Shape = a.a.ui.components.cardShape(0, 1),
        onPicked: (String) -> Unit,
    ) {
        val keepTouch = slot == "edge" && StripConfig.isTouch(action)
        SettingRow(
            title = name, shape = shape, modifier = Modifier.padding(vertical = 2.dp),
            summary = SidePicker.label(this@SidesActivity, action),
            onClick = {
                SidePicker.pick(this@SidesActivity, slot) { picked ->
                    onPicked(if (keepTouch) StripConfig.withTouch(picked, true) else picked)
                }
            },
            trailing = {
                if (slot == "edge" && action.isNotEmpty()) TextButton(
                    onClick = { onPicked(StripConfig.withTouch(action, !keepTouch)) },
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp),
                ) { Text(if (keepTouch) "⚡" else "○") }
                if (action.isNotEmpty()) TextButton(onClick = { onPicked("") }) { Text("×") }
            },
        )
    }
}
