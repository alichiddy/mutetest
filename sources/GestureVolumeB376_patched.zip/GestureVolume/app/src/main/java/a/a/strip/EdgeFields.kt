package a.a.strip

import android.content.Context
import android.content.SharedPreferences
import a.a.flow.FlowStore
import a.a.flow.NativePicker
import a.a.share.FilePaths
import a.a.ui.screens.strip.INTENT_ACTION_PREFIX
import a.a.utils.HandlerActionCatalog
import a.a.utils.HandlerActions
import org.json.JSONObject

/**
 * The main slider's "actions outside of the cells window": each side (Top, Left, Bottom, Right) is
 * cut into 1-6 equal fields. Field 0 keeps the old key (`stripEdge<Side>`), field i is
 * `stripEdge<Side>_<i>`; the count is `stripEdgeCnt<Side>`. A field can also keep the name and icon
 * the user gave it (`<key>Meta`), which the editor shows; the running code only needs the action.
 */
object EdgeFields {
    val SIDES = listOf("Top", "Left", "Bottom", "Right")
    const val MAX = 6

    fun key(side: String, zone: Int) = if (zone <= 0) "stripEdge$side" else "stripEdge${side}_$zone"

    fun count(sp: SharedPreferences, side: String) = sp.getInt("stripEdgeCnt$side", 1).coerceIn(1, MAX)

    fun setCount(sp: SharedPreferences, side: String, n: Int) {
        sp.edit().putInt("stripEdgeCnt$side", n.coerceIn(1, MAX)).apply()
    }

    fun action(sp: SharedPreferences, side: String, zone: Int) = sp.getString(key(side, zone), "").orEmpty()

    /** The name and icon the user gave a field: (label, icon), empty when none. */
    fun meta(sp: SharedPreferences, key: String): Pair<String, String> {
        val raw = sp.getString(key + "Meta", null) ?: return "" to ""
        return runCatching { JSONObject(raw).let { it.optString("l") to it.optString("i") } }.getOrDefault("" to "")
    }

    fun save(sp: SharedPreferences, key: String, action: String, label: String, icon: String) {
        val e = sp.edit().putString(key, action)
        if (action.isEmpty() || (label.isEmpty() && icon.isEmpty())) e.remove(key + "Meta")
        else e.putString(key + "Meta", JSONObject().put("l", label).put("i", icon).toString())
        e.apply()
    }

    fun clear(sp: SharedPreferences, key: String) = save(sp, key, "", "", "")

    // ---- Cancel gap: a band between the cells window and the outside fields; the thumb in it runs nothing ----
    // Keys (all "strip..." so they follow the window's own settings and the backup): stripCxlOn (whole idea),
    // stripCxlDp<Side> (size of that side's band, dp), stripCxl<Side>_<zone> (that field's gap is active, default yes),
    // stripCxlStyle (0 colour, 1 glow, 2 blur), stripCxlColor (ARGB).
    const val GAP_MAX_DP = 150

    fun gapOn(sp: SharedPreferences) = sp.getBoolean("stripCxlOn", false)

    /**
     * What a shown outside-action name is made of: two independent on/off buttons, "Words" and "Icon" (both on = icon + words, both off =
     * no names). Older builds saved one int, stripEdgeNamesShow (0 words only, 1 icon only, 2 icon + words); it is read until a button is touched.
     */
    fun namesWords(sp: SharedPreferences): Boolean =
        if (sp.contains("stripEdgeNamesWords")) sp.getBoolean("stripEdgeNamesWords", true) else sp.getInt("stripEdgeNamesShow", 0).coerceIn(0, 2) != 1
    fun namesIcon(sp: SharedPreferences): Boolean =
        if (sp.contains("stripEdgeNamesIcon")) sp.getBoolean("stripEdgeNamesIcon", false) else sp.getInt("stripEdgeNamesShow", 0).coerceIn(0, 2) != 0
    fun gapDp(sp: SharedPreferences, side: String) = sp.getInt("stripCxlDp$side", 24).coerceIn(0, GAP_MAX_DP)
    fun setGapDp(sp: SharedPreferences, side: String, dp: Int) { sp.edit().putInt("stripCxlDp$side", dp.coerceIn(0, GAP_MAX_DP)).apply() }
    fun gapActive(sp: SharedPreferences, side: String, zone: Int) = sp.getBoolean("stripCxl${side}_$zone", true)
    fun setGapActive(sp: SharedPreferences, side: String, zone: Int, on: Boolean) { sp.edit().putBoolean("stripCxl${side}_$zone", on).apply() }
    fun gapStyle(sp: SharedPreferences) = sp.getInt("stripCxlStyle", 2).coerceIn(0, 2)
    fun gapColor(sp: SharedPreferences) = sp.getInt("stripCxlColor", 0xFFFF3B30.toInt())

    /** The gap next to one field in dp: 0 when the idea is off or this field's gap is cancelled. */
    fun gapFor(sp: SharedPreferences, side: String, zone: Int): Int =
        if (gapOn(sp) && gapActive(sp, side, zone)) gapDp(sp, side) else 0

    /** What a field is called when its owner has not named it: the action's own name. */
    fun actionName(context: Context, b: String): String = when {
        b.isEmpty() -> "Nothing"
        b.startsWith("MyFlow:") -> "Script: " + (FlowStore.resolve(context, b.removePrefix("MyFlow:")) ?: b.removePrefix("MyFlow:"))
        b.startsWith(StripConfig.FLOW_PREFIX) -> "Automate flow " + b.removePrefix(StripConfig.FLOW_PREFIX)
        b.startsWith(INTENT_ACTION_PREFIX) -> "App shortcut"
        b.startsWith("File:") -> "Open file: " + FilePaths.nameOf(b)
        NativePicker.isNative(b) -> NativePicker.label(b)
        else -> {
            val pkg = HandlerActions.launchedPackage(b)
            if (pkg != null) runCatching {
                val pm = context.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            else HandlerActionCatalog.displayEntryFor(b)?.let { context.getString(it.labelRes) } ?: b
        }
    }

    /**
     * The name shown for a field, in the Cells window settings and on the running strip alike: the name the
     * user gave it, else the action's own name. [useMeta] is false for a segment's own outside actions (no names kept).
     */
    fun displayName(context: Context, sp: SharedPreferences, key: String, action: String, useMeta: Boolean = true): String {
        val bare = StripConfig.bare(action)
        if (bare.isEmpty()) return ""
        if (useMeta) { val ml = meta(sp, key).first; if (ml.isNotEmpty()) return ml }
        return actionName(context, bare)
    }

    /** (side, zone) of a field key made by [key]. */
    fun parse(key: String): Pair<String, Int> {
        val body = key.removePrefix("stripEdge")
        val u = body.indexOf('_')
        return if (u < 0) body to 0 else body.substring(0, u) to (body.substring(u + 1).toIntOrNull() ?: 0)
    }

    /** Keys in the order Top, Left, Bottom, Right and then along the side. */
    fun sorted(keys: Collection<String>): List<String> =
        keys.distinct().sortedWith(compareBy({ SIDES.indexOf(parse(it).first) }, { parse(it).second }))

    private class Raw(val action: String, val meta: String?)

    private fun readRaw(sp: SharedPreferences, key: String) = Raw(sp.getString(key, "").orEmpty(), sp.getString(key + "Meta", null))

    private fun put(e: SharedPreferences.Editor, key: String, r: Raw) {
        e.putString(key, r.action)
        if (r.action.isEmpty() || r.meta == null) e.remove(key + "Meta") else e.putString(key + "Meta", r.meta)
    }

    /** Two fields trade places completely: shortcut (with its touch mark), name and icon. */
    fun swap(sp: SharedPreferences, a: String, b: String) {
        if (a == b) return
        val ra = readRaw(sp, a); val rb = readRaw(sp, b)
        val e = sp.edit(); put(e, a, rb); put(e, b, ra); e.apply()
    }

    /**
     * Moves the fields [from] (any order) to the run of fields starting at [zone0] of [side], in their own order.
     * What is in the targets is replaced; a source that is not a target becomes empty. The side gets more fields
     * when the run needs them (6 at most). Returns a message when it does not fit, else null.
     */
    fun move(sp: SharedPreferences, from: Collection<String>, side: String, zone0: Int): String? {
        val src = sorted(from)
        if (src.isEmpty()) return null
        if (zone0 + src.size > MAX) return "Not enough room on $side: a side has $MAX fields at most."
        val raws = src.map { readRaw(sp, it) }
        val e = sp.edit()
        for (k in src) put(e, k, Raw("", null))
        for (i in src.indices) put(e, key(side, zone0 + i), raws[i])
        if (zone0 + src.size > count(sp, side)) e.putInt("stripEdgeCnt$side", zone0 + src.size)
        e.apply()
        return null
    }

    /** Empties every field of [keys]. */
    fun clearMany(sp: SharedPreferences, keys: Collection<String>) {
        val e = sp.edit()
        for (k in keys) put(e, k, Raw("", null))
        e.apply()
    }
}
