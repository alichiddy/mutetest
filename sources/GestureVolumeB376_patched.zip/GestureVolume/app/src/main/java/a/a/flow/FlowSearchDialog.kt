package a.a.flow

import a.a.ui.motion.TextButton
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun SearchHead(text: String) {
    Text(
        text, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
    )
}

@Composable
private fun SearchPick(label: String, on: Boolean, radio: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (radio) RadioButton(selected = on, onClick = onClick) else Checkbox(checked = on, onCheckedChange = { onClick() })
        Text(label, fontSize = 15.sp)
    }
}

/** The advanced search box: text and where to look, plus blocks and device actions picked from lists. */
@Composable
fun AdvancedSearchDialog(
    start: FlowSearch.Query,
    onApply: (FlowSearch.Query) -> Unit,
    onClear: () -> Unit,
    onClose: () -> Unit,
) {
    var text by remember { mutableStateOf(start.text) }
    var scope by remember { mutableStateOf(start.scope) }
    var all by remember { mutableStateOf(start.all) }
    var keys by remember { mutableStateOf(start.keys) }
    var find by remember { mutableStateOf("") }
    val stay = remember { FlowSearch.stayItems() }
    val other = remember { FlowSearch.otherItems() }
    val blocks = remember { FlowSearch.blockItems() }
    val actions = remember { FlowSearch.actionItems() }
    fun toggle(k: String) { keys = if (k in keys) keys - k else keys + k }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Advanced search") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    text, { text = it }, singleLine = true, label = { Text("Text to find") },
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                )
                SearchHead("Look for the text in")
                FlowSearch.SCOPES.forEach { (k, label) -> SearchPick(label, scope == k, true) { scope = k } }
                SearchHead(if (keys.isEmpty()) "Scripts that have (tick any)" else "Scripts that have (${keys.size} ticked)")
                SearchPick("Has all of the ticked ones", all, true) { all = true }
                SearchPick("Has any of the ticked ones", !all, true) { all = false }
                OutlinedTextField(
                    find, { find = it }, singleLine = true, label = { Text("Find in this list") },
                    shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                )
                SearchHead("Stays running or waits")
                stay.filter { find.isBlank() || it.label.contains(find, true) }
                    .forEach { SearchPick(it.label, it.key in keys, false) { toggle(it.key) } }
                SearchHead("Other checks")
                other.filter { find.isBlank() || it.label.contains(find, true) }
                    .forEach { SearchPick(it.label, it.key in keys, false) { toggle(it.key) } }
                SearchHead("Blocks")
                blocks.filter { find.isBlank() || it.label.contains(find, true) }
                    .forEach { SearchPick(it.label, it.key in keys, false) { toggle(it.key) } }
                SearchHead("Device actions")
                actions.filter { find.isBlank() || it.label.contains(find, true) }
                    .forEach { SearchPick(it.label, it.key in keys, false) { toggle(it.key) } }
            }
        },
        confirmButton = { TextButton(onClick = { onApply(FlowSearch.Query(text.trim(), scope, all, keys)) }) { Text("Search") } },
        dismissButton = { TextButton(onClick = onClear) { Text("Clear") } },
    )
}
