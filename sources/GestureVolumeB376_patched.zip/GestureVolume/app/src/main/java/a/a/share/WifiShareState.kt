package a.a.share

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.SecureRandom

/** What the share window shows. Written by WifiShareService, read by WifiShareActivity. */
data class ShareUi(
    val running: Boolean = false,
    val status: String = "",
    val ssid: String = "",
    val pass: String = "",
    val bandText: String = "",
    val url: String = "",
    val wifiQr: String = "",
    val files: List<String> = emptyList(),
    val served: Int = 0,
    val need: String = "",
    /** Web address on the Wi-Fi network the phone is connected to now (empty when it is not on Wi-Fi). */
    val lanUrl: String = "",
    val received: Int = 0,
    val receivedNames: List<String> = emptyList()
)

object WifiShareState {
    val ui = MutableStateFlow(ShareUi())
}

/** Name, password and band of the Wi-Fi Direct group, kept in the app's own preferences. */
object SharePrefs {
    private fun p(c: Context) = c.getSharedPreferences("wifi_share", Context.MODE_PRIVATE)

    fun ssid(c: Context): String = p(c).getString("ssid", null) ?: "DIRECT-AA-Share"

    fun pass(c: Context): String {
        val s = p(c).getString("pass", null)
        if (s != null) return s
        val n = (10000000 + SecureRandom().nextInt(90000000)).toString()
        p(c).edit().putString("pass", n).apply()
        return n
    }

    fun band(c: Context): Int = p(c).getInt("band", 5)

    /** Whether the other device may send files to this phone from the web page (default on). */
    fun upload(c: Context): Boolean = p(c).getBoolean("upload", true)

    fun saveUpload(c: Context, on: Boolean) {
        p(c).edit().putBoolean("upload", on).apply()
    }

    fun save(c: Context, ssid: String, pass: String, band: Int) {
        p(c).edit().putString("ssid", ssid).putString("pass", pass).putInt("band", band).apply()
    }

    /** Wi-Fi Direct names must start with DIRECT-xx (two letters or digits). */
    fun fixSsid(s: String): String {
        var t = s.trim()
        if (!Regex("^DIRECT-[A-Za-z0-9]{2}.*").matches(t)) t = "DIRECT-AA-$t"
        return t.take(32)
    }
}

fun sizeText(b: Long): String {
    if (b < 0) return ""
    if (b < 1024) return "$b B"
    val k = b / 1024.0
    if (k < 1024) return String.format("%.0f KB", k)
    val m = k / 1024.0
    if (m < 1024) return String.format("%.1f MB", m)
    return String.format("%.2f GB", m / 1024.0)
}
