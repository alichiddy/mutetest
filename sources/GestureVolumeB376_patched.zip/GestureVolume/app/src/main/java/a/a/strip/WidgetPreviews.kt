package a.a.strip

import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.LayoutInflater
import android.view.View

/**
 * The pictures the widget picker shows: the app's icon, and what the widget looks like (the picture the widget's own
 * app made for the launcher's widget list, or, on Android 12 and later, its preview layout drawn once).
 * Nothing here keeps anything: the picker holds the pictures while it is open and lets go of them when it closes.
 */
object WidgetPreviews {
    /** The longest side of a picture, in pixels. */
    private const val MAX_PX = 640

    private fun toBitmap(d: Drawable, maxPx: Int): Bitmap? = runCatching {
        var w = d.intrinsicWidth
        var h = d.intrinsicHeight
        if (w <= 0 || h <= 0) { w = maxPx; h = maxPx }
        val k = minOf(1f, maxPx.toFloat() / maxOf(w, h))
        val bw = (w * k).toInt().coerceAtLeast(1)
        val bh = (h * k).toInt().coerceAtLeast(1)
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh)
        d.draw(Canvas(b))
        b
    }.getOrNull()

    /** The icon of the widget's app. Safe to call off the main thread. */
    fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
        toBitmap(ctx.packageManager.getApplicationIcon(pkg), 144)
    }.getOrNull()

    /** The picture the widget's app made of it, or null when it made none. Safe to call off the main thread. */
    fun image(ctx: Context, info: AppWidgetProviderInfo): Bitmap? = runCatching {
        info.loadPreviewImage(ctx, 0)?.let { toBitmap(it, MAX_PX) }
    }.getOrNull()

    /** Android 12 and later: the widget's preview layout drawn into a picture (call on the main thread), or null. */
    fun layoutImage(ctx: Context, info: AppWidgetProviderInfo): Bitmap? {
        if (Build.VERSION.SDK_INT < 31) return null
        return runCatching {
            val res = info.previewLayout
            if (res == 0) return@runCatching null
            val pctx = ctx.createPackageContext(info.provider.packageName, 0)
            val v = LayoutInflater.from(pctx).inflate(res, null)
            val dm = ctx.resources.displayMetrics
            val wPx = (if (info.targetCellWidth > 0) (info.targetCellWidth * 70 - 30) * dm.density else info.minWidth.toFloat()).toInt().coerceIn(64, 900)
            val hPx = (if (info.targetCellHeight > 0) (info.targetCellHeight * 70 - 30) * dm.density else info.minHeight.toFloat()).toInt().coerceIn(48, 900)
            v.measure(View.MeasureSpec.makeMeasureSpec(wPx, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(hPx, View.MeasureSpec.EXACTLY))
            v.layout(0, 0, wPx, hPx)
            val k = minOf(1f, MAX_PX.toFloat() / maxOf(wPx, hPx))
            val b = Bitmap.createBitmap((wPx * k).toInt().coerceAtLeast(1), (hPx * k).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.scale(k, k)
            v.draw(c)
            b
        }.getOrNull()
    }

    /** "2×2 cells · 110×110 dp", the size the widget asks for. */
    fun sizeText(ctx: Context, info: AppWidgetProviderInfo): String {
        val d = ctx.resources.displayMetrics.density
        val wDp = (info.minWidth / d).toInt()
        val hDp = (info.minHeight / d).toInt()
        val cw = if (Build.VERSION.SDK_INT >= 31 && info.targetCellWidth > 0) info.targetCellWidth else ((wDp + 30) / 70).coerceAtLeast(1)
        val ch = if (Build.VERSION.SDK_INT >= 31 && info.targetCellHeight > 0) info.targetCellHeight else ((hDp + 30) / 70).coerceAtLeast(1)
        return "$cw×$ch cells · $wDp×$hDp dp"
    }
}
