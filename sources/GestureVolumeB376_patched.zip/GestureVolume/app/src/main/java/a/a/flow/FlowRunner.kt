package a.a.flow

import android.content.Context
import android.content.Intent
import android.net.Uri
import a.a.utils.ShizukuShell
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Runs a flow on its own thread and is gone when it ends. [log] gets one line per thing that
 * happens, [message] is where a Message step shows its text. [trace] (the canvas) hears which
 * block is running, finished or failed; [startAt] runs from a chosen block.
 */
object FlowRunner {
    /** One running script. Everything it starts (scripts inside it, blocks at the same time) shares it. */
    class Run(val id: Long, val name: String, val since: Long, val alwaysOn: Boolean) {
        @Volatile var stopped = false
        @Volatile var thread: Thread? = null
        /** What the script waits for right now ("Waiting for: Slide in"), or "" when it is not waiting. */
        @Volatile var waitingFor: String = ""
    }

    /** What the Scripts window and the notifications need to know about a running script. */
    data class RunInfo(
        val id: Long, val name: String, val since: Long, val alwaysOn: Boolean,
        /** "Waiting for: Slide in" for a script that waits at a When block, or listens for one; "" otherwise. */
        val waiting: String = "",
        /** True for a script that is not running a thread but listens for an event (a When block that starts it). */
        val listening: Boolean = false,
    )

    private val runs = ConcurrentHashMap<Long, Run>()
    private val nextId = java.util.concurrent.atomic.AtomicLong(1)

    fun running(): List<RunInfo> = runs.values.map { RunInfo(it.id, it.name, it.since, it.alwaysOn, it.waitingFor) }.sortedBy { it.since }

    /**
     * Everything the Scripts window counts as running: the scripts that run now, plus the scripts that listen in the
     * background for the event of a When block that starts them (they are armed and really waiting, though no thread
     * runs). Nothing is polled for this: the list is worked out from the saved scripts only when the window asks.
     */
    fun runningAll(context: Context): List<RunInfo> {
        val real = running()
        val have = real.map { it.name }.toSet()
        val extra = WhenEvents.listening(context).filter { it.key !in have }.map { (n, what) ->
            RunInfo(-(Math.abs(n.hashCode().toLong()) + 1L), n, 0L, false, "Waiting for: $what", listening = true)
        }
        return real + extra
    }

    /** Stops a script completely: its running copies, and its background listening (it stays off until started again). */
    fun stopScript(context: Context, name: String) {
        stopByName(name)
        WhenEvents.pause(context, name, true)
    }

    /** Stops every running script and every background listener. */
    fun stopEverything(context: Context) {
        stopAllRuns()
        WhenEvents.pauseAll(context)
    }
    fun isRunning(id: Long): Boolean = runs.containsKey(id)

    private fun halt(r: Run) {
        r.stopped = true
        // A wait inside a block ends at once; the flag stops everything else between blocks.
        r.thread?.interrupt()
    }

    /** Stops one running script (its id comes from [running]). */
    fun stop(id: Long) { runs[id]?.let { halt(it) } }

    /** Stops every run of the script with this name. */
    fun stopByName(name: String) { runs.values.filter { it.name == name }.forEach { halt(it) } }

    /** Stops all running scripts, or only the ones marked "Always On". */
    fun stopAllRuns(alwaysOnOnly: Boolean = false) {
        runs.values.filter { !alwaysOnOnly || it.alwaysOn }.forEach { halt(it) }
    }

    fun stop() = stopAllRuns()

    fun run(
        context: Context, name: String, log: (String) -> Unit,
        message: (String) -> Unit = {}, vars: MutableMap<String, String> = HashMap(), depth: Int = 0,
        trace: ((Int, Int, String) -> Unit)? = null, startAt: Int = 0, token: Run? = null,
    ) {
        val own = token == null && depth == 0
        val tk = token ?: if (depth == 0) {
            Run(nextId.getAndIncrement(), name, System.currentTimeMillis(), FlowPrefs.isAlwaysOn(context, name))
        } else Run(0L, name, 0L, false)
        if (own) {
            tk.thread = Thread.currentThread()
            runs[tk.id] = tk
            RunningNotes.started(context, tk)
            FlowMeta.ran(context, FlowStore.idOf(context, FlowStore.resolve(context, name) ?: name))
        }
        if (depth == 0) {
            // Personal values (keys, codes) are filled in as {name}; flow variables of the same name win.
            PrivateValues.all(context).forEach { (k, v) -> vars.putIfAbsent(k, v) }
        }
        try {
            // A "goto" Run step hands over to another flow without growing the stack (loops, joins).
            var cur = name
            var hops = 0
            while (true) {
                val next = runOnce(
                    context, cur, log, message, vars, depth, tk,
                    if (hops == 0) trace else null, if (hops == 0) startAt else 0,
                ) ?: return
                if (tk.stopped || ++hops > 20_000) return
                cur = next
            }
        } finally {
            if (own) {
                runs.remove(tk.id)
                tk.thread = null
                Thread.interrupted()   // a stop that arrived between two waits must not leak into the next job of this thread
                RunningNotes.ended(context, tk)
            }
        }
    }

    private fun runOnce(
        context: Context, name: String, logFn: (String) -> Unit,
        message: (String) -> Unit, vars: MutableMap<String, String>, depth: Int, tk: Run,
        traceFn: ((Int, Int, String) -> Unit)?, startAt: Int,
    ): String? {
        if (depth > 8) { logFn("Too many flows inside flows."); return null }
        val graph = FlowStore.loadGraph(context, name)
        if (graph.none { it.type != Step.BEGIN }) { logFn("Flow '$name' is empty or missing."); return null }
        // Blocks that run at the same time share the variables.
        val shared = ConcurrentHashMap<String, String>(vars)
        fun sub(t: String): String {
            var r = t
            shared.forEach { (k, v) -> r = r.replace("{$k}", v) }
            return r
        }
        val env = object : FlowEnv {
            override fun stopped() = tk.stopped

            override fun trace(id: Int, state: Int, msg: String) {
                if (traceFn == null) return
                traceFn(id, state, msg)
                // On the canvas, give each block a moment so the highlight can be seen.
                if (state == Interpreter.RUNNING) {
                    try { Thread.sleep(220) } catch (_: InterruptedException) { }
                }
            }

            override fun log(text: String) = logFn(text)

            override fun decide(s: Step, vars: MutableMap<String, String>): Boolean =
                if (s.type == Step.ONLYIF) a.a.strip.WhenRules.holdsNow(context, s.a, sub(s.b).trim())
                else if (s.b == "expr") Expr.truth(evalExpr(context, s.a, vars)) else test(sub(s.a), s.b, sub(s.c))

            override fun items(s: Step, vars: MutableMap<String, String>): List<String>? =
                Expr.asList(evalExpr(context, s.a, vars))?.map { Expr.text(it) }

            override fun count(s: Step, vars: MutableMap<String, String>): Int = sub(s.a).toIntOrNull() ?: 1

            override fun gotoTarget(s: Step, vars: MutableMap<String, String>): String = sub(s.a)

            override fun failed(s: Step, e: Throwable) {
                if (tk.stopped) { log("Stopped"); return }
                if (e is NativeActions.NeedsShizuku) {
                    // Not an error: say what is missing and take the user to Shizuku.
                    message(e.message ?: "This needs Shizuku.")
                    log(e.message ?: "This needs Shizuku.")
                    NativeActions.openShizuku(context)
                } else {
                    val text = e.message ?: e.javaClass.simpleName
                    log("Failed (${s.describe()}): $text")
                    message(text)
                }
            }

            override fun exec(s: Step, vars: MutableMap<String, String>, last: Boolean) {
                when (s.type) {
                    Step.SHELL -> {
                        val out = StringBuilder()
                        val code = ShizukuShell.run(sub(s.a)) { line -> out.append(line).append('\n'); log(line) }
                        vars["code"] = code.toString()
                        vars[s.b.ifEmpty { "out" }] = out.toString().trim()
                    }
                    Step.WAIT -> Thread.sleep((if (s.c == "expr") Expr.num(evalExpr(context, s.a, vars)).toLong() else sub(s.a).toDoubleOrNull()?.toLong() ?: 0L).coerceAtLeast(0L))
                    Step.MESSAGE -> {
                        val text = sub(s.a)
                        log(text)
                        when (s.c) {
                            "window" -> ResultActivity.show(context, name, text)
                            "toast" -> android.os.Handler(android.os.Looper.getMainLooper()).post {
                                android.widget.Toast.makeText(context.applicationContext, text, android.widget.Toast.LENGTH_LONG).show()
                            }
                            else -> if (FlowPrefs.mode(context) != FlowPrefs.NEVER) message(text)
                        }
                    }
                    Step.LAUNCH -> if (s.b.isNotEmpty()) {
                        // Open it without an animation, wait, then go back to where the person was.
                        if (!a.a.strip.WidgetFloat.openThenBack(context, sub(s.a).trim(), s.b.toIntOrNull() ?: 1500, sub(s.c).trim())) log("App not found: ${s.a}")
                    } else if (s.c.isNotBlank()) {
                        // An exact activity (package + class), for example one particular home screen.
                        val pkg = sub(s.a).trim()
                        a.a.utils.AppStarter.start(context, exactIntent(pkg, sub(s.c).trim()))
                    } else context.packageManager.getLaunchIntentForPackage(sub(s.a).trim())
                        ?.let { a.a.utils.AppStarter.start(context, it) }
                        ?: log("App not found: ${s.a}")
                    Step.INTENT -> a.a.utils.AppStarter.start(
                        context,
                        a.a.utils.AppStarter.parse(sub(s.a))
                    )
                    Step.SET -> vars[s.a] = if (s.c == "expr") Expr.text(evalExpr(context, s.b, vars)) else sub(s.b)
                    Step.HTTP -> {
                        val c = URL(sub(s.a)).openConnection() as HttpURLConnection
                        c.requestMethod = s.b.ifEmpty { "GET" }
                        c.connectTimeout = 15000; c.readTimeout = 30000
                        val text = (if (c.responseCode < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                        vars["status"] = c.responseCode.toString()
                        vars[s.c.ifEmpty { "answer" }] = text
                        c.disconnect()
                    }
                    Step.RUN -> if (s.b == "async") {
                        val copy = HashMap(vars); val target = sub(s.a)
                        Thread { run(context, target, logFn, message, copy, depth + 1, token = tk) }.start()
                    } else run(context, sub(s.a), logFn, message, vars, depth + 1, token = tk)
                    Step.ACTION -> {
                        try {
                            val result = NativeActions.run(context, s.a, sub(s.b), vars)
                            if (result.isNotBlank()) {
                                log(result)
                                if (NativeActions.staysOnScreen(s.a, result)) ResultActivity.show(context, name, result)
                                else if (FlowPrefs.mode(context) == FlowPrefs.ALWAYS && last) message(result)
                            }
                        } catch (e: NativeActions.NeedsShizuku) {
                            if (s.c != "optional") throw e
                            log("Skipped (needs Shizuku): ${s.a}")
                        }
                    }
                    Step.SHIZUKU -> {
                        if (s.c == "optional" && !ShizukuShell.isReady()) {
                            log("Skipped (needs Shizuku): ${s.a}")
                        } else {
                            val (code, out) = NativeActions.sh(sub(s.a))
                            vars["code"] = code.toString()
                            vars[s.b.ifEmpty { "out" }] = out
                            if (out.isNotBlank()) log(out.lines().last())
                        }
                    }
                    Step.OCRWAIT -> {
                        val res = a.a.strip.ScreenOcr.waitRead(
                            context, sub(s.a), s.b.ifEmpty { "digits" }, s.c.toIntOrNull() ?: 40000,
                            digitCount = sub(s.e).trim().toIntOrNull() ?: 0,
                            ignore = sub(s.f).split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() },
                        ) { tk.stopped }
                        vars[s.d.ifEmpty { "ocr" }] = res
                        vars["ocr_found"] = if (res.isNotEmpty()) "yes" else "no"
                        log(if (res.isNotEmpty()) "OCR read: $res" else "OCR read nothing in time")
                    }
                    Step.COUNTDOWN -> {
                        val opts = Countdown.Opts(s.c.ifEmpty { "bar" }, s.d.toIntOrNull() ?: 80, sub(s.e), s.f.ifEmpty { "join" })
                        if (!Countdown.show(context, sub(s.b).ifEmpty { "Wait" }, sub(s.a).toLongOrNull() ?: 0L, opts) { tk.stopped }) {
                            log("A countdown with this name is already running: this run stops")
                            vars["__stop__"] = "1"
                        }
                    }
                    Step.FIELDWAIT -> {
                        val ok = a.a.strip.ScreenOcr.waitField(context, sub(s.a).toIntOrNull() ?: 30000) { tk.stopped }
                        vars["field_found"] = if (ok) "yes" else "no"
                        log(if (ok) "A field with the cursor is there" else "No field with the cursor in time")
                    }
                    Step.RATELIMIT -> {
                        val key = sub(s.a).ifEmpty { "limit" }
                        val gap = sub(s.b).toLongOrNull() ?: 120000L
                        val label = sub(s.d).ifEmpty { "Wait" }
                        val limitOpts = Countdown.Opts(s.e.ifEmpty { "bar" }, s.f.toIntOrNull() ?: 80, "limit:" + key, "join")
                        val sp = context.getSharedPreferences("flow_limits", Context.MODE_PRIVATE)
                        val now = System.currentTimeMillis()
                        val last = sp.getLong(key, 0L)
                        val left = last + gap - now
                        if (left > 0 && last <= now) {
                            when (s.c) {
                                "stop" -> { log("Too soon ($key): stopped"); vars["__stop__"] = "1" }
                                "wait" -> {
                                    Countdown.show(context, label, left, limitOpts) { tk.stopped }
                                    sp.edit().putLong(key, System.currentTimeMillis()).apply()
                                }
                                else -> { Countdown.show(context, label, left, limitOpts) { tk.stopped }; vars["__stop__"] = "1" }
                            }
                        } else sp.edit().putLong(key, now).apply()
                    }
                    Step.WHEN -> {
                        if (vars.remove("__when_start__") == s.id.toString()) {
                            // The script was started by this block's own event: there is nothing to wait for.
                            vars["when_found"] = "yes"
                            log("Started by: " + WhenEvents.eventLabel(s.a, s.d))
                        } else if (s.b != WhenEvents.MODE_START && s.b.isNotEmpty()) {
                            log("Waiting for: " + WhenEvents.eventLabel(s.a, s.d))
                            tk.waitingFor = "Waiting for: " + WhenEvents.eventLabel(s.a, s.d)
                            val got = try {
                                WhenEvents.await(s.a, s.c, s.e.trim().toLongOrNull() ?: 0L, WhenEvents.fromOf(s.f))
                            } finally { tk.waitingFor = "" }
                            vars["when_found"] = if (got) "yes" else "no"
                            log(if (got) "It happened" else "It did not happen in time")
                        }
                    }
                    Step.SHORTCUT -> {
                        // The same shortcuts a cell of the Cells window runs: an app's own shortcut, or a built-in one.
                        val act = sub(s.a).trim()
                        val shown = s.b.ifEmpty { act.take(40) }
                        if (act.isEmpty()) {
                            log("No shortcut chosen")
                        } else if (act.startsWith("Intent:") || act.startsWith("intent:")) {
                            val ok = a.a.utils.AppStarter.start(context, a.a.utils.AppStarter.parse(act))
                            if (!ok) throw IllegalStateException(a.a.utils.AppStarter.lastFailure ?: "This shortcut is not available on this device")
                            log("Ran app shortcut: $shown")
                        } else {
                            val controller = a.a.service.OverlayRuntime.activeController ?: throw IllegalStateException("Turn A on first.")
                            controller.runStripItem(a.a.strip.StripItem(shown, "", act))
                            log("Ran built-in shortcut: $shown")
                        }
                        val extra = sub(s.d).trim().toLongOrNull() ?: 0L
                        if (extra > 0L) Thread.sleep(extra)
                    }
                    Step.BROADCAST -> {
                        val target = sub(s.a)
                        val intent = Intent(sub(s.b))
                        if (target.contains("/")) {
                            val pkg = target.substringBefore("/")
                            val cls = target.substringAfter("/").let { if (it.startsWith(".")) pkg + it else it }
                            intent.setClassName(pkg, cls)
                        } else if (target.isNotEmpty()) intent.setPackage(target)
                        sub(s.c).split(";").filter { it.contains("=") }.forEach {
                            intent.putExtra(it.substringBefore("=").trim(), it.substringAfter("=").trim())
                        }
                        intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                        context.sendBroadcast(intent)
                        log("Broadcast sent to $target")
                    }
                    else -> {}
                }
            }
        }
        try {
            return Interpreter(graph, env, shared).run(startAt)
        } finally {
            vars.putAll(shared)
        }
    }

    private fun test(left: String, op: String, right: String): Boolean {
        val l = left.toDoubleOrNull(); val r = right.toDoubleOrNull()
        return when (op) {
            "=" -> if (l != null && r != null) l == r else left == right
            "!=" -> if (l != null && r != null) l != r else left != right
            "contains" -> left.contains(right)
            "!contains" -> !left.contains(right)
            ">" -> l != null && r != null && l > r
            "<" -> l != null && r != null && l < r
            ">=" -> l != null && r != null && l >= r
            "<=" -> l != null && r != null && l <= r
            else -> false
        }
    }

    /** Expression with {name} texts filled in first, plus checks such as is("wifi"). */
    private fun evalExpr(context: Context, text: String, vars: MutableMap<String, String>): Any? =
        Expr.eval(text, vars) { name, args -> NativeActions.check(context, name, args.map { Expr.text(it) }) }
}
