package a.a.flow

/**
 * What a device action wants as its argument, as choices to tap instead of text to type.
 * The stored argument stays the same short text it always was ("4g5g", "music:50"), so existing
 * cells and flows keep working.
 */
object ActionArgs {
    sealed class Spec
    /** One of a few fixed values: (label, stored value). */
    class Choices(val options: List<Pair<String, String>>, val default: String = "") : Spec()
    /** A stream and a percent, stored as "stream:percent". */
    object StreamPercent : Spec()

    val STREAMS = listOf("Media" to "music", "Ringtone" to "ring", "Alarm" to "alarm", "Notifications" to "notification")
    val PERCENTS = (0..100 step 10).map { "$it%" to "$it" }

    fun specFor(id: String, ctx: android.content.Context? = null): Spec? = when (id) {
        "netmode" -> Choices(
            listOf(
                "2G only" to "2g", "2G + 3G" to "2g3g", "4G (LTE)" to "4g",
                "4G + 5G" to "4g5g", "5G only" to "5g", "All networks (auto)" to "all",
            ), default = "all",
        )
        "brightness_toggle" -> Choices(listOf("25%" to "64", "50%" to "128", "75%" to "192", "100%" to "255"), default = "255")
        "volume_max" -> Choices(STREAMS, default = "music")
        "volume_set" -> StreamPercent
        "install_existing" -> Choices(
            listOf("Second space (999)" to "999", "Work profile (10)" to "10", "User 11" to "11", "Owner (0)" to "0"), default = "999",
        )
        "ocr_area" -> {
            // The saved boxes come from the OCR screen, so the list needs a context to name them.
            val names = if (ctx != null) a.a.strip.ScreenOcr.boxNames(ctx) else emptyList()
            val list = ArrayList<Pair<String, String>>()
            for ((verb, mode) in listOf("Copy it" to "copy", "Copy it and type it into the field with the cursor" to "type")) {
                for (n in names) list.add("$verb: box $n" to "$mode:box:$n")
                list.add("$verb: selected widget" to "$mode:widget")
                list.add("$verb: widget on screen now" to "$mode:widgetnow")
                list.add("$verb: USSD screen" to "$mode:ussd")
            }
            Choices(list, default = list.firstOrNull()?.second ?: "copy:widget")
        }
        "rotation" -> Choices(
            listOf(
                "Automatic (unlock)" to "auto", "Lock / unlock (toggle)" to "toggle", "Portrait" to "portrait",
                "Landscape" to "landscape", "Portrait upside down" to "portrait-reverse", "Landscape reversed" to "landscape-reverse",
            ), default = "portrait",
        )
        "ringer" -> Choices(
            listOf(
                "Sound" to "sound", "Vibrate" to "vibrate", "Silent" to "silent",
                "Sound / vibrate (switch between)" to "sound-vibrate", "Sound / silent (switch between)" to "sound-silent",
            ), default = "sound-vibrate",
        )
        "lensnet" -> Choices(listOf("Prepare" to "prep", "Turn on" to "on"), default = "on")
        "bgshell" -> Choices(listOf("Copy and upload" to "upload", "Run only" to "plain"), default = "upload")
        else -> null
    }

    /** The argument in words, for lists and block titles. */
    fun label(id: String, arg: String): String {
        if (arg.isEmpty()) return ""
        if (id == "ocr_area") ocrLabel(arg)?.let { return it }
        return when (val s = specFor(id)) {
            is Choices -> s.options.firstOrNull { it.second == arg }?.first ?: arg
            StreamPercent -> {
                val st = arg.substringBefore(':', "music")
                val pct = arg.substringAfter(':', "")
                (STREAMS.firstOrNull { it.second == st }?.first ?: st) + if (pct.isNotEmpty()) " $pct%" else ""
            }
            null -> arg
        }
    }

    /** Boxes and the older ask-when-it-runs values, in words. Null for the rest (widget, USSD). */
    private fun ocrLabel(arg: String): String? {
        val verb = if (arg.startsWith("type")) "Copy it and type it into the field with the cursor" else "Copy it"
        return when {
            arg.contains(":box:") -> "$verb: box " + arg.substringAfter(":box:")
            arg == "copy" || arg == "type" -> "$verb: part of the screen, chosen when it runs"
            arg.endsWith(":region") -> "$verb: the last saved part of the screen"
            else -> null
        }
    }
}
