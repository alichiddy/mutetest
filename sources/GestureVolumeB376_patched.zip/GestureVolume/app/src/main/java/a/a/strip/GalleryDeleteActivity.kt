package a.a.strip

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast

/**
 * Deletes the photos ticked in the floating gallery. A see-through screen that stays only until the work is done.
 * Android 11 and later: the system's own delete question (MediaStore.createDeleteRequest). With All files access:
 * a plain delete, no question. Android 10: a plain delete, and the system's question for a photo that belongs to
 * another app. The gallery is told which photos are gone (GalleryBridge) so it can refresh.
 */
class GalleryDeleteActivity : Activity() {
    private var ids = LongArray(0)
    private val queue = ArrayList<Long>()
    private val gone = ArrayList<Long>()
    private var waiting: Long = -1L

    private fun uri(id: Long): Uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ids = intent.getLongArrayExtra("ids") ?: LongArray(0)
        if (ids.isEmpty()) { done(); return }
        val allFiles = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()
        if (allFiles || Build.VERSION.SDK_INT < 29) {
            Thread {
                val ok = ids.filter { runCatching { contentResolver.delete(uri(it), null, null) > 0 }.getOrDefault(false) }
                runOnUiThread { gone.addAll(ok); done() }
            }.start()
        } else if (Build.VERSION.SDK_INT >= 30) {
            val ok = runCatching {
                val pi = MediaStore.createDeleteRequest(contentResolver, ids.map { uri(it) })
                startIntentSenderForResult(pi.intentSender, REQ, null, 0, 0, 0)
            }.isSuccess
            if (!ok) done()
        } else {
            queue.addAll(ids.toList())
            next()
        }
    }

    /** Android 10: one photo at a time; a photo of another app asks the system first. */
    private fun next() {
        while (queue.isNotEmpty()) {
            val id = queue.removeAt(0)
            try {
                if (contentResolver.delete(uri(id), null, null) > 0) gone.add(id)
            } catch (e: RecoverableSecurityException) {
                waiting = id
                runCatching { startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ, null, 0, 0, 0) }
                    .onFailure { waiting = -1L }
                if (waiting != -1L) return
            } catch (_: Throwable) {
            }
        }
        done()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ) return
        if (Build.VERSION.SDK_INT >= 30) {
            if (resultCode == RESULT_OK) gone.addAll(ids.toList())
            done()
        } else {
            if (resultCode == RESULT_OK && waiting != -1L) gone.add(waiting)
            waiting = -1L
            next()
        }
    }

    private fun done() {
        val app = applicationContext
        if (gone.isNotEmpty()) GalleryBridge.onDeleted?.invoke(gone.toList())
        Toast.makeText(
            app,
            if (gone.isEmpty()) "Nothing was deleted" else if (gone.size == 1) "1 photo deleted" else "${gone.size} photos deleted",
            Toast.LENGTH_SHORT,
        ).show()
        finish()
    }

    private companion object { const val REQ = 41 }
}
