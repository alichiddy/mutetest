package a.a.ui.screens.shell

import android.hardware.usb.UsbDevice
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import a.a.adb.AdbConnection
import a.a.adb.AdbOtg
import a.a.ui.motion.Button
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.LinkRow
import a.a.ui.screens.strip.SettingRow

/** Pick a device plugged into the OTG cable and connect to it; or disconnect from the current one. */
@Composable
fun OtgDialog(
    connectedName: String?,
    onConnected: (AdbConnection) -> Unit,
    onDisconnect: () -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var devices by remember { mutableStateOf(AdbOtg.devices(ctx)) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun connect(d: UsbDevice) {
        if (busy) return
        busy = true
        status = "Allow USB access in the Android window..."
        AdbOtg.requestPermission(ctx, d) { granted ->
            if (!granted) {
                status = "USB access was not allowed."
                busy = false
            } else {
                status = "Connecting..."
                Thread {
                    var conn: AdbConnection? = null
                    try {
                        val t = AdbOtg.open(ctx, d)
                        val c = AdbConnection(ctx, t)
                        conn = c
                        c.connect { status = "On the other device: tick Always allow, then tap Allow." }
                        onConnected(c)
                        status = "Connected."
                    } catch (e: Throwable) {
                        conn?.close()
                        status = "Could not connect: " + (e.message ?: e.javaClass.simpleName)
                    }
                    busy = false
                }.start()
            }
        }
    }

    ShellWindow(title = "OTG device", onBack = onDismiss) {
        CardGroup(
            title = "How to connect",
            hint = "Plug the other device into this phone with an OTG cable. On that device turn on USB debugging (Developer options).",
        ) {
            if (connectedName != null) {
                row { sh ->
                    SettingRow(title = "Connected to", shape = sh, icon = Icons.Filled.Check, lit = true, summary = connectedName)
                }
                row { sh ->
                    LinkRow(
                        title = "Disconnect", summary = "Run on this phone again", shape = sh, icon = Icons.Filled.Terminal,
                    ) { onDisconnect(); onDismiss() }
                }
            }
            if (status.isNotEmpty()) row { sh ->
                SettingRow(title = "What is happening", shape = sh, icon = Icons.Filled.Info, summary = status)
            }
            row { sh ->
                LinkRow(
                    title = "Refresh", summary = "Look for plugged-in devices again", shape = sh, icon = Icons.Filled.Refresh,
                ) { devices = AdbOtg.devices(ctx) }
            }
        }
        CardGroup(title = "Devices found") {
            if (devices.isEmpty()) row { sh ->
                SettingRow(
                    title = "No USB device found", shape = sh, icon = Icons.Filled.Terminal,
                    summary = "Plug it in, then press Refresh.",
                )
            }
            for (d in devices) {
                row { sh ->
                    val usable = !busy && AdbOtg.isAdb(d)
                    SettingRow(
                        title = AdbOtg.label(d), shape = sh, icon = Icons.Filled.Terminal,
                        summary = if (AdbOtg.isAdb(d)) "Ready to connect" else "No debugging interface found",
                        trailing = { Button(enabled = usable, onClick = { connect(d) }) { Text("Connect") } },
                    )
                }
            }
        }
    }
}

/** Where on the other device the pushed files go; the file picker opens after Choose. */
@Composable
fun PushDialog(dir: String, onDismiss: () -> Unit, onChoose: (String) -> Unit) {
    var d by remember { mutableStateOf(dir) }
    ShellWindow(title = "Push files to the other device", onBack = onDismiss) {
        CardGroup(title = "Where they go", hint = "The folder is made on the other device if it is missing.") {
            row { sh ->
                SettingRow(
                    title = "Folder on the other device", shape = sh, icon = Icons.Filled.Download,
                    footer = {
                        OutlinedTextField(
                            value = d, onValueChange = { d = it }, singleLine = true,
                            modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
                        )
                    },
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(enabled = d.isNotBlank(), onClick = { onChoose(d.trim()) }, modifier = Modifier.fillMaxWidth()) {
            Text("Choose files and push")
        }
    }
}
