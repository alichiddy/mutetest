package a.a.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import a.a.R
import a.a.ui.components.CardWindow
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow

/** The light / dark choice in the card design: one row per choice with a round mark, Confirm under it (back arrow = Cancel). */
@Composable
fun ThemeDialog(
    currentTheme: Int,
    onDismiss: () -> Unit,
    onThemeSelect: (Int) -> Unit
) {
    val options: List<Int> = listOf(
        R.string.system_default,
        R.string.light,
        R.string.dark
    )
    var selectedOption by remember { mutableStateOf(currentTheme) }

    CardWindow(title = stringResource(R.string.choose_theme), onBack = onDismiss) {
        CardGroup(title = "Pick one") {
            options.forEachIndexed { index, resId ->
                row { sh ->
                    SettingRow(
                        title = stringResource(resId), shape = sh,
                        onClick = { selectedOption = index },
                        trailing = { RadioButton(selected = index == selectedOption, onClick = null) },
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.cancel)) }
            Button(
                onClick = {
                    onThemeSelect(selectedOption)
                    onDismiss()
                },
                modifier = Modifier.weight(1f),
            ) { Text(stringResource(R.string.confirm)) }
        }
    }
}
