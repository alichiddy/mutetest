package a.a.auto

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import a.a.ui.motion.IconButton
import a.a.ui.motion.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import a.a.flow.FlowStore
import a.a.ui.components.AWindowPage
import a.a.ui.components.GroupHeading
import a.a.ui.components.cardShape
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.ChipsRow
import a.a.ui.screens.strip.SettingRow

/**
 * Rules like "when a text arrives, run CopyOTP". Rules run only while the A service is on
 * (the app-opened rule) or the app is installed (text rule works even when A is off).
 */
@Composable
fun AutomationsScreen(close: () -> Unit) {
    val c = LocalContext.current
    val rules = remember { mutableStateListOf<AutoRule>().apply { addAll(AutoStore.load(c)) } }
    var adding by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    fun persist() { AutoStore.save(c, rules.toList()); Automations.start(c) }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        info = if (ok) "Text permission allowed." else "Text permission refused. Use Grant permissions (Shizuku) or allow it in Android settings."
    }
    BackHandler(onBack = close)
    AWindowPage("Automations", onBack = close) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            item {
                Text(
                    "When something happens, run one of your scripts. Turn A off and on once after adding the first rule.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 6.dp),
                )
            }
            if (info.isNotEmpty()) item {
                Box(
                    Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer).padding(12.dp),
                ) { Text(info, fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            item {
                Column {
                    CardGroup("Add") {
                        row { sh ->
                            SettingRow(
                                "Add rule", sh, icon = Icons.Filled.Add,
                                summary = "Choose what happens and which script to run",
                                onClick = { adding = true },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                "Copy OTP from texts", sh, icon = Icons.Filled.Notifications,
                                summary = "A text arrives, then the script CopyOTP runs",
                                onClick = {
                                    AutoStore.ensureFlows(c)
                                    if (rules.none { it.trigger == AutoTriggers.SMS && it.flow == "CopyOTP" }) rules.add(AutoRule(AutoTriggers.SMS, "", "CopyOTP"))
                                    persist()
                                    info = "Added: text arrives → CopyOTP. Allow text reading below if you have not."
                                },
                            )
                        }
                    }
                    CardGroup("Permissions") {
                        row { sh ->
                            SettingRow(
                                "Allow reading texts", sh, icon = Icons.Filled.Lock,
                                summary = "Needed by the rule that reads a text",
                                onClick = {
                                    if (c.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) info = "Text permission is already allowed."
                                    else smsPerm.launch(Manifest.permission.RECEIVE_SMS)
                                },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                "Allow usage access", sh, icon = Icons.Filled.Check,
                                summary = "Opens Android's setting that lets A see which app is open",
                                onClick = { runCatching { c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                            )
                        }
                    }
                }
            }
            item {
                GroupHeading(
                    "Your rules (${rules.size})",
                    modifier = Modifier.padding(top = 14.dp),
                    hint = if (rules.isEmpty()) "No rules yet. Tap Add rule." else "Tap a rule to turn it on or off.",
                )
            }
            itemsIndexed(rules) { i, r ->
                SettingRow(
                    AutoTriggers.label(r.trigger) + if (r.arg.isNotBlank()) ": ${r.arg}" else "",
                    cardShape(i, rules.size), icon = Icons.Filled.Notifications, lit = r.enabled,
                    summary = "Runs ${r.flow}",
                    onClick = { rules[i] = r.copy(enabled = !r.enabled); persist() },
                    trailing = {
                        Switch(r.enabled, null)
                        IconButton(onClick = { rules.removeAt(i); persist() }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete this rule")
                        }
                    },
                )
            }
        }
    }
    if (adding) {
        var trig by remember { mutableStateOf(AutoTriggers.SMS) }
        var arg by remember { mutableStateOf("") }
        var flow by remember { mutableStateOf("") }
        val flows = remember { FlowStore.names(c) }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New rule") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChipsRow("When", AutoTriggers.all.map { AutoTriggers.label(it) to (it == trig) }) { trig = AutoTriggers.all[it] }
                    if (AutoTriggers.argHint(trig).isNotEmpty())
                        OutlinedTextField(
                            arg, { arg = it }, label = { Text(AutoTriggers.argHint(trig)) }, singleLine = true,
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
                        )
                    ChipsRow("Run this script", flows.map { it to (it == flow) }) { flow = flows[it] }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (flow.isNotEmpty()) { rules.add(AutoRule(trig, arg.trim(), flow)); persist() }
                    adding = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } },
        )
    }
}
