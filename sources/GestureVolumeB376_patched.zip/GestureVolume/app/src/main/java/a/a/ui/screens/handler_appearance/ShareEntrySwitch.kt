package a.a.ui.screens.handler_appearance

import android.content.ComponentName
import android.content.pm.PackageManager
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext

/**
 * One switch of the "A ..." entries A adds to other apps' Share and Open with lists:
 * off = that entry is hidden from those lists (its component is disabled).
 */
@Composable
internal fun ShareEntrySwitch(name: String, component: ComponentName) {
    val ctx = LocalContext.current
    var on by remember {
        mutableStateOf(ctx.packageManager.getComponentEnabledSetting(component) != PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
    }
    SwitchControl(
        label = "Show \"$name\" when sharing or opening a file",
        checked = on,
        borderColor = MaterialTheme.colorScheme.primary,
        onCheckedChange = {
            on = it
            ctx.packageManager.setComponentEnabledSetting(
                component,
                if (it) PackageManager.COMPONENT_ENABLED_STATE_DEFAULT else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    )
}
