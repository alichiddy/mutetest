package a.a.strip

import android.app.Activity
import android.os.Bundle

/**
 * What a widget cell starts. A cell can only start an activity, so this one shows nothing: it hands
 * the request to [WidgetFloat], which draws the floating widget as an overlay window, and closes.
 * Because no activity stays open, nothing about the app in front changes and no home screen shows.
 *
 * Extras: mode = "show" (float the widget) or "press" (press a tile), wid / pkg = the widget,
 * tap / pos = the tile, show = seconds to keep the widget visible after pressing (0 = hidden).
 */
open class WidgetFloatActivity : Activity() {
    protected open val defaultMode: String get() = "show"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        a.a.utils.PreviousApp.widgetTouched()
        val mode = intent.getStringExtra("mode") ?: defaultMode
        runCatching { WidgetFloat.handle(this, mode, intent) }
        finish()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}

/** Cells made by the first widget version ("press a chat") keep working. */
class WidgetTapActivity : WidgetFloatActivity() {
    override val defaultMode: String get() = "press"
}

/** Cells made by the first widget version ("popup") keep working. */
class WidgetPopupActivity : WidgetFloatActivity() {
    override val defaultMode: String get() = "show"
}
