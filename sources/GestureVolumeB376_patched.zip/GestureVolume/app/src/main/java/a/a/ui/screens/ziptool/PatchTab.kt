package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.components.rowColor
import a.a.ui.motion.Button
import java.io.File
import java.util.Locale
import java.util.zip.ZipFile

/**
 * Patch several files in a zip in one go. Pick the source zip, tick the files to replace from a searchable
 * list, then give the new versions either as several loose files (matched by file name) or as one zip holding
 * them (matched by path). A Check box shows exactly what goes where before anything is built. New files that
 * contain placeholder text instead of real code are refused. The new zip is read back and checked.
 *
 * Files that fit nothing in the source zip are ADDED (a switch turns that off, and then they are ignored): a file
 * from a replacement zip is added at its own path, a loose file is added in the folder chosen for new files.
 */
class PatchState(private val ctx: Context) {
    var srcName by mutableStateOf<String?>(null)
    var srcFile by mutableStateOf<File?>(null)
    var srcEntries by mutableStateOf<List<String>>(emptyList())
    var chosen by mutableStateOf<Set<String>>(emptySet())
    var looseFiles by mutableStateOf<List<Pair<String, Uri>>>(emptyList())
    var repZipName by mutableStateOf<String?>(null)
    var repZipFile by mutableStateOf<File?>(null)
    var repEntries by mutableStateOf<List<String>>(emptyList())
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var log by mutableStateOf("")
    var showList by mutableStateOf(false)
    var addNew by mutableStateOf(true)
    var addFolder by mutableStateOf("")
    var showFolders by mutableStateOf(false)

    fun cleanup() {
        File(ctx.cacheDir, SRC_TMP).delete()
        File(ctx.cacheDir, REP_TMP).delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    // ---------------------------------------------------------------- picking

    /** Copies the source zip into the app's cache and lists the files inside it. */
    fun loadSrc(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            try {
                val f = File(ctx.cacheDir, SRC_TMP)
                ZipIo.copyToCache(ctx.contentResolver, u, f)
                val names = ZipIo.listFiles(f)
                srcFile = f
                srcName = name
                srcEntries = names
                chosen = emptySet()
                outName = ZipIo.stem(name) + "_patched.zip"
                autoSelect()
            } catch (e: Throwable) {
                log = "PATCH ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    /** Several loose files were picked: they replace any replacement zip picked before. */
    fun useLoose(us: List<Uri>) {
        if (busy) return
        File(ctx.cacheDir, REP_TMP).delete()
        repZipFile = null
        repZipName = null
        repEntries = emptyList()
        looseFiles = us.map { ZipIo.nameOf(ctx.contentResolver, it) to it }
        log = ""
        autoSelect()
    }

    /** One zip holding the new files was picked: it replaces any loose files picked before. */
    fun loadRepZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            try {
                val f = File(ctx.cacheDir, REP_TMP)
                ZipIo.copyToCache(ctx.contentResolver, u, f)
                val names = ZipIo.listFiles(f)
                looseFiles = emptyList()
                repZipFile = f
                repZipName = name
                repEntries = names
                autoSelect()
            } catch (e: Throwable) {
                log = "PATCH ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    /** Every file that has a new version is ticked for you (you can untick any in the list). */
    private fun autoSelect() {
        val r = resolveAll()
        if (r.map.isNotEmpty()) chosen = chosen + r.map.keys
    }

    // ---------------------------------------------------------------- matching

    /** One new version: a loose file (uri) or an entry of the replacement zip. */
    class Rep(val label: String, val uri: Uri?, val entry: String?)

    /** [map] holds source path -> its new version. [unmatched] are new versions that fit no file in the source zip. */
    class Resolved(
        val map: LinkedHashMap<String, Rep>,
        val problems: List<String>,
        val unmatched: List<String>,
        /** New path in the zip -> the new file to put there (files that fit nothing, when adding is on). */
        val adds: LinkedHashMap<String, Rep> = LinkedHashMap(),
    )

    /** Every folder in the source zip (without the project folder), for the "folder for new files" list. */
    fun folderList(): List<String> {
        val root = rootOf(srcEntries)
        return srcEntries.map { it.removePrefix(root).substringBeforeLast('/', "") }
            .filter { it.isNotEmpty() }.distinct().sorted()
    }

    /** Where a new file from the replacement zip goes: its own path, under the project folder of the source zip. */
    private fun newPathFor(p: String, src: List<String>, root: String): String {
        var rel = p
        if (root.isNotEmpty() && p.startsWith(root)) {
            rel = p.removePrefix(root)
        } else {
            val repRoot = rootOf(repEntries)
            if (repRoot.isNotEmpty() && repRoot != root) {
                val tops = src.map { it.removePrefix(root).substringBefore('/', "") }.toHashSet()
                if (repRoot.removeSuffix("/") !in tops) rel = p.removePrefix(repRoot)
            }
        }
        return root + rel
    }

    fun rootOf(src: List<String>): String {
        if (src.isEmpty()) return ""
        val first = src[0].substringBefore('/', "")
        return if (first.isNotEmpty() && src.all { it.startsWith("$first/") }) "$first/" else ""
    }

    fun resolveAll(): Resolved {
        val map = LinkedHashMap<String, Rep>()
        val problems = ArrayList<String>()
        val unmatched = ArrayList<String>()
        val src = srcEntries
        if (src.isEmpty()) return Resolved(map, problems, unmatched)
        val srcSet = src.toHashSet()
        val root = rootOf(src)
        if (looseFiles.isNotEmpty()) {
            for ((name, uri) in looseFiles) {
                val cands = src.filter { it.substringAfterLast('/') == name }
                var target: String? = null
                var skip = false
                if (cands.size == 1) {
                    target = cands[0]
                } else if (cands.size > 1) {
                    val inChosen = cands.filter { it in chosen }
                    if (inChosen.size == 1) {
                        target = inChosen[0]
                    } else {
                        problems.add("$name fits ${cands.size} files in the zip. Tick the one you mean in the list.")
                        skip = true
                    }
                }
                if (skip) continue
                if (target == null) {
                    unmatched.add(name)
                    continue
                }
                if (map.containsKey(target)) {
                    problems.add("Two new files are named $name.")
                    continue
                }
                map[target] = Rep(name, uri, null)
            }
        } else {
            for (p in repEntries) {
                val target = resolve(p, src, srcSet, root)
                if (target == null) {
                    unmatched.add(p)
                    continue
                }
                val prev = map[target]
                if (prev != null) {
                    problems.add("${prev.label} and $p both fit ${target.removePrefix(root)}.")
                    continue
                }
                map[target] = Rep(p, null, p)
            }
        }
        val adds = LinkedHashMap<String, Rep>()
        if (addNew && unmatched.isNotEmpty()) {
            val folder = addFolder.trim().trim('/')
            for (u in unmatched) {
                val newPath: String
                if (looseFiles.isNotEmpty()) {
                    if (folder.isEmpty()) {
                        problems.add("$u is new: choose the folder for new files, or switch adding off.")
                        continue
                    }
                    newPath = root + folder + "/" + u
                } else {
                    if (src.any { it.endsWith("/" + u) }) {
                        problems.add("$u fits several files in the zip. Give its full path in the replacement zip.")
                        continue
                    }
                    newPath = newPathFor(u, src, root)
                }
                if (newPath in srcSet) {
                    problems.add("$u would be added as ${newPath.removePrefix(root)}, which is already in the zip.")
                    continue
                }
                if (adds.containsKey(newPath)) {
                    problems.add("Two new files would be added as ${newPath.removePrefix(root)}.")
                    continue
                }
                val rp = if (looseFiles.isNotEmpty()) Rep(u, looseFiles.first { it.first == u }.second, null) else Rep(u, null, u)
                adds[newPath] = rp
            }
        }
        return Resolved(map, problems, unmatched, adds)
    }

    /** Finds which source file a path from the replacement zip stands for (same path, with or without the project folder). */
    fun resolve(p: String, src: List<String>, srcSet: Set<String>, root: String): String? {
        if (p in srcSet) return p
        if (root.isNotEmpty() && (root + p) in srcSet) return root + p
        val rest = p.substringAfter('/', "")
        if (rest.isNotEmpty()) {
            if (rest in srcSet) return rest
            if (root.isNotEmpty() && (root + rest) in srcSet) return root + rest
        }
        if (p.contains('/')) {
            val hits = src.filter { it.endsWith("/" + p) }
            return if (hits.size == 1) hits[0] else null
        }
        val hits = src.filter { it.substringAfterLast('/') == p }
        return if (hits.size == 1) hits[0] else null
    }

    fun names(list: List<String>): String {
        val first = list.take(3).joinToString(", ") { it.substringAfterLast('/') }
        return if (list.size > 3) "$first and ${list.size - 3} more" else first
    }

    fun previewText(res: Resolved, toApply: List<String>, missing: List<String>): String {
        val root = rootOf(srcEntries)
        val sb = StringBuilder()
        if (toApply.isNotEmpty() || res.adds.isEmpty()) sb.append("Will replace ${toApply.size} file(s):\n")
        for (t in toApply) sb.append(" ${t.removePrefix(root)}\n    <- ${res.map[t]!!.label}\n")
        if (missing.isNotEmpty()) {
            sb.append("\nNo new version found for:\n")
            for (t in missing) sb.append(" ${t.removePrefix(root)}\n")
        }
        if (res.adds.isNotEmpty()) {
            sb.append("\nWill ADD ${res.adds.size} new file(s):\n")
            for ((p, r) in res.adds) sb.append(" ${p.removePrefix(root)}\n    <- ${r.label}\n")
        }
        val left = res.map.keys.count { it !in chosen }
        if (left > 0) sb.append("\nLeft alone (fits a file, not ticked): $left\n")
        if (!addNew && res.unmatched.isNotEmpty()) {
            sb.append("\nNot in the source zip, ignored: ${res.unmatched.size}\n")
            for (u in res.unmatched.take(8)) sb.append(" $u\n")
            if (res.unmatched.size > 8) sb.append(" ...and ${res.unmatched.size - 8} more\n")
        }
        for (p in res.problems) sb.append("\nPROBLEM: $p")
        return sb.toString().trim()
    }

    // ---------------------------------------------------------------- building

    fun make() {
        val src = srcFile ?: return
        if (busy) return
        val res = resolveAll()
        val targets = chosen.filter { res.map.containsKey(it) }.sorted()
        val missing = chosen.filter { !res.map.containsKey(it) }
        val adds = res.adds.keys.sorted()
        if (res.problems.isNotEmpty() || missing.isNotEmpty() || (targets.isEmpty() && adds.isEmpty())) {
            log = "PATCH ERROR: fix what the Check box shows first.\nNothing was saved."
            return
        }
        busy = true
        log = ""
        val saveName = ZipIo.cleanName(outName, "patched")
        val repFile = repZipFile
        val useRepZip = looseFiles.isEmpty() && repFile != null
        val root = rootOf(srcEntries)
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            var repZip: ZipFile? = null
            try {
                if (useRepZip) repZip = ZipFile(repFile!!)
                val newBytes = LinkedHashMap<String, ByteArray>()
                val addBytes = LinkedHashMap<String, ByteArray>()
                val problems = ArrayList<String>()
                val warnings = ArrayList<String>()
                var codeChecked = 0
                fun inspect(path: String, b: ByteArray) {
                    val leaf = path.substringAfterLast('/')
                    if (b.isEmpty()) {
                        problems.add("$leaf: the new file is empty.")
                        return
                    }
                    val ext = leaf.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ext in CodeChecks.TEXT_EXT) {
                        val text = String(b, Charsets.UTF_8)
                        val hit = CodeChecks.placeholderHit(text)
                        if (hit != null) {
                            problems.add("$leaf line ${hit.first}: ${hit.second}")
                        } else if (ext == "kt" || ext == "java") {
                            codeChecked++
                            val note = CodeChecks.bracketNote(text)
                            if (note != null) warnings.add("$leaf: $note")
                        }
                    }
                }
                for (t in targets) {
                    val b = bytesOf(res.map[t]!!, repZip)
                    newBytes[t] = b
                    inspect(t, b)
                }
                for (a in adds) {
                    val b = bytesOf(res.adds[a]!!, repZip)
                    addBytes[a] = b
                    inspect(a, b)
                }
                if (problems.isNotEmpty()) {
                    throw IllegalStateException("A new file was not accepted:\n" + problems.joinToString("\n") { " - $it" })
                }
                val out = ZipIo.rewrite(
                    src, tmp,
                    newBytes.mapValues { ZipIo.Blob(it.value) },
                    add = addBytes.map { it.key to ZipIo.Blob(it.value) },
                )
                if (out.replaced != newBytes.size) {
                    throw IllegalStateException("Only ${out.replaced} of ${newBytes.size} files were found in the zip.")
                }
                if (out.added != addBytes.size) {
                    throw IllegalStateException("Only ${out.added} of ${addBytes.size} new files were added.")
                }
                val sb = StringBuilder()
                if (targets.isNotEmpty()) {
                    sb.append("REPLACED ${targets.size} file(s):\n")
                    for (t in targets) sb.append(" - ${t.removePrefix(root)}\n")
                }
                if (adds.isNotEmpty()) {
                    sb.append("ADDED ${adds.size} file(s):\n")
                    for (a in adds) sb.append(" - ${a.removePrefix(root)}\n")
                }
                if (out.skipped > 0) sb.append("Note: ${out.skipped} repeated file name(s) in the zip were left out.\n")
                if (warnings.isEmpty()) {
                    sb.append("Brackets: $codeChecked code file(s) balanced.\n")
                } else {
                    for (w in warnings) sb.append("WARNING brackets: $w\n")
                }
                val problem = ZipIo.verify(tmp, out.written, out.expectCrc)
                if (problem != null) {
                    sb.append("PATCH ERROR: $problem\nNothing was saved.")
                } else {
                    val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
                    sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                    sb.append("Read back and checked. ${out.written} files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "PATCH ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                runCatching { repZip?.close() }
                tmp.delete()
                busy = false
            }
        }.start()
    }

    fun bytesOf(rep: Rep, repZip: ZipFile?): ByteArray {
        val u = rep.uri
        if (u != null) return ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }
        val zf = repZip ?: throw IllegalStateException("The replacement zip is not open.")
        val e = zf.getEntry(rep.entry!!) ?: throw IllegalStateException("${rep.entry} is missing in the replacement zip.")
        return zf.getInputStream(e).use { it.readBytes() }
    }

    private companion object {
        const val SRC_TMP = "zt_patch_src.zip"
        const val REP_TMP = "zt_patch_rep.zip"
        const val OUT_TMP = "zt_patch_out.zip"
    }
}

@Composable
fun PatchTab(s: PatchState) {
    val pickSrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadSrc(u)
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us ->
        if (us.isNotEmpty()) s.useLoose(us)
    }
    val pickRepZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadRepZip(u)
    }
    val res = remember(s.srcEntries, s.chosen, s.looseFiles, s.repEntries, s.addNew, s.addFolder) { s.resolveAll() }
    val toApply = s.chosen.filter { res.map.containsKey(it) }.sorted()
    val missing = s.chosen.filter { !res.map.containsKey(it) }.sorted()
    val hasRep = s.looseFiles.isNotEmpty() || s.repEntries.isNotEmpty()
    val ready = s.srcFile != null && (toApply.isNotEmpty() || res.adds.isNotEmpty()) && missing.isEmpty() &&
        res.problems.isEmpty() && s.outName.isNotBlank()

    HeroCard(
        title = "Patch several files in a zip",
        text = "Pick the source zip, tick the files to replace, then give the new versions as files or as one zip. Files that are not in the zip yet are added. A new zip is saved in Downloads and checked.",
        leading = { IconTile(Icons.Filled.Settings, lit = true) },
    )
    Column {
        GroupHeading("Source")
        RowGroup {
            KitRow(
                title = "Source zip",
                shape = cardShape(0, 2),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = s.srcName ?: "Tap to choose",
                description = if (s.srcName != null) "${s.srcEntries.size} files inside" else null,
                onClick = { if (!s.busy) pickSrc.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "Files to replace",
                shape = cardShape(1, 2),
                summary = if (s.chosen.isEmpty()) "Tap to choose from the list" else "${s.chosen.size} chosen",
                description = when {
                    s.srcEntries.isEmpty() -> "Choose the source zip first"
                    s.chosen.isEmpty() -> null
                    else -> s.names(s.chosen.sorted())
                },
                onClick = { if (!s.busy && s.srcEntries.isNotEmpty()) s.showList = true },
            )
        }
    }
    Column {
        GroupHeading("New versions (use one of the two)")
        RowGroup {
            KitRow(
                title = "Several files",
                shape = cardShape(0, 2),
                summary = if (s.looseFiles.isEmpty()) "Tap to choose the new files" else "${s.looseFiles.size} files",
                description = if (s.looseFiles.isEmpty()) "Matched to the zip by file name" else s.names(s.looseFiles.map { it.first }),
                onClick = { if (!s.busy) pickFiles.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "One zip with the files",
                shape = cardShape(1, 2),
                summary = s.repZipName ?: "Tap to choose the zip",
                description = if (s.repZipName != null) "${s.repEntries.size} files inside" else "Matched to the zip by path",
                onClick = { if (!s.busy) pickRepZip.launch(arrayOf("*/*")) },
            )
        }
    }
    Column {
        GroupHeading("New files (not in the zip yet)")
        RowGroup {
            KitRow(
                title = "Add files that fit nothing",
                shape = cardShape(0, 2),
                description = if (s.addNew) "They are added to the new zip" else "They are ignored",
                onClick = { if (!s.busy) s.addNew = !s.addNew },
                trailing = { Switch(checked = s.addNew, onCheckedChange = { if (!s.busy) s.addNew = it }) },
            )
            KitRow(
                title = "Folder for new files",
                shape = cardShape(1, 2),
                summary = if (s.addFolder.isBlank()) "Tap to choose" else s.addFolder,
                description = "Only for files picked one by one. A replacement zip keeps its own paths.",
                onClick = { if (!s.busy && s.srcEntries.isNotEmpty()) s.showFolders = true },
            )
        }
    }
    if (s.srcFile != null && (s.chosen.isNotEmpty() || hasRep)) {
        Column {
            GroupHeading("Check")
            TextBox(s.previewText(res, toApply, missing))
        }
    }
    SaveAsField(s.outName) { s.outName = it }
    Button(
        onClick = { s.make() },
        enabled = ready && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) "Working..." else "Patch and make zip") }
    ResultBox(s.log)

    if (s.showList) {
        var query by remember { mutableStateOf("") }
        val shown = remember(s.srcEntries, query) {
            val q = query.trim()
            if (q.isEmpty()) s.srcEntries else s.srcEntries.filter { it.contains(q, ignoreCase = true) }
        }
        CardWindow(title = "Files to replace", onBack = { s.showList = false }, scroll = false) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search (${shown.size} files, ${s.chosen.size} chosen)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shown) { path ->
                    val on = path in s.chosen
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        background = if (on) MaterialTheme.colorScheme.primaryContainer else rowColor(),
                        onClick = { s.chosen = if (on) s.chosen - path else s.chosen + path },
                        trailing = { if (on) Icon(Icons.Filled.Check, contentDescription = null) },
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { s.chosen = emptySet() },
                    enabled = s.chosen.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                ) { Text("Clear") }
                Button(
                    onClick = { s.showList = false },
                    modifier = Modifier.weight(1f),
                ) { Text("Done (${s.chosen.size})") }
            }
        }
    }

    if (s.showFolders) {
        var typed by remember { mutableStateOf(s.addFolder) }
        val folders = remember(s.srcEntries) { s.folderList() }
        val shownF = remember(folders, typed) {
            val q = typed.trim()
            if (q.isEmpty()) folders else folders.filter { it.contains(q, ignoreCase = true) }
        }
        CardWindow(title = "Folder for new files", onBack = { s.showFolders = false }, scroll = false) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                singleLine = true,
                label = { Text("Type a folder, or tap one below (${shownF.size} folders)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shownF.take(300)) { path ->
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        onClick = { typed = path },
                        trailing = null,
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = { s.addFolder = ""; s.showFolders = false },
                    modifier = Modifier.weight(1f),
                ) { Text("No folder") }
                Button(
                    onClick = { s.addFolder = typed.trim().trim('/'); s.showFolders = false },
                    enabled = typed.isNotBlank(),
                    modifier = Modifier.weight(1f),
                ) { Text("Use this folder") }
            }
        }
    }
}
