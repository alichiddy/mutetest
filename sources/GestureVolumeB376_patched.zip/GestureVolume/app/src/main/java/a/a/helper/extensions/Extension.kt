package a.a.helper.extensions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.core.net.toUri
import a.a.BuildConfig

fun getApplicationVersion(): String {
    return BuildConfig.VERSION_NAME
}

fun Context.toast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun shareApp(context: Context) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, "http://play.google.com/store/apps/details?id=${context.packageName}")
    }
    val chooser = Intent.createChooser(shareIntent, "Share via")
    context.startActivity(chooser)
}

fun openMailApp(context: Context, subject: String, mail: Array<String>, content: String = "") {
    // Get app information
    val packageManager = context.packageManager
    val packageName = context.packageName
    var appName: String
    var appVersion: String
    var appBuild: String

    try {
        val packageInfo = packageManager.getPackageInfo(packageName, 0)
        val applicationInfo = packageManager.getApplicationInfo(context.packageName, 0)
        appName = packageManager.getApplicationLabel(applicationInfo).toString()
        appVersion = packageInfo.versionName ?: "Unknown"
        appBuild = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo.longVersionCode.toString()
        } else {
            @Suppress("DEPRECATION")
            packageInfo.versionCode.toString()
        }
    } catch (e: PackageManager.NameNotFoundException) {
        e.printStackTrace()
        appName = "Unknown"
        appVersion = "Unknown"
        appBuild = "Unknown"
    }

    // Get device information
    val deviceName = Build.MODEL
    val androidVersion = Build.VERSION.SDK_INT

    // Build the email body
    val template = """
Q: What problem did you encounter?
A: 
$content

--------------
APP: $appName
Version: $appVersion
Build: $appBuild
Device: $deviceName
System: $androidVersion
    """.trimIndent()

    try {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = "mailto:".toUri()
            putExtra(Intent.EXTRA_EMAIL, mail)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, template)
        }
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        context.toast("There are no email apps installed on your device")
    }
}

fun openAppStore(context: Context, link: String, error: (String?) -> Unit) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, link.toUri())
        context.startActivity(intent)
    } catch (e: Exception) {
        error(e.message)
    }
}

fun openWebPage(context: Context, url: String?, error: (String?) -> Unit) {
    try {
        url?.let {
            val browserIntent = Intent(Intent.ACTION_VIEW, it.toUri())
            context.startActivity(browserIntent)
        } ?: error("URL is null")
    } catch (e: Exception) {
        error(e.message)
    }
}

fun isUriEmpty(uri: Uri?): Boolean {
    return uri == null || uri == Uri.EMPTY
}