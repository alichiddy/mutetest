package a.a.ui.screens.ziptool

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * What every tab of the Zip tools window shares: copying a picked file into the cache, listing a zip,
 * rewriting a zip with some files swapped, added or removed, reading the result back to check it, and
 * saving it in Downloads. A new zip is always written; the zip you picked is never touched.
 */
object ZipIo {
    const val BUF = 64 * 1024

    fun nameOf(cr: ContentResolver, u: Uri): String {
        var n: String? = null
        runCatching {
            cr.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) n = c.getString(0)
            }
        }
        return (n ?: u.lastPathSegment ?: "file").substringAfterLast('/')
    }

    fun sizeOf(cr: ContentResolver, u: Uri): Long {
        var s = 0L
        runCatching {
            cr.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) s = c.getLong(0)
            }
        }
        return s
    }

    fun mb(bytes: Long): String = String.format(Locale.US, "%.2f MB", bytes / 1048576.0)

    /** A short size for a list row: bytes, KB or MB. */
    fun size(bytes: Long): String = when {
        bytes < 1024L -> "$bytes B"
        bytes < 1048576L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.2f MB", bytes / 1048576.0)
    }

    /** A file name that is safe to save: no slashes or other path characters, always ending in .zip. */
    fun cleanName(s: String, fallback: String): String {
        var n = s.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        if (n.isEmpty()) n = fallback
        if (!n.endsWith(".zip", ignoreCase = true)) n += ".zip"
        return n
    }

    /** The picked name without its .zip, for building a default output name. */
    fun stem(name: String): String = Regex("(?i)\\.zip$").replace(name, "")

    fun copyToCache(cr: ContentResolver, u: Uri, dest: File) {
        val input = cr.openInputStream(u) ?: throw IllegalStateException("Could not open the file.")
        input.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
    }

    /** Every file (not folder) inside a zip, sorted. */
    fun listFiles(f: File): List<String> {
        val names = ArrayList<String>()
        ZipFile(f).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory) names.add(e.name)
            }
        }
        return names.sorted()
    }

    /** "Project/" when every file sits inside one top folder, otherwise "". */
    fun rootOf(src: List<String>): String {
        if (src.isEmpty()) return ""
        val first = src[0].substringBefore('/', "")
        return if (first.isNotEmpty() && src.all { it.startsWith("$first/") }) "$first/" else ""
    }

    /** The new content of one file: bytes already in memory, or a stream opened when it is written. */
    class Blob(val bytes: ByteArray? = null, private val opener: (() -> InputStream)? = null) {
        fun open(): InputStream =
            bytes?.let { ByteArrayInputStream(it) } ?: (opener ?: throw IllegalStateException("No content.")).invoke()
    }

    /** What [rewrite] did. [expectCrc] holds the checksum every file in the new zip must have. */
    class Outcome(
        val written: Int,
        val skipped: Int,
        val replaced: Int,
        val removed: Int,
        val added: Int,
        val expectCrc: Map<String, Long>,
    )

    /**
     * Writes a copy of [src] to [out]: every file is copied across with its name, date, comment and storage
     * method, except the ones in [replace] (new content), [remove] (left out) and [add] (new files appended).
     */
    fun rewrite(
        src: File,
        out: File,
        replace: Map<String, Blob>,
        remove: Set<String> = emptySet(),
        add: List<Pair<String, Blob>> = emptyList(),
    ): Outcome {
        val expect = HashMap<String, Long>()
        var written = 0
        var skipped = 0
        var replaced = 0
        var removed = 0
        var added = 0
        ZipFile(src).use { zf ->
            ZipOutputStream(out.outputStream().buffered()).use { zo ->
                val seen = HashSet<String>()
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (!seen.add(e.name)) { skipped++; continue }
                    if (e.name in remove) { removed++; continue }
                    val o = ZipEntry(e.name)
                    if (e.time != -1L) o.time = e.time
                    if (e.comment != null) o.comment = e.comment
                    val blob = replace[e.name]
                    if (blob != null) {
                        replaced++
                        expect[e.name] = putBlob(zo, o, e.method, blob)
                    } else if (e.isDirectory) {
                        o.method = ZipEntry.STORED
                        o.size = 0L
                        o.compressedSize = 0L
                        o.crc = 0L
                        zo.putNextEntry(o)
                        zo.closeEntry()
                    } else if (e.method == ZipEntry.STORED) {
                        expect[e.name] = e.crc
                        o.method = ZipEntry.STORED
                        o.size = e.size
                        o.compressedSize = e.size
                        o.crc = e.crc
                        zo.putNextEntry(o)
                        zf.getInputStream(e).use { it.copyTo(zo) }
                        zo.closeEntry()
                    } else {
                        expect[e.name] = e.crc
                        o.method = ZipEntry.DEFLATED
                        zo.putNextEntry(o)
                        zf.getInputStream(e).use { it.copyTo(zo) }
                        zo.closeEntry()
                    }
                    written++
                }
                for ((name, blob) in add) {
                    if (!seen.add(name)) throw IllegalStateException("$name is already in the zip, so it cannot be added.")
                    val o = ZipEntry(name)
                    o.time = System.currentTimeMillis()
                    expect[name] = putBlob(zo, o, ZipEntry.DEFLATED, blob)
                    added++
                    written++
                }
            }
        }
        return Outcome(written, skipped, replaced, removed, added, expect)
    }

    /** Writes one file's content as an entry and returns its checksum. */
    private fun putBlob(zo: ZipOutputStream, o: ZipEntry, method: Int, blob: Blob): Long {
        val crc = CRC32()
        val b = blob.bytes
        if (b != null) {
            crc.update(b)
            if (method == ZipEntry.STORED) {
                o.method = ZipEntry.STORED
                o.size = b.size.toLong()
                o.compressedSize = b.size.toLong()
                o.crc = crc.value
            } else {
                o.method = ZipEntry.DEFLATED
            }
            zo.putNextEntry(o)
            zo.write(b)
            zo.closeEntry()
            return crc.value
        }
        o.method = ZipEntry.DEFLATED
        zo.putNextEntry(o)
        blob.open().use { i ->
            val buf = ByteArray(BUF)
            while (true) {
                val r = i.read(buf)
                if (r < 0) break
                crc.update(buf, 0, r)
                zo.write(buf, 0, r)
            }
        }
        zo.closeEntry()
        return crc.value
    }

    /** Reads the whole new zip back: every file's checksum must match what it should be. Null when all is well. */
    fun verify(file: File, expected: Int, expectCrc: Map<String, Long>): String? {
        return try {
            var n = 0
            var files = 0
            ZipInputStream(file.inputStream().buffered()).use { zi ->
                val buf = ByteArray(BUF)
                while (true) {
                    val e = zi.nextEntry ?: break
                    val crc = CRC32()
                    while (true) {
                        val r = zi.read(buf)
                        if (r < 0) break
                        crc.update(buf, 0, r)
                    }
                    n++
                    if (e.isDirectory) continue
                    files++
                    val want = expectCrc[e.name] ?: return "${e.name} is in the new zip but was not expected."
                    if (want != crc.value) return "${e.name} in the new zip does not match."
                }
            }
            when {
                n != expected -> "the new zip holds $n entries, expected $expected."
                files != expectCrc.size -> "the new zip holds $files files, expected ${expectCrc.size}."
                else -> null
            }
        } catch (e: Throwable) {
            "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    /** Puts the zip in Downloads and returns where it ended up (Android adds (1) if the name is taken). */
    @Suppress("DEPRECATION")
    fun saveToDownloads(ctx: Context, file: File, name: String): String {
        val cr = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create the file in Downloads.")
            val os = cr.openOutputStream(uri) ?: throw IllegalStateException("Could not write the file in Downloads.")
            os.use { o -> file.inputStream().use { it.copyTo(o) } }
            var finalName = name
            runCatching {
                cr.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { finalName = it }
                }
            }
            return "Downloads/$finalName"
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val dest = File(dir, name)
        file.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        return "Downloads/$name"
    }
}
