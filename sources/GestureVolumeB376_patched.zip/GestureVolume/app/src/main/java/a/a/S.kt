package a.a

import a.a.service.GestureAccessibilityService

/**
 * The accessibility service under its short name, so it is written `a.a/.S` in a command or in
 * Automate. Everything it does is in [GestureAccessibilityService].
 */
class S : GestureAccessibilityService()
