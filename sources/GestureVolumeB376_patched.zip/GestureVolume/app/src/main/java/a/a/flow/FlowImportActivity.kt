package a.a.flow

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/**
 * Opens a .afl file (from a file manager, a chat app or the share sheet) and imports the scripts in it.
 * No window and nothing kept in memory: it reads the file, shows a toast, opens the first script, and ends.
 */
class FlowImportActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val names = runCatching { read() }.getOrNull()
        when {
            names == null -> toast("That is not an A scripts file (.afl).")
            names.isEmpty() -> toast("The file has no scripts.")
            else -> {
                toast("Imported " + names.size + " script(s): " + names.joinToString(", "))
                startActivity(
                    Intent(this, FlowActivity::class.java)
                        .putExtra("flow", names.first())
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }
        finish()
    }

    private fun read(): List<String>? {
        val i = intent ?: return null
        val uri: Uri? = if (i.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        } else i.data
        if (uri != null) return FlowShare.import(this, uri)
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return null
        return FlowShare.importText(this, text)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
