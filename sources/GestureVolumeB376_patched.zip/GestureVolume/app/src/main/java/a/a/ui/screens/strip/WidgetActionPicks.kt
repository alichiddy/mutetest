package a.a.ui.screens.strip

import a.a.strip.WidgetFloatActivity
import a.a.strip.WidgetKit
import a.a.strip.WidgetTiles
import a.a.ui.motion.TextButton
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * The two widget entries of Built-in shortcuts. Both hand back the same action text a widget cell holds
 * ("Intent:" + the intent of WidgetFloatActivity), so they run exactly like a cell made in the Widgets window.
 * The lists are read only while a picker is open.
 */
internal object WidgetActions {
    /** "Intent:" text that shows (or hides) the floating popup of the saved widget [id]. */
    fun popupAction(context: Context, id: Int): String {
        val pkg = WidgetKit.providerPackage(context, id)
        val i = Intent(context, WidgetFloatActivity::class.java)
            .putExtra("mode", "show").putExtra("wid", id).putExtra("pkg", pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME)
    }

    /** The name of a saved widget: its own label, else its app's package. */
    fun widgetName(context: Context, id: Int): String {
        val info = AppWidgetManager.getInstance(context).getAppWidgetInfo(id)
        val label = runCatching { info?.loadLabel(context.packageManager) }.getOrNull()?.toString().orEmpty()
        return label.ifBlank { WidgetKit.providerPackage(context, id).ifBlank { "Widget $id" } }
    }
}

/** The widgets added in the Widgets window; picking one gives the action that opens its floating popup. */
@Composable
internal fun WidgetOpenPicker(onPicked: (action: String, name: String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val widgets = remember { WidgetKit.savedIds(context).map { it to WidgetActions.widgetName(context, it) } }
    PickDialog("Open a widget (floating popup)", "No widget yet. Add one in the Widgets window first.", widgets.map { it.second }, onDismiss) { i ->
        val (id, name) = widgets[i]
        onPicked(WidgetActions.popupAction(context, id), name)
    }
}

/** The buttons saved in the Widgets window (a tile of a widget, pressed by name and place); picking one gives its action. */
@Composable
internal fun WidgetTilePicker(onPicked: (action: String, name: String) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val tiles = remember { WidgetTiles.load(context).filter { it.action.isNotEmpty() } }
    PickDialog(
        "Press a widget button", "No button yet. In the Widgets window, grab a tile and save it first.",
        tiles.map { it.name.ifBlank { "Tile" } }, onDismiss,
    ) { i -> onPicked(tiles[i].action, tiles[i].name.ifBlank { "Tile" }) }
}

@Composable
private fun PickDialog(title: String, empty: String, names: List<String>, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().statusBarsPadding().padding(12.dp)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                if (names.isEmpty()) Text(empty)
                LazyColumn(Modifier.weight(1f)) {
                    items(names.indices.toList()) { i ->
                        Text(names[i], fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 12.dp))
                    }
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    }
}
