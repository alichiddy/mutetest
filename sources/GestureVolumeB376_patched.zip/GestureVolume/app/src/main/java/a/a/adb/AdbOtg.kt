package a.a.adb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.io.IOException

/** ADB over a USB OTG cable: finds the devices, asks Android's USB permission, opens the cable. */
object AdbOtg {
    private const val PERMISSION_ACTION = "a.a.adb.USB_PERMISSION"

    private fun mgr(c: Context) = c.getSystemService(Context.USB_SERVICE) as UsbManager

    fun devices(c: Context): List<UsbDevice> = mgr(c).deviceList.values.toList()

    private fun adbInterface(d: UsbDevice): UsbInterface? {
        for (i in 0 until d.interfaceCount) {
            val f = d.getInterface(i)
            if (f.interfaceClass == 0xFF && f.interfaceSubclass == 0x42 && f.interfaceProtocol == 1) return f
        }
        return null
    }

    fun isAdb(d: UsbDevice): Boolean = adbInterface(d) != null

    fun label(d: UsbDevice): String {
        val name = d.productName ?: "USB device"
        val ids = String.format("%04x:%04x", d.vendorId, d.productId)
        return if (isAdb(d)) "$name ($ids)" else "$name ($ids) - not an ADB device"
    }

    /** Asks Android's own "Allow A to access this USB device?" window (skipped when already allowed). */
    fun requestPermission(c: Context, d: UsbDevice, done: (Boolean) -> Unit) {
        val m = mgr(c)
        if (m.hasPermission(d)) { done(true); return }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                runCatching { context.unregisterReceiver(this) }
                done(intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
            }
        }
        ContextCompat.registerReceiver(c, receiver, IntentFilter(PERMISSION_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getBroadcast(c, 0, Intent(PERMISSION_ACTION).setPackage(c.packageName), flags)
        m.requestPermission(d, pi)
    }

    /** Opens the cable to the device's ADB interface. Throws when it cannot. */
    fun open(c: Context, d: UsbDevice): AdbTransport {
        val m = mgr(c)
        val f = adbInterface(d) ?: throw IOException("This device has no ADB interface (turn USB debugging on)")
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (i in 0 until f.endpointCount) {
            val e = f.getEndpoint(i)
            if (e.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (e.direction == UsbConstants.USB_DIR_IN) inEp = e else outEp = e
        }
        val ein = inEp ?: throw IOException("No USB input endpoint")
        val eout = outEp ?: throw IOException("No USB output endpoint")
        val conn = m.openDevice(d) ?: throw IOException("Android would not open the USB device (permission?)")
        if (!conn.claimInterface(f, true)) {
            conn.close()
            throw IOException("Another app is using the device (close adb or other USB tools)")
        }
        return UsbTransport(m, d, conn, f, ein, eout)
    }
}

class UsbTransport(
    private val mgr: UsbManager,
    private val dev: UsbDevice,
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint
) : AdbTransport {
    override fun write(buf: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val n = minOf(16384, len - off)
            val r = conn.bulkTransfer(outEp, buf, off, n, 10000)
            if (r < 0) throw IOException("USB write failed")
            off += r
        }
    }

    override fun read(buf: ByteArray, off: Int, len: Int, timeoutMs: Int): Int =
        conn.bulkTransfer(inEp, buf, off, len, timeoutMs)

    override fun alive(): Boolean = mgr.deviceList.containsKey(dev.deviceName)

    override fun close() {
        runCatching { conn.releaseInterface(iface) }
        runCatching { conn.close() }
    }
}
