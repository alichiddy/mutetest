package a.a.strip

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import a.a.data.local.SharedPref
import org.json.JSONObject

/**
 * Opens any .json file (file manager, chat app, share sheet). If it is an A backup it asks what to
 * import, saves what you have now first (undo copy, plus the auto backup when that is on), applies
 * the chosen part, and offers Undo. No Compose and nothing kept in memory: it ends when you answer.
 */
class SettingsImportActivity : Activity() {
    private var text = ""
    private var fileName = "this file"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = readUri()
        if (uri == null) { stop("No file to import."); return }
        fileName = nameOf(uri)
        val body = runCatching {
            contentResolver.openInputStream(uri)!!.use { s ->
                val b = s.readBytes()
                if (b.size > MAX_BYTES) null else b.toString(Charsets.UTF_8)
            }
        }.getOrNull()
        if (body == null) { stop("Could not read $fileName."); return }
        val root = runCatching { JSONObject(body.trimStart('\uFEFF', ' ', '\n', '\r', '\t')) }.getOrNull()
        val prefs = root?.optJSONObject("prefs")
        if (root == null || prefs == null) { stop("$fileName is not an A backup."); return }
        text = body.trimStart('\uFEFF', ' ', '\n', '\r', '\t')

        var hasSettings = false
        var hasScripts = root.has("icons") || root.has("ocrBoxes") || root.has("widgetTiles")
        for (k in prefs.keys()) { if (SettingsBackup.isStripKey(k)) hasScripts = true else hasSettings = true }
        if (!hasSettings && !hasScripts) { stop("$fileName has no settings or scripts."); return }

        val labels = ArrayList<String>()
        val picks = ArrayList<Pair<Boolean, Boolean>>()
        if (hasSettings && hasScripts) { labels += "Everything (settings and scripts)"; picks += true to true }
        if (hasSettings) { labels += "Settings only (everything except the cells)"; picks += true to false }
        if (hasScripts) { labels += "Scripts only (the cells, shortcuts and scripts)"; picks += false to true }
        labels += "Cancel"

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Import into A")
            .setMessage("$fileName\n\nWhat do you want to import? What you have now is saved first, so you can undo.")
            .setItems(labels.toTypedArray()) { _, i ->
                if (i >= picks.size) finish() else doImport(picks[i].first, picks[i].second)
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun doImport(settings: Boolean, scripts: Boolean) {
        val prefs = SharedPref(this).sharedPreferences
        // Restoring clears every setting first, and backups never carry the GitHub token, so keep it.
        val token = prefs.getString("ghToken", null)
        SettingsBackup.saveUndo(this, prefs)
        if (AutoBackup.enabled(this)) runCatching { AutoBackup.save(this) }
        val n = runCatching { SettingsBackup.apply(prefs, text, settings, scripts) }.getOrDefault(-1)
        if (token != null && !prefs.contains("ghToken")) prefs.edit().putString("ghToken", token).commit()
        if (n <= 0) {
            stop(if (n < 0) "Import failed. Nothing was changed." else "$fileName holds nothing of that part.")
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Imported")
            .setMessage("$n items imported from $fileName.\n\nClose and reopen A to apply them everywhere.")
            .setPositiveButton("OK") { _, _ -> finish() }
            .setNegativeButton("Undo import") { _, _ ->
                val back = SettingsBackup.undoLast(this, prefs)
                if (token != null && !prefs.contains("ghToken")) prefs.edit().putString("ghToken", token).commit()
                toast(if (back < 0) "Nothing to undo." else "Import undone. Close and reopen A.")
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun readUri(): Uri? {
        val i = intent ?: return null
        return if (i.action == Intent.ACTION_SEND) {
            @Suppress("DEPRECATION")
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        } else i.data
    }

    private fun nameOf(uri: Uri): String {
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) return n }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "this file"
    }

    private fun stop(msg: String) { toast(msg); finish() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private companion object { const val MAX_BYTES = 32 * 1024 * 1024 }
}
