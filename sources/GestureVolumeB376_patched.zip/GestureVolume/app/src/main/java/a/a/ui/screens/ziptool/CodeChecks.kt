package a.a.ui.screens.ziptool

/**
 * Checks on new files before they go into a zip: lines that stand in for real code (placeholders left by a
 * careless copy) and unbalanced brackets in Kotlin and Java files.
 */
object CodeChecks {
        /** Files whose text is looked through for placeholders. */
        val TEXT_EXT = setOf("kt", "java", "xml", "kts", "gradle")

        /** Lines that stand in for real code: a capital-letter note in square brackets, a comment that is only dots, or a comment saying the old code goes here. */
        val PLACEHOLDERS = listOf(
            Regex("""\[(KEEP|REST OF|EXISTING|UNCHANGED|SAME AS|YOUR CODE|INSERT|PLACE)[A-Z0-9,._'/-]* [A-Z0-9 ,._'/-]*\]"""),
            Regex("""(?i)(//|/\*)\s*\.\.\.\s*((\*/)?\s*$|(existing|rest|more|other|previous|remaining|unchanged|same|omitted|code)\b)"""),
            Regex(
                """(?i)(//|/\*).*(existing\s+(code|logic|implementation)\s+(here|unchanged|remains|stays|goes)|omitted\s+for\s+brevity|keep\s+existing|rest\s+of\s+(the\s+)?(file|code|class|function|method|logic)\s+(here|unchanged|remains|stays|as\s+is|as\s+before|goes))""",
            ),
        )

    /** The first line that looks like a placeholder instead of real code, as (line number, the line), or null. */
    fun placeholderHit(text: String): Pair<Int, String>? {
        var line = 0
        for (l in text.split('\n')) {
            line++
            if (l.length > 400) continue
            for (rx in PLACEHOLDERS) {
                if (rx.containsMatchIn(l)) return line to l.trim().take(90)
            }
        }
        return null
    }

    /** Null when every bracket closes. Strings (also with ${...} inside), characters and comments are skipped. */
    fun bracketNote(t: String): String? {
        val st = ArrayList<Char>()
        val n = t.length
        var i = 0
        var mode = 0
        while (i < n) {
            val c = t[i]
            if (mode == 1) {
                when {
                    c == '\\' -> i += 2
                    c == '"' -> { mode = 0; i++ }
                    c == '$' && i + 1 < n && t[i + 1] == '{' -> { st.add('T'); mode = 0; i += 2 }
                    else -> i++
                }
                continue
            }
            if (mode == 2) {
                when {
                    t.startsWith("\"\"\"", i) -> {
                        i += 3
                        while (i < n && t[i] == '"') i++
                        mode = 0
                    }
                    c == '$' && i + 1 < n && t[i + 1] == '{' -> { st.add('R'); mode = 0; i += 2 }
                    else -> i++
                }
                continue
            }
            when {
                t.startsWith("//", i) -> {
                    while (i < n && t[i] != '\n') i++
                }
                t.startsWith("/*", i) -> {
                    var depth = 1
                    i += 2
                    while (i < n && depth > 0) {
                        if (t.startsWith("/*", i)) { depth++; i += 2 }
                        else if (t.startsWith("*/", i)) { depth--; i += 2 }
                        else i++
                    }
                }
                t.startsWith("\"\"\"", i) -> { mode = 2; i += 3 }
                c == '"' -> { mode = 1; i++ }
                c == '`' -> {
                    i++
                    while (i < n && t[i] != '`') i++
                    i++
                }
                c == '\'' -> {
                    i++
                    while (i < n && t[i] != '\'') {
                        if (t[i] == '\\') i++
                        i++
                    }
                    i++
                }
                c == '(' || c == '[' || c == '{' -> { st.add(c); i++ }
                c == ')' || c == ']' || c == '}' -> {
                    val top = if (st.isEmpty()) ' ' else st[st.size - 1]
                    if (c == '}' && (top == 'T' || top == 'R')) {
                        st.removeAt(st.size - 1)
                        mode = if (top == 'T') 1 else 2
                    } else if ((c == ')' && top == '(') || (c == ']' && top == '[') || (c == '}' && top == '{')) {
                        st.removeAt(st.size - 1)
                    } else {
                        val at = t.substring(0, minOf(i, n)).count { it == '\n' } + 1
                        return "line $at: unexpected $c"
                    }
                    i++
                }
                else -> i++
            }
        }
        return if (st.isEmpty() && mode == 0) null else "ends with ${st.size} bracket(s) still open"
    }
}
