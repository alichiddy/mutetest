package a.a.ui.screens.shell

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow
import a.a.ui.screens.strip.SwitchRow
import a.a.utils.ShellFeedback

/**
 * "When a shell shortcut ends, show its result as": any mix of the bar, a toast and a notification, in the card
 * design. Same preference keys and defaults as before (bar, barMs, toast, toastLong, notice, noticeMs).
 */
@Composable
fun ShellFeedbackDialog(onDismiss: () -> Unit) {
    val fp = ShellFeedback.prefs(LocalContext.current)
    var barOn by remember { mutableStateOf(fp.getBoolean("bar", true)) }
    var toastOn by remember { mutableStateOf(fp.getBoolean("toast", false)) }
    var toastLong by remember { mutableStateOf(fp.getBoolean("toastLong", false)) }
    var noticeOn by remember { mutableStateOf(fp.getBoolean("notice", false)) }
    var barMs by remember { mutableStateOf(fp.getInt("barMs", 3000).toString()) }
    var noticeMs by remember { mutableStateOf(fp.getInt("noticeMs", 4000).toString()) }

    ShellWindow(title = "Shortcut feedback", onBack = onDismiss) {
        CardGroup(
            title = "Bar",
            hint = "When a shell shortcut ends, its result can show in any mix: tick one, two or all three.",
        ) {
            row { sh ->
                SwitchRow(
                    title = "Show it in the bar", checked = barOn, shape = sh, icon = Icons.Filled.Visibility,
                    summary = "A bar on the screen that goes away by itself.",
                ) { barOn = it; fp.edit().putBoolean("bar", it).apply() }
            }
            if (barOn) row { sh ->
                MsRow("Bar time", barMs, sh) { v ->
                    barMs = v.filter { it.isDigit() }.take(6)
                    barMs.toIntOrNull()?.let { fp.edit().putInt("barMs", it).apply() }
                }
            }
        }
        CardGroup(title = "Toast") {
            row { sh ->
                SwitchRow(
                    title = "Show it as a toast", checked = toastOn, shape = sh, icon = Icons.Filled.Info,
                    summary = "The small message Android shows near the bottom.",
                ) { toastOn = it; fp.edit().putBoolean("toast", it).apply() }
            }
            if (toastOn) row { sh ->
                SwitchRow(
                    title = "Long toast", checked = toastLong, shape = sh,
                    summary = "Stays a little longer.",
                ) { toastLong = it; fp.edit().putBoolean("toastLong", it).apply() }
            }
        }
        CardGroup(title = "Notification") {
            row { sh ->
                SwitchRow(
                    title = "Show it as a notification", checked = noticeOn, shape = sh, icon = Icons.Filled.Notifications,
                    summary = "A notification that goes away by itself.",
                ) { noticeOn = it; fp.edit().putBoolean("notice", it).apply() }
            }
            if (noticeOn) row { sh ->
                MsRow("Notification time", noticeMs, sh) { v ->
                    noticeMs = v.filter { it.isDigit() }.take(6)
                    noticeMs.toIntOrNull()?.let { fp.edit().putInt("noticeMs", it).apply() }
                }
            }
        }
    }
}

/** A row with a number box for milliseconds (the number is kept as typed; the caller saves it). */
@Composable
private fun MsRow(label: String, value: String, shape: Shape, onChange: (String) -> Unit) {
    SettingRow(
        title = label, shape = shape, summary = "In milliseconds (1000 = one second).",
        footer = {
            OutlinedTextField(
                value = value, onValueChange = onChange, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            )
        },
    )
}
