package a.a.ui.screens.strip

/**
 * Word search shared by the pickers. Every typed word counts, in any order and anywhere in the text,
 * and spelling variants such as "wi-fi" and "wifi" are the same word. Each result is scored by how many
 * of the typed words it holds, so "wifi data" lists "toggle wifi and data mode" first and still lists
 * everything that has just "wifi" or just "data" below it.
 */
internal object SearchMatch {
    private fun squash(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** The words of a query, lower case, with punctuation dropped. */
    fun words(query: String): List<String> =
        query.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }.distinct()

    /** How many of the words appear in the text (0 = no match). */
    fun score(words: List<String>, text: String): Int {
        if (words.isEmpty()) return 0
        val plain = text.lowercase()
        val squashed = squash(text)
        return words.count { plain.contains(it) || squashed.contains(it) }
    }

    /** The items that match at least one word, the ones with most words first; all items for an empty query. */
    fun <T> filter(items: List<T>, query: String, text: (T) -> String): List<T> {
        val w = words(query)
        if (w.isEmpty()) return items
        return items.map { it to score(w, text(it)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }   // stable: equal scores keep their order
            .map { it.first }
    }
}
