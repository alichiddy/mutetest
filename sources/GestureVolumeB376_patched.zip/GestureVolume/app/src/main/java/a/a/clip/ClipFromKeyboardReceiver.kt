package a.a.clip

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import a.a.utils.DiagLog

/**
 * The LeanType A keyboard tells A what was copied. Only apps signed with A's own key can send this
 * (a signature permission guards the receiver). Nothing runs until a copy happens.
 */
class ClipFromKeyboardReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: return
        DiagLog.note("clip from keyboard len=${text.length} converted=${intent.getBooleanExtra("changed", false)}")
        ClipTools.announce(context.applicationContext, text)
    }
}
