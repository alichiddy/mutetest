package a.a.ui.screens.strip

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage

/**
 * "Move to" in the card design (full-screen window with the back arrow, like the other Cell Settings windows):
 * the folder above, if there is one, and every folder of this level that the moved cells are not in themselves.
 * [folders] holds each folder's place in the list and its name. Only the drawing is new; the moving is done by
 * the caller through [onUp] and [onInto].
 */
@Composable
fun MoveToDialog(
    count: Int,
    canGoUp: Boolean,
    folders: List<Pair<Int, String>>,
    onUp: () -> Unit,
    onInto: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AWindowPage(if (count == 1) "Move 1 cell to" else "Move $count cells to", onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup("Pick the place", hint = "Tap a folder and the cells go into it.") {
                        if (canGoUp) {
                            row { sh -> LinkRow("The folder above", "Takes them out of this folder", sh, Icons.Filled.ArrowUpward) { onUp() } }
                        }
                        folders.forEach { (place, name) ->
                            row { sh -> LinkRow(name, "Put them in this folder", sh, Icons.Filled.Folder) { onInto(place) } }
                        }
                        if (folders.isEmpty() && !canGoUp) {
                            row { sh ->
                                SettingRow(
                                    "No folder yet", sh, icon = Icons.Filled.Info,
                                    summary = "Use Make folder or + Add a folder first.",
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
