package a.a.flow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * When each script was made, added, edited, opened and run, and how many times it ran.
 * Kept by the script's permanent id (so a rename keeps it), in its own small list.
 * Read only when the Scripts window sorts, written only when something happens: nothing stays
 * in memory. Scripts from before this list existed simply have no dates ("unknown", sorted last).
 */
object FlowMeta {
    private const val KEY = "m"

    // Positions in one record.
    const val BORN = 0     // made here or arrived (time)
    const val EDITED = 1   // content last changed
    const val OPENED = 2   // last opened in the block editor
    const val ADDED = 3    // arrived from outside (import, Automate, examples, shared); 0 = made here
    const val RAN = 4      // last run
    const val RUNS = 5     // how many times it ran
    private const val SIZE = 6

    /** True while scripts are being brought in from outside, so new ones count as "added". */
    @Volatile var adding = false

    fun <T> asAdded(block: () -> T): T {
        val was = adding
        adding = true
        try { return block() } finally { adding = was }
    }

    private fun prefs(c: Context) = c.getSharedPreferences("FlowMeta", Context.MODE_PRIVATE)

    private fun read(c: Context): JSONObject =
        runCatching { JSONObject(prefs(c).getString(KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())

    private fun write(c: Context, o: JSONObject) { prefs(c).edit().putString(KEY, o.toString()).apply() }

    private fun rec(o: JSONObject, id: String): JSONArray {
        val a = o.optJSONArray(id) ?: JSONArray().also { o.put(id, it) }
        while (a.length() < SIZE) a.put(0L)
        return a
    }

    /** New scripts got these ids: stamp their birth (and "added" when they came from outside). */
    fun born(c: Context, ids: Collection<String>, added: Boolean = adding) {
        if (ids.isEmpty()) return
        runCatching {
            val o = read(c)
            val now = System.currentTimeMillis()
            for (id in ids) {
                if (o.has(id)) continue
                val a = rec(o, id)
                a.put(BORN, now)
                if (added) a.put(ADDED, now)
            }
            write(c, o)
        }
    }

    /** [idToName] is the ids list of the flows (id -> name); stamps the ones whose name is in [names]. */
    fun edited(c: Context, idToName: JSONObject, names: Collection<String>) {
        if (names.isEmpty()) return
        runCatching {
            val o = read(c)
            val now = System.currentTimeMillis()
            val want = names.toHashSet()
            idToName.keys().forEach { id -> if (idToName.optString(id) in want) rec(o, id).put(EDITED, now) }
            write(c, o)
        }
    }

    fun opened(c: Context, id: String?) {
        if (id == null) return
        runCatching { val o = read(c); rec(o, id).put(OPENED, System.currentTimeMillis()); write(c, o) }
    }

    fun ran(c: Context, id: String?) {
        if (id == null) return
        runCatching {
            val o = read(c)
            val a = rec(o, id)
            a.put(RAN, System.currentTimeMillis())
            a.put(RUNS, a.optLong(RUNS) + 1)
            write(c, o)
        }
    }

    fun forget(c: Context, ids: Collection<String>) {
        if (ids.isEmpty()) return
        runCatching { val o = read(c); ids.forEach { o.remove(it) }; write(c, o) }
    }

    /** Every record, by id. */
    fun all(c: Context): Map<String, LongArray> {
        val o = read(c)
        val out = HashMap<String, LongArray>()
        o.keys().forEach { id ->
            val a = o.optJSONArray(id) ?: return@forEach
            out[id] = LongArray(SIZE) { i -> a.optLong(i) }
        }
        return out
    }
}
