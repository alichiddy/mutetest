package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.CardWindow
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File

/**
 * Replace one file inside a zip: three boxes (the zip, the file inside it picked from a list, the new file),
 * a name, one button. Every other file is copied across untouched and the new zip is read back and checked.
 */
class ReplaceState(private val ctx: Context) {
    var zipName by mutableStateOf<String?>(null)
    var srcFile by mutableStateOf<File?>(null)
    var entries by mutableStateOf<List<String>>(emptyList())
    var target by mutableStateOf<String?>(null)
    private var targetAuto = false
    var newUri by mutableStateOf<Uri?>(null)
    var newName by mutableStateOf<String?>(null)
    var newSize by mutableStateOf(0L)
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var log by mutableStateOf("")
    var showList by mutableStateOf(false)

    val ready: Boolean get() = srcFile != null && target != null && newUri != null && outName.isNotBlank()

    fun cleanup() {
        File(ctx.cacheDir, SRC_TMP).delete()
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    /** Copies the chosen zip into the app's cache and lists the files inside it. */
    fun loadZip(u: Uri) {
        if (busy) return
        busy = true
        log = ""
        val name = ZipIo.nameOf(ctx.contentResolver, u)
        Thread {
            try {
                val f = File(ctx.cacheDir, SRC_TMP)
                ZipIo.copyToCache(ctx.contentResolver, u, f)
                val names = ZipIo.listFiles(f)
                srcFile = f
                zipName = name
                entries = names
                outName = ZipIo.stem(name) + "_updated.zip"
                target = null
                targetAuto = false
                autoMatch()
            } catch (e: Throwable) {
                log = "ZIP ERROR: could not open $name (${e.javaClass.simpleName}: ${e.message})"
            } finally {
                busy = false
            }
        }.start()
    }

    fun setNew(u: Uri) {
        newUri = u
        newName = ZipIo.nameOf(ctx.contentResolver, u)
        newSize = ZipIo.sizeOf(ctx.contentResolver, u)
        autoMatch()
    }

    fun pickTarget(path: String) {
        target = path
        targetAuto = false
        showList = false
    }

    /** When the new file's name fits exactly one file in the zip, that one is chosen for you. */
    private fun autoMatch() {
        val n = newName ?: return
        if (target != null && !targetAuto) return
        val hits = entries.filter { it.substringAfterLast('/') == n }
        if (hits.size == 1) {
            target = hits[0]
            targetAuto = true
        }
    }

    fun make() {
        val src = srcFile ?: return
        val tgt = target ?: return
        val nu = newUri ?: return
        if (busy) return
        busy = true
        log = ""
        val saveName = ZipIo.cleanName(outName, "updated")
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                val newBytes = (ctx.contentResolver.openInputStream(nu) ?: throw IllegalStateException("Could not open the new file."))
                    .use { it.readBytes() }
                val out = ZipIo.rewrite(src, tmp, mapOf(tgt to ZipIo.Blob(newBytes)))
                if (out.replaced == 0) throw IllegalStateException("$tgt was not found in the zip.")
                val sb = StringBuilder("REPLACED: $tgt\n")
                if (out.skipped > 0) sb.append("Note: ${out.skipped} repeated file name(s) in the zip were left out.\n")
                val problem = ZipIo.verify(tmp, out.written, out.expectCrc)
                if (problem != null) {
                    sb.append("ZIP ERROR: $problem\nNothing was saved.")
                } else {
                    val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
                    sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                    sb.append("ZIP integrity check passed. ${out.written} files.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.javaClass.simpleName}: ${e.message}\nNothing was saved."
            } finally {
                tmp.delete()
                busy = false
            }
        }.start()
    }

    private companion object {
        const val SRC_TMP = "zt_replace_src.zip"
        const val OUT_TMP = "zt_replace_out.zip"
    }
}

@Composable
fun ReplaceTab(s: ReplaceState) {
    val pickZip = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.loadZip(u)
    }
    val pickNew = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) s.setNew(u)
    }
    HeroCard(
        title = "Replace one file in a zip",
        text = "Pick the zip, pick the file inside it, pick the new file. A new zip is saved in Downloads and checked.",
        leading = { IconTile(Icons.Filled.Folder, lit = true) },
    )
    Column {
        GroupHeading("Pick")
        RowGroup {
            KitRow(
                title = "Zip file",
                shape = cardShape(0, 3),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = s.zipName ?: "Tap to choose",
                description = if (s.zipName != null) "${s.entries.size} files inside" else null,
                onClick = { if (!s.busy) pickZip.launch(arrayOf("*/*")) },
            )
            KitRow(
                title = "File inside the zip",
                shape = cardShape(1, 3),
                summary = s.target ?: "Tap to choose from the list",
                description = if (s.entries.isEmpty()) "Choose the zip first" else null,
                onClick = { if (!s.busy && s.entries.isNotEmpty()) s.showList = true },
            )
            KitRow(
                title = "New file",
                shape = cardShape(2, 3),
                summary = s.newName ?: "Tap to choose",
                description = if (s.newName != null) ZipIo.mb(s.newSize) else null,
                onClick = { if (!s.busy) pickNew.launch(arrayOf("*/*")) },
            )
        }
    }
    SaveAsField(s.outName) { s.outName = it }
    Button(
        onClick = { s.make() },
        enabled = s.ready && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) "Working..." else "Replace and make zip") }
    ResultBox(s.log)

    if (s.showList) {
        var query by remember { mutableStateOf("") }
        val wanted = s.newName
        val shown = remember(s.entries, query, wanted) {
            val q = query.trim()
            val hits = if (q.isEmpty()) s.entries else s.entries.filter { it.contains(q, ignoreCase = true) }
            // Files named like the new file come first.
            hits.sortedBy { if (wanted != null && it.substringAfterLast('/') == wanted) 0 else 1 }
        }
        CardWindow(title = "File inside the zip", onBack = { s.showList = false }, scroll = false) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                label = { Text("Search (${shown.size} files)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                items(shown) { path ->
                    KitRow(
                        title = path.substringAfterLast('/'),
                        shape = RoundedCornerShape(14.dp),
                        description = path.substringBeforeLast('/', "").takeIf { it.isNotEmpty() },
                        onClick = { s.pickTarget(path) },
                        trailing = null,
                    )
                }
            }
        }
    }
}
