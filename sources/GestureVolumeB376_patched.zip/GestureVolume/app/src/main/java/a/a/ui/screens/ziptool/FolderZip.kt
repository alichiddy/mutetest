package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.InputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Reads a whole folder picked with the system folder picker and packs it into a zip.
 * The folder is only ever read: nothing in it is changed, moved or replaced.
 */
object FolderZip {

    /** One file or sub-folder of the picked folder. [rel] is its path inside the folder; folders end with "/". */
    class Node(val rel: String, val docId: String, val isDir: Boolean, val size: Long, val time: Long)

    /** Everything found in the folder. */
    class Scan(val tree: Uri, val rootName: String, val nodes: List<Node>) {
        val fileCount: Int get() = nodes.count { !it.isDir }
        val folderCount: Int get() = nodes.count { it.isDir }
        val bytes: Long get() = nodes.filter { !it.isDir && it.size > 0L }.sumOf { it.size }
    }

    /** What [pack] wrote. [expectCrc] holds the checksum every file in the zip must have. */
    class Packed(val entries: Int, val expectCrc: Map<String, Long>)

    /** Walks the picked folder, sub-folders included, and lists everything in it. */
    fun scan(ctx: Context, tree: Uri): Scan {
        val cr = ctx.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        var rootName: String? = null
        runCatching {
            val rootUri = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
            cr.query(rootUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) rootName = c.getString(0)
            }
        }
        val name = (rootName ?: rootId.substringAfterLast(':').substringAfterLast('/')).replace('/', '_')
            .ifEmpty { "folder" }

        val out = ArrayList<Node>()
        val visited = HashSet<String>()
        val pending = ArrayList<Pair<String, String>>()
        pending.add(rootId to "")
        visited.add(rootId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        while (pending.isNotEmpty()) {
            val (id, prefix) = pending.removeAt(pending.lastIndex)
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            val cursor = cr.query(kids, cols, null, null, null) ?: continue
            cursor.use { c ->
                while (c.moveToNext()) {
                    val did = c.getString(0) ?: continue
                    val nm = (c.getString(1) ?: continue).replace('/', '_')
                    val mime = c.getString(2)
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    val time = if (c.isNull(4)) -1L else c.getLong(4)
                    val rel = prefix + nm
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (visited.add(did)) {
                            out.add(Node("$rel/", did, true, 0L, time))
                            pending.add(did to "$rel/")
                        }
                    } else {
                        out.add(Node(rel, did, false, size, time))
                    }
                }
            }
        }
        out.sortBy { it.rel }
        return Scan(tree, name, out)
    }

    /** Opens one file of the folder for reading, or null when the provider will not give it. */
    fun open(ctx: Context, scan: Scan, node: Node): InputStream? {
        val uri = DocumentsContract.buildDocumentUriUsingTree(scan.tree, node.docId)
        return ctx.contentResolver.openInputStream(uri)
    }

    /**
     * Writes the whole folder into the zip [out]. [prefix] ("Name/" or "") goes in front of every path.
     * A file that cannot be read stops everything, so a zip is never quietly missing something.
     * [fast] uses the quickest compression, for temporary zips that are only read back.
     */
    fun pack(
        ctx: Context,
        scan: Scan,
        out: File,
        prefix: String,
        fast: Boolean,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
    ): Packed {
        val expect = HashMap<String, Long>()
        var n = 0
        val total = scan.nodes.size
        ZipOutputStream(out.outputStream().buffered()).use { zo ->
            if (fast) zo.setLevel(Deflater.BEST_SPEED)
            val seen = HashSet<String>()
            val buf = ByteArray(ZipIo.BUF)
            if (prefix.isNotEmpty()) {
                val top = ZipEntry(prefix)
                top.method = ZipEntry.STORED
                top.size = 0L
                top.compressedSize = 0L
                top.crc = 0L
                zo.putNextEntry(top)
                zo.closeEntry()
                seen.add(prefix)
                n++
            }
            for (node in scan.nodes) {
                val name = prefix + node.rel
                if (!seen.add(name)) continue
                val e = ZipEntry(name)
                if (node.time > 0L) e.time = node.time
                if (node.isDir) {
                    e.method = ZipEntry.STORED
                    e.size = 0L
                    e.compressedSize = 0L
                    e.crc = 0L
                    zo.putNextEntry(e)
                    zo.closeEntry()
                } else {
                    val input = open(ctx, scan, node) ?: throw IllegalStateException("Could not read ${node.rel}.")
                    val crc = CRC32()
                    e.method = ZipEntry.DEFLATED
                    zo.putNextEntry(e)
                    input.use { i ->
                        while (true) {
                            val r = i.read(buf)
                            if (r < 0) break
                            crc.update(buf, 0, r)
                            zo.write(buf, 0, r)
                        }
                    }
                    zo.closeEntry()
                    expect[name] = crc.value
                }
                n++
                if (n % 25 == 0) onProgress(n, total)
            }
        }
        onProgress(n, total)
        return Packed(n, expect)
    }
}
