package a.a.share

import android.app.Activity
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.widget.Toast
import a.a.utils.ShizukuShell
import java.io.File

/**
 * "A Delete" in the share / open-with sheet of any app: deletes the file(s) that were shared or opened
 * at once, without asking, and says on a toast what was deleted and what was not (with the reason).
 * It tries, in this order: the file itself by its path (when A may touch it), the app that owns it
 * (its document provider), and last Shizuku (rm on the real path). A file removed by path is also
 * taken out of the media store, so Gallery and Files do not keep showing it.
 * Nothing stays open afterwards.
 */
class DeleteFileActivity : Activity() {
    private class Target(val uri: Uri, val name: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val targets = collect(intent)
        if (targets.isEmpty()) { finishWith("Nothing to delete."); return }
        deleteAll(targets)
    }

    @Suppress("DEPRECATION")
    private fun collect(i: Intent): List<Target> {
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
        }
        return uris.map { Target(it, FilePaths.displayName(this, it) ?: "file") }
    }

    private fun deleteAll(targets: List<Target>) {
        val app = applicationContext
        Thread {
            val gone = ArrayList<String>()
            val kept = ArrayList<String>()
            for (t in targets) {
                // null = deleted, otherwise the reason the file stayed.
                val why = try { deleteOne(t.uri) } catch (e: Throwable) { "it failed (" + (e.message ?: e.javaClass.simpleName) + ")" }
                if (why == null) gone += t.name else kept += t.name + " (" + why + ")"
            }
            var report = if (gone.isNotEmpty()) "Deleted: " + gone.joinToString(", ") else ""
            if (kept.isNotEmpty()) {
                if (report.isNotEmpty()) report += "\n"
                report += "Could not delete: " + kept.joinToString(", ")
            }
            runOnUiThread { finishWith(report.ifEmpty { "Nothing to delete." }, app) }
        }.start()
    }

    private fun finishWith(report: String, app: android.content.Context = applicationContext) {
        Toast.makeText(app, report, Toast.LENGTH_LONG).show()
        finish()
    }

    /** Deletes one file. Returns null when it is gone, otherwise a short reason why it is still there. */
    private fun deleteOne(uri: Uri): String? {
        val path = FilePaths.pathOf(uri) ?: dataPath(uri)
        // 1. The file itself, when A may touch it.
        if (path != null) {
            val f = File(path)
            if (f.isFile && f.delete()) { forget(path); return null }
        }
        // 2. The app that owns it.
        if (uri.scheme == "content") {
            val viaDoc = runCatching {
                DocumentsContract.isDocumentUri(this, uri) && DocumentsContract.deleteDocument(contentResolver, uri)
            }.getOrDefault(false)
            if (viaDoc) return null
            val viaProvider = runCatching { contentResolver.delete(uri, null, null) > 0 }.getOrDefault(false)
            if (viaProvider) return null
        }
        // 3. Shizuku, only on a real file path in shared storage (rm without -r never removes a folder).
        val shizuku = ShizukuShell.isReady()
        if (path != null && shizuku &&
            (path.startsWith("/storage/") || path.startsWith("/sdcard/") || path.startsWith("/data/media/"))
        ) {
            val q = "'" + path.replace("'", "'\\''") + "'"
            // rm -f also says 0 when it removed nothing, so the file must really be gone.
            val code = runCatching { ShizukuShell.run("rm -f $q && [ ! -e $q ]") { } }.getOrDefault(-1)
            if (code == 0) { forget(path); return null }
            return "Shizuku could not remove it"
        }
        return when {
            path != null && !shizuku && Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager() ->
                "A needs All files access, or Shizuku running"
            path != null -> "Android did not allow it"
            else -> "the app that shared it does not allow deleting"
        }
    }

    /** Takes a deleted path out of the media store, so Gallery and Files stop listing it. */
    private fun forget(path: String) {
        runCatching { MediaScannerConnection.scanFile(applicationContext, arrayOf(path), null, null) }
    }

    /** The real path some providers (the media store) still give under "_data". */
    private fun dataPath(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()?.takeIf { it.startsWith("/") }
}
