package a.a

import android.app.Application
import a.a.utils.DiagLog
import dagger.hilt.android.HiltAndroidApp
import a.a.strip.AutoBackup
import a.a.utils.VolumeBoost

/** The application class. Ads, billing and the Play Store prompts are gone from this build. */
@HiltAndroidApp
class GestureApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DiagLog.processStarted(this)
        a.a.strip.SettingsBackup.init(this)
        AutoBackup.refresh(this)
        VolumeBoost.configure(this)
        a.a.strip.TextReaderControl.safetyOff(this)
    }
}
