package a.a.strip

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.ImageView
import a.a.service.GestureAccessibilityService
import a.a.service.OverlayRuntime
import a.a.utils.HandlerActions

/**
 * Quick Settings tiles (Wi-Fi, Bluetooth, torch...) pressed the way a widget's tile is: the cell holds the
 * tile's name and place, and A finds that tile in the shade and clicks it. No Shizuku.
 *
 * Android gives an app no way to click another app's tile without the shade, so the accessibility service
 * opens Quick Settings, finds the tile in the SystemUI window, clicks it and closes the shade again. While
 * this runs, a picture of the screen as it was is drawn over everything (when the phone allows a screenshot,
 * Android 11+), so the shade is not seen. Nothing runs and nothing is kept between presses.
 *
 * Only the Quick Settings window is read, only during a press or a grab, and only the tiles' names.
 * Tile names are matched without their state ("Wi-Fi" for "Wi-Fi, On"); if the tile moved, it is found by
 * its name, the shade's pages are turned, and the new place is saved ([WidgetTiles.savePlace]).
 */
object QsTiles {
    const val PKG = "com.android.systemui"
    private const val PAGE = 1000

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var busy = false
    private var gen = 0
    private var cover: View? = null

    private fun svc() = OverlayRuntime.accessibilityService

    // ---- reading tiles ----

    private fun gather(n: AccessibilityNodeInfo, depth: Int, out: MutableList<String>) {
        n.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { out += it }
        if (depth >= 3) return
        for (i in 0 until n.childCount) n.getChild(i)?.let { gather(it, depth + 1, out) }
    }

    private fun descName(n: AccessibilityNodeInfo): String =
        n.contentDescription?.toString().orEmpty().split(',', '\n').firstOrNull().orEmpty().trim()

    /** The tile's name: its label text, else the first part of its description. */
    fun label(n: AccessibilityNodeInfo): String {
        val texts = ArrayList<String>()
        gather(n, 0, texts)
        texts.firstOrNull { t -> t.any { it.isLetter() } }?.let { return it.take(60) }
        return descName(n).take(60)
    }

    private fun matches(n: AccessibilityNodeInfo, key: String): Boolean {
        if (descName(n).equals(key, ignoreCase = true)) return true
        val texts = ArrayList<String>()
        gather(n, 0, texts)
        return texts.any { it.equals(key, ignoreCase = true) }
    }

    /** Every pressable tile of the shade as it shows now, in the order they are drawn. */
    private fun tilesOf(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 14) return
            if (n.isClickable && n.isVisibleToUser && n.className?.toString()?.contains("EditText") != true && label(n).isNotBlank()) {
                out += n
                return
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return out
    }

    /** The tile a tapped node belongs to: it or the nearest parent that can be clicked. */
    private fun tileOf(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var c: AccessibilityNodeInfo? = n
        var up = 0
        while (c != null && up < 5) {
            if (c.isClickable && label(c).isNotBlank()) return c
            c = c.parent
            up++
        }
        return null
    }

    // ---- grabbing a tile ----

    /** Opens Quick Settings; the next tile the user taps is noted and [onDone] gets its name, place and description. */
    fun grab(ctx: Context, onDone: (String, Int, String) -> Unit): Boolean {
        val app = ctx.applicationContext
        val s = svc() ?: run {
            WidgetFloat.toast(app, "Turn on A's accessibility service first")
            return false
        }
        var done = false
        fun stop() { done = true; s.setQsGrab(null) }
        s.setQsGrab { node ->
            if (done) return@setQsGrab
            val tile = tileOf(node)
            if (tile == null) {
                WidgetFloat.toast(app, "Tap right on a tile")
                return@setQsGrab
            }
            val key = label(tile)
            val root = s.rootInActiveWindow
            val idx = if (root != null && root.packageName?.toString() == PKG) tilesOf(root).indexOfFirst { it == tile } else -1
            val details = "Quick Settings tile: $key\nDescription: " + tile.contentDescription +
                "\nId: " + tile.viewIdResourceName + "\nPlace: " + idx.coerceAtLeast(0)
            stop()
            // Close the shade (A's window is behind it), then hand the tile over.
            ui.postDelayed({
                s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                ui.postDelayed({ onDone(key, idx.coerceAtLeast(0), details) }, 450)
            }, 250)
        }
        s.performSystemAction(HandlerActions.QUICK_SETTINGS)
        WidgetFloat.toast(app, "Tap the tile you want (it will also switch once)")
        ui.postDelayed({ if (!done) { stop(); WidgetFloat.toast(app, "No tile was tapped") } }, 60000)
        return true
    }

    // ---- pressing a tile ----

    fun press(ctx: Context, key: String, place: Int, showMs: Int, findMs: Int, tid: String, covered: Boolean): Boolean {
        val app = ctx.applicationContext
        val s = svc() ?: run {
            WidgetFloat.toast(app, "Turn on A's accessibility service first")
            WidgetFloat.pressState = 3
            return false
        }
        if (busy) return false
        busy = true
        val g = ++gen
        WidgetFloat.pressState = 1
        var started = false
        fun go() {
            if (started) return
            started = true
            ui.post { runCatching { openAndPress(app, s, key, place, showMs, findMs.coerceAtLeast(500), tid) }.onFailure { finish(s, 3) } }
        }
        if (covered && Build.VERSION.SDK_INT >= 30) {
            // Cover first (a picture of the screen as it is), then open the shade under it.
            ui.postDelayed({ go() }, 900)
            runCatching { shoot(s) { go() } }.onFailure { go() }
        } else go()
        // Whatever happens, the cover never stays.
        ui.postDelayed({ if (busy && gen == g) finish(s, WidgetFloat.pressState.takeIf { it == 2 } ?: 3) }, (findMs.coerceAtLeast(500) + maxOf(showMs, 0) + 8000).toLong())
        return true
    }

    @androidx.annotation.RequiresApi(30)
    private fun shoot(s: GestureAccessibilityService, then: () -> Unit) {
        s.takeScreenshot(Display.DEFAULT_DISPLAY, s.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                runCatching {
                    val hb = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    hb.close()
                    if (bmp != null) showCover(s, bmp)
                }
                then()
            }
            override fun onFailure(errorCode: Int) { then() }
        })
    }

    private fun openAndPress(app: Context, s: GestureAccessibilityService, key: String, place: Int, showMs: Int, limit: Int, tid: String) {
        s.performSystemAction(HandlerActions.QUICK_SETTINGS)
        val start = SystemClock.uptimeMillis() + 400   // the shade needs a moment to open
        var nextScroll = start + 1500
        var page = 0
        var stuck = 0
        val r = object : Runnable {
            override fun run() {
                if (!busy) return
                val now = SystemClock.uptimeMillis()
                val root = s.rootInActiveWindow
                if (root != null && root.packageName?.toString() == PKG) {
                    val tiles = tilesOf(root)
                    val hit = pick(tiles, key, place % PAGE)
                    if (hit != null) {
                        val found = page * PAGE + tiles.indexOf(hit)
                        if (tid.isNotEmpty() && key.isNotBlank() && found != place && tiles.count { matches(it, key) } == 1) {
                            runCatching { WidgetTiles.savePlace(app, tid, found) }
                        }
                        if (!clickNode(hit)) { finish(s, 3, "That tile could not be pressed"); return }
                        WidgetFloat.pressState = 2
                        // Let the switch happen, then close the shade as the cell asked.
                        ui.postDelayed({ closeShade(s, showMs) }, 350)
                        return
                    }
                    if (now >= nextScroll && tiles.isNotEmpty()) {
                        if (turnPage(tiles.first())) { page++; stuck = 0 } else stuck++
                        nextScroll = now + 800
                        if (stuck >= 2) { finish(s, 3, "That tile was not found in Quick Settings"); return }
                    }
                }
                if (now - start >= limit) { finish(s, 3, "That tile was not found in Quick Settings"); return }
                ui.postDelayed(this, 150)
            }
        }
        ui.postDelayed(r, 400)
    }

    private fun pick(tiles: List<AccessibilityNodeInfo>, key: String, idx: Int): AccessibilityNodeInfo? {
        if (key.isBlank()) return tiles.getOrNull(idx)
        val m = tiles.filter { matches(it, key) }
        return m.firstOrNull { tiles.indexOf(it) == idx } ?: m.firstOrNull()
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var up = 0
        while (c != null && up < 4) {
            if (c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            up++
        }
        return false
    }

    /** Turns the shade's tile pages forward: the scrollable parent of a tile. */
    private fun turnPage(tile: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = tile.parent
        var up = 0
        while (c != null && up < 8) {
            if (c.isScrollable && c.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true
            c = c.parent
            up++
        }
        return false
    }

    /** showMs > 0: close after that long; 0: at once; below 0: leave the shade open. */
    private fun closeShade(s: GestureAccessibilityService, showMs: Int) {
        if (showMs < 0) { finish(s, 2); return }
        ui.postDelayed({
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            // Some phones keep the panel open after one Back.
            ui.postDelayed({
                val root = s.rootInActiveWindow
                if (root != null && root.packageName?.toString() == PKG) s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                ui.postDelayed({ finish(s, 2) }, 350)
            }, 450)
        }, showMs.coerceAtLeast(0).toLong())
    }

    private fun finish(s: GestureAccessibilityService, state: Int, message: String? = null) {
        if (message != null) {
            WidgetFloat.toast(s, message)
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        }
        WidgetFloat.pressState = state
        ui.postDelayed({ hideCover(s); busy = false }, if (message != null) 450L else 0L)
    }

    // ---- the cover ----

    private fun showCover(s: GestureAccessibilityService, bmp: Bitmap) {
        hideCover(s)
        val v = ImageView(s)
        v.setImageBitmap(bmp)
        v.scaleType = ImageView.ScaleType.FIT_XY
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE,
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        val wm = s.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (runCatching { wm.addView(v, lp) }.isSuccess) cover = v
    }

    private fun hideCover(s: GestureAccessibilityService) {
        val v = cover ?: return
        cover = null
        runCatching { (s.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) }
    }
}
