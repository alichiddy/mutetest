package a.a.ui.screens.ziptool

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import a.a.ui.components.GroupHeading
import a.a.ui.components.HeroCard
import a.a.ui.components.IconTile
import a.a.ui.components.KitRow
import a.a.ui.components.RowGroup
import a.a.ui.components.cardShape
import a.a.ui.motion.Button
import java.io.File

/**
 * Zip a whole folder: pick the folder, press the button, and a new zip of everything inside it (sub-folders
 * and empty folders included) is saved in Downloads. The folder itself is only read, nothing in it is changed
 * or replaced. The zip is read back and every file's checksum is checked before it is saved.
 */
class FolderState(private val ctx: Context) {
    var scan by mutableStateOf<FolderZip.Scan?>(null)
    var folderName by mutableStateOf<String?>(null)
    var wrapFolder by mutableStateOf(true)
    var outName by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var log by mutableStateOf("")

    val ready: Boolean get() = scan != null && outName.isNotBlank()

    fun cleanup() {
        File(ctx.cacheDir, OUT_TMP).delete()
    }

    /** Lists everything inside the picked folder, so you can see what will be zipped before it is. */
    fun load(tree: Uri) {
        if (busy) return
        busy = true
        log = ""
        status = "Reading the folder..."
        Thread {
            try {
                val sc = FolderZip.scan(ctx, tree)
                if (sc.fileCount == 0) throw IllegalStateException("The folder has no files in it.")
                scan = sc
                folderName = sc.rootName
                outName = sc.rootName + ".zip"
            } catch (e: Throwable) {
                scan = null
                folderName = null
                log = "FOLDER ERROR: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                status = ""
                busy = false
            }
        }.start()
    }

    fun make() {
        val sc = scan ?: return
        if (busy) return
        busy = true
        log = ""
        val saveName = ZipIo.cleanName(outName, sc.rootName)
        val prefix = if (wrapFolder) sc.rootName + "/" else ""
        Thread {
            val tmp = File(ctx.cacheDir, OUT_TMP)
            try {
                status = "Zipping..."
                val packed = FolderZip.pack(ctx, sc, tmp, prefix, fast = false) { done, total ->
                    status = "Zipping $done of $total..."
                }
                status = "Checking the zip..."
                val problem = ZipIo.verify(tmp, packed.entries, packed.expectCrc)
                val sb = StringBuilder()
                sb.append("ZIPPED: ${sc.rootName}\n")
                sb.append("${sc.fileCount} files, ${sc.folderCount} folders (${ZipIo.size(sc.bytes)} before compressing)\n")
                if (problem != null) {
                    sb.append("ZIP ERROR: $problem\nNothing was saved.")
                } else {
                    val where = ZipIo.saveToDownloads(ctx, tmp, saveName)
                    sb.append("Created: $where (${ZipIo.mb(tmp.length())})\n")
                    sb.append("Read back and checked. The folder was not changed.")
                }
                log = sb.toString()
            } catch (e: Throwable) {
                log = "ZIP ERROR: ${e.message ?: e.javaClass.simpleName}\nNothing was saved."
            } finally {
                tmp.delete()
                status = ""
                busy = false
            }
        }.start()
    }

    private companion object {
        const val OUT_TMP = "zt_folder_out.zip"
    }
}

@Composable
fun FolderTab(s: FolderState) {
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) s.load(u)
    }
    val sc = s.scan
    HeroCard(
        title = "Zip a whole folder",
        text = "Pick a folder. Everything inside it, sub-folders too, goes into a new zip in Downloads. Nothing in the folder is changed or replaced.",
        leading = { IconTile(Icons.Filled.Folder, lit = true) },
    )
    Column {
        GroupHeading("Folder")
        RowGroup {
            KitRow(
                title = "Folder to zip",
                shape = cardShape(0, 2),
                leading = { IconTile(Icons.Filled.Folder) },
                summary = s.folderName ?: "Tap to choose",
                description = if (sc != null) "${sc.fileCount} files, ${sc.folderCount} folders, ${ZipIo.size(sc.bytes)}" else null,
                onClick = { if (!s.busy) pickFolder.launch(null) },
            )
            KitRow(
                title = "Keep the folder name inside the zip",
                shape = cardShape(1, 2),
                description = if (s.wrapFolder) "The zip opens to one folder named ${s.folderName ?: "like this"}" else "The files sit at the top of the zip",
                onClick = { if (!s.busy) s.wrapFolder = !s.wrapFolder },
                trailing = { Switch(checked = s.wrapFolder, onCheckedChange = { if (!s.busy) s.wrapFolder = it }) },
            )
        }
    }
    SaveAsField(s.outName) { s.outName = it }
    Button(
        onClick = { s.make() },
        enabled = s.ready && !s.busy,
        modifier = Modifier.fillMaxWidth(),
    ) { Text(if (s.busy) (s.status.ifEmpty { "Working..." }) else "Zip the folder") }
    ResultBox(s.log)
}
