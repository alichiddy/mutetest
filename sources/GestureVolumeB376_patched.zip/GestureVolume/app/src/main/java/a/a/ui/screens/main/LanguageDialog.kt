package a.a.ui.screens.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import a.a.R
import a.a.ui.components.CardWindow
import a.a.ui.motion.Button
import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.strip.CardGroup
import a.a.ui.screens.strip.SettingRow

data class LanguageOption(val code: String, val nameRes: Int)

/** The language choice in the card design: one row per language with a round mark, Confirm under it (back arrow = Cancel). */
@Composable
fun LanguageDialog(
    currentLanguage: String,
    onDismiss: () -> Unit,
    onLanguageSelect: (String) -> Unit
) {
    val options = listOf(
        LanguageOption("en", R.string.lang_english),
        LanguageOption("ar", R.string.lang_arabic)
    )

    var selectedOption by remember { mutableStateOf(currentLanguage) }

    CardWindow(title = stringResource(R.string.choose_language), onBack = onDismiss) {
        CardGroup(title = "Pick one") {
            options.forEach { option ->
                row { sh ->
                    SettingRow(
                        title = stringResource(option.nameRes), shape = sh,
                        onClick = { selectedOption = option.code },
                        trailing = { RadioButton(selected = option.code == selectedOption, onClick = null) },
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text(stringResource(R.string.cancel)) }
            Button(
                onClick = {
                    onLanguageSelect(selectedOption)
                    onDismiss()
                },
                modifier = Modifier.weight(1f),
            ) { Text(stringResource(R.string.confirm)) }
        }
    }
}
