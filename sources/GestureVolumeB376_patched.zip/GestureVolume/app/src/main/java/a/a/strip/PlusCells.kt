package a.a.strip

import android.content.SharedPreferences

/**
 * The cells window's "+" options, read from one window's settings (the main slider's or a segment's own):
 *  - "+ in empty cells": blank cells show a "+"; a tap (in the editing window) or a release (in the live window) on one opens its editing window.
 *  - "Hold a cell to edit it": the thumb resting on a cell opens its editing window. Independent of the "+ in empty cells" option.
 *    The user picks where it works, any of: defined cells, blank cells, empty space (the window's space that is not on a cell; there a new
 *    cell is added when its editing window is saved). The hold time is the system's or one of the user's own.
 *  - "+ after the last cell": one more slot after the last cell; it adds a blank cell and opens its editing window.
 * Each choice is a set of independent on/off buttons (there is no "Both" button: both buttons on = both; a button off = off there):
 *  - scope: "Main cells window" and "Folders" (prefs <key>Main / <key>Folders).
 *  - where, for the last-cell "+": "From a gesture (like Slide-in)" and "In the cells editing window" (prefs stripPlusEndGesture / stripPlusEndEditor).
 *  - hold time: "System's default" on = the system's; off = the user's own (pref stripHoldOwn is the inverse).
 * Settings saved by older builds (the int stripPlusEmptyScope / stripPlusEndScope / stripPlusEndWhere, 0 = both) are still read until the
 * new button is touched.
 */
object PlusCells {
    /** The hold time the user's own setting starts at, in milliseconds. */
    const val HOLD_MS_DEFAULT = 500
    const val HOLD_MS_MAX = 10000

    /** One on/off button: its own pref if it was ever set, else what the older int setting [legacyKey] said ([legacyOn] tells for which values). */
    private fun flag(sp: SharedPreferences, key: String, legacyKey: String, legacyOn: (Int) -> Boolean): Boolean =
        if (sp.contains(key)) sp.getBoolean(key, true) else legacyOn(sp.getInt(legacyKey, 0))

    /** Old scope values: 0 = both, 1 = main window only, 2 = folders only. */
    fun scopeMain(sp: SharedPreferences, prefix: String): Boolean = flag(sp, prefix + "Main", prefix + "Scope") { it == 0 || it == 1 }
    fun scopeFolders(sp: SharedPreferences, prefix: String): Boolean = flag(sp, prefix + "Folders", prefix + "Scope") { it == 0 || it == 2 }

    /** Old where values: 0 = both, 1 = only from a gesture, 2 = only in the editing window. */
    fun endGesture(sp: SharedPreferences): Boolean = flag(sp, "stripPlusEndGesture", "stripPlusEndWhere") { it == 0 || it == 1 }
    fun endEditor(sp: SharedPreferences): Boolean = flag(sp, "stripPlusEndEditor", "stripPlusEndWhere") { it == 0 || it == 2 }

    const val PREFIX_EMPTY = "stripPlusEmpty"
    const val PREFIX_END = "stripPlusEnd"

    private fun inScope(sp: SharedPreferences, prefix: String, folder: Boolean) =
        if (folder) scopeFolders(sp, prefix) else scopeMain(sp, prefix)

    /** Whether blank cells show a "+" in the main window ([folder] false) or in a folder's window. */
    fun empty(sp: SharedPreferences, folder: Boolean): Boolean =
        sp.getBoolean("stripPlusEmpty", false) && inScope(sp, PREFIX_EMPTY, folder)

    /** Whether the slot after the last cell shows a "+", in the live window ([gesture] true) or in the editing window. */
    fun end(sp: SharedPreferences, folder: Boolean, gesture: Boolean): Boolean {
        if (!sp.getBoolean("stripPlusEnd", false)) return false
        if (!inScope(sp, PREFIX_END, folder)) return false
        return if (gesture) endGesture(sp) else endEditor(sp)
    }

    /** Whether resting on a cell opens its editing window (the hold option). */
    fun hold(sp: SharedPreferences): Boolean = sp.getBoolean("stripHoldEdit", false)

    /** The hold works on defined cells (cells with an action; folders never count). */
    fun holdCells(sp: SharedPreferences): Boolean = sp.getBoolean("stripHoldCells", true)

    /** The hold works on blank cells. */
    fun holdBlank(sp: SharedPreferences): Boolean = sp.getBoolean("stripHoldBlank", true)

    /** The hold works on the empty space of the window (not on a cell): it starts a new cell. */
    fun holdSpace(sp: SharedPreferences): Boolean = sp.getBoolean("stripHoldSpace", false)

    /** The hold time in milliseconds: the system's ([systemMs]) unless the user set their own. */
    fun holdMs(sp: SharedPreferences, systemMs: Int): Int =
        if (sp.getBoolean("stripHoldOwn", false)) sp.getInt("stripHoldMs", HOLD_MS_DEFAULT).coerceIn(50, HOLD_MS_MAX) else systemMs
}
