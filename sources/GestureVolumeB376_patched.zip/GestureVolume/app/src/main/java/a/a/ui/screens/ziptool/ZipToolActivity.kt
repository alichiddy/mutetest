package a.a.ui.screens.ziptool

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import a.a.ui.components.AWindow
import a.a.ui.components.AWindowPage
import a.a.ui.components.ChoiceChip

/**
 * Zip tools: one window for everything done to zips and project folders, one tab each.
 *
 *  - Replace one: swap one file inside a zip for a new file.
 *  - Extract files: take chosen files out of a zip, saved as folders or as a new zip.
 *  - Patch several: replace many files inside a project zip at once.
 *  - Rename app: change the package name and app name inside a project zip.
 *  - Zip a folder: zip a whole folder into a new zip, changing nothing in it.
 *  - Compare and merge: compare two zips or folders, see what differs, and choose file by file what to take.
 *
 * Every tab saves a new zip in Downloads, reads it back and checks it, and never changes what you picked.
 * Nothing runs or is held in memory until this window is open.
 */
class ZipToolActivity : ComponentActivity() {
    private enum class Mode(val tab: String, val key: String) {
        REPLACE("Replace one", "replace"),
        EXTRACT("Extract files", "extract"),
        PATCH("Patch several", "patch"),
        RENAME("Rename app", "rename"),
        FOLDER("Zip a folder", "folder"),
        MERGE("Compare & merge", "merge"),
    }

    private var mode by mutableStateOf(Mode.REPLACE)

    private val replace by lazy { ReplaceState(applicationContext) }
    private val extract by lazy { ExtractState(applicationContext) }
    private val patch by lazy { PatchState(applicationContext) }
    private val rename by lazy { RenameState(applicationContext) }
    private val folder by lazy { FolderState(applicationContext) }
    private val merge by lazy { MergeState(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modeFrom(intent)
        setContent {
            AWindow {
                AWindowPage("Zip tools", onBack = { finish() }) { pad ->
                    Column(
                        Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                            .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            for (m in Mode.entries) {
                                ChoiceChip(m.tab, mode == m, onClick = { mode = m })
                            }
                        }
                        when (mode) {
                            Mode.REPLACE -> ReplaceTab(replace)
                            Mode.EXTRACT -> ExtractTab(extract)
                            Mode.PATCH -> PatchTab(patch)
                            Mode.RENAME -> RenameTab(rename)
                            Mode.FOLDER -> FolderTab(folder)
                            Mode.MERGE -> MergeTab(merge)
                        }
                    }
                }
            }
        }
    }

    /** The Rename and Patch shortcuts saved before the tools were merged open this window on their own tab. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        modeFrom(intent)
    }

    private fun modeFrom(i: Intent?) {
        val key = i?.getStringExtra(EXTRA_MODE) ?: return
        Mode.entries.firstOrNull { it.key == key }?.let { mode = it }
    }

    override fun onDestroy() {
        if (isFinishing) {
            replace.cleanup()
            extract.cleanup()
            patch.cleanup()
            rename.cleanup()
            folder.cleanup()
            merge.cleanup()
        }
        super.onDestroy()
    }

    companion object {
        /** Which tab to open: replace, extract, patch, rename, folder or merge. */
        const val EXTRA_MODE = "zipToolMode"
    }
}
