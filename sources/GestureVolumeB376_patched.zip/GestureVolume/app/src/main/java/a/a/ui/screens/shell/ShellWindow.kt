package a.a.ui.screens.shell

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.runtime.Composable
import a.a.ui.components.CardWindow

/**
 * A full-screen card window above the Shell screen: the same top bar as the Cells window (back arrow = close),
 * then the cards. [scroll] is false for a window that holds its own list (the history), which scrolls by itself.
 */
@Composable
internal fun ShellWindow(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    scroll: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) = CardWindow(title, onBack, actions, scroll, content)
