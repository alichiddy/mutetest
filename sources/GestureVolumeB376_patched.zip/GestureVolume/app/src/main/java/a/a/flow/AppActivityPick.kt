package a.a.flow

import a.a.ui.motion.OutlinedButton
import a.a.ui.screens.apps.AllAppsPickActivity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** One activity of an app, for the list under the Class box. */
internal class ActivityRow(val cls: String, val label: String, val exported: Boolean, val launcher: Boolean, val home: Boolean)

/** A class name as typed (".ui.Main" is short for the app's own package) written out in full. */
internal fun fullClass(pkg: String, cls: String): String =
    if (cls.startsWith(".")) pkg + cls else if (!cls.contains('.')) "$pkg.$cls" else cls

/** The intent that starts exactly this activity: MAIN + LAUNCHER with the component, so A's normal start (Shizuku `am start`) is used. */
internal fun exactIntent(pkg: String, cls: String): Intent =
    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(pkg, fullClass(pkg, cls)))

/** Every activity the app declares: launcher ones first, then home ones, then the rest by name. Blocking. */
private fun activitiesOf(pm: PackageManager, pkg: String): List<ActivityRow> {
    val infos = runCatching {
        @Suppress("DEPRECATION")
        pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES or PackageManager.MATCH_DISABLED_COMPONENTS).activities
    }.getOrNull().orEmpty().toList()
    fun names(cat: String): Set<String> = runCatching {
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat).setPackage(pkg), 0).map { it.activityInfo.name }.toSet()
    }.getOrDefault(emptySet())
    val launchers = names(Intent.CATEGORY_LAUNCHER)
    val homes = names(Intent.CATEGORY_HOME)
    return infos.map { ai ->
        ActivityRow(
            ai.name, runCatching { ai.loadLabel(pm).toString() }.getOrDefault(""),
            ai.exported, ai.name in launchers, ai.name in homes,
        )
    }.sortedWith(compareBy({ !it.launcher }, { !it.home }, { it.cls }))
}

/**
 * One card for "Open app" and "Send intent": a button that opens the All apps window (its four filters)
 * and fills the Package, a Class box, and below them the activities of that app (tap one to fill the Class).
 * Package and Class stay editable by hand before and after picking. Nothing is read until the card is on screen.
 * [onChange] gets the package, the class ("" = the app's normal launcher entry) and whether the app was just
 * chosen from the All apps window (then whatever was there before is replaced).
 */
@Composable
internal fun AppAndClassCard(
    activity: ComponentActivity, pkg: String, cls: String,
    onChange: (pkg: String, cls: String, fresh: Boolean) -> Unit,
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = r.data?.getStringExtra("pkg").orEmpty()
        if (r.resultCode == android.app.Activity.RESULT_OK && p.isNotEmpty()) onChange(p, "", true)
    }
    var filter by remember { mutableStateOf("") }
    val rows by produceState<List<ActivityRow>?>(null, pkg) {
        value = null
        value = if (pkg.isBlank()) emptyList() else withContext(Dispatchers.Default) { activitiesOf(activity.packageManager, pkg.trim()) }
    }
    val label = remember(pkg) {
        if (pkg.isBlank()) "" else runCatching {
            activity.packageManager.getApplicationLabel(activity.packageManager.getApplicationInfo(pkg.trim(), 0)).toString()
        }.getOrDefault("")
    }
    FormCard("App and activity") {
        OutlinedButton(onClick = {
            runCatching { picker.launch(Intent(activity, AllAppsPickActivity::class.java)) }
        }) { Text(if (pkg.isBlank()) "Choose an app (All apps window)" else "Choose another app (All apps window)") }
        OutlinedTextField(pkg, { onChange(it, cls, false) }, label = { Text("Package") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (label.isNotEmpty()) FormHint(label)
        OutlinedTextField(cls, { onChange(pkg, it, false) }, label = { Text("Class (empty = the app's normal start)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        FormHint("Both boxes can be typed or changed by hand. A class starting with a dot is short for the app's own package.")
        if (pkg.isNotBlank()) {
            val all = rows
            if (all == null) FormHint("Reading the activities...")
            else if (all.isEmpty()) FormHint("No activities found for this package (type the class by hand if you know it).")
            else {
                OutlinedTextField(filter, { filter = it }, label = { Text("Filter the ${all.size} activities") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                val words = filter.trim().lowercase().split(' ').filter { it.isNotEmpty() }
                val shown = if (words.isEmpty()) all else all.filter { r -> (r.cls + " " + r.label).lowercase().let { h -> words.all { h.contains(it) } } }
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 260.dp)) {
                    items(shown, key = { it.cls }) { r ->
                        Column(Modifier.fillMaxWidth().clickable { onChange(pkg, r.cls, false) }.padding(vertical = 6.dp)) {
                            Text(
                                (if (r.cls.startsWith(pkg)) r.cls.removePrefix(pkg) else r.cls).ifEmpty { r.cls },
                                fontSize = 13.sp,
                                color = if (fullClass(pkg, cls) == r.cls) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            )
                            val tags = listOfNotNull(
                                r.label.takeIf { it.isNotBlank() && it != r.cls }, "launcher".takeIf { r.launcher }, "home".takeIf { r.home },
                                "not exported".takeIf { !r.exported },
                            )
                            if (tags.isNotEmpty()) Text(tags.joinToString("  -  "), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
