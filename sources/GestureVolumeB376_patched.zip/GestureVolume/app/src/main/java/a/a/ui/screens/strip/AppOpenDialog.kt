package a.a.ui.screens.strip

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.ui.components.AWindowPage
import a.a.ui.motion.Button

/**
 * The question after an app that is on has been picked, in the card design (full-screen window with the back arrow,
 * back = Cancel): stay open, or go back after a time. [onOk] gets the time in milliseconds, or -1 for "stay open",
 * the same values the dialog gave before (1500 ms is where the time starts).
 */
@Composable
internal fun AppOpenDialog(appLabel: String, onOk: (Int) -> Unit, onDismiss: () -> Unit) {
    var goBack by remember { mutableStateOf(false) }
    var ms by remember { mutableStateOf(1500) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AWindowPage(appLabel, onBack = onDismiss) { pad ->
                Column(
                    Modifier.fillMaxSize().padding(pad).padding(horizontal = 12.dp)
                        .verticalScroll(rememberScrollState()).padding(bottom = 24.dp),
                ) {
                    CardGroup("After it opens", hint = "What happens once this app is on the screen.") {
                        row { sh ->
                            SettingRow(
                                title = "Stay open", shape = sh, icon = Icons.Filled.Visibility, lit = !goBack,
                                summary = "The app stays on the screen until you leave it.",
                                onClick = { goBack = false },
                                trailing = { RadioButton(selected = !goBack, onClick = null) },
                            )
                        }
                        row { sh ->
                            SettingRow(
                                title = "Go back after a time", shape = sh, icon = Icons.Filled.Home, lit = goBack,
                                summary = "It goes back to where you were when the time is over.",
                                onClick = { goBack = true },
                                trailing = { RadioButton(selected = goBack, onClick = null) },
                                footer = {
                                    if (goBack) Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
                                        NumberBox("Time in the app (milliseconds, 1000 = 1 second)", ms, min = 100, max = 999999) { ms = it }
                                    }
                                },
                            )
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { onOk(if (goBack) ms else -1) }, modifier = Modifier.fillMaxWidth()) { Text("OK") }
                }
            }
        }
    }
}
