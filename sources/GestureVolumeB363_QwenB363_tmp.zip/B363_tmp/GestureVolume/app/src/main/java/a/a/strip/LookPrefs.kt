package a.a.strip
import android.graphics.Color
import a.a.data.local.SharedPref

object LookPrefs {
    var tileColor: Int get() = SharedPref.getInt("strip.tileColor", Color.parseColor("#FFB300")); set(value) = SharedPref.setInt("strip.tileColor", value)
    var tileOpacity: Float get() = SharedPref.getFloat("strip.tileOpacity", 1.0f); set(value) = SharedPref.setFloat("strip.tileOpacity", value)
    var cornerRoundness: Float get() = SharedPref.getFloat("strip.cornerRoundness", 16f); set(value) = SharedPref.setFloat("strip.cornerRoundness", value)
    var borderColor: Int get() = SharedPref.getInt("strip.borderColor", Color.TRANSPARENT); set(value) = SharedPref.setInt("strip.borderColor", value)
    var borderWidth: Float get() = SharedPref.getFloat("strip.borderWidth", 0f); set(value) = SharedPref.setFloat("strip.borderWidth", value)

    fun getTileColor(id: String?): Int = if (id != null) SharedPref.getInt("strip.item.$id.tileColor", -1).takeIf { it != -1 } ?: tileColor else tileColor
    fun setTileColor(id: String, v: Int) = SharedPref.setInt("strip.item.$id.tileColor", v)
    fun getTileOpacity(id: String?): Float = if (id != null) SharedPref.getFloat("strip.item.$id.tileOpacity", -1f).takeIf { it != -1f } ?: tileOpacity else tileOpacity
    fun setTileOpacity(id: String, v: Float) = SharedPref.setFloat("strip.item.$id.tileOpacity", v)
    fun getCornerRoundness(id: String?): Float = if (id != null) SharedPref.getFloat("strip.item.$id.cornerRoundness", -1f).takeIf { it != -1f } ?: cornerRoundness else cornerRoundness
    fun setCornerRoundness(id: String, v: Float) = SharedPref.setFloat("strip.item.$id.cornerRoundness", v)
    fun getBorderColor(id: String?): Int = if (id != null) SharedPref.getInt("strip.item.$id.borderColor", -1).takeIf { it != -1 } ?: borderColor else borderColor
    fun setBorderColor(id: String, v: Int) = SharedPref.setInt("strip.item.$id.borderColor", v)
    fun getBorderWidth(id: String?): Float = if (id != null) SharedPref.getFloat("strip.item.$id.borderWidth", -1f).takeIf { it != -1f } ?: borderWidth else borderWidth
    fun setBorderWidth(id: String, v: Float) = SharedPref.setFloat("strip.item.$id.borderWidth", v)
}
