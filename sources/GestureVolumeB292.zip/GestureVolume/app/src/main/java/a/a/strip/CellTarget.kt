package a.a.strip

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Column

/**
 * Where a cell saved from outside (Widgets, the launcher catcher, tiles) goes: the main slider's cells window by
 * default, or, when "Ask me which cells window" is on and a segment has its own window, a small choice first.
 */
object CellTarget {
    private const val ASK = "cellTargetAsk"
    private fun p(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun askOn(c: Context) = p(c).getBoolean(ASK, false)
    fun setAsk(c: Context, on: Boolean) { p(c).edit().putBoolean(ASK, on).apply() }

    fun save(context: Context, label: String, action: String, icon: String = "") {
        if (!askOn(context) || StripScope.ownWindowIds(context).isEmpty()) {
            ActionSaver.saveToCells(context, label, action, icon)
            Toast.makeText(context, "Saved to cells", Toast.LENGTH_SHORT).show()
            return
        }
        context.startActivity(
            Intent(context, CellTargetActivity::class.java)
                .putExtra("label", label).putExtra("action", action).putExtra("icon", icon)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** The choice: Main slider, or one of the segments that has its own cells window. Nothing stays open after it. */
class CellTargetActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val label = intent.getStringExtra("label").orEmpty()
        val action = intent.getStringExtra("action").orEmpty()
        val icon = intent.getStringExtra("icon").orEmpty()
        val windows = StripScope.ownWindowIds(this)
        fun pick(id: String, name: String) {
            runCatching { ActionSaver.saveToCellsIn(this, id, label, action, icon) }
            Toast.makeText(this, "Saved to $name", Toast.LENGTH_SHORT).show()
            finish()
        }
        setContent {
            MaterialTheme {
                AlertDialog(
                    onDismissRequest = { finish() },
                    title = { Text("Save to which cells window?") },
                    text = {
                        Column {
                            TextButton(onClick = { pick(StripScope.MAIN, "the main slider") }) { Text("Main slider") }
                            windows.forEach { (id, name) -> TextButton(onClick = { pick(id, name) }) { Text(name) } }
                        }
                    },
                    confirmButton = {},
                    dismissButton = { TextButton(onClick = { finish() }) { Text("Cancel") } },
                )
            }
        }
    }
}
