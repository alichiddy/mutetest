package a.a.ui.screens.strip

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.strip.LookPrefs
import a.a.strip.StripItem
import a.a.strip.StripView

private val SAMPLE = listOf(
    StripItem("Wi-Fi", "📶", "x"), StripItem("Torch", "🔦", "x"), StripItem("Camera", "📷", "x"),
    StripItem("Music", "🎵", "x"), StripItem("Notes", "📝", "x"), StripItem("Maps", "🗺️", "x"),
)

private fun hasContent(list: List<StripItem>): Boolean =
    list.any { it.label.isNotEmpty() || it.icon.isNotEmpty() || it.action.isNotEmpty() }

/** The first folder (looking inside folders too) that has something in it, for the Folders preview. */
private fun firstFolder(list: List<StripItem>): StripItem? {
    for (item in list) {
        val kids = item.children ?: continue
        if (hasContent(kids)) return item
        val deeper = firstFolder(kids)
        if (deeper != null) return deeper
    }
    return null
}

/**
 * "Look of the cells": the same live cells window as in the editor stays at the top while the settings below
 * change it. Two tabs: the cells window, and the windows that open from folders (their own copy of every setting).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LookDialog(
    sp: SharedPreferences,
    rootItems: List<StripItem>,
    rootCols: Int,
    sizePct: Int,
    showLabels: Boolean,
    startOnFolders: Boolean,
    onChange: () -> Unit,
    onDismiss: () -> Unit,
) {
    var tab by remember { mutableIntStateOf(if (startOnFolders) 1 else 0) }
    var tick by remember { mutableIntStateOf(0) }
    var resetTick by remember { mutableIntStateOf(0) }
    var bg by remember { mutableIntStateOf(sp.getInt("stripLookPreviewBg", 3)) }
    val folder = tab == 1
    val ctx = LocalContext.current

    fun getInt(name: String, def: Int): Int = sp.getInt(LookPrefs.readKey(sp, folder, name), def)
    fun getBool(name: String, def: Boolean): Boolean = sp.getBoolean(LookPrefs.readKey(sp, folder, name), def)
    fun putInt(name: String, v: Int) { sp.edit().putInt(LookPrefs.writeKey(folder, name), v).apply(); tick++ }
    fun putBool(name: String, v: Boolean) { sp.edit().putBoolean(LookPrefs.writeKey(folder, name), v).apply(); tick++ }
    fun finish() { onChange(); onDismiss() }

    Dialog(onDismissRequest = { finish() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Look of the cells", Modifier.weight(1f), fontSize = 20.sp)
                    TextButton(onClick = { finish() }) { Text("Done") }
                }
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Cells window") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Folders") })
                }

                // ---- the live view ----
                val folderItem = if (folder) firstFolder(rootItems) else null
                val realItems = if (folder) folderItem?.children.orEmpty() else rootItems
                val usingSample = !hasContent(realItems)
                val items = if (usingSample) SAMPLE else realItems
                val cols = if (usingSample) 3 else if (folder) (folderItem?.cols ?: 3).coerceIn(1, 8) else rootCols.coerceIn(1, 16)
                val bgMod = when (bg) {
                    0 -> Modifier.background(Color(0xFF111111))
                    1 -> Modifier.background(Color(0xFF8A8A8A))
                    2 -> Modifier.background(Color.White)
                    else -> Modifier.background(
                        Brush.horizontalGradient(colorStops = arrayOf(0f to Color.Black, 0.5f to Color.Black, 0.5f to Color.White, 1f to Color.White))
                    )
                }
                BoxWithConstraints(Modifier.fillMaxWidth().padding(top = 6.dp).then(bgMod)) {
                    val density = LocalDensity.current
                    val dm = ctx.resources.displayMetrics
                    val screenW = minOf(dm.widthPixels, dm.heightPixels).toFloat()
                    val screenH = maxOf(dm.widthPixels, dm.heightPixels).toFloat()
                    // The size the cells have on the screen (as in the editor), made smaller only to fit this window.
                    val eg = sp.getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                    val rootRows = ((rootItems.size + rootCols.coerceIn(1, 16) - 1) / rootCols.coerceIn(1, 16)).coerceAtLeast(1)
                    val trueCell = minOf(
                        (screenW * 0.94f) / (rootCols.coerceIn(1, 16) * (1f + eg) + eg),
                        screenH * 0.88f / (rootRows * (1f + eg) + eg),
                    ) * sizePct / 100f
                    val g = getInt("stripGapPct", 8).coerceIn(0, 40) / 100f
                    val rows = ((items.size + cols - 1) / cols).coerceAtLeast(1)
                    val availW = with(density) { maxWidth.toPx() } * 0.94f
                    val availH = with(density) { 190.dp.toPx() }
                    val cell = minOf(
                        trueCell,
                        availW / (cols * (1f + g) + g),
                        availH / (rows * (1f + g) + g),
                    ).toInt().coerceAtLeast(24)
                    val view = remember(tick, tab, cell, items, cols, showLabels) {
                        StripView(ctx, items, cell, cols, showLabels, folderLook = folder).apply { setScreenOrigin(0f, 0f) }
                    }
                    Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                        key(view) {
                            AndroidView(
                                factory = { view },
                                modifier = Modifier.requiredSize(
                                    with(density) { view.panelWidthPx.toDp() },
                                    with(density) { view.panelHeightPx.toDp() },
                                ).pointerInput(view) {
                                    detectTapGestures { off -> view.highlight(view.cellAt(off.x, off.y)) }
                                },
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Behind it:", fontSize = 12.sp)
                    listOf("Dark", "Grey", "White", "Both").forEachIndexed { i, name ->
                        TextButton(onClick = { bg = i; sp.edit().putInt("stripLookPreviewBg", i).apply() }) {
                            Text((if (bg == i) "●  " else "○  ") + name, fontSize = 12.sp)
                        }
                    }
                }
                Text(
                    (if (folder) {
                        if (usingSample) "Sample cells (you have no folder with cells yet). " else "Your first folder. "
                    } else if (usingSample) "Sample cells. " else "") +
                        "Tap a cell to light it. This is the same view as in the editor.",
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                HorizontalDivider(Modifier.padding(vertical = 6.dp))

                // ---- the settings of the chosen tab ----
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    key(tab, resetTick) {
                        if (folder) Text(
                            "These settings are only for the windows that open from a folder. A setting you have not changed here follows the cells window.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 6.dp),
                        )
                        var look by remember { mutableIntStateOf(getInt("stripLook", 0)) }
                        var halo by remember { mutableStateOf(getBool("stripHalo", false)) }
                        listOf(0 to "Tiles (as before)", 1 to "Icons only: no tiles, no panel, bigger icons", 2 to "Icons only on a very faint dark panel").forEach { (v, name) ->
                            TextButton(onClick = { look = v; putInt("stripLook", v) }) {
                                Text((if (look == v) "●  " else "○  ") + name)
                            }
                        }
                        if (look == 2) {
                            PctSlider("Opacity of the panel (100 = solid)", "%", getInt("stripBackdropPct", 18), 0, 100) { putInt("stripBackdropPct", it) }
                            ColorRow(
                                "Colour of the panel", "Black",
                                listOf(0xFFFFFFFF.toInt(), 0xFF1F8A8A.toInt(), 0xFF1565C0.toInt(), 0xFF6A1B9A.toInt(), 0xFFC62828.toInt(), 0xFFEF6C00.toInt(), 0xFF2E7D32.toInt(), 0xFF455A64.toInt()),
                                getInt("stripBackdropColor", 0),
                            ) { putInt("stripBackdropColor", it) }
                        }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Soft dark glow around icons and names", Modifier.weight(1f))
                            Switch(checked = halo, onCheckedChange = { halo = it; putBool("stripHalo", it) })
                        }
                        Text("The glow follows the shape of each icon. The cell under the thumb still lights up.", fontSize = 12.sp)

                        // The names under the icons.
                        Text("Names under the icons", fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
                        PctSlider("Size of the names", "%", getInt("stripLabelPct", 100), 50, 200) { putInt("stripLabelPct", it) }
                        Text("A very long name is still made smaller so it does not run far into the next cell.", fontSize = 12.sp)
                        var outline by remember { mutableIntStateOf(getInt("stripOutlineColor", 0)) }
                        ColorRow(
                            "Outline round the names (so they read on a white background)", "None",
                            listOf(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF0D1B4C.toInt(), 0xFF5A0F0F.toInt(), 0xFF1B3D1B.toInt(), 0xFFFFD600.toInt()),
                            outline,
                        ) { outline = it; putInt("stripOutlineColor", it) }
                        if (outline != 0) PctSlider("Outline thickness", "%", getInt("stripOutlinePct", 14), 4, 40) { putInt("stripOutlinePct", it) }

                        // Tile colour, icon size and the gap between cells.
                        ColorRow(
                            "Colour of the cell tiles (not used by the icons-only looks)", "Standard",
                            listOf(0xFF1F8A8A.toInt(), 0xFF1565C0.toInt(), 0xFF6A1B9A.toInt(), 0xFFC62828.toInt(), 0xFFEF6C00.toInt(), 0xFF2E7D32.toInt(), 0xFF455A64.toInt(), 0xFF000000.toInt()),
                            getInt("stripTileColor", 0),
                        ) { putInt("stripTileColor", it) }
                        PctSlider("Icon size", "%", getInt("stripIconPct", 100), 50, 170) { putInt("stripIconPct", it) }
                        PctSlider("Gap between the cells", "%", getInt("stripGapPct", 8), 0, 40) { putInt("stripGapPct", it) }
                        // Pinned cells (same for the cells window and the folders).
                        Text("Pinned cells (📌 Pin in the cells editor)", fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
                        PickRow(
                            "When a new row is added, a pinned cell that sits in the bottom row",
                            listOf("Follows the bottom row (blank cells fill the gap)", "Only pinned folders follow the bottom row", "Never follows: it stays on its own row"),
                            sp.getInt("stripPinFollow", 0).coerceIn(0, 2),
                        ) { sp.edit().putInt("stripPinFollow", it).apply(); tick++ }
                        var pinDot by remember { mutableStateOf(sp.getBoolean("stripPinDot", true)) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Small dot on a pinned cell", Modifier.weight(1f))
                            Switch(checked = pinDot, onCheckedChange = { pinDot = it; sp.edit().putBoolean("stripPinDot", it).apply(); tick++ })
                        }
                        if (pinDot) {
                            PctSlider("Dot size", "", sp.getInt("stripPinDotPx", 5), 1, 12) { sp.edit().putInt("stripPinDotPx", it).apply(); tick++ }
                            PickRow(
                                "Corner of the cell for the dot",
                                listOf("Top left", "Top right", "Bottom left", "Bottom right"),
                                sp.getInt("stripPinDotCorner", 0).coerceIn(0, 3),
                            ) { sp.edit().putInt("stripPinDotCorner", it).apply(); tick++ }
                            PctSlider("Distance from the side", " dp", sp.getInt("stripPinDotX", 3), 0, 24) { sp.edit().putInt("stripPinDotX", it).apply(); tick++ }
                            PctSlider("Distance from the top or bottom", " dp", sp.getInt("stripPinDotY", 3), 0, 24) { sp.edit().putInt("stripPinDotY", it).apply(); tick++ }
                            ColorRow(
                                "Dot colour", "Red",
                                listOf(0xFFFFD600.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                                sp.getInt("stripPinDotColor", 0).let { if (it == 0xFFFF5252.toInt()) 0 else it },
                            ) { sp.edit().putInt("stripPinDotColor", if (it == 0) 0xFFFF5252.toInt() else it).apply(); tick++ }
                        }
                        var pinText by remember { mutableStateOf(sp.getBoolean("stripPinText", false)) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Change the text colour of a pinned cell too", Modifier.weight(1f))
                            Switch(checked = pinText, onCheckedChange = { pinText = it; sp.edit().putBoolean("stripPinText", it).apply(); tick++ })
                        }
                        if (pinText) ColorRow(
                            "Text colour of pinned cells", "Yellow",
                            listOf(0xFFFF5252.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                            sp.getInt("stripPinTextColor", 0).let { if (it == 0xFFFFD600.toInt()) 0 else it },
                        ) { sp.edit().putInt("stripPinTextColor", if (it == 0) 0xFFFFD600.toInt() else it).apply(); tick++ }

                        // The mark on a folder cell and what a folder cell shows (same for the cells window and the folders).
                        Text("Folder cells", fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
                        PickRow(
                            "Picture of a folder",
                            listOf("Its own icon", "The first 4 apps inside (when it has no icon of its own)", "The first 4 apps inside, always"),
                            sp.getInt("stripFoldPreview", 0).coerceIn(0, 2),
                        ) { sp.edit().putInt("stripFoldPreview", it).apply(); tick++ }
                        if (sp.getInt("stripFoldPreview", 0) != 0) {
                            var plate by remember { mutableStateOf(sp.getBoolean("stripFoldPlate", true)) }
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Soft plate behind the 4 apps", Modifier.weight(1f))
                                Switch(checked = plate, onCheckedChange = { plate = it; sp.edit().putBoolean("stripFoldPlate", it).apply(); tick++ })
                            }
                            PctSlider("Size of the 4 small icons", "%", sp.getInt("stripFoldMiniPct", 100), 40, 140) { sp.edit().putInt("stripFoldMiniPct", it).apply(); tick++ }
                        }
                        var foldArrow by remember { mutableStateOf(sp.getBoolean("stripFoldArrow", true)) }
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Mark on a folder cell (the arrow)", Modifier.weight(1f))
                            Switch(checked = foldArrow, onCheckedChange = { foldArrow = it; sp.edit().putBoolean("stripFoldArrow", it).apply(); tick++ })
                        }
                        if (foldArrow) {
                            PickRow(
                                "Shape of the mark",
                                listOf("Corner triangle", "Dot", "Square", "Arrow right", "Arrow down", "Diamond"),
                                sp.getInt("stripFoldArrowShape", 0).coerceIn(0, 5),
                            ) { sp.edit().putInt("stripFoldArrowShape", it).apply(); tick++ }
                            PctSlider("Size of the mark", "%", sp.getInt("stripFoldArrowPct", 20), 8, 45) { sp.edit().putInt("stripFoldArrowPct", it).apply(); tick++ }
                            PickRow(
                                "Corner of the cell for the mark",
                                listOf("Top left", "Top right", "Bottom left", "Bottom right"),
                                sp.getInt("stripFoldArrowCorner", 3).coerceIn(0, 3),
                            ) { sp.edit().putInt("stripFoldArrowCorner", it).apply(); tick++ }
                            PctSlider("Distance from the side", " dp", sp.getInt("stripFoldArrowX", 2), 0, 40) { sp.edit().putInt("stripFoldArrowX", it).apply(); tick++ }
                            PctSlider("Distance from the top or bottom", " dp", sp.getInt("stripFoldArrowY", 2), 0, 40) { sp.edit().putInt("stripFoldArrowY", it).apply(); tick++ }
                            ColorRow(
                                "Colour of the mark", "Same as the text",
                                listOf(0xFFFFD600.toInt(), 0xFF00E676.toInt(), 0xFF40C4FF.toInt(), 0xFFFF5252.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFE040FB.toInt()),
                                sp.getInt("stripFoldArrowColor", 0),
                            ) { sp.edit().putInt("stripFoldArrowColor", it).apply(); tick++ }
                        }

                        if (folder) {
                            TextButton(onClick = { LookPrefs.clearFolders(sp); resetTick++; tick++ }) {
                                Text("Folders follow the cells window again (clear all folder settings)")
                            }
                        } else {
                            TextButton(onClick = {
                                sp.edit().remove("stripTileColor").putInt("stripIconPct", 100).putInt("stripGapPct", 8)
                                    .putInt("stripLabelPct", 100).remove("stripOutlineColor").putInt("stripOutlinePct", 14).apply()
                                resetTick++; tick++
                            }) { Text("Reset colour, icon size, gap, name size and outline") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PctSlider(label: String, unit: String, initial: Int, min: Int, max: Int, onValue: (Int) -> Unit) {
    var v by remember { mutableIntStateOf(initial.coerceIn(min, max)) }
    Text("$label: $v$unit", fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
    Slider(
        value = v.toFloat(), valueRange = min.toFloat()..max.toFloat(),
        onValueChange = { v = it.toInt(); onValue(v) },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PickRow(title: String, names: List<String>, initial: Int, onPick: (Int) -> Unit) {
    var cur by remember { mutableIntStateOf(initial) }
    Text(title, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        names.forEachIndexed { n, name ->
            Box(
                Modifier.clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(
                        if (cur == n) 3.dp else 1.dp,
                        if (cur == n) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(8.dp),
                    )
                    .clickable { cur = n; onPick(n) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center,
            ) { Text(name, fontSize = 12.sp) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ColorRow(title: String, noneLabel: String, colors: List<Int>, initial: Int, onPick: (Int) -> Unit) {
    var cur by remember { mutableIntStateOf(initial) }
    var hex by remember { mutableStateOf(if (initial == 0) "" else String.format("%06X", initial and 0xFFFFFF)) }
    Text(title, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        (listOf(0) + colors).forEach { c ->
            Box(
                Modifier.height(32.dp).defaultMinSize(minWidth = 32.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (c == 0) MaterialTheme.colorScheme.surfaceVariant else Color(c))
                    .border(
                        if (cur == c) 3.dp else 1.dp,
                        if (cur == c) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        RoundedCornerShape(8.dp),
                    )
                    .clickable {
                        cur = c; hex = if (c == 0) "" else String.format("%06X", c and 0xFFFFFF)
                        onPick(c)
                    }.padding(horizontal = if (c == 0) 8.dp else 0.dp),
                contentAlignment = Alignment.Center,
            ) { if (c == 0) Text(noneLabel, fontSize = 12.sp) }
        }
    }
    OutlinedTextField(
        value = hex, singleLine = true, label = { Text("Your own colour (hex, like 1F8A8A)") },
        onValueChange = { v ->
            hex = v.filter { it.isDigit() || it in 'a'..'f' || it in 'A'..'F' }.take(6)
            if (hex.length == 6) {
                cur = (0xFF000000L or hex.toLong(16)).toInt()
                onPick(cur)
            }
        },
        modifier = Modifier.fillMaxWidth(),
    )
}
