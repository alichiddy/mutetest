@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package a.a.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tap-to-choose widgets for the canvas: nothing here needs typing except where the text itself is the point. */

@Composable
fun ChoiceRow(options: List<Pair<String, String>>, value: String, onPick: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { (label, v) ->
            if (v == value) Button(onClick = {}) { Text(label, fontSize = 12.sp) }
            else OutlinedButton(onClick = { onPick(v) }) { Text(label, fontSize = 12.sp) }
        }
    }
}

/** A whole number: common values to tap, and - / + for anything else. */
@Composable
fun NumberPick(
    value: String, presets: List<Pair<String, String>>, step: Int, min: Int = 0, max: Int = Int.MAX_VALUE,
    shown: (Int) -> String = { it.toString() }, onChange: (String) -> Unit,
) {
    val n = value.toIntOrNull() ?: presets.firstOrNull()?.second?.toIntOrNull() ?: 0
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ChoiceRow(presets, value) { onChange(it) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onChange((n - step).coerceAtLeast(min).toString()) }) { Text("-") }
            Text(shown(n), fontSize = 16.sp)
            OutlinedButton(onClick = { onChange((n + step).coerceAtMost(max).toString()) }) { Text("+") }
        }
    }
}

/** Variables the blocks of a flow already use, plus a few usual names. */
fun variablesIn(blocks: List<Step>): List<String> {
    val out = LinkedHashSet<String>()
    blocks.forEach { s ->
        when (s.type) {
            Step.SET -> out += s.a
            Step.SHELL, Step.SHIZUKU -> out += s.b.ifEmpty { "out" }
            Step.HTTP -> out += s.c.ifEmpty { "answer" }
            Step.OCRWAIT -> { out += s.d.ifEmpty { "ocr" }; out += "ocr_found" }
            Step.FIELDWAIT -> out += "field_found"
            Step.REPEAT -> if (s.b == "each") out += s.c.ifEmpty { "item" }
        }
    }
    listOf("out", "answer", "result", "count", "item").forEach { out += it }
    return out.filter { it.isNotBlank() }
}

/** A variable name: tap one that exists, or make a new one from a list of usual names. */
@Composable
fun VarPick(value: String, vars: List<String>, emptyMeans: String = "", onPick: (String) -> Unit) {
    var custom by remember { mutableStateOf(false) }
    val usual = listOf("count", "total", "name", "value", "state", "time", "text", "number", "flag")
    val all = (vars + usual).distinct()
    val shownValue = value.ifEmpty { emptyMeans }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ChoiceRow(all.map { it to it }, shownValue) { onPick(it) }
        OutlinedButton(onClick = { custom = true }) { Text("Another name…", fontSize = 12.sp) }
    }
    if (custom) {
        var t by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { custom = false },
            title = { Text("Name of the variable") },
            text = { OutlinedTextField(t, { t = it.filter { c -> c.isLetterOrDigit() || c == '_' } }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onPick(t); custom = false }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { custom = false }) { Text("Cancel") } },
        )
    }
}

private val VAR_REF = Regex("""^\{[A-Za-z_]\w*\}$""")
private val WORDS = listOf("on", "off", "yes", "no", "true", "false", "enabled", "disabled")

/** A value: a number to tap, a variable to pick, or a word to pick (or type, if it is something else). */
@Composable
fun ValuePick(value: String, blocks: List<Step>, onChange: (String) -> Unit) {
    val modeNow = when {
        VAR_REF.matches(value) -> "var"
        value.isEmpty() || value.toDoubleOrNull() != null -> "num"
        else -> "text"
    }
    var mode by remember { mutableStateOf(modeNow) }
    var typing by remember { mutableStateOf(modeNow == "text" && value !in WORDS) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ChoiceRow(listOf("Number" to "num", "Variable" to "var", "Word" to "text"), mode) {
            mode = it
            if (it == "var") onChange("{" + variablesIn(blocks).first() + "}")
            if (it == "num" && value.toDoubleOrNull() == null) onChange("0")
            if (it == "text" && value.toDoubleOrNull() != null || it == "text" && VAR_REF.matches(value)) onChange("on")
        }
        when (mode) {
            "num" -> NumberPick(value.ifEmpty { "0" }, listOf("0" to "0", "1" to "1", "2" to "2", "5" to "5", "10" to "10", "50" to "50", "100" to "100"), step = 1, onChange = onChange)
            "var" -> ChoiceRow(variablesIn(blocks).map { it to it }, value.removePrefix("{").removeSuffix("}")) { onChange("{$it}") }
            else -> {
                ChoiceRow(WORDS.map { it to it }, if (typing) "" else value) { typing = false; onChange(it) }
                OutlinedButton(onClick = { typing = true }) { Text("Another word…", fontSize = 12.sp) }
                if (typing) OutlinedTextField(value, onChange, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/** The argument of a device action: choices where the action has them. Returns false if it has none (use text). */
@Composable
fun ActionArgPick(actionId: String, value: String, onChange: (String) -> Unit): Boolean {
    when (val spec = ActionArgs.specFor(actionId, androidx.compose.ui.platform.LocalContext.current)) {
        is ActionArgs.Choices -> {
            ChoiceRow(spec.options, value.ifEmpty { spec.default }) { onChange(it) }
            return true
        }
        ActionArgs.StreamPercent -> {
            val st = value.substringBefore(':', "music").ifEmpty { "music" }
            val pct = value.substringAfter(':', "100").ifEmpty { "100" }
            Text("Which sound", fontSize = 12.sp)
            ChoiceRow(ActionArgs.STREAMS, st) { onChange("$it:$pct") }
            Text("How loud", fontSize = 12.sp)
            NumberPick(pct, ActionArgs.PERCENTS, step = 5, min = 0, max = 100, shown = { "$it%" }) { onChange("$st:$it") }
            return true
        }
        null -> return false
    }
}
