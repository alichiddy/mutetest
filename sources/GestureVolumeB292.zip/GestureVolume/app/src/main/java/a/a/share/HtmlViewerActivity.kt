package a.a.share

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.io.File

/**
 * "A HTML Viewer": opens an HTML page (open with, share, or a cell's "Open a file") with JavaScript,
 * offline. The page is served to the web view from memory at a made-up address, so it behaves like
 * a normal page (storage, relative links to files beside it when the folder can be read) while every
 * request to the internet is answered "blocked". A web socket cannot be stopped this way.
 *
 * Nothing exists until a page is opened; the web view is destroyed when the window closes.
 */
open class HtmlViewerActivity : Activity() {
    private var web: WebView? = null
    private lateinit var ui: HtmlViewerUi
    private var page: ByteArray = ByteArray(0)
    private var pageName = "index.html"
    private var baseDir: File? = null

    private companion object {
        const val HOST = "a.local"
        const val MAX_BYTES = 40 * 1024 * 1024
        const val REQ_SAVE = 4711
    }

    /** The page as it was opened (or as the Source tab last changed it). */
    fun sourceText(): String = String(page, Charsets.UTF_8)

    fun pageFileName(): String = pageName

    fun pageDone() { if (::ui.isInitialized) ui.onPageFinished() }

    /** Replaces the page served to the web view and loads it again. The file it came from is not touched. */
    fun setSource(html: String) {
        page = html.toByteArray(Charsets.UTF_8)
        web?.clearCache(true)
        web?.reload()
    }

    private var pendingSave: String? = null

    /** Asks where to save [text] and writes it there. */
    @Suppress("DEPRECATION")
    fun saveText(name: String, mime: String, text: String) {
        pendingSave = text
        runCatching {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE, name),
                REQ_SAVE,
            )
        }.onFailure { pendingSave = null; toast("Could not open the save window.") }
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAVE) return
        val text = pendingSave; pendingSave = null
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null || text == null) return
        val ok = runCatching { contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } != null }.getOrDefault(false)
        toast(if (ok) "Saved" else "Could not save.")
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_SEND -> intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> intent.data
        }
        var text: String? = null
        if (uri == null && intent.action == Intent.ACTION_SEND) text = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (uri == null && text == null) { toast("Nothing to show."); finish(); return }
        if (uri != null) {
            val file = FilePaths.readable(uri)
            val data = runCatching {
                if (file != null) file.inputStream().use { it.readLimited() }
                else contentResolver.openInputStream(uri)?.use { it.readLimited() }
            }.getOrNull()
            if (data == null) { toast("Could not read that file."); finish(); return }
            page = data
            baseDir = file?.parentFile
            val n = (FilePaths.displayName(this, uri) ?: "index.html").replace(Regex("[^A-Za-z0-9._-]"), "_")
            pageName = if (n.isBlank()) "index.html" else n
            title = FilePaths.displayName(this, uri) ?: "HTML"
        } else {
            page = text!!.toByteArray(Charsets.UTF_8)
            title = "HTML"
        }

        val frame = FrameLayout(this)
        // Edge to edge is forced on new Android: keep the page clear of the bars.
        frame.setOnApplyWindowInsetsListener { v, ins ->
            // A bar that is hidden takes no room: the page fills its place (no black strip).
            val pad = if (::ui.isInitialized) ui.padding(ins)
            else intArrayOf(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            v.setPadding(pad[0], pad[1], pad[2], pad[3])
            ins
        }
        val w = ScrollWebView(this)
        web = w
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == HOST) return false
                if (request.isForMainFrame) toast("Blocked: this viewer is offline.")
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val u = request.url
                if (u.host != HOST) return blocked()
                val path = Uri.decode(u.path.orEmpty()).trimStart('/')
                if (path.isEmpty() || path == pageName) {
                    return WebResourceResponse("text/html", null, ByteArrayInputStream(page))
                }
                val dir = baseDir ?: return notFound()
                val f = runCatching { File(dir, path).canonicalFile }.getOrNull() ?: return notFound()
                if (!f.path.startsWith(dir.canonicalPath + File.separator) || !f.isFile || !f.canRead()) return notFound()
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
                return runCatching { WebResourceResponse(mime, if (mime.startsWith("text/") || mime.endsWith("javascript") || mime.endsWith("json")) "UTF-8" else null, f.inputStream()) }.getOrNull() ?: notFound()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                this@HtmlViewerActivity.pageDone()
            }

            private fun blocked() = WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            private fun notFound() = WebResourceResponse("text/plain", "UTF-8", 404, "Not found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, t: String?) { if (!t.isNullOrBlank() && !t.startsWith(HOST)) title = t }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@HtmlViewerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }.setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@HtmlViewerActivity).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }.setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                val input = EditText(this@HtmlViewerActivity).apply { setText(defaultValue.orEmpty()) }
                AlertDialog.Builder(this@HtmlViewerActivity).setMessage(message).setView(input)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }.setOnCancelListener { result.cancel() }.show()
                return true
            }
        }
        frame.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        ui = HtmlViewerUi(this, w, frame)
        setContentView(frame)
        ui.start()
        w.loadUrl("https://$HOST/$pageName")
    }

    private fun java.io.InputStream.readLimited(): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > MAX_BYTES) error("too big")
        }
        return out.toByteArray()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::ui.isInitialized) ui.reapply()
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::ui.isInitialized) ui.stop()
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
        super.onDestroy()
    }
}
