package a.a.ui.screens.main

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import a.a.utils.SmartSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * "Search everything", opened from the main menu. A full-screen window with one box: every setting,
 * screen, built-in shortcut, cell, folder and script that holds what is typed, best first, each with
 * where it lives ("Appearance > Content"). Tapping one goes there.
 *
 * The list is read when this opens and let go when it closes, so the search costs no memory the rest
 * of the time.
 */
@Composable
fun SearchDialog(onDismiss: () -> Unit, onPick: (SearchHit) -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    val index by produceState<SmartSearch.Index<SearchHit>?>(initialValue = null) {
        value = withContext(Dispatchers.Default) {
            SmartSearch.Index(SearchSources.load(context)) { SmartSearch.Doc(it.title, it.info, it.path) }
        }
    }
    val results = remember(index, query) { index?.search(query).orEmpty() }
    val partial = remember(index, query) { results.isNotEmpty() && index?.isPartial(query) == true }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search")
                    }
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Search everything") },
                        modifier = Modifier.weight(1f).focusRequester(focus),
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { results.firstOrNull()?.let(onPick) }),
                    )
                    Spacer(Modifier.width(12.dp))
                }
                when {
                    index == null -> Note("Loading…")
                    query.trim().length < 2 -> Note(
                        "Type any part of a name, in any order: \"wifi toggle\", \"cells volume\", \"torch\". " +
                            "It looks through every setting, screen, built-in shortcut, and your own cells, folders and scripts."
                    )
                    results.isEmpty() -> Note("Nothing found for \"" + query.trim() + "\". Try fewer or shorter words.")
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        if (partial) item {
                            Text(
                                "Nothing holds all your words. These hold the most of them.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            )
                        }
                        items(results) { hit ->
                            Column(
                                Modifier.fillMaxWidth().clickable { onPick(hit) }.padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Text(hit.title, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(hit.path, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (hit.info.isNotBlank()) {
                                    Text(
                                        hit.info.take(160),
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        fontSize = 14.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
    )
}
