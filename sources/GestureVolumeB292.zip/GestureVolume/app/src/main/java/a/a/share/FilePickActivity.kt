package a.a.share

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * A's own file picker, offered wherever an app asks for a file: "choose a file" (GET_CONTENT and
 * OPEN_DOCUMENT, one or many), "save as" (CREATE_DOCUMENT) and "choose a folder"
 * (OPEN_DOCUMENT_TREE). Android lists every app that answers these requests next to its own Files
 * app, so this is picked there; "Always" in that list makes it the one that opens every time.
 *
 * It browses the real storage and hands back document addresses of [PickerProvider], which is what
 * apps expect from a picker (readable, writable and kept across restarts). Needs "All files
 * access"; nothing runs or stays in memory outside the moment it is open.
 */
class FilePickActivity : ComponentActivity() {
    private enum class Mode { PICK, CREATE, TREE }

    private var resumeTick by mutableIntStateOf(0)

    private val askStorage = registerForActivityResult(ActivityResultContracts.RequestPermission()) { resumeTick++ }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val mode = when (intent.action) {
            Intent.ACTION_CREATE_DOCUMENT -> Mode.CREATE
            Intent.ACTION_OPEN_DOCUMENT_TREE -> Mode.TREE
            else -> Mode.PICK
        }
        val multi = mode == Mode.PICK && intent.getBooleanExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
        val types = if (mode == Mode.PICK) acceptedTypes() else emptyList()
        val prefs = getSharedPreferences("a_file_picker", MODE_PRIVATE)
        val last = prefs.getString("dir", null)?.let { File(it) }?.takeIf { it.isDirectory }
        val start = last ?: Environment.getExternalStorageDirectory()
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().systemBarsPadding()) {
                    if (!hasAccess(resumeTick)) AccessScreen()
                    else Browser(mode, multi, types, start) { prefs.edit().putString("dir", it.absolutePath).apply() }
                }
            }
        }
    }

    // ---------------------------------------------------------------- what was asked for

    /** The kinds of file wanted; empty when any file will do. */
    private fun acceptedTypes(): List<String> {
        val extra = intent.getStringArrayExtra(Intent.EXTRA_MIME_TYPES)?.filter { it.isNotBlank() }
        val all = if (!extra.isNullOrEmpty()) extra else listOfNotNull(intent.type)
        return if (all.isEmpty() || all.any { it == "*/*" }) emptyList() else all
    }

    private fun matches(types: List<String>, f: File): Boolean {
        if (types.isEmpty()) return true
        val m = PickerProvider.mimeOf(f.name)
        return types.any { t -> t == m || (t.endsWith("/*") && m.startsWith(t.removeSuffix("*"))) }
    }

    @Suppress("unused")
    private fun hasAccess(tick: Int): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    // ---------------------------------------------------------------- what is handed back

    private val grants = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION

    private fun docUri(f: File): Uri =
        DocumentsContract.buildDocumentUri("$packageName.docs", PickerProvider.docId(f))

    private fun finishPick(files: List<File>) {
        if (files.isEmpty()) return
        val uris = files.map { docUri(it) }
        val clip = ClipData.newRawUri("files", uris[0])
        for (u in uris.drop(1)) clip.addItem(ClipData.Item(u))
        val result = Intent().setData(uris[0]).addFlags(grants)
        result.clipData = clip
        setResult(RESULT_OK, result)
        finish()
    }

    private fun finishTree(dir: File) {
        val uri = DocumentsContract.buildTreeDocumentUri("$packageName.docs", PickerProvider.docId(dir))
        setResult(RESULT_OK, Intent().setData(uri).addFlags(grants or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION))
        finish()
    }

    private fun finishCreate(dir: File, wanted: String) {
        var name = wanted.trim().replace('/', '_')
        if (name.isEmpty()) {
            Toast.makeText(this, "Type a file name", Toast.LENGTH_SHORT).show()
            return
        }
        if (!name.contains('.')) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(intent.type)?.let { name += ".$it" }
        }
        val f = PickerProvider.uniqueIn(dir, name)
        val ok = try { f.createNewFile() } catch (e: Exception) { false }
        if (!ok) {
            Toast.makeText(this, "Cannot create the file here", Toast.LENGTH_LONG).show()
            return
        }
        setResult(RESULT_OK, Intent().setData(docUri(f)).addFlags(grants))
        finish()
    }

    // ---------------------------------------------------------------- screens

    @Composable
    private fun AccessScreen() {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
            Text("A files", style = MaterialTheme.typography.titleLarge)
            Text(
                "To show your files, A needs access to all files on this phone.",
                Modifier.padding(vertical = 12.dp)
            )
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= 30) {
                    val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                    runCatching { startActivity(i) }.onFailure {
                        runCatching { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                    }
                } else askStorage.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            }) { Text("Allow access to files") }
            TextButton(onClick = { finish() }) { Text("Cancel") }
        }
    }

    @Composable
    private fun Browser(mode: Mode, multi: Boolean, types: List<String>, startDir: File, onDir: (File) -> Unit) {
        val internal = Environment.getExternalStorageDirectory()
        var dir by remember { mutableStateOf(startDir) }
        var byDate by remember { mutableStateOf(false) }
        var showAll by remember { mutableStateOf(false) }
        var query by remember { mutableStateOf("") }
        var name by remember { mutableStateOf(intent.getStringExtra(Intent.EXTRA_TITLE).orEmpty()) }
        var refresh by remember { mutableIntStateOf(0) }
        var newFolder by remember { mutableStateOf<String?>(null) }
        val picked = remember { mutableStateListOf<String>() }
        LaunchedEffect(dir) { onDir(dir) }

        // Storage volumes (where "up" stops) and the folders offered as quick buttons.
        val volumes = remember {
            val out = ArrayList<Pair<String, File>>()
            out += "Internal" to internal
            getExternalFilesDirs(null).forEach { d ->
                val p = d?.absolutePath?.substringBefore("/Android/data") ?: return@forEach
                val f = File(p)
                if (out.none { it.second.absolutePath == f.absolutePath }) out += (f.name to f)
            }
            out.toList()
        }
        val roots = remember {
            volumes + listOf(
                "Download" to Environment.DIRECTORY_DOWNLOADS, "DCIM" to Environment.DIRECTORY_DCIM,
                "Pictures" to Environment.DIRECTORY_PICTURES, "Documents" to Environment.DIRECTORY_DOCUMENTS,
                "Music" to Environment.DIRECTORY_MUSIC, "Movies" to Environment.DIRECTORY_MOVIES,
            ).map { (label, dn) -> label to Environment.getExternalStoragePublicDirectory(dn) }
        }
        val isRoot = volumes.any { it.second.absolutePath == dir.absolutePath } || dir.parentFile == null
        val up = if (isRoot) null else dir.parentFile
        BackHandler(enabled = up != null) { if (up != null) { dir = up; query = "" } }

        val entries = remember(dir, refresh, byDate, showAll, query) {
            val all = dir.listFiles()?.toList() ?: emptyList()
            val shown = all.filter { f ->
                (query.isBlank() || f.name.contains(query, ignoreCase = true)) &&
                    (if (mode == Mode.PICK) f.isDirectory || showAll || matches(types, f) else f.isDirectory)
            }
            val dirs = shown.filter { it.isDirectory }
            val files = shown.filter { !it.isDirectory }
            if (byDate) dirs.sortedByDescending { it.lastModified() } + files.sortedByDescending { it.lastModified() }
            else dirs.sortedBy { it.name.lowercase() } + files.sortedBy { it.name.lowercase() }
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when (mode) { Mode.PICK -> "Choose a file"; Mode.CREATE -> "Save as"; Mode.TREE -> "Choose a folder" },
                    style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { finish() }) { Text("Cancel") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                roots.forEach { (label, f) -> TextButton(onClick = { dir = f; query = "" }) { Text(label) } }
            }
            Text(dir.absolutePath, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("Search this folder") }, modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton(onClick = { byDate = !byDate }) { Text(if (byDate) "Sorted: newest first" else "Sorted: name") }
                if (mode == Mode.PICK && types.isNotEmpty()) {
                    TextButton(onClick = { showAll = !showAll }) { Text(if (showAll) "Showing all files" else "Only the kind asked for") }
                }
                if (mode != Mode.PICK) TextButton(onClick = { newFolder = "" }) { Text("New folder") }
            }
            LazyColumn(Modifier.weight(1f)) {
                if (up != null) item {
                    Text("📁  ..", Modifier.fillMaxWidth().clickable { dir = up; query = "" }.padding(vertical = 12.dp, horizontal = 4.dp))
                }
                if (entries.isEmpty()) item {
                    Text(
                        if (dir.listFiles() == null) "This folder cannot be read." else "Nothing here.",
                        Modifier.padding(16.dp), fontSize = 13.sp
                    )
                }
                items(entries, key = { it.absolutePath }) { f ->
                    val on = f.absolutePath in picked
                    Column(
                        Modifier.fillMaxWidth().clickable {
                            when {
                                f.isDirectory -> { dir = f; query = "" }
                                multi -> if (on) picked.remove(f.absolutePath) else picked.add(f.absolutePath)
                                else -> finishPick(listOf(f))
                            }
                        }.padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            (if (f.isDirectory) "📁  " else if (multi) (if (on) "☑  " else "☐  ") else "📄  ") + f.name,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        if (!f.isDirectory) {
                            Text(
                                Formatter.formatShortFileSize(this@FilePickActivity, f.length()) + "   " +
                                    DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.lastModified())),
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            when (mode) {
                Mode.PICK -> {
                    if (multi) {
                        Button(
                            onClick = { finishPick(picked.map { File(it) }) }, enabled = picked.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        ) { Text("Done (${picked.size})") }
                    }
                }
                Mode.CREATE -> {
                    Column(Modifier.padding(vertical = 6.dp)) {
                        OutlinedTextField(
                            value = name, onValueChange = { name = it }, singleLine = true,
                            label = { Text("File name") }, modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { finishCreate(dir, name) }, modifier = Modifier.fillMaxWidth()) { Text("Save here") }
                    }
                }
                Mode.TREE -> {
                    Button(
                        onClick = { finishTree(dir) }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    ) { Text("Use this folder") }
                }
            }
        }

        newFolder?.let { typed ->
            AlertDialog(
                onDismissRequest = { newFolder = null },
                title = { Text("New folder") },
                text = { OutlinedTextField(value = typed, onValueChange = { newFolder = it }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        val n = typed.trim().replace('/', '_')
                        if (n.isNotEmpty() && !PickerProvider.uniqueIn(dir, n).mkdir()) {
                            Toast.makeText(this@FilePickActivity, "Cannot create the folder here", Toast.LENGTH_LONG).show()
                        }
                        newFolder = null
                        refresh++
                    }) { Text("Create") }
                },
                dismissButton = { TextButton(onClick = { newFolder = null }) { Text("Cancel") } },
            )
        }
    }
}
