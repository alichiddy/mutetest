package a.a.strip

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView

/**
 * What a minimized floating window turns into: a small round button you can drag anywhere and tap to bring the
 * window back. It exists only while something is minimized (one small overlay each), and remembers where you
 * left it per window.
 */
class FloatBubble(private val app: Context, private val key: String, label: String, private val onRestore: () -> Unit) {
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = app.resources.displayMetrics.density
    private val prefs = app.getSharedPreferences("float_bubbles", Context.MODE_PRIVATE)
    private val letter = label.trim().take(1).uppercase().ifEmpty { "A" }
    private var view: TextView? = null

    /** False when the bubble could not be shown (then the window must stay as it is). */
    fun show(): Boolean {
        if (view != null) return true
        val dm = app.resources.displayMetrics
        val size = (46 * d).toInt()
        val v = TextView(app)
        v.text = letter
        v.textSize = 18f
        v.gravity = Gravity.CENTER
        v.setTextColor(0xFFFFFFFF.toInt())
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(0xEE202124.toInt())
        bg.setStroke((2 * d).toInt(), 0xCCFFFFFF.toInt())
        v.background = bg
        val p = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        val saved = prefs.getString(key, null)?.split(",")
        val n = synchronized(active) { active.size }
        // The bubble may sit half outside the screen on any side (FLAG_LAYOUT_NO_LIMITS lets the window go there).
        val half = size / 2
        p.x = (saved?.getOrNull(0)?.toIntOrNull() ?: (dm.widthPixels - size - (4 * d).toInt())).coerceIn(-half, dm.widthPixels - half)
        p.y = (saved?.getOrNull(1)?.toIntOrNull() ?: ((140 + 52 * n) * d).toInt()).coerceIn(-half, dm.heightPixels - half)

        val slop = ViewConfiguration.get(app).scaledTouchSlop
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            val m = app.resources.displayMetrics
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        p.x = (ox + dx).toInt().coerceIn(-half, m.widthPixels - half)
                        p.y = (oy + dy).toInt().coerceIn(-half, m.heightPixels - half)
                        runCatching { wm.updateViewLayout(v, p) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) prefs.edit().putString(key, p.x.toString() + "," + p.y).apply() else onRestore()
                }
            }
            true
        }
        if (runCatching { wm.addView(v, p) }.isFailure) return false
        view = v
        synchronized(active) { active.add(key) }
        return true
    }

    fun hide() {
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        synchronized(active) { active.remove(key) }
    }

    private companion object {
        val active = HashSet<String>()
    }
}
