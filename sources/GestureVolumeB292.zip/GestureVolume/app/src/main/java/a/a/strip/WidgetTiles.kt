package a.a.strip

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/** A saved widget tile: kept in the widget window, whether or not a cell of it is on the strip. */
data class TileRec(
    val id: String, val name: String, val wid: Int, val pkg: String, val details: String,
    /** The same text a cell holds: "Intent:" + the press intent, with the tile's id in the extra "tid". */
    val action: String,
)

/**
 * Saved tiles of the widget window. The cell on the strip and the tile here carry the same id (extra "tid"
 * inside the cell's raw text), so:
 *  - editing the tile here rewrites every cell with that id;
 *  - editing the cell's raw text or name in the cells window shows here the next time this window opens;
 *  - deleting the cell leaves the tile here;
 *  - cells saved before this existed get an id and a tile the first time the widget window opens.
 * Nothing is loaded until the widget window is open.
 */
object WidgetTiles {
    private const val FILE = "widget_tiles"
    private const val KEY = "tiles"
    private const val GONE = "removed"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private fun main(c: Context) = c.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
    private val rnd = SecureRandom()

    fun newId(): String {
        val s = StringBuilder("t")
        repeat(8) { s.append("abcdefghijklmnopqrstuvwxyz0123456789"[rnd.nextInt(36)]) }
        return s.toString()
    }

    fun parse(action: String): Intent? =
        if (!action.startsWith("Intent:")) null
        else runCatching { Intent.parseUri(action.removePrefix("Intent:"), Intent.URI_INTENT_SCHEME) }.getOrNull()

    fun isTile(action: String): Boolean {
        val i = parse(action) ?: return false
        return i.component?.className?.endsWith("WidgetFloatActivity") == true && i.getStringExtra("mode") in listOf("press", "qs")
    }

    fun tidOf(action: String): String? = parse(action)?.getStringExtra("tid")?.takeIf { it.isNotEmpty() }

    fun withTid(action: String, id: String): String {
        val i = parse(action) ?: return action
        return "Intent:" + i.putExtra("tid", id).toUri(Intent.URI_INTENT_SCHEME)
    }

    fun recFrom(action: String, name: String, id: String): TileRec {
        val i = parse(action)
        val tap = i?.getStringExtra("tap").orEmpty()
        val pos = i?.getIntExtra("pos", 0) ?: 0
        val pkg = i?.getStringExtra("pkg").orEmpty()
        return TileRec(id, name, i?.getIntExtra("wid", -1) ?: -1, pkg,
            "Tile: " + tap.ifEmpty { "(no text)" } + "\nPlace: " + pos + "\nWidget app: " + pkg, action)
    }

    fun load(c: Context): List<TileRec> = runCatching {
        val a = JSONArray(sp(c).getString(KEY, "[]") ?: "[]")
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            TileRec(o.getString("id"), o.optString("name"), o.optInt("wid", -1), o.optString("pkg"), o.optString("details"), o.optString("action"))
        }
    }.getOrDefault(emptyList())

    private fun write(c: Context, list: List<TileRec>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("wid", it.wid).put("pkg", it.pkg).put("details", it.details).put("action", it.action)) }
        sp(c).edit().putString(KEY, a.toString()).apply()
    }

    private fun gone(c: Context): Set<String> = sp(c).getStringSet(GONE, emptySet()) ?: emptySet()

    private fun mapItems(items: List<StripItem>, f: (StripItem) -> StripItem): List<StripItem> =
        items.map { x ->
            val m = f(x)
            val ch = m.children
            if (ch != null) m.copy(children = mapItems(ch, f)) else m
        }

    private fun walk(items: List<StripItem>, f: (StripItem) -> Unit) {
        items.forEach { x -> f(x); x.children?.let { walk(it, f) } }
    }

    /** The main window and every segment's own cells window: a tile's cells are kept in step in all of them. */
    private fun windows(c: Context): List<String> = listOf(StripScope.MAIN) + StripScope.ownWindowIds(c).map { it.first }

    /**
     * Brings the saved tiles and the cells together and returns the tiles with the ids that still have a cell.
     * A cell whose raw text or name was edited wins over the tile; the tile then updates every cell with its id.
     */
    fun reconcile(c: Context): Pair<List<TileRec>, Set<String>> {
        val wins = windows(c).map { it to StripScope.load(c, it) }
        val recs = load(c).toMutableList()
        val removed = gone(c)
        var recsChanged = false

        // 1. What the cells say.
        val cells = ArrayList<Pair<String, StripItem>>()
        for ((_, cfg) in wins) walk(cfg.items) { if (isTile(it.action)) tidOf(it.action)?.let { t -> cells += t to it } }
        for (tid in cells.map { it.first }.distinct()) {
            if (tid in removed) continue
            val mine = cells.filter { it.first == tid }.map { it.second }
            val at = recs.indexOfFirst { it.id == tid }
            if (at < 0) {
                recs += recFrom(mine.first().action, mine.first().label, tid); recsChanged = true
            } else {
                val r = recs[at]
                val edited = mine.firstOrNull { it.action != r.action || it.label != r.name }
                if (edited != null) { recs[at] = recFrom(edited.action, edited.label, tid).copy(details = r.details); recsChanged = true }
            }
        }

        // 2. Cells saved before tiles existed: give them an id and a tile (same raw text, same id).
        val stamp = HashMap<String, String>()
        val linked = HashSet<String>()
        for ((wid, cfg) in wins) {
            var cfgChanged = false
            val items = mapItems(cfg.items) { x ->
                if (!isTile(x.action)) return@mapItems x
                val tid = tidOf(x.action)
                if (tid == null) {
                    val id = stamp.getOrPut(x.action) {
                        val n = newId()
                        recs += recFrom(withTid(x.action, n), x.label, n); recsChanged = true
                        n
                    }
                    cfgChanged = true
                    x.copy(action = withTid(x.action, id))
                } else {
                    val r = recs.firstOrNull { it.id == tid }
                    if (r != null && tid !in removed && (r.action != x.action || r.name != x.label)) { cfgChanged = true; x.copy(action = r.action, label = r.name) } else x
                }
            }
            if (cfgChanged) StripScope.save(c, wid, cfg.copy(items = items))
            walk(items) { if (isTile(it.action)) tidOf(it.action)?.let { t -> linked += t } }
        }
        if (recsChanged) write(c, recs)
        return recs.toList() to linked
    }

    /** Saves a new tile and, when [asCell], puts a cell for it on the strip. */
    fun add(c: Context, rec: TileRec, asCell: Boolean) {
        write(c, load(c).filter { it.id != rec.id } + rec)
        sp(c).edit().putStringSet(GONE, gone(c) - rec.id).apply()
        if (asCell) CellTarget.save(c, rec.name.ifBlank { "Tile" }, rec.action, "app:" + rec.pkg)
    }

    /** An edit made here: the tile and every cell with its id change together. */
    fun update(c: Context, rec: TileRec) {
        write(c, load(c).map { if (it.id == rec.id) rec else it })
        for (wid in windows(c)) {
            val cfg = StripScope.load(c, wid)
            var hit = false
            val items = mapItems(cfg.items) { x ->
                if (isTile(x.action) && tidOf(x.action) == rec.id) { hit = true; x.copy(action = rec.action, label = rec.name) } else x
            }
            if (hit || wid.isEmpty()) StripScope.save(c, wid, cfg.copy(items = items))
        }
    }

    /** The tile was found at another place: keeps the new place in the tile and in every cell of it. */
    fun savePlace(c: Context, tid: String, pos: Int) {
        val rec = load(c).firstOrNull { it.id == tid } ?: return
        val i = parse(rec.action) ?: return
        i.putExtra("pos", pos)
        val action = "Intent:" + i.toUri(Intent.URI_INTENT_SCHEME)
        update(c, rec.copy(action = action, details = rec.details.replace(Regex("Place: -?\\d+"), "Place: $pos")))
    }

    /** Takes the tile off the list. Its cells stay as they are, and stay unlinked. */
    fun remove(c: Context, id: String) {
        write(c, load(c).filter { it.id != id })
        sp(c).edit().putStringSet(GONE, gone(c) + id).apply()
    }
}
