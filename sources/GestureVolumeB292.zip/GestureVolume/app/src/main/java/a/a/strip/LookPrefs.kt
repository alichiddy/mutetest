package a.a.strip

import android.content.SharedPreferences

/**
 * The look settings of the cells window ("Look of the cells"). Folders have their own copy of every setting
 * (same name with `stripF` in front, e.g. stripLook -> stripFLook). A folder setting that was never set follows
 * the cells window, so nothing changes until the folders' own tools are used.
 */
object LookPrefs {
    val NAMES = listOf(
        "stripLook", "stripBackdropPct", "stripBackdropColor", "stripHalo", "stripTileColor", "stripIconPct", "stripGapPct",
        "stripLabelPct", "stripOutlineColor", "stripOutlinePct",
    )

    fun folderKey(name: String) = "stripF" + name.removePrefix("strip")

    /** The key to read: the folder's own when it has one, else the cells window's. */
    fun readKey(sp: SharedPreferences, folder: Boolean, name: String): String =
        if (folder && sp.contains(folderKey(name))) folderKey(name) else name

    /** The key to write for the cells window or for the folders. */
    fun writeKey(folder: Boolean, name: String): String = if (folder) folderKey(name) else name

    /** Folders go back to following the cells window. */
    fun clearFolders(sp: SharedPreferences) {
        val e = sp.edit()
        NAMES.forEach { e.remove(folderKey(it)) }
        e.apply()
    }
}
