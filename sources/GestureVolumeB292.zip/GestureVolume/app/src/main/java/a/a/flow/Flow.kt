package a.a.flow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom

/**
 * Where flows live: one text value, so the settings backup carries them too.
 *
 * Every flow has a permanent id ("#k3f9a2x1"), stored beside the flows. Cells, other flows and
 * automations that point at "#id" keep working when the flow is renamed, and the id travels with
 * the flow when it is shared, so a cell of the same id on another phone runs the shared flow.
 * Old references by name still work: a renamed flow keeps its old name as an alias.
 */
object FlowStore {
    private const val KEY = "flowsV1"
    private const val IDS = "flowIdsV1"      // {"<id>": "<current name>"}
    private const val ALIASES = "flowAliasV1" // {"<old name>": "<id>"}

    private fun prefs(context: Context) = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    private fun all(context: Context): JSONObject =
        runCatching { JSONObject(prefs(context).getString(KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())

    private fun obj(context: Context, key: String): JSONObject =
        runCatching { JSONObject(prefs(context).getString(key, "{}") ?: "{}") }.getOrDefault(JSONObject())

    private fun write(context: Context, flows: JSONObject, ids: JSONObject, aliases: JSONObject) {
        prefs(context).edit()
            .putString(KEY, flows.toString()).putString(IDS, ids.toString()).putString(ALIASES, aliases.toString())
            .apply()
    }

    fun names(context: Context): List<String> = all(context).keys().asSequence().sorted().toList()

    @Volatile private var cache: Map<String, String> = emptyMap()

    /** A reference as a name for display: ids become the flow's name. No Context needed. */
    fun display(ref: String): String = if (ref.startsWith("#")) cache[ref] ?: "(missing flow)" else ref

    // ---- ids -------------------------------------------------------------------------------------

    private val rnd = SecureRandom()
    private fun newId(taken: JSONObject): String {
        while (true) {
            val s = StringBuilder("#")
            repeat(8) { s.append("abcdefghijklmnopqrstuvwxyz0123456789"[rnd.nextInt(36)]) }
            if (!taken.has(s.toString())) return s.toString()
        }
    }

    /** Makes sure every flow has an id and every id points at a flow. Cheap; called before reading ids. */
    private fun synced(context: Context): Triple<JSONObject, JSONObject, JSONObject> {
        val flows = all(context)
        val ids = obj(context, IDS)
        val aliases = obj(context, ALIASES)
        var changed = false
        // Drop ids of flows that no longer exist (a restored backup, a manual edit).
        ids.keys().asSequence().toList().forEach { id -> if (!flows.has(ids.optString(id))) { ids.remove(id); changed = true } }
        val named = HashSet<String>().apply { ids.keys().forEach { add(ids.optString(it)) } }
        flows.keys().forEach { n -> if (n !in named) { ids.put(newId(ids), n); changed = true } }
        if (changed) write(context, flows, ids, aliases)
        cache = ids.keys().asSequence().associateWith { ids.optString(it) }
        return Triple(flows, ids, aliases)
    }

    /** The permanent id ("#...") of a flow, made if it had none. Null when there is no such flow. */
    fun idOf(context: Context, name: String): String? {
        val (flows, ids, _) = synced(context)
        if (!flows.has(name)) return null
        return ids.keys().asSequence().firstOrNull { ids.optString(it) == name }
    }

    /** Every script as (name, link): one pass over the saved data, instead of one full read per script. */
    fun links(context: Context): List<Pair<String, String>> {
        val (flows, ids, _) = synced(context)
        val idOfName = HashMap<String, String>()
        ids.keys().forEach { id -> idOfName[ids.optString(id)] = id }
        return flows.keys().asSequence().sorted().map { n -> n to (idOfName[n] ?: n) }.toList()
    }

    /** What a cell stores to run this flow: "MyFlow:" + this. Survives renames. */
    fun link(context: Context, name: String): String = idOf(context, name) ?: name

    /**
     * The current name for a reference: an id ("#..."), a name, or an old name of a renamed flow.
     * Null when no such flow exists.
     */
    fun resolve(context: Context, ref: String): String? {
        if (ref.isEmpty()) return null
        val (flows, ids, aliases) = synced(context)
        if (ref.startsWith("#")) return ids.optString(ref).takeIf { it.isNotEmpty() && flows.has(it) }
        if (flows.has(ref)) return ref
        val id = aliases.optString(ref)
        return if (id.isNotEmpty()) ids.optString(id).takeIf { it.isNotEmpty() && flows.has(it) } else null
    }

    // ---- reading and writing -----------------------------------------------------------------------

    /** [name] may also be an id or an old name. */
    fun load(context: Context, name: String): List<Step> {
        val key = resolve(context, name) ?: name
        val arr = all(context).optJSONArray(key) ?: return emptyList()
        return (0 until arr.length()).map { Step.fromJson(arr.getJSONObject(it)) }
    }

    /** The flow as canvas blocks: a flat (old) flow is converted, an empty one gets just its Start block. */
    fun loadGraph(context: Context, name: String): List<Step> = FlowGraph.normalize(load(context, name))

    fun save(context: Context, name: String, steps: List<Step>) = saveAll(context, mapOf(name to steps))

    fun saveAll(context: Context, flowsToSave: Map<String, List<Step>>) {
        val (flows, ids, aliases) = synced(context)
        flowsToSave.forEach { (name, steps) ->
            flows.put(name, JSONArray().apply { steps.forEach { put(it.toJson()) } })
            // A name taken by a new flow is no longer an alias of an old one.
            if (aliases.has(name)) aliases.remove(name)
        }
        write(context, flows, ids, aliases)
        synced(context) // gives any new flow its id
    }

    fun delete(context: Context, name: String) = deleteMany(context, listOf(name))

    fun deleteMany(context: Context, names: Collection<String>) {
        val (flows, ids, aliases) = synced(context)
        names.forEach { n ->
            val id = ids.keys().asSequence().firstOrNull { ids.optString(it) == n }
            flows.remove(n)
            if (id != null) {
                ids.remove(id)
                aliases.keys().asSequence().toList().forEach { a -> if (aliases.optString(a) == id) aliases.remove(a) }
            }
        }
        write(context, flows, ids, aliases)
    }

    /** True when renamed. False if [new] is empty, unchanged or already used. Links keep working. */
    fun rename(context: Context, old: String, new: String): Boolean {
        val n = new.trim()
        val (flows, ids, aliases) = synced(context)
        if (n.isEmpty() || n == old || !flows.has(old) || flows.has(n)) return false
        val id = ids.keys().asSequence().firstOrNull { ids.optString(it) == old } ?: return false
        flows.put(n, flows.get(old)); flows.remove(old)
        ids.put(id, n)
        aliases.put(old, id)          // cells that still say the old name keep finding it
        aliases.remove(n)
        write(context, flows, ids, aliases)
        return true
    }

    /** Copies a flow under a free name ("X copy", "X copy 2"...) with a new id. Returns the new name. */
    fun duplicate(context: Context, name: String): String? {
        val (flows, _, _) = synced(context)
        val src = flows.optJSONArray(name) ?: return null
        var n = "$name copy"
        var i = 2
        while (flows.has(n)) n = "$name copy ${i++}"
        flows.put(n, JSONArray(src.toString()))
        write(context, flows, obj(context, IDS), obj(context, ALIASES))
        synced(context)
        return n
    }

    /** A free name based on [wanted]: "X", "X 2", "X 3"... */
    fun freeName(context: Context, wanted: String): String {
        val have = names(context).toSet()
        val base = wanted.trim().ifEmpty { "Flow" }
        if (base !in have) return base
        var i = 2
        while ("$base $i" in have) i++
        return "$base $i"
    }

    /** The flows run by "Run flow" blocks inside [name]. */
    fun dependencies(context: Context, name: String): List<String> =
        load(context, name).filter { it.type == Step.RUN && it.a.isNotEmpty() }
            .mapNotNull { resolve(context, it.a) }.distinct()

    // ---- sharing: raw read and write by id, used by FlowShare ------------------------------------------

    internal fun rawSteps(context: Context, name: String): JSONArray? = all(context).optJSONArray(name)

    /** Puts a flow in with the given id. Same id here already: its steps are replaced and its name kept. */
    internal fun putShared(context: Context, id: String, wantedName: String, steps: JSONArray): String {
        val (flows, ids, aliases) = synced(context)
        val existing = ids.optString(id)
        val name: String
        if (existing.isNotEmpty() && flows.has(existing)) {
            name = existing
        } else {
            var n = wantedName.trim().ifEmpty { "Shared flow" }
            if (flows.has(n)) { var i = 2; while (flows.has("$n $i")) i++; n = "$n $i" }
            name = n
            ids.put(id, name)
            aliases.remove(name)
        }
        flows.put(name, steps)
        write(context, flows, ids, aliases)
        return name
    }
}
