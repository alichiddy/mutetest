package a.a.ui.screens.strip

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import a.a.strip.ShortcutTools

/** Test (run now) and Add to launcher for the shortcut shown above: used in the cell editor. */
@Composable
fun ShortcutToolRow(label: String, icon: String, action: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var launcher by remember { mutableStateOf(false) }
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { ShortcutTools.test(ctx, label, icon, action) }, modifier = Modifier.weight(1f)) { Text("Test (run now)") }
        OutlinedButton(onClick = { launcher = true }, modifier = Modifier.weight(1f)) { Text("Add to launcher") }
    }
    if (launcher) AddToLauncherDialog(label, icon, action) { launcher = false }
}

/**
 * Shown when a shortcut is tapped in a list: it can be tried (Test), sent to a launcher, or used.
 * [onUse] carries on exactly as the tap did before.
 */
@Composable
fun ShortcutGateDialog(label: String, icon: String, action: String, onUse: () -> Unit, onDismiss: () -> Unit) {
    var launcher by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    if (launcher) { AddToLauncherDialog(label, icon, action) { launcher = false }; return }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(label.ifBlank { "Shortcut" }) },
        text = {
            Column {
                Text("Try it before you use it.")
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { ShortcutTools.test(ctx, label, icon, action) }, modifier = Modifier.weight(1f)) { Text("Test (run now)") }
                    OutlinedButton(onClick = { launcher = true }, modifier = Modifier.weight(1f)) { Text("Add to launcher") }
                }
            }
        },
        confirmButton = { TextButton(onClick = onUse) { Text("Use") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun Choice(text: String, bold: Boolean = false, onClick: (() -> Unit)? = null) {
    Text(
        text,
        fontWeight = if (bold) FontWeight.SemiBold else null,
        modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(vertical = 10.dp, horizontal = 4.dp),
    )
}

/** Where the shortcut goes: the default launcher, another launcher, a ready app slot (A) or a new APK app (B). */
@Composable
fun AddToLauncherDialog(label: String, icon: String, action: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var slots by remember { mutableStateOf(false) }
    val others = remember { ShortcutTools.otherLaunchers(ctx) }
    val defName = remember {
        ShortcutTools.defaultLauncher(ctx)?.let { p -> runCatching { ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(p, 0)).toString() }.getOrNull() }
    }
    if (action.isBlank()) {
        AlertDialog(onDismissRequest = onDismiss, title = { Text("Nothing chosen yet") }, text = { Text("Choose a shortcut first.") },
            confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } })
        return
    }
    if (slots) { SlotDialog(label, icon, action, onDismiss); return }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add \"" + label.ifBlank { "shortcut" } + "\"") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Choice("Home screen of the default launcher" + (defName?.let { " ($it)" } ?: "")) {
                    val ok = ShortcutTools.pinToDefault(ctx, label, icon, action)
                    Toast.makeText(ctx, if (ok) "Your launcher will ask you to confirm." else "This launcher does not accept shortcuts from apps.", Toast.LENGTH_LONG).show()
                    onDismiss()
                }
                others.forEach { (pkg, name) ->
                    Choice("Launcher: $name\n(works only if that launcher still accepts the old add-shortcut request)") {
                        ShortcutTools.sendLegacy(ctx, pkg, label, icon, action)
                        Toast.makeText(ctx, "Sent to $name. If nothing appears, it does not accept it.", Toast.LENGTH_LONG).show()
                        onDismiss()
                    }
                }
                Choice("As an app (also works where only apps are allowed, like kids mode)", bold = true)
                Choice("A: one of the ready app slots (A 1 … A ${ShortcutTools.SLOTS}). Install once, change its shortcut any time.") { slots = true }
                Choice("B: build a new APK app for this shortcut, with its own name and icon.") {
                    ShortcutTools.buildOwnApp(ctx, label, icon, action)
                    onDismiss()
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun SlotDialog(label: String, icon: String, action: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val rows = remember {
        (1..ShortcutTools.SLOTS).map { n ->
            val pkg = ShortcutTools.STUB_PREFIX + "s$n"
            val installed = ShortcutTools.isInstalled(ctx, pkg)
            val e = ShortcutTools.stubEntry(ctx, pkg)
            n to ("A $n  -  " + (if (installed) "installed" else "not installed") + "  -  " + (e?.let { "runs: " + it.label.ifBlank { it.action.take(24) } } ?: "free"))
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Which app slot?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("The chosen slot runs \"" + label.ifBlank { "this shortcut" } + "\". A slot that is not installed opens the installer.")
                rows.forEach { (n, text) ->
                    Choice(text) { ShortcutTools.useSlot(ctx, n, label, icon, action); onDismiss() }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
