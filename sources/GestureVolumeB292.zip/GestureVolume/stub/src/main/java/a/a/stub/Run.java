package a.a.stub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/** Hands over to A: tells A's StubRunActivity which helper app was tapped (this app's own package name). */
public class Run extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            Intent i = new Intent();
            i.setClassName("a.a", "a.a.strip.StubRunActivity");
            i.putExtra("stub", getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(this, "A is not installed.", Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
