// Tiny helper apps for A's shortcuts: the ready slots (a.a.sc.s1 .. s10, named "A 1" .. "A 10") and one
// template (a.a.sc.tpl) that A copies, renames and signs on the phone to make an APK for one shortcut.
// Each only starts A's StubRunActivity with its own package name. Built by A's build, never installed by it alone.
plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "a.a.stub"
    compileSdk = 37

    defaultConfig {
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    flavorDimensions += "slot"
    productFlavors {
        for (i in 1..10) {
            create("s$i") {
                dimension = "slot"
                applicationId = "a.a.sc.s$i"
                manifestPlaceholders["stubLabel"] = "A $i"
            }
        }
        create("tpl") {
            dimension = "slot"
            applicationId = "a.a.sc.tpl"
            manifestPlaceholders["stubLabel"] = "TPLLABEL"
        }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
