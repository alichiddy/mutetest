package a.volmap;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    static final String ACTION_EDIT = "com.twofortyfouram.locale.intent.action.EDIT_SETTING";
    static final String EXTRA_BUNDLE = "com.twofortyfouram.locale.intent.extra.BUNDLE";
    static final String EXTRA_BLURB = "com.twofortyfouram.locale.intent.extra.BLURB";
    static final String KEY_ACTION = "action";
    static final String KEY_MODE = "mode"; // older extra: toggle / mute / unmute
    private static final int REQ_SHORTCUT = 1, REQ_BACKUP = 2, REQ_RESTORE = 3, REQ_SHIZUKU = 100;

    private boolean plugin;
    private TextView status, logView;
    private Button grabBtn, routeBtn;
    private EditText longEt, dblEt;
    private String pendingGesture;
    private final Map<String, Button> buttons = new HashMap<String, Button>();

    private final Shizuku.OnRequestPermissionResultListener permListener =
            (requestCode, grantResult) -> runOnUiThread(() -> refresh());

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        plugin = ACTION_EDIT.equals(getIntent().getAction());
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);
        sv.addView(root);

        if (plugin) {
            TextView t = new TextView(this);
            t.setText("Choose the action to run");
            root.addView(t);
            List<String> ids = Mute.allIds(this);
            List<String> labels = Mute.allLabels(this);
            for (int i = 0; i < ids.size(); i++) {
                final String id = ids.get(i);
                if (Mute.NONE.equals(id) || Mute.SHORTCUT.equals(id)) continue;
                final String label = labels.get(i);
                Button btn = new Button(this);
                btn.setAllCaps(false);
                btn.setText(label);
                btn.setOnClickListener(v -> {
                    Bundle bundle = new Bundle();
                    bundle.putString(KEY_ACTION, id);
                    Intent r = new Intent();
                    r.putExtra(EXTRA_BUNDLE, bundle);
                    r.putExtra(EXTRA_BLURB, label);
                    setResult(RESULT_OK, r);
                    finish();
                });
                root.addView(btn);
            }
            setContentView(sv);
            return;
        }

        try { Shizuku.addRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }

        status = new TextView(this);
        root.addView(status);

        addButton(root, "Open accessibility settings",
                () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton(root, "Grant Shizuku access", () -> grantShizuku());
        addButton(root, "Open Shizuku", () -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) startActivity(i);
            else toast("Shizuku is not installed");
        });
        addButton(root, "Copy the keyboard-trick setup command", () -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("setup", "pm grant a.volmap android.permission.WRITE_SECURE_SETTINGS"));
            toast("Copied. Run it once in your privileged shell.");
        });
        addButton(root, "Test: send key 164 (mute) now", () -> { Mute.run(this, Mute.TOGGLE_MUTE, null); refresh(); });
        addButton(root, "Restore my keyboard", () -> {
            try {
                ImeKey.forceBack(this);
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showInputMethodPicker();
            } catch (Throwable t) {
                toast("" + t);
            }
            refresh();
        });

        routeBtn = addButton(root, "", () -> {
            Mute.prefs(this).edit().putString("route", Mute.shizukuFirst(this) ? "ime" : "auto").apply();
            refresh();
        });
        grabBtn = addButton(root, "", () -> {
            Mute.prefs(this).edit().putBoolean("grab", !Mute.grab(this)).apply();
            refresh();
        });

        TextView tt = new TextView(this);
        tt.setText("\nLong press time (ms)  |  Max gap between double press taps (ms)");
        root.addView(tt);
        longEt = new EditText(this);
        longEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        longEt.setText(String.valueOf(Mute.longMs(this)));
        root.addView(longEt);
        dblEt = new EditText(this);
        dblEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        dblEt.setText(String.valueOf(Mute.dblMs(this)));
        root.addView(dblEt);
        addButton(root, "Save timings", () -> saveTimings());

        addButton(root, "Shell commands...", () -> showShellList());

        TextView hint = new TextView(this);
        hint.setText("\nChoose what each press does. Presses left on \"Do nothing\" keep the normal volume behavior.");
        root.addView(hint);

        for (int i = 0; i < Mute.GESTURES.length; i++) {
            final String g = Mute.GESTURES[i];
            final String title = Mute.GESTURE_LABELS[i];
            buttons.put(g, addButton(root, "", () -> pick(g, title)));
        }

        TextView bk = new TextView(this);
        bk.setText("\nBackup");
        root.addView(bk);
        addButton(root, "Backup settings to a file", () -> {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "avolmap-backup.json");
            startActivityForResult(i, REQ_BACKUP);
        });
        addButton(root, "Restore settings from a file", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_RESTORE);
        });

        TextView logTitle = new TextView(this);
        logTitle.setText("\nLog");
        root.addView(logTitle);
        addButton(root, "Refresh log", () -> refresh());
        addButton(root, "Clear log", () -> { Mute.clearLog(this); refresh(); });
        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        root.addView(logView);
        setContentView(sv);
    }

    private Button addButton(LinearLayout root, String text, final Runnable r) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setOnClickListener(v -> r.run());
        root.addView(b);
        return b;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() {
        super.onResume();
        if (!plugin) ImeKey.restoreIfStuck(this);
        refresh();
    }

    @Override protected void onDestroy() {
        if (!plugin) {
            try { Shizuku.removeRequestPermissionResultListener(permListener); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }

    private void grantShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                toast("Shizuku is not running. Open Shizuku and start it first.");
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                toast("Already granted");
            } else {
                Shizuku.requestPermission(REQ_SHIZUKU);
            }
        } catch (Throwable t) {
            toast("Shizuku error: " + t);
        }
    }

    private void saveTimings() {
        try {
            int l = Integer.parseInt(longEt.getText().toString().trim());
            int d = Integer.parseInt(dblEt.getText().toString().trim());
            l = Math.max(50, Math.min(3000, l));
            d = Math.max(50, Math.min(2000, d));
            Mute.prefs(this).edit().putInt("long_ms", l).putInt("dbl_ms", d).apply();
            longEt.setText(String.valueOf(l));
            dblEt.setText(String.valueOf(d));
            toast("Saved");
        } catch (Exception e) {
            toast("Enter whole numbers");
        }
    }

    private void refresh() {
        if (plugin) return;
        status.setText("Accessibility service: " + (MuteService.instance != null ? "ON" : "OFF - enable it in the first button")
                + "\nShizuku: " + Priv.status()
                + "\nKeyboard trick setup (WRITE_SECURE_SETTINGS): " + (ImeKey.canSend(this) ? "done" : "NOT done"));
        routeBtn.setText("Key route: " + (Mute.shizukuFirst(this)
                ? "Shizuku when ready, else keyboard trick" : "Keyboard trick only") + "\n(tap to change)");
        grabBtn.setText("Grab volume keys: " + (Mute.grab(this) ? "ON" : "OFF") + "\n(tap to change)");
        for (int i = 0; i < Mute.GESTURES.length; i++) {
            String g = Mute.GESTURES[i];
            String id = Mute.getAction(this, g);
            String txt = Mute.label(this, id);
            if (Mute.SHORTCUT.equals(id)) txt = "Shortcut: " + Mute.getShortcutName(this, g);
            buttons.get(g).setText(Mute.GESTURE_LABELS[i] + "\n" + txt);
        }
        logView.setText(Mute.readLog(this));
    }

    private void pick(final String gesture, String title) {
        final List<String> ids = Mute.allIds(this);
        List<String> labels = Mute.allLabels(this);
        new AlertDialog.Builder(this).setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    String id = ids.get(which);
                    if (Mute.SHORTCUT.equals(id)) {
                        pendingGesture = gesture;
                        chooseShortcutSource();
                    } else {
                        Mute.prefs(this).edit().putString(gesture, id).apply();
                        refresh();
                    }
                }).show();
    }

    // ---- shell commands ----

    private void showShellList() {
        final List<Shell.Cmd> l = Shell.list(this);
        List<String> names = new ArrayList<String>();
        names.add("+ Add a shell command");
        for (Shell.Cmd x : l) names.add(x.name + (x.priv ? "   (Shizuku)" : ""));
        new AlertDialog.Builder(this).setTitle("Shell commands")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    if (which == 0) editShell(null);
                    else editShell(l.get(which - 1));
                }).show();
    }

    private void editShell(final Shell.Cmd existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);
        final EditText nameEt = new EditText(this);
        nameEt.setHint("Name (shown in the action list)");
        nameEt.setInputType(InputType.TYPE_CLASS_TEXT);
        final EditText cmdEt = new EditText(this);
        cmdEt.setHint("Command, e.g.  input keyevent 164");
        cmdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        cmdEt.setMinLines(3);
        final CheckBox privBox = new CheckBox(this);
        privBox.setText("Run with Shizuku (shell UID 2000)");
        if (existing != null) {
            nameEt.setText(existing.name);
            cmdEt.setText(existing.cmd);
            privBox.setChecked(existing.priv);
        }
        box.addView(nameEt);
        box.addView(cmdEt);
        box.addView(privBox);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "New shell command" : "Edit shell command")
                .setView(box)
                .setPositiveButton("Save", (d, w) ->
                        saveShell(existing, nameEt.getText().toString(), cmdEt.getText().toString(), privBox.isChecked()))
                .setNeutralButton("Save & test", (d, w) -> {
                    Shell.Cmd c = saveShell(existing, nameEt.getText().toString(), cmdEt.getText().toString(), privBox.isChecked());
                    if (c != null) {
                        Shell.run(this, c);
                        toast("Running... see the log");
                    }
                });
        if (existing != null) {
            b.setNegativeButton("Delete", (d, w) -> {
                List<Shell.Cmd> l = Shell.list(this);
                for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id.equals(existing.id)) l.remove(i);
                Shell.save(this, l);
                refresh();
            });
        } else {
            b.setNegativeButton("Cancel", (d, w) -> { });
        }
        b.show();
    }

    private Shell.Cmd saveShell(Shell.Cmd existing, String name, String cmd, boolean priv) {
        String n = name.trim();
        if (n.isEmpty()) {
            toast("Give it a name");
            return null;
        }
        List<Shell.Cmd> l = Shell.list(this);
        Shell.Cmd target = null;
        if (existing != null) {
            for (Shell.Cmd x : l) if (x.id.equals(existing.id)) target = x;
        }
        if (target == null) {
            target = new Shell.Cmd();
            target.id = Shell.newId(l);
            l.add(target);
        }
        target.name = n;
        target.cmd = cmd;
        target.priv = priv;
        Shell.save(this, l);
        refresh();
        return target;
    }

    // ---- shortcuts ----

    private void chooseShortcutSource() {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> list = pm.queryIntentActivities(new Intent(Intent.ACTION_CREATE_SHORTCUT), 0);
        if (list.isEmpty()) {
            toast("No shortcut sources found");
            return;
        }
        List<String> names = new ArrayList<String>();
        for (ResolveInfo ri : list) names.add(ri.loadLabel(pm).toString());
        new AlertDialog.Builder(this).setTitle("Shortcut from...")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    ActivityInfo ai = list.get(which).activityInfo;
                    Intent pick = new Intent(Intent.ACTION_CREATE_SHORTCUT);
                    pick.setClassName(ai.packageName, ai.name);
                    try {
                        startActivityForResult(pick, REQ_SHORTCUT);
                    } catch (Exception e) {
                        toast("Could not open: " + e);
                    }
                }).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        if (req == REQ_SHORTCUT) {
            if (pendingGesture == null) return;
            Intent sc = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_INTENT);
            String name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);
            if (sc == null) {
                toast("That app did not return a shortcut");
                return;
            }
            Mute.prefs(this).edit()
                    .putString(pendingGesture, Mute.SHORTCUT)
                    .putString("sc_" + pendingGesture, sc.toUri(Intent.URI_INTENT_SCHEME))
                    .putString("scn_" + pendingGesture, name == null ? "" : name)
                    .apply();
            refresh();
        } else if (req == REQ_BACKUP) {
            try {
                Uri uri = data.getData();
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(Backup.export(this).getBytes("UTF-8"));
                os.close();
                toast("Backup saved");
            } catch (Exception e) {
                toast("Backup failed: " + e);
            }
        } else if (req == REQ_RESTORE) {
            try {
                Uri uri = data.getData();
                InputStream in = getContentResolver().openInputStream(uri);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                int count = Backup.restore(this, bo.toString("UTF-8"));
                longEt.setText(String.valueOf(Mute.longMs(this)));
                dblEt.setText(String.valueOf(Mute.dblMs(this)));
                refresh();
                toast("Restored " + count + " settings");
            } catch (Exception e) {
                toast("Restore failed: " + e);
            }
        }
    }
}
