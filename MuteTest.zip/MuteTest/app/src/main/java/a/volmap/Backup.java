package a.volmap;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;

/** Backup / restore of every setting (mappings, shortcuts, shell commands, timings) as a JSON file. */
final class Backup {
    private static final String APP = "a.volmap";

    static String export(Context c) throws Exception {
        JSONObject root = new JSONObject();
        root.put("app", APP);
        root.put("version", 1);
        JSONObject data = new JSONObject();
        for (Map.Entry<String, ?> e : Mute.prefs(c).getAll().entrySet()) {
            if ("ime_prev".equals(e.getKey())) continue; // device specific
            data.put(e.getKey(), e.getValue());
        }
        root.put("settings", data);
        return root.toString(2);
    }

    /** Replaces the current settings; returns how many were restored. */
    static int restore(Context c, String json) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!APP.equals(root.optString("app"))) throw new IllegalArgumentException("this is not an A VolMap backup");
        JSONObject data = root.getJSONObject("settings");
        SharedPreferences prefs = Mute.prefs(c);
        String prev = prefs.getString("ime_prev", null);
        SharedPreferences.Editor ed = prefs.edit();
        ed.clear();
        if (prev != null) ed.putString("ime_prev", prev);
        int n = 0;
        Iterator<String> it = data.keys();
        while (it.hasNext()) {
            String k = it.next();
            Object v = data.get(k);
            if (v instanceof Boolean) ed.putBoolean(k, ((Boolean) v).booleanValue());
            else if (v instanceof Integer) ed.putInt(k, ((Integer) v).intValue());
            else if (v instanceof Long) ed.putInt(k, ((Long) v).intValue());
            else if (v instanceof String) ed.putString(k, (String) v);
            else continue;
            n++;
        }
        ed.apply();
        return n;
    }
}
