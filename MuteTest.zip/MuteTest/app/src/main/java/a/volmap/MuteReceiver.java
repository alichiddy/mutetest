package a.volmap;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/**
 * Broadcast + Tasker/Locale plug-in. Extra "action" can be: toggle_mute, mute, unmute, toggle_flashlight,
 * or sh:<shell command name or id>. Older extra "mode" (toggle / mute / unmute) still works.
 */
public class MuteReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String action = null, mode = null;
        Bundle b = i.getBundleExtra(MainActivity.EXTRA_BUNDLE);   // Tasker/Locale plug-in
        if (b != null) {
            action = b.getString(MainActivity.KEY_ACTION);
            mode = b.getString(MainActivity.KEY_MODE);
        }
        if (action == null) action = i.getStringExtra(MainActivity.KEY_ACTION); // plain broadcast
        if (mode == null) mode = i.getStringExtra(MainActivity.KEY_MODE);
        if (action == null) {
            action = "mute".equals(mode) ? Mute.MUTE : "unmute".equals(mode) ? Mute.UNMUTE : Mute.TOGGLE_MUTE;
        }
        Mute.log(c, "RECEIVED " + i.getAction() + " -> " + action);
        Mute.run(c, action, null);
    }
}
