package a.volmap;

import android.content.Context;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.os.Looper;

final class Torch {
    private static volatile boolean on;
    private static String camId;
    private static boolean registered;

    static synchronized void init(Context ctx) throws Exception {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        if (camId == null) {
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (flash != null && flash.booleanValue() && facing != null
                        && facing.intValue() == CameraCharacteristics.LENS_FACING_BACK) {
                    camId = id;
                    break;
                }
            }
            if (camId == null) throw new IllegalStateException("no flashlight found");
        }
        if (!registered) {
            cm.registerTorchCallback(new CameraManager.TorchCallback() {
                @Override public void onTorchModeChanged(String id, boolean enabled) {
                    if (id.equals(camId)) on = enabled;
                }
            }, new Handler(Looper.getMainLooper()));
            registered = true;
        }
    }

    static synchronized void toggle(Context ctx) throws Exception {
        init(ctx);
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        cm.setTorchMode(camId, !on);
    }
}
