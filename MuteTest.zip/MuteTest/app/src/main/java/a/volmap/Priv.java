package a.volmap;

import android.content.Context;
import android.content.pm.PackageManager;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;
import rikka.shizuku.Shizuku;

/** Runs commands with shell privileges (UID 2000) through Shizuku. */
final class Priv {
    private static final AtomicBoolean busy = new AtomicBoolean(false);

    static boolean ready() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static String status() {
        try {
            if (!Shizuku.pingBinder()) return "not running (start Shizuku)";
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    ? "ready (shell UID 2000)" : "running, access not granted";
        } catch (Throwable t) {
            return "unavailable";
        }
    }

    static Process newProcess(String[] cmd) throws Exception {
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        return (Process) m.invoke(null, cmd, null, null);
    }

    /** Runs "sh -c cmd" privileged on a background thread. dropIfBusy skips it if a previous drop-able one is still running. */
    static void exec(final Context c, final String cmd, final boolean dropIfBusy) {
        if (dropIfBusy && !busy.compareAndSet(false, true)) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Process p = newProcess(new String[]{"sh", "-c", cmd});
                    p.waitFor();
                } catch (Throwable t) {
                    Mute.log(c, "privileged exec failed: " + t);
                } finally {
                    if (dropIfBusy) busy.set(false);
                }
            }
        }).start();
    }
}
