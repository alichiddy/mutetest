package a.volmap;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

/**
 * Volume key gestures, volkey style:
 *  - a short press fires at once (no waiting for a possible double press)
 *  - a second tap within the double-press gap fires "double" (the first tap already fired "short")
 *  - a long press fires while the key is still held
 */
public class MuteService extends AccessibilityService {
    static volatile MuteService instance;

    private static class Btn {
        final String prefix;
        final int keyCode;
        long downTime, lastTapUp;
        boolean longFired, passing;
        Runnable longRun;
        Btn(String prefix, int keyCode) { this.prefix = prefix; this.keyCode = keyCode; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Btn up = new Btn("up", KeyEvent.KEYCODE_VOLUME_UP);
    private final Btn dn = new Btn("dn", KeyEvent.KEYCODE_VOLUME_DOWN);

    @Override protected void onServiceConnected() {
        instance = this;
        try { Torch.init(this); } catch (Throwable ignored) { }
        ImeKey.restoreIfStuck(this);
    }

    @Override public boolean onUnbind(Intent i) {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        return super.onUnbind(i);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    private boolean has(Btn b, String g) {
        return !Mute.NONE.equals(Mute.getAction(this, b.prefix + "_" + g));
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        final Btn b;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) b = up;
        else if (code == KeyEvent.KEYCODE_VOLUME_DOWN) b = dn;
        else return false;
        if (e.getDeviceId() < 0) return false; // virtual keyboard keys are not physical presses

        boolean hasShort = has(b, "short"), hasLong = has(b, "long"), hasDouble = has(b, "double");
        if (!hasShort && !hasLong && !hasDouble) return false; // nothing mapped: system handles it
        final boolean grab = Mute.grab(this);

        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                b.downTime = SystemClock.uptimeMillis();
                b.longFired = false;
                b.passing = false;
                if (b.longRun != null) handler.removeCallbacks(b.longRun);
                b.longRun = null;
                if (hasLong) {
                    b.longRun = new Runnable() {
                        @Override public void run() {
                            b.longRun = null;
                            b.longFired = true;
                            b.lastTapUp = 0;
                            fire(b, "long", grab);
                        }
                    };
                    handler.postDelayed(b.longRun, Mute.longMs(this));
                }
                return grab;
            }
            if (grab && !hasLong && !b.passing && !b.longFired) {
                // held with no long-press action: hand the press back so the volume keeps changing
                b.passing = true;
                b.lastTapUp = 0;
                Mute.key(this, b.keyCode);
                return false;
            }
            return grab && !b.passing;
        }

        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (b.longRun != null) { handler.removeCallbacks(b.longRun); b.longRun = null; }
            if (b.passing) { b.passing = false; return false; }
            if (b.longFired) { b.longFired = false; return grab; }
            long now = SystemClock.uptimeMillis();
            if (hasDouble && b.lastTapUp > 0 && b.downTime - b.lastTapUp <= Mute.dblMs(this)) {
                b.lastTapUp = 0;
                fire(b, "double", grab);
            } else {
                b.lastTapUp = hasDouble ? now : 0;
                fire(b, "short", grab);
            }
            return grab;
        }
        return grab;
    }

    private void fire(Btn b, String g, boolean grab) {
        String id = b.prefix + "_" + g;
        String action = Mute.getAction(this, id);
        if (Mute.NONE.equals(action)) {
            if (grab && "short".equals(g)) Mute.key(this, b.keyCode); // not mapped: normal volume press
            return;
        }
        Mute.run(this, action, Mute.getShortcut(this, id));
    }
}
