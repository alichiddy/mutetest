package a.volmap;

import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

/** Invisible keyboard: sends the queued key presses, then hands the real keyboard back. */
public class KeyIME extends InputMethodService {

    @Override public void onCreate() {
        super.onCreate();
        Mute.log(this, "key sender started");
    }

    @Override public void onInitializeInterface() {
        super.onInitializeInterface();
        flush("init");
    }

    @Override public void onBindInput() {
        super.onBindInput();
        flush("bind");
    }

    @Override public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        flush("start");
    }

    @Override public boolean onEvaluateInputViewShown() { return false; }
    @Override public boolean onEvaluateFullscreenMode() { return false; }

    private void flush(String where) {
        if (!ImeKey.hasPending()) {
            // started without a key to send (late start, or someone picked us): never stay selected
            giveBack(where + ", nothing to send");
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            Mute.log(this, "key sender (" + where + "): no input connection yet");
            return;
        }
        Integer k;
        boolean sent = false;
        while ((k = ImeKey.poll()) != null) {
            sendDownUpKeyEvents(k.intValue());
            sent = true;
            Mute.log(this, "key sender (" + where + "): sent key " + k);
        }
        if (sent) giveBack(where + ", sent");
    }

    /** Puts the user's keyboard back: ask the system to switch (like a user pick), then write the setting. */
    private void giveBack(String why) {
        String target = ImeKey.target(this);
        try {
            if (Build.VERSION.SDK_INT >= 28 && target != null) switchInputMethod(target);
        } catch (Throwable t) {
            Mute.log(this, "switchInputMethod failed: " + t);
        }
        ImeKey.restore(this);
    }
}
