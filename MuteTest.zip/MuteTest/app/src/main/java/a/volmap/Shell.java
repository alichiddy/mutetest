package a.volmap;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** User-defined shell commands, saved in the settings. */
final class Shell {
    static final class Cmd {
        String id = "", name = "", cmd = "";
        boolean priv;
    }

    private static final String KEY = "shell_cmds";

    static synchronized List<Cmd> list(Context c) {
        List<Cmd> out = new ArrayList<Cmd>();
        try {
            JSONArray a = new JSONArray(Mute.prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Cmd x = new Cmd();
                x.id = o.optString("id");
                x.name = o.optString("name");
                x.cmd = o.optString("cmd");
                x.priv = o.optBoolean("priv", false);
                out.add(x);
            }
        } catch (Exception ignored) { }
        return out;
    }

    static synchronized void save(Context c, List<Cmd> l) {
        JSONArray a = new JSONArray();
        try {
            for (Cmd x : l) {
                JSONObject o = new JSONObject();
                o.put("id", x.id);
                o.put("name", x.name);
                o.put("cmd", x.cmd);
                o.put("priv", x.priv);
                a.put(o);
            }
        } catch (Exception ignored) { }
        Mute.prefs(c).edit().putString(KEY, a.toString()).apply();
    }

    /** Finds a command by its id, or by its name (case-insensitive). */
    static Cmd find(Context c, String idOrName) {
        List<Cmd> l = list(c);
        for (Cmd x : l) if (x.id.equals(idOrName)) return x;
        for (Cmd x : l) if (x.name.equalsIgnoreCase(idOrName)) return x;
        return null;
    }

    static String newId(List<Cmd> l) {
        int max = 0;
        for (Cmd x : l) {
            try { max = Math.max(max, Integer.parseInt(x.id)); } catch (Exception ignored) { }
        }
        return String.valueOf(max + 1);
    }

    static void run(final Context c, final Cmd cmd) {
        final Context app = c.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                String who = "app uid";
                String out = "";
                int rc = -1;
                try {
                    final Process p;
                    if (cmd.priv && Priv.ready()) {
                        p = Priv.newProcess(new String[]{"sh", "-c", cmd.cmd});
                        who = "shell uid 2000 via Shizuku";
                    } else {
                        if (cmd.priv) who = "app uid (Shizuku not ready)";
                        p = new ProcessBuilder("sh", "-c", cmd.cmd).start();
                    }
                    Thread dog = new Thread(new Runnable() {
                        @Override public void run() {
                            try { Thread.sleep(20000); p.destroy(); } catch (InterruptedException ignored) { }
                        }
                    });
                    dog.setDaemon(true);
                    dog.start();
                    String o = read(p.getInputStream());
                    String e = read(p.getErrorStream());
                    rc = p.waitFor();
                    dog.interrupt();
                    out = (o + (e.isEmpty() ? "" : " | stderr: " + e)).trim();
                } catch (Throwable t) {
                    out = "ERR " + t;
                }
                Mute.log(app, "shell '" + cmd.name + "' [" + who + "] exit=" + rc
                        + (out.isEmpty() ? "" : " out=" + (out.length() > 300 ? out.substring(0, 300) + "..." : out)));
            }
        }).start();
    }

    private static String read(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        int n;
        while ((n = in.read(buf)) > 0 && b.size() < 4000) b.write(buf, 0, n);
        return b.toString("UTF-8");
    }
}
