package com.example.mutetest;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import java.util.ArrayDeque;

/**
 * Button Mapper's trick: briefly make our invisible keyboard the default one (needs WRITE_SECURE_SETTINGS,
 * granted once over ADB). The keyboard sends the key press to the app in front, which is how the system
 * treats it like a real key press. Then the user's own keyboard is put back.
 */
final class ImeKey {
    static final String IME_ID = "com.example.mutetest/.KeyIME";
    private static final String SETTING = "default_input_method";
    private static final ArrayDeque<Integer> queue = new ArrayDeque<Integer>();
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static Runnable restoreRun;
    private static int rounds;

    static boolean canSend(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED;
    }

    static synchronized void send(Context c, int keyCode) {
        Context app = c.getApplicationContext();
        queue.add(Integer.valueOf(keyCode));
        switchIme(app);
    }

    private static synchronized void switchIme(Context app) {
        ContentResolver cr = app.getContentResolver();
        String cur = Settings.Secure.getString(cr, SETTING);
        if (!IME_ID.equals(cur)) {
            if (cur != null) Mute.prefs(app).edit().putString("ime_prev", cur).apply();
            Settings.Secure.putString(cr, SETTING, IME_ID);
            Mute.log(app, "keyboard switched to the key sender (was " + cur + ")");
        }
        scheduleRestore(app);
    }

    private static void scheduleRestore(final Context app) {
        if (restoreRun != null) handler.removeCallbacks(restoreRun);
        restoreRun = new Runnable() {
            @Override public void run() { restore(app); }
        };
        handler.postDelayed(restoreRun, 2000); // safety net: always give the keyboard back
    }

    /** Called by the key sender keyboard. */
    static synchronized Integer poll() {
        Integer k = queue.poll();
        if (k != null) rounds = 0;
        return k;
    }

    static synchronized void restore(final Context c) {
        final Context app = c.getApplicationContext();
        ContentResolver cr = app.getContentResolver();
        String prev = Mute.prefs(app).getString("ime_prev", null);
        String cur = Settings.Secure.getString(cr, SETTING);
        if (IME_ID.equals(cur) && prev != null) {
            Settings.Secure.putString(cr, SETTING, prev);
            Mute.log(app, "keyboard restored: " + prev);
        }
        if (!queue.isEmpty()) {
            if (++rounds <= 1) {
                handler.postDelayed(new Runnable() {
                    @Override public void run() { switchIme(app); }
                }, 250);
            } else {
                queue.clear();
                rounds = 0;
                Mute.log(app, "key sender never got an input connection - key dropped");
            }
        }
    }

    /** If the app was killed while our keyboard was selected, give the real one back. */
    static void restoreIfStuck(Context c) {
        try {
            Context app = c.getApplicationContext();
            String cur = Settings.Secure.getString(app.getContentResolver(), SETTING);
            if (IME_ID.equals(cur) && queue.isEmpty()) restore(app);
        } catch (Throwable ignored) { }
    }
}
