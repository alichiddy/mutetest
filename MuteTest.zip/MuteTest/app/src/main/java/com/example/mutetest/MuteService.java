package com.example.mutetest;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class MuteService extends AccessibilityService {
    static volatile MuteService instance;

    private static final int LONG_MS = 500;   // hold time for a long press
    private static final int DOUBLE_MS = 300; // window to wait for a second tap

    private static class Btn {
        final String prefix;
        boolean longFired, cancelled, pendingTap;
        Runnable longRun, tapRun;
        Btn(String prefix) { this.prefix = prefix; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Btn up = new Btn("up");
    private final Btn dn = new Btn("dn");

    @Override protected void onServiceConnected() { instance = this; }

    @Override public boolean onUnbind(Intent i) {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        return super.onUnbind(i);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    private boolean has(Btn b, String g) {
        return !Mute.NONE.equals(Mute.getAction(this, b.prefix + "_" + g));
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        final Btn b;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) b = up;
        else if (code == KeyEvent.KEYCODE_VOLUME_DOWN) b = dn;
        else return false;

        boolean hasShort = has(b, "short"), hasLong = has(b, "long"), hasDouble = has(b, "double");
        if (!hasShort && !hasLong && !hasDouble) return false; // nothing mapped: system handles it

        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                b.longFired = false;
                b.cancelled = false;
                if (hasLong) {
                    b.longRun = new Runnable() {
                        @Override public void run() {
                            b.longRun = null;
                            b.longFired = true;
                            cancelPending(b);
                            fire(b, "long");
                        }
                    };
                    handler.postDelayed(b.longRun, LONG_MS);
                }
            } else if (!hasLong) {
                // held with no long-press action: act like the normal key and repeat the default
                if (!b.cancelled) { b.cancelled = true; cancelPending(b); }
                defaultAdjust(b);
            }
            return true;
        }

        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (b.longRun != null) { handler.removeCallbacks(b.longRun); b.longRun = null; }
            if (b.longFired || b.cancelled) {
                b.longFired = false;
                b.cancelled = false;
                return true;
            }
            // a short tap
            if (hasDouble) {
                if (b.pendingTap) {
                    cancelPending(b);
                    fire(b, "double");
                } else {
                    b.pendingTap = true;
                    b.tapRun = new Runnable() {
                        @Override public void run() {
                            b.pendingTap = false;
                            b.tapRun = null;
                            fire(b, "short");
                        }
                    };
                    handler.postDelayed(b.tapRun, DOUBLE_MS);
                }
            } else {
                fire(b, "short");
            }
            return true;
        }
        return true;
    }

    private void cancelPending(Btn b) {
        if (b.tapRun != null) handler.removeCallbacks(b.tapRun);
        b.tapRun = null;
        b.pendingTap = false;
    }

    private void fire(Btn b, String g) {
        String id = b.prefix + "_" + g;
        String action = Mute.getAction(this, id);
        if (Mute.NONE.equals(action)) {
            if ("short".equals(g)) defaultAdjust(b); // not mapped: normal volume change
            return;
        }
        Mute.run(this, action, Mute.getShortcut(this, id));
    }

    private void defaultAdjust(Btn b) {
        Mute.run(this, b == up ? Mute.VOL_UP : Mute.VOL_DOWN, null);
    }
}
