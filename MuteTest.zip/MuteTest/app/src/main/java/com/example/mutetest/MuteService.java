package com.example.mutetest;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class MuteService extends AccessibilityService {
    static volatile MuteService instance;

    private static class Btn {
        final String prefix;
        final int keyCode;
        boolean longFired, cancelled, pendingTap;
        Runnable longRun, tapRun;
        Btn(String prefix, int keyCode) { this.prefix = prefix; this.keyCode = keyCode; }
    }

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Btn up = new Btn("up", KeyEvent.KEYCODE_VOLUME_UP);
    private final Btn dn = new Btn("dn", KeyEvent.KEYCODE_VOLUME_DOWN);
    private int skipCode;
    private long skipUntil;

    @Override protected void onServiceConnected() {
        instance = this;
        try { Torch.init(this); } catch (Throwable ignored) { }
    }

    @Override public boolean onUnbind(Intent i) {
        instance = null;
        handler.removeCallbacksAndMessages(null);
        return super.onUnbind(i);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    private boolean has(Btn b, String g) {
        return !Mute.NONE.equals(Mute.getAction(this, b.prefix + "_" + g));
    }

    @Override protected boolean onKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        final Btn b;
        if (code == KeyEvent.KEYCODE_VOLUME_UP) b = up;
        else if (code == KeyEvent.KEYCODE_VOLUME_DOWN) b = dn;
        else return false;

        // keys we replayed ourselves (virtual keyboard, or just sent) go straight to the system
        if (e.getDeviceId() < 0) return false;
        if (code == skipCode && SystemClock.uptimeMillis() < skipUntil) return false;

        boolean hasShort = has(b, "short"), hasLong = has(b, "long"), hasDouble = has(b, "double");
        if (!hasShort && !hasLong && !hasDouble) return false; // nothing mapped: system handles it
        final boolean grab = Mute.grab(this);

        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) {
                b.longFired = false;
                b.cancelled = false;
                if (hasLong) {
                    b.longRun = new Runnable() {
                        @Override public void run() {
                            b.longRun = null;
                            b.longFired = true;
                            cancelPending(b);
                            fire(b, "long", grab);
                        }
                    };
                    handler.postDelayed(b.longRun, Mute.longMs(this));
                }
            } else if (grab && !hasLong) {
                // held with no long-press action: behave like the normal key (repeat the default)
                if (!b.cancelled) { b.cancelled = true; cancelPending(b); }
                replay(b, true);
            }
            return grab;
        }

        if (e.getAction() == KeyEvent.ACTION_UP) {
            if (b.longRun != null) { handler.removeCallbacks(b.longRun); b.longRun = null; }
            if (b.longFired || b.cancelled) {
                b.longFired = false;
                b.cancelled = false;
                return grab;
            }
            // a short tap
            if (hasDouble) {
                if (b.pendingTap) {
                    cancelPending(b);
                    fire(b, "double", grab);
                } else {
                    b.pendingTap = true;
                    b.tapRun = new Runnable() {
                        @Override public void run() {
                            b.pendingTap = false;
                            b.tapRun = null;
                            fire(b, "short", grab);
                        }
                    };
                    handler.postDelayed(b.tapRun, Mute.dblMs(this));
                }
            } else {
                fire(b, "short", grab);
            }
            return grab;
        }
        return grab;
    }

    private void cancelPending(Btn b) {
        if (b.tapRun != null) handler.removeCallbacks(b.tapRun);
        b.tapRun = null;
        b.pendingTap = false;
    }

    private void fire(Btn b, String g, boolean grab) {
        String id = b.prefix + "_" + g;
        String action = Mute.getAction(this, id);
        if (Mute.NONE.equals(action)) {
            if (grab && "short".equals(g)) replay(b, false); // not mapped: normal volume change
            return;
        }
        Mute.run(this, action, Mute.getShortcut(this, id));
    }

    /** Re-sends the physical key so the unmapped behavior stays the system default. */
    private void replay(Btn b, boolean dropIfBusy) {
        skipCode = b.keyCode;
        skipUntil = SystemClock.uptimeMillis() + 700;
        Mute.key(this, b.keyCode, dropIfBusy);
    }
}
