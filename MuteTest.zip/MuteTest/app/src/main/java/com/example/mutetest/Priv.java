package com.example.mutetest;

import android.content.Context;
import android.content.pm.PackageManager;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;
import rikka.shizuku.Shizuku;

/** Runs shell commands with shell privileges through Shizuku. */
final class Priv {
    private static final AtomicBoolean busy = new AtomicBoolean(false);

    static boolean ready() {
        try {
            return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    static String status() {
        try {
            if (!Shizuku.pingBinder()) return "not running (start Shizuku)";
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    ? "ready" : "running, access not granted";
        } catch (Throwable t) {
            return "unavailable";
        }
    }

    /** Runs "sh -c cmd" privileged on a background thread. dropIfBusy skips it if a previous drop-able one is still running. */
    static void exec(final Context c, final String cmd, final boolean dropIfBusy) {
        if (dropIfBusy && !busy.compareAndSet(false, true)) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
                    m.setAccessible(true);
                    Process p = (Process) m.invoke(null, new String[]{"sh", "-c", cmd}, null, null);
                    p.waitFor();
                } catch (Throwable t) {
                    Mute.log(c, "privileged exec failed: " + t);
                } finally {
                    if (dropIfBusy) busy.set(false);
                }
            }
        }).start();
    }
}
