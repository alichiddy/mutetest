package com.example.mutetest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class MuteReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String mode = null, method = null;
        Bundle b = i.getBundleExtra(MainActivity.EXTRA_BUNDLE);   // Tasker/Locale plug-in
        if (b != null) {
            mode = b.getString(MainActivity.KEY_MODE);
            method = b.getString(MainActivity.KEY_METHOD);
        }
        if (mode == null) mode = i.getStringExtra(MainActivity.KEY_MODE);       // plain broadcast
        if (method == null) method = i.getStringExtra(MainActivity.KEY_METHOD);
        Mute.log(c, "RECEIVED action=" + i.getAction()
                + " extras=" + (i.getExtras() != null ? i.getExtras().keySet() : "none"));
        Mute.apply(c, mode, method);
    }
}
