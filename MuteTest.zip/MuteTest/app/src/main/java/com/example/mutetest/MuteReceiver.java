package com.example.mutetest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class MuteReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String mode = null;
        Bundle b = i.getBundleExtra(MainActivity.EXTRA_BUNDLE);   // Tasker/Locale plug-in
        if (b != null) mode = b.getString(MainActivity.KEY_MODE);
        if (mode == null) mode = i.getStringExtra(MainActivity.KEY_MODE); // plain broadcast
        Mute.apply(c, mode);
    }
}
