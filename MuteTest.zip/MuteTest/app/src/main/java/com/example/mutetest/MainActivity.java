package com.example.mutetest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    static final String ACTION_EDIT = "com.twofortyfouram.locale.intent.action.EDIT_SETTING";
    static final String EXTRA_BUNDLE = "com.twofortyfouram.locale.intent.extra.BUNDLE";
    static final String EXTRA_BLURB = "com.twofortyfouram.locale.intent.extra.BLURB";
    static final String KEY_MODE = "mode";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final boolean plugin = ACTION_EDIT.equals(getIntent().getAction());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);
        TextView t = new TextView(this);
        t.setText(plugin ? "Choose the volume action"
                : "Mute test\n1) Enable the accessibility service\n2) Use the buttons to test");
        root.addView(t);
        if (!plugin) {
            Button a = new Button(this);
            a.setText("Open accessibility settings");
            a.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
            root.addView(a);
        }
        add(root, "Toggle mute", Mute.TOGGLE, plugin);
        add(root, "Mute", Mute.MUTE, plugin);
        add(root, "Unmute", Mute.UNMUTE, plugin);
        setContentView(root);
    }

    private void add(LinearLayout root, String label, final String mode, final boolean plugin) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setOnClickListener(v -> {
            if (plugin) {
                Bundle bundle = new Bundle();
                bundle.putString(KEY_MODE, mode);
                Intent r = new Intent();
                r.putExtra(EXTRA_BUNDLE, bundle);
                r.putExtra(EXTRA_BLURB, "Volume: " + label);
                setResult(RESULT_OK, r);
                finish();
            } else {
                Mute.apply(this, mode);
            }
        });
        root.addView(btn);
    }
}
