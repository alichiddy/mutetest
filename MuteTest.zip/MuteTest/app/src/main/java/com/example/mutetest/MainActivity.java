package com.example.mutetest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    static final String ACTION_EDIT = "com.twofortyfouram.locale.intent.action.EDIT_SETTING";
    static final String EXTRA_BUNDLE = "com.twofortyfouram.locale.intent.extra.BUNDLE";
    static final String EXTRA_BLURB = "com.twofortyfouram.locale.intent.extra.BLURB";
    static final String KEY_MODE = "mode";
    static final String KEY_METHOD = "method";

    private TextView logView;
    private boolean plugin;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        plugin = ACTION_EDIT.equals(getIntent().getAction());
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);
        sv.addView(root);
        TextView t = new TextView(this);
        t.setText(plugin ? "Choose the volume action"
                : "Mute test\nEnable the accessibility service, then test. The log at the bottom shows what each trigger did.");
        root.addView(t);
        if (!plugin) {
            Button a = new Button(this);
            a.setText("Open accessibility settings");
            a.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
            root.addView(a);
        }
        add(root, "Toggle (stream)", Mute.TOGGLE, Mute.STREAM);
        add(root, "Toggle (suggested)", Mute.TOGGLE, Mute.SUGGESTED);
        add(root, "Toggle (key 164)", Mute.TOGGLE, Mute.KEY);
        add(root, "Mute (stream)", Mute.MUTE, Mute.STREAM);
        add(root, "Unmute (stream)", Mute.UNMUTE, Mute.STREAM);
        if (!plugin) {
            Button r = new Button(this);
            r.setText("Refresh log");
            r.setOnClickListener(v -> refresh());
            root.addView(r);
            Button c = new Button(this);
            c.setText("Clear log");
            c.setOnClickListener(v -> { Mute.clearLog(this); refresh(); });
            root.addView(c);
            logView = new TextView(this);
            logView.setTextIsSelectable(true);
            root.addView(logView);
        }
        setContentView(sv);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() { if (logView != null) logView.setText(Mute.readLog(this)); }

    private void add(LinearLayout root, final String label, final String mode, final String method) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setOnClickListener(v -> {
            if (plugin) {
                Bundle bundle = new Bundle();
                bundle.putString(KEY_MODE, mode);
                bundle.putString(KEY_METHOD, method);
                Intent r = new Intent();
                r.putExtra(EXTRA_BUNDLE, bundle);
                r.putExtra(EXTRA_BLURB, "Volume: " + label);
                setResult(RESULT_OK, r);
                finish();
            } else {
                Mute.apply(this, mode, method);
                refresh();
            }
        });
        root.addView(btn);
    }
}
