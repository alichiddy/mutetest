package com.example.mutetest;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    static final String ACTION_EDIT = "com.twofortyfouram.locale.intent.action.EDIT_SETTING";
    static final String EXTRA_BUNDLE = "com.twofortyfouram.locale.intent.extra.BUNDLE";
    static final String EXTRA_BLURB = "com.twofortyfouram.locale.intent.extra.BLURB";
    static final String KEY_ACTION = "action";
    static final String KEY_MODE = "mode"; // older extra: toggle / mute / unmute
    private static final int REQ_SHORTCUT = 1;

    private boolean plugin;
    private TextView status, logView;
    private String pendingGesture;
    private final Map<String, Button> buttons = new HashMap<String, Button>();

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        plugin = ACTION_EDIT.equals(getIntent().getAction());
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);
        sv.addView(root);

        if (plugin) {
            TextView t = new TextView(this);
            t.setText("Choose the action to run");
            root.addView(t);
            for (int i = 0; i < Mute.IDS.length; i++) {
                final String id = Mute.IDS[i];
                if (Mute.NONE.equals(id) || Mute.SHORTCUT.equals(id)) continue;
                Button btn = new Button(this);
                btn.setText(Mute.LABELS[i]);
                final String label = Mute.LABELS[i];
                btn.setOnClickListener(v -> {
                    Bundle bundle = new Bundle();
                    bundle.putString(KEY_ACTION, id);
                    Intent r = new Intent();
                    r.putExtra(EXTRA_BUNDLE, bundle);
                    r.putExtra(EXTRA_BLURB, label);
                    setResult(RESULT_OK, r);
                    finish();
                });
                root.addView(btn);
            }
            setContentView(sv);
            return;
        }

        status = new TextView(this);
        root.addView(status);
        Button acc = new Button(this);
        acc.setText("Open accessibility settings");
        acc.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(acc);

        TextView hint = new TextView(this);
        hint.setText("\nChoose what each press does. Anything left on \"Do nothing\" keeps the normal volume behavior.");
        root.addView(hint);

        for (int i = 0; i < Mute.GESTURES.length; i++) {
            final String g = Mute.GESTURES[i];
            final String title = Mute.GESTURE_LABELS[i];
            Button btn = new Button(this);
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> pick(g, title));
            buttons.put(g, btn);
            root.addView(btn);
        }

        TextView logTitle = new TextView(this);
        logTitle.setText("\nLog");
        root.addView(logTitle);
        Button refresh = new Button(this);
        refresh.setText("Refresh log");
        refresh.setOnClickListener(v -> refresh());
        root.addView(refresh);
        Button clear = new Button(this);
        clear.setText("Clear log");
        clear.setOnClickListener(v -> { Mute.clearLog(this); refresh(); });
        root.addView(clear);
        logView = new TextView(this);
        logView.setTextIsSelectable(true);
        root.addView(logView);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        if (plugin) return;
        status.setText("Accessibility service: " + (MuteService.instance != null ? "ON" : "OFF - enable it below"));
        for (int i = 0; i < Mute.GESTURES.length; i++) {
            String g = Mute.GESTURES[i];
            String id = Mute.getAction(this, g);
            String txt = Mute.label(id);
            if (Mute.SHORTCUT.equals(id)) txt = "Shortcut: " + Mute.getShortcutName(this, g);
            buttons.get(g).setText(Mute.GESTURE_LABELS[i] + "\n" + txt);
        }
        logView.setText(Mute.readLog(this));
    }

    private void pick(final String gesture, String title) {
        new AlertDialog.Builder(this).setTitle(title).setItems(Mute.LABELS, (d, which) -> {
            String id = Mute.IDS[which];
            if (Mute.SHORTCUT.equals(id)) {
                pendingGesture = gesture;
                chooseShortcutSource();
            } else {
                Mute.prefs(this).edit().putString(gesture, id).apply();
                refresh();
            }
        }).show();
    }

    private void chooseShortcutSource() {
        PackageManager pm = getPackageManager();
        final List<ResolveInfo> list = pm.queryIntentActivities(new Intent(Intent.ACTION_CREATE_SHORTCUT), 0);
        if (list.isEmpty()) {
            Toast.makeText(this, "No shortcut sources found", Toast.LENGTH_LONG).show();
            return;
        }
        List<String> names = new ArrayList<String>();
        for (ResolveInfo ri : list) names.add(ri.loadLabel(pm).toString());
        new AlertDialog.Builder(this).setTitle("Shortcut from...")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    ActivityInfo ai = list.get(which).activityInfo;
                    Intent pick = new Intent(Intent.ACTION_CREATE_SHORTCUT);
                    pick.setClassName(ai.packageName, ai.name);
                    try {
                        startActivityForResult(pick, REQ_SHORTCUT);
                    } catch (Exception e) {
                        Toast.makeText(this, "Could not open: " + e, Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_SHORTCUT || res != RESULT_OK || data == null || pendingGesture == null) return;
        Intent sc = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_INTENT);
        String name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);
        if (sc == null) {
            Toast.makeText(this, "That app did not return a shortcut", Toast.LENGTH_LONG).show();
            return;
        }
        Mute.prefs(this).edit()
                .putString(pendingGesture, Mute.SHORTCUT)
                .putString("sc_" + pendingGesture, sc.toUri(Intent.URI_INTENT_SCHEME))
                .putString("scn_" + pendingGesture, name == null ? "" : name)
                .apply();
        refresh();
    }
}
