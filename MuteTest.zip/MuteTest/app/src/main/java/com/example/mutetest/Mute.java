package com.example.mutetest;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.view.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Mute {
    // action ids
    static final String NONE = "none", SHORTCUT = "shortcut", TOGGLE_MUTE = "toggle_mute",
            MUTE = "mute", UNMUTE = "unmute", TOGGLE_FLASH = "toggle_flashlight";

    static final String[] IDS = {NONE, SHORTCUT, TOGGLE_MUTE, MUTE, UNMUTE, TOGGLE_FLASH};
    static final String[] LABELS = {"Do nothing (keep default)", "Run a shortcut...",
            "Toggle mute", "Mute", "Unmute", "Toggle flashlight"};

    // gesture ids (SharedPreferences keys)
    static final String[] GESTURES = {"up_short", "up_double", "up_long", "dn_short", "dn_double", "dn_long"};
    static final String[] GESTURE_LABELS = {"Volume Up - short press", "Volume Up - double press",
            "Volume Up - long press", "Volume Down - short press", "Volume Down - double press",
            "Volume Down - long press"};

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    static String getAction(Context c, String gesture) { return prefs(c).getString(gesture, NONE); }
    static String getShortcut(Context c, String gesture) { return prefs(c).getString("sc_" + gesture, ""); }
    static String getShortcutName(Context c, String gesture) { return prefs(c).getString("scn_" + gesture, ""); }
    static boolean grab(Context c) { return prefs(c).getBoolean("grab", true); }
    static int longMs(Context c) { return prefs(c).getInt("long_ms", 500); }
    static int dblMs(Context c) { return prefs(c).getInt("dbl_ms", 300); }

    static String label(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return LABELS[i];
        return id;
    }

    static void run(Context c, String action, String shortcutUri) {
        if (action == null || NONE.equals(action)) return;
        MuteService svc = MuteService.instance;
        Context ctx = svc != null ? svc : c.getApplicationContext();
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        boolean before = am.isStreamMute(AudioManager.STREAM_MUSIC);
        String err = "";
        try {
            switch (action) {
                case TOGGLE_MUTE:
                    key(c, KeyEvent.KEYCODE_VOLUME_MUTE);
                    break;
                case MUTE:
                    if (!before) key(c, KeyEvent.KEYCODE_VOLUME_MUTE);
                    break;
                case UNMUTE:
                    if (before) key(c, KeyEvent.KEYCODE_VOLUME_MUTE);
                    break;
                case TOGGLE_FLASH:
                    Torch.toggle(ctx);
                    break;
                case SHORTCUT:
                    launch(ctx, shortcutUri);
                    break;
                default:
                    err = " ERR=unknown action";
            }
        } catch (Throwable e) {
            err = " ERR=" + e;
        }
        log(c, "run " + action + " service=" + (svc != null) + " setup=" + ImeKey.canSend(c)
                + " muted(before)=" + before + err);
    }

    /** Sends a key like Button Mapper's custom keycode (keyboard trick); weaker audio fallback if not set up. */
    static void key(Context c, int keyCode) {
        if (ImeKey.canSend(c)) {
            ImeKey.send(c, keyCode);
            return;
        }
        log(c, "WRITE_SECURE_SETTINGS not granted - using the audio fallback (the phone may ignore it)");
        Context ctx = MuteService.instance != null ? MuteService.instance : c.getApplicationContext();
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        switch (keyCode) {
            case KeyEvent.KEYCODE_VOLUME_MUTE:
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
                break;
            case KeyEvent.KEYCODE_VOLUME_UP:
                am.adjustSuggestedStreamVolume(AudioManager.ADJUST_RAISE, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
                break;
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                am.adjustSuggestedStreamVolume(AudioManager.ADJUST_LOWER, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
                break;
            default:
                break;
        }
    }

    private static void launch(Context ctx, String uri) throws Exception {
        if (uri == null || uri.isEmpty()) throw new IllegalStateException("no shortcut chosen");
        Intent i = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    static synchronized void log(Context c, String msg) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            if (f.length() > 8000) f.delete();
            try (FileWriter w = new FileWriter(f, true)) {
                w.write(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + msg + "\n");
            }
        } catch (Throwable ignored) { }
    }

    static synchronized String readLog(Context c) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            return f.exists() ? new String(Files.readAllBytes(f.toPath())) : "(log empty)";
        } catch (Throwable e) { return "(cannot read log: " + e + ")"; }
    }

    static synchronized void clearLog(Context c) {
        new File(c.getApplicationContext().getFilesDir(), "log.txt").delete();
    }
}
