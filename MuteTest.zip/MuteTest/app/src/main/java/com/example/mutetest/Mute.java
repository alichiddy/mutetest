package com.example.mutetest;

import android.content.Context;
import android.media.AudioManager;
import android.view.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Mute {
    static final String TOGGLE = "toggle", MUTE = "mute", UNMUTE = "unmute";
    static final String STREAM = "stream", SUGGESTED = "suggested", KEY = "key";

    static void apply(Context c, String mode, String method) {
        if (mode == null) mode = TOGGLE;
        if (method == null) method = STREAM;
        MuteService svc = MuteService.instance;
        Context ctx = svc != null ? svc : c.getApplicationContext();
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        int dir = MUTE.equals(mode) ? AudioManager.ADJUST_MUTE
                : UNMUTE.equals(mode) ? AudioManager.ADJUST_UNMUTE
                : AudioManager.ADJUST_TOGGLE_MUTE;
        boolean before = am.isStreamMute(AudioManager.STREAM_MUSIC);
        String err = "";
        try {
            switch (method) {
                case SUGGESTED:
                    am.adjustSuggestedStreamVolume(dir, AudioManager.STREAM_MUSIC, 0);
                    break;
                case KEY:
                    long t = System.currentTimeMillis();
                    am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE, 0));
                    am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_VOLUME_MUTE, 0));
                    break;
                default:
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0); // flags 0: no UI
            }
        } catch (Throwable e) {
            err = " ERR=" + e;
        }
        boolean after = am.isStreamMute(AudioManager.STREAM_MUSIC);
        log(c, mode + "/" + method + " accessibilityService=" + (svc != null)
                + " muted " + before + "->" + after + err);
    }

    static synchronized void log(Context c, String msg) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            if (f.length() > 8000) f.delete();
            try (FileWriter w = new FileWriter(f, true)) {
                w.write(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + msg + "\n");
            }
        } catch (Throwable ignored) { }
    }

    static synchronized String readLog(Context c) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            return f.exists() ? new String(Files.readAllBytes(f.toPath())) : "(log empty)";
        } catch (Throwable e) { return "(cannot read log: " + e + ")"; }
    }

    static synchronized void clearLog(Context c) {
        new File(c.getApplicationContext().getFilesDir(), "log.txt").delete();
    }
}
