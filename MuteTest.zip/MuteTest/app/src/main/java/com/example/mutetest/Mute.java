package com.example.mutetest;

import android.content.Context;
import android.media.AudioManager;

final class Mute {
    static final String TOGGLE = "toggle", MUTE = "mute", UNMUTE = "unmute";

    static void apply(Context c, String mode) {
        Context ctx = MuteService.instance != null ? MuteService.instance : c.getApplicationContext();
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        int dir = MUTE.equals(mode) ? AudioManager.ADJUST_MUTE
                : UNMUTE.equals(mode) ? AudioManager.ADJUST_UNMUTE
                : AudioManager.ADJUST_TOGGLE_MUTE;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0); // flags 0: no UI
    }
}
