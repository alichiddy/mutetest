package com.example.mutetest;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.view.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Mute {
    // action ids
    static final String NONE = "none", TOGGLE_MUTE = "toggle_mute", MUTE = "mute", UNMUTE = "unmute",
            VOL_UP = "vol_up", VOL_DOWN = "vol_down", SHORTCUT = "shortcut",
            HOME = "home", BACK = "back", RECENTS = "recents", NOTIFICATIONS = "notifications",
            LOCK = "lock_screen", PLAYPAUSE = "playpause", NEXT = "next", PREV = "prev";

    static final String[] IDS = {NONE, TOGGLE_MUTE, MUTE, UNMUTE, VOL_UP, VOL_DOWN, SHORTCUT,
            HOME, BACK, RECENTS, NOTIFICATIONS, LOCK, PLAYPAUSE, NEXT, PREV};
    static final String[] LABELS = {"Do nothing (keep default)", "Toggle mute", "Mute", "Unmute",
            "Volume up", "Volume down", "Run a shortcut...",
            "Home", "Back", "Recent apps", "Notifications", "Lock screen",
            "Media play/pause", "Media next", "Media previous"};

    // gesture ids (SharedPreferences keys)
    static final String[] GESTURES = {"up_short", "up_double", "up_long", "dn_short", "dn_double", "dn_long"};
    static final String[] GESTURE_LABELS = {"Volume Up - short press", "Volume Up - double press",
            "Volume Up - long press", "Volume Down - short press", "Volume Down - double press",
            "Volume Down - long press"};

    static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }

    static String getAction(Context c, String gesture) { return prefs(c).getString(gesture, NONE); }
    static String getShortcut(Context c, String gesture) { return prefs(c).getString("sc_" + gesture, ""); }
    static String getShortcutName(Context c, String gesture) { return prefs(c).getString("scn_" + gesture, ""); }

    static String label(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return LABELS[i];
        return id;
    }

    static void run(Context c, String action, String shortcutUri) {
        if (action == null || NONE.equals(action)) return;
        MuteService svc = MuteService.instance;
        Context ctx = svc != null ? svc : c.getApplicationContext();
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        boolean before = am.isStreamMute(AudioManager.STREAM_MUSIC);
        String err = "";
        try {
            switch (action) {
                case TOGGLE_MUTE: // same call Button Mapper makes
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
                    break;
                case MUTE:
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
                    break;
                case UNMUTE:
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI);
                    break;
                case VOL_UP:
                    am.adjustSuggestedStreamVolume(AudioManager.ADJUST_RAISE, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
                    break;
                case VOL_DOWN:
                    am.adjustSuggestedStreamVolume(AudioManager.ADJUST_LOWER, AudioManager.USE_DEFAULT_STREAM_TYPE, AudioManager.FLAG_SHOW_UI);
                    break;
                case PLAYPAUSE: media(am, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); break;
                case NEXT: media(am, KeyEvent.KEYCODE_MEDIA_NEXT); break;
                case PREV: media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS); break;
                case HOME: global(svc, AccessibilityService.GLOBAL_ACTION_HOME); break;
                case BACK: global(svc, AccessibilityService.GLOBAL_ACTION_BACK); break;
                case RECENTS: global(svc, AccessibilityService.GLOBAL_ACTION_RECENTS); break;
                case NOTIFICATIONS: global(svc, AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS); break;
                case LOCK: global(svc, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN); break;
                case SHORTCUT: launch(ctx, shortcutUri); break;
                default: err = " ERR=unknown action";
            }
        } catch (Throwable e) {
            err = " ERR=" + e;
        }
        if (!VOL_UP.equals(action) && !VOL_DOWN.equals(action)) {
            boolean after = am.isStreamMute(AudioManager.STREAM_MUSIC);
            log(c, "run " + action + " service=" + (svc != null) + " muted " + before + "->" + after + err);
        } else if (!err.isEmpty()) {
            log(c, "run " + action + err);
        }
    }

    private static void media(AudioManager am, int keyCode) {
        long t = System.currentTimeMillis();
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_DOWN, keyCode, 0));
        am.dispatchMediaKeyEvent(new KeyEvent(t, t, KeyEvent.ACTION_UP, keyCode, 0));
    }

    private static void global(MuteService svc, int code) {
        if (svc == null) throw new IllegalStateException("accessibility service is not running");
        svc.performGlobalAction(code);
    }

    private static void launch(Context ctx, String uri) throws Exception {
        if (uri == null || uri.isEmpty()) throw new IllegalStateException("no shortcut chosen");
        Intent i = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    static synchronized void log(Context c, String msg) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            if (f.length() > 8000) f.delete();
            try (FileWriter w = new FileWriter(f, true)) {
                w.write(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + " " + msg + "\n");
            }
        } catch (Throwable ignored) { }
    }

    static synchronized String readLog(Context c) {
        try {
            File f = new File(c.getApplicationContext().getFilesDir(), "log.txt");
            return f.exists() ? new String(Files.readAllBytes(f.toPath())) : "(log empty)";
        } catch (Throwable e) { return "(cannot read log: " + e + ")"; }
    }

    static synchronized void clearLog(Context c) {
        new File(c.getApplicationContext().getFilesDir(), "log.txt").delete();
    }
}
