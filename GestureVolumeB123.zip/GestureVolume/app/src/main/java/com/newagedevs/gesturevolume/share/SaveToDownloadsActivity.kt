package com.newagedevs.gesturevolume.share

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Process
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import com.newagedevs.gesturevolume.utils.ShizukuShell
import java.io.File

/**
 * "Save to Downloads" in the share sheet of any app: whatever is shared (a file, several files,
 * or text) is written to the Download folder, with no storage permission and nothing left open.
 *
 * When A runs in a second profile (a dual-app space) and Shizuku is ready, the file is also
 * copied to the main profile's Download folder.
 */
class SaveToDownloadsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = applicationContext
        val work = intent
        Thread {
            val report = try { handle(work) } catch (e: Throwable) { "Could not save: " + (e.message ?: e.javaClass.simpleName) }
            runOnUiThread {
                Toast.makeText(app, report, Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun handle(i: Intent): String {
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.add(it) }
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { uris.addAll(it) }
            // ChatGPT Library shares files as ACTION_VIEW with the URI in Intent.data.
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
        }
        val saved = ArrayList<String>()
        if (uris.isEmpty()) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return "Nothing to save."
            saved += write(text.toByteArray().inputStream(), "shared_text.txt", "text/plain")
        } else {
            for (u in uris) saved += write(contentResolver.openInputStream(u) ?: continue, nameOf(u), contentResolver.getType(u) ?: "application/octet-stream")
        }
        if (saved.isEmpty()) return "Nothing was saved."
        var report = "Saved to Downloads: " + saved.joinToString(", ")
        val user = Process.myUserHandle().hashCode()
        if (user != 0 && ShizukuShell.isReady()) {
            val copied = saved.count { name ->
                ShizukuShell.run("cp '/data/media/$user/Download/$name' /data/media/0/Download/") { } == 0
            }
            if (copied > 0) report += "\nAlso copied $copied to the main profile's Download folder."
        }
        return report
    }

    private fun nameOf(uri: Uri): String {
        var name: String? = null
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0)
            }
        }
        return (name ?: uri.lastPathSegment ?: "shared_file").substringAfterLast('/')
    }

    /** Writes the stream into Download and returns the name it ended up with. */
    private fun write(input: java.io.InputStream, name: String, mime: String): String {
        input.use { src ->
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val out = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("the phone refused to create the file")
                (contentResolver.openOutputStream(out) ?: throw IllegalStateException("cannot open the new file")).use { dst ->
                    src.copyTo(dst)
                }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                contentResolver.update(out, done, null, null)
                var finalName = name
                contentResolver.query(out, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) finalName = it.getString(0) ?: name
                }
                return finalName
            }
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val target = File(dir, name)
            target.outputStream().use { src.copyTo(it) }
            return target.name
        }
    }
}
