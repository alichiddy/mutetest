plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "a.mk"
    compileSdk = 37

    defaultConfig {
        applicationId = "a.mk"
        minSdk = 26
        targetSdk = 37
        versionCode = (project.findProperty("buildNo") as String?)?.toIntOrNull() ?: 1
        versionName = "1.0-b" + (project.findProperty("buildNo") ?: "local")
    }

    // One fixed key kept in the project: every build is signed the same and installs over the last one.
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    // The helper apps are built by the :stub module and copied into this app's assets, see copyStubApks below.
    sourceSets {
        getByName("main") {
            // A plain folder, not a Provider (the Android source set refuses providers); preBuild below waits for the copy.
            assets.srcDir(layout.buildDirectory.dir("generated/stubAssets").get().asFile)
        }
    }
}

val stubNames = (1..10).map { "s$it" } + "tpl"
val copyStubApks = tasks.register<Copy>("copyStubApks") {
    stubNames.forEach { n -> dependsOn(":stub:assemble${n.replaceFirstChar { it.uppercase() }}Debug") }
    from(project(":stub").layout.buildDirectory.dir("outputs/apk")) { include("**/*-debug.apk") }
    into(layout.buildDirectory.dir("generated/stubAssets/stub"))
    eachFile { path = name.removePrefix("stub-").removeSuffix("-debug.apk") + ".apk" }
    includeEmptyDirs = false
}
tasks.configureEach { if (name == "preBuild") dependsOn(copyStubApks) }

dependencies {
    // Signs the APKs this app makes.
    implementation("com.android.tools.build:apksig:8.5.2")
    // FileProvider, to hand a made APK to the system installer.
    implementation("androidx.core:core:1.19.1")
}
