package a.mk

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView

/** Plain system views only: no libraries, so the app stays small. */
object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun column(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 16)
        setPadding(p, p, p, p)
    }

    fun text(col: LinearLayout, s: String, size: Float = 15f, bold: Boolean = false): TextView {
        val t = TextView(col.context).apply {
            text = s
            textSize = size
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(col.context, 8), 0, dp(col.context, 4))
        }
        col.addView(t)
        return t
    }

    fun button(col: LinearLayout, s: String, onClick: () -> Unit): Button {
        val b = Button(col.context).apply {
            text = s
            isAllCaps = false
            gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            setOnClickListener { onClick() }
        }
        col.addView(b)
        return b
    }

    /** A scrolling page with a title; returns the column to add things to. */
    fun page(a: Activity, title: String): LinearLayout {
        val col = column(a)
        a.setContentView(ScrollView(a).apply { fitsSystemWindows = true; addView(col) })
        text(col, title, 22f, bold = true)
        return col
    }
}

/** First screen: where the shortcut comes from. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = Ui.page(this, "Shortcut APK")
        Ui.text(col, "Take a shortcut from anywhere and turn it into an app of its own.")
        Ui.button(col, "1. A shortcut from an app on this phone") {
            startActivity(Intent(this, PickActivity::class.java).putExtra("mode", "apps"))
        }
        Ui.button(col, "2. A shortcut an app offers (Tasker, Automate, Shortcut makers…)") {
            startActivity(Intent(this, PickActivity::class.java).putExtra("mode", "offers"))
        }
        Ui.text(col, "3. Paste or share a link: an intent link (intent:#Intent;…;end, also with Intent: in front) or a web address.")
        val shared = if (intent?.action == Intent.ACTION_SEND) intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() else null
        val box = EditText(this).apply {
            hint = "Link"
            minLines = 2
            setText(shared.orEmpty())
        }
        col.addView(box)
        Ui.button(col, "Use this link") {
            val sc = Tools.parseLink(this, box.text.toString())
            if (sc == null) Tools.toast(this, "That is not a link I can run.")
            else Tools.openMake(this, sc.first, sc.second, null)
        }
    }
}

/** A list to search and pick from: the apps on the phone, or the apps that offer shortcuts. */
class PickActivity : Activity() {
    private class Row(val label: String, val sub: String, val cn: ComponentName) {
        override fun toString() = "$label\n$sub"
    }

    private var picked: Row? = null
    private val offers get() = intent.getStringExtra("mode") == "offers"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager
        val q = if (offers) Intent(Intent.ACTION_CREATE_SHORTCUT)
        else Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val rows = pm.queryIntentActivities(q, 0).map {
            val ai = it.activityInfo
            Row(
                it.loadLabel(pm).toString(),
                if (offers) ai.applicationInfo.loadLabel(pm).toString() else ai.packageName,
                ComponentName(ai.packageName, ai.name),
            )
        }.sortedBy { it.label.lowercase() }

        val root = Ui.column(this).apply { fitsSystemWindows = true }
        Ui.text(root, if (offers) "Shortcuts apps offer" else "Apps on this phone", 22f, bold = true)
        val search = EditText(this).apply { hint = "Search"; isSingleLine = true }
        root.addView(search)
        val list = ListView(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> adapter.getItem(pos)?.let { pick(it) } }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { adapter.filter.filter(s) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        setContentView(root)
        if (rows.isEmpty()) Tools.toast(this, "Nothing found.")
    }

    private fun pick(r: Row) {
        if (offers) {
            picked = r
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(r.cn), 1)
            } catch (e: Throwable) {
                Tools.toast(this, "Could not open it: ${e.javaClass.simpleName}")
            }
        } else {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(r.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val icon = runCatching { Tools.bitmapOf(packageManager.getActivityIcon(r.cn)) }.getOrNull()
            Tools.openMake(this, r.label, i.toUri(Intent.URI_INTENT_SCHEME), icon)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val r = picked ?: return
        if (requestCode != 1 || resultCode != RESULT_OK || data == null) return
        val sc = data.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
        if (sc == null) { Tools.toast(this, "That app gave no shortcut."); return }
        val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: r.label
        Tools.openMake(this, name, sc.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).toUri(Intent.URI_INTENT_SCHEME), Tools.iconOf(this, data))
    }
}

/** The picked shortcut: name it, try it, and make it an app (ready slot, or a new APK). */
class MakeActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent.getStringExtra("u").orEmpty()
        val col = Ui.page(this, "Make an app")
        Ui.text(col, "Name of the app (shown on the phone after it is installed)")
        val name = EditText(this).apply {
            setText(intent.getStringExtra("n").orEmpty())
            isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(30))
        }
        col.addView(name)
        Ui.text(col, "Runs: " + uri.take(160))
        Ui.button(col, "Test (run now)") { Tools.run(this, uri) }
        Ui.text(col, "Make it an app, two ways:")
        val slots = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Ui.button(col, "A: one of the ready app slots (A 1 … A ${Tools.SLOTS}). Install once, change its shortcut any time.") {
            slots.removeAllViews()
            for (n in 1..Tools.SLOTS) {
                val pkg = Tools.STUB_PREFIX + "s$n"
                val e = Tools.stubEntry(this, pkg)
                val line = "A $n  -  " + (if (Tools.isInstalled(this, pkg)) "installed" else "not installed") +
                    "  -  " + (e?.let { "runs: " + it.name } ?: "free")
                Ui.button(slots, line) { Tools.useSlot(this, n, uri, name.text.toString()) }
            }
        }
        col.addView(slots)
        Ui.button(col, "B: build a new APK app for this shortcut, with its own name and icon.") {
            if (name.text.isBlank()) Tools.toast(this, "Type a name first.")
            else Tools.buildOwnApp(this, uri, name.text.toString())
        }
    }
}
