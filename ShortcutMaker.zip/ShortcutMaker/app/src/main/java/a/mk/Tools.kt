package a.mk

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * What a shortcut can become: an app of its own, either one of the ready slots (A 1 .. A 10, installed once, its
 * shortcut changed any time) or a new APK built here. A shortcut is kept as an intent link (Intent.toUri).
 *
 * Nothing here runs until a button is pressed.
 */
object Tools {
    /** Every helper app's package starts with this; the slots are a.mk.sc.s1 .. s10, built ones a.mk.sc.b<random>. */
    const val STUB_PREFIX = "a.mk.sc."
    const val SLOTS = 10
    private const val MAP_KEY = "stubMap"

    /** What a helper app runs: its name, the shortcut as an intent link, and a hash of its picture. */
    class Entry(val name: String, val uri: String, val iconHash: String = "")

    private fun prefs(c: Context) = c.getSharedPreferences("mk", Context.MODE_PRIVATE)
    fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

    // ---- pictures ---------------------------------------------------------------------------

    fun bitmapOf(d: Drawable, size: Int = 192): Bitmap =
        Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { d.setBounds(0, 0, size, size); d.draw(Canvas(it)) }

    private fun pngOf(b: Bitmap): ByteArray = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()

    private fun pendingIcon(c: Context) = File(c.cacheDir, "pending_icon.png")

    /** The picture of the shortcut that was just picked: kept in a file so the next screen can use it. */
    private fun savePending(c: Context, b: Bitmap?) {
        val f = pendingIcon(c)
        if (b == null) { f.delete(); return }
        f.outputStream().use { it.write(pngOf(b)) }
    }

    /** The picture to put on the new app: the picked one, else this app's own icon. */
    private fun iconPng(c: Context): ByteArray {
        val f = pendingIcon(c)
        if (f.exists()) return f.readBytes()
        return pngOf(bitmapOf(c.packageManager.getApplicationIcon(c.packageName)))
    }

    /** The picture an app gives with its shortcut (a bitmap, or a picture inside the app), or null. */
    @Suppress("DEPRECATION")
    fun iconOf(c: Context, data: Intent): Bitmap? {
        (data.getParcelableExtra<Parcelable>(Intent.EXTRA_SHORTCUT_ICON) as? Bitmap)?.let { return Bitmap.createScaledBitmap(it, 192, 192, true) }
        val r = data.getParcelableExtra<Intent.ShortcutIconResource>(Intent.EXTRA_SHORTCUT_ICON_RESOURCE) ?: return null
        return runCatching {
            val res = c.packageManager.getResourcesForApplication(r.packageName)
            val id = res.getIdentifier(r.resourceName, null, null)
            bitmapOf(res.getDrawable(id, null))
        }.getOrNull()
    }

    // ---- pick -> make -----------------------------------------------------------------------

    /** Goes to the screen where the app is made. [uri] is the shortcut as an intent link. */
    fun openMake(c: Context, name: String, uri: String, icon: Bitmap?) {
        savePending(c, icon)
        c.startActivity(Intent(c, MakeActivity::class.java).putExtra("n", name).putExtra("u", uri))
    }

    /** Turns pasted text into (name, intent link): an intent link ("intent:#Intent;...;end", also with A's "Intent:" in front) or any web address. Null when it is neither. */
    fun parseLink(c: Context, raw: String): Pair<String, String>? {
        var t = raw.trim()
        if (t.startsWith("Intent:intent:")) t = t.removePrefix("Intent:")
        if (t.isEmpty()) return null
        val i = try {
            if (t.startsWith("intent:")) Intent.parseUri(t, Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, Uri.parse(t))
        } catch (e: Exception) { return null }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pkg = i.component?.packageName ?: i.`package`
        val name = pkg?.let { p ->
            runCatching { c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(p, 0)).toString() }.getOrNull()
        } ?: i.dataString?.take(30) ?: "Shortcut"
        return name to i.toUri(Intent.URI_INTENT_SCHEME)
    }

    /** Runs the shortcut now, the way the made app will. */
    fun run(c: Context, uri: String): Boolean = try {
        c.startActivity(Intent.parseUri(uri, Intent.URI_INTENT_SCHEME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Throwable) {
        toast(c, "Could not run it: ${e.javaClass.simpleName}")
        false
    }

    // ---- apps of their own ------------------------------------------------------------------

    fun stubEntry(c: Context, pkg: String): Entry? = runCatching {
        val o = JSONObject(prefs(c).getString(MAP_KEY, "{}") ?: "{}").optJSONObject(pkg) ?: return null
        Entry(o.optString("n"), o.optString("u"), o.optString("h"))
    }.getOrNull()

    private fun assignStub(c: Context, pkg: String, e: Entry) {
        val m = runCatching { JSONObject(prefs(c).getString(MAP_KEY, "{}") ?: "{}") }.getOrDefault(JSONObject())
        m.put(pkg, JSONObject().put("n", e.name).put("u", e.uri).put("h", e.iconHash))
        prefs(c).edit().putString(MAP_KEY, m.toString()).apply()
    }

    fun isInstalled(c: Context, pkg: String): Boolean =
        runCatching { c.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

    /** Opens the system installer for [f]; first sends the person to the "allow installing" switch when it is off. */
    fun installFile(c: Context, f: File) {
        if (!c.packageManager.canRequestPackageInstalls()) {
            toast(c, "Allow this app to install apps on the next screen, then press the button again.")
            c.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        c.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /**
     * Option A: the ready slot app number [n] is given this shortcut and the name [appName]. A slot that is not installed
     * is installed with that name; an installed one whose name or picture changed is installed again over itself
     * (if Android refuses, uninstall that slot once and press again).
     */
    fun useSlot(c: Context, n: Int, uri: String, appName: String) {
        val pkg = STUB_PREFIX + "s$n"
        val name = appName.trim().ifBlank { "A $n" }.take(30)
        val old = stubEntry(c, pkg)
        val installed = isInstalled(c, pkg)
        val png = iconPng(c)
        val hash = Integer.toHexString(java.util.Arrays.hashCode(png))
        assignStub(c, pkg, Entry(name, uri, hash))
        if (installed && old != null && old.name == name && old.iconHash == hash) { toast(c, "App \"$name\" now runs this shortcut"); return }
        val app = c.applicationContext
        Thread {
            val main = Handler(Looper.getMainLooper())
            try {
                val apk = ApkMaker.makeShortcutApp(app, pkg, name, png, asset = "stub/s$n.apk", oldPkg = pkg, oldLabel = "A $n")
                main.post { installFile(app, apk) }
            } catch (e: Throwable) {
                android.util.Log.e("mk", "Slot app", e)
                main.post { toast(app, "Could not make the slot app: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }.start()
    }

    /** Option B: builds a new APK app for this shortcut (own name, own icon, signed here), keeps a copy in Downloads and opens the installer. */
    fun buildOwnApp(c: Context, uri: String, appName: String) {
        val app = c.applicationContext
        toast(app, "Building the app…")
        val png = iconPng(app)
        Thread {
            val main = Handler(Looper.getMainLooper())
            try {
                val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
                val rnd = java.util.Random()
                val pkg = STUB_PREFIX + "b" + (1..8).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
                val name = appName.trim().ifBlank { "A shortcut" }.take(30)
                val apk = ApkMaker.makeShortcutApp(app, pkg, name, png)
                assignStub(app, pkg, Entry(name, uri))
                val saved = ApkMaker.copyToDownloads(app, apk, "A-" + name.replace(Regex("[^A-Za-z0-9._-]+"), "_") + ".apk")
                main.post {
                    toast(app, if (saved) "Saved in Downloads. Install it to finish." else "Built. Install it to finish.")
                    installFile(app, apk)
                }
            } catch (e: Throwable) {
                android.util.Log.e("mk", "Shortcut app", e)
                main.post { toast(app, "Could not build the app: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }.start()
    }
}

/** Started by a helper app of its own: looks up the shortcut that app was given and runs it. Invisible; nothing stays. */
class StubRunActivity : Activity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        val stub = intent.getStringExtra("stub").orEmpty()
        val e = if (stub.startsWith(Tools.STUB_PREFIX)) Tools.stubEntry(this, stub) else null
        if (e == null) Tools.toast(this, "This app has no shortcut yet. Give it one in Shortcut APK.")
        else Tools.run(this, e.uri)
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }
}
