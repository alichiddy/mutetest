// Tiny helper apps: the ready slots (a.mk.sc.s1 .. s10, named "A 1" .. "A 10") and one template (a.mk.sc.tpl)
// that the app copies, renames and signs on the phone to make an APK for one shortcut.
// Each only starts the app's StubRunActivity with its own package name. Built by the app's build, never installed by it alone.
plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "a.mk.stub"
    compileSdk = 37

    defaultConfig {
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    flavorDimensions += "slot"
    productFlavors {
        for (i in 1..10) {
            create("s$i") {
                dimension = "slot"
                applicationId = "a.mk.sc.s$i"
                manifestPlaceholders["stubLabel"] = "A $i"
            }
        }
        create("tpl") {
            dimension = "slot"
            applicationId = "a.mk.sc.tpl"
            manifestPlaceholders["stubLabel"] = "TPLLABEL"
        }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
