package com.vpnoff;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = VpnService.prepare(this);
        if (i != null) {
            startActivityForResult(i, 1);
        } else {
            go();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (res == RESULT_OK) {
            go();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void go() {
        startService(new Intent(this, KillVpnService.class));
        Toast.makeText(this, "VPN off", Toast.LENGTH_SHORT).show();
        finish();
    }
}
