package com.vpnoff;

import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

public class KillVpnService extends VpnService {
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            ParcelFileDescriptor p = new Builder()
                    .addAddress("10.255.255.1", 32)
                    .setSession("off")
                    .establish();
            if (p != null) p.close();
        } catch (Exception ignored) {
        }
        stopSelf();
        return START_NOT_STICKY;
    }
}
