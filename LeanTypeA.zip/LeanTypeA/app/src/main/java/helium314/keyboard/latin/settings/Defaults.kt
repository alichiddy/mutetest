package helium314.keyboard.latin.settings

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import helium314.keyboard.keyboard.KeyboardTheme
import helium314.keyboard.latin.BuildConfig
import helium314.keyboard.latin.common.Constants.Separators
import helium314.keyboard.latin.common.Constants.Subtype.ExtraValue
import helium314.keyboard.latin.utils.LayoutType
import helium314.keyboard.latin.utils.POPUP_KEYS_LABEL_DEFAULT
import helium314.keyboard.latin.utils.POPUP_KEYS_ORDER_DEFAULT
import helium314.keyboard.latin.utils.defaultClipboardToolbarPref
import helium314.keyboard.latin.utils.defaultPinnedToolbarPref
import helium314.keyboard.latin.utils.defaultToolbarPref

object Defaults {
    fun initDynamicDefaults(context: Context) {
        PREF_GESTURE_DYNAMIC_PREVIEW_FOLLOW_SYSTEM = getTransitionAnimationScale(context) != 0.0f
        val dm = context.resources.displayMetrics
        val px600 = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 600f, dm)
        PREF_POPUP_ON = dm.widthPixels >= px600 || dm.heightPixels >= px600
    }

    // must correspond to a file name
    val LayoutType.default get() = when (this) {
        LayoutType.MAIN -> "qwerty"
        LayoutType.SYMBOLS -> "symbols"
        LayoutType.MORE_SYMBOLS -> "symbols_shifted"
        LayoutType.FUNCTIONAL -> if (Settings.getInstance().isTablet) "functional_keys_tablet" else "functional_keys"
        LayoutType.NUMBER -> "number"
        LayoutType.NUMBER_ROW -> "number_row"
        LayoutType.NUMPAD -> "numpad"
        LayoutType.NUMPAD_LANDSCAPE -> "numpad_landscape"
        LayoutType.PHONE -> "phone"
        LayoutType.PHONE_SYMBOLS -> "phone_symbols"
        LayoutType.EMOJI_BOTTOM -> "emoji_bottom_row"
        LayoutType.CLIPBOARD_BOTTOM -> "clip_bottom_row"
        LayoutType.HANDWRITING_BOTTOM -> "handwriting_bottom_row"
        LayoutType.EDITING -> "editing_gboard"
        LayoutType.CUSTOM1 -> "symbols"
        LayoutType.CUSTOM2 -> "symbols"
        LayoutType.CUSTOM3 -> "symbols"
        LayoutType.CUSTOM4 -> "symbols"
        LayoutType.CUSTOM5 -> "symbols"
    }
    
    const val PREF_SPLIT_TOOLBAR = false
    const val PREF_AUTO_SPAN_TOOLBAR_KEYS = true
    const val PREF_TOOLBAR_KEYS_ALIGNMENT = "right"
    const val PREF_CLIPBOARD_KEYS_ALIGNMENT = "right"
    const val PREF_SHOW_DOWNLOAD_BUTTON_IN_TOOLBAR = true
    const val PREF_USE_SYSTEM_EMOJI = false

    const val PREF_ENABLE_SPELL_CHECKER_SERVICE = true
    const val PREF_ENABLE_CLIPBOARD_LISTENER = true
    const val PREF_ENABLE_SMS_OTP_RECEIVER = false
    const val PREF_ENABLE_APP_SYNC_LISTENER = false


    private const val DEFAULT_SIZE_SCALE = 1.0f // 100%
    const val PREF_THEME_STYLE = KeyboardTheme.STYLE_ROUNDED
    const val PREF_ICON_STYLE = KeyboardTheme.STYLE_ROUNDED
    val PREF_THEME_COLORS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) KeyboardTheme.THEME_DYNAMIC else KeyboardTheme.THEME_LIGHT
    val PREF_THEME_COLORS_NIGHT = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) KeyboardTheme.THEME_DYNAMIC else KeyboardTheme.THEME_DARK
    const val PREF_THEME_KEY_BORDERS = true
    const val PREF_KEY_BORDER_RADIUS = 10f
    const val PREF_KEY_BORDER_RADIUS_FUNCTIONAL = 25f
    const val PREF_KEY_BORDER_RADIUS_ACTION = 25f
    val PREF_THEME_DAY_NIGHT = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    const val PREF_BACKGROUND_BLUR_AMOUNT = 0
    const val PREF_USE_SYSTEM_WALLPAPER = false
    const val PREF_CUSTOM_ICON_NAMES = ""
    const val PREF_TOOLBAR_CUSTOM_KEY_CODES = ""
    const val PREF_AUTO_CAP = true
    const val PREF_VIBRATE_ON = false
    const val PREF_VIBRATE_IN_DND_MODE = false
    const val PREF_SOUND_ON = false
    const val PREF_SUGGEST_EMOJIS = true
    const val PREF_INLINE_EMOJI_SEARCH = true
    const val PREF_SHOW_EMOJI_DESCRIPTIONS = true
    var PREF_POPUP_ON = true
    const val PREF_KEY_PREVIEW_WIDTH_SCALE = 1.0f
    const val PREF_KEY_PREVIEW_HEIGHT_SCALE = 1.0f
    const val PREF_KEY_PREVIEW_RADIUS = 5f
    const val PREF_AUTO_CORRECTION = false
    const val PREF_AUTO_CORRECT_AGGRESSIVENESS = 2
    const val PREF_EXPAND_FINE_TUNE_AUTOCORRECT = false
    const val PREF_EXPAND_FINE_TUNE_PREDICTION = false
    const val PREF_EXPAND_FINE_TUNE_THEME = false
    const val PREF_EXPAND_FINE_TUNE_KEY_PREVIEWS = false
    const val PREF_EXPAND_FINE_TUNE_KEYBOARD_LAYOUT = false
    const val PREF_EXPAND_FINE_TUNE_FOLDABLE = false
    const val PREF_EXPAND_FINE_TUNE_HAPTICS = false
    const val PREF_EXPAND_FINE_TUNE_ADDITIONAL_KEYS = false
    const val PREF_EXPAND_FINE_TUNE_CLIPBOARD = false
    const val PREF_EXPAND_FINE_TUNE_TOOLBAR = false
    const val PREF_EXPAND_FINE_TUNE_GESTURE = false
    const val PREF_EXPAND_FINE_TUNE_SWIPES = false
    const val PREF_EXPAND_FINE_TUNE_ADVANCED = false
    const val PREF_AUTO_CORRECT_TRIGGER = "both"
    const val PREF_MORE_AUTO_CORRECTION = false
    const val PREF_AUTO_CORRECT_THRESHOLD = 0.067f
    const val PREF_AUTOCORRECT_SHORTCUTS = true
    const val PREF_BACKSPACE_REVERTS_AUTOCORRECT = true
    const val PREF_BACKSPACE_REPEAT_DELETES_WORDS = false
    const val PREF_CENTER_SUGGESTION_TEXT_TO_ENTER = false
    const val PREF_CENTER_TYPED_WORD = false
    const val PREF_SHOW_SUGGESTIONS = true
    const val PREF_ALWAYS_SHOW_SUGGESTIONS = false
    const val PREF_ALWAYS_SHOW_SUGGESTIONS_EXCEPT_WEB_TEXT = true
    const val PREF_KEY_USE_PERSONALIZED_DICTS = true
    const val PREF_KEY_USE_DOUBLE_SPACE_PERIOD = true
    const val PREF_BLOCK_POTENTIALLY_OFFENSIVE = true
    const val PREF_SHOW_LANGUAGE_SWITCH_KEY = false
    const val PREF_LANGUAGE_SWITCH_KEY = "internal"
    const val PREF_DIRECT_IME_SWITCH_TARGET = ""
    const val PREF_APP_LANGUAGE = ""
    const val PREF_SHOW_EMOJI_KEY = false
    const val PREF_VARIABLE_TOOLBAR_DIRECTION = true
    const val PREF_SHOW_ONLY_TOOLBAR_WITH_HARDWARE_KEYBOARD = true
    const val PREF_PHYSICAL_KEYBOARD_SUGGESTION_SHORTCUTS = "alt"
    const val PREF_PHYSICAL_KEYBOARD_LAYOUT = "match_soft_keyboard"
    const val PREF_ADDITIONAL_SUBTYPES = "de${Separators.SET}${ExtraValue.KEYBOARD_LAYOUT_SET}=MAIN:qwerty${Separators.SETS}" +
            "fr${Separators.SET}${ExtraValue.KEYBOARD_LAYOUT_SET}=MAIN:qwertz${Separators.SETS}" +
            "hu${Separators.SET}${ExtraValue.KEYBOARD_LAYOUT_SET}=MAIN:qwerty"
    const val PREF_ENABLE_SPLIT_KEYBOARD = false
    const val PREF_ENABLE_SPLIT_KEYBOARD_LANDSCAPE = false
    const val PREF_REMEMBER_FLOATING_KEYBOARD = false
    const val PREF_FLOATING_KEYBOARD_LANDSCAPE = false
    // ponytail: persist text edit mode default
    const val PREF_PERSIST_TEXT_EDIT_MODE = false
    // ponytail: default value to disable multi-word suggestions is false
    const val PREF_DISABLE_MULTI_WORD_SUGGESTIONS = false
    val PREF_SPLIT_SPACER_SCALE = Array(2) { DEFAULT_SIZE_SCALE }
    val PREF_KEYBOARD_HEIGHT_SCALE = arrayOf(0.77f, 0.45f)
    val PREF_UNFOLDED_KEYBOARD_HEIGHT_SCALE = arrayOf(0.65f, 0.40f)
    val PREF_BOTTOM_PADDING_SCALE = arrayOf(1.05f, 0f)
    val PREF_UNFOLDED_BOTTOM_PADDING_SCALE = arrayOf(0.5f, 0f)
    const val PREF_ENABLE_SPLIT_KEYBOARD_UNFOLDED = true
    val PREF_SIDE_PADDING_SCALE = Array(4) { 0.15f }
    const val PREF_FONT_SCALE = 0.85f
    const val PREF_SECONDARY_FONT_SCALE = 1.0f
    const val PREF_CLIPBOARD_FONT_SCALE = 1.0f
    const val PREF_EMOJI_FONT_SCALE = DEFAULT_SIZE_SCALE
    const val PREF_EMOJI_KEY_FIT = true
    const val PREF_EMOJI_SKIN_TONE = ""
    const val PREF_SPACE_HORIZONTAL_SWIPE = "move_cursor"
    const val PREF_SPACE_VERTICAL_SWIPE = "touchpad_mode"
    const val PREF_SPACE_VERTICAL_DOWN_SWIPE = "none"
    const val PREF_VERTICAL_SWIPE_THRESHOLD = 24
    const val PREF_DELETE_SWIPE = true
    const val PREF_DELETE_SWIPE_WORD_BY_WORD = false
    const val PREF_AUTO_PAIR_SYMBOLS = false
    const val PREF_AUTOSPACE_AFTER_PUNCTUATION = false
    const val PREF_AUTOSPACE_AFTER_EMOJI = false
    const val PREF_AUTOSPACE_AFTER_SUGGESTION = true
    const val PREF_AUTOSPACE_AFTER_GESTURE_TYPING = true
    const val PREF_AUTOSPACE_BEFORE_GESTURE_TYPING = true
    const val PREF_SHIFT_REMOVES_AUTOSPACE = false
    const val PREF_PRESERVE_SPACE_BEFORE_PUNCTUATION = false
    const val PREF_ALWAYS_INCOGNITO_MODE = false
    const val PREF_BIGRAM_PREDICTIONS = true
    const val PREF_PRIORITIZE_PERSONAL_SUGGESTIONS = false
    const val PREF_SUGGESTION_BALANCE = 3
    const val PREF_NEXT_WORD_BOOST_LEVEL = "500"
    const val PREF_NEXT_WORD_STRICT_NGRAM = false
    const val PREF_IMMEDIATE_AUTO_SPACE = false
    const val PREF_SUGGEST_PUNCTUATION = false
    const val PREF_SUGGEST_CLIPBOARD_CONTENT = true
    const val PREF_SUGGESTIONS_COUNT_IN_STRIP = 3
    const val PREF_SUGGEST_SCREENSHOTS = false
    const val PREF_COMPRESS_SCREENSHOTS = true
    const val PREF_AUTO_READ_OTP = false
    const val PREF_INLINE_MATH_CALCULATION = true
    const val PREF_GESTURE_INPUT = true
    // ponytail: gesture method default value
    const val PREF_GESTURE_METHOD = "fallback"
    const val PREF_VIBRATION_DURATION_SETTINGS = -1
    const val PREF_VIBRATION_AMPLITUDE_SETTINGS = -1
    const val PREF_HAPTIC_ENGINE = Settings.HAPTIC_ENGINE_SYSTEM
    const val PREF_KEYPRESS_SOUND_VOLUME = -0.01f
    const val PREF_KEYPRESS_SOUND_STYLE = "system"
    const val PREF_SOUND_PITCH_SCALE = 1.0f
    const val PREF_SOUND_RANDOM_PITCH = true
    const val PREF_SOUND_STEREO_PAN = true
    const val PREF_SOUND_DYNAMIC_VELOCITY = false
    const val PREF_SOUND_MUTE_IN_SILENT = true
    const val PREF_SOUND_MUTE_IN_DND = true
    const val PREF_SOUND_PLAY_OVER_BLUETOOTH = false
    const val PREF_SOUND_VOL_SPACE = 1.0f
    const val PREF_SOUND_VOL_DELETE = 1.0f
    const val PREF_SOUND_VOL_ENTER = 1.0f
    const val PREF_SOUND_VOL_MODIFIERS = 1.0f
    const val PREF_KEY_LONGPRESS_TIMEOUT = 300
    const val PREF_ENABLE_EMOJI_ALT_PHYSICAL_KEY = true
    const val PREF_GESTURE_PREVIEW_TRAIL = true
    const val PREF_GESTURE_FLOATING_PREVIEW_TEXT = true
    const val PREF_GESTURE_FLOATING_PREVIEW_DYNAMIC = true
    var PREF_GESTURE_DYNAMIC_PREVIEW_FOLLOW_SYSTEM = true
    const val PREF_GESTURE_SPACE_AWARE = false
    const val PREF_GESTURE_FAST_TYPING_COOLDOWN = 500
    const val PREF_GESTURE_TRAIL_FADEOUT_DURATION = 800
    const val PREF_USE_APPS = false
    const val PREFS_LONG_PRESS_SYMBOLS_FOR_NUMPAD = false
    const val PREF_ONE_HANDED_MODE = false
    @SuppressLint("RtlHardcoded")
    const val PREF_ONE_HANDED_GRAVITY = Gravity.LEFT
    const val PREF_ONE_HANDED_SCALE = 1f
    const val PREF_SHOW_NUMBER_ROW = false
    const val PREF_SHOW_NUMBER_ROW_IN_SYMBOLS = true
    const val PREF_COMPACT_NUMBER_ROW_IN_SYMBOLS = true
    const val PREF_LOCALIZED_NUMBER_ROW = true
    const val PREF_SHOW_NUMBER_ROW_HINTS = false
    const val PREF_CUSTOM_CURRENCY_KEY = ""
    const val PREF_SHOW_HINTS = true
    const val PREF_POPUP_KEYS_ORDER = POPUP_KEYS_ORDER_DEFAULT
    const val PREF_POPUP_KEYS_LABELS_ORDER = POPUP_KEYS_LABEL_DEFAULT
    const val PREF_SHOW_POPUP_HINTS = false
    const val PREF_SHOW_TLD_POPUP_KEYS = true
    const val PREF_POPUP_KEYS_VERTICAL_OFFSET = 8f // Legacy dp default
    const val PREF_POPUP_KEYS_VERTICAL_OFFSET_PERCENT = 4f
    const val PREF_ANIMATION_SPEED_SCALE = 1.0f
    const val PREF_MORE_POPUP_KEYS = "main"
    const val PREF_SPACE_TO_CHANGE_LANG = true
    const val PREF_LANGUAGE_SWIPE_DISTANCE = 5
    const val PREF_FULL_KEYBOARD_SWIPE = "none"
    const val PREF_FULL_SWIPE_SWITCH_LANGUAGE = false
    const val PREF_TOUCHPAD_SENSITIVITY = 50
    const val PREF_TOUCHPAD_FULLSCREEN = false
    const val PREF_FORCE_AUTO_CAPS = false
    const val PREF_SHIFT_RECAPITALIZES_WORD = false
    const val PREF_CLIPBOARD_SKIP_SENSITIVE = false
    const val PREF_OFFLINE_TEMP = 0.1f  // Lower for faster, more deterministic proofreading
    const val PREF_OFFLINE_TOP_P = 0.5f  // Lower for faster token sampling
    const val PREF_OFFLINE_TOP_K = 40
    const val PREF_OFFLINE_MIN_P = 0.05f
    const val PREF_OFFLINE_SHOW_THINKING = false
    const val PREF_OFFLINE_SYSTEM_PROMPT = "Correct the grammar and spelling. Keep the same language as the input. Do not translate. Output only the corrected text."
    const val PREF_OFFLINE_TRANSLATE_SYSTEM_PROMPT = "Translate the following text to {lang}. Output only the translation, nothing else:\n\n"
    const val PREF_OFFLINE_MAX_TOKENS = 512
    const val PREF_OFFLINE_TRANSLATE_TARGET_LANGUAGE = "French"
    const val PREF_OFFLINE_KEEP_MODEL_LOADED = false
    const val PREF_AI_ALLOW_INSECURE_CONNECTIONS = false
    const val PREF_OPENAI_USE_MAX_COMPLETION_TOKENS = false
    const val PREF_OPENAI_OMIT_TEMPERATURE = false
    const val PREF_CLOUD_AI_MAX_TOKENS = 4096
    const val PREF_ENABLE_CLIPBOARD_HISTORY = true
    const val PREF_CLIPBOARD_HISTORY_RETENTION_TIME = 15 // minutes
    const val PREF_CLIPBOARD_HISTORY_PINNED_FIRST = true
    const val PREF_CLIPBOARD_FOLD_PINNED = false
    const val PREF_CLEAR_CLIPBOARD_ICON = "bin"
    const val PREF_ADD_TO_PERSONAL_DICTIONARY = false
    const val PREF_ADD_TO_PERSONAL_DICT_THRESHOLD = 6
    val PREF_NAVBAR_COLOR = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    const val PREF_NARROW_KEY_GAPS = true
    const val PREF_NARROW_KEY_GAPS_LEVEL = 1
    const val PREF_ENABLED_SUBTYPES = ""
    const val PREF_SELECTED_SUBTYPE = ""
    const val PREF_URL_DETECTION = false
    const val PREF_DONT_SHOW_MISSING_DICTIONARY_DIALOG = false
    const val PREF_DISABLE_NETWORK = false
    const val PREF_TOOLBAR_MODE = "EXPANDABLE"
    const val PREF_TOOLBAR_HIDING_GLOBAL = true
    const val PREF_QUICK_PIN_TOOLBAR_KEYS = false
    const val PREF_TOOLBAR_LONG_PRESS_HINT = true
    val PREF_PINNED_TOOLBAR_KEYS = defaultPinnedToolbarPref
    val PREF_TOOLBAR_KEYS = defaultToolbarPref
    const val PREF_AUTO_SHOW_TOOLBAR = false
    const val PREF_AUTO_SHOW_TOOLBAR_ON_SELECT = false
    const val PREF_AUTO_HIDE_TOOLBAR = true
    const val PREF_AUTO_SHOW_TOOLBAR_NO_SUGGESTIONS = false
    const val PREF_TOOLBAR_SWIPE_DOWN_DISMISS = false
    const val PREF_TOOLBAR_SWIPE_UP_GESTURE = "none"
    const val PREF_TOOLBAR_SWIPE_DOWN_GESTURE = "none"
    const val PREF_AUTO_HIDE_PINNED_KEYS = true
    const val PREF_REMEMBER_TOOLBAR_STATE = false
    const val PREF_TOOLBAR_EXPANDED = false
    val PREF_CLIPBOARD_TOOLBAR_KEYS = defaultClipboardToolbarPref
    const val PREF_ABC_AFTER_EMOJI = false
    const val PREF_ABC_AFTER_CLIP = false
    const val PREF_ABC_AFTER_SYMBOL_SPACE = true
    const val PREF_ABC_AFTER_NUMPAD_SPACE = false
    const val PREF_REMOVE_REDUNDANT_POPUPS = true
    const val PREF_SPACE_BAR_TEXT = ""
    const val PREF_TIMESTAMP_FORMAT = "yyyy-MM-dd HH:mm:ss"
    const val PREF_EMOJI_RECENT_KEYS = ""
    const val PREF_LAST_SHOWN_EMOJI_CATEGORY_PAGE_ID = 0
    const val PREF_SHOW_DEBUG_SETTINGS = false
    val PREF_DEBUG_MODE = BuildConfig.DEBUG
    const val PREF_SHOW_SUGGESTION_INFOS = false
    const val PREF_FORCE_NON_DISTINCT_MULTITOUCH = false
    const val PREF_SLIDING_KEY_INPUT_PREVIEW = true
    const val PREF_USER_COLORS = "[]"
    const val PREF_USER_MORE_COLORS = 0
    const val PREF_USER_ALL_COLORS = ""
    const val PREF_SAVE_SUBTYPE_PER_APP = false
    const val PREF_DONT_SHOW_SPONSOR_DIALOG = false
    const val PREF_LAST_SPONSOR_DIALOG_SHOWN = 0L
}
