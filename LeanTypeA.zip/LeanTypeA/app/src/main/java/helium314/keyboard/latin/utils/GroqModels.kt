/*
 * Copyright (C) 2026 LeanBitLab
 * SPDX-License-Identifier: GPL-3.0-only
 */
package helium314.keyboard.latin.utils

object GroqModels {
    val AVAILABLE_MODELS = listOf(
        "llama-3.3-70b-versatile",
        "llama-3.1-8b-instant",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "meta-llama/llama-4-maverick-17b-128e-instruct",
        "qwen/qwen3-32b",
        "openai/gpt-oss-120b",
        "openai/gpt-oss-20b",
        "groq/compound",
        "groq/compound-mini",
        "moonshotai/kimi-k2-instruct",
        "moonshotai/kimi-k2-instruct-0905",
        "canopylabs/orpheus-v1-english",
        "canopylabs/orpheus-arabic-saudi",
        "allam-2-7b"
    )
    const val DEFAULT_MODEL = "llama-3.1-8b-instant"

    val VOICE_MODELS = listOf(
        "whisper-large-v3-turbo",
        "whisper-large-v3",
        "distil-whisper-large-v3-en"
    )
    const val DEFAULT_VOICE_MODEL = "whisper-large-v3-turbo"
}
