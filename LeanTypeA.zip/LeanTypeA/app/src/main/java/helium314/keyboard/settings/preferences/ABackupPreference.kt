// SPDX-License-Identifier: GPL-3.0-only
package helium314.keyboard.settings.preferences

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import helium314.keyboard.latin.ABackup
import helium314.keyboard.latin.utils.prefs
import helium314.keyboard.settings.Setting
import helium314.keyboard.settings.filePicker

/** LeanType A: automatic backups, backup now, restore, and Make APK (the keyboard with its settings inside). */
@Composable
fun ABackupPreference(setting: Setting) {
    val ctx = LocalContext.current
    var show by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(ABackup.autoEnabled(ctx)) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    val restorePicker = filePicker { uri ->
        msg = "Restoring…"
        ABackup.restoreFromUri(ctx, uri) { err -> msg = err?.let { "Restore failed: $it" } ?: "Restored. Settings are applied." }
    }

    fun go(start: String, job: () -> String) {
        if (busy) return
        busy = true; msg = start
        Thread { val r = runCatching(job).getOrElse { "Failed: ${it.message}" }; msg = r; busy = false }.start()
    }

    Preference(name = setting.title, onClick = { show = true })
    if (show) {
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text(setting.title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Automatic backup to Download/A Settings (last 5)", Modifier.weight(1f))
                        Switch(checked = auto, onCheckedChange = {
                            auto = it
                            ctx.prefs().edit().putBoolean(ABackup.AUTO_ON, it).apply()
                            ABackup.refresh(ctx)
                        })
                    }
                    TextButton(enabled = !busy, onClick = {
                        go("Backing up…") { ABackup.saveNow(ctx, onlyIfChanged = false)?.let { "Saved: $it" } ?: "Backup failed" }
                    }) { Text("Back up now") }
                    TextButton(enabled = !busy, onClick = {
                        go("Looking…") {
                            val e = ABackup.list(ctx).firstOrNull() ?: return@go "No automatic backup found in Download/A Settings."
                            msg = "Restoring ${e.name}…"
                            ABackup.restoreFromUri(ctx, ABackup.uriOf(e)) { err -> msg = err?.let { "Restore failed: $it" } ?: "Restored ${e.name}." }
                            msg
                        }
                    }) { Text("Restore newest automatic backup") }
                    TextButton(enabled = !busy, onClick = {
                        restorePicker.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" })
                    }) { Text("Restore from a file…") }
                    TextButton(enabled = !busy, onClick = {
                        go("Making the APK… (about half a minute)") { ABackup.makeApk(ctx) }
                    }) { Text("Make APK with my settings") }
                    if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                    Text(
                        "Saved: layouts, colors and appearance, dictionaries and all settings. Not saved: clipboard history, typing history, API keys. " +
                            "An APK made here installs over this keyboard and brings the settings along; on a new phone it starts with them.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { show = false }) { Text("Close") } },
        )
    }
}
