/*
 * Copyright (C) 2014 The Android Open Source Project
 * modified
 * SPDX-License-Identifier: Apache-2.0 AND GPL-3.0-only
 */

package helium314.keyboard.latin

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import helium314.keyboard.keyboard.KeyboardLayoutSet
import helium314.keyboard.latin.utils.Log
import helium314.keyboard.settings.SettingsActivity

/**
 * This class detects the [Intent.ACTION_MY_PACKAGE_REPLACED] broadcast intent when this IME
 * package has been replaced by a newer version of the same package. This class also detects
 * [Intent.ACTION_BOOT_COMPLETED] broadcast intent.
 */
class SystemBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                Log.i(TAG, "Package has been replaced: " + context.packageName)
                ensureLauncherActivityEnabled(context)
            }
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.i(TAG, "Boot has been completed")
            }
            Intent.ACTION_LOCALE_CHANGED -> {
                Log.i(TAG, "System locale changed")
                KeyboardLayoutSet.onSystemLocaleChanged()
            }
        }
    }

    companion object {
        private val TAG = SystemBroadcastReceiver::class.simpleName

        private fun ensureLauncherActivityEnabled(context: Context) {
            try {
                val component = ComponentName(context, SettingsActivity::class.java)
                val state = context.packageManager.getComponentEnabledSetting(component)
                if (state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                    context.packageManager.setComponentEnabledSetting(
                        component,
                        PackageManager.COMPONENT_ENABLED_STATE_DEFAULT,
                        PackageManager.DONT_KILL_APP
                    )
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to restore launcher activity state", e)
            }
        }
    }
}
