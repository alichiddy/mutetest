// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.SharedPreferences
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.util.TypedValue
import android.view.Gravity
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/**
 * LeanType A addition: the options of the clipboard (opened with the gear icon in the clipboard icon bar)
 * and the clip shortcuts (a short word that offers a clip in the suggestion strip).
 */
object ClipboardOptions {
    const val KEY_MIDDLE_ELLIPSIS = "clip_opt_middle_ellipsis"
    const val KEY_COLS_PORTRAIT = "clip_opt_cols_portrait"
    const val KEY_COLS_LANDSCAPE = "clip_opt_cols_landscape"
    const val KEY_LINES = "clip_opt_lines"
    const val KEY_SHORTCUTS_ON = "clip_opt_shortcuts"
    private const val KEY_SHORTCUTS = "clip_shortcuts_v1"
    private const val KEY_EDIT_ACTIONS = "clip_edit_actions_v1"

    const val KEY_DOTS = "clip_opt_dots"
    const val DEFAULT_DOTS = 6

    const val DEFAULT_LINES = 4

    /** Number of dots between the first part and the last words of a long clip. */
    fun dots(p: SharedPreferences) = p.getInt(KEY_DOTS, DEFAULT_DOTS).coerceIn(1, 30)

    fun middleEllipsis(p: SharedPreferences) = p.getBoolean(KEY_MIDDLE_ELLIPSIS, false)
    fun lines(p: SharedPreferences) = p.getInt(KEY_LINES, DEFAULT_LINES).coerceIn(1, 20)
    fun shortcutsOn(p: SharedPreferences) = p.getBoolean(KEY_SHORTCUTS_ON, true)

    /** 0 = the normal number of columns of the app. */
    fun columns(p: SharedPreferences, landscape: Boolean): Int =
        p.getInt(if (landscape) KEY_COLS_LANDSCAPE else KEY_COLS_PORTRAIT, 0).coerceIn(0, 8)

    // ---------------------------------------------------------------------------------------------
    // size of the icons in the icon bar (dp)

    const val KEY_ICON_SIZE = "clip_opt_icon_size"
    const val DEFAULT_ICON_SIZE = 36
    fun iconSize(p: SharedPreferences) = p.getInt(KEY_ICON_SIZE, DEFAULT_ICON_SIZE).coerceIn(20, 64)

    /** Paste methods, in the order the user picked them: "text" (type it in), "native" (the app's own Paste), "key" (paste key). */
    const val KEY_PASTE_ORDER = "clip_opt_paste_order"
    val PASTE_METHODS = listOf("text", "native", "key")
    fun pasteOrder(p: SharedPreferences): List<String> =
        (p.getString(KEY_PASTE_ORDER, "text") ?: "text").split(",").filter { it in PASTE_METHODS }.distinct().ifEmpty { listOf("text") }

    const val KEY_TRACE_ON = "clip_opt_trace"
    fun traceOn(p: SharedPreferences) = p.getBoolean(KEY_TRACE_ON, true)

    // ---------------------------------------------------------------------------------------------
    // clip titles: a short name shown on the card, never pasted

    const val KEY_TITLE_ON = "clip_opt_title_on"
    const val KEY_TITLE_ONLY = "clip_opt_title_only"
    const val KEY_TITLE_BOLD = "clip_opt_title_bold"
    const val KEY_TITLE_ITALIC = "clip_opt_title_italic"
    const val KEY_TITLE_UNDERLINE = "clip_opt_title_underline"
    const val KEY_TITLE_HIGHLIGHT = "clip_opt_title_highlight"
    const val KEY_TITLE_SIZE = "clip_opt_title_size"
    const val KEY_TITLE_COLOR = "clip_opt_title_color"
    const val KEY_TITLE_ALIGN = "clip_opt_title_align"
    private const val KEY_TITLES = "clip_titles_v1"

    /** Colours offered for titles; 0 = same as the clip text. */
    val TITLE_COLORS = intArrayOf(
        0, 0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFFFDD835.toInt(), 0xFF43A047.toInt(),
        0xFF00ACC1.toInt(), 0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFFEC407A.toInt(),
        0xFFFFFFFF.toInt(), 0xFF000000.toInt()
    )

    data class TitleStyle(
        val on: Boolean, val only: Boolean, val bold: Boolean, val italic: Boolean, val underline: Boolean,
        val highlight: Boolean, val sizeSp: Int, val color: Int, val align: Int
    )

    fun titleStyle(p: SharedPreferences) = TitleStyle(
        on = p.getBoolean(KEY_TITLE_ON, true),
        only = p.getBoolean(KEY_TITLE_ONLY, false),
        bold = p.getBoolean(KEY_TITLE_BOLD, true),
        italic = p.getBoolean(KEY_TITLE_ITALIC, false),
        underline = p.getBoolean(KEY_TITLE_UNDERLINE, false),
        highlight = p.getBoolean(KEY_TITLE_HIGHLIGHT, false),
        sizeSp = p.getInt(KEY_TITLE_SIZE, 13).coerceIn(8, 28),
        color = p.getInt(KEY_TITLE_COLOR, 0),
        align = p.getInt(KEY_TITLE_ALIGN, 0).coerceIn(0, 2)
    )

    /** Shows [title] in [tv] with the chosen look. [defaultColor] is used when the colour is left on automatic. */
    fun styleTitle(tv: TextView, title: String, style: TitleStyle, defaultColor: Int, face: Typeface?, maxLines: Int) {
        val color = if (style.color == 0) defaultColor else style.color
        val sp = SpannableString(title)
        if (style.underline) sp.setSpan(android.text.style.UnderlineSpan(), 0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (style.highlight) sp.setSpan(
            android.text.style.BackgroundColorSpan((color and 0x00FFFFFF) or 0x40000000),
            0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        tv.text = sp
        val flags = when {
            style.bold && style.italic -> Typeface.BOLD_ITALIC
            style.bold -> Typeface.BOLD
            style.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        tv.typeface = Typeface.create(face ?: Typeface.DEFAULT, flags)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, style.sizeSp.toFloat())
        tv.setTextColor(color)
        tv.maxLines = maxLines
        tv.gravity = when (style.align) {
            1 -> Gravity.CENTER_HORIZONTAL
            2 -> Gravity.END
            else -> Gravity.START
        }
    }

    @Volatile private var cachedTitlesRaw: String? = null
    @Volatile private var cachedTitles: Map<Long, String> = emptyMap()

    fun loadTitles(p: SharedPreferences): Map<Long, String> {
        val raw = p.getString(KEY_TITLES, null) ?: return emptyMap()
        if (raw == cachedTitlesRaw) return cachedTitles
        val map = try {
            val o = JSONObject(raw)
            val m = HashMap<Long, String>()
            o.keys().forEach { k -> k.toLongOrNull()?.let { id -> o.optString(k).takeIf { t -> t.isNotEmpty() }?.let { t -> m[id] = t } } }
            m
        } catch (_: Exception) {
            emptyMap<Long, String>()
        }
        cachedTitles = map
        cachedTitlesRaw = raw
        return map
    }

    fun titleOfClip(p: SharedPreferences, clipId: Long): String? = loadTitles(p)[clipId]

    /** An empty [title] removes the title of the clip. */
    fun setTitle(p: SharedPreferences, clipId: Long, title: String) {
        val m = loadTitles(p).toMutableMap()
        val t = title.trim().replace('\n', ' ')
        if (t.isEmpty()) m.remove(clipId) else m[clipId] = t.take(200)
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k.toString(), v) }
        p.edit().putString(KEY_TITLES, o.toString()).apply()
    }

    // ---------------------------------------------------------------------------------------------
    // buttons shown under the clip editor (null = all)

    fun editActions(p: SharedPreferences): Set<String>? =
        p.getString(KEY_EDIT_ACTIONS, null)?.split(',')?.filter { it.isNotEmpty() }?.toSet()

    fun setEditActions(p: SharedPreferences, names: Collection<String>) {
        p.edit().putString(KEY_EDIT_ACTIONS, names.joinToString(",")).apply()
    }

    // ---------------------------------------------------------------------------------------------
    // clip shortcuts

    data class Shortcut(val key: String, val clipId: Long, val text: String)

    @Volatile private var cachedRaw: String? = null
    @Volatile private var cachedList: List<Shortcut> = emptyList()

    fun loadShortcuts(p: SharedPreferences): List<Shortcut> {
        val raw = p.getString(KEY_SHORTCUTS, null) ?: return emptyList()
        if (raw == cachedRaw) return cachedList
        val list = try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                val o = arr.optJSONObject(it) ?: return@mapNotNull null
                val key = o.optString("k")
                if (key.isEmpty()) null else Shortcut(key, o.optLong("id", -1L), o.optString("t"))
            }
        } catch (_: Exception) {
            emptyList()
        }
        cachedList = list
        cachedRaw = raw
        return list
    }

    private fun saveShortcuts(p: SharedPreferences, list: List<Shortcut>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("k", it.key).put("id", it.clipId).put("t", it.text)) }
        p.edit().putString(KEY_SHORTCUTS, arr.toString()).apply()
    }

    fun shortcutOfClip(p: SharedPreferences, clipId: Long): String? =
        loadShortcuts(p).firstOrNull { it.clipId == clipId }?.key

    /** One shortcut per clip, one clip per shortcut word. An empty [word] removes the shortcut of the clip. */
    fun setShortcut(p: SharedPreferences, clipId: Long, text: String, word: String) {
        val key = word.filter { !it.isWhitespace() }
        val list = loadShortcuts(p).filter { it.clipId != clipId && !it.key.equals(key, ignoreCase = true) }.toMutableList()
        if (key.isNotEmpty()) list.add(Shortcut(key, clipId, text))
        saveShortcuts(p, list)
    }

    /** Keeps the saved text of the shortcut in step with an edited clip. */
    fun updateShortcutText(p: SharedPreferences, clipId: Long, text: String) {
        val list = loadShortcuts(p)
        if (list.none { it.clipId == clipId }) return
        saveShortcuts(p, list.map { if (it.clipId == clipId) it.copy(text = text) else it })
    }

    fun findShortcut(p: SharedPreferences, typed: String): Shortcut? {
        if (typed.isEmpty() || !shortcutsOn(p)) return null
        return loadShortcuts(p).firstOrNull { it.key.equals(typed, ignoreCase = true) && it.text.isNotEmpty() }
    }
}
