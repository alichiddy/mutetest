// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.settings.dialogs

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import helium314.keyboard.keyboard.ColorSetting
import helium314.keyboard.keyboard.KeyboardTheme
import helium314.keyboard.latin.AClipColors
import helium314.keyboard.latin.common.ColorType
import helium314.keyboard.latin.common.default
import helium314.keyboard.latin.settings.Defaults
import helium314.keyboard.latin.settings.Settings
import java.util.EnumMap

/** LeanType A: six colours in one place; each can be Automatic, Dynamic (system palette) or Custom. */
private class QRow(val title: String, val name: String, val type: ColorType?)

private val rows = listOf(
    QRow("1. Keyboard background", KeyboardTheme.COLOR_BACKGROUND, ColorType.MAIN_BACKGROUND),
    QRow("2. All the buttons (letters)", KeyboardTheme.COLOR_KEYS, ColorType.KEY_BACKGROUND),
    QRow("3. Shift, numbers, comma, language, dot", KeyboardTheme.COLOR_FUNCTIONAL_KEYS, ColorType.FUNCTIONAL_KEY_BACKGROUND),
    QRow("4. Enter button", KeyboardTheme.COLOR_ACCENT, ColorType.ACTION_KEY_BACKGROUND),
    QRow("Clipboard background", AClipColors.CLIP_BACKGROUND, null),
    QRow("Clipboard items", AClipColors.CLIP_CARDS, null),
)

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun QuickColorsDialog(prefs: SharedPreferences, themeName: String, isNight: Boolean, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<QRow?>(null) }
    var custom by remember { mutableStateOf<QRow?>(null) }

    fun current(r: QRow): Pair<Int, Boolean> { // colour shown, is it chosen (not automatic)
        version.let { }
        val list = KeyboardTheme.readUserColors(prefs, themeName)
        if (r.type == null) {
            val c = list.firstOrNull { it.name == r.name && it.auto != true }?.color
            return (c ?: android.graphics.Color.GRAY) to (c != null)
        }
        if (KeyboardTheme.readUserMoreColors(prefs, themeName) == 2) {
            val style = prefs.getString(Settings.PREF_THEME_STYLE, Defaults.PREF_THEME_STYLE) ?: Defaults.PREF_THEME_STYLE
            val fb = KeyboardTheme.getThemeColors(themeName, style, ctx, prefs, isNight)
            val all = KeyboardTheme.readUserAllColors(prefs, themeName, fb)
            val own = KeyboardTheme.readUserAllColors(prefs, themeName, null)
            return (all[r.type] ?: r.type.default()) to own.containsKey(r.type)
        }
        val c = list.firstOrNull { it.name == r.name }
        return KeyboardTheme.determineUserColor(list, ctx, r.name, isNight) to (c != null && c.auto == false && c.color != null)
    }

    fun apply(r: QRow, color: Int?) {
        if (r.type != null && r.name != AClipColors.CLIP_BACKGROUND && KeyboardTheme.readUserMoreColors(prefs, themeName) == 2) {
            val map: EnumMap<ColorType, Int> = KeyboardTheme.readUserAllColors(prefs, themeName, null)
            if (color == null) map.remove(r.type) else map[r.type] = color
            KeyboardTheme.writeUserAllColors(prefs, themeName, map)
        } else {
            val old = KeyboardTheme.readUserColors(prefs, themeName)
            val cs = if (color == null) ColorSetting(r.name, true, null) else ColorSetting(r.name, false, color)
            KeyboardTheme.writeUserColors(prefs, themeName, (old + cs).reversed().distinctBy { it.name })
        }
        version++
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Quick colors") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Tap a colour: Automatic, Dynamic (your phone's palette) or Custom. Reopen the keyboard to see changes.", style = MaterialTheme.typography.bodySmall)
                for (r in rows) {
                    val (c, chosen) = current(r)
                    Row(
                        Modifier.fillMaxWidth().clickable { editing = r }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Spacer(Modifier.size(36.dp).background(Color(c), CircleShape))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(r.title, style = MaterialTheme.typography.bodyLarge)
                            Text(if (chosen) "Chosen" else "Automatic", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )

    editing?.let { r ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(r.title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = { apply(r, null); editing = null }) { Text("Automatic") }
                    TextButton(onClick = { custom = r; editing = null }) { Text("Custom…") }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        Text("Dynamic (system palette)", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (id in dynamicIds()) {
                                val col = runCatching { ctx.getColor(id) }.getOrNull() ?: continue
                                Spacer(Modifier.size(40.dp).background(Color(col), CircleShape).clickable { apply(r, col); editing = null })
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
        )
    }
    custom?.let { r ->
        ColorPickerDialog(
            onDismissRequest = { custom = null },
            initialColor = current(r).first,
            title = r.title,
            showDefault = true,
            onDefault = { apply(r, null) },
        ) { color -> apply(r, color); custom = null }
    }
}

private fun dynamicIds(): List<Int> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) listOf(
    android.R.color.system_accent1_100, android.R.color.system_accent1_200, android.R.color.system_accent1_300,
    android.R.color.system_accent1_400, android.R.color.system_accent1_500, android.R.color.system_accent1_600,
    android.R.color.system_accent1_700, android.R.color.system_accent2_300, android.R.color.system_accent2_500,
    android.R.color.system_accent3_300, android.R.color.system_accent3_500,
    android.R.color.system_neutral1_50, android.R.color.system_neutral1_100, android.R.color.system_neutral1_200,
    android.R.color.system_neutral1_700, android.R.color.system_neutral1_800, android.R.color.system_neutral1_900,
) else emptyList()
