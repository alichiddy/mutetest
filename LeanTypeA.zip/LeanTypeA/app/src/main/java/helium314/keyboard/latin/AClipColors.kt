// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.Context
import helium314.keyboard.keyboard.KeyboardTheme
import helium314.keyboard.latin.settings.Defaults
import helium314.keyboard.latin.settings.Settings
import helium314.keyboard.latin.utils.prefs
import helium314.keyboard.settings.SettingsActivity

/** LeanType A: the clipboard's own colours, chosen in Colors > Quick colors (stored with the theme). */
object AClipColors {
    const val CLIP_BACKGROUND = "clipboard_background"
    const val CLIP_CARDS = "clipboard_cards"

    fun themeName(context: Context): String {
        val prefs = context.prefs()
        val isNight = SettingsActivity.forceNight
            ?: (helium314.keyboard.latin.utils.ResourceUtils.isNight(context.resources) && prefs.getBoolean(Settings.PREF_THEME_DAY_NIGHT, Defaults.PREF_THEME_DAY_NIGHT))
        return SettingsActivity.forceTheme ?: (if (isNight) prefs.getString(Settings.PREF_THEME_COLORS_NIGHT, Defaults.PREF_THEME_COLORS_NIGHT)
        else prefs.getString(Settings.PREF_THEME_COLORS, Defaults.PREF_THEME_COLORS)) ?: Defaults.PREF_THEME_COLORS
    }

    /** The chosen colour, or null when it is left on automatic. */
    fun get(context: Context, name: String): Int? = runCatching {
        KeyboardTheme.readUserColors(context.prefs(), themeName(context))
            .firstOrNull { it.name == name && it.auto != true }?.color
    }.getOrNull()
}
