// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * LeanType A addition: the icons of the clipboard sections. An icon is stored as one text:
 *  - "res:robot"        a built-in drawn icon (takes the colour of the keyboard icons)
 *  - "app:com.pkg.name" the icon of an installed app
 *  - anything else      text shown big: an emoji, or a few letters typed by the user
 */
object ClipIcons {
    const val RES = "res:"
    const val APP = "app:"

    /** Built-in drawn icons: name -> drawable, and the emoji that stands for it where only text fits. */
    private val BUILTIN = linkedMapOf(
        "robot" to Pair(R.drawable.ic_clip_robot, "🤖"),
        "terminal" to Pair(R.drawable.ic_clip_terminal, "⌨️"),
        "code" to Pair(R.drawable.ic_clip_code, "💻"),
        "command" to Pair(R.drawable.ic_clip_command, "⌘")
    )

    val BUILTIN_SPECS: List<String> = BUILTIN.keys.map { RES + it }

    /** The emoji picker: simple emojis that every phone can draw. */
    val EMOJI_ALL: List<String> = (
        "🤖 💻 🖥️ ⌨️ 🖱️ 🧑‍💻 🛠️ 🔧 🔨 ⚙️ 🧰 🧪 🧠 ✨ 💡 🔮 🪄 🚀 🛰️ 📡 🔌 🔋 💾 💿 📀 🗄️ 🗂️ 📁 📂 📋 📎 📌 📍 🔍 🔎 " +
        "📝 ✏️ 🖊️ 📖 📚 📰 🗞️ 📄 📃 📑 🧾 📊 📈 📉 🗓️ 📅 ⏰ ⏳ ⌛ 🕐 🔔 🔕 📣 📢 💬 🗨️ 💭 ✉️ 📧 📨 📩 📮 📦 🎁 " +
        "🏠 🏡 🏢 🏬 🏦 🏥 🏫 🏭 ⛪ 🕌 🛒 🛍️ 💳 💰 💵 💶 💸 🪙 🧮 🔑 🗝️ 🔒 🔓 🔐 🛡️ ⚠️ 🚫 ✅ ❌ ❗ ❓ " +
        "👤 👥 👨 👩 🧒 👶 👨‍👩‍👧 🙂 😀 😎 🤓 🥳 😍 🤔 😴 🤯 👍 👎 👌 🙏 💪 👀 🧿 ❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 ⭐ 🌟 🔥 💥 ⚡ " +
        "🌐 🔗 📶 📞 ☎️ 📱 📲 📷 📸 🎥 🎬 🎵 🎶 🎧 🎤 🎮 🕹️ 🎲 🎯 🧩 ⚽ 🏀 🏆 🥇 🎓 🎨 🖌️ " +
        "🍔 🍕 🍟 🌮 🍜 🍣 🍰 🍎 🍌 🍇 ☕ 🍵 🥤 🍺 " +
        "🚗 🚕 🚌 🚆 ✈️ 🚁 🚲 🏍️ ⛽ 🗺️ 🧭 🏖️ ⛰️ 🌍 🌙 ☀️ ☁️ ❄️ 🌧️ 🌈 🌱 🌳 🌸 🐶 🐱 🐞 🦋 " +
        "💊 💉 🩺 🧬 🔬 🔭 ⚖️ 📐 📏 ✂️ 🧷 🧹 🪪 🏷️ 🔖 ➕ ➖ ✔️ ➡️ ⬅️ ⬆️ ⬇️ 🔄 ♻️ #️⃣ 🔢 🔤 ⌘"
        ).split(" ").filter { it.isNotEmpty() }.distinct()

    fun isText(spec: String) = !spec.startsWith(RES) && !spec.startsWith(APP)

    fun builtinRes(spec: String): Int? =
        if (spec.startsWith(RES)) BUILTIN[spec.removePrefix(RES)]?.first else null

    fun appPackage(spec: String): String? = if (spec.startsWith(APP)) spec.removePrefix(APP) else null

    /** Text that stands for the icon where only text can be shown (e.g. the small badge of a search result). */
    fun fallbackText(spec: String): String = when {
        isText(spec) -> spec
        spec.startsWith(RES) -> BUILTIN[spec.removePrefix(RES)]?.second ?: "📁"
        else -> "📱"
    }

    private val appCache = HashMap<String, Drawable?>()

    fun appIcon(context: Context, pkg: String): Drawable? {
        if (appCache.containsKey(pkg)) return appCache[pkg]?.constantState?.newDrawable()?.mutate() ?: appCache[pkg]
        val d = try { context.packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }
        appCache[pkg] = d
        return d?.constantState?.newDrawable()?.mutate() ?: d
    }

    /** Makes the view of an icon, [sizePx] high and wide, with the icon stretched to fill it. */
    fun createView(context: Context, spec: String, sizePx: Int, tint: Int, textColor: Int): View {
        val res = builtinRes(spec)
        if (res != null) {
            return ImageView(context).apply {
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageResource(res)
                setColorFilter(tint)
            }
        }
        val pkg = appPackage(spec)
        if (pkg != null) {
            val d = appIcon(context, pkg)
            if (d != null) {
                return ImageView(context).apply {
                    layoutParams = LinearLayout.LayoutParams(sizePx, sizePx)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageDrawable(d)
                }
            }
        }
        val text = if (pkg != null) "📱" else spec
        // letters shrink so that a few of them still fit; an emoji fills the whole height
        val plain = text.all { it.isLetterOrDigit() }
        val factor = if (plain && text.length > 1) 0.78f / text.length.coerceAtMost(4) * 1.6f else 0.78f
        return TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, sizePx)
            gravity = Gravity.CENTER
            includeFontPadding = false
            this.text = text
            setTextColor(textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx * factor.coerceAtMost(0.78f))
            maxLines = 1
        }
    }
}
