// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import helium314.keyboard.compat.ClipboardManagerCompat

/**
 * LeanType A addition. Whenever something is copied (in any app, because a keyboard may read the
 * clipboard at any time): Persian and Arabic digits are replaced by 0-9 in the copied text, and the
 * A app (package a.a) is told what was copied so it can show it, translate it and so on.
 * The broadcast is protected by a signature permission, so only apps signed with the same key as A
 * can receive it.
 */
object AClipBridge {
    private const val ACTION = "a.a.CLIP_COPIED"
    private const val TARGET = "a.a"
    private const val PERMISSION = "a.a.permission.CLIP_FROM_KEYBOARD"
    private var lastSet: String? = null
    private var lastSetAt = 0L
    private var lastSent: String? = null
    private var lastSentAt = 0L

    fun convertDigits(s: String): String {
        var changed = false
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')   // Persian
                in '٠'..'٩' -> '0' + (ch - '٠')   // Arabic-Indic
                '٫' -> '.'                                  // Arabic decimal separator
                '٬' -> ','                                  // Arabic thousands separator
                else -> ch
            }
            if (c != ch) changed = true
            sb.append(c)
        }
        return if (changed) sb.toString() else s
    }

    /** True while the keyboard itself re-reads the clipboard (window shown): nothing new was copied then. */
    @Volatile var suppress = false

    fun onCopy(context: Context, cm: ClipboardManager, keepOriginal: ((String, Long) -> Unit)? = null) {
        if (suppress) return
        val clip = try { cm.primaryClip } catch (_: Exception) { null } ?: return
        if (clip.itemCount == 0) return
        // Passwords and other items marked sensitive by the copying app are left alone.
        if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        if (clip.description?.hasMimeType("text/*") != true) return
        val text = clip.getItemAt(0)?.coerceToText(context)?.toString() ?: return
        val now = System.currentTimeMillis()
        if (text.isEmpty()) return
        // The echo of our own rewrite (it triggers this again within a moment) is ignored; a real
        // copy of the same text later is not.
        if (text == lastSet && now - lastSetAt < 1500) return
        val out = convertDigits(text)
        val changed = out != text
        if (changed) {
            lastSet = out; lastSetAt = now
            // The Persian original stays in the clipboard history; the converted text becomes the current clip.
            try { keepOriginal?.invoke(text, ClipboardManagerCompat.getClipTimestamp(clip)) } catch (_: Throwable) {}
            cm.setPrimaryClip(ClipData.newPlainText("LeanType A", out))
        }
        // The same text copied again is reported again; only a double event within a split second is dropped.
        if (out == lastSent && now - lastSentAt < 400) return
        lastSent = out; lastSentAt = now
        val intent = Intent(ACTION).setPackage(TARGET)
            .putExtra("text", if (out.length > 20000) out.substring(0, 20000) else out)
            .putExtra("changed", changed)
        context.sendBroadcast(intent, null)
    }
}
