// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent

/**
 * LeanType A addition. Whenever something is copied (in any app, because a keyboard may read the
 * clipboard at any time): Persian and Arabic digits are replaced by 0-9 in the copied text, and the
 * A app (package a.a) is told what was copied so it can show it, translate it and so on.
 * The broadcast is protected by a signature permission, so only apps signed with the same key as A
 * can receive it.
 */
object AClipBridge {
    private const val ACTION = "a.a.CLIP_COPIED"
    private const val TARGET = "a.a"
    private const val PERMISSION = "a.a.permission.CLIP_FROM_KEYBOARD"
    private var lastSet: String? = null
    private var lastSent: String? = null

    fun convertDigits(s: String): String {
        var changed = false
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = when (ch) {
                in '۰'..'۹' -> '0' + (ch - '۰')   // Persian
                in '٠'..'٩' -> '0' + (ch - '٠')   // Arabic-Indic
                '٫' -> '.'                                  // Arabic decimal separator
                '٬' -> ','                                  // Arabic thousands separator
                else -> ch
            }
            if (c != ch) changed = true
            sb.append(c)
        }
        return if (changed) sb.toString() else s
    }

    fun onCopy(context: Context, cm: ClipboardManager) {
        val clip = try { cm.primaryClip } catch (_: Exception) { null } ?: return
        if (clip.itemCount == 0) return
        // Passwords and other items marked sensitive by the copying app are left alone.
        if (clip.description?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
        if (clip.description?.hasMimeType("text/*") != true) return
        val text = clip.getItemAt(0)?.coerceToText(context)?.toString() ?: return
        if (text.isEmpty() || text == lastSet) return
        val out = convertDigits(text)
        val changed = out != text
        if (changed) {
            lastSet = out
            cm.setPrimaryClip(ClipData.newPlainText("LeanType A", out))
        }
        if (out == lastSent) return
        lastSent = out
        val intent = Intent(ACTION).setPackage(TARGET)
            .putExtra("text", if (out.length > 20000) out.substring(0, 20000) else out)
            .putExtra("changed", changed)
        context.sendBroadcast(intent, null)
    }
}
