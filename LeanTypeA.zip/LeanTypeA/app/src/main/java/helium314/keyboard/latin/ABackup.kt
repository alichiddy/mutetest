// SPDX-License-Identifier: GPL-3.0-only

package helium314.keyboard.latin

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import helium314.keyboard.latin.utils.prefs
import helium314.keyboard.settings.preferences.BackupCategory
import helium314.keyboard.settings.preferences.doBackup
import helium314.keyboard.settings.preferences.doRestore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * LeanType A: settings backup (zip, the keyboard's own backup format), optional automatic backups to
 * Download/A Settings (last 5), restore, and "Make APK" (a copy of this keyboard with the settings baked in).
 * Nothing runs unless the automatic option is on.
 */
object ABackup {
    const val AUTO_ON = "a_auto_backup_on"
    private const val LAST_HASH = "a_auto_backup_hash"
    private const val LAST_TIME = "a_auto_backup_time"
    private const val BAKED_HASH = "a_baked_hash"
    private const val FOLDER = "A Settings"
    private const val PREFIX = "LeanType A "
    private const val KEEP = 5
    private const val BURST_MS = 10 * 60 * 1000L

    // Everything except clipboard history, typing history and API keys (private, and big).
    val CATS = setOf(BackupCategory.LAYOUTS, BackupCategory.THEME_APPEARANCE, BackupCategory.DICTIONARIES, BackupCategory.GENERAL_SETTINGS)

    private val main = Handler(Looper.getMainLooper())
    private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private var appContext: Context? = null
    private val job = Runnable { appContext?.let { Thread { autoSave(it) }.start() } }

    /** Writes the backup zip to [file]; returns null when fine, else the problem. Blocks (background thread only). */
    fun backupToFile(ctx: Context, file: File): String? {
        var err: String? = null
        val latch = CountDownLatch(1)
        doBackup(ctx, Uri.fromFile(file), CATS, { err = it; latch.countDown() }) { latch.countDown() }
        if (!latch.await(120, TimeUnit.SECONDS)) return "timed out"
        return err
    }

    fun restoreFromUri(ctx: Context, uri: Uri, onResult: (String?) -> Unit) {
        doRestore(ctx, uri, CATS, { onResult(it) }) { onResult(null) }
    }

    // ---------- automatic backups ----------
    fun autoEnabled(c: Context) = c.prefs().getBoolean(AUTO_ON, false)

    /** Call at start and whenever the option changes. */
    fun refresh(c: Context) {
        val ctx = c.applicationContext
        appContext = ctx
        val prefs = ctx.prefs()
        listener?.let { prefs.unregisterOnSharedPreferenceChangeListener(it) }
        listener = null
        main.removeCallbacks(job)
        if (!prefs.getBoolean(AUTO_ON, false)) return
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key != null && !volatile(key)) { main.removeCallbacks(job); main.postDelayed(job, 8000L) }
        }
        listener = l
        prefs.registerOnSharedPreferenceChangeListener(l)
    }

    private fun volatile(key: String): Boolean {
        val k = key.lowercase()
        return k.startsWith("a_") || k.contains("last") || k.contains("recent") || k.contains("count") ||
            k.contains("timestamp") || k.contains("dismissed") || k.contains("history") || k.contains("stats") || k.contains("time")
    }

    private fun canUseFiles() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
    private fun dir() = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER)

    class Entry(val name: String, val file: File?, val uri: Uri?)

    @Synchronized
    fun autoSave(c: Context): String? = saveNow(c, onlyIfChanged = true)

    @Synchronized
    fun saveNow(c: Context, onlyIfChanged: Boolean): String? = runCatching {
        val prefs = c.prefs()
        val stable = prefs.all.filter { !volatile(it.key) }.toSortedMap().entries.joinToString("|") { it.key + "=" + it.value }.hashCode().toString()
        if (onlyIfChanged && prefs.getString(LAST_HASH, null) == stable) return@runCatching null
        val now = System.currentTimeMillis()
        val tmp = File(c.cacheDir, "a_backup.zip")
        backupToFile(c, tmp)?.let { error(it) }
        val existing = list(c)
        if (onlyIfChanged && existing.isNotEmpty() && now - prefs.getLong(LAST_TIME, 0L) < BURST_MS) delete(c, existing.first())
        val name = PREFIX + SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.US).format(Date(now)) + ".zip"
        write(c, name, tmp)
        tmp.delete()
        list(c).drop(KEEP).forEach { delete(c, it) }
        prefs.edit().putString(LAST_HASH, stable).putLong(LAST_TIME, now).apply()
        name
    }.getOrElse { android.util.Log.w("ABackup", "backup failed", it); null }

    private fun write(c: Context, name: String, src: File) {
        if (canUseFiles()) {
            val d = dir(); d.mkdirs()
            src.copyTo(File(d, name), overwrite = true)
        } else {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + FOLDER)
            }
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error("cannot create the file")
            c.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o) } }
        }
    }

    /** The saved backups, newest first. */
    fun list(c: Context): List<Entry> {
        val out = ArrayList<Entry>()
        if (canUseFiles()) {
            dir().listFiles { f -> f.isFile && f.name.startsWith(PREFIX) && f.name.endsWith(".zip") }
                ?.forEach { out += Entry(it.name, it, null) }
        }
        if (Build.VERSION.SDK_INT >= 29) runCatching {
            c.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
                arrayOf("${Environment.DIRECTORY_DOWNLOADS}/$FOLDER%", "$PREFIX%"), null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(1)
                    if (out.any { it.name == name }) continue
                    out += Entry(name, null, ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cur.getLong(0)))
                }
            }
        }
        return out.sortedByDescending { it.name }
    }

    fun uriOf(e: Entry): Uri = e.uri ?: Uri.fromFile(e.file!!)

    private fun delete(c: Context, e: Entry) {
        runCatching { e.file?.delete() ?: c.contentResolver.delete(e.uri!!, null, null) }
    }

    // ---------- Make APK ----------
    /** Saves a copy of this keyboard with the current settings inside; returns a message. */
    fun makeApk(c: Context): String {
        val tmp = File(c.cacheDir, "a_backup_for_apk.zip")
        backupToFile(c, tmp)?.let { return "Backup failed: $it" }
        val bytes = tmp.readBytes(); tmp.delete()
        val stamp = SimpleDateFormat("yyyy-MM-dd HH-mm", Locale.US).format(Date())
        return AApkCloner.make(c, "LeanType A $stamp.apk", bytes)
    }

    // ---------- settings baked into this APK ----------
    /** First start of an APK made by Make APK (or after it updates this app): its settings are applied once. */
    @Synchronized
    fun applyBaked(c: Context) {
        val bytes = runCatching { c.assets.open(AApkCloner.ASSET_NAME).use { it.readBytes() } }.getOrNull() ?: return
        val hash = java.security.MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val prefs = c.prefs()
        if (prefs.getString(BAKED_HASH, null) == hash) return
        val tmp = File(c.cacheDir, "a_baked.zip")
        tmp.writeBytes(bytes)
        // The marker is stored first, so a failing file cannot make this run on every start.
        prefs.edit().putString(BAKED_HASH, hash).apply()
        restoreFromUri(c, Uri.fromFile(tmp)) { prefs.edit().putString(BAKED_HASH, hash).apply() }
    }
}
